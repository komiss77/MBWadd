/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.Bukkit;

public class cn
extends bS<Void> {
    public static cn a = new cn();

    @Override
    public bP.c a() {
        return bP.c.a;
    }

    @Override
    public String a(Void void_) {
        return this.c(null);
    }

    @Override
    public String c(Arena arena) {
        return "" + Bukkit.getOnlinePlayers().size();
    }
}

