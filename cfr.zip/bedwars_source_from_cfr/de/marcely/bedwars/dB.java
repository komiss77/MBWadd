/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dy;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dB
extends dy {
    public dB(Arena arena) {
        super(arena, "teamsize");
    }

    @Override
    public String e(Player player) {
        return "" + this.arena.getPerTeamPlayers();
    }
}

