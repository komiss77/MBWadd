/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import java.net.DatagramPacket;

public interface k {
    public void b(DatagramPacket var1);
}

