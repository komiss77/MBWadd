/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ch;
import de.marcely.bedwars.game.stats.c;

public class cg
extends ch {
    public static cg a = new cg();

    @Override
    protected String a(c c2) {
        return "" + c2.getKills();
    }
}

