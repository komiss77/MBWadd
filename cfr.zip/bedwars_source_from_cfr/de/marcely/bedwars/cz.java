/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cz {
    private final Player player;
    private final Arena arena;
    private final SpectateReason a;
    private final long j;

    public cz(Player player, Arena arena, SpectateReason spectateReason) {
        this.player = player;
        this.arena = arena;
        this.a = spectateReason;
        this.j = System.currentTimeMillis();
    }

    public Player getPlayer() {
        return this.player;
    }

    public Arena getArena() {
        return this.arena;
    }

    public SpectateReason a() {
        return this.a;
    }

    public long a() {
        return this.j;
    }
}

