/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Permission;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.aq;
import de.marcely.bedwars.bx;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class ap
implements Cloneable {
    public ap a;
    private String name = "NO NAME";
    private String v = "NO NAME";
    private ItemStack icon = new ItemStack(Material.STONE);
    private aq a;
    private DropType c;
    private int priceAmount = 1;
    private int capsMultiply = 1;
    private HashMap<Enchantment, Integer> d = new HashMap();
    private ExtraItem extraItem = null;
    private Integer a = null;
    public boolean keepOnDeath = false;
    public boolean oneTimePurchase = false;
    public ItemStack c = null;

    public ap(String string) {
        this.setName(string);
        this.s(string);
    }

    public ap(String string, aq aq2, DropType dropType, int n2) {
        this(string, new ItemStack(Material.STONE, 1), aq2, dropType, n2, 1);
    }

    public ap(String string, Material material, int n2, aq aq2, DropType dropType, int n3) {
        this(string, new ItemStack(material, n2), aq2, dropType, n3, n2);
    }

    public ap(String string, Material material, short s2, int n2, aq aq2, DropType dropType, int n3) {
        this(string, new ItemStack(material, n2, s2), aq2, dropType, n3, n2);
    }

    public ap(String string, aq aq2, DropType dropType, int n2, int n3) {
        this(string, new ItemStack(Material.STONE), aq2, dropType, n2, n3);
    }

    public ap(String string, Material material, int n2, aq aq2, DropType dropType, int n3, int n4) {
        this(string, new ItemStack(material, n2), aq2, dropType, n3, n4);
    }

    public ap(String string, Material material, short s2, int n2, aq aq2, DropType dropType, int n3, int n4) {
        this(string, new ItemStack(material, n2, s2), aq2, dropType, n3, n4);
    }

    public ap(String string, ExtraItem extraItem, int n2, aq aq2, DropType dropType, int n3) {
        this(string, extraItem, extraItem.getItemStack().getAmount(), aq2, dropType, n3, 1);
    }

    public ap(String string, bx bx2, int n2, aq aq2, DropType dropType, int n3) {
        this(string, bx2.getExtraItem(), bx2.getItemStack().getAmount(), aq2, dropType, n3, 1);
    }

    public ap(String string, ExtraItem extraItem, int n2, aq aq2, DropType dropType, int n3, int n4) {
        this.setName(string);
        this.s(string);
        this.setExtraItem(extraItem);
        this.setIcon(extraItem.getItemStack());
        this.a(aq2);
        this.a(dropType);
        this.c(n3);
        this.setCapsMultiply(n4);
    }

    public ap(String string, ItemStack itemStack, aq aq2, DropType dropType, int n2) {
        this(string, itemStack, aq2, dropType, n2, itemStack.getAmount());
    }

    public ap(String string, ItemStack itemStack, aq aq2, DropType dropType, int n2, int n3) {
        this.setName(string);
        this.s(string);
        this.setIcon(itemStack);
        this.a(aq2);
        this.a(dropType);
        this.c(n2);
        this.setCapsMultiply(n3);
    }

    public void a(Enchantment enchantment) {
        this.addEnchantment(enchantment, 1);
    }

    public void addEnchantment(Enchantment enchantment, int n2) {
        this.d.put(enchantment, n2);
    }

    public void setIcon(ItemStack itemStack) {
        if (itemStack.getEnchantments().size() >= 1) {
            this.d.putAll(itemStack.getEnchantments());
        }
        this.icon = itemStack;
    }

    public void a(DropType dropType, int n2) {
        this.a(dropType);
        this.c(n2);
    }

    public void a(aq aq2) {
        this.a = aq2;
    }

    public void setAmount(int n2) {
        this.icon.setAmount(n2);
    }

    public ItemStack getIcon() {
        int n2 = this.icon.getAmount();
        if (this.extraItem != null) {
            this.icon = this.extraItem.getItemStack(this.icon.getAmount());
        }
        this.icon.setAmount(n2);
        if (this.a().size() >= 1 && this.icon.getEnchantments().size() == 0) {
            ItemMeta itemMeta = this.icon.getItemMeta();
            for (Map.Entry<Enchantment, Integer> entry : this.a().entrySet()) {
                itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), false);
            }
            this.icon.setItemMeta(itemMeta);
        }
        return this.icon;
    }

    public List<ap> getItems() {
        return Arrays.asList(this);
    }

    public boolean v() {
        return this.extraItem != null;
    }

    public int getAmountPlayerCanBuy(Player player, boolean bl2) {
        int n2 = 999;
        if (this.a().getActualItemstack() != null && this.a().getActualItemstack().getType() != null && this.a().getActualItemstack().getType() != Material.AIR) {
            n2 = s.a(player, i.a(this.a().getActualItemstack().clone(), (Object)this.a().getChatColor() + this.a().a(null, true)));
        }
        if (n2 >= this.getPriceAmount()) {
            int n3 = 1;
            if (bl2) {
                n3 = n2;
            }
            if (n3 > this.getCapsMultiply()) {
                n3 = this.getCapsMultiply();
            }
            return n3;
        }
        return 0;
    }

    public HashMap<Enchantment, Integer> a() {
        return this.d;
    }

    public int getAmount() {
        return this.icon.getAmount();
    }

    public void a(Player player, Team team, int n2, Map<Enchantment, Integer> map) {
        ItemStack itemStack = this.getExtraItem() == null ? (this.getIcon() != null ? this.getIcon().clone() : null) : this.getExtraItem().getItemStack().clone();
        itemStack.setAmount(n2);
        itemStack = i.a(itemStack, team);
        ItemMeta itemMeta = itemStack.getItemMeta();
        for (Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), true);
        }
        itemStack.setItemMeta(itemMeta);
        s.a(player, itemStack);
    }

    public int getPrice(Player player) {
        return this.a != null && s.hasPermission((CommandSender)player, Permission.ShopCustomPrice) ? this.a : this.priceAmount;
    }

    public ap a() {
        try {
            ap ap2 = (ap)super.clone();
            ap2.c = this.c != null ? this.c.b() : null;
            ap2.icon = this.icon != null ? this.icon.clone() : null;
            ap2.a = this.a != null ? this.a : this;
            return ap2;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public void setName(String string) {
        this.name = string;
    }

    public void s(String string) {
        this.v = string;
    }

    public String getName() {
        return this.name;
    }

    public String getRealName() {
        return this.v;
    }

    public aq a() {
        return this.a;
    }

    public void a(DropType dropType) {
        this.c = dropType;
    }

    public DropType a() {
        return this.c;
    }

    public int getPriceAmount() {
        return this.priceAmount;
    }

    public void c(int n2) {
        this.priceAmount = n2;
    }

    public int getCapsMultiply() {
        return this.capsMultiply;
    }

    public void setCapsMultiply(int n2) {
        this.capsMultiply = n2;
    }

    public ExtraItem getExtraItem() {
        return this.extraItem;
    }

    public void setExtraItem(ExtraItem extraItem) {
        this.extraItem = extraItem;
    }

    public Integer a() {
        return this.a;
    }

    public void a(Integer n2) {
        this.a = n2;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return this.a();
    }
}

