/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  de.devcubehd.cloudsystem.api.CloudSystemAPI
 *  de.devcubehd.cloudsystem.api.Ping
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import com.google.gson.JsonObject;
import de.devcubehd.cloudsystem.api.CloudSystemAPI;
import de.devcubehd.cloudsystem.api.Ping;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.cZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.List;
import org.bukkit.entity.Player;

public class dc
extends cZ {
    @Override
    public cT a() {
        return cT.d;
    }

    @Override
    public void onEnable() {
        CloudSystemAPI.getPingAPI().setPing(new Ping(){

            public JsonObject ping() {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("packet", "PING");
                Arena arena = s.b(ConfigValue.cloudsystem_arena);
                if (arena == null) {
                    d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
                }
                if (arena != null) {
                    jsonObject.addProperty("players", (Number)arena.getPlayers().size());
                    jsonObject.addProperty("maxplayers", (Number)arena.getMaxPlayers());
                    jsonObject.addProperty("status", arena.b().name());
                    jsonObject.addProperty("extra", ConfigValue.cloudsystem_extra.a(arena));
                } else {
                    jsonObject.addProperty("players", (Number)-1);
                    jsonObject.addProperty("maxplayers", (Number)-1);
                    jsonObject.addProperty("status", "MBW: WARNING");
                    jsonObject.addProperty("extra", "Only 1 Arena!");
                }
                return jsonObject;
            }
        });
    }

    @Override
    public void onDisable() {
    }

}

