/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;

public class bT
extends bS<Void> {
    private final String I;

    public bT(String string) {
        this.I = string;
    }

    @Override
    public bP.c a() {
        return bP.c.a;
    }

    @Override
    public String a(Void void_) {
        return this.I;
    }

    @Override
    public String c(Arena arena) {
        return this.I;
    }

    public String p() {
        return this.I;
    }
}

