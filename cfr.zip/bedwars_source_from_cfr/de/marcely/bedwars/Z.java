/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.versions.Version;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class Z {
    private List<Player> players;
    private HashMap<Player, List<Object>> a;
    private HashMap<Player, List<Object>> b;
    public Location loc;
    private static final double a = 0.23;
    private static String path = Bukkit.getServer().getClass().getPackage().getName();
    private static String version = path.substring(path.lastIndexOf(".") + 1, path.length());
    private static Class<?> a;
    private static Class<?> b;
    private static Class<?> c;
    private static Class<?> d;
    private static Class<?> e;
    private static Class<?> f;
    private static Constructor<?> a;
    private static Class<?> g;
    private static Constructor<?> b;
    private static Class<?> h;

    static {
        try {
            a = Class.forName("net.minecraft.server." + version + ".EntityArmorStand");
            b = Class.forName("net.minecraft.server." + version + ".World");
            c = Class.forName("net.minecraft.server." + version + ".Entity");
            d = Class.forName("org.bukkit.craftbukkit." + version + ".CraftWorld");
            e = Class.forName("net.minecraft.server." + version + ".PacketPlayOutSpawnEntityLiving");
            f = Class.forName("net.minecraft.server." + version + ".EntityLiving");
            a = ((Class)((Object)a)).getConstructor(new Class[]{b});
            g = Class.forName("net.minecraft.server." + version + ".PacketPlayOutEntityDestroy");
            b = g.getConstructor(int[].class);
            h = Class.forName("net.minecraft.server." + version + ".Packet");
        }
        catch (ClassNotFoundException | NoSuchMethodException | SecurityException exception) {
            System.err.println("Error - Classes not initialized!");
            exception.printStackTrace();
        }
    }

    public Z(Location location) {
        if (Version.a().getVersionNumber() <= 7) {
            new SecurityException("Outdated spigot version").printStackTrace();
        }
        this.loc = location;
        this.players = new ArrayList<Player>();
        this.b = new HashMap();
        this.a = new HashMap();
    }

    public boolean b(Player player) {
        if (!this.players.contains((Object)player)) {
            List<Object> list = this.b.get((Object)player);
            for (int i2 = 0; i2 < list.size(); ++i2) {
                this.sendPacket(player, list.get(i2));
            }
            this.players.add(player);
            return true;
        }
        return false;
    }

    public boolean c(Player player) {
        if (this.players.contains((Object)player)) {
            List<Object> list = this.a.get((Object)player);
            for (int i2 = 0; i2 < list.size(); ++i2) {
                this.sendPacket(player, list.get(i2));
            }
            this.players.remove((Object)player);
            return true;
        }
        return false;
    }

    private Object a(World world, double d2, double d3, double d4, String string) {
        try {
            Method method;
            Object obj = d.cast((Object)world);
            Method method2 = obj.getClass().getMethod("getHandle", new Class[0]);
            Object t2 = ((Constructor)((Object)a)).newInstance(method2.invoke(obj, new Object[0]));
            Method method3 = t2.getClass().getMethod("setCustomName", String.class);
            method3.invoke(t2, string);
            Method method4 = c.getMethod("setCustomNameVisible", Boolean.TYPE);
            method4.invoke(t2, true);
            if (Version.a().getVersionNumber() <= 9) {
                method = t2.getClass().getMethod("setGravity", Boolean.TYPE);
                method.invoke(t2, false);
            } else {
                method = t2.getClass().getMethod("setNoGravity", Boolean.TYPE);
                method.invoke(t2, true);
            }
            method = t2.getClass().getMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE);
            method.invoke(t2, d2, d3, d4, Float.valueOf(0.0f), Float.valueOf(0.0f));
            Method method5 = t2.getClass().getMethod("setInvisible", Boolean.TYPE);
            method5.invoke(t2, true);
            Constructor<?> constructor = e.getConstructor(f);
            Object obj2 = constructor.newInstance(t2);
            return obj2;
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    private Object a(int ... arrn) {
        try {
            return ((Constructor)((Object)b)).newInstance(new Object[]{arrn});
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException | InvocationTargetException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    private void sendPacket(Player player, Object object) {
        try {
            Method method = player.getClass().getMethod("getHandle", new Class[0]);
            Object object2 = method.invoke((Object)player, new Object[0]);
            Object object3 = object2.getClass().getField("playerConnection").get(object2);
            Method method2 = object3.getClass().getMethod("sendPacket", h);
            method2.invoke(object3, object);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(Player player, List<String> list) {
        this.b.remove((Object)player);
        this.a.remove((Object)player);
        ArrayList<Object> arrayList = new ArrayList<Object>();
        ArrayList<Object> arrayList2 = new ArrayList<Object>();
        Location location = this.loc.clone().add(0.0, 0.23 * (double)list.size() - 1.97, 0.0);
        for (int i2 = 0; i2 < list.size(); ++i2) {
            Object object = this.a(this.loc.getWorld(), location.getX(), location.getY(), location.getZ(), list.get(i2));
            arrayList.add(object);
            try {
                String string = "a";
                Field field = e.getDeclaredField(string);
                field.setAccessible(true);
                arrayList2.add(this.a((Integer)field.get(object)));
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            location.add(0.0, -0.23, 0.0);
        }
        this.b.put(player, arrayList);
        this.a.put(player, arrayList2);
    }

    public List<Player> getPlayers() {
        return this.players;
    }
}

