/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;

public abstract class ea {
    public void a(Player player, int n2) {
    }

    public void b(Player player, int n2) {
    }

    @Nullable
    public List<String> a(Player player, String string) {
        return null;
    }

    public boolean a(Player player, long l2, long l3) {
        return false;
    }

    public boolean a(Player player, float f2, int n2, float f3) {
        return false;
    }

    public boolean a(Player player, float f2) {
        return false;
    }

    public boolean b(Player player, int n2, Object object, Object object2) {
        return false;
    }

    public void a(Player player, int n2, int n3) {
    }
}

