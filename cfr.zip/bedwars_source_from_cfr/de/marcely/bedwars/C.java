/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.S;
import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.ArrayList;
import java.util.Collection;

public class C
extends NormalPacket {
    public byte k;
    public Collection<S> a;

    @Override
    public byte getPacketID() {
        return 3;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.k);
        bufferedWriteStream.writeUnsignedByte(this.a.size());
        for (S s2 : this.a) {
            bufferedWriteStream.writeString(s2.name());
        }
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.k = bufferedReadStream.readByte();
        int n2 = bufferedReadStream.readUnsignedByte();
        this.a = new ArrayList<S>(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            S s2 = S.a(bufferedReadStream.readString());
            if (s2 == null) continue;
            this.a.add(s2);
        }
    }
}

