/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.server.PluginDisableEvent
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.BedwarsAddon;
import java.util.Map;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.Plugin;

public class aw {
    public static void a(PluginDisableEvent pluginDisableEvent) {
        MBedwars.b.remove((Object)pluginDisableEvent.getPlugin());
    }
}

