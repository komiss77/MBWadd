/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dR;
import de.marcely.bedwars.game.stats.c;

public class dU
extends dR {
    public dU() {
        super("roundsplayed");
    }

    @Override
    public String c(c c2) {
        return "" + c2.getRoundsPlayed();
    }
}

