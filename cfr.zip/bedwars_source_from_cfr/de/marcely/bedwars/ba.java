/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cA;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ba {
    public static void b(PlayerPickupItemEvent playerPickupItemEvent) {
        Object object;
        List list;
        Player player = playerPickupItemEvent.getPlayer();
        ItemStack itemStack = playerPickupItemEvent.getItem().getItemStack();
        Arena arena = s.a(player);
        if (cA.E.containsKey((Object)player)) {
            playerPickupItemEvent.setCancelled(true);
        } else if (arena != null) {
            if (arena.b().F()) {
                playerPickupItemEvent.setCancelled(true);
            } else if (arena.b() == ArenaStatus.f && (list = (List)s.W.get((Object)playerPickupItemEvent.getItem().getItemStack().getType())) != null && list.size() == 1) {
                object = (ShopProduct)list.get(0);
                playerPickupItemEvent.getItem().setItemStack(((ShopProduct)object).getGiveItem(itemStack, player, arena.a(player), itemStack.getAmount(), arena));
            }
        }
        list = playerPickupItemEvent.getItem().getItemStack().getItemMeta().getLore();
        if (list != null && list.size() == 1 && s.isInteger((String)list.get(0))) {
            object = itemStack.getItemMeta();
            object.setLore(null);
            itemStack.setItemMeta((ItemMeta)object);
        }
    }
}

