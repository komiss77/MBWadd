/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dR;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.s;

public class dS
extends dR {
    public dS() {
        super("playtime");
    }

    @Override
    public String c(c c2) {
        return s.a(c2.getPlayTime());
    }
}

