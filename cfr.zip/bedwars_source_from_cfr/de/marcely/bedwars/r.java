/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.j;

public class r
extends j {
    private String g;

    public r(String string) {
        this.g = string;
    }

    public String e() {
        return this.g;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.m.getID()) + "/" + this.e().replace("/", "&sKEYslash;");
    }

    public static r a(String string) {
        String[] arrstring = string.split("/");
        if (arrstring.length == 2) {
            return new r(arrstring[1].replace("&sKEYslash;", "/"));
        }
        return null;
    }
}

