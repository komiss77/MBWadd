/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.holographic.a;
import de.marcely.bedwars.holographic.b;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.holographic.i;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class cI
extends f<cE>
implements a,
b {
    private Object h;
    private Object i;
    private final e a = new e(this);
    private boolean U;

    public cI(g g2, Location location) {
        super(g2, location);
    }

    @Override
    public i a() {
        return i.a;
    }

    @Override
    public float getHeight() {
        return this.U ? 0.9875f : 1.975f;
    }

    @Override
    public void a(cE cE2) {
        try {
            Object obj = NMSClass.l.cast((Object)this.location.getWorld());
            Object object = obj.getClass().getMethod("getHandle", new Class[0]).invoke(obj, new Object[0]);
            this.g = Version.a().getVersionNumber() <= 13 ? NMSClass.A.getDeclaredConstructor(NMSClass.n).newInstance(object) : NMSClass.A.getDeclaredConstructor(NMSClass.X, NMSClass.n).newInstance(NMSClass.X.getField("ARMOR_STAND").get(null), object);
            int[] arrn = new int[]{(Integer)NMSClass.q.getMethod("getId", new Class[0]).invoke(this.g, new Object[0])};
            this.entityId = arrn[0];
            this.i = NMSClass.y.getDeclaredConstructor(int[].class).newInstance(new Object[]{arrn});
            this.setLocation(this.location);
            this.setCustomName(cE2.name);
            cE2.a((ArmorStand)NMSClass.q.getMethod("getBukkitEntity", new Class[0]).invoke(this.g, new Object[0]), this);
            this.h = NMSClass.B.getDeclaredConstructor(NMSClass.t).newInstance(this.g);
            this.U = cE2.d;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    protected void D(Player player) {
        Version.a().sendPacket(player, this.h);
        this.a.send(player);
        this.F(player);
    }

    @Override
    protected void E(Player player) {
        Version.a().sendPacket(player, this.i);
    }

    @Override
    public void F(Player player) {
        try {
            Version.a().sendPacket(player, NMSClass.K.getDeclaredConstructor(NMSClass.q).newInstance(this.g));
            if (Version.a().getVersionNumber() >= 9) {
                Version.a().sendPacket(player, NMSClass.O.getDeclaredConstructor(Integer.TYPE, Byte.TYPE, Byte.TYPE, Boolean.TYPE).newInstance(this.entityId, (byte)(this.location.getYaw() * 256.0f / 360.0f), (byte)(this.location.getPitch() * 256.0f / 360.0f), true));
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void a(Player player, float f2) {
        try {
            Object obj = NMSClass.z.getDeclaredConstructor(NMSClass.q, Byte.TYPE).newInstance(this.g, (byte)2);
            if (!this.a(this.getHealth() - f2)) {
                Version.a().sendPacket(player, obj);
                Sound.ENTITY_ARMOR_STAND_HIT.play(this.getLocation());
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public boolean a(float f2) {
        try {
            float f3 = this.getHealth();
            NMSClass.t.getMethod("setHealth", Float.TYPE).invoke(this.g, Float.valueOf(f2));
            if (f2 <= 0.0f && f3 >= 1.0f) {
                Object obj = NMSClass.z.getDeclaredConstructor(NMSClass.q, Byte.TYPE).newInstance(this.g, (byte)3);
                for (Player player : de.marcely.bedwars.util.b.a(this.location, Bukkit.getViewDistance() * 16)) {
                    Version.a().sendPacket(player, obj);
                }
                Sound.ENTITY_ARMOR_STAND_BREAK.play(this.getLocation());
                new BukkitRunnable(){

                    public void run() {
                        cI.this.a.R();
                    }
                }.runTaskLaterAsynchronously((Plugin)MBedwars.a, 40L);
                return true;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    @Override
    public float getHealth() {
        try {
            return ((Float)NMSClass.t.getMethod("getHealth", new Class[0]).invoke(this.g, new Object[0])).floatValue();
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
            return -1.0f;
        }
    }

    @Override
    public void setCustomName(@Nullable String string) {
        this.y(string);
    }

    @Override
    public e a() {
        return this.a;
    }

}

