/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.d;
import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class H
extends NormalPacket {
    public String name;
    public d a;

    @Override
    public byte getPacketID() {
        return 32;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
        this.a.write(bufferedWriteStream);
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
        this.a = (d)Value.a(bufferedReadStream);
    }
}

