/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.c;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class s
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        de.marcely.bedwars.util.s.k = player.getLocation();
        de.marcely.bedwars.util.s.k.setWorld(player.getWorld());
        c.save();
        de.marcely.bedwars.util.s.a(commandSender, b.a(Language.Changed_GameDoneLocation));
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

