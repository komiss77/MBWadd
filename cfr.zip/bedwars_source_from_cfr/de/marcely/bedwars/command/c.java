/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.q;
import de.marcely.bedwars.game.stats.StatsSign;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class c
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length >= 2) {
            Block block = b.getLookingBlock(player, 10);
            if (block != null && block.getType() != null && a.b(block)) {
                if (s.isInteger(arrstring[1])) {
                    int n2 = Integer.valueOf(arrstring[1]);
                    if (n2 >= 1 && n2 <= 10) {
                        StatsSign statsSign = new StatsSign(n2, block.getLocation());
                        statsSign.a(de.marcely.bedwars.game.stats.b.a[n2 - 1]);
                        statsSign.update();
                        s.T.put(block.getLocation().toString(), statsSign);
                        q.save();
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Added_Sign));
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Place).a("place", arrstring[1]));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", arrstring[1]));
                }
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotLooking_AtSign));
            }
        } else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

