/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.e;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class i
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Arena arena = s.a((Player)commandSender);
        if (arena != null) {
            if (arena.b() == ArenaStatus.e) {
                if (arena.j() >= arena.k()) {
                    if (arena.a != null && arena.a.getValue() >= ConfigValue.forcestart_time && !arena.a.I()) {
                        arena.f((Player)commandSender);
                    } else {
                        s.a(commandSender, b.a(Language.ForceStart_Already));
                    }
                } else {
                    s.a(commandSender, b.a(Language.TooLess_Players).a("arena", arena.getName()));
                }
            } else if (arena.b() == ArenaStatus.f) {
                s.a(commandSender, b.a(Language.JoinMessage_running).a("arena", arena.getName()));
            } else if (arena.b() == ArenaStatus.d) {
                s.a(commandSender, b.a(Language.JoinMessage_stopped).a("arena", arena.getName()));
            }
        } else {
            s.a(commandSender, b.a(Language.Not_Ingame));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

