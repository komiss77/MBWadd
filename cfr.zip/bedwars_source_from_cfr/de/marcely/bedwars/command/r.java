/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class r
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        ArrayList<Arena> arrayList = new ArrayList<Arena>();
        for (Arena object2 : s.af) {
            if (object2.b() != ArenaStatus.f) continue;
            arrayList.add(object2);
        }
        GUI gUI = new GUI(b.a(Language.GUI_RunningGames_Title).f(commandSender), 1);
        if (arrayList.size() >= 1) {
            for (Object object3 : arrayList) {
                gUI.addItem(new GUIItem(i.a(i.a(((Arena)object3).getIcon(), (Object)ChatColor.WHITE + ((Arena)object3).getDisplayName()), new String[]{String.valueOf((Object)ChatColor.YELLOW + ((Arena)object3).j() + (Object)ChatColor.GOLD + "/" + (Object)ChatColor.YELLOW + ((Arena)object3).getMaxPlayers())}), (Arena)object3, player){
                    private final /* synthetic */ Arena val$arena;
                    private final /* synthetic */ Player val$player;
                    {
                        this.val$arena = arena;
                        this.val$player = player;
                        super(itemStack);
                    }

                    @Override
                    public void onClick(Player player, boolean bl2, boolean bl3) {
                        if (this.val$arena.b() == ArenaStatus.f) {
                            String string = s.b(player, this.val$arena);
                            if (string != null) {
                                player.sendMessage(string);
                            }
                        } else {
                            Sound.CMD_RUNNINGGAME_FAILURE.play(this.val$player);
                        }
                    }
                });
            }
            gUI.centerAtYAll(GUI.CenterFormatType.Beautiful);
        } else {
            gUI.setItemAt(new GUIItem(i.a(new ItemStack(s.e), b.a(Language.RunningGames_NoOne).f(commandSender))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                }
            }, 4, 0);
        }
        gUI.open(player);
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }

}

