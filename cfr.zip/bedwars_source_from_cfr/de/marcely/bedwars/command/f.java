/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.a;
import de.marcely.bedwars.b;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class f
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;
    private List<CommandSender> e = new ArrayList<CommandSender>();

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(final CommandSender commandSender, String string, String string2, String[] arrstring) {
        block28 : {
            b[] arrb;
            block26 : {
                block30 : {
                    block29 : {
                        block27 : {
                            String string3;
                            arrb = b.a();
                            if (arrstring.length < 2) break block26;
                            String string4 = string3 = arrstring[1].toLowerCase();
                            switch (string4.hashCode()) {
                                case -1352294148: {
                                    if (string4.equals("create")) break block27;
                                    break block28;
                                }
                                case -1335458389: {
                                    if (string4.equals("delete")) break block29;
                                    break block28;
                                }
                                case 3322014: {
                                    if (string4.equals("list")) break;
                                    break block28;
                                }
                                case 1097519758: {
                                    if (string4.equals("restore")) break block30;
                                    break block28;
                                }
                            }
                            commandSender.sendMessage("");
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_List));
                            for (b b2 : arrb) {
                                try {
                                    BasicFileAttributes basicFileAttributes = Files.readAttributes(b2.getFile().toPath(), BasicFileAttributes.class, new LinkOption[0]);
                                    commandSender.sendMessage((Object)ChatColor.AQUA + b2.getName() + " " + (Object)ChatColor.DARK_AQUA + " " + s.b(b2.getFile().length()) + " " + (Object)ChatColor.GRAY + s.a(new Date(basicFileAttributes.creationTime().toMillis())));
                                }
                                catch (IOException iOException) {
                                    iOException.printStackTrace();
                                }
                            }
                            commandSender.sendMessage("");
                            break block28;
                        }
                        if (arrstring.length >= 3) {
                            b b3 = new b(arrstring[2]);
                            if (!b3.getFile().exists()) {
                                double d2 = (double)b3.a().longValue() / 1000.0;
                                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Create_Success).a("name", b3.getName()).a("time", "" + d2));
                            } else {
                                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Create_Exists).a("name", b3.getName()));
                            }
                        } else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + string + " backup create <name>"));
                        }
                        break block28;
                    }
                    if (arrstring.length >= 3) {
                        b b4 = new b(arrstring[2]);
                        if (b4.getFile().exists()) {
                            b4.getFile().delete();
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Delete_Success).a("name", b4.getName()));
                        } else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Unkown).a("name", b4.getName()));
                        }
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + string + " backup delete <name>"));
                    }
                    break block28;
                }
                if (arrstring.length >= 3) {
                    b b5 = new b(arrstring[2]);
                    if (b5.getFile().exists()) {
                        if (this.e.contains((Object)commandSender)) {
                            long l2 = System.currentTimeMillis();
                            List<Plugin> list = MBedwars.a.getEnabledAddons();
                            for (Plugin plugin : list) {
                                Bukkit.getPluginManager().disablePlugin(plugin);
                            }
                            Bukkit.getPluginManager().disablePlugin((Plugin)MBedwars.a);
                            b5.b();
                            Bukkit.getPluginManager().enablePlugin((Plugin)MBedwars.a);
                            for (Plugin plugin : list) {
                                Bukkit.getPluginManager().enablePlugin(plugin);
                            }
                            double d3 = (double)(System.currentTimeMillis() - l2) / 1000.0;
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Success).a("name", b5.getName()).a("time", "" + d3));
                        } else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Ask1).a("name", b5.getName()));
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Ask2));
                            this.e.add(commandSender);
                            new BukkitRunnable(){

                                public void run() {
                                    f.this.e.remove((Object)commandSender);
                                }
                            }.runTaskLater((Plugin)MBedwars.a, 200L);
                        }
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Unkown).a("name", b5.getName()));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + string + " backup restore <name>"));
                }
                break block28;
            }
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender));
            for (int i2 = 0; i2 < 6; ++i2) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " list" + (Object)ChatColor.DARK_GRAY + " (" + arrb.length + ")");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " create" + (Object)ChatColor.AQUA + " <name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " delete" + (Object)ChatColor.AQUA + " <name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " restore" + (Object)ChatColor.AQUA + " <name>");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return null;
    }

}

