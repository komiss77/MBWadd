/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.bl;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.game.arena.picker.condition.c;
import de.marcely.bedwars.game.arena.picker.condition.d;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class e
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;
    private Map<String, a> d = new HashMap<String, a>();

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
        new de.marcely.bedwars.command.e$1();
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        a a2;
        String string3 = "";
        if (arrstring.length >= 1) {
            string3 = String.join((CharSequence)" ", Arrays.copyOfRange(arrstring, 1, arrstring.length));
        }
        if ((a2 = this.d.get(string3)) == null) {
            a2 = new a();
            if (!string3.isEmpty()) {
                try {
                    a2.a = new d().a(string3);
                }
                catch (bl bl2) {
                    s.a(commandSender, b.a(Language.Error_Occured_Syntax).a("message", bl2.getMessage()));
                    return;
                }
            }
            a2.update();
            final String string4 = string3;
            a2.gui = new GUI(b.a(Language.ArenasGUI_Title).f(null), 0){

                @Override
                public void onClose(Player player) {
                    if (this.getPlayersWhoUseThisGUI().size() == 0) {
                        e.this.d.remove(string4);
                    }
                }
            };
            e.a(a2.gui, a2.d);
            this.d.put(string3, a2);
        }
        a2.gui.open((Player)commandSender);
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }

    private static void a(GUI gUI, List<Arena> list) {
        gUI.clear();
        gUI.setHeight(0);
        list.sort(new Comparator<Arena>(){

            public int a(Arena arena, Arena arena2) {
                if (arena.b() == ArenaStatus.e) {
                    return arena.getPlayers().size() >= arena2.getPlayers().size() ? -1 : 1;
                }
                if (arena2.b() == ArenaStatus.e) {
                    return -this.a(arena2, arena);
                }
                return 0;
            }

            @Override
            public /* synthetic */ int compare(Object object, Object object2) {
                return this.a((Arena)object, (Arena)object2);
            }
        });
        for (final Arena arena : list) {
            ItemStack itemStack = arena.b() == ArenaStatus.e ? ConfigValue.gui_arenasgui_joinable_item.clone() : ConfigValue.gui_arenasgui_not_joinable_item.clone();
            itemStack = i.b(itemStack, arena.o());
            itemStack = i.a(itemStack, (Object)ChatColor.WHITE + arena.getDisplayName());
            gUI.addItem(new GUIItem(itemStack){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    s.b(player, arena);
                }
            });
        }
        gUI.centerAtYAll(GUI.CenterFormatType.Normal);
        gUI.update();
    }

    private static class a {
        public List<Arena> d = new ArrayList<Arena>();
        public GUI gui;
        @Nullable
        public c a;

        private a() {
        }

        public void update() {
            if (this.a != null) {
                this.d = new ArrayList<Arena>();
                for (Arena arena : s.af) {
                    if (!this.a.a(arena)) continue;
                    this.d.add(arena);
                }
            } else {
                this.d = s.af;
            }
        }
    }

}

