/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class n
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 2) {
            Player player = Bukkit.getPlayer((String)arrstring[1]);
            if (player != null) {
                Arena arena = s.a(player);
                if (arena != null) {
                    arena.a(KickReason.c, player);
                    s.a(commandSender, b.a(Language.Kicked_Player).a("player", player.getName()).a("arena", arena.getName()));
                    s.a((CommandSender)player, b.a(Language.Kicked_Player_ToPlayer));
                } else {
                    s.a(commandSender, b.a(Language.Not_Ingame_Player).a("player", player.getName()));
                }
            } else {
                s.a(commandSender, b.a(Language.NotFound_Player).a("player", arrstring[1]));
            }
        } else {
            s.a(commandSender, b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.z();
        }
        if (arrstring.length == 1) {
            return s.a(s.z(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

