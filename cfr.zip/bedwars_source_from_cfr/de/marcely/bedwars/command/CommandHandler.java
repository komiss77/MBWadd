/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.api.event.CommandFireEvent;
import de.marcely.bedwars.command.a;
import de.marcely.bedwars.command.b;
import de.marcely.bedwars.command.c;
import de.marcely.bedwars.command.d;
import de.marcely.bedwars.command.e;
import de.marcely.bedwars.command.f;
import de.marcely.bedwars.command.g;
import de.marcely.bedwars.command.h;
import de.marcely.bedwars.command.i;
import de.marcely.bedwars.command.j;
import de.marcely.bedwars.command.k;
import de.marcely.bedwars.command.l;
import de.marcely.bedwars.command.m;
import de.marcely.bedwars.command.n;
import de.marcely.bedwars.command.o;
import de.marcely.bedwars.command.p;
import de.marcely.bedwars.command.q;
import de.marcely.bedwars.command.r;
import de.marcely.bedwars.command.s;
import de.marcely.bedwars.command.t;
import de.marcely.bedwars.command.u;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CommandHandler
implements CommandExecutor {
    private List<Command> f = new ArrayList<Command>();

    public CommandHandler() {
        this.refresh();
    }

    public void refresh() {
        this.f.clear();
        this.f.add(new Command(this, (Command.a)new j(), null, false, false, "[page]", "help"));
        this.f.add(new Command(this, (Command.a)new d(), Permission.Command_Arena, false, "[args...]", "arena", "arenas"));
        this.f.add(new Command(this, (Command.a)new u(), Permission.Command_Summon, true, "[args...]", "summon", "spawn", "summonentity", "spawnentity"));
        this.f.add(new Command(this, (Command.a)new b(), Permission.Command_AddSign, true, "<arena name>", "addsign", "signadd", "sign", "signsadd", "addsigns"));
        this.f.add(new Command(this, (Command.a)new c(), Permission.Command_AddStatsSign, true, "<place>", "addstatssign", "signstatsadd", "statssign", "signsaddstats", "addsignsstats"));
        this.f.add(new Command(this, (Command.a)new s(), Permission.Command_SetGameDoneLocation, true, "", "setgamedonelocation", "sgdl", "gamedonelocation", "gamedonelocationset"));
        this.f.add(new Command(this, (Command.a)new k(), Permission.Command_Hologram, true, "[args...]", "hologram", "holograms"));
        this.f.add(new Command(this, (Command.a)new m(), Permission.Command_Join, true, "<arena name>", "join", "enter"));
        this.f.add(new Command(this, (Command.a)new o(), Permission.Command_Leave, true, "", "leave", "quit"));
        this.f.add(new Command(this, (Command.a)new n(), Permission.Command_Kick, true, "<player name>", "kick", "kickplayer"));
        this.f.add(new Command(this, (Command.a)new t(), Permission.Command_Stats, true, "[player]", "stats"));
        this.f.add(new Command(this, (Command.a)new i(), Permission.Command_Forcestart, true, "", "forcestart", "fs", "forcestartround", "forcestartgame", "forcestartarena"));
        this.f.add(new Command(this, (Command.a)new a(), Permission.Command_Addon, false, "[args...]", "addon", "add-on", "addons", "add-ons"));
        this.f.add(new Command(this, (Command.a)new g(), Permission.Command_CheckUpdate, false, "", "checkupdate"));
        this.f.add(new Command(this, (Command.a)new q(), Permission.Command_Reload, false, "", "reload", "rl"));
        this.f.add(new Command(this, (Command.a)new p(), Permission.Command_RecalculateStats, false, false, "", "calulatestats", "recalculatestats", "rlstats", "reloadstats"));
        this.f.add(new Command(this, (Command.a)new e(), Permission.Command_ArenasGUI, false, "", "arenasgui"));
        this.f.add(new Command(this, (Command.a)new r(), Permission.Command_RunningGames, true, "", "runninggames"));
        this.f.add(new Command(this, (Command.a)new f(), Permission.Command_Backup, false, "", "backup"));
        this.f.add(new Command(this, (Command.a)new h(), Permission.Command_Debug, true, false, "", "debug"));
        this.f.add(new Command(this, (Command.a)new l(), Permission.Command_Info, false, "", "info", "infos", "information", "informations", "about"));
    }

    public boolean onCommand(CommandSender commandSender, org.bukkit.command.Command command, String string, String[] arrstring) {
        if (arrstring.length >= 1) {
            Command command2 = this.a(arrstring[0]);
            if (command2 != null) {
                if (!command2.f || command2.f && commandSender instanceof Player) {
                    if (command2.a[0].equals("info") || command2.a[0].equals("debug") && commandSender instanceof Player && ((Player)commandSender).getName().equals("Marcely1199") || command2.a == null || command2.a != null && de.marcely.bedwars.util.s.hasPermission(commandSender, command2.a)) {
                        this.a(command2, commandSender, string, "/" + string + " " + arrstring[0].toLowerCase() + " " + command2.usage, arrstring);
                    } else {
                        this.a(this.f.get(0), commandSender, string, null, arrstring);
                    }
                } else {
                    de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                }
            } else if (!de.marcely.bedwars.util.s.isInteger(arrstring[0])) {
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", arrstring[0]));
            } else {
                this.a(this.f.get(0), commandSender, string, null, arrstring);
            }
        } else {
            this.a(this.f.get(0), commandSender, string, null, arrstring);
        }
        return true;
    }

    private void a(Command command, CommandSender commandSender, String string, String string2, String ... arrstring) {
        CommandFireEvent commandFireEvent = new CommandFireEvent(commandSender, command);
        Bukkit.getPluginManager().callEvent((Event)commandFireEvent);
        if (!commandFireEvent.isCancelled()) {
            command.a.a(commandSender, string, string2, arrstring);
        }
    }

    public List<Command> getCommands() {
        return this.f;
    }

    public List<String> c() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Command command : this.f) {
            arrayList.add(command.a()[0]);
        }
        return arrayList;
    }

    public Command a(String string) {
        String string2 = string.toLowerCase();
        for (Command command : this.f) {
            for (String string3 : command.a) {
                if (!string2.equals(string3)) continue;
                return command;
            }
        }
        return null;
    }

    public List<String> a(String string, CommandSender commandSender) {
        String[] arrstring = CommandHandler.a(string);
        if (arrstring.length >= 2) {
            Command command = this.a(arrstring[1]);
            if (command != null && arrstring.length >= 3) {
                List<String> list = command.a().a(Arrays.copyOfRange(arrstring, 2, arrstring.length), string, commandSender);
                if (list != null) {
                    return list;
                }
                return de.marcely.bedwars.util.s.z();
            }
            return de.marcely.bedwars.util.s.a(this.c(), arrstring[1]);
        }
        return this.c();
    }

    private static String[] a(String string) {
        String[] arrstring = string.split(" ");
        if (!string.endsWith(" ")) {
            return arrstring;
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        for (String string2 : arrstring) {
            arrayList.add(string2);
        }
        arrayList.add("");
        return arrayList.toArray(new String[arrayList.size()]);
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class Command {
        protected CommandHandler b;
        protected a a;
        protected Permission a;
        protected boolean f;
        protected boolean visible;
        protected String usage;
        protected String[] a;

        public Command(CommandHandler commandHandler, a a2, Permission permission, boolean bl2, String string, String ... arrstring) {
            this(commandHandler, a2, permission, bl2, true, string, arrstring);
        }

        public Command(CommandHandler commandHandler, a a2, Permission permission, boolean bl2, boolean bl3, String string, String ... arrstring) {
            this.b = commandHandler;
            this.a = a2;
            this.a = permission;
            this.f = bl2;
            this.visible = bl3;
            this.usage = string;
            this.a = arrstring;
            a2.a(this);
        }

        public CommandHandler getCommandHandler() {
            return this.b;
        }

        public a a() {
            return this.a;
        }

        public Permission a() {
            return this.a;
        }

        public boolean n() {
            return this.f;
        }

        public boolean isVisible() {
            return this.f;
        }

        public String getUsage() {
            return this.usage;
        }

        public String[] a() {
            return this.a;
        }

        public static interface a {
            public void a(Command var1);

            public void a(CommandSender var1, String var2, String var3, String[] var4);

            @Nullable
            public List<String> a(String[] var1, String var2, CommandSender var3);
        }

    }

}

