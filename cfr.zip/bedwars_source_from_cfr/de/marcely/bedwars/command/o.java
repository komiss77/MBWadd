/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class o
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        Arena arena = s.a(player);
        if (arena != null) {
            arena.a(KickReason.b, (Player)commandSender);
        } else if (cA.E.containsKey((Object)player)) {
            cA.a(player, cD.b);
        } else {
            s.a(commandSender, b.a(Language.Not_Ingame));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

