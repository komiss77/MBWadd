/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class j
implements CommandHandler.Command.a {
    public static final int f = 7;
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        int n2;
        List<CommandHandler.Command> list = this.a(commandSender);
        int n3 = (int)Math.ceil((double)this.a(commandSender).size() / 7.0);
        int n4 = 1;
        if (arrstring.length >= 1 && s.isInteger(arrstring[0])) {
            n4 = Integer.valueOf(arrstring[0]);
        } else if (arrstring.length >= 2 && s.isInteger(arrstring[1])) {
            n4 = Integer.valueOf(arrstring[1]);
        }
        int n5 = n4 >= 1 ? Math.max(0, Math.min(7, list.size() - (n4 - 1) * 7)) : 0;
        commandSender.sendMessage((Object)ChatColor.YELLOW + " ---- " + (Object)ChatColor.GOLD + b.a(Language.Help).f(commandSender) + (Object)ChatColor.YELLOW + " -- " + (Object)ChatColor.GOLD + b.a(Language.Page).f(commandSender) + " " + n4 + (Object)ChatColor.RED + "/" + (Object)ChatColor.GOLD + n3 + (Object)ChatColor.YELLOW + " ----");
        commandSender.sendMessage((Object)ChatColor.GRAY + "/" + string + " " + this.cmd.a[0] + " " + (Object)ChatColor.DARK_GRAY + "[" + b.a(Language.Page).f(commandSender) + "]");
        for (n2 = 0; n2 <= 7 - n5; ++n2) {
            commandSender.sendMessage("");
        }
        for (n2 = 0; n2 < n5; ++n2) {
            CommandHandler.Command command = list.get((n4 - 1) * 7 + n2);
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + command.a[0] + " " + (Object)ChatColor.AQUA + command.usage);
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        ArrayList<String> arrayList = new ArrayList<String>();
        int n2 = 1;
        while ((double)n2 <= Math.ceil((double)this.a(commandSender).size() / 7.0)) {
            arrayList.add("" + n2);
            ++n2;
        }
        return arrayList;
    }

    private List<CommandHandler.Command> a(CommandSender commandSender) {
        ArrayList<CommandHandler.Command> arrayList = new ArrayList<CommandHandler.Command>(this.cmd.b.getCommands().size());
        for (CommandHandler.Command command : this.cmd.b.getCommands()) {
            if (!command.isVisible() || !s.hasPermission(commandSender, command.a())) continue;
            arrayList.add(command);
        }
        return arrayList;
    }
}

