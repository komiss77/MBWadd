/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class t
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length <= 1) {
            t.a((CommandSender)player, player.getUniqueId(), s.f(player));
        } else if (!ConfigValue.sql_enabled) {
            Player player22;
            for (Player player22 : Bukkit.getServer().getOnlinePlayers()) {
                if (!player22.getName().equalsIgnoreCase(arrstring[1])) continue;
                t.a((CommandSender)player, player22.getUniqueId(), player22.getName());
                return;
            }
            player22 = Bukkit.getOfflinePlayer((String)arrstring[1]);
            if (player22 != null) {
                t.a((CommandSender)player, player22.getUniqueId(), player22.getName());
                return;
            }
            s.a(commandSender, b.a(Language.NotFound_Player).a("player", arrstring[1]));
        } else {
            t.a((CommandSender)player, null, arrstring[1]);
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.z();
        }
        if (arrstring.length == 1) {
            return s.a(s.z(), arrstring[0]);
        }
        return new ArrayList<String>();
    }

    public static void a(final CommandSender commandSender, UUID uUID, final String string) {
        if (uUID == null && commandSender instanceof Player && string.equalsIgnoreCase(commandSender.getName())) {
            uUID = ((Player)commandSender).getUniqueId();
        }
        final Future<c> future = c.a(string, uUID);
        s.a(future, new Runnable(){

            @Override
            public void run() {
                try {
                    c c2 = (c)future.get();
                    if (c2 == null) {
                        s.a(commandSender, b.a(Language.NotFound_Player).a("player", string));
                        return;
                    }
                    t.a(commandSender, c2);
                }
                catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    public static void a(CommandSender commandSender, c c2) {
        de.marcely.bedwars.util.t.c(c2);
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + b.a(Language.Stats_By).a().a("player", c2.getPlayerName()).f(commandSender) + ": ");
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Rank).a().f(commandSender)) + (c2.getRank() != -1 ? Integer.valueOf(c2.getRank()) : b.a(Language.Ranking_Unranked).f(commandSender)));
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Won).a().f(commandSender)) + c2.getWins());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Lost).a().f(commandSender)) + c2.getLoses());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_RoundsPlayed).a().f(commandSender)) + c2.getRoundsPlayed());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_WL).a().f(commandSender)) + c2.a());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Kills).a().f(commandSender)) + c2.getKills());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Deaths).a().f(commandSender)) + c2.getDeaths());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_KD).a().f(commandSender)) + c2.b());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_BedsDestroyed).a().f(commandSender)) + c2.getBedsDestroyed());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_PlayTime).a().f(commandSender)) + s.a(c2.getPlayTime()));
    }

}

