/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.BedwarsAddon;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class a
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        de.marcely.bedwars.a a2 = MBedwars.a;
        if (arrstring.length >= 3) {
            if (arrstring[1].equalsIgnoreCase("setenabled")) {
                Plugin plugin = a2.getAddonByName(arrstring[2]);
                if (plugin != null) {
                    a2.setAddonState(plugin, true);
                    s.a(commandSender, b.a(Language.Addon_Enabled).a("name", plugin.getName()));
                } else {
                    s.a(commandSender, b.a(Language.Addon_Unkown).a("id", arrstring[2]));
                }
            } else if (arrstring[1].equalsIgnoreCase("setdisabled")) {
                Plugin plugin = a2.getAddonByName(arrstring[2]);
                if (plugin != null) {
                    a2.setAddonState(plugin, false);
                    s.a(commandSender, b.a(Language.Addon_Disabled).a("name", plugin.getName()));
                } else {
                    s.a(commandSender, b.a(Language.Addon_Unkown).a("id", arrstring[2]));
                }
            } else if (arrstring[1].equalsIgnoreCase("command")) {
                Plugin plugin = a2.getAddonByName(arrstring[2]);
                if (plugin != null) {
                    BedwarsAddon bedwarsAddon = MBedwars.b.get((Object)plugin);
                    if (arrstring.length == 3) {
                        commandSender.sendMessage((Object)ChatColor.GRAY + "==== " + b.a(Language.Addon_Command_List).a("addon", plugin.getName()).f(commandSender) + (Object)ChatColor.GRAY + " ====");
                        commandSender.sendMessage("");
                        if (bedwarsAddon != null && bedwarsAddon.getCommands().size() >= 1) {
                            for (BedwarsAddon.BedwarsAddonCommand bedwarsAddonCommand : bedwarsAddon.getCommands()) {
                                commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0] + " " + arrstring[1] + " " + arrstring[2] + " " + bedwarsAddonCommand.getCommand() + " " + bedwarsAddonCommand.getUsage());
                            }
                        } else {
                            s.a(commandSender, b.a(Language.Addon_Command_None));
                        }
                    } else if (bedwarsAddon != null) {
                        BedwarsAddon.BedwarsAddonCommand bedwarsAddonCommand = bedwarsAddon.getCommand(arrstring[3]);
                        if (bedwarsAddonCommand != null) {
                            bedwarsAddonCommand.onWrite(commandSender, Arrays.copyOfRange(arrstring, 4, arrstring.length), "/" + string + " " + arrstring[0] + " " + arrstring[1] + " " + arrstring[2] + " " + bedwarsAddonCommand.getCommand() + " " + bedwarsAddonCommand.getUsage());
                        } else {
                            s.a(commandSender, b.a(Language.Addon_Command_Unkown).a("command", arrstring[3]));
                        }
                    } else {
                        s.a(commandSender, b.a(Language.Addon_Command_None));
                    }
                } else {
                    s.a(commandSender, b.a(Language.Addon_Unkown).a("id", arrstring[2]));
                }
            } else {
                s.a(commandSender, b.a(Language.Unkown_Argument).a("arg", arrstring[1]));
            }
        } else if (arrstring.length == 2) {
            if (arrstring[1].equalsIgnoreCase("research")) {
                s.a(commandSender, b.a(Language.Addon_Research).a("number", "" + a2.research()));
            } else {
                s.a(commandSender, b.a(Language.Unkown_Argument).a("arg", arrstring[1]));
            }
        } else {
            commandSender.sendMessage("");
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + b.a(Language.Addons_Enabled).f(commandSender));
            if (a2.getEnabledAddons().size() > 0) {
                for (Plugin plugin : a2.getEnabledAddons()) {
                    commandSender.sendMessage(" " + (Object)ChatColor.GOLD + a2.getAddonID(plugin) + " " + (Object)ChatColor.YELLOW + plugin.getName());
                }
            } else {
                commandSender.sendMessage((Object)ChatColor.RED + " " + b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + b.a(Language.Addons_Disabled).f(commandSender));
            if (a2.getDisabledAddons().size() > 0) {
                for (Plugin plugin : a2.getDisabledAddons()) {
                    commandSender.sendMessage(" " + (Object)ChatColor.GOLD + a2.getAddonID(plugin) + " " + (Object)ChatColor.YELLOW + plugin.getName());
                }
            } else {
                commandSender.sendMessage((Object)ChatColor.RED + " " + b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + b.a(Language.Commands_List).f(commandSender));
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " setenabled " + (Object)ChatColor.AQUA + "<addon id>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " setdisabled " + (Object)ChatColor.AQUA + "<addon id>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " command " + (Object)ChatColor.AQUA + "<addon id> [command] [args...]");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " research");
            commandSender.sendMessage("");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        BedwarsAddon bedwarsAddon;
        Plugin plugin;
        de.marcely.bedwars.a a2 = MBedwars.a;
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (arrstring.length == 2 && (string2.equalsIgnoreCase("setenabled") || string2.equalsIgnoreCase("setdisabled") || string2.equalsIgnoreCase("command"))) {
            return Arrays.asList((String[])a2.getEnabledAddons().stream().map(Plugin::getName).toArray(n2 -> new String[n2]));
        }
        if (arrstring.length == 3 && string2.equalsIgnoreCase("command") && (plugin = a2.getAddonByName(arrstring[1])) != null && (bedwarsAddon = MBedwars.b.get((Object)plugin)) != null) {
            ArrayList<String> arrayList = new ArrayList<String>();
            for (BedwarsAddon.BedwarsAddonCommand bedwarsAddonCommand : bedwarsAddon.getCommands()) {
                arrayList.add(bedwarsAddonCommand.getCommand());
            }
            return s.a(arrayList, arrstring[2]);
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("setenabled", "setdisabled", "command", "research");
    }
}

