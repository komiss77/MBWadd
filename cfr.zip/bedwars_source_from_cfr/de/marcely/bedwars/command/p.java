/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class p
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;
    private List<CommandSender> g = new ArrayList<CommandSender>();

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(final CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (!this.g.contains((Object)commandSender)) {
            s.a(commandSender, b.a(Language.RecalculateStats_Sure1));
            s.a(commandSender, b.a(Language.RecalculateStats_Sure2));
            s.a(commandSender, b.a(Language.RecalculateStats_Sure3));
            this.g.add(commandSender);
            new BukkitRunnable(){

                public void run() {
                    p.this.g.remove((Object)commandSender);
                }
            }.runTaskLater((Plugin)MBedwars.a, 200L);
        } else {
            this.g.remove((Object)commandSender);
            final long l2 = System.currentTimeMillis();
            s.c(new Runnable(){

                @Override
                public void run() {
                    s.a(commandSender, b.a(Language.RecalculateStats_Done).a("time", "" + (double)(System.currentTimeMillis() - l2) / 1000.0));
                }
            });
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }

}

