/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class b
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length >= 2) {
            Block block = de.marcely.bedwars.util.b.getLookingBlock(player, 10);
            if (block != null && block.getType() != null && a.b(block)) {
                Arena arena = s.b(arrstring[1]);
                if (arena != null) {
                    HashMap<XYZW, String> hashMap = new HashMap<XYZW, String>();
                    hashMap.putAll(s.S);
                    for (Map.Entry entry : hashMap.entrySet()) {
                        XYZW xYZW = (XYZW)entry.getKey();
                        if (xYZW.getWorld() == null && !de.marcely.bedwars.config.b.o() && !s.g(xYZW.getWorldString())) {
                            s.S.remove(xYZW);
                        }
                        if (!block.getWorld().equals((Object)xYZW.getWorld()) || xYZW.getX() != (double)block.getX() || xYZW.getY() != (double)block.getY() || xYZW.getZ() != (double)block.getZ()) continue;
                        s.S.remove(xYZW);
                    }
                    s.S.put(XYZW.valueOf(block.getLocation()), arena.getName());
                    s.a(block.getLocation(), arena);
                    s.ai();
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Added_Sign));
                } else {
                    Language.sendNotFoundArenaMessage((CommandSender)player, arrstring[1]);
                }
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotLooking_AtSign));
            }
        } else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

