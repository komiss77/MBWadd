/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.game.stats.d;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class k
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (Version.a().getVersionNumber() >= 8) {
            Player player = (Player)commandSender;
            if (arrstring.length >= 2) {
                if (arrstring[1].equalsIgnoreCase("add")) {
                    s.ae.add(new XYZW(player.getLocation()));
                    s.ah();
                    d.e(player.getLocation());
                    s.a((CommandSender)player, b.a(Language.Hologram_Add).a("id", "" + (s.ae.size() - 1)));
                } else if (arrstring[1].equalsIgnoreCase("remove")) {
                    if (arrstring.length >= 3) {
                        if (s.isInteger(arrstring[2])) {
                            int n2 = Integer.valueOf(arrstring[2]);
                            if (n2 >= 0 && n2 < s.ae.size()) {
                                d.f(s.ae.get(n2).toBukkit());
                                s.ae.remove(n2);
                                s.ah();
                                s.a((CommandSender)player, b.a(Language.Hologram_Remove).a("id", "" + n2));
                            } else {
                                s.a((CommandSender)player, b.a(Language.Hologram_Remove_IDNotExists).a("id", arrstring[2]));
                            }
                        } else {
                            s.a((CommandSender)player, b.a(Language.Number_NotOne).a("number", arrstring[2]));
                        }
                    } else {
                        s.a((CommandSender)player, b.a(Language.Usage).a("usage", "/" + string + " hologram remove <id>"));
                    }
                } else {
                    s.a((CommandSender)player, b.a(Language.Unkown_Argument).a("arg", arrstring[1]));
                }
            } else {
                player.sendMessage("");
                player.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + b.a(Language.Hologram_List).f(commandSender));
                int n3 = 0;
                if (s.ae.size() >= 1) {
                    for (XYZW xYZW : s.ae) {
                        player.sendMessage(" " + (Object)ChatColor.GOLD + n3 + (Object)ChatColor.YELLOW + " W:" + xYZW.getWorld().getName() + " X:" + (int)xYZW.getX() + " Y:" + (int)xYZW.getY() + " Z:" + (int)xYZW.getZ());
                        ++n3;
                    }
                } else {
                    player.sendMessage((Object)ChatColor.RED + " " + b.a(Language.None).f(commandSender));
                }
                player.sendMessage("");
                player.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + b.a(Language.Commands_List).f(commandSender));
                player.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " add");
                player.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " remove " + (Object)ChatColor.AQUA + "<id>");
                player.sendMessage("");
            }
        } else {
            s.a(commandSender, b.a(Language.Not_Supported).a("version", "8"));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (string2.equalsIgnoreCase("remove") && arrstring.length == 2) {
            ArrayList<String> arrayList = new ArrayList<String>();
            for (int i2 = 0; i2 < s.ae.size(); ++i2) {
                arrayList.add("" + i2);
            }
            return s.a(arrayList, arrstring[1]);
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("add", "remove");
    }
}

