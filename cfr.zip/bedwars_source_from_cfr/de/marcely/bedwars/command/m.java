/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class m
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length >= 2) {
            if (s.a(player) != null) {
                s.a((CommandSender)player, b.a(Language.AlreadyInside_Arena));
                return;
            }
            Arena arena = s.b(String.join((CharSequence)" ", Arrays.copyOfRange(arrstring, 1, arrstring.length)));
            if (arena != null) {
                String string3 = s.b(player, arena);
                if (string3 != null) {
                    player.sendMessage(string3);
                }
            } else {
                Language.sendNotFoundArenaMessage((CommandSender)player, arrstring[1]);
            }
        } else {
            s.a((CommandSender)player, b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

