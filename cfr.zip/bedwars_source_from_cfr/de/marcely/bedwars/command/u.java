/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.config.l;
import de.marcely.bedwars.game.IEntity;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

public class u
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (b.o()) {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Wait_AllArenasLoaded));
            return;
        }
        if (arrstring.length >= 3 && arrstring[1].equalsIgnoreCase("hubvillager")) {
            if (arrstring.length == 3) {
                Arena arena = s.b(arrstring[2]);
                if (arena != null) {
                    s.a(IEntity.a(player.getLocation(), arena));
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_LobbyVillager));
                } else {
                    Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
                }
            } else if (s.isInteger(arrstring[2]) && s.isInteger(arrstring[3])) {
                try {
                    s.a(IEntity.a(player.getLocation(), Integer.valueOf(arrstring[2]), Integer.valueOf(arrstring[3])));
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_LobbyVillager));
                }
                catch (Exception exception) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Error_Occured));
                    exception.printStackTrace();
                }
            } else if (!s.isInteger(arrstring[2])) {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", arrstring[2]));
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", arrstring[3]));
            }
        } else if (arrstring.length >= 3 && arrstring[1].equalsIgnoreCase("teamselectvillager")) {
            Team team = Team.a(commandSender, arrstring[2]);
            if (team != null) {
                s.a(IEntity.a(player.getLocation(), team));
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_TeamSelectVillager));
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", arrstring[2]));
            }
        } else if (arrstring.length >= 3 && arrstring[1].equalsIgnoreCase("ranking")) {
            if (Version.a().getVersionNumber() >= 8) {
                if (s.isInteger(arrstring[2])) {
                    int n2 = Integer.valueOf(arrstring[2]);
                    Location location = player.getLocation().clone();
                    if (n2 >= 1 && n2 <= 3) {
                        if (Version.a().getVersionNumber() >= 9) {
                            s.aj.add(player);
                        }
                        RankingStatue rankingStatue = new RankingStatue(RankingStatue.a.a(n2), location, de.marcely.bedwars.game.stats.b.a[n2 - 1]);
                        s.ad.add(rankingStatue);
                        rankingStatue.a();
                        l.save();
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawn_Ranking).a("place", arrstring[2]));
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Place).a("place", arrstring[2]));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", arrstring[2]));
                }
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Not_Supported).a("version", "8"));
            }
        } else if (arrstring.length >= 2 && arrstring[1].equalsIgnoreCase("dealer")) {
            s.a(IEntity.a(player.getLocation()));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_Dealer));
        } else if (arrstring.length >= 2 && arrstring[1].equalsIgnoreCase("upgradedealer")) {
            s.a(IEntity.b(player.getLocation()));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_UpgradeDealer));
        } else {
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender));
            for (int i2 = 0; i2 < 3; ++i2) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " hubvillager" + (Object)ChatColor.AQUA + " <teams> <players in each team>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " hubvillager" + (Object)ChatColor.AQUA + " <arena name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " teamselectvillager" + (Object)ChatColor.AQUA + " <team color>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " ranking" + (Object)ChatColor.AQUA + " <place>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " dealer");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " upgradedealer");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (arrstring.length == 2) {
            if (string2.equalsIgnoreCase("hubvillager")) {
                return s.a(s.A(), arrstring[1]);
            }
            if (string2.equalsIgnoreCase("teamselectvillager")) {
                return s.a(Team.a(commandSender, true, true), arrstring[1]);
            }
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("hubvillager", "teamselectvillager", "ranking", "dealer", "upgradedealer");
    }
}

