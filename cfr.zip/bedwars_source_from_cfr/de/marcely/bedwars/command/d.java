/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.command.CommandHandler;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class d
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;
    public de.marcely.bedwars.command.arena.CommandHandler a = new de.marcely.bedwars.command.arena.CommandHandler();

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        this.a.onCommand(commandSender, null, string, arrstring);
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return this.a.b(arrstring, string, commandSender);
    }
}

