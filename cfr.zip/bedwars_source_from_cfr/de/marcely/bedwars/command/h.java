/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Skull
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.bC;
import de.marcely.bedwars.bl;
import de.marcely.bedwars.bm;
import de.marcely.bedwars.bs;
import de.marcely.bedwars.bt;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.dZ;
import de.marcely.bedwars.ec;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.shop.Shop;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesignData;
import de.marcely.bedwars.game.shop.upgrade.UpgradeShop;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.j;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.n;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Skull;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class h
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(final CommandSender commandSender, String string, String string2, final String[] arrstring) {
        commandSender.sendMessage((Object)ChatColor.RED + "This command is ONLY for debug purposes!");
        commandSender.sendMessage((Object)ChatColor.RED + "Use it at your own risk.");
        commandSender.sendMessage((Object)ChatColor.GOLD + "============");
        Player player = (Player)commandSender;
        if (arrstring.length >= 2) {
            String string3 = arrstring[1];
            if (string3.equals("0")) {
                Shop.open((Player)commandSender, ShopDesignData.getDesignByName(arrstring[2]), ShopOpenType.DEBUG);
            } else if (string3.equals("1")) {
                Sound sound = Sound.byName(arrstring[2]);
                if (sound == null) {
                    player.sendMessage((Object)ChatColor.RED + "Unkown sound");
                } else {
                    sound.play(player);
                }
            } else if (string3.equals("2")) {
                bs bs2 = null;
                List<Arena> list = null;
                try {
                    bs2 = new bt().a(String.join((CharSequence)" ", Arrays.copyOfRange(arrstring, 2, arrstring.length)));
                }
                catch (bl | bm iOException) {
                    player.sendMessage((Object)ChatColor.RED + "A syntax error occured: " + (Object)ChatColor.GOLD + iOException.getMessage());
                    return;
                }
                if (bs2.a() != null) {
                    list = new ArrayList<Arena>();
                    for (de.marcely.bedwars.game.arena.Arena arena2 : s.af) {
                        if (!bs2.a().a(arena2)) continue;
                        list.add(arena2);
                    }
                } else {
                    list = BedwarsAPI.getArenas();
                }
                if (list.size() == 0) {
                    player.sendMessage((Object)ChatColor.GREEN + "Success! But no arenas were found.");
                    return;
                }
                player.sendMessage((Object)ChatColor.GREEN + "Success! Arenas: " + String.join((CharSequence)", ", (CharSequence[])list.stream().map(arena -> arena.getName()).toArray(n2 -> new String[n2])));
            } else if (string3.equals("3")) {
                commandSender.sendMessage(String.valueOf(b.o()) + " " + (b.b() != null && b.b().isAlive()));
            } else if (string3.equals("4")) {
                commandSender.sendMessage("" + s.b(arrstring[2]).B());
            } else if (string3.equals("5")) {
                s.a(player).b((Team)null);
            } else if (string3.equals("6")) {
                commandSender.sendMessage(String.valueOf(s.b((String)arrstring[2]).a.isEnabled()) + " " + ConfigValue.scoreboard_enabled);
                if (arrstring[3].equals("1")) {
                    s.b((String)arrstring[2]).a.s(player);
                } else {
                    s.b((String)arrstring[2]).a.q(player);
                }
            } else if (string3.equals("7")) {
                de.marcely.bedwars.game.arena.Arena arena3 = s.a(player);
                Team team = Team.a(commandSender, arrstring[2]);
                arena3.a(player, arena3.a().a(team).toBukkit(arena3.getWorld()), team);
            } else if (string3.equals("8")) {
                Player player2 = Bukkit.getPlayer((String)arrstring[2]);
                s.a(player2).a(KickReason.b, player2);
            } else if (string3.equals("9")) {
                bC.e(player, Team.values()[s.RAND.nextInt(Team.values().length)]);
            } else if (string3.equals("10")) {
                Location location = player.getLocation().clone();
                location.setYaw(0.0f);
                location.setPitch(0.0f);
                bC.a(location, Float.valueOf(arrstring[2]).floatValue(), Float.valueOf(arrstring[3]).floatValue(), Float.valueOf(arrstring[4]).floatValue(), Team.values()[s.RAND.nextInt(Team.values().length)]);
            } else if (string3.equals("11")) {
                AnvilGUI anvilGUI = new AnvilGUI("Cool name xD");
                anvilGUI.setTitle("The title is also working on never versions :)");
                anvilGUI.setWroteListener(new AnvilGUI.WroteListener(){

                    @Override
                    public void run(String string) {
                        commandSender.sendMessage("Your message: " + string);
                    }
                });
                anvilGUI.open(player);
            } else if (string3.equals("12")) {
                final Future<de.marcely.bedwars.game.stats.c> future = de.marcely.bedwars.game.stats.c.a(player.getName(), player.getUniqueId());
                s.a(future, new Runnable(){

                    @Override
                    public void run() {
                        try {
                            de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)future.get();
                            c2.setPlayTime(Long.valueOf(arrstring[2]));
                            c2.save();
                            System.out.println(c2.getPlayTime());
                        }
                        catch (InterruptedException | ExecutionException exception) {
                            exception.printStackTrace();
                        }
                    }
                });
            } else if (string3.equals("13")) {
                de.marcely.bedwars.game.arena.Arena arena4 = s.b(arrstring[2]);
                arena4.a(ArenaStatus.e);
                int n3 = arena4.getMinPlayers();
                arena4.setMinPlayers(0);
                arena4.D();
                arena4.setMinPlayers(n3);
            } else if (string3.equals("14")) {
                int n4 = 3;
                if (arrstring.length >= 3) {
                    if (!s.isInteger(arrstring[2])) {
                        player.sendMessage((Object)ChatColor.RED + "Argument isn't an integer");
                        return;
                    }
                    n4 = Integer.parseInt(arrstring[2]);
                }
                player.sendMessage((Object)ChatColor.GOLD + (Object)ChatColor.BOLD + "Measuring...");
                new j(n4, a2 -> {
                    int n2;
                    for (n2 = 0; n2 < 3; ++n2) {
                        player.sendMessage("");
                    }
                    player.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + " Process load: " + (Object)ChatColor.GRAY + (double)Math.round(a2.e * 100.0) / 100.0 + "%");
                    player.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + " System load: " + (Object)ChatColor.GRAY + (double)Math.round(a2.f * 100.0) / 100.0 + "%");
                    player.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + " TPS: " + (Object)ChatColor.GRAY + (double)Math.round(a2.g * 100.0) / 100.0);
                    player.sendMessage("");
                    for (Map.Entry<Thread, Double> entry : a2.P.entrySet()) {
                        Thread thread = entry.getKey();
                        if (!(thread instanceof MThread) && thread != s.a) continue;
                        String string = (Object)ChatColor.GOLD + thread.getId() + (Object)ChatColor.YELLOW + " " + thread.getState().name() + "(" + (double)Math.round(entry.getValue() * 100.0) / 100.0 + "%)";
                        string = String.valueOf(string) + MThread.getDisplayInfo(thread);
                        commandSender.sendMessage(string);
                    }
                    for (n2 = 0; n2 < 3; ++n2) {
                        player.sendMessage("");
                    }
                }).run();
            } else if (string3.equals("15")) {
                de.marcely.bedwars.game.arena.Arena arena5;
                commandSender.sendMessage("Config World: " + arena5.C + " | Actual world: " + ((arena5 = s.b(arrstring[2])).getWorld() != null ? arena5.getWorld().getName() : null) + " | Config Lobbyworld: " + arena5.D + " | Actual Lobbyworld: " + (arena5.getLobby() != null && arena5.getLobby().getWorld() != null ? arena5.getLobby().getWorld().getName() : "null"));
            } else if (string3.equals("16")) {
                final de.marcely.bedwars.holographic.c<cI> c2 = de.marcely.bedwars.holographic.c.a(cI.class, player.getLocation(), new cE());
                final cI cI2 = c2.a();
                c2.Q();
                new BukkitRunnable(){
                    int i = 0;

                    public void run() {
                        Location location;
                        location.setYaw((location = cI2.getLocation()).getYaw() < 360.0f ? location.getYaw() + 2.0f : 0.0f);
                        cI2.teleport(location);
                        cI2.setCustomName("DEBUG ENTITY | " + this.i);
                        if (s.RAND.nextInt(10) >= 9) {
                            cI2.a().a(e.a.a, new ItemStack(Material.values()[s.RAND.nextInt(Material.values().length)]));
                        }
                        cI2.T();
                        if (this.i >= 500) {
                            c2.remove();
                            this.cancel();
                        }
                        ++this.i;
                    }
                }.runTaskTimer((Plugin)MBedwars.a, 0L, 0L);
            } else if (string3.equals("17")) {
                Block block = de.marcely.bedwars.util.b.getLookingBlock(player);
                Block block2 = a.a(block);
                block2.setType(Material.WOOL);
                block2.setData((byte)s.RAND.nextInt(15));
                commandSender.sendMessage("Data of block: " + block.getData());
            } else if (string3.equals("18")) {
                UpgradeShop.open(player, null, UpgradeDesignData.getDesignByID(Integer.valueOf(arrstring[2])));
            } else if (string3.equals("19")) {
                Block block = de.marcely.bedwars.util.b.getLookingBlock(player);
                ItemStack itemStack = player.getItemInHand();
                String string4 = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2RjZDdkZjUyNjQ1YzY4Y2RhZDg1NDhlNjFiM2Y3NjU5NjQwNzcyMjZiYTg3MmI5ZDJiZDQ1YzQzOWQifX19";
                if (arrstring[2].equals("1")) {
                    Version.a().a((Skull)block.getState(), "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2RjZDdkZjUyNjQ1YzY4Y2RhZDg1NDhlNjFiM2Y3NjU5NjQwNzcyMjZiYTg3MmI5ZDJiZDQ1YzQzOWQifX19");
                } else if (arrstring[2].equals("2")) {
                    commandSender.sendMessage(Version.a().a((Skull)block.getState()));
                } else if (arrstring[2].equals("3")) {
                    SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
                    Version.a().a(skullMeta, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2RjZDdkZjUyNjQ1YzY4Y2RhZDg1NDhlNjFiM2Y3NjU5NjQwNzcyMjZiYTg3MmI5ZDJiZDQ1YzQzOWQifX19");
                    itemStack.setItemMeta((ItemMeta)skullMeta);
                } else if (arrstring[2].equals("4")) {
                    commandSender.sendMessage(Version.a().a((SkullMeta)itemStack.getItemMeta()));
                }
            } else if (string3.equals("20")) {
                Achievement achievement = Achievement.a(arrstring[2]);
                if (achievement == null) {
                    player.sendMessage((Object)ChatColor.RED + "Unkown achievement :/");
                    return;
                }
                s.a(player, achievement, true);
            } else if (string3.equals("21")) {
                s.a(player).a().reset(true);
            } else if (string3.equals("22")) {
                commandSender.sendMessage("" + s.Z.containsKey((Object)player));
                dY dY2 = s.Z.get((Object)player);
                if (dY2 != null && dY2.a() instanceof ec) {
                    commandSender.sendMessage("" + ((ec)dY2.a()).isInjected());
                }
            } else if (string3.equals("23")) {
                Block block = de.marcely.bedwars.util.b.getLookingBlock(player);
                player.sendMessage((Object)block.getType() + ":" + block.getData());
            } else if (string3.equals("24")) {
                player.sendMessage(String.valueOf(ConfigValue.tab_removenonplayers) + " | " + ConfigValue.player_color);
            } else if (string3.equals("25")) {
                s.b.U();
            } else if (string3.equals("26")) {
                int n5 = 0;
                for (Map.Entry<String, Long> entry : s.c(s.a.getData()).entrySet()) {
                    if (entry.getValue() == 0L) continue;
                    ++n5;
                    ChatColor chatColor = ChatColor.WHITE;
                    if (entry.getValue() >= 20L) {
                        chatColor = ChatColor.DARK_RED;
                    } else if (entry.getValue() >= 10L) {
                        chatColor = ChatColor.RED;
                    } else if (entry.getValue() >= 2L) {
                        chatColor = ChatColor.YELLOW;
                    }
                    player.sendMessage((Object)chatColor + entry.getKey() + " - " + entry.getValue() + "ms");
                }
                if (n5 == 0) {
                    player.sendMessage((Object)ChatColor.RED + "No lag has been logged yet. Yay!");
                }
            } else if (string3.equals("27")) {
                ItemStack itemStack = i.b(arrstring[2]);
                if (itemStack == null) {
                    player.sendMessage("invalid");
                } else {
                    player.getInventory().addItem(new ItemStack[]{itemStack});
                }
            } else if (string3.equals("28")) {
                try {
                    String string5 = arrstring[2];
                    Field field = ConfigValue.class.getField(string5.replace("-", "_"));
                    if (!Modifier.isStatic(field.getModifiers())) {
                        player.sendMessage((Object)ChatColor.RED + "Config does not exist");
                        return;
                    }
                    Object object = field.get(null);
                    player.sendMessage("Value: " + object.toString());
                }
                catch (NoSuchFieldException noSuchFieldException) {
                    player.sendMessage((Object)ChatColor.RED + "Config does not exist");
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        } else {
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 0 <id> = Open Shop with ID");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 1 <name> = Play the sound");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 2 <arena picker> = Test arena picker");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 3 = Returns if ArenaData is loading");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 4 <arena> = Returns if arena is regenerating");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 5 = Ends your current arena");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 6 <arena> <1/2> = Changes your scoreboard to the arena one");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 7 <team> = Fake bed break");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 8 <player> = Kick the player");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 9 = Spawns a parachute");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 10 <yaw> <pitch> <roll> = Spawn a parachute part");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 11 = Open a test anvil gui");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 12 <number in milis> = Change your playtime to the number");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 13 <arena> = Force start an arena");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 14 [calc time (default = 3)] = Returns system usage");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 15 <arena name> = Returns world info of arena");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 16 = Spawns a holographic armorstand at your location");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 17 = Changes the block behind the sign");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 18 <id> = Open Upgrade Shop with ID");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 19 <1/2> = Set/Get a skull texture of a block");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 19 <3/4> = Set/Get a skull texture of a block");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 20 <achievement> = (Forcefully) gives you this achievement");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 21 = Spawn every bed in your arena");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 22 = Returns if you are injected to netty");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 23 = Returns the data of the look at which you are looking at");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 24 = Returns if config is enabled: tab-removenonplayers | player-color");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 25 = Remove all holographic watchers and by that cause them to resend");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 26 = Show timings");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 27 <item> = Parse&get item");
            commandSender.sendMessage((Object)ChatColor.YELLOW + "/" + string + " debug 28 <name> = Get value of a config of config.cm2");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }

}

