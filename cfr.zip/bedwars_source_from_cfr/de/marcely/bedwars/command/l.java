/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.e;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class l
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        commandSender.sendMessage("");
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "- " + (Object)ChatColor.AQUA + b.a(Language.Info_MadeBy).f(commandSender) + ": Marcely1199");
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "- " + (Object)ChatColor.AQUA + b.a(Language.Info_Website).f(commandSender) + ": http://Marcely.de/");
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "- " + (Object)ChatColor.AQUA + b.a(Language.Info_Version).f(commandSender) + ": " + MBedwars.getVersion());
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "- " + (Object)ChatColor.AQUA + b.a(Language.Info_NewestVersion).f(commandSender) + ": " + MBedwars.a.c());
        commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "--------------------");
        commandSender.sendMessage("");
        commandSender.sendMessage((Object)ChatColor.YELLOW + "NOTE: " + (Object)ChatColor.GRAY + "First of all thanks for using this plugin. It took me multiple thousands of hours to create and modify this plugin to its best. If you didn't bought that yet, please take the time as I did and give me the money to pay my server-costs for one month.");
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

