/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.command.CommandSender;

public class l
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 3) {
            Arena arena = s.b(String.join((CharSequence)" ", Arrays.copyOfRange(arrstring, 2, arrstring.length)));
            if (arena != null) {
                if (arena.a().J()) {
                    if (!arena.E) {
                        if (arena.B()) {
                            s.a(commandSender, b.a(Language.Reseting_Start_Failed_AlreadyRunning).a("arena", arena.getName()));
                            return;
                        }
                        if (arena.b().H()) {
                            arena.kickAllPlayers();
                        }
                        if (arena.b(commandSender)) {
                            s.a(commandSender, b.a(Language.Reseting_Now).a("arena", arena.getName()));
                        } else {
                            s.a(commandSender, b.a(Language.Reseting_Start_Failed).a("arena", arena.getName()));
                        }
                    } else {
                        s.a(commandSender, b.a(Language.Regeneration_Fail_SavingBlocks).a("arena", arena.getName()));
                    }
                } else {
                    s.a(commandSender, b.a(Language.ArenaType_NotSupported).a("type", arena.a().name()).a("name", arena.getName()));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        } else {
            s.a(commandSender, b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

