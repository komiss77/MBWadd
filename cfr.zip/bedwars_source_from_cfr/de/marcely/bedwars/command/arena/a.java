/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class a
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 3) {
            String string3 = arrstring[2].toLowerCase();
            if (string3.equals("info") && arrstring.length >= 4) {
                Arena arena = s.b(arrstring[3]);
                if (arena != null) {
                    List<Team> list = this.a(arena);
                    Object[] arrobject = new String[list.size()];
                    for (int i2 = 0; i2 < list.size(); ++i2) {
                        arrobject[i2] = list.get(i2).a(commandSender, true);
                    }
                    List<Team> list2 = this.b(arena);
                    Object[] arrobject2 = new String[list2.size()];
                    for (int i3 = 0; i3 < list2.size(); ++i3) {
                        arrobject2[i3] = list2.get(i3).a(commandSender, true);
                    }
                    commandSender.sendMessage((Object)ChatColor.GRAY + "======= " + (Object)ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Cages_Info_Title).f(commandSender) + (Object)ChatColor.GRAY + " =======");
                    commandSender.sendMessage((Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_Arena).f(commandSender) + ": " + (Object)ChatColor.AQUA + arena.getName());
                    commandSender.sendMessage((Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_IsEnabled).f(commandSender) + ": " + (Object)ChatColor.AQUA + arena.a().isEnabled());
                    commandSender.sendMessage((Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_Arena).f(commandSender) + ": " + (Object)ChatColor.AQUA + arena.getName());
                    commandSender.sendMessage((Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_TeamsLeft).f(commandSender) + ": " + (Object)ChatColor.RED + Arrays.toString(arrobject2));
                    commandSender.sendMessage((Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_TeamsSet).f(commandSender) + ": " + (Object)ChatColor.GREEN + Arrays.toString(arrobject));
                } else {
                    Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
                }
            } else if (string3.equals("setenabled") && arrstring.length >= 5) {
                Arena arena = s.b(arrstring[3]);
                if (arena != null) {
                    if (s.isBoolean(arrstring[4])) {
                        boolean bl2 = Boolean.valueOf(arrstring[4]);
                        arena.a().setEnabled(bl2);
                        b.b(arena);
                        s.a(commandSender, bl2 ? de.marcely.bedwars.message.b.a(Language.Cages_Enable) : de.marcely.bedwars.message.b.a(Language.Cages_Disable).a("arena", arena.getName()));
                        if (bl2 && this.b(arena).size() >= 1) {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Cages_Warning_Missing));
                        }
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                    }
                } else {
                    Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
                }
            } else if (string3.equals("set") && arrstring.length >= 5) {
                if (!(commandSender instanceof Player)) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                    return;
                }
                Arena arena = s.b(arrstring[3]);
                if (arena != null) {
                    Team team = Team.a(commandSender, arrstring[4]);
                    if (team != null) {
                        arena.a().c().put(team, XYZYP.valueOf(((Player)commandSender).getLocation()));
                        b.b(arena);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Cages_Set).a("arena", arena.getName()).a("team", team.a(commandSender, true)));
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", arrstring[4]));
                    }
                } else {
                    Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
                }
            } else {
                this.a(commandSender, string, arrstring);
            }
        } else {
            this.a(commandSender, string, arrstring);
        }
    }

    private List<Team> a(Arena arena) {
        ArrayList<Team> arrayList = new ArrayList<Team>(arena.a().c().keySet());
        for (Team team : Team.values()) {
            if (arena.a().r().contains((Object)team)) continue;
            arrayList.remove((Object)team);
        }
        return arrayList;
    }

    private List<Team> b(Arena arena) {
        ArrayList<Team> arrayList = new ArrayList<Team>();
        for (Team team : arena.a().r()) {
            arrayList.add(team);
        }
        arrayList.removeAll(this.a(arena));
        return arrayList;
    }

    private void a(CommandSender commandSender, String string, String[] arrstring) {
        commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender));
        for (int i2 = 0; i2 < 6; ++i2) {
            commandSender.sendMessage("");
        }
        String string2 = (Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " ";
        commandSender.sendMessage(String.valueOf(string2) + "info " + (Object)ChatColor.AQUA + "<arena name>");
        commandSender.sendMessage(String.valueOf(string2) + "setenabled " + (Object)ChatColor.AQUA + "<arena name> <true/false>");
        commandSender.sendMessage(String.valueOf(string2) + "set " + (Object)ChatColor.AQUA + "<arena name> <team color>");
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return null;
    }
}

