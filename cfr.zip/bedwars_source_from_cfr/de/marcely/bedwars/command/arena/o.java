/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.event.Event
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.event.EnableArenaEvent;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.CrashMessage;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Event;

public class o
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 4) {
            Arena arena = s.b(arrstring[2]);
            if (arena != null) {
                if (s.isBoolean(arrstring[3])) {
                    boolean bl2 = Boolean.valueOf(arrstring[3]);
                    if (bl2) {
                        List<CrashMessage> list = arena.getProblems();
                        EnableArenaEvent enableArenaEvent = new EnableArenaEvent(arena, list);
                        Bukkit.getPluginManager().callEvent((Event)enableArenaEvent);
                        list = enableArenaEvent.getCrashMessages();
                        if (list.size() == 0) {
                            arena.a(ArenaStatus.e);
                            b.b(arena);
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Enabled_Arena).a("arena", arena.getName()));
                        } else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.FixProblemsBeforeEnabled));
                            for (CrashMessage crashMessage : list) {
                                if (crashMessage.getInformation() == null) {
                                    commandSender.sendMessage((Object)ChatColor.GRAY + "- " + (Object)ChatColor.RED + crashMessage.getMessage());
                                    continue;
                                }
                                commandSender.sendMessage((Object)ChatColor.GRAY + "- " + (Object)ChatColor.RED + crashMessage.getMessage() + (Object)ChatColor.DARK_RED + " (" + crashMessage.getInformation() + ")");
                            }
                        }
                    } else {
                        arena.a(KickReason.c);
                        arena.a(ArenaStatus.d);
                        b.b(arena);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Disabled_Arena).a("arena", arena.getName()));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        } else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        if (arrstring.length == 2) {
            return s.a(Arrays.asList("true", "false"), arrstring[1]);
        }
        return new ArrayList<String>();
    }
}

