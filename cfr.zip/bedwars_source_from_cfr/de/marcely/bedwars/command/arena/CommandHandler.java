/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.APIConfiguration;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.api.event.CommandArenaFireEvent;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.command.arena.b;
import de.marcely.bedwars.command.arena.c;
import de.marcely.bedwars.command.arena.d;
import de.marcely.bedwars.command.arena.e;
import de.marcely.bedwars.command.arena.f;
import de.marcely.bedwars.command.arena.g;
import de.marcely.bedwars.command.arena.h;
import de.marcely.bedwars.command.arena.i;
import de.marcely.bedwars.command.arena.j;
import de.marcely.bedwars.command.arena.k;
import de.marcely.bedwars.command.arena.l;
import de.marcely.bedwars.command.arena.m;
import de.marcely.bedwars.command.arena.n;
import de.marcely.bedwars.command.arena.o;
import de.marcely.bedwars.command.arena.p;
import de.marcely.bedwars.command.arena.q;
import de.marcely.bedwars.command.arena.r;
import de.marcely.bedwars.command.arena.s;
import de.marcely.bedwars.command.arena.t;
import de.marcely.bedwars.command.arena.u;
import de.marcely.bedwars.command.arena.v;
import de.marcely.bedwars.library.worldedit.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class CommandHandler
implements CommandExecutor {
    private List<Command> f = new ArrayList<Command>();

    public CommandHandler() {
        this.refresh();
    }

    public void refresh() {
        this.f.clear();
        this.f.add(new Command(this, (Command.a)new h(), false, false, "", "help"));
        this.f.add(new Command(this, (Command.a)new k(), false, "", "list", "arenas", "all"));
        this.f.add(new Command(this, (Command.a)new f(), true, "[arena name]", "gui", "easy", "createeasy", "setupeasy", "easily", "fast", "quick"));
        this.f.add(new Command(this, (Command.a)new t(), true, "", "setupitem", "item", "guiitem", "quickitem", "fastitem", "createitem"));
        this.f.add(new Command(this, (Command.a)new d(), true, "<arena name> [made by...]", "create", "createarena", "createnewarena", "newarena"));
        if (de.marcely.bedwars.util.s.b == null || !de.marcely.bedwars.util.s.b.get(a.class).isInjected()) {
            this.f.add(new Command(this, (Command.a)new g(), true, "", "getpositionaxe", "getaxe", "positionaxe", "axe"));
        }
        this.f.add(new Command(this, (Command.a)new m(), false, "<arena name>", "remove", "rm", "delete", "del", "removearena", "delarena", "deletearena"));
        this.f.add(new Command(this, (Command.a)new c(), true, "<arena name>", "configure", "conf", "configurate", "setup"));
        if (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
            this.f.add(new Command(this, (Command.a)new u(), true, "[args...]", "team"));
        }
        if (BedwarsAPI.getOpenAPIConfiguration().itemspawnersEnabled) {
            this.f.add(new Command(this, (Command.a)new j(), true, "[args...]", "itemspawner", "is"));
        }
        this.f.add(new Command(this, (Command.a)new p(), true, "<arena name>", "setlobby"));
        this.f.add(new Command(this, (Command.a)new e(), false, "[args...]", "flag", "modify"));
        this.f.add(new Command(this, (Command.a)new o(), false, "<arena name> <bool (true/false)>", "setenabled", "enabled", "setenable", "enable"));
        this.f.add(new Command(this, (Command.a)new l(), false, "<arena name>", "regenerate", "regen", "updateblocks"));
        this.f.add(new Command(this, (Command.a)new n(), false, "<arena name>", "saveblocks", "updateblocks"));
        this.f.add(new Command(this, (Command.a)new q(), true, "<arena name>", "setposition", "updatelocation", "changeposition", "changelocation", "setcorner", "setcorners"));
        this.f.add(new Command(this, (Command.a)new s(), true, "<arena name>", "setworld", "updateworld", "changeworld"));
        this.f.add(new Command(this, (Command.a)new r(), true, "<arena name>", "setspectatorspawn", "setspectatorpoint", "setspectator"));
        this.f.add(new Command(this, (Command.a)new v(), true, "<arena name>", "teleport", "tp"));
        this.f.add(new Command(this, (Command.a)new b(), false, "<arena name> <new arena name>", "clone", "copy", "duplicate"));
        this.f.add(new Command(this, (Command.a)new i(), false, "<arena name>", "info", "information", "informations"));
    }

    public boolean onCommand(CommandSender commandSender, org.bukkit.command.Command command, String string, String[] arrstring) {
        if (arrstring.length >= 2) {
            Command command2 = this.a(arrstring[1]);
            if (command2 != null) {
                if (!command2.f || command2.f && commandSender instanceof Player) {
                    this.a(command2, commandSender, string, "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " " + command2.usage, arrstring);
                } else {
                    de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                }
            } else if (!de.marcely.bedwars.util.s.isInteger(arrstring[1])) {
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", arrstring[1]));
            } else {
                this.a(this.f.get(0), commandSender, string, null, arrstring);
            }
        } else {
            this.a(this.f.get(0), commandSender, string, null, arrstring);
        }
        return true;
    }

    private void a(Command command, CommandSender commandSender, String string, String string2, String ... arrstring) {
        CommandArenaFireEvent commandArenaFireEvent = new CommandArenaFireEvent(commandSender, command);
        Bukkit.getPluginManager().callEvent((Event)commandArenaFireEvent);
        if (!commandArenaFireEvent.isCancelled()) {
            command.a.a(commandSender, string, string2, arrstring);
        }
    }

    public List<Command> getCommands() {
        return this.f;
    }

    public List<String> c() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Command command : this.f) {
            arrayList.add(command.a()[0]);
        }
        return arrayList;
    }

    public Command a(String string) {
        String string2 = string.toLowerCase();
        for (Command command : this.f) {
            for (String string3 : command.a) {
                if (!string2.equals(string3)) continue;
                return command;
            }
        }
        return null;
    }

    public List<String> b(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.c();
        }
        if (arrstring.length == 1) {
            return de.marcely.bedwars.util.s.a(this.c(), arrstring[0]);
        }
        Command command = this.a(arrstring[0]);
        if (command != null) {
            return command.a().a(Arrays.copyOfRange(arrstring, 1, arrstring.length), string, commandSender);
        }
        return new ArrayList<String>();
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class Command {
        protected CommandHandler b;
        protected a a;
        protected boolean f;
        protected boolean visible;
        protected String usage;
        protected String[] a;

        public Command(CommandHandler commandHandler, a a2, boolean bl2, String string, String ... arrstring) {
            this(commandHandler, a2, bl2, true, string, arrstring);
        }

        public Command(CommandHandler commandHandler, a a2, boolean bl2, boolean bl3, String string, String ... arrstring) {
            this.b = commandHandler;
            this.a = a2;
            this.f = bl2;
            this.visible = bl3;
            this.usage = string;
            this.a = arrstring;
            a2.a(this);
        }

        public CommandHandler a() {
            return this.b;
        }

        public a a() {
            return this.a;
        }

        public boolean n() {
            return this.f;
        }

        public boolean isVisible() {
            return this.f;
        }

        public String getUsage() {
            return this.usage;
        }

        public String[] a() {
            return this.a;
        }

        public static interface a {
            public void a(Command var1);

            public void a(CommandSender var1, String var2, String var3, String[] var4);

            @Nullable
            public List<String> a(String[] var1, String var2, CommandSender var3);
        }

    }

}

