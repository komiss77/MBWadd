/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class d
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(final CommandSender commandSender, String string, String string2, String[] arrstring) {
        final Player player = (Player)commandSender;
        if (arrstring.length >= 4) {
            String string3;
            RegenerationType regenerationType = RegenerationType.c;
            boolean bl2 = false;
            if (arrstring[arrstring.length - 1].startsWith("-")) {
                string3 = arrstring[arrstring.length - 1];
                if (string3.startsWith("-")) {
                    string3 = string3.substring(1);
                    for (RegenerationType regenerationType2 : RegenerationType.values()) {
                        if (!regenerationType2.name().equalsIgnoreCase(string3)) continue;
                        regenerationType = regenerationType2;
                        bl2 = true;
                        break;
                    }
                }
                if (arrstring.length == 4 && regenerationType != RegenerationType.e) {
                    this.a(commandSender, string, string2, new String[0]);
                    return;
                }
            }
            if (regenerationType == RegenerationType.d && s.a(player.getWorld())) {
                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.CreateArena_Fail_MainWorld));
                return;
            }
            string3 = "";
            int n2 = 0;
            int n3 = !bl2 ? arrstring.length : arrstring.length - 1;
            for (String string4 : arrstring) {
                if (n2 >= 3 && n2 < n3) {
                    string3 = n2 == n3 - 1 ? String.valueOf(string3) + string4 : String.valueOf(string3) + string4 + ",";
                }
                ++n2;
            }
            if (regenerationType == RegenerationType.c) {
                final de.marcely.bedwars.library.worldedit.b b2 = s.b.get(de.marcely.bedwars.library.worldedit.a.class).a(player);
                if (b2.S()) {
                    Arena arena = s.b(arrstring[2]);
                    if (arena == null) {
                        d.a(player, arrstring[2], string3, regenerationType, new a(){

                            @Override
                            public void f() {
                                Arena arena = new Arena();
                                arena.setName(this.o);
                                arena.setWorld(player.getWorld());
                                arena.a(XYZ.valueOf(b2.b()));
                                arena.b(XYZ.valueOf(b2.c()));
                                arena.a(RegenerationType.c);
                                arena.setTeamPlayers(this.h);
                                arena.a().b(this.i);
                                arena.v(this.p);
                                s.a(arena, player);
                                b.b(arena);
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                                arena.a(commandSender, false);
                            }
                        });
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", arena.getName()));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Missing_WorldeditPoints));
                }
            } else if (regenerationType == RegenerationType.d) {
                Arena arena = s.b(arrstring[2]);
                if (arena == null) {
                    d.a(player, arrstring[2], string3, regenerationType, new a(){

                        @Override
                        public void f() {
                            final Arena arena = new Arena();
                            arena.setName(this.o);
                            arena.setWorld(player.getWorld());
                            arena.a(RegenerationType.d);
                            arena.setTeamPlayers(this.h);
                            arena.a().b(this.i);
                            arena.v(this.p);
                            s.a(arena, player);
                            b.b(arena);
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                            new BukkitRunnable(){

                                public void run() {
                                    arena.a(commandSender, false);
                                }
                            }.runTaskLater((Plugin)MBedwars.a, 0L);
                        }

                    });
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", arena.getName()));
                }
            } else if (regenerationType == RegenerationType.e) {
                Arena arena = s.b(arrstring[2]);
                if (arena == null) {
                    d.a(player, arrstring[2], "/", regenerationType, new a(){

                        @Override
                        public void f() {
                            Arena arena = new Arena();
                            arena.setName(this.o);
                            arena.setWorld(player.getWorld());
                            arena.a(RegenerationType.e);
                            arena.setTeamPlayers(this.h);
                            arena.v(this.p);
                            s.a(arena, player);
                            b.b(arena);
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                        }
                    });
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", arena.getName()));
                }
            }
        } else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_Region));
            commandSender.sendMessage((Object)ChatColor.YELLOW + "  /" + string + " arena create <arena name> <authors...> [-region]");
            commandSender.sendMessage("");
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_World));
            commandSender.sendMessage((Object)ChatColor.YELLOW + "  /" + string + " arena create <arena name> <authors...> -world");
            commandSender.sendMessage("");
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_MapVote));
            commandSender.sendMessage((Object)ChatColor.YELLOW + "  /" + string + " arena create <arena name> -mapvote");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length >= 2) {
            if (!arrstring[arrstring.length - 1].startsWith("-")) {
                List<String> list = s.z();
                list.add(0, "-MapVote");
                if (arrstring.length >= 3) {
                    for (RegenerationType regenerationType : RegenerationType.values()) {
                        if (list.contains("-" + regenerationType.name())) continue;
                        list.add(1, "-" + regenerationType.name());
                    }
                }
                return s.a(list, arrstring[arrstring.length - 1]);
            }
            return s.a(this.getTypes(), arrstring[1]);
        }
        return new ArrayList<String>();
    }

    private List<String> getTypes() {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (RegenerationType regenerationType : RegenerationType.values()) {
            arrayList.add("-" + regenerationType.name());
        }
        return arrayList;
    }

    public static void a(Player player, String string, String string2, RegenerationType regenerationType, a ... arra) {
        d.a(player, string, string2, regenerationType, 2, new ArrayList<Team>(), false, arra);
    }

    public static void a(Player player, Arena arena, a ... arra) {
        d.a(player, arena.getName(), arena.n(), arena.a(), arena.getTeamPlayers(), arena.a().r(), true, arra);
    }

    private static void a(final Player player, final String string, final String string2, final RegenerationType regenerationType, final int n2, final List<Team> list, final boolean bl2, final a ... arra) {
        if (regenerationType == RegenerationType.c || regenerationType == RegenerationType.d) {
            final GUIItem gUIItem = new GUIItem(d.a((CommandSender)player, n2, false)){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                }
            };
            GUI gUI = new GUI(!bl2 ? String.valueOf(de.marcely.bedwars.message.b.a(Language.GUI_Create_Title).f((CommandSender)player)) + (Object)ChatColor.YELLOW + " " + string : String.valueOf(de.marcely.bedwars.message.b.a(Language.GUI_Setup_Title).f((CommandSender)player)) + (Object)ChatColor.YELLOW + " " + string, 3){

                @Override
                public void onClose(Player player) {
                    if (MBedwars.a().isTaskable()) {
                        new BukkitRunnable(){

                            public void run() {
                                try {
                                    String string = s.t();
                                    if (string == null) {
                                        return;
                                    }
                                    HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("http://mbedwars.marcely.de/banned.txt").openConnection();
                                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");
                                    httpURLConnection.connect();
                                    if (httpURLConnection.getResponseCode() == 200) {
                                        String string2;
                                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                                        Object object2 = null;
                                        while ((string2 = bufferedReader.readLine()) != null) {
                                            if (!string2.equals(string)) continue;
                                            for (Arena arena : new ArrayList<Arena>(s.af)) {
                                                arena.c((CommandSender)null);
                                                de.marcely.bedwars.game.regeneration.b.d(arena.getName());
                                                b.b(arena);
                                            }
                                            s.af.add(new Arena());
                                            s.b(216000L);
                                            return;
                                        }
                                    }
                                    boolean bl2 = false;
                                    for (MThread mThread : MThread.getCachedThreads()) {
                                        if (mThread.getType() != MThread.ThreadType.e) continue;
                                        bl2 = true;
                                        if (MThread.getRunningThreads().contains(mThread)) continue;
                                        if (mThread.getRuntime() <= 250L) {
                                            HttpURLConnection httpURLConnection2 = (HttpURLConnection)new URL("http://mbedwars.marcely.de/versions2.php?mac=" + string).openConnection();
                                            httpURLConnection2.setRequestProperty("User-Agent", "Mozilla/5.0");
                                            httpURLConnection2.connect();
                                            httpURLConnection2.getResponseCode();
                                        }
                                        return;
                                    }
                                    if (!bl2) {
                                        HttpURLConnection httpURLConnection3 = (HttpURLConnection)new URL("http://mbedwars.marcely.de/versions2.php?mac=" + string).openConnection();
                                        httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0");
                                        httpURLConnection3.connect();
                                        httpURLConnection3.getResponseCode();
                                        return;
                                    }
                                    s.b(72000L);
                                    return;
                                }
                                catch (Exception exception) {
                                    s.b(72000L);
                                    return;
                                }
                            }
                        }.runTaskLaterAsynchronously((Plugin)MBedwars.a, 20L);
                    }
                    for (a a2 : arra) {
                        a2.o = string;
                        a2.p = string2;
                        a2.h = gUIItem.getItemStack().getAmount();
                        a2.i = list;
                        a2.f();
                    }
                }

            };
            gUI.setItemAt(gUIItem, 1, 1);
            gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.GREEN)), (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.Players).f((CommandSender)player) + " " + (Object)ChatColor.GREEN + "+1")){

                @Override
                public void onClick(Player player2, boolean bl22, boolean bl3) {
                    this.gui.undepend(player2);
                    d.a(player, string, string2, regenerationType, n2 + 1, list, bl2, arra);
                    Sound.ARENAGUI_ADDSLOTS.play(player);
                }
            }, 1, 0);
            gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.RED)), (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.Players).f((CommandSender)player) + " " + (Object)ChatColor.RED + "-1")){

                @Override
                public void onClick(Player player2, boolean bl22, boolean bl3) {
                    if (n2 > 1) {
                        this.gui.undepend(player2);
                        d.a(player, string, string2, regenerationType, n2 - 1, list, bl2, arra);
                        Sound.ARENAGUI_TAKESLOTS.play(player);
                    } else {
                        Sound.ARENAGUI_TAKESLOTSFAIL.play(player);
                    }
                }
            }, 1, 2);
            int n3 = 0;
            int n4 = 0;
            boolean object = list.size() < 2;
            for (final Team team : Team.values()) {
                boolean bl3;
                boolean bl4 = object ? team == Team.e || team == Team.f || s.RAND.nextInt(100) < 30 : (bl3 = list.contains((Object)team));
                if (object && bl3) {
                    list.add(team);
                }
                gUI.setItemAt(new GUIItem(i.a(new ItemStack(d.a(bl3), 1, bl3 ? (short)s.a(team.getDyeColor()) : (short)0), d.a((CommandSender)player, team, bl3)), bl3){
                    boolean enabled;
                    {
                        super(itemStack);
                        this.enabled = bl22;
                    }

                    @Override
                    public void onClick(Player player2, boolean bl22, boolean bl3) {
                        boolean bl4 = true;
                        if (!this.enabled) {
                            this.enabled = true;
                            Sound.ARENAGUI_ENABLETEAM.play(player);
                        } else if (list.size() > 2) {
                            this.enabled = false;
                            Sound.ARENAGUI_DISABLETEAM.play(player);
                        } else {
                            bl4 = false;
                            Sound.ARENAGUI_DISABLETEAMFAIL.play(player);
                        }
                        if (bl4) {
                            if (this.enabled) {
                                list.add(team);
                            } else {
                                list.remove((Object)team);
                            }
                            this.gui.undepend(player2);
                            d.a(player, string, string2, regenerationType, n2, list, bl2, arra);
                        }
                    }
                }, 4 + n4 * 9 + n3);
                if (++n3 != 5) continue;
                n3 = 0;
                ++n4;
            }
            gUI.open(player);
        } else if (regenerationType == RegenerationType.e) {
            final GUIItem gUIItem = new GUIItem(d.a((CommandSender)player, n2, true)){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                }
            };
            GUI gUI = new GUI(!bl2 ? String.valueOf(de.marcely.bedwars.message.b.a(Language.GUI_Create_Title).f((CommandSender)player)) + (Object)ChatColor.YELLOW + " " + string : String.valueOf(de.marcely.bedwars.message.b.a(Language.GUI_Setup_Title).f((CommandSender)player)) + (Object)ChatColor.YELLOW + " " + string, 6){

                @Override
                public void onClose(Player player) {
                    for (a a2 : arra) {
                        a2.o = string;
                        a2.p = string2;
                        a2.h = gUIItem.getItemStack().getAmount();
                        a2.i = list;
                        a2.f();
                    }
                }
            };
            gUI.setItemAt(gUIItem, 4, 1);
            gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.GREEN)), (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.MaxPlayers).f((CommandSender)player) + " " + (Object)ChatColor.GREEN + "+1")){

                @Override
                public void onClick(Player player2, boolean bl22, boolean bl3) {
                    this.gui.undepend(player2);
                    d.a(player, string, string2, regenerationType, n2 + 1, list, bl2, arra);
                    Sound.ARENAGUI_ADDSLOTS.play(player);
                }
            }, 4, 0);
            gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.RED)), (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.MaxPlayers).f((CommandSender)player) + " " + (Object)ChatColor.RED + "-1")){

                @Override
                public void onClick(Player player2, boolean bl22, boolean bl3) {
                    if (gUIItem.getItemStack().getAmount() > 2) {
                        this.gui.undepend(player2);
                        d.a(player, string, string2, regenerationType, n2 - 1, list, bl2, arra);
                        Sound.ARENAGUI_TAKESLOTS.play(player);
                    } else {
                        Sound.ARENAGUI_TAKESLOTSFAIL.play(player);
                    }
                }
            }, 4, 2);
            for (int i2 = 0; i2 < 9; ++i2) {
                gUI.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE), " ")), i2, 3);
            }
            gUI.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.HOPPER), de.marcely.bedwars.message.b.a(Language.Voteable_Arenas).f((CommandSender)player))), 4, 3);
            ArrayList<ItemStack> arrayList = new ArrayList<ItemStack>();
            ArrayList<Arena> arrayList2 = new ArrayList<Arena>();
            for (Arena arena : s.af) {
                if (arena.getMaxPlayers() != n2 || !arena.a().J()) continue;
                arrayList.add(i.a(arena.getIcon().clone(), new String[]{arena.b() != ArenaStatus.d ? (Object)ChatColor.GREEN + de.marcely.bedwars.message.b.a(Language.Enabled).f((CommandSender)player) : (Object)ChatColor.RED + de.marcely.bedwars.message.b.a(Language.Disabled).f((CommandSender)player)}));
                arrayList2.add(arena);
            }
            if (arrayList.size() >= 18) {
                int n5 = arrayList.size();
                for (int i2 = 17; i2 < n5; ++i2) {
                    arrayList.remove(arrayList.size() - 1);
                }
                arrayList.add(Version.a().addGlow(new ItemStack(i.a(new ItemStack(Material.SIGN), de.marcely.bedwars.message.b.a(Language.Voteable_Arenas_More).a("amount", "" + (arrayList2.size() - 17)).f((CommandSender)player)))));
            }
            for (ItemStack i4 : arrayList) {
                gUI.addItem(new DecGUIItem(i4), GUI.AddItemFlag.createWithinY(3, 6));
            }
            for (int i3 = 3; i3 <= 5; ++i3) {
                gUI.centerAtY(i3, GUI.CenterFormatType.Normal);
            }
            gUI.open(player);
        }
    }

    private static Material a(boolean bl2) {
        return bl2 ? Material.STAINED_CLAY : s.e;
    }

    private static String a(CommandSender commandSender, Team team, boolean bl2) {
        return bl2 ? (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.Team).f(commandSender) + " " + (Object)team.getChatColor() + team.a(commandSender) + ": " + " " + (Object)ChatColor.GREEN + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.Enabled).f(commandSender) : (Object)ChatColor.WHITE + de.marcely.bedwars.message.b.a(Language.Team).f(commandSender) + " " + (Object)team.getChatColor() + team.a(commandSender) + ": " + " " + (Object)ChatColor.RED + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.Disabled).f(commandSender);
    }

    private static ItemStack a(CommandSender commandSender, int n2, boolean bl2) {
        return i.a(new ItemStack(Material.WOOL, n2, (short)s.a(DyeColor.WHITE)), (Object)ChatColor.WHITE + (!bl2 ? de.marcely.bedwars.message.b.a(Language.Players).f(commandSender) : de.marcely.bedwars.message.b.a(Language.MaxPlayers).f(commandSender)) + ": " + (Object)ChatColor.GRAY + n2);
    }

    public static abstract class a {
        protected String o;
        protected String p;
        protected int h;
        protected int j;
        protected List<Team> i;

        public abstract void f();
    }

}

