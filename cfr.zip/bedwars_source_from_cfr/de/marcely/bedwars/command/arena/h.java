/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class h
implements CommandHandler.Command.a {
    public static final int f = 7;
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        int n2 = 1;
        int n3 = this.e();
        if (arrstring.length >= 2 && s.isInteger(arrstring[1])) {
            n2 = Integer.valueOf(arrstring[1]);
        } else if (arrstring.length >= 3 && s.isInteger(arrstring[2])) {
            n2 = Integer.valueOf(arrstring[2]);
        }
        List<CommandHandler.Command> list = this.a(n2);
        commandSender.sendMessage((Object)ChatColor.YELLOW + " ---- " + (Object)ChatColor.GOLD + b.a(Language.Help).f(commandSender) + (Object)ChatColor.YELLOW + " -- " + (Object)ChatColor.GOLD + b.a(Language.Page).f(commandSender) + " " + n2 + (Object)ChatColor.RED + "/" + (Object)ChatColor.GOLD + n3 + (Object)ChatColor.YELLOW + " ----");
        commandSender.sendMessage((Object)ChatColor.GRAY + "/" + string + " " + arrstring[0] + " " + this.cmd.a[0] + " " + (Object)ChatColor.DARK_GRAY + "[" + b.a(Language.Page).f(commandSender) + "]");
        for (int i2 = 0; i2 < 7 - list.size() + 1; ++i2) {
            commandSender.sendMessage("");
        }
        for (CommandHandler.Command command : list) {
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0] + " " + command.a[0] + " " + (Object)ChatColor.AQUA + command.usage);
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (int i2 = 1; i2 <= this.e(); ++i2) {
            arrayList.add("" + i2);
        }
        return arrayList;
    }

    public List<CommandHandler.Command> a(int n2) {
        ArrayList<CommandHandler.Command> arrayList = new ArrayList<CommandHandler.Command>();
        int n3 = 1;
        int n4 = 0;
        for (CommandHandler.Command command : this.cmd.b.getCommands()) {
            if (n4 >= 7) {
                ++n3;
                n4 = 0;
            }
            ++n4;
            if (!command.visible) {
                --n4;
            }
            if (!command.visible || n3 != n2) continue;
            arrayList.add(command);
        }
        return arrayList;
    }

    public int e() {
        return (this.cmd.b.getCommands().size() + 7 - 1 - this.f()) / 7;
    }

    public int f() {
        int n2 = 0;
        for (CommandHandler.Command command : this.cmd.b.getCommands()) {
            if (command.visible) continue;
            ++n2;
        }
        return n2;
    }
}

