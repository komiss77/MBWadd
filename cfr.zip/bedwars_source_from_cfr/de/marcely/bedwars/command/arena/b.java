/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command.arena;

import com.google.common.io.Files;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;

public class b
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(final CommandSender commandSender, String string, String string2, final String[] arrstring) {
        if (arrstring.length >= 4) {
            final Arena arena = s.b(arrstring[2]);
            if (arena != null) {
                if (s.b(arrstring[3]) == null) {
                    if (arena.b() == ArenaStatus.d) {
                        new MThread(MThread.ThreadType.p, arrstring[3]){

                            @Override
                            public void run() {
                                try {
                                    Files.copy((File)new File("plugins/MBedwars/data/arenadata/" + arena.getName() + ".cfg"), (File)new File("plugins/MBedwars/data/arenadata/" + arrstring[3] + ".cfg"));
                                    if (new File("plugins/MBedwars/data/arenablocks/" + arena.getName() + ".yml").exists()) {
                                        Files.copy((File)new File("plugins/MBedwars/data/arenablocks/" + arena.getName() + ".yml"), (File)new File("plugins/MBedwars/data/arenablocks/" + arrstring[3] + ".yml"));
                                    }
                                    de.marcely.bedwars.config.b.a(arrstring[3]);
                                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Clone_Arena).a("arena1", arena.getName()).a("arena2", arrstring[3]));
                                }
                                catch (Exception exception) {
                                    exception.printStackTrace();
                                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Error_Occured));
                                }
                            }
                        }.start();
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Arena_HasToBeStopped).a("arena", arena.getName()));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", arrstring[3]));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        } else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }

}

