/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

public class j
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("add")) {
            DropType dropType = DropType.a(arrstring[4]);
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                if (dropType != null) {
                    if (arena.a().J()) {
                        if (arena.getWorld() == null) {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Problem_Arena_World).a("arena", arena.getName()));
                            commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.FixProblemWith).f(commandSender)) + "/" + string + " arena setworld " + arena.getName());
                            return;
                        }
                        if (player.getWorld().equals((Object)arena.getWorld())) {
                            Location location = player.getLocation().getBlock().getLocation();
                            arena.addItemSpawner(dropType, XYZ.valueOf(location));
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Added_Itemspawner).a("spawnertype", dropType.getName()));
                            b.b(arena);
                        } else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotSameWorld_Arena).a("arena", arena.getName()).a("world", arena.getWorld().getName()));
                        }
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", arena.a().name()).a("name", arena.getName()));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Itemspawner).a("itemspawner", arrstring[4]));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 4 && arrstring[2].equalsIgnoreCase("remove")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                if (arena.a().J()) {
                    Location location = player.getLocation().getBlock().getLocation();
                    int n2 = arena.a(location);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Removed_Itemspawners).a("number", "" + n2));
                    b.b(arena);
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", arena.a().name()).a("name", arena.getName()));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 4 && arrstring[2].equalsIgnoreCase("get")) {
            DropType dropType = DropType.a(arrstring[3]);
            if (dropType != null) {
                if (dropType.getActualItemstack() != null && dropType.getActualItemstack().getItemMeta() != null && dropType.getName() != null && dropType.getChatColor() != null) {
                    int n3 = 1;
                    if (arrstring.length >= 5 && s.isInteger(arrstring[4])) {
                        n3 = Integer.valueOf(arrstring[4]);
                    }
                    ItemStack itemStack = i.a(dropType.getActualItemstack().clone(), (Object)dropType.getChatColor() + dropType.getName());
                    itemStack.setAmount(n3);
                    ((Player)commandSender).getInventory().addItem(new ItemStack[]{itemStack});
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Give_Itemspawner).a("amount", "" + n3).a("itemspawner", dropType.getName()));
                } else {
                    commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.Error_Occured).f(commandSender)) + " (" + dropType.getName() + ")");
                }
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Itemspawner).a("itemspawner", arrstring[3]));
            }
        } else {
            commandSender.sendMessage("");
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.ItemSpawner_List).f(commandSender));
            if (DropType.values().size() >= 1) {
                for (DropType dropType : DropType.values()) {
                    commandSender.sendMessage(" " + (Object)ChatColor.GOLD + dropType.a(commandSender, true));
                }
            } else {
                commandSender.sendMessage((Object)ChatColor.RED + " " + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.Commands_List).f(commandSender));
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " add " + (Object)ChatColor.AQUA + "<arena name> <itemspawner>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " remove " + (Object)ChatColor.AQUA + "<arena name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " get " + (Object)ChatColor.AQUA + "<itemspawner> [amount]");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (arrstring.length == 2) {
            if (string2.equalsIgnoreCase("add") || string2.equalsIgnoreCase("remove")) {
                return s.a(s.A(), arrstring[1]);
            }
            if (string2.equalsIgnoreCase("get")) {
                return s.a(DropType.a(commandSender, true), arrstring[1]);
            }
        } else if (arrstring.length == 3 && string2.equalsIgnoreCase("add")) {
            return s.a(DropType.a(commandSender, true), arrstring[2]);
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("add", "remove", "get");
    }
}

