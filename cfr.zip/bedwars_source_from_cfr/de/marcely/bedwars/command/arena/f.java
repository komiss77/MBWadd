/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.Flag;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.util.SoftHashMap;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class f
implements CommandHandler.Command.a {
    public static f a;
    protected CommandHandler.Command cmd;
    private static final ItemStack b;
    private static final int k = 10;
    public final Map<Player, c> e = new SoftHashMap<Player, c>();

    static {
        b = i.a(new ItemStack(Material.ARROW), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Back).f(null));
    }

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
        a = this;
        de.marcely.bedwars.config.b.k.add(new b.a(){

            @Override
            public void a(Arena arena) {
                new de.marcely.bedwars.command.arena.f$1$1();
            }

            @Override
            public void g() {
            }

        });
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        c c2 = this.a(player);
        if (arrstring.length <= 2) {
            if (c2.b == null) {
                this.d(player);
            } else {
                c2.i = true;
                c2.b.open(player);
            }
        } else {
            Arena arena = s.b(arrstring[2]);
            if (arena != null) {
                this.a(player, arena);
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }

    private c a(Player player) {
        c c2 = this.e.get((Object)player);
        if (c2 == null) {
            c2 = new c();
            this.e.put(player, c2);
        }
        return c2;
    }

    private void d(Player player) {
        GUI gUI = new GUI("", 0){

            @Override
            public void onClose(Player player) {
                c c2 = f.this.e.get((Object)player);
                if (c2 != null) {
                    c2.i = false;
                }
            }
        };
        for (final Arena object2 : s.af) {
            gUI.addItem(new GUIItem(i.a(object2.getIcon(), (Object)ChatColor.WHITE + object2.getName())){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    f.this.a(player, object2);
                }
            });
        }
        if (de.marcely.bedwars.config.b.d().size() >= 1) {
            for (int i2 = 0; i2 < de.marcely.bedwars.config.b.d().size() - s.af.size(); ++i2) {
                gUI.addItem(new DecGUIItem(i.a(new ItemStack(Material.COAL, 0), (Object)ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.NotFound_Arena_Loading).f((CommandSender)player))));
            }
        }
        gUI.centerAtYAll(GUI.CenterFormatType.Normal);
        gUI.open(player);
        c c2 = this.a(player);
        c2.i = true;
        c2.b = null;
    }

    private void a(final Player player, final Arena arena) {
        LinkedHashMap<SimpleGUI, String> linkedHashMap = this.a(arena, player, new b(){

            @Override
            public void a(SimpleGUI simpleGUI, String string) {
                f.this.a(simpleGUI, string, arena.getName(), player);
            }
        });
        Map.Entry entry = ((Map.Entry[])linkedHashMap.entrySet().stream().toArray(n2 -> new Map.Entry[n2]))[0];
        this.a((SimpleGUI)entry.getKey(), (String)entry.getValue(), arena.getName(), player);
    }

    private void a(SimpleGUI simpleGUI, String string, String string2, Player player) {
        this.a((Player)player).b = simpleGUI;
        simpleGUI.setTitle(this.a(string2, string));
        simpleGUI.open(player);
    }

    private String a(String string, String ... arrstring) {
        String string2 = (Object)ChatColor.GOLD + string;
        for (String string3 : arrstring) {
            string2 = String.valueOf(string2) + (Object)ChatColor.YELLOW + " > " + (Object)ChatColor.GOLD + string3;
        }
        return string2;
    }

    private void a(final Arena arena, final Team team, Player player) {
        GUI gUI = this.a(player, arena, i.a(new ItemStack(Material.WOOL, 1, (short)team.getDyeColor().getWoolData()), (Object)team.getChatColor() + team.a((CommandSender)player, true)), "Teams", team.a((CommandSender)player, true));
        gUI.setHeight(3);
        gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.STONE_PLATE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Teams_SetSpawn).f((CommandSender)player))){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("team").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "setspawn", arena.getName(), team.name()).toArray(new String[5]));
            }
        }, 3, 2);
        gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.BED), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Teams_GetBed).f((CommandSender)player))){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("team").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "getbed", team.name()).toArray(new String[4]));
            }
        }, 5, 2);
        gUI.open(player);
    }

    private void a(final Arena arena, final DropType dropType, Player player) {
        GUI gUI = this.a(player, arena, i.a(dropType.getActualItemstack(), (Object)(dropType.getChatColor() != null ? dropType.getChatColor() : ChatColor.ITALIC) + dropType.a((CommandSender)player, true)), "Itemspawners", dropType.a((CommandSender)player, true));
        gUI.setHeight(3);
        gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.STONE_PLATE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners_Add).f((CommandSender)player))){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "add", arena.getName(), dropType.getName()).toArray(new String[5]));
            }
        }, 3, 2);
        gUI.setItemAt(new GUIItem(i.a(new ItemStack(Material.DROPPER), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners_Get).a("amount", "10").f((CommandSender)player))){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "get", dropType.getName(), "10").toArray(new String[5]));
            }
        }, 5, 2);
        gUI.open(player);
    }

    private GUI a(final Player player, final Arena arena, ItemStack itemStack, String string, String string2) {
        GUI gUI = new GUI(this.a(arena.getName(), string, string2), 2);
        gUI.setItemAt(new DecGUIItem(arena.getIcon()), 3, 0);
        gUI.setItemAt(new DecGUIItem(itemStack), 5, 0);
        gUI.setItemAt(new GUIItem(b){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.a(player, arena);
            }
        }, 0, 0);
        for (int i2 = 0; i2 < 9; ++i2) {
            gUI.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 15), " ")), i2, 1);
        }
        return gUI;
    }

    private LinkedHashMap<SimpleGUI, String> a(final Arena arena, final Player player, final b b2) {
        LinkedHashMap<SimpleGUI, String> linkedHashMap = new LinkedHashMap<SimpleGUI, String>();
        ItemStack itemStack = i.a(i.a("MHF_ArrowLeft", 1), (Object)ChatColor.DARK_AQUA + "< " + (Object)ChatColor.AQUA);
        ItemStack itemStack2 = i.a(i.a("MHF_ArrowRight", 1), (Object)ChatColor.DARK_AQUA + "> " + (Object)ChatColor.AQUA);
        a a2 = new a(arena, "");
        String string = de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main).f((CommandSender)player);
        a a3 = new a(arena, "");
        String string2 = de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Teams).f((CommandSender)player);
        a a4 = new a(arena, "");
        String string3 = de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners).f((CommandSender)player);
        a a5 = new a(arena, "");
        String string4 = de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Flags).f((CommandSender)player);
        a2.a(new GUIItem(i.a(new ItemStack(Material.WORKBENCH), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Configure).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("configure").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a2.a(new GUIItem(i.a(new ItemStack(Version.a().getVersionNumber() >= 8 ? Material.BIRCH_DOOR_ITEM : Material.BEACON), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_SetLobby).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("setlobby").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a2.a(new GUIItem(i.a(new ItemStack(Material.NAME_TAG), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Rename).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                AnvilGUI anvilGUI = new AnvilGUI(arena.getName());
                anvilGUI.setTitle(de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Rename).f((CommandSender)player));
                anvilGUI.setWroteListener(new AnvilGUI.WroteListener(){

                    @Override
                    public void run(String string) {
                        4.a(this).cmd.a().a("flag").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "setname", arena.getName(), string).toArray(new String[5]));
                    }
                });
                anvilGUI.open(player2);
            }

            static /* synthetic */ f a(4 var0) {
                return var0.f.this;
            }

        });
        a2.a(new GUIItem(i.a(new ItemStack(Material.STAINED_CLAY, 1, 5), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Enable).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("setenabled").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName(), "true").toArray(new String[4]));
            }
        });
        a2.a(new GUIItem(i.a(new ItemStack(Material.STAINED_CLAY, 1, 14), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Disable).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("setenabled").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName(), "false").toArray(new String[4]));
            }
        });
        if (arena.a().J()) {
            a2.a(new GUIItem(i.a(new ItemStack(Material.FURNACE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Regenerate).f((CommandSender)player))){

                @Override
                public void onClick(Player player2, boolean bl2, boolean bl3) {
                    f.this.cmd.a().a("regenerate").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
            a2.a(new GUIItem(i.a(new ItemStack(Material.HOPPER), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_SaveBlocks).f((CommandSender)player))){

                @Override
                public void onClick(Player player2, boolean bl2, boolean bl3) {
                    f.this.cmd.a().a("saveblocks").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
        }
        a2.a(new GUIItem(i.a(new ItemStack(Material.GRASS), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_SetWorld).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("setworld").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        if (arena.a() == RegenerationType.c) {
            a2.a(new GUIItem(i.a(new ItemStack(Material.WOOD_AXE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_SetPosition).f((CommandSender)player))){

                @Override
                public void onClick(Player player2, boolean bl2, boolean bl3) {
                    f.this.cmd.a().a("setposition").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
        }
        a2.a(new GUIItem(i.a(new ItemStack(Material.EYE_OF_ENDER), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_SetSpectatorSpawn).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("setspectatorspawn").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a2.a(new GUIItem(i.a(new ItemStack(Material.ENDER_PEARL), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Teleport).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("teleport").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a2.a(new GUIItem(i.a(new ItemStack(Material.GLOWSTONE_DUST), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Enter).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                String string = s.b(player, arena);
                if (string != null) {
                    player.sendMessage(string);
                }
            }
        });
        if (arena.a().J()) {
            a2.a(new GUIItem(i.a(new ItemStack(Material.SULPHUR), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_EnterSpectator).f((CommandSender)player))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    cA.a(player, arena, SpectateReason.ENTER);
                }
            });
        }
        a2.a(new GUIItem(i.a(new ItemStack(Material.SIGN), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Main_Info).f((CommandSender)player))){

            @Override
            public void onClick(Player player2, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("info").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        for (final Team object2 : arena.a().r()) {
            a3.a(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)object2.getDyeColor().getWoolData()), (Object)object2.getChatColor() + object2.a((CommandSender)player, true))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    f.this.a(arena, object2, player);
                }
            });
        }
        a4.a(new GUIItem(i.a(new ItemStack(s.e), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners_Remove).f((CommandSender)player))){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                f.this.cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "remove", arena.getName()).toArray(new String[4]));
            }
        });
        a4.a(new DecGUIItem(new ItemStack(Material.PORTAL)));
        Object object3 = DropType.values().iterator();
        while (object3.hasNext()) {
            DropType dropType;
            a4.a(new GUIItem(i.a(dropType.getActualItemstack(), (Object)((dropType = (DropType)object3.next()).getChatColor() != null ? dropType.getChatColor() : ChatColor.ITALIC) + dropType.a((CommandSender)player, true))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    f.this.a(arena, dropType, player);
                }
            });
        }
        for (final Flag flag : arena.p()) {
            a5.a(new GUIItem(i.a(new ItemStack(Material.SIGN), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Flags_Modify).a("name", flag.getName()).a("type", flag.getType().name()).f((CommandSender)player))){

                @Override
                public void onClick(final Player player2, boolean bl2, boolean bl3) {
                    AnvilGUI anvilGUI = new AnvilGUI(String.valueOf(flag.getValue()));
                    anvilGUI.setTitle(de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Flags_Modify).a("name", flag.getName()).a("type", flag.getType().name()).f((CommandSender)player));
                    anvilGUI.setWroteListener(new AnvilGUI.WroteListener(){

                        @Override
                        public void run(String string) {
                            if (flag.getType().isInstance(r.b(string))) {
                                flag.setValue(r.b(string));
                                s.a((CommandSender)player2, de.marcely.bedwars.message.b.a(Language.Flag_Modfiy_Success).a("name", flag.getName()).a("to", string));
                            } else {
                                s.a((CommandSender)player2, de.marcely.bedwars.message.b.a(Language.Flag_Modfiy_WrongType).a("value", string).a("type", flag.getType().name()));
                            }
                            f.this.a(player2, arena);
                        }
                    });
                    anvilGUI.open(player2);
                }

            });
        }
        linkedHashMap.put(a2.a(), string);
        if (arena.a().J()) {
            linkedHashMap.put(a3.a(), string2);
            linkedHashMap.put(a4.a(), string3);
        }
        linkedHashMap.put(a5.a(), string4);
        Iterator iterator = linkedHashMap.keySet().iterator();
        object3 = null;
        SimpleGUI simpleGUI = (SimpleGUI)iterator.next();
        SimpleGUI simpleGUI2 = iterator.hasNext() ? (SimpleGUI)iterator.next() : null;
        while (simpleGUI != null) {
            String string5;
            Object object;
            GUI gUI = (GUI)simpleGUI;
            if (object3 != null) {
                string5 = linkedHashMap.get(object3);
                object = object3;
                gUI.setItemAt(new GUIItem(i.b(itemStack.clone(), string5), (SimpleGUI)object, string5){
                    private final /* synthetic */ SimpleGUI a;
                    private final /* synthetic */ String q;
                    {
                        this.a = simpleGUI;
                        this.q = string;
                        super(itemStack);
                    }

                    @Override
                    public void onClick(Player player, boolean bl2, boolean bl3) {
                        b2.a(this.a, this.q);
                    }
                }, 0, 1);
            }
            if (simpleGUI2 != null) {
                string5 = linkedHashMap.get(simpleGUI2);
                object = simpleGUI2;
                gUI.setItemAt(new GUIItem(i.b(itemStack2.clone(), string5), (SimpleGUI)object, string5){
                    private final /* synthetic */ SimpleGUI a;
                    private final /* synthetic */ String q;
                    {
                        this.a = simpleGUI;
                        this.q = string;
                        super(itemStack);
                    }

                    @Override
                    public void onClick(Player player, boolean bl2, boolean bl3) {
                        b2.a(this.a, this.q);
                    }
                }, 8, 1);
            }
            object3 = simpleGUI;
            simpleGUI = simpleGUI2;
            SimpleGUI simpleGUI3 = simpleGUI2 = iterator.hasNext() ? (SimpleGUI)iterator.next() : null;
        }
        return linkedHashMap;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    private class a {
        private final Arena arena;
        private final String title;
        private List<GUIItem> items = new ArrayList<GUIItem>();
        private GUIItem b = null;
        private GUIItem c = null;
        private boolean h = true;
        private GUI gui = null;

        public a(Arena arena, String string) {
            this.arena = arena;
            this.title = string;
        }

        public void a(GUIItem gUIItem) {
            this.items.add(gUIItem);
            this.h = true;
        }

        public SimpleGUI a() {
            int n2;
            if (!this.h) {
                return this.gui;
            }
            this.gui = new GUI(this.title, 2);
            this.gui.setItemAt(new DecGUIItem(this.arena.getIcon()), 4, 0);
            this.gui.setItemAt(new GUIItem(b){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    a.this.f.this.d(player);
                }
            }, 0, 0);
            for (n2 = 0; n2 < 9; ++n2) {
                this.gui.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 15), " ")), n2, 1);
            }
            if (this.b != null) {
                this.gui.setItemAt(this.b, 0, 1);
            }
            if (this.c != null) {
                this.gui.setItemAt(this.c, 8, 1);
            }
            for (GUIItem gUIItem : this.items) {
                this.gui.addItem(gUIItem, GUI.AddItemFlag.createWithinY(2, 6));
            }
            for (n2 = 2; n2 < this.gui.getHeight(); ++n2) {
                this.gui.centerAtY(n2, GUI.CenterFormatType.Normal);
            }
            this.h = false;
            return this.gui;
        }

    }

    private static interface b {
        public void a(SimpleGUI var1, String var2);
    }

    private static class c {
        public boolean i = false;
        @Nullable
        public SimpleGUI b = null;

        private c() {
        }
    }

}

