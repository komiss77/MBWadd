/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class i
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 3) {
            Arena arena = s.b(arrstring[2]);
            if (arena != null) {
                if (commandSender instanceof Player) {
                    int n2;
                    if (arena.a() == RegenerationType.c) {
                        for (n2 = 0; n2 < 2; ++n2) {
                            commandSender.sendMessage("");
                        }
                    } else {
                        for (n2 = 0; n2 < 4; ++n2) {
                            commandSender.sendMessage("");
                        }
                    }
                }
                commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "======== " + (Object)ChatColor.AQUA + arena.getName() + (Object)ChatColor.DARK_AQUA + " ========");
                String string3 = "null";
                if (arena.getWorld() != null) {
                    string3 = arena.getWorld().getName();
                }
                commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "World " + (Object)ChatColor.GREEN + string3);
                commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "Status " + (Object)ChatColor.GREEN + arena.b().name());
                commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "Players " + (Object)ChatColor.GREEN + arena.getPlayers().size() + "/" + arena.getMaxPlayers());
                commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "Regeneration type " + (Object)ChatColor.GREEN + arena.a().name());
                commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "Is Sleeping " + (Object)ChatColor.GREEN + arena.isSleeping());
                if (arena.a().J()) {
                    commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "Regeneration time " + (Object)ChatColor.GREEN + "~" + (int)arena.a() + "s");
                }
                if (arena.a() == RegenerationType.c) {
                    commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "PosMin " + (Object)ChatColor.GREEN + "X" + arena.getPosMin().getX() + " Y" + arena.getPosMin().getY() + " Z" + arena.getPosMin().getZ());
                    commandSender.sendMessage((Object)ChatColor.DARK_GREEN + "PosMax " + (Object)ChatColor.GREEN + "X" + arena.getPosMax().getX() + " Y" + arena.getPosMax().getY() + " Z" + arena.getPosMax().getZ());
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        } else {
            s.a(commandSender, b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

