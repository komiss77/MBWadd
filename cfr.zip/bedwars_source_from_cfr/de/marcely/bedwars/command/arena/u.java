/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.APIConfiguration;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class u
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        Player player = (Player)commandSender;
        if (arrstring.length >= 4 && arrstring[2].equalsIgnoreCase("getbed") && BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
            String string3 = arrstring.length >= 5 ? String.valueOf(arrstring[3]) + " " + arrstring[4] : arrstring[3];
            Team team = Team.a(commandSender, string3);
            if (team != null) {
                ItemStack itemStack = new ItemStack(k.a(ConfigValue.bed_block));
                itemStack = i.a(itemStack, String.format(s.W, (Object)team.getChatColor() + team.getName(true)));
                itemStack = i.a(itemStack, team);
                player.getInventory().addItem(new ItemStack[]{itemStack});
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Get_Bed).a("color", team.a(commandSender)).a("colorcode", "" + (Object)team.getChatColor()));
            } else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", string3));
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("setspawn") && (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled)) {
            String string4 = arrstring.length >= 6 ? String.valueOf(arrstring[4]) + " " + arrstring[5] : arrstring[4];
            Arena arena = s.b(arrstring[3]);
            Team team = Team.a(commandSender, string4);
            if (arena != null) {
                if (arena.a().J()) {
                    if (team != null) {
                        if (arena.a().r().contains((Object)team)) {
                            if (player.getWorld().equals((Object)arena.getWorld())) {
                                arena.a().a(XYZYP.valueOf(player.getLocation()), team);
                                b.b(arena);
                                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Changed_TeamSpawn).a("color", team.a(commandSender)).a("colorcode", "" + (Object)team.getChatColor()));
                            } else {
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotSameWorld_Arena).a("arena", arena.getName()).a("world", arena.getWorld().getName()));
                            }
                        } else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Team_NotAddedYet).a("team", team.a(commandSender, true)).a("teamcolor", "" + (Object)team.getChatColor()).a("arena", arena.getName()));
                        }
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", string4));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", arena.a().name()).a("name", arena.getName()));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else {
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender));
            for (int i2 = 0; i2 < 7; ++i2) {
                commandSender.sendMessage("");
            }
            if (BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
                commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " getbed" + (Object)ChatColor.AQUA + " <team color>");
            }
            if (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
                commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + " " + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " setspawn" + (Object)ChatColor.AQUA + " <arena name> <team color>");
            }
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (arrstring.length == 2) {
            if (string2.equalsIgnoreCase("getbed")) {
                return s.a(Team.a(commandSender, true, true), arrstring[1]);
            }
            return s.a(s.A(), arrstring[1]);
        }
        if (arrstring.length == 3 && string2.equalsIgnoreCase("setspawn")) {
            return s.a(Team.a(commandSender, true, true), arrstring[1]);
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("getbed", "setspawn");
    }
}

