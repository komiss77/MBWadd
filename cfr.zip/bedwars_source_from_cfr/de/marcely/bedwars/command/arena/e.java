/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class e
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("setname")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                if (arena.f(arrstring[4])) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", arrstring[4]));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("seticon")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                ItemStack itemStack = i.b(arrstring[4]);
                if (itemStack != null) {
                    arena.setIcon(itemStack);
                    b.b(arena);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Block).a("block", arrstring[4]));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("addauthor")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                String string3 = arena.n();
                string3 = string3 == "" ? arrstring[4].replace("\\,", "") : String.valueOf(string3) + ", " + arrstring[4].replace("\\,", "");
                arena.v(string3);
                b.b(arena);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("delauthor")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                String[] arrstring2 = arena.n().split("\\,");
                ArrayList<String> arrayList = new ArrayList<String>();
                boolean bl2 = false;
                for (String string4 : arrstring2) {
                    if (!string4.equalsIgnoreCase(arrstring[4])) {
                        arrayList.add(string4);
                        continue;
                    }
                    bl2 = true;
                }
                if (!bl2) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotFound_Author).a("author", arrstring[4]));
                    return;
                }
                if (arrayList.size() != 0) {
                    int n2 = 0;
                    String string5 = "";
                    for (String string6 : arrayList) {
                        string5 = arrayList.size() == n2 + 1 ? String.valueOf(string5) + string6 : String.valueOf(string5) + string6 + ",";
                        ++n2;
                    }
                    arena.v(string5);
                }
                b.b(arena);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("setminplayers")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                if (s.isInteger(arrstring[4])) {
                    int n3 = Integer.valueOf(arrstring[4]);
                    if (n3 >= 2) {
                        arena.setMinPlayers(n3);
                        b.b(arena);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
                    } else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NeedMore_Players_Than).a("amount", arrstring[4]));
                    }
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", arrstring[4]));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("sethascustomname")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                if (s.isBoolean(arrstring[4])) {
                    arena.setHasCustomName(Boolean.parseBoolean(arrstring[4]));
                    b.b(arena);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else if (arrstring.length >= 5 && arrstring[2].equalsIgnoreCase("setcustomname")) {
            Arena arena = s.b(arrstring[3]);
            if (arena != null) {
                String string7 = arrstring[4];
                for (int i2 = 5; i2 < arrstring.length; ++i2) {
                    string7 = String.valueOf(string7) + " " + arrstring[i2];
                }
                arena.setCustomName(string7);
                b.b(arena);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", arena.getName()));
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[3]);
            }
        } else {
            commandSender.sendMessage((Object)ChatColor.GRAY + (Object)ChatColor.BOLD + de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender));
            for (int i3 = 0; i3 < 2; ++i3) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " setname" + (Object)ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " seticon" + (Object)ChatColor.AQUA + " <arena name> <block>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " addauthor" + (Object)ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " delauthor" + (Object)ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " setminplayers" + (Object)ChatColor.AQUA + " <arena name> <amount>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " sethascustomname" + (Object)ChatColor.AQUA + " <arena name> <true/false>");
            commandSender.sendMessage((Object)ChatColor.DARK_AQUA + "/" + string + arrstring[0].toLowerCase() + " " + arrstring[1].toLowerCase() + " setcustomname" + (Object)ChatColor.AQUA + " <arena name> <name (can contain space)>");
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return this.b();
        }
        if (arrstring.length == 1) {
            return s.a(this.b(), arrstring[0]);
        }
        String string2 = arrstring[0];
        if (arrstring.length == 2) {
            return s.a(s.A(), arrstring[1]);
        }
        if (arrstring.length == 3) {
            if (string2.equalsIgnoreCase("seticon")) {
                return s.a(k.y(), arrstring[2]);
            }
            if (string2.equalsIgnoreCase("addauthor")) {
                return null;
            }
            if (string2.equalsIgnoreCase("delauthor")) {
                Arena arena = s.b(arrstring[1]);
                if (arena != null) {
                    return s.a(Arrays.asList(arena.b()), arrstring[2]);
                }
                return null;
            }
        }
        return new ArrayList<String>();
    }

    private List<String> b() {
        return Arrays.asList("setname", "seticon", "addauthor", "delauthor", "setminplayers", "sethascustomname", "setcustomname");
    }
}

