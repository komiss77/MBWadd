/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;

public class k
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        String string3 = "";
        int n2 = 1;
        for (Arena arena : s.af) {
            string3 = n2 != s.af.size() ? String.valueOf(string3) + arena.getName() + ", " : String.valueOf(string3) + arena.getName();
            ++n2;
        }
        if (string3.isEmpty()) {
            commandSender.sendMessage(String.valueOf(b.a(Language.List_Arenas).f(commandSender)) + b.a(Language.None).f(commandSender));
        } else {
            commandSender.sendMessage(String.valueOf(b.a(Language.List_Arenas).f(commandSender)) + "(" + s.af.size() + "); " + string3);
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        return new ArrayList<String>();
    }
}

