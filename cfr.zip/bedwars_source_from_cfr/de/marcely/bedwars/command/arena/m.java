/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.command.CommandSender;

public class m
implements CommandHandler.Command.a {
    protected CommandHandler.Command cmd;

    @Override
    public void a(CommandHandler.Command command) {
        this.cmd = command;
    }

    @Override
    public void a(CommandSender commandSender, String string, String string2, String[] arrstring) {
        if (arrstring.length >= 3) {
            Arena arena = s.b(String.join((CharSequence)" ", Arrays.copyOfRange(arrstring, 2, arrstring.length)));
            if (arena != null) {
                if (arena.b() == ArenaStatus.d) {
                    arena.c(commandSender);
                    de.marcely.bedwars.game.regeneration.b.d(arena.getName());
                    b.b(arena);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Remove_Arena).a("arena", arena.getName()));
                } else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.JoinMessage_running).a("arena", arena.getName()));
                }
            } else {
                Language.sendNotFoundArenaMessage(commandSender, arrstring[2]);
            }
        } else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", string2));
        }
    }

    @Override
    public List<String> a(String[] arrstring, String string, CommandSender commandSender) {
        if (arrstring.length == 0) {
            return s.A();
        }
        if (arrstring.length == 1) {
            return s.a(s.A(), arrstring[0]);
        }
        return new ArrayList<String>();
    }
}

