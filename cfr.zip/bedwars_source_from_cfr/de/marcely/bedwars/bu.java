/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.arena.picker.ArenaPickerExecutor;
import de.marcely.bedwars.util.s;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.Random;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class bu
extends Enum<bu> {
    public static final /* enum */ bu a = new bu((list, arena) -> (Arena)list.get(s.RAND.nextInt(list.size())));
    public static final /* enum */ bu b = new bu((list, arena2) -> {
        int n3 = list.stream().map(arena -> arena.getPlayers().size()).mapToInt(n2 -> n2).max().orElse(-1);
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            if (((Arena)iterator.next()).getPlayers().size() == n3) continue;
            iterator.remove();
        }
        if (arena2 != null && list.contains(arena2)) {
            return arena2;
        }
        return (Arena)list.get(s.RAND.nextInt(list.size()));
    });
    private final ArenaPickerExecutor b;
    private static final /* synthetic */ bu[] a;

    static {
        a = new bu[]{a, b};
    }

    private bu(ArenaPickerExecutor arenaPickerExecutor) {
        this.b = arenaPickerExecutor;
    }

    public static void init() {
        if (s.ab.size() >= 1) {
            return;
        }
        for (bu bu2 : bu.values()) {
            s.ab.put(bu2.toString().toLowerCase(), bu2.b);
        }
    }

    public ArenaPickerExecutor b() {
        return this.b;
    }

    public static bu[] values() {
        bu[] arrbu = a;
        int n2 = arrbu.length;
        bu[] arrbu2 = new bu[n2];
        System.arraycopy(arrbu, 0, arrbu2, 0, n2);
        return arrbu2;
    }

    public static bu valueOf(String string) {
        return Enum.valueOf(bu.class, string);
    }
}

