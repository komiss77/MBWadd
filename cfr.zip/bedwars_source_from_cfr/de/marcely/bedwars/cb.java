/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bZ;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import java.util.List;

public class cb
extends bZ {
    public static cb a = new cb();

    @Override
    public bP.c a() {
        return bP.c.a;
    }

    @Override
    public String c(Arena arena) {
        return "" + arena.a().r().size();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.c((Arena)object);
    }
}

