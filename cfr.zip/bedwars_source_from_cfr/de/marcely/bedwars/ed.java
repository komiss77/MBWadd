/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 */
package de.marcely.bedwars;

import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.d;
import de.marcely.bedwars.ef;
import de.marcely.bedwars.eg;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class ed
extends ef {
    public ed() {
        super(eg.b);
    }

    @Override
    public boolean aa() {
        return true;
    }

    @Override
    public boolean ab() {
        return true;
    }

    @Override
    public boolean isConnected() {
        return true;
    }

    @Override
    public Future<Boolean> d(final UUID uUID) {
        return this.a(new Callable<Boolean>(){

            @Override
            public Boolean call() throws Exception {
                return ed.b(uUID).exists();
            }
        });
    }

    @Override
    public Future<c> a(final UUID uUID, final String string) {
        return this.a(new Callable<c>(){

            public c c() throws Exception {
                if (!ed.b(uUID).exists()) {
                    return new c(string, uUID, false);
                }
                try (InputStreamReader inputStreamReader = null;){
                    inputStreamReader = new FileReader(new File("plugins/MBedwars/data/playerstats/" + uUID.toString() + ".yml"));
                    c c2 = new c(string, uUID, false);
                    XMLInputFactory xMLInputFactory = XMLInputFactory.newInstance();
                    XMLStreamReader xMLStreamReader = xMLInputFactory.createXMLStreamReader(inputStreamReader);
                    while (xMLStreamReader.hasNext()) {
                        int n2 = xMLStreamReader.next();
                        if (n2 != 1) continue;
                        if (xMLStreamReader.getLocalName().equals("stats")) {
                            for (int i2 = 0; i2 < xMLStreamReader.getAttributeCount(); ++i2) {
                                String string3 = xMLStreamReader.getAttributeLocalName(i2);
                                String string2 = xMLStreamReader.getAttributeValue(i2);
                                if (string3.equals("rank")) {
                                    c2.setRank(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("wins")) {
                                    c2.setWins(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("loses")) {
                                    c2.setLoses(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("kills")) {
                                    c2.setKills(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("deaths")) {
                                    c2.setDeaths(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("bedsDestroyed")) {
                                    c2.setBedsDestroyed(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("roundsPlayed")) {
                                    c2.setRoundsPlayed(Integer.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("playTime")) {
                                    c2.setPlayTime(Long.valueOf(string2));
                                    continue;
                                }
                                if (string3.equals("coins")) {
                                    c2.setCoins(Integer.valueOf(string2));
                                    continue;
                                }
                                if (!string3.equals("finalKills")) continue;
                                c2.setFinalKills(Integer.valueOf(string2));
                            }
                            continue;
                        }
                        if (xMLStreamReader.getLocalName().equals("user_name")) {
                            c2.x(xMLStreamReader.getElementText());
                            continue;
                        }
                        if (!xMLStreamReader.getLocalName().equals("user_id")) continue;
                        c2.b(UUID.fromString(xMLStreamReader.getElementText()));
                    }
                    if (c2.getPlayerName() == null || c2.getPlayerName().length() < 2) {
                        d.b("Fixing username in stats of user with UUID '" + uUID + "'...");
                        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                        if (offlinePlayer != null && offlinePlayer.getName() != null) {
                            c2.x(offlinePlayer.getName());
                            c2.save();
                            d.c("-> Fix was successful (Username: " + c2.getPlayerName() + ") !");
                        } else {
                            d.b("-> Failed as the user never joined the server before");
                        }
                    }
                    c c3 = c2;
                    return c3;
                }
                return null;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.c();
            }
        });
    }

    @Override
    public Future<UUID[]> c() {
        return this.a(new Callable<UUID[]>(){

            public UUID[] a() throws Exception {
                ArrayList<UUID> arrayList = new ArrayList<UUID>();
                for (File file : s.m.listFiles()) {
                    if (!file.getName().endsWith(".yml")) continue;
                    arrayList.add(UUID.fromString(file.getName().replaceFirst(".yml", "")));
                }
                return arrayList.toArray(new UUID[arrayList.size()]);
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    @Override
    public Future<Void> a(final c c2) {
        return this.a(new Callable<Void>(){

            public Void a() throws Exception {
                File file = ed.b(c2.getUUID());
                if (file.exists()) {
                    file.delete();
                }
                return null;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    @Override
    public Future<Void> b(final c c2) {
        return this.a(new Callable<Void>(){

            public Void a() throws Exception {
                try (OutputStreamWriter outputStreamWriter = null;){
                    try {
                        outputStreamWriter = new FileWriter(ed.b(c2.getUUID()));
                        XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
                        XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(outputStreamWriter);
                        xMLStreamWriter.writeStartDocument();
                        xMLStreamWriter.writeStartElement("stats");
                        xMLStreamWriter.writeAttribute("rank", "" + c2.getRank());
                        xMLStreamWriter.writeAttribute("wins", "" + c2.getWins());
                        xMLStreamWriter.writeAttribute("loses", "" + c2.getLoses());
                        xMLStreamWriter.writeAttribute("kills", "" + c2.getKills());
                        xMLStreamWriter.writeAttribute("deaths", "" + c2.getDeaths());
                        xMLStreamWriter.writeAttribute("bedsDestroyed", "" + c2.getBedsDestroyed());
                        xMLStreamWriter.writeAttribute("roundsPlayed", "" + c2.getRoundsPlayed());
                        xMLStreamWriter.writeAttribute("playTime", "" + c2.getPlayTime());
                        xMLStreamWriter.writeAttribute("coins", "" + c2.getCoins());
                        xMLStreamWriter.writeAttribute("finalKills", "" + c2.q());
                        xMLStreamWriter.writeStartElement("user_name");
                        xMLStreamWriter.writeCharacters(c2.getPlayerName() != null ? c2.getPlayerName() : "?");
                        xMLStreamWriter.writeEndElement();
                        xMLStreamWriter.writeStartElement("user_uuid");
                        xMLStreamWriter.writeCharacters(c2.getUUID().toString());
                        xMLStreamWriter.writeEndElement();
                        xMLStreamWriter.writeEndElement();
                        xMLStreamWriter.writeEndDocument();
                        xMLStreamWriter.flush();
                    }
                    catch (IOException | XMLStreamException exception) {
                        exception.printStackTrace();
                        outputStreamWriter.close();
                    }
                }
                return null;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    @Override
    public Future<Boolean> e(final UUID uUID) {
        return this.a(new Callable<Boolean>(){

            @Override
            public Boolean call() throws Exception {
                return ed.c(uUID).exists();
            }
        });
    }

    @Override
    public Future<UserAchievements> f(final UUID uUID) {
        return this.a(new Callable<UserAchievements>(){

            public UserAchievements a() throws Exception {
                if (!ed.c(uUID).exists()) {
                    return null;
                }
                FileInputStream fileInputStream = new FileInputStream(ed.c(uUID));
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                UserAchievements userAchievements = (UserAchievements)objectInputStream.readObject();
                userAchievements.uuid = uUID;
                fileInputStream.close();
                objectInputStream.close();
                return userAchievements;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    @Override
    public Future<Void> a(final UserAchievements userAchievements) {
        return this.a(new Callable<Void>(){

            public Void a() throws Exception {
                File file = ed.c(userAchievements.getUUID());
                if (file.exists()) {
                    file.delete();
                }
                return null;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    @Override
    public Future<Void> b(final UserAchievements userAchievements) {
        return this.a(new Callable<Void>(){

            public Void a() throws Exception {
                FileOutputStream fileOutputStream = new FileOutputStream(ed.c(userAchievements.getUUID()));
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(userAchievements);
                objectOutputStream.close();
                fileOutputStream.close();
                return null;
            }

            @Override
            public /* synthetic */ Object call() throws Exception {
                return this.a();
            }
        });
    }

    private static File b(UUID uUID) {
        return new File(s.m, String.valueOf(uUID.toString()) + ".yml");
    }

    private static File c(UUID uUID) {
        return new File(s.k, String.valueOf(uUID.toString()) + ".cfg");
    }

}

