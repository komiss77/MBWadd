/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerGameModeChangeEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

public class aU {
    public static void a(PlayerGameModeChangeEvent playerGameModeChangeEvent) {
        GameMode gameMode = playerGameModeChangeEvent.getNewGameMode();
        if (ConfigValue.anticheat_enabled && s.a(playerGameModeChangeEvent.getPlayer()) != null && (gameMode == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR)) {
            playerGameModeChangeEvent.setCancelled(true);
        }
    }
}

