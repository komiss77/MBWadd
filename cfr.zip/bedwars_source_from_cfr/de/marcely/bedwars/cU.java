/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayer
 *  de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayerManager
 *  de.simonsator.partyandfriends.spigot.api.party.PartyManager
 *  de.simonsator.partyandfriends.spigot.api.party.PlayerParty
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.AddPlayerFail;
import de.marcely.bedwars.api.event.PlayerJoinArenaEvent;
import de.marcely.bedwars.cR;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.util.s;
import de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayer;
import de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayerManager;
import de.simonsator.partyandfriends.spigot.api.party.PartyManager;
import de.simonsator.partyandfriends.spigot.api.party.PlayerParty;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class cU
extends cR
implements Listener {
    @Override
    public cT a() {
        return cT.w;
    }

    @Override
    public void onEnable() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }

    @Override
    public void onDisable() {
        HandlerList.unregisterAll((Listener)this);
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void a(final PlayerJoinArenaEvent playerJoinArenaEvent) {
        if (playerJoinArenaEvent.getFailReason() != null) {
            return;
        }
        new BukkitRunnable(){

            public void run() {
                Player player = playerJoinArenaEvent.getPlayer();
                Arena arena = s.a(player);
                if (arena == null || arena.getTeamPlayers() <= 1) {
                    return;
                }
                PAFPlayer pAFPlayer = PAFPlayerManager.getInstance().getPlayer(player.getUniqueId());
                if (pAFPlayer == null) {
                    return;
                }
                PlayerParty playerParty = PartyManager.getInstance().getParty(pAFPlayer);
                if (playerParty == null) {
                    return;
                }
                cU.this.a(arena, player, pAFPlayer, playerParty);
            }
        }.runTaskLater((Plugin)MBedwars.a, 1L);
    }

    private void a(Arena arena, Player player, PAFPlayer pAFPlayer, PlayerParty playerParty) {
        TreeMap<Integer, Team> treeMap = new TreeMap<Integer, Team>();
        for (PAFPlayer object : playerParty.getAllPlayers()) {
            if (object == pAFPlayer) continue;
            Team team = arena.a(player);
            treeMap.put(arena.a(team).size(), team);
        }
        for (Map.Entry entry : treeMap.entrySet()) {
            if ((Integer)entry.getKey() >= arena.getPerTeamPlayers()) continue;
            arena.b(player, (Team)((Object)entry.getValue()));
            return;
        }
        treeMap = new TreeMap();
        for (Team team : arena.a().r()) {
            treeMap.put(arena.a(team).size(), team);
        }
        arena.b(player, (Team)((Object)treeMap.get(0)));
    }

}

