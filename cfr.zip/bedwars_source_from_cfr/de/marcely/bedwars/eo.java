/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class eo
extends ex {
    public short a;
    public int version;
    public long e;
    public byte z;

    @Override
    public ey a() {
        return ey.g;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedShort(this.a);
        bufferedWriteStream.writeUnsignedShort(this.version);
        bufferedWriteStream.writeSignedLong(this.e);
        bufferedWriteStream.writeByte(this.z);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
    }
}

