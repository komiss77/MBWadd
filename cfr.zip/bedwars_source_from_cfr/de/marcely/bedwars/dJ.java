/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dI;
import de.marcely.bedwars.game.arena.Arena;
import java.util.List;
import org.bukkit.entity.Player;

public class dJ
extends dI {
    public dJ() {
        super("players");
    }

    @Override
    protected String a(Player player, Arena arena) {
        return "" + arena.getPlayers().size();
    }
}

