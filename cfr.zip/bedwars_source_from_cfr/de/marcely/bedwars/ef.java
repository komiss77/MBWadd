/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.d;
import de.marcely.bedwars.eg;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.e;
import de.marcely.bedwars.util.s;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ef {
    private eg a;
    public final Queue<e<?>> a;
    private boolean isRunning = true;

    public ef(eg eg2) {
        this.a = eg2;
        this.a = new ArrayDeque();
        new MThread(MThread.ThreadType.q, "Type:" + eg2.name()){

            @Override
            public void run() {
                while (ef.this.isRunning) {
                    if (ef.this.a.size() >= 1) {
                        e e2 = null;
                        while ((e2 = (e)ef.this.a.poll()) != null) {
                            if (e2.isDone()) continue;
                            e2.ae();
                        }
                    }
                    s.sleep(50L);
                }
            }
        }.start();
    }

    public void shutdown() {
        if (!this.isConnected()) {
            this.a.clear();
        }
        this.ab();
        this.isRunning = false;
        d.c("Successfully shut down service: " + this.a.name());
    }

    public abstract boolean aa();

    public abstract boolean ab();

    public abstract boolean isConnected();

    public abstract Future<Boolean> d(UUID var1);

    public abstract Future<c> a(UUID var1, String var2);

    public abstract Future<UUID[]> c();

    public abstract Future<Void> a(c var1);

    public abstract Future<Void> b(c var1);

    public abstract Future<Boolean> e(UUID var1);

    public abstract Future<UserAchievements> f(UUID var1);

    public abstract Future<Void> a(UserAchievements var1);

    public abstract Future<Void> b(UserAchievements var1);

    protected <T> Future<T> a(Callable<T> callable) {
        e<T> e2 = new e<T>(callable);
        this.a.add(e2);
        return e2;
    }

    public eg a() {
        return this.a;
    }

}

