/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

public enum eg {
    b,
    c;
    
}

