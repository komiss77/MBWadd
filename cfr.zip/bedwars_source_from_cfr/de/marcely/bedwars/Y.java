/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class Y {
    private static final Random a = new Random();
    private File b = null;
    private a.b<String, Object> a = new a.b();

    public Y(File file) {
        this(file, true);
    }

    public Y(File file, boolean bl2) {
        this.b(file.getAbsolutePath(), bl2);
    }

    public Y(String string, String string2) {
        this(string, string2, true);
    }

    public Y(String string, String string2, boolean bl2) {
        this.b("plugins/" + string + "/" + string2, bl2);
    }

    public void r(String string) {
        ((a.b)((Object)this.a)).put(string, null);
    }

    public void addConfig(String string, Object object) {
        ((a.b)((Object)this.a)).put(string, object);
    }

    public void j(String string, String string2) {
        ((a.b)((Object)this.a)).put(string, string2);
    }

    public void a(String string, boolean bl2) {
        ((a.b)((Object)this.a)).put(string, bl2);
    }

    public void a(String string, Double d2) {
        ((a.b)((Object)this.a)).put(string, d2);
    }

    public void a(String string, int n2) {
        ((a.b)((Object)this.a)).put(string, n2);
    }

    public void addComment(String string) {
        this.j("# " + string, "");
    }

    public String getConfigString(String string) {
        Object object = this.a(string);
        if (object instanceof String) {
            return (String)object;
        }
        return null;
    }

    public Boolean getConfigBoolean(String string) {
        String string2;
        Object object = this.a(string);
        if (object instanceof Boolean) {
            return (boolean)((Boolean)object);
        }
        if (object instanceof String && ((string2 = String.valueOf(object)).equalsIgnoreCase("true") || string2.equalsIgnoreCase("false"))) {
            return Boolean.valueOf(string2);
        }
        return null;
    }

    public Double getConfigDouble(String string) {
        Object object = this.a(string);
        if (object instanceof Double) {
            return (double)((Double)object);
        }
        if (object instanceof Float) {
            return ((Float)object).floatValue();
        }
        if (object instanceof String) {
            return Double.valueOf((String)object);
        }
        return null;
    }

    public Integer getConfigInt(String string) {
        Object object = this.a(string);
        if (object instanceof String && Y.c(String.valueOf(object))) {
            return Integer.valueOf(String.valueOf(object));
        }
        return null;
    }

    public void addEmptyLine() {
        this.j("empty" + a.nextInt(), null);
    }

    public a.b<String, String> a(String string) {
        a.b<String, String> b2 = new a.b<String, String>();
        for (a.a a2 : ((a.b)((Object)this.a)).entrySet()) {
            String string2 = (String)a2.getKey();
            if (!string2.startsWith(string)) continue;
            if (a2.getValue() != null) {
                String string3 = a2.getValue().toString();
                b2.put(string2, string3);
                continue;
            }
            b2.put(string2, null);
        }
        return b2;
    }

    public a.b<String, String> b(String string) {
        a.b<String, String> b2 = new a.b<String, String>();
        for (a.a a2 : ((a.b)((Object)this.a)).entrySet()) {
            String string2 = (String)a2.getKey();
            if (!string2.endsWith(string)) continue;
            if (a2.getValue() != null) {
                String string3 = a2.getValue().toString();
                b2.put(string2, string3);
                continue;
            }
            b2.put(string2, null);
        }
        return b2;
    }

    public a.b<String, String> c(String string) {
        a.b<String, String> b2 = new a.b<String, String>();
        for (a.a a2 : ((a.b)((Object)this.a)).entrySet()) {
            String string2 = (String)a2.getKey();
            if (!string2.equals(string)) continue;
            if (a2.getValue() != null) {
                String string3 = a2.getValue().toString();
                b2.put(string2, string3);
                continue;
            }
            b2.put(string2, null);
        }
        return b2;
    }

    public Object a(String string) {
        return ((a.b)((Object)this.a)).getFirst(string);
    }

    public boolean update() {
        if (!this.b.exists()) {
            this.save();
            return false;
        }
        return true;
    }

    public a.b<String, Object> a(int n2) {
        a.b<String, Object> b2 = new a.b<String, Object>();
        for (a.a a2 : ((a.b)((Object)this.a)).entrySet()) {
            String string = (String)a2.getKey();
            Object object = a2.getValue();
            if (String.valueOf(string).startsWith("# ") || string.split("\\.").length - 1 != n2) continue;
            String string2 = "";
            int n3 = 1;
            int n4 = string.split("\\.").length;
            for (String string3 : string.split("\\.")) {
                while (string3.startsWith("\t")) {
                    string3 = string3.substring(1, string3.length());
                }
                if (n3 >= n4) {
                    string2 = String.valueOf(string2) + string3;
                    continue;
                }
                string2 = String.valueOf(string2) + string3 + ".";
                ++n3;
            }
            if (object instanceof String) {
                String string3;
                string3 = (String)object;
                while (string3.startsWith("\t")) {
                    string3 = string3.substring(1, string3.length());
                }
                object = string3;
            }
            b2.put(string2, object);
        }
        return b2;
    }

    public void save() {
        try {
            this.p();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private void p() throws IOException {
        if (this.b.exists()) {
            this.b.delete();
        }
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter((OutputStream)new FileOutputStream(this.b), "UTF8"));
        ArrayList<String> arrayList = new ArrayList<String>();
        for (a.a a2 : ((a.b)((Object)this.a)).entrySet()) {
            String string = (String)a2.getKey();
            Object obj2 = a2.getValue();
            if (string.startsWith("empty") && obj2 == null) {
                bufferedWriter.write("");
                bufferedWriter.newLine();
                continue;
            }
            if (!String.valueOf(string).startsWith("# ")) {
                if (string.split("\\.").length >= 2) {
                    String string2 = "";
                    for (int i2 = 0; i2 < string.split("\\.").length - 1; ++i2) {
                        string2 = i2 <= string.split("\\.").length - 2 ? String.valueOf(string2) + string.split("\\.")[i2] : String.valueOf(string2) + string.split("\\.")[i2] + ".";
                    }
                    if (arrayList.contains(string2)) continue;
                    bufferedWriter.write(String.valueOf(string2) + " {");
                    bufferedWriter.newLine();
                    for (a.a a3 : ((a.b)((Object)this.a)).entrySet()) {
                        String string3 = (String)a3.getKey();
                        Object obj22 = a3.getValue();
                        if (String.valueOf(string3).startsWith("# ") || string3.split("\\.").length < 2) continue;
                        String string4 = "";
                        for (int i3 = 0; i3 < string3.split("\\.").length - 1; ++i3) {
                            string4 = i3 <= string3.split("\\.").length - 2 ? String.valueOf(string4) + string3.split("\\.")[i3] : String.valueOf(string4) + string3.split("\\.")[i3] + ".";
                        }
                        if (!string2.equals(string4)) continue;
                        String string5 = "";
                        for (int i4 = 0; i4 < string3.split("\\.").length - 1; ++i4) {
                            string5 = String.valueOf(string5) + "\t";
                        }
                        if (obj22 != null) {
                            bufferedWriter.write(String.valueOf(string5) + string3.replace(string2, "").substring(1) + ": " + String.valueOf(obj22));
                        } else {
                            bufferedWriter.write(String.valueOf(string5) + string3.replace(string2, "").substring(1));
                        }
                        bufferedWriter.newLine();
                    }
                    arrayList.add(string2);
                    bufferedWriter.write("");
                    bufferedWriter.newLine();
                    continue;
                }
                if (obj2 != null) {
                    bufferedWriter.write(String.valueOf(string) + ": " + String.valueOf(obj2));
                } else {
                    bufferedWriter.write(string);
                }
                bufferedWriter.newLine();
                continue;
            }
            bufferedWriter.write(string);
            bufferedWriter.newLine();
        }
        bufferedWriter.close();
    }

    public void load() {
        this.b(true);
    }

    public void b(boolean bl2) {
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = !bl2 ? new BufferedReader(new InputStreamReader(new FileInputStream(this.b))) : new BufferedReader(new InputStreamReader((InputStream)new FileInputStream(this.b), "UTF8"));
        }
        catch (Exception exception) {
            System.err.println("[MBedwars] There was an issue with loading a config with utf8.");
            if (!bl2) {
                exception.printStackTrace();
            }
            this.b(false);
        }
        String string = null;
        String string2 = "";
        try {
            this.clear();
            while ((string = bufferedReader.readLine()) != null) {
                Object object;
                boolean bl3 = false;
                if (string.endsWith("{")) {
                    object = string.substring(0, string.length() - 1);
                    while (((String)object).startsWith("\t")) {
                        object = ((String)object).substring(1, ((String)object).length());
                    }
                    while (((String)object).endsWith(" ")) {
                        object = ((String)object).substring(0, ((String)object).length() - 1);
                    }
                    string2 = string2.equals("") ? String.valueOf(string2) + (String)object : String.valueOf(string2) + "." + (String)object;
                    bl3 = true;
                } else if (string.startsWith("") && !string.equals("")) {
                    object = string2.split("\\.");
                    string2 = string2.substring(0, string2.length() - object[((String[])object).length - 1].length());
                    bl3 = true;
                }
                if (bl3) continue;
                object = string.split(":");
                String string3 = object[0];
                String string4 = "";
                if (((String[])object).length >= 2) {
                    for (int i2 = 1; i2 < ((Object)object).length; ++i2) {
                        string4 = i2 > 1 ? String.valueOf(string4) + ":" + (String)object[i2] : String.valueOf(string4) + (String)object[i2];
                    }
                } else {
                    string4 = null;
                }
                if (string4 != null) {
                    while (string4.startsWith("\t") || string4.startsWith(" ")) {
                        string4 = string4.substring(1, string4.length());
                    }
                }
                while (string3.startsWith("\t") || string3.startsWith(" ")) {
                    string3 = string3.substring(1, string3.length());
                }
                if (string2.equals("")) {
                    ((a.b)((Object)this.a)).put(string3, string4);
                    continue;
                }
                ((a.b)((Object)this.a)).put(String.valueOf(string2) + "." + string3, string4);
            }
            bufferedReader.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public List<String> c(String string) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (a.a a2 : ((a.b)this.a(string)).entrySet()) {
            String string2 = String.valueOf(((String)a2.getKey()).replaceFirst(string.endsWith(".") ? string : String.valueOf(string) + ".", "")) + (a2.getValue() != null ? ": " + (String)a2.getValue() : "");
            while (string2.startsWith("\t") || string2.startsWith(" ")) {
                string2 = string2.substring(1, string2.length());
            }
            arrayList.add(string2);
        }
        return arrayList;
    }

    public void clear() {
        ((a.b)((Object)this.a)).clear();
    }

    public boolean exists() {
        return this.b.exists();
    }

    public boolean isEmpty() {
        return this.b.length() == 0L;
    }

    public void setPath(String string) {
        this.b(string, true);
    }

    public void b(String string, boolean bl2) {
        this.b = new File(string);
        File file = this.b.getParentFile();
        if (!file.exists()) {
            file.mkdirs();
        }
        if (bl2 && !this.b.exists()) {
            try {
                this.b.createNewFile();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    public String getPath() {
        return this.b.getPath();
    }

    public File getFile() {
        return this.b;
    }

    public a.b<String, Object> a() {
        return this.a;
    }

    private static boolean c(String string) {
        try {
            Integer.valueOf(string);
            return true;
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static class de.marcely.bedwars.Y$a {

        public static class a<obj1, obj2>
        implements Map.Entry<obj1, obj2> {
            private obj1 b;
            private obj2 c;

            public a(obj1 obj1, obj2 obj2) {
                this.b = obj1;
                this.c = obj2;
            }

            @Override
            public obj1 getKey() {
                return this.b;
            }

            @Override
            public obj2 getValue() {
                return this.c;
            }

            @Override
            public obj2 setValue(obj2 obj2) {
                this.c = obj2;
                return obj2;
            }
        }

        public static class b<obj1, obj2> {
            List<obj1> l1 = new ArrayList<obj1>();
            List<obj2> l2 = new ArrayList<obj2>();

            public b() {
            }

            public b(b<obj1, obj2> b2) {
                this.l1 = new ArrayList<obj1>(b2.l1);
                this.l2 = new ArrayList<obj2>(b2.l2);
            }

            public int size() {
                return this.l1.size();
            }

            public void put(obj1 obj1, obj2 obj2) {
                this.l1.add(obj1);
                this.l2.add(obj2);
            }

            public obj2 getFirst(obj1 obj1) {
                if (this.get(obj1).size() >= 1) {
                    return this.get(obj1).get(0);
                }
                return null;
            }

            public List<obj2> get(obj1 obj1) {
                ArrayList<obj2> arrayList = new ArrayList<obj2>();
                int n2 = 0;
                for (obj1 obj12 : this.l1) {
                    if (obj1.equals(obj12)) {
                        arrayList.add(this.l2.get(n2));
                    }
                    ++n2;
                }
                return arrayList;
            }

            public List<a<obj1, obj2>> entrySet() {
                ArrayList<a<obj1, obj2>> arrayList = new ArrayList<a<obj1, obj2>>();
                int n2 = 0;
                for (obj1 obj1 : new ArrayList<obj1>(this.l1)) {
                    arrayList.add(new a<obj1, obj2>(obj1, this.l2.get(n2)));
                    ++n2;
                }
                return arrayList;
            }

            public void remove(obj1 obj1) {
                int n2 = 0;
                for (obj1 obj12 : this.l1) {
                    if (obj12.equals(obj1)) {
                        this.l1.remove(n2);
                        this.l2.remove(n2);
                    }
                    ++n2;
                }
            }

            public void remove(obj1 obj1, obj2 obj2) {
                int n2 = 0;
                for (obj1 obj12 : new ArrayList<obj1>(this.l1)) {
                    if (obj12.equals(obj1) && this.l2.get(n2).equals(obj2)) {
                        this.l1.remove(n2);
                        this.l2.remove(n2);
                        --n2;
                    }
                    ++n2;
                }
            }

            public boolean containsKey(obj1 obj1) {
                return this.l1.contains(obj1);
            }

            public boolean containsValue(obj2 obj2) {
                return this.l2.contains(obj2);
            }

            public void replace(obj1 obj1, obj2 obj2) {
                this.remove(obj1);
                this.put(obj1, obj2);
            }

            public List<obj1> keySet() {
                return new ArrayList<obj1>(this.l1);
            }

            public List<obj2> values() {
                return new ArrayList<obj2>(this.l2);
            }

            public boolean removeFirst() {
                if (this.size() >= 1) {
                    this.l1.remove(0);
                    this.l2.remove(0);
                    return true;
                }
                return false;
            }

            public boolean removeLast() {
                if (this.size() >= 1) {
                    this.l1.remove(this.l1.size() - 1);
                    this.l2.remove(this.l2.size() - 2);
                    return true;
                }
                return false;
            }

            public void clear() {
                this.l1.clear();
                this.l2.clear();
            }
        }

    }

}

