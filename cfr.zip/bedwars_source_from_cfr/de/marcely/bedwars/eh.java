/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ei;
import de.marcely.bedwars.ej;
import de.marcely.bedwars.ek;
import de.marcely.bedwars.el;
import de.marcely.bedwars.em;
import de.marcely.bedwars.en;
import de.marcely.bedwars.ep;
import de.marcely.bedwars.er;
import de.marcely.bedwars.et;
import de.marcely.bedwars.eu;
import de.marcely.bedwars.ev;
import de.marcely.bedwars.ew;
import de.marcely.bedwars.ex;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.versions.Version;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class eh
extends ek {
    private final el a;
    private boolean ap = false;

    public eh(el el2) {
        this.a = el2;
    }

    @Override
    public void a(et et2) {
        switch (et2.reply) {
            case -1: {
                this.a.a(ej.d);
                eu eu2 = new eu();
                eu2.ac = Bukkit.getBukkitVersion();
                eu2.ad = Version.a().a().name();
                Plugin[] arrplugin = Bukkit.getPluginManager().getPlugins();
                eu2.a = new eu.a[arrplugin.length];
                for (int i2 = 0; i2 < arrplugin.length; ++i2) {
                    eu2.a[i2] = eu.a.a(arrplugin[i2]);
                }
                try {
                    eu2.b = NetworkInterface.getByInetAddress(InetAddress.getLocalHost()).getHardwareAddress();
                    if (eu2.b.length > 32) {
                        eu2.b = null;
                    }
                }
                catch (Exception exception) {
                    // empty catch block
                }
                this.a.a(eu2);
                break;
            }
            case 1: {
                this.a.a(ei.a.d);
                break;
            }
            case 3: {
                this.a.a(ei.a.e);
                break;
            }
            default: {
                this.a.a(ei.a.c);
            }
        }
    }

    @Override
    public void a(ev ev2) {
        switch (ev2.reply) {
            case -1: {
                this.a.a(ej.a);
                this.a.a().onConnect();
                break;
            }
            case 1: {
                this.a.a(ei.a.b);
                break;
            }
            default: {
                this.a.a(ei.a.c);
            }
        }
    }

    @Override
    public void a(er er2) {
        if (!this.ap) {
            this.ap = true;
            this.a.a().a(er2.a);
        }
    }

    @Override
    public void a(ep ep2) {
        em em2 = this.a.ae.get(ep2.z);
        if (em2 != null) {
            this.a.ae.remove(ep2.z);
            em2.a(ep2.data, this.a.ae.size());
        }
    }

    @Override
    public void a(en en2) {
        this.a.a().a(en2.name.length() > 1, en2.name);
    }

    @Override
    public void a(ew ew2) {
        switch (ew2.L) {
            case 0: {
                de.marcely.bedwars.d.m("SERVER MESSAGE: " + ew2.message);
                break;
            }
            case 16: {
                de.marcely.bedwars.d.n("SERVER MESSAGE: " + ew2.message);
                break;
            }
            case 17: {
                de.marcely.bedwars.d.n("SERVER MESSAGE: " + ew2.message);
                break;
            }
        }
    }
}

