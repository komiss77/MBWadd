/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.io.netty.channel.Channel
 *  net.minecraft.util.io.netty.channel.ChannelHandler
 *  net.minecraft.util.io.netty.channel.ChannelHandlerContext
 *  net.minecraft.util.io.netty.channel.ChannelPipeline
 *  net.minecraft.util.io.netty.handler.codec.MessageToMessageDecoder
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.aa;
import de.marcely.bedwars.versions.NMSClass;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import net.minecraft.util.io.netty.channel.Channel;
import net.minecraft.util.io.netty.channel.ChannelHandler;
import net.minecraft.util.io.netty.channel.ChannelHandlerContext;
import net.minecraft.util.io.netty.channel.ChannelPipeline;
import net.minecraft.util.io.netty.handler.codec.MessageToMessageDecoder;
import org.bukkit.entity.Player;

@Deprecated
public class ab
implements aa.b {
    @Override
    public void a(final aa.c c2) {
        try {
            final aa.c c3 = c2;
            Object obj = NMSClass.m.cast((Object)c2.player);
            Object object = obj.getClass().getMethod("getHandle", new Class[0]).invoke(obj, new Object[0]);
            Object object2 = object.getClass().getDeclaredField("playerConnection").get(object);
            Object object3 = object2.getClass().getDeclaredField("networkManager").get(object2);
            Field field = object3.getClass().getDeclaredField("m");
            field.setAccessible(true);
            ChannelPipeline channelPipeline = ((Channel)field.get(object3)).pipeline();
            MessageToMessageDecoder<Object> messageToMessageDecoder = new MessageToMessageDecoder<Object>(){

                protected void decode(ChannelHandlerContext channelHandlerContext, Object object, List<Object> list) throws Exception {
                    block6 : {
                        try {
                            if (!NMSClass.H.isInstance(object)) break block6;
                            Field field = NMSClass.H.getDeclaredField("a");
                            field.setAccessible(true);
                            int n2 = field.getInt(object);
                            for (aa aa2 : c3.u) {
                                if (aa2.getEntityId() != n2) continue;
                                field = NMSClass.H.getDeclaredField("action");
                                field.setAccessible(true);
                                Object object2 = field.get(object);
                                String string = (String)object2.getClass().getMethod("name", new Class[0]).invoke(object2, new Object[0]);
                                if (string.equals("INTERACT")) {
                                    for (aa.a a2 : aa2.i()) {
                                        a2.g(c2.player);
                                    }
                                    continue;
                                }
                                if (!string.equals("ATTACK")) continue;
                                for (aa.a a2 : aa2.i()) {
                                    a2.h(c2.player);
                                }
                            }
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }
                    list.add(object);
                }
            };
            try {
                channelPipeline.addAfter("decoder", "MBedwars_IM", (ChannelHandler)messageToMessageDecoder);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                channelPipeline.remove(channelPipeline.get("MBedwars_IM"));
                channelPipeline.addAfter("decoder", "MBedwars_IM", (ChannelHandler)messageToMessageDecoder);
            }
            c2.d = channelPipeline;
            c2.e = messageToMessageDecoder;
        }
        catch (IllegalAccessException | NoSuchFieldException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
        }
    }

}

