/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.ak;
import de.marcely.bedwars.al;
import de.marcely.bedwars.bp;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.regeneration.RegionData;
import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

@Deprecated
public class aj {
    private Arena arena;
    private BukkitRunnable a;
    private int regenerationSpeed;
    private CommandSender sender;
    private boolean running = false;
    private int x;
    private int y;
    private int z;
    private int xMax;
    private int yMax;
    private int B;
    private long d = -1L;

    public aj(Arena arena, int n2, CommandSender commandSender) {
        this.arena = arena;
        this.regenerationSpeed = n2;
        this.sender = commandSender;
    }

    public void b(int n2) {
        this.regenerationSpeed = n2;
    }

    public Arena getArena() {
        return this.arena;
    }

    public int getRegenerationSpeed() {
        return this.regenerationSpeed;
    }

    public boolean isRunning() {
        return this.running;
    }

    public boolean cancel() {
        if (this.isRunning()) {
            this.running = false;
            if (this.a != null) {
                this.a.cancel();
            }
            if (this.sender != null) {
                s.a(this.sender, de.marcely.bedwars.message.b.a(Language.Regeneration_Stopped).a("arena", this.arena.getName()).a("time", "" + (double)(System.currentTimeMillis() - this.d) / 1000.0));
            }
            return true;
        }
        return false;
    }

    public boolean run() {
        if (!this.isRunning()) {
            this.running = true;
            this.arena.a(ArenaStatus.g, true);
            if (this.arena.a() == RegenerationType.c) {
                this.x = (int)this.arena.getPosMin().getX();
                this.y = (int)this.arena.getPosMin().getY();
                this.z = (int)this.arena.getPosMin().getZ();
                this.xMax = (int)this.arena.getPosMax().getX();
                this.yMax = (int)this.arena.getPosMax().getY();
                this.B = (int)this.arena.getPosMax().getZ();
            }
            this.q();
            return true;
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void q() {
        boolean bl2 = false;
        aj aj2 = this;
        synchronized (aj2) {
            bl2 = true;
        }
        if (!bl2) {
            new bp().printStackTrace();
            return;
        }
        if (this.arena.getWorld() == null) {
            d.b("There's a problem with the world by the arena '" + this.arena.getName() + "'!!");
            this.arena.a(ArenaStatus.e);
            return;
        }
        if (!ak.exists(this.arena.getName())) {
            d.b("Missing '/MBedwars/arenablocks/" + this.arena.getName() + ".yml' file!!");
            this.arena.a(ArenaStatus.e);
            return;
        }
        this.d = System.currentTimeMillis();
        if (this.arena.a() == RegenerationType.c) {
            ak.a(new ak.a(){

                @Override
                public void a(final RegionData regionData) {
                    if (regionData == null) {
                        d.b("The file '/MBedwars/arenablocks/" + aj.this.arena.getName() + ".yml' is corrupted!!");
                        aj.this.arena.a(ArenaStatus.e);
                        b.b(aj.this.arena);
                        return;
                    }
                    if (regionData.getBlocks().size() == 0) {
                        d.b("The file '/MBedwars/arenablocks/" + aj.this.arena.getName() + ".yml' is empty!!");
                        aj.this.arena.a(ArenaStatus.e);
                        b.b(aj.this.arena);
                        return;
                    }
                    final List<al.b> list = al.b.a(regionData.getBlocks());
                    aj.a(aj.this, new BukkitRunnable(){
                        int C = 0;
                        int D;
                        int E;
                        int F;
                        int G;
                        int H;
                        int I;
                        boolean p;
                        {
                            this.D = (int)aj.this.arena.getPosMin().getX();
                            this.E = (int)aj.this.arena.getPosMin().getY();
                            this.F = (int)aj.this.arena.getPosMin().getZ();
                            this.G = 0;
                            this.H = -1;
                            this.I = 0;
                            this.p = false;
                        }

                        public void run() {
                            if (this.C == 0) {
                                for (Entity entity : aj.this.arena.getWorld().getEntities()) {
                                    if (entity.getType() == EntityType.PLAYER || entity.getType() == EntityType.DROPPED_ITEM || !aj.this.arena.isInside(entity.getLocation())) continue;
                                    entity.remove();
                                }
                                ++this.C;
                            } else if (this.C == 1) {
                                for (int i2 = 0; i2 < ConfigValue.regeneration_speed_ms; ++i2) {
                                    ++this.D;
                                    if ((double)this.D > aj.this.arena.getPosMax().getX()) {
                                        this.D = (int)aj.this.arena.getPosMin().getX();
                                        ++this.E;
                                    }
                                    if ((double)this.E > aj.this.arena.getPosMax().getY()) {
                                        this.E = (int)aj.this.arena.getPosMin().getY();
                                        ++this.F;
                                    }
                                    if ((double)this.F > aj.this.arena.getPosMax().getZ()) {
                                        ++this.C;
                                        return;
                                    }
                                    Version.a().a(new Location(aj.this.arena.getWorld(), (double)this.D, (double)this.E, (double)this.F), Material.AIR, (byte)0);
                                }
                            } else if (this.C == 2) {
                                if (this.G < regionData.getBlocks().size()) {
                                    int n2 = this.G + ConfigValue.regeneration_speed_ms;
                                    if (n2 > regionData.getBlocks().size()) {
                                        n2 = regionData.getBlocks().size();
                                    }
                                    for (int i3 = this.G; i3 < n2; ++i3) {
                                        if (i3 % 50000 == 0) {
                                            ++this.H;
                                        }
                                        RBlock rBlock = ((al.b)list.get((int)this.H)).blocks.get(i3 - this.H * 50000);
                                        try {
                                            rBlock.a(aj.this.arena.getWorld(), aj.this.arena);
                                            continue;
                                        }
                                        catch (Exception exception) {
                                            d.b("[Regeneration] Skipped block placement at X" + rBlock.getX() + " Y" + rBlock.getY() + " Z" + rBlock.getZ() + " in arena " + aj.this.arena.getName());
                                        }
                                    }
                                    this.G = n2;
                                } else {
                                    ++this.C;
                                }
                            } else if (this.C == 3) {
                                REntity rEntity;
                                int n3 = aj.this.regenerationSpeed / 25000;
                                if (n3 <= 0) {
                                    n3 = 1;
                                }
                                boolean bl2 = false;
                                for (int i4 = 0; i4 < n3; ++i4) {
                                    int n4 = this.I + i4;
                                    if (n4 >= regionData.getEntities().size()) {
                                        bl2 = true;
                                        break;
                                    }
                                    rEntity = regionData.getEntities().get(n4);
                                    try {
                                        rEntity.a(aj.this.arena.getWorld());
                                        continue;
                                    }
                                    catch (Exception exception) {
                                        d.b("[Regeneration] Skipped entity type " + rEntity.getType().name() + " in arena " + aj.this.arena.getName());
                                    }
                                }
                                this.I += n3;
                                if (bl2) {
                                    for (REntity rEntity2 : regionData.getEntities()) {
                                        if (rEntity2.b() == null || rEntity2.a() == null || (rEntity = regionData.a(rEntity2.b())).a() == null) continue;
                                        rEntity2.a().setPassenger(rEntity.a());
                                    }
                                    ++this.C;
                                }
                            } else if (this.C == 4) {
                                if (!this.p) {
                                    this.p = true;
                                    final List<Chunk> list2 = aj.this.arena.m();
                                    new MThread(MThread.ThreadType.m, aj.this.arena.getName()){

                                        @Override
                                        public void run() {
                                            ArrayList<Player> arrayList = new ArrayList<Player>();
                                            for (Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(aj.this.arena.a().toBukkit(aj.this.arena.getWorld()), Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16)) {
                                                if (entity.getType() != EntityType.PLAYER) continue;
                                                arrayList.add((Player)entity);
                                            }
                                            new de.marcely.bedwars.aj$1$1$1$1(list2, arrayList);
                                            ++C;
                                        }

                                    }.start();
                                }
                            } else if (this.C == 5) {
                                aj.a(aj.this, false);
                                aj.this.r();
                                aj.this.arena.a().reset();
                                this.cancel();
                                aj.this.arena.a(ArenaStatus.e);
                                b.b(aj.this.arena);
                            }
                        }

                    });
                    aj.this.a.runTaskTimer((Plugin)MBedwars.a, 0L, (long)ConfigValue.performance.v);
                }

            }, null, this.arena);
        } else if (this.arena.a() == RegenerationType.d) {
            aj2 = de.marcely.bedwars.game.regeneration.d.a(this.arena.getWorld(), new File("plugins/MBedwars/data/arenablocks/" + this.arena.getName() + ".yml"));
            new de.marcely.bedwars.aj$2((World)aj2);
        }
    }

    private void r() {
        if (this.sender != null) {
            s.a(this.sender, de.marcely.bedwars.message.b.a(Language.Regeneration_Done).a("arena", this.arena != null ? this.arena.getName() : "Unkown").a("time", "" + (double)(System.currentTimeMillis() - this.d) / 1000.0));
        }
    }

    static /* synthetic */ void a(aj aj2, boolean bl2) {
        aj2.running = bl2;
    }

    static /* synthetic */ void a(aj aj2, BukkitRunnable bukkitRunnable) {
        aj2.a = bukkitRunnable;
    }

}

