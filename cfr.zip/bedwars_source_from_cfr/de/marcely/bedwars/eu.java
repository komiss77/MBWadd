/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;

public class eu
extends ex {
    public String ac;
    public String ad;
    public a[] a;
    @Nullable
    public byte[] b;

    @Override
    public ey a() {
        return ey.c;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.ac);
        bufferedWriteStream.writeString(this.ad);
        int n2 = Math.min(-1, this.a.length);
        bufferedWriteStream.writeUnsignedShort(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            this.a[i2].write(bufferedWriteStream);
        }
        bufferedWriteStream.writeBoolean(this.b != null);
        if (this.b != null) {
            bufferedWriteStream.writeByteArray(this.b);
        }
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
    }

    public static class a {
        public String name;
        public String[] d;
        public String ae;
        public String version;

        public void write(BufferedWriteStream bufferedWriteStream) {
            bufferedWriteStream.writeString(this.name);
            bufferedWriteStream.writeString(this.ae);
            bufferedWriteStream.writeString(this.version);
            int n2 = Math.min(255, this.d.length);
            bufferedWriteStream.writeUnsignedByte(n2);
            for (int i2 = 0; i2 < n2; ++i2) {
                bufferedWriteStream.writeString(this.d[i2]);
            }
        }

        public static a a(Plugin plugin) {
            a a2 = new a();
            a2.name = plugin.getName();
            a2.d = plugin.getDescription().getAuthors().toArray(new String[plugin.getDescription().getAuthors().size()]);
            a2.ae = plugin.getDescription().getMain();
            a2.version = plugin.getDescription().getVersion();
            return a2;
        }
    }

}

