/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.config.e;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.i;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.n;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class cM
extends cJ {
    public cM(g g2, Location location) {
        super(g2, location);
    }

    @Override
    public i a() {
        return i.c;
    }

    @Override
    protected void D(Player player) {
        this.a(player, list -> {
            this.f((List<String>)list);
            super.D(player);
        });
    }

    private void a(final Player player, final n<List<String>> n2) {
        Future<c> future = c.a(player);
        s.a(future, new Runnable(){

            @Override
            public void run() {
                try {
                    c c2 = c.a(player).get();
                    ArrayList<String> arrayList = new ArrayList<String>();
                    for (String string : e.m) {
                        arrayList.add(string.replace("{player}", player.getName()).replace("{kd}", "" + c2.b()).replace("{wl}", "" + c2.a()).replace("{wins}", "" + c2.getWins()).replace("{loses}", "" + c2.getLoses()).replace("{kills}", "" + c2.getKills()).replace("{deaths}", "" + c2.getDeaths()).replace("{bedsdestroyed}", "" + c2.getBedsDestroyed()).replace("{roundsplayed}", "" + c2.getRoundsPlayed()).replace("{playtime}", s.a(c2.getPlayTime())).replace("{uuid}", player.getUniqueId().toString()).replace("{world}", player.getWorld().getName()).replace("{rank}", "" + (c2.getRank() != -1 ? Integer.valueOf(c2.getRank()) : b.a(Language.Ranking_Unranked).f((CommandSender)player))));
                    }
                    n2.call(arrayList);
                }
                catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

}

