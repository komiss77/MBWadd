/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.event.world.WorldLoadEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.IEntity;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.location.XYZYPW;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.util.s;
import java.util.Collection;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.world.WorldLoadEvent;

public class bj {
    public static void a(WorldLoadEvent worldLoadEvent) {
        World world = worldLoadEvent.getWorld();
        for (Arena object2 : s.af) {
            if (!(object2.getWorld() != null && object2.getWorld().getName().equals(object2.C) && Bukkit.getWorld((String)world.getName()).equals((Object)object2.getWorld()) || !object2.C.equals(world.getName()))) {
                object2.setWorld(world);
            }
            if (object2.D == null || !world.getName().equals(object2.D)) continue;
            object2.getLobby().setWorld(world);
        }
        for (List list : s.U.values()) {
            for (Object object : list) {
                c<?> c2 = ((IEntity)object).a();
                if (c2 == null || !((IEntity)object).a().getWorldString().equals(world.getName())) continue;
                c2.getLocation().setWorld(world);
                ((IEntity)object).a().setWorld(world);
                c2.Q();
            }
        }
        if (s.V.containsKey(world.getName())) {
            List list = (List)s.V.get(world.getName());
            s.V.remove(world.getName());
            for (Object iEntity : list) {
                s.a((IEntity)iEntity);
            }
        }
    }
}

