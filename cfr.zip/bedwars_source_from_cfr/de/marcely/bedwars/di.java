/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  cloud.evaped.nickapi.api.APIManager
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import cloud.evaped.nickapi.api.APIManager;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import java.util.UUID;
import org.bukkit.entity.Player;

public class di
extends dg {
    private static /* synthetic */ int[] q;

    @Override
    public cT a() {
        return cT.r;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void a(Player player, df df2) {
        switch (di.r()[df2.ordinal()]) {
            case 1: {
                this.c(player, ConfigValue.coins_give_win);
                break;
            }
            case 2: {
                this.c(player, ConfigValue.coins_give_lose);
                break;
            }
            case 3: {
                this.c(player, ConfigValue.coins_give_beddestroy);
                break;
            }
            case 4: {
                this.c(player, ConfigValue.coins_give_killplayer);
            }
        }
    }

    private void c(Player player, int n2) {
        APIManager.getCoinsAPI().addCoins(player.getUniqueId(), n2);
    }

    static /* synthetic */ int[] r() {
        if (q != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[df.values().length];
        try {
            arrn[df.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        q = arrn;
        return q;
    }
}

