/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.metadata.Metadatable
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.plugin.Plugin;

public class bG
extends by {
    private static final String F = "MBW_EI_TRACK_LAST_USE_AS";
    private static final String G = "MBW_EI_TRACK_ANTI_SPAM_AS";

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = playerUseExtraItemEvent.getPlayer();
        Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        Long l2 = s.a((Metadatable)player, F, 0L);
        Long l3 = s.a((Metadatable)player, G, 0L);
        if (System.currentTimeMillis() - l3 <= 1000L) {
            this.done();
            return;
        }
        player.setMetadata(G, (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        if (System.currentTimeMillis() - l2 <= (long)((int)(ConfigValue.tracker_delay * 1000.0))) {
            s.a((CommandSender)player, b.a(Language.Tracker_ReuseDelay).a("time", "" + (int)(ConfigValue.tracker_delay - (double)((System.currentTimeMillis() - l2) / 1000L))));
            this.done();
            return;
        }
        player.setMetadata(F, (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        s.a(player, Achievement.s);
        Player player2 = s.a(arena, player);
        this.done();
        if (player2 != null) {
            player.setCompassTarget(player2.getLocation());
            s.a((CommandSender)player, b.a(Language.Tracker_TrackedPlayer));
        } else {
            s.a((CommandSender)player, b.a(Language.Tracker_Failed_OnlyOne));
        }
    }

    @Override
    public void K() {
    }
}

