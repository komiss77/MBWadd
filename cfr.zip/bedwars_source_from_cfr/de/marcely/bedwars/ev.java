/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class ev
extends ex {
    public static final byte REPLY_SUCCESS = -1;
    public static final byte C = 0;
    public static final byte G = 1;
    public byte reply;

    @Override
    public ey a() {
        return ey.d;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.reply = bufferedReadStream.readByte();
    }
}

