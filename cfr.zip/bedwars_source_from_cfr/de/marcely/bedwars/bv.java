/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.api.ExtraItemListener;
import de.marcely.bedwars.bw;
import de.marcely.bedwars.bx;
import org.bukkit.inventory.ItemStack;

public class bv
extends ExtraItem {
    private final bx a;

    public bv(bx bx2, ItemStack itemStack) {
        super(bx2.name().toLowerCase().replace("_", " "), itemStack);
        this.a = bx2;
        this.registerListener(bw.a);
    }

    public bx a() {
        return this.a;
    }
}

