/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.lang.invoke.LambdaMetafactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.OptionalInt;
import java.util.Random;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.bukkit.entity.Player;

@Deprecated
public class W {
    private static Arena a;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static List<Arena> b(String var0) {
        block22 : {
            block17 : {
                block19 : {
                    block21 : {
                        block18 : {
                            block20 : {
                                var1_1 = new ArrayList<Arena>();
                                var2_2 = 0;
                                var3_3 = var0;
                                switch (var3_3.hashCode()) {
                                    case -1979792251: {
                                        if (!var3_3.equals("%best_lobby%")) {
                                            ** break;
                                        }
                                        break block17;
                                    }
                                    case -1889869599: {
                                        if (!var3_3.equals("%random_lobby_joinable%")) {
                                            ** break;
                                        }
                                        break block18;
                                    }
                                    case -1432163194: {
                                        if (!var3_3.equals("%random_lobby_running%")) {
                                            ** break;
                                        }
                                        break block19;
                                    }
                                    case 289245702: {
                                        if (!var3_3.equals("%random_lobby%")) {
                                            ** break;
                                        }
                                        break block20;
                                    }
                                    case 1037381629: {
                                        if (var3_3.equals("%random%")) break;
                                        ** break;
                                    }
                                    case 1985087575: {
                                        if (!var3_3.equals("%random_ingame%")) {
                                            ** break;
                                        }
                                        break block21;
                                    }
                                }
                                var2_2 |= 1;
                                ** break;
                            }
                            var2_2 |= 5;
                            ** break;
                        }
                        var2_2 |= 21;
                        ** break;
                    }
                    var2_2 |= 9;
                    ** break;
                }
                var2_2 |= 13;
                ** break;
            }
            var2_2 |= 3;
lbl44: // 13 sources:
            if (var2_2 & true) break block22;
            var5_4 = s.af.iterator();
            ** GOTO lbl54
        }
        var5_5 = s.af.iterator();
        ** GOTO lbl60
lbl-1000: // 1 sources:
        {
            var4_6 = var5_4.next();
            if (!var4_6.getName().equalsIgnoreCase(var0)) continue;
            var1_1.add(var4_6);
lbl54: // 3 sources:
            ** while (var5_4.hasNext())
        }
lbl55: // 1 sources:
        return var1_1;
lbl-1000: // 1 sources:
        {
            var4_7 = var5_5.next();
            if ((var2_2 & 16) == 16 && var4_7.getPlayers().size() >= var4_7.getMaxPlayers() || (var2_2 & 4) == 4 && var4_7.b() != ArenaStatus.e || (var2_2 & 8) == 8 && var4_7.b() != ArenaStatus.f) continue;
            var1_1.add(var4_7);
lbl60: // 3 sources:
            ** while (var5_5.hasNext())
        }
lbl61: // 1 sources:
        if (var1_1.size() < 2) return var1_1;
        if ((var2_2 & 2) == 0) {
            return Arrays.asList(new Arena[]{(Arena)var1_1.get(s.RAND.nextInt(var1_1.size()))});
        }
        var4_8 = var1_1.stream().map((Function<Arena, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, a(de.marcely.bedwars.game.arena.Arena ), (Lde/marcely/bedwars/game/arena/Arena;)Ljava/lang/Integer;)()).mapToInt((ToIntFunction<Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)I, a(java.lang.Integer ), (Ljava/lang/Integer;)I)()).max().orElse(-1);
        var5_5 = var1_1.iterator();
        while (var5_5.hasNext()) {
            if (var5_5.next().getPlayers().size() == var4_8) continue;
            var5_5.remove();
        }
        if (W.a != null && var1_1.contains(W.a)) return Arrays.asList(new Arena[]{W.a});
        W.a = (Arena)var1_1.get(s.RAND.nextInt(var1_1.size()));
        return Arrays.asList(new Arena[]{W.a});
    }

    private static /* synthetic */ Integer a(Arena arena) {
        return arena.getPlayers().size();
    }

    private static /* synthetic */ int a(Integer n2) {
        return n2;
    }
}

