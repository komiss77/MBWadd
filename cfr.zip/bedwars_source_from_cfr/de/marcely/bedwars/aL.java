/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.SimpleGUI;
import java.util.List;
import java.util.Map;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class aL {
    public static void a(InventoryCloseEvent inventoryCloseEvent) {
        final Player player = (Player)inventoryCloseEvent.getPlayer();
        if (GUI.openInventories.containsKey((Object)player)) {
            if (GUI.cachePlayers.contains((Object)player)) {
                GUI.cachePlayers.remove((Object)player);
            } else {
                ((SimpleGUI)GUI.openInventories.remove((Object)player)).onClose(player);
            }
            if (GUI.openInventoriesDelayed.containsKey((Object)player)) {
                new BukkitRunnable(){

                    public void run() {
                        GUI.openInventoriesDelayed.remove((Object)player);
                    }
                }.runTaskLater((Plugin)MBedwars.a, 1L);
            }
        }
    }

}

