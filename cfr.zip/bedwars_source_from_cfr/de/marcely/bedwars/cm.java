/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.m;

public abstract class cm
extends bS<m> {
    @Override
    public bP.c a() {
        return bP.c.b;
    }

    @Override
    public String c(Arena arena) {
        return null;
    }
}

