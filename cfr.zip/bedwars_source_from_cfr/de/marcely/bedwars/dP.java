/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dR;
import de.marcely.bedwars.game.stats.c;

public class dP
extends dR {
    public dP() {
        super("kills");
    }

    @Override
    public String c(c c2) {
        return "" + c2.getKills();
    }
}

