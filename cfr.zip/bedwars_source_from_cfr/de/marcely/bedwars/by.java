/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public abstract class by {
    private PlayerUseExtraItemEvent a;

    protected abstract void onUse(PlayerUseExtraItemEvent var1);

    public abstract void K();

    public void a(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        this.a = playerUseExtraItemEvent;
        this.onUse(playerUseExtraItemEvent);
        if (this.isActive()) {
            ((Arena)playerUseExtraItemEvent.getArena()).N.add(this);
        }
    }

    public boolean isActive() {
        return this.a != null;
    }

    public void stop() {
        this.done();
    }

    protected void done() {
        if (!this.isActive()) {
            return;
        }
        ((Arena)this.a.getArena()).N.remove(this);
        this.a = null;
        this.K();
    }

    protected void L() {
        s.a(this.a.getPlayer(), this.a.getExtraItem().getItemStack(1), this.a.getPlayer().getInventory().getHeldItemSlot());
    }
}

