/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.musterbukkit.replaysystem.main.ReplayAPI
 *  org.bukkit.Location
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.event.RoundEndEvent;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cR;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.musterbukkit.replaysystem.main.ReplayAPI;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class cX
extends cR
implements Listener {
    @Override
    public cT a() {
        return cT.y;
    }

    @Override
    public void onEnable() {
        if (!ConfigValue.autojoin_enabled) {
            return;
        }
        Arena arena = s.b(ConfigValue.autojoin_arena);
        if (arena == null) {
            return;
        }
        ReplayAPI.setSpectatorLocation((Location)cA.a(arena));
        ReplayAPI.setMapName((String)arena.getName());
    }

    @Override
    public void onDisable() {
    }

    @EventHandler
    public void a(RoundEndEvent roundEndEvent) {
        ReplayAPI.createSnapshot((Integer)((int)(roundEndEvent.getArena().getRunningTime() / 1000L)));
    }
}

