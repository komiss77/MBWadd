/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  me.jumper251.replay.api.ReplayAPI
 *  me.jumper251.replay.replaysystem.Replay
 *  me.jumper251.replay.replaysystem.recording.Recorder
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.ArenaStatus;
import de.marcely.bedwars.api.event.ArenaStatusUpdateEvent;
import de.marcely.bedwars.cR;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import me.jumper251.replay.api.ReplayAPI;
import me.jumper251.replay.replaysystem.Replay;
import me.jumper251.replay.replaysystem.recording.Recorder;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class cO
extends cR
implements Listener {
    private final Map<Arena, Replay> I = new HashMap<Arena, Replay>();

    @Override
    public cT a() {
        return cT.x;
    }

    @Override
    public void onEnable() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }

    @Override
    public void onDisable() {
        HandlerList.unregisterAll((Listener)this);
        for (Replay replay : this.I.values()) {
            if (!replay.isRecording()) continue;
            replay.getRecorder().stop(true);
        }
        this.I.clear();
    }

    @EventHandler
    public void a(ArenaStatusUpdateEvent arenaStatusUpdateEvent) {
        Arena arena = (Arena)arenaStatusUpdateEvent.getArena();
        this.e(arena);
        if (arenaStatusUpdateEvent.getStatus() == ArenaStatus.Running) {
            this.d(arena);
        }
    }

    private void d(Arena arena) {
        String string = "MBW: " + arena.getName() + " [" + s.a(new Date(), "MM.dd.yyyy hh:mm") + "]";
        Replay replay = ReplayAPI.getInstance().recordReplay(string, null, (Player[])arena.getPlayers().stream().toArray(n2 -> new Player[n2]));
        this.I.put(arena, replay);
    }

    private void e(Arena arena) {
        Replay replay = this.I.get(arena);
        if (replay == null) {
            return;
        }
        if (replay.isRecording()) {
            replay.getRecorder().stop(true);
        }
        this.I.remove(arena);
    }
}

