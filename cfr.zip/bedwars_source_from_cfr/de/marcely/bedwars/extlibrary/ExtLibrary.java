/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.extlibrary;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ExtLibrary
extends Enum<ExtLibrary> {
    public static final /* enum */ ExtLibrary a = new ExtLibrary(0, true);
    public static final /* enum */ ExtLibrary b = new ExtLibrary(1, true);
    public static final /* enum */ ExtLibrary c = new ExtLibrary(2, false);
    public static final /* enum */ ExtLibrary d = new ExtLibrary(3, false);
    private final short a;
    private final boolean v;
    public boolean loaded = false;
    private static final /* synthetic */ ExtLibrary[] a;

    static {
        a = new ExtLibrary[]{a, b, c, d};
    }

    private ExtLibrary(int n3, boolean bl2) {
        this.a = (short)n3;
        this.v = bl2;
    }

    public short getId() {
        return this.a;
    }

    public boolean y() {
        return this.v;
    }

    public static ExtLibrary[] values() {
        ExtLibrary[] arrextLibrary = a;
        int n2 = arrextLibrary.length;
        ExtLibrary[] arrextLibrary2 = new ExtLibrary[n2];
        System.arraycopy(arrextLibrary, 0, arrextLibrary2, 0, n2);
        return arrextLibrary2;
    }

    public static ExtLibrary valueOf(String string) {
        return Enum.valueOf(ExtLibrary.class, string);
    }
}

