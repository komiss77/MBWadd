/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.extlibrary;

import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.sql.EmptySQLTask;
import de.marcely.bedwars.sql.SQLConnection;
import de.marcely.bedwars.sql.SQLResult;
import de.marcely.bedwars.sql.SQLTask;
import de.marcely.bedwars.sql.SQLType;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;

public class b
implements Closeable,
AutoCloseable {
    private final SQLConnection a;

    public b(File file) {
        this.a = new SQLConnection(SQLType.SQLite, file, true);
        this.a.doLog = false;
    }

    @Override
    public void close() throws IOException {
        this.a.disconnect();
    }

    public boolean connect(final Runnable runnable) {
        return this.a.connect(new Runnable(){

            @Override
            public void run() {
                b.this.init();
                runnable.run();
            }
        });
    }

    private void init() {
        try {
            this.a.doTask(new EmptySQLTask("CREATE TABLE IF NOT EXISTS InstalledLibraries(ID SMALLINT NOT NULL,Name VARCHAR(32) NOT NULL,Version UNSIGNED SMALLINT NOT NULL,Checksum BIGINT NOT NULL)", false));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public Collection<d> a() {
        try {
            SQLResult sQLResult = this.a.doTask(new EmptySQLTask("SELECT * FROM InstalledLibraries", true));
            ResultSet resultSet = sQLResult.getResult();
            ArrayList<d> arrayList = new ArrayList<d>();
            while (resultSet.next()) {
                d d2 = new d();
                d2.a = resultSet.getShort("ID");
                d2.name = resultSet.getString("Name");
                d2.version = resultSet.getInt("Version");
                d2.e = resultSet.getLong("Checksum");
                arrayList.add(d2);
            }
            sQLResult.closeAll();
            return arrayList;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public void b(d d2) {
        this.c(d2);
        try {
            this.a.doTask(new EmptySQLTask("INSERT INTO InstalledLibraries VALUES (?, ?, ?, ?)", false).addParameter(d2.a).addParameter(d2.name).addParameter(d2.version).addParameter(d2.e));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void c(d d2) {
        this.a(d2.a);
    }

    public void a(short s2) {
        try {
            this.a.doTask(new EmptySQLTask("DELETE FROM InstalledLibraries WHERE ID = ?", false).addParameter(s2));
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

}

