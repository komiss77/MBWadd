/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.extlibrary;

import de.marcely.bedwars.MBedwars;
import java.io.InputStream;

public class a {
    public static InputStream getResourceAsStream(String string) {
        return MBedwars.a.getResource("de/marcely/bedwars/extlibrary/" + string);
    }
}

