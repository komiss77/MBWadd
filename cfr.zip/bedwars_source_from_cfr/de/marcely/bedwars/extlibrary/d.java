/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.extlibrary;

import de.marcely.sbenlib.util.BufferedReadStream;

public class d {
    public short a;
    public String name;
    public int version;
    public long e;

    public void read(BufferedReadStream bufferedReadStream) {
        this.a = bufferedReadStream.readSignedShort();
        this.name = bufferedReadStream.readString();
        this.version = bufferedReadStream.readUnsignedShort();
        this.e = bufferedReadStream.readSignedLong();
    }
}

