/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.extlibrary;

import de.marcely.bedwars.cR;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.extlibrary.ExtLibrary;
import de.marcely.bedwars.extlibrary.a;
import de.marcely.bedwars.extlibrary.b;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.sql.SQLType;
import de.marcely.bedwars.util.o;
import de.marcely.bedwars.util.s;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

public class c
implements Closeable,
AutoCloseable {
    public static boolean w = false;
    private final File folder;
    private final b b;
    private List<d> E;

    public c() {
        this(s.p);
    }

    public c(File file) {
        this.folder = file;
        this.b = new b(new File(file, "library.db"));
        if (w) {
            de.marcely.bedwars.d.a("Send this to the dev: Debugging 0 is still enabled!");
        }
    }

    public void a(final Runnable runnable) {
        this.b.connect(new Runnable(){

            @Override
            public void run() {
                c.a(c.this, new ArrayList());
                c.this.E.addAll(c.this.b.a());
                c.this.u();
                runnable.run();
            }
        });
    }

    public void u() {
        try {
            Iterator<d> iterator = this.E.iterator();
            while (iterator.hasNext()) {
                d d2 = iterator.next();
                File file = this.a(d2);
                if (!file.exists()) {
                    iterator.remove();
                    this.b.c(d2);
                    continue;
                }
                long l2 = de.marcely.bedwars.util.c.a(Files.readAllBytes(file.toPath()));
                if (w || l2 == d2.e) continue;
                iterator.remove();
                this.b.c(d2);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public boolean a(short s2, int n2, long l2) {
        for (d d2 : this.E) {
            if (d2.a != s2 || d2.version != n2 || d2.e != l2) continue;
            return true;
        }
        return false;
    }

    public void a(d d2, byte[] arrby) {
        if (this.a(d2.a, d2.version, d2.e)) {
            return;
        }
        try {
            File file = this.a(d2);
            Files.write(file.toPath(), arrby, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);
            this.b.b(d2);
            this.E.add(d2);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(d d2, String string) {
        if (this.a(d2.a, d2.version, d2.e)) {
            return;
        }
        try {
            InputStream inputStream = a.getResourceAsStream(string);
            if (inputStream == null) {
                throw new RuntimeException("A fatal error occured. JAR seems to be corrupted (Missing '" + string + "')");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int n2 = -1;
            while ((n2 = inputStream.read()) != -1) {
                byteArrayOutputStream.write(n2);
            }
            byte[] arrby = byteArrayOutputStream.toByteArray();
            long l2 = de.marcely.bedwars.util.c.a(arrby);
            inputStream.close();
            byteArrayOutputStream.close();
            d2.e = l2;
            this.a(d2, arrby);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(d d2, boolean bl2) throws Exception {
        o.a(this.a(d2), bl2);
    }

    private boolean a(ExtLibrary extLibrary) throws Exception {
        if (extLibrary == null) {
            return false;
        }
        if (!extLibrary.loaded) {
            d d2 = this.a(extLibrary.getId());
            if (d2 != null) {
                this.a(d2, extLibrary.y());
                extLibrary.loaded = true;
            } else {
                return false;
            }
        }
        return true;
    }

    private File a(d d2) {
        return new File(this.folder, String.valueOf(d2.a) + "." + d2.name.toLowerCase().replace(" ", "_") + ".jar");
    }

    @Nullable
    public d a(short s2) {
        for (d d2 : this.E) {
            if (d2.a != s2) continue;
            return d2;
        }
        return null;
    }

    public void loadLibraries() {
        for (cR cR2 : s.b.h().values()) {
            try {
                if (!this.a(cR2.a())) continue;
                cR2.X();
            }
            catch (Error error) {
                error.printStackTrace();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        if (ConfigValue.sql_enabled && ConfigValue.sql_type.getExtLibrary() != null) {
            try {
                this.a(ConfigValue.sql_type.getExtLibrary());
            }
            catch (Error error) {
                error.printStackTrace();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

    @Override
    public void close() throws IOException {
        this.b.close();
    }

    public File getFolder() {
        return this.folder;
    }

    static /* synthetic */ void a(c c2, List list) {
        c2.E = list;
    }

}

