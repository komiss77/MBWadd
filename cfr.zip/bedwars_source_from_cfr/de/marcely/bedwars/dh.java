/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  ch.dkrieger.coinsystem.core.CoinSystem
 *  ch.dkrieger.coinsystem.core.player.CoinPlayer
 *  ch.dkrieger.coinsystem.core.player.CoinPlayerManager
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import ch.dkrieger.coinsystem.core.CoinSystem;
import ch.dkrieger.coinsystem.core.player.CoinPlayer;
import ch.dkrieger.coinsystem.core.player.CoinPlayerManager;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import java.util.UUID;
import org.bukkit.entity.Player;

public class dh
extends dg {
    private static /* synthetic */ int[] q;

    @Override
    public cT a() {
        return cT.q;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void a(Player player, df df2) {
        switch (dh.r()[df2.ordinal()]) {
            case 1: {
                this.c(player, ConfigValue.coins_give_win);
                break;
            }
            case 2: {
                this.c(player, ConfigValue.coins_give_lose);
                break;
            }
            case 3: {
                this.c(player, ConfigValue.coins_give_beddestroy);
                break;
            }
            case 4: {
                this.c(player, ConfigValue.coins_give_killplayer);
            }
        }
    }

    private void c(Player player, int n2) {
        CoinPlayer coinPlayer = CoinSystem.getInstance().getPlayerManager().getPlayer(player.getUniqueId());
        coinPlayer.addCoins((long)n2);
    }

    static /* synthetic */ int[] r() {
        if (q != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[df.values().length];
        try {
            arrn[df.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        q = arrn;
        return q;
    }
}

