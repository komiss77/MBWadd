/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.r;

public class bU
extends bS<Arena> {
    public static bU a = new bU();

    @Override
    public bP.c a() {
        return bP.c.e;
    }

    @Override
    public String c(Arena arena) {
        int n2 = arena.N % 60;
        int n3 = (int)Math.floor(arena.N / 60);
        return String.valueOf(r.a("" + n3, '0', 2)) + ":" + r.a("" + n2, '0', 2);
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.c((Arena)object);
    }
}

