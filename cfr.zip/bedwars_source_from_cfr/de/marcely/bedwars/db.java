/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.dytanic.cloudnet.ext.bridge.bukkit.BukkitCloudNetHelper
 *  de.dytanic.cloudnet.wrapper.Wrapper
 */
package de.marcely.bedwars;

import de.dytanic.cloudnet.ext.bridge.bukkit.BukkitCloudNetHelper;
import de.dytanic.cloudnet.wrapper.Wrapper;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.cZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.util.s;

public class db
extends cZ {
    private d a;
    private Arena arena;
    private static /* synthetic */ int[] l;

    @Override
    public cT a() {
        return cT.c;
    }

    @Override
    public void onEnable() {
        this.arena = s.b(ConfigValue.cloudsystem_arena);
        if (this.arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.a = new d(){

            @Override
            public void a(Arena arena, d.a a2) {
                db.this.b(arena, a2);
            }
        };
        this.arena.a(this.a);
    }

    private void b(Arena arena, d.a a2) {
        if (a2 == d.a.e && arena.b() == ArenaStatus.f) {
            BukkitCloudNetHelper.changeToIngame();
            return;
        }
        BukkitCloudNetHelper.setState((String)db.a(arena.b()));
        BukkitCloudNetHelper.setExtra((String)ConfigValue.cloudsystem_extra.a(arena));
        Wrapper.getInstance().publishServiceInfoUpdate();
    }

    private static String a(ArenaStatus arenaStatus) {
        switch (db.m()[arenaStatus.ordinal()]) {
            case 3: {
                return "ingame";
            }
            case 2: {
                return "lobby";
            }
        }
        return "offline";
    }

    @Override
    public void onDisable() {
        if (this.arena != null) {
            this.arena.a(this.a);
        }
    }

    static /* synthetic */ int[] m() {
        if (l != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ArenaStatus.values().length];
        try {
            arrn[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        l = arrn;
        return l;
    }

}

