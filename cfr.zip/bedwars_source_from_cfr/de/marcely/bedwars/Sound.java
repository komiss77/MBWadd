/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.d;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public enum Sound {
    COUNTDOWN_COUNTING("FIRE_IGNITE", "ITEM_FLINTANDSTEEL_USE", false),
    COUNTDOWN_DONECOUNTING("LEVEL_UP", "ENTITY_PLAYER_LEVELUP", false),
    BED_DESTROY("WITHER_DEATH", "ENTITY_WITHER_DEATH", true),
    BED_DESTROY_ENEMY("WITHER_DEATH", "ENTITY_WITHER_DEATH", false),
    TEAM_ELIMINATED("ENDERDRAGON_HIT", "ENTITY_ENDERDRAGON_HURT", false),
    ARENAGUI_ADDSLOTS("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false),
    ARENAGUI_TAKESLOTS("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false),
    ARENAGUI_TAKESLOTSFAIL("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", true),
    ARENAGUI_ENABLETEAM("CLICK", "UI_BUTTON_CLICK", false),
    ARENAGUI_DISABLETEAM("CLICK", "UI_BUTTON_CLICK", true),
    ARENAGUI_DISABLETEAMFAIL("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    VILLAGERSHOP_OPEN("CLICK", "UI_BUTTON_CLICK", false),
    VILLAGERSHOP_BUYFAIL_ONETIMEPURCHASE("NOTE_BASS_DRUM", "BLOCK_NOTE_BLOCK_BASEDRUM", false),
    VILLAGERSHOP_BUYFAIL_TOOFEWMATERIALS("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    VILLAGERSHOP_BUYFAIL_INSUFFICIENT_PERMISSIONS("NOTE_STICKS", "BLOCK_NOTE_HARP", false),
    VILLAGERSHOP_BUYFAIL_BUYGROUP("NOTE_BASS_DRUM", "BLOCK_NOTE_BLOCK_BASEDRUM", false),
    VILLAGERSHOP_BUYSUCCESS("ITEM_PICKUP", "ENTITY_ITEM_PICKUP", false),
    UPGRADESHOP_OPEN("CLICK", "UI_BUTTON_CLICK", true),
    UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS("NOTE_BASS", "BLOCK_NOTE_BASS", true),
    UPGRADESHOP_BUYSUCCESS("ITEM_PICKUP", "ENTITY_ITEM_PICKUP", true),
    SPECTATOR_BORDER("NOTE_BASS_DRUM", "BLOCK_NOTE_BASEDRUM", false),
    EXTRAITEM_TELEPORTER_USE("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false),
    EXTRAITEM_TNTSHEEP_FUSE("FUSE", "ENTITY_TNT_PRIMED", false),
    EXTRAITEM_MINISHOP_USE("ORB_PICKUP", "ENTITY_EXPERIENCE_ORB_PICKUP", false),
    EXTRAITEM_RESCUEPLATFORM_USE("FIZZ", "BLOCK_LAVA_EXTINGUISH", false),
    EXTRAITEM_RESCUEPLATFORM_AUTOBREAK("SLIME_ATTACK", "BLOCK_SLIME_BREAK", false),
    LOBBY_LEAVE("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", true),
    LOBBY_ACHIEVEMENTS_OPEN("CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false),
    LOBBY_ACHIEVEMENTS_CLICK("NOTE_BASS", "BLOCK_NOTE_BASS", true),
    LOBBY_FORCESTART("CAT_HISS", "ENTITY_CAT_HISS", false),
    LOBBY_SELECTTEAM_OPEN("FIREWORK_BLAST", "ENTITY_FIREWORK_BLAST", true),
    LOBBY_SELECTTEAM_SELECT("SHEEP_IDLE", "ENTITY_SHEEP_AMBIENT", true),
    LOBBY_SELECTTEAM_ALREADYSELECTED("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    LOBBY_SELECTTEAM_FULL("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    LOBBY_VOTEARENA_OPEN("FIREWORK_BLAST", "ENTITY_FIREWORK_BLAST", false),
    LOBBY_VOTEARENA_VOTE("LEVEL_UP", "ENTITY_PLAYER_LEVELUP", true),
    LOBBY_VOTEARENA_ALREADYVOTED("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    LOBBY_VOTEARENA_NOTVOTEABLE("NOTE_BASS", "BLOCK_NOTE_BASS", false),
    LOBBY_OUTOFMAP("CAT_HISS", "ENTITY_CAT_HISS", true),
    ACHIEVEMENT_GET("LEVEL_UP", "ENTITY_PLAYER_LEVELUP", false),
    PLAYERDEATH_EFFECT("FIZZ", "BLOCK_LAVA_EXTINGUISH", false),
    CMD_RUNNINGGAME_FAILURE("NOTE_BASS_DRUM", "BLOCK_NOTE_BASEDRUM", false),
    ENDERCHEST_OPEN("CHEST_OPEN", "BLOCK_CHEST_OPEN", false),
    BREAK_TOPSTATUE("ITEM_BREAK", "ENTITY_ARMORSTAND_BREAK", false),
    TRAP_CAUSE("ITEM_BREAK", "ENTITY_ITEM_BREAK", false),
    TRAP_OWNER("GHAST_MOAN", "ENTITY_GHAST_WARN", true),
    BRIDGE_BUILD("DIG_STONE", "BLOCK_STONE_BREAK", false),
    TELEPORTER_COUNTING("NOTE_PLING", "BLOCK_NOTE_BELL", true),
    ENTITY_VILLAGER_HURT("VILLAGER_HIT", "ENTITY_VILLAGER_HURT", false),
    ENTITY_VILLAGER_DEATH("VILLAGER_DEATH", "ENTITY_VILLAGER_DEATH", false),
    ENTITY_PLAYER_HURT("HURT_FLESH", "ENTITY_PLAYER_HURT", false),
    ENTITY_PLAYER_DEATH("HURT_FLESH", "ENTITY_PLAYER_DEATH", false),
    ENTITY_ARMOR_STAND_HIT("/", "ENTITY_ARMOR_STAND_HIT", false),
    ENTITY_ARMOR_STAND_BREAK("/", "ENTITY_ARMOR_STAND_BREAK", false);
    
    private SoundData data;

    private Sound(String string2, String string3, boolean bl2) {
        this.data = new SoundData(string2, string3, bl2);
    }

    public void play(Player player) {
        org.bukkit.Sound sound = this.data.a();
        if (sound == null) {
            return;
        }
        if (this.data.e()) {
            player.playSound(player.getLocation(), sound, 1.0f, 6.0f);
        } else {
            player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
        }
    }

    public void play(Location location) {
        org.bukkit.Sound sound = this.data.a();
        if (sound == null) {
            return;
        }
        if (this.data.e()) {
            location.getWorld().playSound(location, sound, 1.0f, 6.0f);
        } else {
            location.getWorld().playSound(location, sound, 1.0f, 1.0f);
        }
    }

    @Nullable
    public static Sound byName(String string) {
        for (Sound sound : Sound.values()) {
            if (!sound.name().equalsIgnoreCase(string)) continue;
            return sound;
        }
        return null;
    }

    public SoundData getData() {
        return this.data;
    }

    public void setData(SoundData soundData) {
        this.data = soundData;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class SoundData {
        private String a;
        private String b;
        private boolean b;
        private org.bukkit.Sound a;

        public SoundData(String string, String string2, boolean bl2) {
            this.a = string.equals("/") ? null : string.toUpperCase();
            this.b = string2.equals("/") ? null : string2.toUpperCase();
            this.b = bl2;
        }

        public org.bukkit.Sound a() {
            if (this.a != null) {
                return this.a;
            }
            org.bukkit.Sound sound = null;
            if (Version.a().getVersionNumber() <= 8) {
                if (this.a == null) {
                    return null;
                }
                sound = s.b(this.a);
            } else {
                if (this.b == null) {
                    return null;
                }
                String string = this.b.replace("_", "");
                if (Version.a().getVersionNumber() >= 13) {
                    if (string.startsWith("BLOCKNOTE")) {
                        string = string.replaceFirst("BLOCKNOTE", "BLOCKNOTEBLOCK");
                    } else if (string.startsWith("ENTITYFIREWORKBLAST")) {
                        string = string.replaceFirst("ENTITYFIREWORKBLAST", "ENTITYFIREWORKROCKETBLAST");
                    }
                }
                sound = s.b(string);
            }
            if (sound == null) {
                d.b("Unkown configured sound '" + (Version.a().getVersionNumber() <= 8 ? this.a : this.b) + "'");
            } else {
                this.a = sound;
            }
            return sound;
        }

        public String a() {
            return this.a;
        }

        public String b() {
            return this.b;
        }

        public boolean e() {
            return this.b;
        }
    }

}

