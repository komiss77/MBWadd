/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bK;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.a;
import de.marcely.bedwars.flag.c;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.flag.e;
import de.marcely.bedwars.flag.g;
import de.marcely.bedwars.flag.h;
import de.marcely.bedwars.flag.j;
import de.marcely.bedwars.flag.l;
import de.marcely.bedwars.flag.n;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.b;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bI {
    private final bK a;
    private final UUID b;
    private boolean O = false;
    private d b;

    public bI(bK bK2, UUID uUID) {
        this(bK2, uUID, new d());
    }

    public bI(bK bK2, UUID uUID, d d2) {
        this.a = bK2;
        this.b = uUID;
        this.b = d2;
    }

    public void save() {
        this.a.b(this);
    }

    public void v(Player player) {
        try {
            this.w(player);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void w(Player player) throws Exception {
        d d2;
        int n2;
        ItemStack itemStack;
        Object object;
        Object object22;
        this.b.clear();
        this.b.a(new g("Username", new n(player.getName())));
        this.b.a(new g("FetchTime", new l(System.currentTimeMillis())));
        d d3 = new d();
        d3.a(new g("GameMode", new n(player.getGameMode().name())));
        d3.a(new g("Health", new h(Float.valueOf((float)de.marcely.bedwars.util.b.a(player)))));
        d3.a(new g("Hunger", new j(player.getFoodLevel())));
        d3.a(new g("Exhaustion", new h(Float.valueOf(player.getExhaustion()))));
        d3.a(new g("Saturation", new h(Float.valueOf(player.getSaturation()))));
        d3.a(new g("Level", new j(player.getLevel())));
        d3.a(new g("LevelEXP", new h(Float.valueOf(player.getExp()))));
        d3.a(new g("FallDistance", new h(Float.valueOf(player.getFallDistance()))));
        d3.a(new g("FireTicks", new j(player.getFireTicks())));
        Value value = new e();
        PotionEffect potionEffect2 = Version.a().a(player);
        for (Object object22 : potionEffect2) {
            ((e)value).a(((b)object22).b());
        }
        d3.a(new g("Attributes", value));
        d3.a(new g("Abilities", Version.a().a(player)));
        value = new e();
        for (PotionEffect potionEffect2 : player.getActivePotionEffects()) {
            object = new d();
            ((d)object).a(new g("Type", new n(potionEffect2.getType().getName())));
            ((d)object).a(new g("Duration", new j(potionEffect2.getDuration())));
            ((d)object).a(new g("Amplifier", new j(potionEffect2.getAmplifier())));
            ((d)object).a(new g("IsAmbient", new a(potionEffect2.isAmbient())));
            if (Version.a().getVersionNumber() >= 8) {
                ((d)object).a(new g("HasParticles", new a(potionEffect2.hasParticles())));
            }
            if (Version.a().getVersionNumber() >= 13) {
                n2 = ((Boolean)PotionEffect.class.getMethod("hasIcon", new Class[0]).invoke((Object)potionEffect2, new Object[0])).booleanValue() ? 1 : 0;
                ((d)object).a(new g("HasIcon", new a(n2 != 0)));
            }
            ((e)value).a((Value<?>)object);
        }
        d3.a(new g("ActiveEffects", value));
        value = new d();
        potionEffect2 = player.getInventory();
        object22 = new e();
        object = new e();
        ((d)value).a(new g("Size", new c((byte)(potionEffect2.getSize() & 255))));
        for (n2 = 0; n2 < potionEffect2.getSize(); n2 += 1) {
            itemStack = potionEffect2.getItem(n2);
            if (itemStack == null || (Version.a().a() instanceof w ? ((w)Version.a().a()).c(itemStack).equals("air") : itemStack.getType() == Material.AIR)) continue;
            d2 = new d();
            d2.a(new g("Slot", new c((byte)(n2 & 255))));
            d2.a(new g("Data", Version.a().a(itemStack)));
            ((e)object22).a(d2);
        }
        for (n2 = 0; n2 < potionEffect2.getArmorContents().length; n2 += 1) {
            itemStack = potionEffect2.getArmorContents()[n2];
            if (itemStack == null || itemStack.getType() == Material.AIR) continue;
            d2 = new d();
            d2.a(new g("Slot", new c((byte)(n2 & 255))));
            d2.a(new g("Data", Version.a().a(itemStack)));
            ((e)object).a(d2);
        }
        ((d)value).a(new g("Content", (Value<?>)object22));
        ((d)value).a(new g("ArmorContent", (Value<?>)object));
        d3.a(new g("Inventory", value));
        this.b.a(new g("WorldData", d3));
    }

    public void x(Player player) {
        try {
            this.y(player);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void y(Player player) throws Exception {
        block3 : for (g g2 : (Collection)this.b.getValue()) {
            String string = g2.getKey();
            switch (string.hashCode()) {
                case -1168669124: {
                    if (!string.equals("WorldData")) continue block3;
                    this.a(player, g2.a(d.class));
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(Player var1_1, d var2_2) throws Exception {
        for (g var3_4 : (Collection)var2_2.getValue()) {
            block34 : {
                block40 : {
                    block33 : {
                        block32 : {
                            block38 : {
                                block36 : {
                                    block31 : {
                                        block35 : {
                                            block39 : {
                                                block37 : {
                                                    block30 : {
                                                        block29 : {
                                                            var5_5 = var3_4.getKey();
                                                            switch (var5_5.hashCode()) {
                                                                case -2137395588: {
                                                                    if (!var5_5.equals("Health")) {
                                                                        ** break;
                                                                    }
                                                                    break block29;
                                                                }
                                                                case -2122237229: {
                                                                    if (!var5_5.equals("Hunger")) {
                                                                        ** break;
                                                                    }
                                                                    break block30;
                                                                }
                                                                case -2067007463: {
                                                                    if (!var5_5.equals("LevelEXP")) {
                                                                        ** break;
                                                                    }
                                                                    break block31;
                                                                }
                                                                case -1895856777: {
                                                                    if (!var5_5.equals("Attributes")) {
                                                                        ** break;
                                                                    }
                                                                    break block32;
                                                                }
                                                                case -1704717099: {
                                                                    if (var5_5.equals("GameMode")) break;
                                                                    ** break;
                                                                }
                                                                case -632618200: {
                                                                    if (!var5_5.equals("Abilities")) {
                                                                        ** break;
                                                                    }
                                                                    break block33;
                                                                }
                                                                case -16631492: {
                                                                    if (!var5_5.equals("Inventory")) {
                                                                        ** break;
                                                                    }
                                                                    break block34;
                                                                }
                                                                case 73313124: {
                                                                    if (!var5_5.equals("Level")) {
                                                                        ** break;
                                                                    }
                                                                    break block35;
                                                                }
                                                                case 908161200: {
                                                                    if (!var5_5.equals("FallDistance")) {
                                                                        ** break;
                                                                    }
                                                                    break block36;
                                                                }
                                                                case 1690834622: {
                                                                    if (!var5_5.equals("Exhaustion")) {
                                                                        ** break;
                                                                    }
                                                                    break block37;
                                                                }
                                                                case 1707249088: {
                                                                    if (!var5_5.equals("FireTicks")) {
                                                                        ** break;
                                                                    }
                                                                    break block38;
                                                                }
                                                                case 1762973682: {
                                                                    if (!var5_5.equals("Saturation")) {
                                                                        ** break;
                                                                    }
                                                                    break block39;
                                                                }
                                                                case 2080567036: {
                                                                    if (!var5_5.equals("ActiveEffects")) {
                                                                        ** break;
                                                                    }
                                                                    break block40;
                                                                }
                                                            }
                                                            var6_6 = de.marcely.bedwars.util.b.a((String)var3_4.a(n.class).getValue());
                                                            if (var6_6 != null) {
                                                                var1_1.setGameMode(var6_6);
                                                                ** break;
                                                            }
                                                            var1_1.setGameMode(GameMode.ADVENTURE);
                                                            ** break;
                                                        }
                                                        var1_1.setHealth((double)((Float)var3_4.a(h.class).getValue()).floatValue());
                                                        ** break;
                                                    }
                                                    var1_1.setFoodLevel(((Integer)var3_4.a(j.class).getValue()).intValue());
                                                    ** break;
                                                }
                                                var1_1.setExhaustion(((Float)var3_4.a(h.class).getValue()).floatValue());
                                                ** break;
                                            }
                                            var1_1.setSaturation(((Float)var3_4.a(h.class).getValue()).floatValue());
                                            ** break;
                                        }
                                        var1_1.setLevel(((Integer)var3_4.a(j.class).getValue()).intValue());
                                        ** break;
                                    }
                                    var1_1.setExp(((Float)var3_4.a(h.class).getValue()).floatValue());
                                    ** break;
                                }
                                var1_1.setFallDistance(((Float)var3_4.a(h.class).getValue()).floatValue());
                                ** break;
                            }
                            var1_1.setFireTicks(((Integer)var3_4.a(j.class).getValue()).intValue());
                            ** break;
                        }
                        this.a(var1_1, var3_4.a(e.class));
                        ** break;
                    }
                    Version.a().c(var1_1, var3_4.a(d.class));
                    ** break;
                }
                this.b(var1_1, var3_4.a(e.class));
                ** break;
            }
            this.b(var1_1, var3_4.a(d.class));
lbl96: // 28 sources:
        }
    }

    private void a(Player player, e e2) {
        ArrayList<b> arrayList = new ArrayList<b>(((Collection)e2.getValue()).size());
        for (Value value : (Collection)e2.getValue()) {
            arrayList.add(b.a((d)value));
        }
        Version.a().c(player, arrayList);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void b(Player var1_1, e var2_2) throws Exception {
        for (PotionEffect var3_4 : var1_1.getActivePotionEffects()) {
            var1_1.removePotionEffect(var3_4.getType());
        }
        for (Value var3_6 : (Collection)var2_2.getValue()) {
            var5_7 = (d)var3_6;
            var6_8 = null;
            var7_9 = 0;
            var8_10 = 0;
            var9_11 = false;
            var10_12 = false;
            var11_13 = false;
            for (g var12_14 : (Collection)var5_7.getValue()) {
                block18 : {
                    block22 : {
                        block21 : {
                            block20 : {
                                block19 : {
                                    var14_16 = var12_14.getKey();
                                    switch (var14_16.hashCode()) {
                                        case -1933705709: {
                                            if (!var14_16.equals("HasIcon")) {
                                                ** break;
                                            }
                                            break block18;
                                        }
                                        case -1927368268: {
                                            if (!var14_16.equals("Duration")) {
                                                ** break;
                                            }
                                            break block19;
                                        }
                                        case -1019399599: {
                                            if (!var14_16.equals("Amplifier")) {
                                                ** break;
                                            }
                                            break block20;
                                        }
                                        case 2622298: {
                                            if (var14_16.equals("Type")) break;
                                            ** break;
                                        }
                                        case 532044270: {
                                            if (!var14_16.equals("IsAmbient")) {
                                                ** break;
                                            }
                                            break block21;
                                        }
                                        case 1572835667: {
                                            if (!var14_16.equals("HasParticles")) {
                                                ** break;
                                            }
                                            break block22;
                                        }
                                    }
                                    var6_8 = de.marcely.bedwars.util.b.a((String)var12_14.a(n.class).getValue());
                                    ** break;
                                }
                                var7_9 = (Integer)var12_14.a(j.class).getValue();
                                ** break;
                            }
                            var8_10 = (Integer)var12_14.a(j.class).getValue();
                            ** break;
                        }
                        var9_11 = (Boolean)var12_14.a(a.class).getValue();
                        ** break;
                    }
                    var10_12 = (Boolean)var12_14.a(a.class).getValue();
                    ** break;
                }
                var11_13 = (Boolean)var12_14.a(a.class).getValue();
lbl54: // 13 sources:
            }
            if (var6_8 == null) continue;
            var12_14 = new PotionEffect(var6_8, var7_9, var8_10, var9_11);
            if (Version.a().getVersionNumber() >= 8 && var10_12) {
                s.a(var12_14.getClass(), "particles").set(var12_14, var10_12);
            }
            if (Version.a().getVersionNumber() >= 13 && var11_13) {
                s.a(var12_14.getClass(), "icon").set(var12_14, var11_13);
            }
            var1_1.addPotionEffect((PotionEffect)var12_14, true);
        }
    }

    private void b(Player player, d d2) {
        d d3;
        int n2;
        PlayerInventory playerInventory = player.getInventory();
        e e2 = d2.a("Content").a(e.class);
        e e3 = d2.a("ArmorContent").a(e.class);
        ItemStack[] arritemStack = new ItemStack[playerInventory.getArmorContents().length];
        playerInventory.clear();
        for (Value value : (Collection)e2.getValue()) {
            d3 = (d)value;
            n2 = (Byte)d3.a("Slot").a(c.class).getValue() & 255;
            if (n2 >= playerInventory.getSize() || n2 < 0) continue;
            playerInventory.setItem(n2, Version.a().a(d3.a("Data").a(d.class)));
        }
        for (Value value : (Collection)e3.getValue()) {
            d3 = (d)value;
            n2 = (Byte)d3.a("Slot").a(c.class).getValue() & 255;
            if (n2 >= arritemStack.length || n2 < 0) continue;
            arritemStack[n2] = Version.a().a(d3.a("Data").a(d.class));
        }
        playerInventory.setArmorContents(arritemStack);
    }

    public UUID getId() {
        return this.b;
    }

    public boolean isIngame() {
        return this.O;
    }

    public void f(boolean bl2) {
        this.O = bl2;
    }

    public d a() {
        return this.b;
    }

    public void a(d d2) {
        this.b = d2;
    }
}

