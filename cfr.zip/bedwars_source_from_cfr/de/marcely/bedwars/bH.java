/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;

public class bH
extends by {
    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        playerUseExtraItemEvent.setCancelled(true);
    }

    @Override
    public void K() {
    }
}

