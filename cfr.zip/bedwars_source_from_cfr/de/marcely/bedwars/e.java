/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.ei;
import de.marcely.bedwars.el;
import de.marcely.bedwars.em;
import de.marcely.bedwars.eq;
import de.marcely.bedwars.ex;
import de.marcely.bedwars.extlibrary.c;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import java.io.IOException;
import java.net.URI;
import java.util.Timer;
import java.util.TimerTask;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class e {
    private static final String c = "ws://msrv.marcely.de:1406";
    private Object a;
    private Timer a;
    private c a;
    private a a;
    private boolean running = false;
    @Nullable
    private String d = "?";
    private boolean c = false;

    public boolean isRunning() {
        return this.running;
    }

    public boolean a(a a2) {
        return this.a(a2, null);
    }

    public boolean a(final a a2, final @Nullable CommandSender commandSender) {
        if (this.isRunning()) {
            return false;
        }
        if (Bukkit.isPrimaryThread()) {
            new MThread(MThread.ThreadType.r){

                @Override
                public void run() {
                    e.this.a(a2, commandSender);
                }
            }.start();
            return true;
        }
        this.running = true;
        this.a = a2;
        if (a2.g()) {
            this.a = new c();
            this.a.a(new Runnable(){

                @Override
                public void run() {
                    try {
                        if (a2 == a.c) {
                            new de.marcely.bedwars.e$2$1(true);
                        }
                        e.this.a(commandSender);
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }

            });
        } else {
            try {
                this.a(commandSender);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        this.a = new Timer();
        this.a.schedule(new TimerTask(){

            @Override
            public void run() {
                try {
                    ei ei2 = (ei)((Object)e.this.a);
                    if (ei2 == null) {
                        de.marcely.bedwars.d.b("A network error occured");
                        for (Thread thread : MThread.getRunningThreads()) {
                            de.marcely.bedwars.d.b("Thread: " + MThread.getDisplayInfo(thread));
                            for (StackTraceElement stackTraceElement : thread.getStackTrace()) {
                                de.marcely.bedwars.d.b("\t" + stackTraceElement.toString());
                            }
                        }
                    }
                    if (ei2 != null && ei2.isConnected()) {
                        e.this.a(ei.a.f);
                    } else {
                        e.this.a(ei.a.a);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }, 20000L);
        return true;
    }

    private void a(final @Nullable CommandSender commandSender) throws Exception {
        if (this.a == a.c) {
            d d2 = new d();
            d2.a = (short)-1;
            d2.name = "Java-WebSocket";
            d2.version = 28;
            this.a.a(d2, "websocket.jar");
            this.a.a(d2, true);
        }
        this.a = new ei(URI.create(c)){

            @Override
            public void onConnect() {
                if (e.this.a == a.c) {
                    this.a().a(new eq());
                }
            }

            @Override
            public void b(ei.a a2) {
                try {
                    e.this.a(a2);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }

            @Override
            public void a(d[] arrd) {
                if (e.this.a != a.c) {
                    return;
                }
                boolean bl2 = false;
                for (d d2 : arrd) {
                    if (e.this.a.a(d2.a, d2.version, d2.e)) continue;
                    e.this.a(d2);
                    bl2 = true;
                }
                if (!bl2) {
                    this.a(ei.a.f);
                }
            }

            @Override
            public void a(boolean bl2, String string) {
                e.a(e.this, bl2);
                if (bl2) {
                    e.a(e.this, string);
                } else {
                    e.a(e.this, "4.0.13");
                }
                if (bl2) {
                    de.marcely.bedwars.d.c(String.valueOf(Language.newUpdate.getMessage(commandSender)) + ": " + string);
                }
                if (commandSender != null) {
                    if (bl2) {
                        commandSender.sendMessage(String.valueOf(Language.newUpdate.getMessage(commandSender)) + ": " + string);
                    } else {
                        s.a(commandSender, b.a(Language.noNewUpdate));
                    }
                }
                if (e.this.a == a.e || e.this.a == a.f) {
                    this.a(ei.a.f);
                }
            }
        };
        ((ei)((Object)this.a)).connect();
    }

    private void a(final d d2) {
        ei ei2 = (ei)((Object)this.a);
        ei2.a().a(d2, new em(){

            @Override
            public void a(byte[] arrby, int n2) {
                try {
                    if (de.marcely.bedwars.util.c.a(arrby) != d2.e) {
                        throw new RuntimeException("Self calculated checksum is different than expected checksum");
                    }
                    e.this.a.a(d2, arrby);
                    de.marcely.bedwars.d.i("Downloaded module '" + d2.name + "' v." + d2.version);
                    if (n2 == 0) {
                        e.this.a(ei.a.f);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    public void a(ei.a a2) throws Exception {
        if (this.a != null) {
            if (a2 == ei.a.b) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("The use to this plugin has been banned for you.");
                de.marcely.bedwars.d.b("If you think that you didn't do anything wrong or think that this is an error, then please contact our support.");
                de.marcely.bedwars.d.b("============================");
                s.a(true, this.a);
            } else if (a2 == ei.a.e) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("It seems like that your current version (" + MBedwars.getVersion() + ") is outdated.");
                de.marcely.bedwars.d.b("Please install the latest version to fix that!");
                de.marcely.bedwars.d.b("Otherwise some plugin components, such as WorldEdit, SQL, etc. may won't work.");
                de.marcely.bedwars.d.b("============================");
                s.a(false, this.a);
            } else if (a2 == ei.a.a || a2 == ei.a.h || a2 == ei.a.c || a2 == ei.a.d) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("Sorry, but we weren't able to identify your version.");
                de.marcely.bedwars.d.b("Please try it again with a working internet connection or look for an update!");
                de.marcely.bedwars.d.b("Otherwise some plugin components, such as WorldEdit, SQL, etc. may won't work.");
                de.marcely.bedwars.d.b("============================");
            }
            ei ei2 = (ei)((Object)this.a);
            this.a = null;
            this.running = false;
            ei2.a(a2);
            if (this.a != null) {
                if (a2 == ei.a.f) {
                    this.a.loadLibraries();
                }
                this.a.close();
            }
            if (this.a != null) {
                this.a.cancel();
                this.a = null;
            }
        }
    }

    @Nullable
    public String c() {
        return this.d;
    }

    public boolean f() {
        return this.c;
    }

    static /* synthetic */ void a(e e2, boolean bl2) {
        e2.c = bl2;
    }

    static /* synthetic */ void a(e e2, String string) {
        e2.d = string;
    }

    public static enum a {
        c,
        d,
        e,
        f;
        

        public boolean g() {
            return this == c;
        }
    }

}

