/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bN;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.flag.g;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.h;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.Collection;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

public class bL {
    public static void a(Block block, BufferedWriteStream bufferedWriteStream, bN bN2) {
        d d2;
        if (a.a(block).equals("AIR")) {
            return;
        }
        bufferedWriteStream.writeSignedInt(block.getTypeId());
        h.a(block.getX() - bN2.ad, bufferedWriteStream);
        bufferedWriteStream.writeUnsignedByte(block.getY());
        h.a(block.getZ() - bN2.ae, bufferedWriteStream);
        bN2.ad = block.getX();
        bN2.ae = block.getZ();
        if (Version.a().getVersionNumber() < 13) {
            bufferedWriteStream.writeByte(block.getData());
        }
        if ((d2 = Version.a().a(block.getLocation())) == null || ((Collection)d2.getValue()).size() == 0) {
            bufferedWriteStream.writeByte((byte)-1);
            return;
        }
        d2.write(bufferedWriteStream);
    }

    public static boolean a(World world, BufferedReadStream bufferedReadStream, Version version, boolean bl2, bN bN2, int n2) throws Exception {
        Object object;
        Object object2;
        int n3 = bufferedReadStream.readSignedInt();
        if (n3 == Integer.MIN_VALUE) {
            return true;
        }
        int n4 = bN2.ad += h.a(bufferedReadStream);
        int n5 = bufferedReadStream.readUnsignedByte();
        int n6 = bN2.ae += h.a(bufferedReadStream);
        Block block = s.a(world, n4, n5, n6);
        if (version.getVersion() < 13) {
            object2 = Material.getMaterial((int)n3);
            if (object2 == null) {
                if (!bl2) {
                    block.setType(Material.AIR);
                } else {
                    Version.a().a(block.getLocation(), Material.AIR, (byte)0);
                }
                bufferedReadStream.readByte();
                Value.a(bufferedReadStream);
                return false;
            }
            if (bl2) {
                Version.a().a(block.getLocation(), (Material)object2, bufferedReadStream.readByte());
            } else {
                block.setType((Material)object2);
                block.setData(bufferedReadStream.readByte());
            }
        } else if (n2 <= 1) {
            object2 = bufferedReadStream.readString();
            if (n2 == 0) {
                object = Material.getMaterial((String)object2);
                if (object != null) {
                    Version.a().a(block.getLocation(), (Material)object, (byte)0);
                }
            } else {
                ((w)Version.a().a()).b(block.getWorld(), block.getX(), block.getY(), block.getZ(), (String)object2);
            }
        }
        object2 = (d)Value.a(bufferedReadStream);
        if (object2 != null && ((Collection)((Value)object2).getValue()).size() > 0) {
            if (n2 <= 1) {
                object = object2;
                object2 = new d();
                ((d)object2).a(new g("entity", (Value<?>)object));
            }
            Version.a().a(block.getLocation(), (d)object2);
        }
        return false;
    }
}

