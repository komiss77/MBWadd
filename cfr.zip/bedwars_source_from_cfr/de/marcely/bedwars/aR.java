/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.Event
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Sound;
import de.marcely.bedwars.aD;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.api.event.PlayerKillPlayerEvent;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class aR {
    private static /* synthetic */ int[] g;

    public static void a(PlayerDeathEvent playerDeathEvent) {
        Location location;
        Player player = playerDeathEvent.getEntity();
        final Arena arena = s.a(player);
        if (ConfigValue.deathmessage_remove) {
            playerDeathEvent.setDeathMessage("");
        }
        if (arena != null && arena.b() == ArenaStatus.f) {
            Object object;
            location = player;
            aD.a a2 = aD.f.get((Object)location);
            Object object2 = object = a2 != null ? a2.damager : null;
            if (ConfigValue.no_drops) {
                player.getInventory().clear();
            }
            final Future<de.marcely.bedwars.game.stats.c> future = de.marcely.bedwars.game.stats.c.a((Player)location);
            s.a(future, new Runnable((Player)location){
                private final /* synthetic */ Player c;
                {
                    this.c = player;
                }

                @Override
                public void run() {
                    try {
                        de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)future.get();
                        c2.setDeaths(c2.getDeaths() + 1);
                        c2.save();
                        arena.a.s(this.c);
                    }
                    catch (InterruptedException | ExecutionException exception) {
                        exception.printStackTrace();
                    }
                }
            });
            if (!ConfigValue.deathmessage_remove && ConfigValue.deathmessage_custom_enabled) {
                Object object32;
                Object object4;
                de.marcely.bedwars.message.b b2 = null;
                if (a2 != null && object != null) {
                    if (arena != null && player.getLastDamageCause() != null) {
                        Object object5;
                        object32 = arena.a((Player)location);
                        object4 = arena.a((Player)object);
                        if (object4 == null) {
                            return;
                        }
                        if (!ConfigValue.stats_count_deaths_beforebedbroken || arena.a().d(arena.a((Player)location)) && ConfigValue.stats_count_deaths_beforebedbroken) {
                            object5 = de.marcely.bedwars.game.stats.c.a((Player)object);
                            s.a(object5, new Runnable((Future)object5, arena, (Player)object){
                                private final /* synthetic */ Future b;
                                private final /* synthetic */ Arena val$arena;
                                private final /* synthetic */ Player d;
                                {
                                    this.b = future;
                                    this.val$arena = arena;
                                    this.d = player;
                                }

                                @Override
                                public void run() {
                                    try {
                                        de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)this.b.get();
                                        c2.setKills(c2.getKills() + 1);
                                        c2.save();
                                        this.val$arena.a.s(this.d);
                                    }
                                    catch (InterruptedException | ExecutionException exception) {
                                        exception.printStackTrace();
                                    }
                                }
                            });
                        }
                        Bukkit.getPluginManager().callEvent((Event)new PlayerKillPlayerEvent(arena, (Player)object, (Player)location, a2.cause, a2.proj));
                        if (b.a((Player)object) == 1.0) {
                            s.a((Player)object, Achievement.l);
                        }
                        if ((object5 = s.a(ConfigValue.deathmessage_custom_killed)) != null) {
                            b2 = de.marcely.bedwars.message.b.a((String)object5).c().a("player", s.getPlayerDisplayName((Player)location)).a("team", ((Team)((Object)object32)).a(null, true)).a("teamcolor", "" + (Object)((Team)((Object)object32)).getChatColor()).a("killer", s.getPlayerDisplayName((Player)object)).a("killerteam", ((Team)((Object)object4)).a(null, true)).a("killerteamcolor", "" + (Object)((Team)((Object)object4)).getChatColor()).a("heartpercent", "" + (int)(b.a((Player)object) / 20.0 * 100.0));
                        }
                        for (dg dg2 : s.b.a(dg.class)) {
                            dg2.a((Player)object, df.d);
                        }
                    }
                } else if (player.getLastDamageCause() != null) {
                    object32 = null;
                    switch (aR.g()[player.getLastDamageCause().getCause().ordinal()]) {
                        case 13: {
                            object32 = s.a(ConfigValue.deathmessage_custom_void);
                            break;
                        }
                        case 11: 
                        case 12: {
                            object32 = s.a(ConfigValue.deathmessage_custom_explosion);
                            break;
                        }
                        case 5: {
                            object32 = s.a(ConfigValue.deathmessage_custom_fall);
                            break;
                        }
                        case 6: 
                        case 7: {
                            object32 = s.a(ConfigValue.deathmessage_custom_fire);
                            break;
                        }
                        default: {
                            object32 = s.a(ConfigValue.deathmessage_custom_default);
                        }
                    }
                    if (object32 != null) {
                        object4 = arena.a((Player)location);
                        b2 = de.marcely.bedwars.message.b.a((String)object32).c().a("player", s.getPlayerDisplayName((Player)location)).a("team", ((Team)((Object)object4)).a(null, true)).a("teamcolor", "" + (Object)((Team)((Object)object4)).getChatColor());
                    }
                }
                if (b2 != null) {
                    playerDeathEvent.setDeathMessage("");
                    if (ConfigValue.deathmessage_private) {
                        arena.a(b2);
                    } else {
                        for (Object object32 : Bukkit.getOnlinePlayers()) {
                            s.a((CommandSender)object32, b2, false);
                        }
                        b2.X();
                    }
                }
            }
            aD.f.remove((Object)player);
        }
        location = player.getLocation().getBlock().getLocation();
        if (arena != null) {
            if (ConfigValue.particles_ondeath && player.getLastDamageCause() != null && player.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.VOID) {
                int n2 = arena.getWorld().getMaxHeight() / 2;
                if (arena.a() == RegenerationType.c) {
                    n2 = (int)arena.getPosMax().getX();
                }
                for (int i2 = location.getBlockY(); i2 < n2; ++i2) {
                    location.setY((double)i2);
                    VarParticle.PARTICLE_CLOUD.play(arena.getWorld(), location, 5);
                    Sound.PLAYERDEATH_EFFECT.play(location);
                }
            }
            if (ConfigValue.drop_only_itemspawner) {
                for (aD.a a2 : new ArrayList(playerDeathEvent.getDrops())) {
                    if (DropType.a((ItemStack)a2) != null) continue;
                    playerDeathEvent.getDrops().remove(a2);
                }
            } else if (ConfigValue.no_drops) {
                playerDeathEvent.getDrops().clear();
            }
        }
    }

    static /* synthetic */ int[] g() {
        if (g != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[EntityDamageEvent.DamageCause.values().length];
        try {
            arrn[EntityDamageEvent.DamageCause.BLOCK_EXPLOSION.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.CONTACT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.CUSTOM.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.DROWNING.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.ENTITY_ATTACK.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.ENTITY_EXPLOSION.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.FALL.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.FALLING_BLOCK.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.FIRE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.FIRE_TICK.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.LAVA.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.LIGHTNING.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.MAGIC.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.MELTING.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.POISON.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.PROJECTILE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.STARVATION.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.SUFFOCATION.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.SUICIDE.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.THORNS.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.VOID.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[EntityDamageEvent.DamageCause.WITHER.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        g = arrn;
        return g;
    }

}

