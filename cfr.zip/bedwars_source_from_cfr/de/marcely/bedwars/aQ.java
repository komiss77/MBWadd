/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.command.t;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class aQ {
    public static void a(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        if (r.a(ConfigValue.hubcommands, playerCommandPreprocessEvent.getMessage())) {
            Player player = playerCommandPreprocessEvent.getPlayer();
            Arena arena = s.a(player);
            if (arena != null) {
                arena.a(KickReason.b, player);
                playerCommandPreprocessEvent.setCancelled(true);
            } else if (cA.E.containsKey((Object)player)) {
                cA.a(player, cD.b);
                playerCommandPreprocessEvent.setCancelled(true);
            }
        } else if (ConfigValue.allowcommand_stats && playerCommandPreprocessEvent.getMessage().toLowerCase().startsWith("/stats")) {
            Player player = playerCommandPreprocessEvent.getPlayer();
            Arena arena = s.a(player);
            if (ConfigValue.allowcommand_stats_global || arena != null) {
                playerCommandPreprocessEvent.setCancelled(true);
                String[] arrstring = playerCommandPreprocessEvent.getMessage().split(" ");
                ((t)MBedwars.a.a("stats").a()).a((CommandSender)player, "stats", "", arrstring);
            }
        }
    }
}

