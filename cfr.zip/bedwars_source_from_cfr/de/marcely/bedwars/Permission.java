/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import java.util.ArrayList;
import java.util.List;

public enum Permission {
    Command_Stats("mbedwars.cmd.stats", true),
    Command_Leave("mbedwars.cmd.leave", true),
    Command_Forcestart("mbedwars.cmd.forcestart"),
    Command_Reload("mbedwars.cmd.reload"),
    Command_List("mbedwars.cmd.list"),
    Command_Arena("mbedwars.cmd.arena"),
    Command_Kick("mbedwars.cmd.kick"),
    Command_Summon("mbedwars.cmd.summon"),
    Command_SetGameDoneLocation("mbedwars.cmd.setgamedonelocation"),
    Command_CheckUpdate("mbedwars.cmd.checkupdate"),
    Command_Info("mbedwars.cmd.info"),
    Command_AddSign("mbedwars.cmd.addsign"),
    Command_Hologram("mbedwars.cmd.hologram"),
    Command_RunningGames("mbedwars.cmd.runninggames"),
    Command_Join("mbedwars.cmd.join"),
    Command_Addon("mbedwars.cmd.addon"),
    Command_RecalculateStats("mbedwars.cmd.recalculatestats"),
    Command_Debug("mbedwars.cmd.debug"),
    Command_ArenasGUI("mbedwars.cmd.arenasgui"),
    Command_Backup("mbedwars.cmd.backup"),
    Command_AddStatsSign("mbedwars.cmd.addstatssign"),
    ArenaTP("mbedwars.arenatp"),
    ArenaBuild("mbedwars.arenabuild"),
    BetaUser("mbedwars.betauser"),
    UpdateMessage("mbedwars.updatemessage"),
    GetArena("mbedwars.getarena"),
    JoinFull("mbedwars.joinfull"),
    SpecialItem("mbedwars.specialitem.{id"),
    Break_RankStatue("mbedwars.breakrankstatue"),
    Damage_Entity("mbedwars.damageentity"),
    ShopCustomPrice("mbedwars.shopcustomprice");
    
    private String selected_permission;
    private String selected_prm;
    private boolean selected_basic;

    private Permission(String string2) {
        this(string2, false);
    }

    private Permission(String string2, boolean bl2) {
        this.selected_permission = string2;
        this.selected_prm = string2;
        this.selected_basic = bl2;
    }

    public String getPermission() {
        return this.selected_permission;
    }

    public boolean isBasic() {
        return this.selected_basic;
    }

    public Permission replace(String string, String string2) {
        this.selected_permission = this.selected_prm.replace(string, string2);
        return this;
    }

    public static List<Permission> valuesCMD() {
        ArrayList<Permission> arrayList = new ArrayList<Permission>();
        for (Permission permission : Permission.values()) {
            if (!permission.name().startsWith("Command_")) continue;
            arrayList.add(permission);
        }
        return arrayList;
    }
}

