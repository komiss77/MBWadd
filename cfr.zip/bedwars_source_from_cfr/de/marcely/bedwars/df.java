/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class df
extends Enum<df> {
    public static final /* enum */ df a = new df();
    public static final /* enum */ df b = new df();
    public static final /* enum */ df c = new df();
    public static final /* enum */ df d = new df();
    private static final /* synthetic */ df[] a;

    static {
        a = new df[]{a, b, c, d};
    }

    public static df[] values() {
        df[] arrdf = a;
        int n2 = arrdf.length;
        df[] arrdf2 = new df[n2];
        System.arraycopy(arrdf, 0, arrdf2, 0, n2);
        return arrdf2;
    }

    public static df valueOf(String string) {
        return Enum.valueOf(df.class, string);
    }
}

