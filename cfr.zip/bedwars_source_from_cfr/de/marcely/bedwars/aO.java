/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerBedEnterEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerBedEnterEvent;

public class aO {
    public static void a(PlayerBedEnterEvent playerBedEnterEvent) {
        Arena arena = s.a(playerBedEnterEvent.getPlayer());
        if (arena != null && (arena.b() == ArenaStatus.f && !ConfigValue.interacting || arena.b() != ArenaStatus.f) && (arena.b() == ArenaStatus.f && !ConfigValue.interacting || arena.b() != ArenaStatus.f)) {
            playerBedEnterEvent.setCancelled(true);
        }
    }
}

