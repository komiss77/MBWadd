/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  cloud.timo.TimoCloud.api.TimoCloudAPI
 *  cloud.timo.TimoCloud.api.objects.ServerObject
 */
package de.marcely.bedwars;

import cloud.timo.TimoCloud.api.TimoCloudAPI;
import cloud.timo.TimoCloud.api.objects.ServerObject;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.cZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.util.s;

public class de
extends cZ {
    private d a;

    @Override
    public cT a() {
        return cT.e;
    }

    @Override
    public void onEnable() {
        Arena arena = s.b(ConfigValue.cloudsystem_arena);
        if (arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        final ServerObject serverObject = TimoCloudAPI.getBukkitAPI().getThisServer();
        this.a = new d(){
            private static /* synthetic */ int[] p;

            @Override
            public void a(Arena arena, d.a a2) {
                switch (1.q()[a2.ordinal()]) {
                    case 3: 
                    case 4: 
                    case 7: {
                        serverObject.setExtra(ConfigValue.cloudsystem_extra.a(arena));
                        break;
                    }
                    case 5: {
                        serverObject.setState(arena.b().b(arena));
                        break;
                    }
                }
            }

            static /* synthetic */ int[] q() {
                if (p != null) {
                    int[] arrn;
                    return arrn;
                }
                int[] arrn = new int[d.a.values().length];
                try {
                    arrn[d.a.a.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.f.ordinal()] = 6;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.c.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.d.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.b.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.g.ordinal()] = 7;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[d.a.e.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                p = arrn;
                return p;
            }
        };
        arena.a(this.a);
    }

    @Override
    public void onDisable() {
        Arena arena = s.b(ConfigValue.cloudsystem_arena);
        if (arena != null) {
            arena.a(this.a);
        }
    }

}

