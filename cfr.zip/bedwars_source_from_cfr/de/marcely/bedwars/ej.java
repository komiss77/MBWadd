/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ej
extends Enum<ej> {
    public static final /* enum */ ej a = new ej();
    public static final /* enum */ ej b = new ej();
    public static final /* enum */ ej c = new ej();
    public static final /* enum */ ej d = new ej();
    private static final /* synthetic */ ej[] a;

    static {
        a = new ej[]{a, b, c, d};
    }

    public static ej[] values() {
        ej[] arrej = a;
        int n2 = arrej.length;
        ej[] arrej2 = new ej[n2];
        System.arraycopy(arrej, 0, arrej2, 0, n2);
        return arrej2;
    }

    public static ej valueOf(String string) {
        return Enum.valueOf(ej.class, string);
    }
}

