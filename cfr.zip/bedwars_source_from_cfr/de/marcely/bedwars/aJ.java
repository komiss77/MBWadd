/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.CraftItemEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.CraftItemEvent;

public class aJ {
    public static void a(CraftItemEvent craftItemEvent) {
        Arena arena = s.a((Player)craftItemEvent.getWhoClicked());
        if (arena != null && (arena.b() != ArenaStatus.f || !ConfigValue.interacting && arena.b() == ArenaStatus.f)) {
            craftItemEvent.setCancelled(true);
        }
    }
}

