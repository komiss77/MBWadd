/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.api.CustomLobbyItem;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.api.ExtraItemListener;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cB;
import de.marcely.bedwars.cC;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.command.arena.f;
import de.marcely.bedwars.command.t;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.LobbyItem;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.game.arena.e;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.library.worldedit.a;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class aV {
    public static Map<Arena, List<Player>> g = new HashMap<Arena, List<Player>>();
    public static Map<Arena, List<Player>> h = new HashMap<Arena, List<Player>>();
    private static List<Player> C = new ArrayList<Player>();

    public static void a(PlayerInteractEvent playerInteractEvent) {
        Object object3;
        Object object;
        s.b.get(a.class).a(playerInteractEvent);
        final Player player = playerInteractEvent.getPlayer();
        Action action = playerInteractEvent.getAction();
        if (player == null || action == null) {
            return;
        }
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            object3 = cA.E.get((Object)player);
            Object object2 = object = object3 != null ? ((cz)object3).getArena() : null;
            if (object != null) {
                playerInteractEvent.setCancelled(true);
                SpectatorItem spectatorItem = cB.a(player.getInventory().getHeldItemSlot());
                if (spectatorItem != null) {
                    if (((cz)object3).a() == SpectateReason.DEATH && !spectatorItem.a().a(player, ((cz)object3).a())) {
                        return;
                    }
                    spectatorItem.a().onUse(player, spectatorItem, (de.marcely.bedwars.api.Arena)object);
                }
                return;
            }
        }
        if ((object3 = s.a(player)) == null) {
            String object22;
            if (action == Action.RIGHT_CLICK_BLOCK) {
                object = s.a(playerInteractEvent.getClickedBlock());
                if (object != null) {
                    s.g((Arena)object);
                    if (!C.contains((Object)player)) {
                        String string = s.b(player, (Arena)object);
                        if (string != null) {
                            player.sendMessage(string);
                        }
                        C.add(player);
                        new BukkitRunnable(){

                            public void run() {
                                C.remove((Object)player);
                            }
                        }.runTaskLater((Plugin)MBedwars.a, 20L);
                    }
                    return;
                }
                object = s.a(playerInteractEvent.getClickedBlock());
                if (object != null) {
                    if (!C.contains((Object)player)) {
                        t.a((CommandSender)player, (c)object);
                        C.add(player);
                        new BukkitRunnable(){

                            public void run() {
                                C.remove((Object)player);
                            }
                        }.runTaskLater((Plugin)MBedwars.a, 40L);
                    }
                    return;
                }
            }
            if ((object = playerInteractEvent.getItem()) != null && (object22 = i.b((ItemStack)object)) != null && object.getType() == Material.CHEST && object22.equals(s.X)) {
                f.a.a((CommandSender)player, "bw", "", new String[0]);
                playerInteractEvent.setCancelled(true);
                return;
            }
        }
        if (object3 != null) {
            if (playerInteractEvent.getAction() == Action.PHYSICAL && playerInteractEvent.getClickedBlock() != null && (object = playerInteractEvent.getClickedBlock().getType()) == Material.SOIL && !ConfigValue.destroyable_farmland) {
                playerInteractEvent.setCancelled(true);
                return;
            }
            if (((Arena)object3).b() == ArenaStatus.f) {
                if (player.getItemInHand() == null || player.getItemInHand().getType() == null || player.getItemInHand().getType() == Material.AIR) {
                    if (!ConfigValue.interacting && playerInteractEvent.getClickedBlock() != null && k.c(playerInteractEvent.getClickedBlock().getType())) {
                        playerInteractEvent.setCancelled(true);
                    }
                    return;
                }
                if (!ConfigValue.bed_interactable && playerInteractEvent.getClickedBlock() != null && ((Arena)object3).a().a(playerInteractEvent.getClickedBlock().getLocation()) != null) {
                    playerInteractEvent.setCancelled(true);
                    return;
                }
                if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                    ExtraItem extraItem;
                    object = playerInteractEvent.getItem();
                    if (object == null || object.getType() == null) {
                        return;
                    }
                    if (object.getType() == Material.ENDER_PEARL) {
                        s.a(player, Achievement.h);
                    }
                    if ((extraItem = s.a(player, (ItemStack)object)) == null) {
                        if (!ConfigValue.interacting && playerInteractEvent.getClickedBlock() != null && (k.c(playerInteractEvent.getClickedBlock().getType()) || ((Arena)object3).a().a(playerInteractEvent.getClickedBlock().getLocation()) != null && playerInteractEvent.getClickedBlock().getType() == Material.CAKE_BLOCK)) {
                            playerInteractEvent.setCancelled(true);
                        }
                        return;
                    }
                    PlayerUseExtraItemEvent playerUseExtraItemEvent = new PlayerUseExtraItemEvent(extraItem, (de.marcely.bedwars.api.Arena)object3, (PlayerEvent)playerInteractEvent, (ItemStack)object);
                    Bukkit.getPluginManager().callEvent((Event)playerUseExtraItemEvent);
                    if (playerUseExtraItemEvent.isCancelled()) {
                        return;
                    }
                    playerInteractEvent.setCancelled(true);
                    for (ExtraItemListener extraItemListener : extraItem.getListeners()) {
                        try {
                            extraItemListener.onUse(playerUseExtraItemEvent);
                            if (!playerUseExtraItemEvent.isCancelled()) continue;
                            playerInteractEvent.setCancelled(false);
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }
                }
            } else if (((Arena)object3).b() == ArenaStatus.e) {
                playerInteractEvent.setCancelled(true);
                if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK || playerInteractEvent.getItem() == null || playerInteractEvent.getItem().getType() == null) {
                    return;
                }
                player.updateInventory();
                object = s.a(playerInteractEvent.getPlayer().getInventory().getHeldItemSlot(), (Arena)object3);
                if (object != null) {
                    if (((LobbyItem)object).getCommands().size() >= 1) {
                        for (String string : ((LobbyItem)object).getCommands()) {
                            player.performCommand(string);
                        }
                    }
                    if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.e) {
                        Sound.LOBBY_ACHIEVEMENTS_OPEN.play(player);
                        final Future<UserAchievements> future = UserAchievements.a(player.getUniqueId());
                        s.a(future, new Runnable(){

                            @Override
                            public void run() {
                                try {
                                    UserAchievements userAchievements = (UserAchievements)future.get();
                                    GUI gUI = new GUI(b.a(Language.GUI_Achievements_Title).f((CommandSender)player), 0);
                                    for (Achievement achievement : s.ac) {
                                        ItemStack itemStack = userAchievements.has(achievement) ? i.a(i.a(ConfigValue.gui_achievements_material_earned.clone(), (Object)ChatColor.GREEN + achievement.a((CommandSender)player)), new String[]{(Object)ChatColor.DARK_PURPLE + " " + achievement.c((CommandSender)player)}) : i.a(i.a(ConfigValue.gui_achievements_material_unearned.clone(), (Object)ChatColor.RED + achievement.a((CommandSender)player)), new String[]{(Object)ChatColor.GRAY + (Object)ChatColor.BOLD + " ????"});
                                        gUI.addItem(new GUIItem(itemStack){

                                            @Override
                                            public void onClick(Player player, boolean bl2, boolean bl3) {
                                                Sound.LOBBY_ACHIEVEMENTS_CLICK.play(player);
                                            }
                                        });
                                        if (ConfigValue.gui_achievements_centered) {
                                            gUI.centerAtYAll(GUI.CenterFormatType.Normal);
                                        }
                                        gUI.setBackground(new DecGUIItem(i.a(ConfigValue.gui_achievements_backgroundmaterial, " ")));
                                    }
                                    gUI.open(player);
                                }
                                catch (InterruptedException | ExecutionException exception) {
                                    exception.printStackTrace();
                                }
                            }

                        });
                    } else if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.d && s.hasPermission((CommandSender)player, Permission.Command_Forcestart) && ((Arena)object3).a != null && !((Arena)object3).a.I()) {
                        if (!((Arena)object3).f(player)) {
                            s.a((CommandSender)player, b.a(Language.TooLess_Players).a("arena", ((Arena)object3).getDisplayName()));
                        }
                    } else if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.a) {
                        Sound.LOBBY_LEAVE.play(player);
                        ((Arena)object3).a(KickReason.b, player);
                    } else if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.b) {
                        Sound.LOBBY_SELECTTEAM_OPEN.play(player);
                        aV.a((Arena)object3, player);
                    } else if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.c) {
                        Sound.LOBBY_VOTEARENA_OPEN.play(player);
                        aV.b((Arena)object3, player);
                    } else if (((LobbyItem)object).a().getType() == LobbyItem.LobbySpecialType.f) {
                        CustomLobbyItem customLobbyItem = s.a(((LobbyItem)object).a().getName());
                        if (customLobbyItem != null) {
                            customLobbyItem.onUse(player);
                        } else {
                            player.sendMessage((Object)ChatColor.DARK_RED + "WARNING (Please send this error message to an administrator): " + (Object)ChatColor.RED + "The special-item '" + ((LobbyItem)object).a().getName() + "' doesn't exist!");
                        }
                    }
                }
            } else if (((Arena)object3).b() == ArenaStatus.h) {
                playerInteractEvent.setCancelled(true);
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public static void a(final Arena arena, final Player player) {
        void var4_8;
        if (player.getItemInHand() == null || !player.getItemInHand().hasItemMeta()) {
            return;
        }
        List<Team> list = arena.a().r();
        GUI gUI = new GUI(b.a(Language.GUI_SelectTeam_Title).f((CommandSender)player), 0){

            @Override
            public void onClose(Player player) {
                List<Player> list = g.get(arena);
                list.remove((Object)player);
            }
        };
        for (final Team object2 : list) {
            ItemStack itemStack = ConfigValue.gui_selectteam_teammaterial;
            itemStack = i.a(itemStack, object2);
            itemStack = Version.a().removeAttributes(itemStack);
            itemStack = i.a(itemStack, (Object)object2.getChatColor() + object2.a((CommandSender)player, true));
            ArrayList<String> arrayList = new ArrayList<String>();
            String string = "";
            for (Player player2 : arena.a(object2)) {
                string = String.valueOf(string) + ConfigValue.gui_selectteam_teammaterial_lore_eachplayer.replace("{name}", s.getPlayerDisplayName(player2)) + "\\n";
            }
            for (String string2 : ConfigValue.gui_selectteam_teammaterial_lore) {
                arrayList.add(Language.stringToChatColor(string2).replace("{eachplayer}", string).replace("{players}", "" + arena.a(object2).size()).replace("{allplayers}", "" + arena.getPlayers().size()).replace("{maxplayers}", "" + arena.getMaxPlayers()).replace("{maxplayersperteam}", "" + arena.getPerTeamPlayers()).replace("{teams}", "" + arena.a().r().size()));
            }
            itemStack = i.a(itemStack, arrayList);
            if (arena.a(player) != null && arena.a(player) == object2) {
                itemStack = Version.a().addGlow(itemStack);
            }
            final Arena arena2 = arena;
            gUI.addItem(new GUIItem(itemStack){

                @Override
                public void onClick(Player player3, boolean bl2, boolean bl3) {
                    if (arena2.getPlayers().contains((Object)player)) {
                        arena2.c(player, object2);
                    }
                    for (Player player2 : new ArrayList(g.get(arena))) {
                        aV.a(arena, player2);
                    }
                }
            });
        }
        if (ConfigValue.gui_selectteam_centered) {
            gUI.centerAtYAll(GUI.CenterFormatType.Normal);
        }
        gUI.setBackground(new DecGUIItem(i.a(ConfigValue.gui_selectteam_backgroundmaterial, " ")));
        List<Player> list2 = g.get(arena);
        if (list2 == null) {
            ArrayList arrayList = new ArrayList();
            g.put(arena, arrayList);
        }
        var4_8.add(player);
        gUI.open(player);
    }

    public static void b(final Arena arena, final Player player) {
        GUI gUI = new GUI(b.a(Language.GUI_VoteArena_Title).f((CommandSender)player), 1){

            @Override
            public void onClose(Player player) {
                List<Player> list = h.get(arena);
                list.remove((Object)player);
            }
        };
        final Arena.a a2 = arena.a(player);
        for (final Arena.a a3 : arena.I) {
            ItemStack itemStack = i.a(a3.arena.getIcon(), (Object)ChatColor.YELLOW + a3.arena.a().r().size() + (Object)ChatColor.GOLD + "x" + (Object)ChatColor.YELLOW + a3.arena.getTeamPlayers(), (Object)ChatColor.GOLD + b.a(Language.ArenaVoting_MinPlayers).f((CommandSender)player) + " " + (Object)ChatColor.YELLOW + a3.arena.k(), "", b.a(Language.GUI_VoteArena_Votes).a("number", "" + a3.P.size()).f((CommandSender)player));
            if (a2 != null && a2.equals(a3)) {
                itemStack = Version.a().addGlow(itemStack);
            }
            gUI.addItem(new GUIItem(itemStack){

                @Override
                public void onClick(Player player3, boolean bl2, boolean bl3) {
                    boolean bl4 = false;
                    if (a2 != null) {
                        if (a2.arena.equals(a3.arena)) {
                            bl4 = true;
                            Sound.LOBBY_VOTEARENA_ALREADYVOTED.play(player);
                        }
                        a2.P.remove((Object)player);
                    }
                    a3.P.add(player);
                    if (!bl4) {
                        Sound.LOBBY_VOTEARENA_VOTE.play(player);
                    }
                    for (Player player2 : new ArrayList(h.get(arena))) {
                        aV.b(arena, player2);
                    }
                }
            });
        }
        for (int i2 = 0; i2 < ConfigValue.arenavoting_maxarenas - arena.I.size(); ++i2) {
            gUI.addItem(new GUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 14), (Object)ChatColor.RED + "\u4e42")){

                @Override
                public void onClick(Player player2, boolean bl2, boolean bl3) {
                    Sound.LOBBY_VOTEARENA_NOTVOTEABLE.play(player);
                }
            });
        }
        gUI.centerAtYAll(GUI.CenterFormatType.Beautiful);
        gUI.setBackground(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE), " ")));
        List<Player> list = h.get(arena);
        if (list == null) {
            list = new ArrayList<Player>();
            h.put(arena, list);
        }
        list.add(player);
        gUI.open(player);
    }

}

