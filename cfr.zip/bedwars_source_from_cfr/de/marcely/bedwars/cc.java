/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;

public class cc
extends bS<Void> {
    public static cc a = new cc();

    @Override
    public bP.c a() {
        return bP.c.d;
    }

    @Override
    public String a(Void void_) {
        return this.c(null);
    }

    @Override
    public String c(Arena arena) {
        return s.u();
    }
}

