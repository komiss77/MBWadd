/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.dev.nickplugin.api.NickManager
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.dp;
import net.dev.nickplugin.api.NickManager;
import org.bukkit.entity.Player;

public class dm
extends dp {
    @Override
    public cT a() {
        return cT.k;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String c(Player player) {
        NickManager nickManager = new NickManager(player);
        return nickManager.isNicked() ? nickManager.getNickName() : null;
    }

    @Override
    public String d(Player player) {
        NickManager nickManager = new NickManager(player);
        return nickManager.isNicked() ? nickManager.getRealName() : null;
    }
}

