/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cm;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.m;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class cl
extends cm {
    public static cl a = new cl();

    @Override
    public String a(m m2) {
        Team team = m2.getTeam();
        if (team == null) {
            return b.a(Language.Spectator).f((CommandSender)m2.getPlayer());
        }
        return m2.getTeam().getName();
    }
}

