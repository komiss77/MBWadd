/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.mysql.jdbc.Connection
 */
package de.marcely.bedwars;

import com.mysql.jdbc.Connection;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class ah {
    private String host;
    private String database;
    private String username;
    private String password;
    private int port;
    private Connection a = null;
    private static ah a = new ah();

    public ah() {
    }

    public ah(String string, int n2, String string2, String string3, String string4) {
        this.host = string;
        this.port = n2;
        this.database = string2;
        this.username = string3;
        this.password = string4;
    }

    public boolean isConnected() {
        try {
            return this.a != null && !this.a.isClosed();
        }
        catch (Exception exception) {
            return false;
        }
    }

    public String getHost() {
        return this.host;
    }

    public int getPort() {
        return this.port;
    }

    public String getDatabase() {
        return this.database;
    }

    public Connection a() {
        try {
            if (!this.isConnected()) {
                this.connect();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return this.a;
    }

    public boolean connect() throws SQLException {
        if (!this.isConnected()) {
            this.a = (Connection)DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database + "?autoReconnect=true", this.username, this.password);
            return true;
        }
        return false;
    }

    public boolean close() {
        if (this.isConnected()) {
            try {
                this.a.close();
            }
            catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
            this.a = null;
            return true;
        }
        return false;
    }

    public void k(String string, String string2) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [createTableIfNotExists]");
            return;
        }
        PreparedStatement preparedStatement = this.a.prepareStatement("CREATE TABLE IF NOT EXISTS " + string + " (" + string2 + ")");
        preparedStatement.execute();
        preparedStatement.close();
    }

    public void a(String string, String string2, String string3, String string4) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [addColoumToTableIfNotExists]");
            return;
        }
        try {
            PreparedStatement preparedStatement = this.a.prepareStatement("ALTER TABLE " + string + " ADD " + string2 + " " + string3 + " NOT NULL DEFAULT '" + string4 + "'");
            preparedStatement.execute();
            preparedStatement.close();
        }
        catch (SQLException sQLException) {
            // empty catch block
        }
    }

    public void a(String string, String string2, String string3) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [setStatementsInTable]");
            return;
        }
        PreparedStatement preparedStatement = this.a.prepareStatement("INSERT INTO " + string + " (" + string2 + ") VALUES (" + string3 + ")");
        preparedStatement.execute();
        preparedStatement.close();
    }

    public void a(String string, String string2, String string3, String string4, String string5) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [updateStatementInTable]");
            return;
        }
        PreparedStatement preparedStatement = this.a.prepareStatement("UPDATE " + string + " SET " + string4 + " = '" + string5 + "' WHERE " + string2 + " = '" + string3 + "'");
        preparedStatement.execute();
        preparedStatement.close();
    }

    public boolean a(String string, String string2, String string3) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [existsInTable]");
            return false;
        }
        PreparedStatement preparedStatement = this.a.prepareStatement("SELECT COUNT(*) FROM " + string + " WHERE " + string2 + "='" + string3 + "'");
        ResultSet resultSet = preparedStatement.executeQuery();
        boolean bl2 = false;
        if (resultSet.next()) {
            bl2 = resultSet.getInt(1) >= 1;
        }
        resultSet.close();
        preparedStatement.close();
        return bl2;
    }

    public List<String> a(String string, String string2) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [getValuesInTable]");
            return null;
        }
        PreparedStatement preparedStatement = this.a.prepareStatement("SELECT " + string2 + " FROM " + string);
        ResultSet resultSet = preparedStatement.executeQuery();
        ArrayList<String> arrayList = new ArrayList<String>();
        while (resultSet.next()) {
            arrayList.add(resultSet.getString(1));
        }
        resultSet.close();
        preparedStatement.close();
        return arrayList;
    }

    public static void onEnable() {
        if (ConfigValue.sql_enabled) {
            a = new ah(ConfigValue.sql_host, ConfigValue.sql_port, ConfigValue.sql_database, ConfigValue.sql_user, ConfigValue.sql_password);
            try {
                a.connect();
                d.f("MySQL is now successfully enabled.");
            }
            catch (SQLException sQLException) {
                d.a(sQLException);
            }
        }
    }

    public static void onDisable() {
        if (ah.s()) {
            a.close();
        }
    }

    public static boolean s() {
        return a != null && a.isConnected();
    }

    public static ah a() {
        return a;
    }
}

