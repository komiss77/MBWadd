/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Sheep
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.util.s;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;

public class av {
    public static void a(b b2) {
        Arena arena = s.a(b2.loc);
        if (arena != null && arena.b() == ArenaStatus.f) {
            Object object;
            h h22;
            b2.a = false;
            for (Entity block2 : de.marcely.bedwars.util.b.getNearbyEntities(b2.loc, 3.0, 3.0, 3.0)) {
                if (block2.getType() != EntityType.SHEEP) continue;
                ((Sheep)block2).setHealth(0.0);
            }
            Block block = b2.loc.getBlock();
            boolean bl2 = false;
            Player player = null;
            XYZ xYZ = XYZ.valueOf(block.getLocation());
            xYZ.floor();
            Block block2 = arena.o.entrySet().iterator();
            while (block2.hasNext()) {
                object = block2.next();
                if (!XYZ.ofString((String)object.getKey()).equals(xYZ)) continue;
                bl2 = true;
                player = arena.o.remove(object.getKey());
                break;
            }
            object = b2.A.iterator();
            while (object.hasNext()) {
                block2 = (Block)object.next();
                if (block2.getType() != ConfigValue.bed_block) continue;
                h22 = arena.a();
                for (Team team : h22.r()) {
                    if (h22.a(team) == null || !s.a(XYZ.valueOf(block2.getLocation()), h22.a(team))) continue;
                    object.remove();
                    if (!ConfigValue.bed_onlydestroyablewith_tnt || !bl2) continue;
                    if (ConfigValue.ownbed_destroyable || !ConfigValue.ownbed_destroyable && team != arena.a(player)) {
                        block2.setType(Material.AIR);
                        arena.a(player, block.getLocation(), team);
                        s.a(block, (double)(ConfigValue.bed_block.name().contains("BED") ? 2 : 1));
                        continue;
                    }
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotAllowed_BedDestroy));
                }
            }
            for (h h22 : block2 = arena.a().a()) {
                Block block3 = h22.getRelative(BlockFace.DOWN);
                b2.A.remove((Object)block3);
            }
            object = b2.A.iterator();
            while (object.hasNext()) {
                h22 = object.next();
                if (!ConfigValue.tnt_canbreakblocks) {
                    object.remove();
                    continue;
                }
                if (ConfigValue.tnt_canbreakblocks_breakby_player && !arena.a((Block)h22)) {
                    object.remove();
                    continue;
                }
                VarParticle.PARTICLE_SMOKE.play(b2.loc.getWorld(), h22.getLocation().add(0.0, 1.0, 0.0), 1);
            }
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a();
        public static final /* enum */ a b = new a();
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{a, b};
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

    public static class b {
        public final a c;
        public final List<Block> A;
        public final Location loc;
        public Boolean a = false;

        public b(a a2, List<Block> list, Location location) {
            this.c = a2;
            this.A = list;
            this.loc = location;
        }
    }

}

