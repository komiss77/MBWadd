/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cp
extends ct {
    public static cp a = new cp();

    public String b(c c2) {
        return "" + c2.getDeaths();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

