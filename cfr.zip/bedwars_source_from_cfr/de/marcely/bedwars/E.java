/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.UUID;

public class E
extends NormalPacket {
    public UUID uuid;
    public String name;

    @Override
    public byte getPacketID() {
        return 48;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.uuid.toString());
        bufferedWriteStream.writeString(this.name);
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.uuid = UUID.fromString(bufferedReadStream.readString());
        this.name = bufferedReadStream.readString();
    }
}

