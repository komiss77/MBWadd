/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.A;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.f;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.i;
import de.marcely.bedwars.j;
import de.marcely.bedwars.o;
import de.marcely.bedwars.p;
import de.marcely.bedwars.q;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import java.net.DatagramPacket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class g {
    public Map<UUID, Arena> c = new HashMap<UUID, Arena>();
    private Plugin plugin;
    private f a;
    private a a = a.b;

    public g(Plugin plugin, f f2) {
        if (f2.h()) {
            this.plugin = plugin;
            this.a = f2;
            this.open();
        } else {
            this.a = a.f;
            d.d("Failed to create communication: channel isn't registred");
        }
    }

    private void open() {
        this.a = a.c;
        this.a(new i(new A(ConfigValue.bungeecord_subchannel), this.a){

            @Override
            public void done() {
                Bukkit.getScheduler().scheduleSyncDelayedTask(g.this.plugin, new Runnable(){

                    @Override
                    public void run() {
                        if (g.this.a() == a.c) {
                            d.d("Got no answer from channel: Disabling channel. Retrying in 10 seconds");
                            g.a(g.this, a.d);
                            new BukkitRunnable(){

                                public void run() {
                                    g.this.open();
                                }
                            }.runTaskLater(g.this.plugin, 200L);
                        }
                    }

                }, 100L);
            }

        });
    }

    public void a(j j2) {
        j2.a(this.a);
    }

    private void a(i i2) {
        i2.a().c(i2);
    }

    public void a(DatagramPacket datagramPacket) {
        if (this.a().i()) {
            String string = new String(datagramPacket.getData());
            if ((string = string.substring(0, datagramPacket.getLength())).length() >= 1) {
                String[] arrstring = string.split("/");
                if (s.isInteger(arrstring[0])) {
                    j.a a2 = j.a.a(Integer.valueOf(arrstring[0]));
                    if (a2 == j.a.a) {
                        o o2;
                        if (this.a() == a.c && (o2 = o.a(string)) != null) {
                            MBedwars.a.setName(o2.f());
                            for (Arena arena : s.af) {
                                this.a(new q(arena));
                                this.a(new q(arena));
                            }
                            this.a = a.e;
                            d.e("Got answer from channel: Channel is now running");
                        }
                    } else if (a2 != j.a.b && a2 == j.a.c) {
                        final String string2 = string;
                        Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)MBedwars.a, new Runnable(){

                            @Override
                            public void run() {
                                p p2 = p.a(string2);
                                if (p2 != null) {
                                    Player player = b.getPlayer(p2.getUUID());
                                    if (player == null) {
                                        g.this.c.put(p2.getUUID(), p2.getArena());
                                    } else {
                                        Arena arena = p2.getArena();
                                        String string = null;
                                        if (arena != null && !arena.getPlayers().contains((Object)player)) {
                                            string = s.b(player, arena);
                                        }
                                        if (string != null) {
                                            player.sendMessage(string);
                                            MBedwars.a.c(player);
                                        }
                                    }
                                }
                            }
                        }, 10L);
                    }
                } else {
                    d.d("Failed to open packet: Received a non-numeric packet");
                }
            }
        }
    }

    public Plugin getPlugin() {
        return this.plugin;
    }

    public f a() {
        return this.a;
    }

    public a a() {
        return this.a;
    }

    static /* synthetic */ void a(g g2, a a2) {
        g2.a = a2;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a b = new a(false);
        public static final /* enum */ a c = new a(true);
        public static final /* enum */ a d = new a(false);
        public static final /* enum */ a e = new a(true);
        public static final /* enum */ a f = new a(false);
        private boolean d;
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{b, c, d, e, f};
        }

        private a(boolean bl2) {
            this.d = bl2;
        }

        public boolean i() {
            return this.d;
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

