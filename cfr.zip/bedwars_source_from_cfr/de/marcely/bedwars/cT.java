/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cO;
import de.marcely.bedwars.cP;
import de.marcely.bedwars.cQ;
import de.marcely.bedwars.cR;
import de.marcely.bedwars.cU;
import de.marcely.bedwars.cV;
import de.marcely.bedwars.cW;
import de.marcely.bedwars.cX;
import de.marcely.bedwars.cY;
import de.marcely.bedwars.da;
import de.marcely.bedwars.db;
import de.marcely.bedwars.dc;
import de.marcely.bedwars.dd;
import de.marcely.bedwars.de;
import de.marcely.bedwars.dh;
import de.marcely.bedwars.di;
import de.marcely.bedwars.dj;
import de.marcely.bedwars.dk;
import de.marcely.bedwars.dl;
import de.marcely.bedwars.dm;
import de.marcely.bedwars.dn;
import de.marcely.bedwars.do;
import de.marcely.bedwars.dq;
import de.marcely.bedwars.dr;
import de.marcely.bedwars.ds;
import de.marcely.bedwars.dt;
import de.marcely.bedwars.library.worldedit.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class cT
extends Enum<cT> {
    public static final /* enum */ cT a = new cT("CaveCloud", cY.class, true);
    public static final /* enum */ cT b = new cT("CloudNetAPI", da.class, true);
    public static final /* enum */ cT c = new cT("CloudNet-Bridge", db.class, true);
    public static final /* enum */ cT d = new cT("CloudSystem", dc.class, true);
    public static final /* enum */ cT e = new cT("TimoCloud", de.class, true);
    public static final /* enum */ cT f = new cT("ReformCloudAPISpigot", dd.class, true);
    public static final /* enum */ cT g = new cT("AutoNicker", dk.class);
    public static final /* enum */ cT h = new cT("NickNamer", dq.class);
    public static final /* enum */ cT i = new cT("VIPHide", dr.class);
    public static final /* enum */ cT j = new cT("BetterNick", dl.class);
    public static final /* enum */ cT k = new cT("EazyNick", dm.class);
    public static final /* enum */ cT l = new cT("NickAPI", do.class);
    public static final /* enum */ cT m = new cT("NametagEdit", dn.class);
    public static final /* enum */ cT n = new cT("PlaceholderAPI", dt.class);
    public static final /* enum */ cT o = new cT("MVdWPlaceholderAPI", ds.class);
    public static final /* enum */ cT p = new cT("PvPLevels", dj.class);
    public static final /* enum */ cT q = new cT("DKCoins", dh.class);
    public static final /* enum */ cT r = new cT("NickAPI", di.class);
    public static final /* enum */ cT s = new cT("GroupManager", cP.class);
    public static final /* enum */ cT t = new cT("FeatherBoard", cQ.class);
    public static final /* enum */ cT u = new cT("ProtocolLib", cV.class);
    public static final /* enum */ cT v = new cT("Vault", cW.class);
    public static final /* enum */ cT w = new cT("Spigot-Party-API-PAF", cU.class);
    public static final /* enum */ cT x = new cT("AdvancedReplay", cO.class);
    public static final /* enum */ cT y = new cT("ReplaySystem", cX.class, true);
    public static final /* enum */ cT z = new cT("RegionEdit", a.class, false, true);
    private final String pluginName;
    private final Class<? extends cR> clazz;
    private final boolean X;
    private final boolean Y;
    private static final /* synthetic */ cT[] a;

    static {
        a = new cT[]{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z};
    }

    private cT(String string2, Class<? extends cR> class_) {
        this(string2, class_, false, false);
    }

    private cT(String string2, Class<? extends cR> class_, boolean bl2) {
        this(string2, class_, bl2, false);
    }

    private cT(String string2, Class<? extends cR> class_, boolean bl2, boolean bl3) {
        this.pluginName = string2;
        this.clazz = class_;
        this.X = bl2;
        this.Y = bl3;
    }

    public String getPluginName() {
        return this.pluginName;
    }

    public Class<? extends cR> getClazz() {
        return this.clazz;
    }

    public boolean O() {
        return this.X;
    }

    public boolean P() {
        return this.Y;
    }

    public static cT[] values() {
        cT[] arrcT = a;
        int n2 = arrcT.length;
        cT[] arrcT2 = new cT[n2];
        System.arraycopy(arrcT, 0, arrcT2, 0, n2);
        return arrcT2;
    }

    public static cT valueOf(String string) {
        return Enum.valueOf(cT.class, string);
    }
}

