/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bZ;
import de.marcely.bedwars.game.arena.Arena;

public class bX
extends bZ {
    public static bX a = new bX();

    @Override
    public bP.c a() {
        return bP.c.a;
    }

    @Override
    public String c(Arena arena) {
        return "" + arena.getPerTeamPlayers();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.c((Arena)object);
    }
}

