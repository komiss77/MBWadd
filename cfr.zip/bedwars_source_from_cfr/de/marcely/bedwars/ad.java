/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

@Deprecated
public class ad {
}

