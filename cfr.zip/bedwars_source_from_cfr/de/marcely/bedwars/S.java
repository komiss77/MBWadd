/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.bedwars.P;
import de.marcely.bedwars.Q;
import de.marcely.bedwars.R;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class S
extends Enum<S> {
    public static final /* enum */ S a = new S();
    public static final /* enum */ S b = new S();
    private static /* synthetic */ int[] b;
    private static final /* synthetic */ S[] a;

    static {
        a = new S[]{a, b};
    }

    public R a() {
        switch (S.b()[this.ordinal()]) {
            case 1: {
                return new Q();
            }
            case 2: {
                return new P();
            }
        }
        return null;
    }

    @Nullable
    public static S a(String string) {
        for (S s2 : S.values()) {
            if (!s2.name().equals(string)) continue;
            return s2;
        }
        return null;
    }

    public static S[] values() {
        S[] arrs = a;
        int n2 = arrs.length;
        S[] arrs2 = new S[n2];
        System.arraycopy(arrs, 0, arrs2, 0, n2);
        return arrs2;
    }

    public static S valueOf(String string) {
        return Enum.valueOf(S.class, string);
    }

    static /* synthetic */ int[] b() {
        if (b != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[S.values().length];
        try {
            arrn[S.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[S.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        b = arrn;
        return b;
    }
}

