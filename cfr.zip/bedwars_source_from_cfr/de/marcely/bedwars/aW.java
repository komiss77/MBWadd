/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerInteractAtEntityEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.aX;
import de.marcely.bedwars.as;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public class aW {
    public static void a(PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
        if (!as.u) {
            PlayerInteractEntityEvent playerInteractEntityEvent = new PlayerInteractEntityEvent(playerInteractAtEntityEvent.getPlayer(), playerInteractAtEntityEvent.getRightClicked());
            aX.a(playerInteractEntityEvent);
            if (playerInteractEntityEvent.isCancelled()) {
                playerInteractAtEntityEvent.setCancelled(true);
            }
        }
    }
}

