/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cR;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;

public abstract class dp
extends cR {
    @Nullable
    public abstract String c(Player var1);

    @Nullable
    public abstract String d(Player var1);
}

