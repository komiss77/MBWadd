/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.S;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class R {
    public abstract S a();

    public abstract void write(BufferedWriteStream var1);

    public abstract void read(BufferedReadStream var1);
}

