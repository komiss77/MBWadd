/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  me.BukkitPVP.VIPHide.VIPHide
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.dp;
import me.BukkitPVP.VIPHide.VIPHide;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class dr
extends dp {
    private VIPHide a;

    @Override
    public cT a() {
        return cT.i;
    }

    @Override
    public void onEnable() {
        this.a = (VIPHide)Bukkit.getPluginManager().getPlugin("VIPHide");
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String c(Player player) {
        return this.a.isDisguised(player) ? this.a.getName(player) : null;
    }

    @Override
    public String d(Player player) {
        return null;
    }
}

