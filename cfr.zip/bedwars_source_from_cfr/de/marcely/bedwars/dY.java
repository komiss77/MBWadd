/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cR;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.cV;
import de.marcely.bedwars.dW;
import de.marcely.bedwars.dX;
import de.marcely.bedwars.dZ;
import de.marcely.bedwars.eb;
import de.marcely.bedwars.ec;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;

public class dY {
    public static final String P = "MBedwars_NI";
    private final Player player;
    private final dZ a;
    private List<eb> listeners = new ArrayList<eb>();
    private long l = 0L;

    public dY(Player player) {
        this.player = player;
        this.a = s.b.a((Class<? extends cR>)cV.class) ? new ec(this) : (Version.a().getVersionNumber() >= 8 ? new dX(this) : new dW(this));
    }

    public boolean a(eb eb2) {
        if (eb2 == null) {
            return false;
        }
        return this.listeners.add(eb2);
    }

    public boolean b(eb eb2) {
        if (eb2 == null) {
            return false;
        }
        return this.listeners.remove(eb2);
    }

    public boolean isInjected() {
        if (!this.player.isOnline()) {
            return false;
        }
        return this.a.isInjected();
    }

    public boolean inject() {
        if (!this.player.isOnline()) {
            return false;
        }
        return this.a.inject();
    }

    public boolean Y() {
        if (!this.player.isOnline()) {
            return false;
        }
        new MThread(MThread.ThreadType.g, this.player.getName()){

            @Override
            public void run() {
                dY.this.a.Y();
            }
        }.start();
        return true;
    }

    public void d(int n2) {
        if (System.currentTimeMillis() - this.l < 200L) {
            return;
        }
        this.l = System.currentTimeMillis();
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            eb2.a(this.player, n2);
        }
    }

    public void e(int n2) {
        if (System.currentTimeMillis() - this.l < 200L) {
            return;
        }
        this.l = System.currentTimeMillis();
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            eb2.b(this.player, n2);
        }
    }

    public String[] c(String string) {
        List<String> list = null;
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            list = eb2.a(this.player, string);
        }
        return list != null ? list.toArray(new String[list.size()]) : null;
    }

    public boolean a(float f2, int n2, float f3) {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            if (!eb2.a(this.player, f2, n2, f3)) continue;
            return true;
        }
        return false;
    }

    public boolean b(float f2) {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            if (!eb2.a(this.player, f2)) continue;
            return true;
        }
        return false;
    }

    public boolean a(long l2, long l3) {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            if (!eb2.a(this.player, l2, l3)) continue;
            return true;
        }
        return false;
    }

    public boolean a(int n2, Object object, Object object2) {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            if (!eb2.a(this.player, n2, object, object2)) continue;
            return true;
        }
        return false;
    }

    public void a(int n2, int n3, boolean bl2) {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            eb2.a(this.player, n2, n3, bl2);
        }
    }

    public boolean Z() {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            if (!eb2.a(this.player)) continue;
            return true;
        }
        return false;
    }

    public void ad() {
        for (int i2 = this.listeners.size() - 1; i2 >= 0; --i2) {
            eb eb2 = this.listeners.get(i2);
            eb2.b(this.player);
        }
    }

    public Player getPlayer() {
        return this.player;
    }

    public dZ a() {
        return this.a;
    }

}

