/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.arena.Arena;
import java.sql.SQLException;
import org.bukkit.Bukkit;

public class d {
    public static void a(String string) {
        d.b("");
        d.b("#########################");
        for (String string2 : string.split("\n")) {
            d.b("# " + string2);
        }
        d.b("#########################");
        d.b("");
    }

    public static void a(String string, String string2) {
        d.c(string, "");
        d.c(string, "#########################");
        for (String string3 : string2.split("\n")) {
            d.c(string, "# " + string3);
        }
        d.c(string, "#########################");
        d.c(string, "");
    }

    public static void b(String string) {
        Bukkit.getLogger().warning("[MBedwars] " + string);
    }

    public static void c(String string) {
        Bukkit.getLogger().info("[MBedwars] " + string);
    }

    private static void b(String string, String string2) {
        Bukkit.getLogger().info("[MBedwars-" + string + "] " + string2);
    }

    private static void c(String string, String string2) {
        Bukkit.getLogger().warning("[MBedwars-" + string + "] " + string2);
    }

    public static void a(String string, Arena arena) {
        d.f(string, arena.getName());
    }

    public static void b(String string, Arena arena) {
        d.g(string, arena.getName());
    }

    public static void d(String string, String string2) {
        d.c("Config-" + string2, string);
    }

    public static void e(String string, String string2) {
        d.b("Config-" + string2, string);
    }

    public static void f(String string, String string2) {
        d.c("Arena-" + string2, string);
    }

    public static void g(String string, String string2) {
        d.b("Arena-" + string2, string);
    }

    public static void a(String string, DropType dropType) {
        d.c("Itemspawner-" + dropType.getName(), string);
    }

    public static void d(String string) {
        d.c("BungeeCord", string);
    }

    public static void e(String string) {
        d.b("BungeeCord", string);
    }

    public static void f(String string) {
        d.b("SQL", string);
    }

    public static void g(String string) {
        d.c("SQL", string);
    }

    public static void a(SQLException sQLException) {
        d.g("");
        d.g("An error occured with SQL: ");
        sQLException.printStackTrace();
        d.g("");
    }

    public static void h(String string) {
        d.c("CloudSystem", string);
    }

    public static void i(String string) {
        d.b("Library", string);
    }

    public static void j(String string) {
        d.b("Backup", string);
    }

    public static void k(String string) {
        d.c("InventoryData", string);
    }

    public static void l(String string) {
        d.b("InventoryData", string);
    }

    public static void m(String string) {
        d.b("WebService", string);
    }

    public static void n(String string) {
        d.c("WebService", string);
    }

    public static void o(String string) {
        d.a("WebService", string);
    }
}

