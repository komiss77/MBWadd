/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.d;
import de.marcely.bedwars.f;
import de.marcely.bedwars.g;
import de.marcely.bedwars.i;
import de.marcely.bedwars.j;
import de.marcely.bedwars.l;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.s;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class h {
    public static final int a = 8;
    private static List<i> c = new ArrayList<i>();
    private static BukkitRunnable a = null;
    private static l a = null;

    public static void onEnable() {
        a = new l(){

            @Override
            public void b(DatagramPacket datagramPacket) {
                MBedwars.a.a(datagramPacket);
            }
        };
        a.inject();
        a.k();
        a = new BukkitRunnable(){

            public void run() {
                s.a.start();
                if (c.size() >= 1) {
                    int n2 = 0;
                    for (i i2 : new ArrayList(c)) {
                        if (n2 > 8) break;
                        if (i2.a().d().length() >= 1) {
                            a.a(i2.a().getInetAddress(), i2.a().getPort(), i2.a().d().getBytes());
                        } else {
                            d.d("Wrong packet format (packetString smaller than 1)");
                        }
                        i2.done();
                        c.remove(i2);
                        ++n2;
                    }
                }
                s.a.a(l.a.d);
            }
        };
        a.runTaskTimer((Plugin)MBedwars.a, 0L, 10L);
    }

    public static void onDisable() {
        a.close();
    }

    public static void b(i i2) {
        c.add(i2);
    }

    public static void close() {
        if (a != null) {
            a.cancel();
        }
        a.close();
    }

}

