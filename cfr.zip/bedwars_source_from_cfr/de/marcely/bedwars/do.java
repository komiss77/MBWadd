/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  cloud.evaped.nickapi.api.APIManager
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import cloud.evaped.nickapi.api.APIManager;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.dp;
import org.bukkit.entity.Player;

public class do
extends dp {
    @Override
    public cT a() {
        return cT.l;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String c(Player player) {
        return APIManager.getNickAPI().isNicked(player) ? player.getName() : null;
    }

    @Override
    public String d(Player player) {
        return APIManager.getNickAPI().isNicked(player) ? APIManager.getNickAPI().getRealName(player) : null;
    }
}

