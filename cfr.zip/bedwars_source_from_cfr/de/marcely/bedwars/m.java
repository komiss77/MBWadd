/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.io.ByteArrayDataOutput
 *  com.google.common.io.ByteStreams
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.f;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class m {
    @Deprecated
    public static void a(Player player, f f2) {
    }

    public static void a(Player player, String string) {
        ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
        byteArrayDataOutput.writeUTF("Connect");
        byteArrayDataOutput.writeUTF(string);
        player.sendPluginMessage((Plugin)MBedwars.a, "BungeeCord", byteArrayDataOutput.toByteArray());
    }
}

