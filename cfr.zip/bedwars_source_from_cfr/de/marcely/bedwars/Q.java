/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.R;
import de.marcely.bedwars.S;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class Q
extends R {
    @Override
    public S a() {
        return S.a;
    }

    @Override
    public void write(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    public void read(BufferedReadStream bufferedReadStream) {
    }
}

