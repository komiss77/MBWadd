/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bI;
import de.marcely.bedwars.bJ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.inventory.PlayerData;
import de.marcely.bedwars.game.inventory.b;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.util.UUID;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;

public class bK {
    @Nullable
    public bI a(Player player) {
        try {
            return bJ.a(this, player.getUniqueId());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public bI b(Player player) {
        bI bI2 = this.a(player);
        if (bI2 == null) {
            bI2 = new bI(this, player.getUniqueId());
            try {
                bI2.v(player);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        return bI2;
    }

    public void b(bI bI2) {
        try {
            bJ.a(bI2);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void z(Player player) {
        if (!ConfigValue.inventory_backup || !player.isOnline()) {
            return;
        }
        bI bI2 = this.a(player);
        if (bI2 == null) {
            File file = b.a(player.getUniqueId());
            if (!file.exists()) {
                return;
            }
            d.l("Found old player inventory file by " + player.getName() + "! Trying to load, convert and delete it...");
            try {
                PlayerData playerData = b.a(player);
                if (playerData.isIngame()) {
                    playerData.u(player);
                }
                file.delete();
            }
            catch (Error error) {
                d.k("An error occured during inventory-conversion task. Deleting the deprecated file as there's no use for it.");
                file.delete();
            }
            catch (Exception exception) {
                d.k("An error occured during inventory-conversion task. Deleting the deprecated file as there's no use for it.");
                file.delete();
            }
            return;
        }
        if (!bI2.isIngame()) {
            return;
        }
        s.b(player, null);
        bI2.x(player);
        bI2.f(false);
        bI2.save();
        c.t(player);
    }

    public void A(Player player) {
        if (!ConfigValue.inventory_backup) {
            return;
        }
        bI bI2 = this.b(player);
        if (bI2.isIngame()) {
            return;
        }
        bI2.v(player);
        bI2.f(true);
        bI2.save();
    }
}

