/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.achievements;

import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.AchievementsAPI;
import de.marcely.bedwars.ef;
import de.marcely.bedwars.util.FutureResult;
import de.marcely.bedwars.util.s;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class UserAchievements
implements AchievementsAPI,
Serializable {
    private static final long serialVersionUID = 3822281586530543702L;
    public UUID uuid;
    private final List<Achievement> gotAchievements;
    private static Map<UUID, UserAchievements> loadedAchievements = new HashMap<UUID, UserAchievements>();

    public UserAchievements(UUID uUID) {
        this(uUID, new ArrayList<Achievement>());
    }

    public UserAchievements(UUID uUID, Achievement ... arrachievement) {
        this(uUID, new ArrayList<Achievement>(Arrays.asList(arrachievement)));
    }

    public UserAchievements(UUID uUID, List<Achievement> list) {
        this.uuid = uUID;
        this.gotAchievements = list;
    }

    @Override
    public boolean has(Achievement achievement) {
        return this.gotAchievements.contains((Object)achievement);
    }

    public boolean a(Achievement achievement) {
        if (this.has(achievement)) {
            return false;
        }
        return this.gotAchievements.add(achievement);
    }

    public boolean b(Achievement achievement) {
        if (!this.has(achievement)) {
            return false;
        }
        return this.gotAchievements.remove((Object)achievement);
    }

    public List<Achievement> a() {
        return this.gotAchievements;
    }

    public static Future<UserAchievements> a(final UUID uUID) {
        final FutureResult<UserAchievements> futureResult = new FutureResult<UserAchievements>();
        if (loadedAchievements.containsKey(uUID)) {
            futureResult.a(loadedAchievements.get(uUID));
        } else {
            final Future<UserAchievements> future = UserAchievements.b(uUID);
            s.a(future, new Runnable(){

                @Override
                public void run() {
                    try {
                        UserAchievements userAchievements = (UserAchievements)future.get();
                        if (userAchievements == null) {
                            userAchievements = new UserAchievements(uUID, new ArrayList<Achievement>());
                        }
                        loadedAchievements.put(uUID, userAchievements);
                        futureResult.a(userAchievements);
                    }
                    catch (InterruptedException | ExecutionException exception) {
                        futureResult.die();
                        exception.printStackTrace();
                    }
                }
            });
        }
        return futureResult;
    }

    private static Future<UserAchievements> b(UUID uUID) {
        return s.b.f(uUID);
    }

    public void save() {
        s.b.b(this);
    }

    public static Future<Boolean> c(UUID uUID) {
        return s.b.e(uUID);
    }

    public static void onEnable() {
    }

    public static void a(UUID uUID) {
        loadedAchievements.remove(uUID);
    }

    public static void e() {
        loadedAchievements.clear();
    }

    @Override
    public UUID getUUID() {
        return this.uuid;
    }

    @Override
    public void set(Achievement achievement, boolean bl2) {
        if (bl2) {
            if (!this.has(achievement)) {
                this.a(achievement);
            }
        } else if (this.has(achievement)) {
            this.b(achievement);
        }
    }

}

