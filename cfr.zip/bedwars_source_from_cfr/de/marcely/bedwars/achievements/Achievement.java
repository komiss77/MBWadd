/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.achievements;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.message.b;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum Achievement {
    b(0, "Default_Leave_Ingame"),
    c(1, "Default_Win_Round"),
    d(2, "Default_LoseRounds"),
    e(3, "Default_Unlucky"),
    f(4, "Default_OPBow"),
    g(5, "Default_Use_RescuePlatform"),
    h(6, "Default_Use_EnderPearl"),
    i(7, "Default_Use_MiniShop"),
    j(8, " Default_Kill_WBow"),
    k(9, "Default_WinInTime"),
    l(10, "Default_Kill_WHalfHeart"),
    m(11, "Default_Win_AmountRounds"),
    n(12, "Default_Use_Bridge"),
    o(13, "Default_Use_GD"),
    p(14, "Default_Use_MagnetShoes"),
    q(15, "Default_Use_Teleporter"),
    r(16, "Default_Use_TNTSheep"),
    s(17, "Default_Use_Tracker"),
    t(18, "Default_Trap_Place"),
    u(19, "Default_Trap_Interact"),
    v(20, "Default_Rank_InTop3"),
    w(21, "Default_Stats_GoodKD"),
    x(22, "Default_Stats_HighPlaytIME"),
    y(23, "Default_WriteGG_End"),
    z(24, "Default_Win_WithoutBed"),
    A(25, "Default_Die_SecsAfterBedDestroyed"),
    B(26, "Default_WinEveryAchievement");
    
    private final int id;
    public final String identifier;
    private static /* synthetic */ int[] a;

    private Achievement(int n3, String string2) {
        this.id = n3;
        this.identifier = string2;
    }

    public String a(@Nullable CommandSender commandSender) {
        switch (Achievement.a()[this.ordinal()]) {
            case 1: {
                return b.a(Language.Achievements_name_rageQuit).f(commandSender);
            }
            case 2: {
                return b.a(Language.Achievements_name_winRound).f(commandSender);
            }
            case 3: {
                return b.a(Language.Achievements_name_loseRound).f(commandSender);
            }
            case 4: {
                return b.a(Language.Achievements_name_ownBedDestroyed).f(commandSender);
            }
            case 5: {
                return b.a(Language.Achievements_name_bestBow).f(commandSender);
            }
            case 6: {
                return b.a(Language.Achievements_name_useRescuePlatform).f(commandSender);
            }
            case 7: {
                return b.a(Language.Achievements_name_useEndepearl).f(commandSender);
            }
            case 8: {
                return b.a(Language.Achievements_name_useMinishop).f(commandSender);
            }
            case 9: {
                return b.a(Language.Achievements_name_killSomeoneWithBow).f(commandSender);
            }
            case 10: {
                return b.a(Language.Achievements_name_winIn3Minutes).f(commandSender);
            }
            case 11: {
                return b.a(Language.Achievements_name_killSomeoneWithHalfAHeart).f(commandSender);
            }
            case 12: {
                return b.a(Language.Achievements_name_win100Rounds).f(commandSender);
            }
            case 13: {
                return b.a(Language.Achievements_name_useBridge).f(commandSender);
            }
            case 14: {
                return b.a(Language.Achievements_name_useGuardDog).f(commandSender);
            }
            case 15: {
                return b.a(Language.Achievements_name_effectMagnetShoes).f(commandSender);
            }
            case 16: {
                return b.a(Language.Achievements_name_useTeleporter).f(commandSender);
            }
            case 17: {
                return b.a(Language.Achievements_name_useTNTSheep).f(commandSender);
            }
            case 18: {
                return b.a(Language.Achievements_name_useTracker).f(commandSender);
            }
            case 19: {
                return b.a(Language.Achievements_name_placeTrap).f(commandSender);
            }
            case 20: {
                return b.a(Language.Achievements_name_runOverTrap).f(commandSender);
            }
            case 21: {
                return b.a(Language.Achievements_name_rankingInTop3).f(commandSender);
            }
            case 22: {
                return b.a(Language.Achievements_name_goodKD).f(commandSender);
            }
            case 23: {
                return b.a(Language.Achievements_name_highPlayTime).f(commandSender);
            }
            case 24: {
                return b.a(Language.Achievements_name_writeGGAtEnd).f(commandSender);
            }
            case 25: {
                return b.a(Language.Achievements_name_winWithoutBed).f(commandSender);
            }
            case 26: {
                return b.a(Language.Achievements_name_die10SecsAfterBedDestruction).f(commandSender);
            }
            case 27: {
                return b.a(Language.Achievements_name_optainEveryAchievement).f(commandSender);
            }
        }
        return null;
    }

    @Deprecated
    public String b(@Nullable CommandSender commandSender) {
        return this.c(commandSender);
    }

    public String c(@Nullable CommandSender commandSender) {
        switch (Achievement.a()[this.ordinal()]) {
            case 1: {
                return b.a(Language.Achievements_text_rageQuit).f(commandSender);
            }
            case 2: {
                return b.a(Language.Achievements_text_winRound).f(commandSender);
            }
            case 3: {
                return b.a(Language.Achievements_text_loseRound).f(commandSender);
            }
            case 4: {
                return b.a(Language.Achievements_text_ownBedDestroyed).f(commandSender);
            }
            case 5: {
                return b.a(Language.Achievements_text_bestBow).f(commandSender);
            }
            case 6: {
                return b.a(Language.Achievements_text_useRescuePlatform).f(commandSender);
            }
            case 7: {
                return b.a(Language.Achievements_text_useEndepearl).f(commandSender);
            }
            case 8: {
                return b.a(Language.Achievements_text_useMinishop).f(commandSender);
            }
            case 9: {
                return b.a(Language.Achievements_text_killSomeoneWithBow).f(commandSender);
            }
            case 10: {
                return b.a(Language.Achievements_text_winIn3Minutes).f(commandSender);
            }
            case 11: {
                return b.a(Language.Achievements_text_killSomeoneWithHalfAHeart).f(commandSender);
            }
            case 12: {
                return b.a(Language.Achievements_text_win100Rounds).f(commandSender);
            }
            case 13: {
                return b.a(Language.Achievements_text_useBridge).f(commandSender);
            }
            case 14: {
                return b.a(Language.Achievements_text_useGuardDog).f(commandSender);
            }
            case 15: {
                return b.a(Language.Achievements_text_effectMagnetShoes).f(commandSender);
            }
            case 16: {
                return b.a(Language.Achievements_text_useTeleporter).f(commandSender);
            }
            case 17: {
                return b.a(Language.Achievements_text_useTNTSheep).f(commandSender);
            }
            case 18: {
                return b.a(Language.Achievements_text_useTracker).f(commandSender);
            }
            case 19: {
                return b.a(Language.Achievements_text_placeTrap).f(commandSender);
            }
            case 20: {
                return b.a(Language.Achievements_text_runOverTrap).f(commandSender);
            }
            case 21: {
                return b.a(Language.Achievements_text_rankingInTop3).f(commandSender);
            }
            case 22: {
                return b.a(Language.Achievements_text_goodKD).f(commandSender);
            }
            case 23: {
                return b.a(Language.Achievements_text_highPlayTime).f(commandSender);
            }
            case 24: {
                return b.a(Language.Achievements_text_writeGGAtEnd).f(commandSender);
            }
            case 25: {
                return b.a(Language.Achievements_text_winWithoutBed).f(commandSender);
            }
            case 26: {
                return b.a(Language.Achievements_text_die10SecsAfterBedDestruction).f(commandSender);
            }
            case 27: {
                return b.a(Language.Achievements_text_optainEveryAchievement).f(commandSender);
            }
        }
        return null;
    }

    public int getID() {
        return this.id;
    }

    @Nullable
    public static Achievement a(int n2) {
        for (Achievement achievement : Achievement.values()) {
            if (achievement.getID() != n2) continue;
            return achievement;
        }
        return null;
    }

    @Nullable
    public static Achievement a(String string) {
        for (Achievement achievement : Achievement.values()) {
            if (!achievement.name().equalsIgnoreCase(string) && !achievement.identifier.equalsIgnoreCase(string)) continue;
            return achievement;
        }
        return null;
    }

    static /* synthetic */ int[] a() {
        if (a != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[Achievement.values().length];
        try {
            arrn[Achievement.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.A.ordinal()] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.p.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.w.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.x.ordinal()] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.l.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.B.ordinal()] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.t.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.v.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.u.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.n.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.o.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.r.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.q.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.s.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.m.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.k.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.z.ordinal()] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Achievement.y.ordinal()] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        a = arrn;
        return a;
    }
}

