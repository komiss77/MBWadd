/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  be.maximvdw.placeholderapi.PlaceholderAPI
 *  be.maximvdw.placeholderapi.PlaceholderReplaceEvent
 *  be.maximvdw.placeholderapi.PlaceholderReplacer
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import be.maximvdw.placeholderapi.PlaceholderAPI;
import be.maximvdw.placeholderapi.PlaceholderReplaceEvent;
import be.maximvdw.placeholderapi.PlaceholderReplacer;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.dD;
import de.marcely.bedwars.du;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ds
extends du {
    @Override
    public cT a() {
        return cT.o;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String a(Player player, String string) {
        return PlaceholderAPI.replacePlaceholders((OfflinePlayer)player, (String)string);
    }

    @Override
    public void a(final dD dD2) {
        PlaceholderAPI.registerPlaceholder((Plugin)MBedwars.a, (String)("mbedwars_" + dD2.getIdentifier()), (PlaceholderReplacer)new PlaceholderReplacer(){

            public String onPlaceholderReplace(PlaceholderReplaceEvent placeholderReplaceEvent) {
                return dD2.e(placeholderReplaceEvent.getPlayer());
            }
        });
    }

    @Override
    public void b(dD dD2) {
    }

    @Override
    public void Z() {
    }

}

