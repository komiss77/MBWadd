/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cm;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.m;
import java.util.Set;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class cj
extends cm {
    public static cj a = new cj();

    @Override
    public String a(m m2) {
        Arena arena = m2.getArena();
        Team team = m2.getTeam();
        Player player = m2.getPlayer();
        if (team == null) {
            return "?";
        }
        return arena.a().a().contains((Object)team) ? b.a(Language.Scoreboard_BedState_Destroyed).f((CommandSender)player) : b.a(Language.Scoreboard_BedState_Alive).f((CommandSender)player);
    }
}

