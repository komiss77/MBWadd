/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cK;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.i;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class cL
extends cK {
    private boolean W = false;

    public cL(g g2, Location location) {
        super(g2, location);
    }

    @Override
    public i a() {
        return i.e;
    }

    @Override
    protected void D(Player player) {
        if (this.W) {
            return;
        }
        this.W = true;
        this.uuid = player.getUniqueId();
        this.W();
        super.D(player);
        this.uuid = null;
        this.W = false;
    }
}

