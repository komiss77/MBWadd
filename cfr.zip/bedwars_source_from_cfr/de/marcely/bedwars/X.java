/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 *  org.spigotmc.event.entity.EntityDismountEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.spigotmc.event.entity.EntityDismountEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class X {
    private Player player;
    private String u;
    private ArmorStand a;
    private BukkitRunnable a = null;
    private static List<X> s = new ArrayList<X>();

    public X(Player player, String string) {
        this.player = player;
        this.u = string;
    }

    public Player getPlayer() {
        return this.player;
    }

    public String getString() {
        return this.u;
    }

    public Entity getEntity() {
        return this.a;
    }

    public void setString(String string) {
        this.u = string;
        if (this.a != null) {
            this.a.setCustomName(string);
        }
    }

    public boolean exists() {
        return this.a != null && !this.a.isDead();
    }

    public void create() {
        if (!this.exists()) {
            s.add(this);
            this.a = (ArmorStand)this.player.getWorld().spawnEntity(this.player.getLocation(), EntityType.ARMOR_STAND);
            this.a.setVisible(false);
            this.a.setGravity(false);
            this.a.setSmall(true);
            this.a.setCustomName(this.u);
            this.a.setCustomNameVisible(true);
            this.a = new BukkitRunnable(){

                public void run() {
                    X.this.a.teleport(X.this.player.getLocation().clone().add(0.0, 4.5, 0.0));
                }
            };
            this.a.runTaskTimer((Plugin)MBedwars.a, 0L, 1L);
        }
    }

    public void remove() {
        if (this.exists()) {
            this.a.cancel();
            this.a.remove();
            s.remove(this);
        }
    }

    public static void a(EntityDismountEvent entityDismountEvent) {
        for (X x2 : s) {
            if (x2.getEntity() == null || !x2.getEntity().equals((Object)entityDismountEvent.getDismounted())) continue;
            x2.getPlayer().setPassenger(x2.getEntity());
        }
    }

}

