/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.ProtocolLibrary
 *  com.comphenix.protocol.ProtocolManager
 */
package de.marcely.bedwars;

import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import de.marcely.bedwars.cR;
import de.marcely.bedwars.cT;

public class cV
extends cR {
    public ProtocolManager a;

    @Override
    public cT a() {
        return cT.u;
    }

    @Override
    public void onEnable() {
        this.a = ProtocolLibrary.getProtocolManager();
    }

    @Override
    public void onDisable() {
    }
}

