/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cy
extends ct {
    public static cy a = new cy();

    public String b(c c2) {
        return "" + c2.getWins();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

