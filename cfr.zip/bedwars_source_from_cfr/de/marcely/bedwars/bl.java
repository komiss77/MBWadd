/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import java.io.IOException;

public class bl
extends IOException {
    private static final long serialVersionUID = 3580004729936969847L;

    public bl(String string) {
        super(string);
    }

    public bl(String string, Throwable throwable) {
        super(string, throwable);
    }

    public bl(Throwable throwable) {
        super(throwable);
    }
}

