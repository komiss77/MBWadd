/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.util.FutureResult;

public class bn
extends Exception {
    private static final long serialVersionUID = 1L;

    public bn(FutureResult<?> futureResult, String string) {
        super(string);
    }
}

