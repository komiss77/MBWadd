/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Ocelot
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Villager
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bB
extends by
implements Listener {
    private Player player;
    private BukkitTask d;
    private Villager a;
    private Ocelot a;
    private ArmorStand b;
    private int U = 0;
    private int V = 20;
    private a a = new a();

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = this.player = playerUseExtraItemEvent.getPlayer();
        Block block = playerUseExtraItemEvent.getClickedBlock();
        BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (block == null) {
            this.done();
            return;
        }
        s.a(player, Achievement.i);
        Sound.EXTRAITEM_MINISHOP_USE.play(player);
        this.L();
        Location location = block.getLocation();
        Location location2 = new Location(location.getWorld(), location.getX() + (double)blockFace.getModX(), location.getY() + (double)blockFace.getModY(), location.getZ() + (double)blockFace.getModZ());
        this.L();
        this.a(location2);
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }

    @Override
    public void K() {
        HandlerList.unregisterAll((Listener)this);
        if (this.a == null) {
            return;
        }
        this.c(this.a.getLocation());
        Sound.ENTITY_VILLAGER_DEATH.play(this.a.getLocation());
        this.a.remove();
        this.a.remove();
        this.b.remove();
        this.d.cancel();
    }

    private void a(Location location) {
        Villager villager = this.a = (Villager)location.getWorld().spawnEntity(location, EntityType.VILLAGER);
        villager.setMetadata("mbw_isMinishop", (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)true));
        villager.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 4));
        this.a = (Ocelot)location.getWorld().spawnEntity(location, EntityType.OCELOT);
        villager = this.a;
        Version.a().a((Entity)villager, ConfigValue.minishop_speed);
        villager.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
        villager.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 1));
        Version.a().c((Entity)villager, true);
        this.b = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
        villager = this.b;
        villager.setVisible(false);
        villager.setGravity(false);
        villager.setCustomNameVisible(true);
        this.d = new BukkitRunnable(){

            public void run() {
                bB.this.tick();
                bB bB2 = bB.this;
                bB.a(bB2, bB2.U + 1);
            }
        }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
    }

    private void tick() {
        if (this.a.isDead() || this.a.isDead()) {
            this.done();
            return;
        }
        this.a.teleport((Entity)this.a);
        this.b.teleport((Entity)this.a);
        if (this.player != null) {
            Version.a().a((Entity)this.a, (Entity)this.player);
        }
        if (this.U % 20 == 0) {
            --this.V;
            if (this.V >= 0) {
                this.b.setCustomName(b.a(Language.MiniShop_Title).a("title", ConfigValue.dealer_title).a("time", "" + this.V).f((CommandSender)this.player));
            } else {
                this.done();
            }
        }
        this.a.d(this.a.getLocation());
    }

    @EventHandler
    public void a(PlayerInteractEntityEvent playerInteractEntityEvent) {
        Entity entity = playerInteractEntityEvent.getRightClicked();
        if (entity == this.b) {
            playerInteractEntityEvent.setCancelled(true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(EntityDamageEvent entityDamageEvent) {
        final Entity entity = entityDamageEvent.getEntity();
        if (entity == this.a) {
            entityDamageEvent.setCancelled(false);
            Version.a().a((Entity)this.a, (float)entityDamageEvent.getFinalDamage());
        } else if (entity == this.a) {
            entityDamageEvent.setCancelled(false);
            new BukkitRunnable(){

                public void run() {
                    bB.this.a.setVelocity(entity.getVelocity());
                }
            }.runTaskLater((Plugin)MBedwars.a, 1L);
        }
    }

    private void c(Location location) {
        for (int i2 = 0; i2 < 6; ++i2) {
            VarParticle.PARTICLE_SMOKE.play(location.getWorld(), location.clone().add((double)s.RAND.nextInt(6) / 10.0, (double)s.RAND.nextInt(8) / 10.0 * (double)(s.RAND.nextInt(2) + 1), (double)s.RAND.nextInt(6) / 10.0), s.RAND.nextInt(10));
        }
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 1.4, 0.4), 0);
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 0.6, 0.4), 0);
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 0.1, 0.4), 0);
    }

    static /* synthetic */ void a(bB bB2, int n2) {
        bB2.U = n2;
    }

    private static class a {
        float x1 = 1.0f;
        float y1 = 1.0f;
        float a = 1.0f;
        float x2 = 0.0f;
        float y2 = 0.0f;
        float b = 0.0f;

        private a() {
        }

        public void d(Location location) {
            this.x1 = (float)((double)this.x1 - 0.025);
            if (this.x1 <= -1.0f) {
                this.x1 = 1.0f;
            }
            this.y1 = (float)((double)this.y1 - 0.035);
            if (this.y1 <= -1.0f) {
                this.y1 = 1.0f;
            }
            this.a = (float)((double)this.a - 0.0125);
            if (this.a <= -1.0f) {
                this.a = 1.0f;
            }
            this.a(location.clone().add(Math.cos(-this.x1) * 2.0 - 1.5, Math.cos(this.y1) * 4.0 - 2.0, Math.cos(-this.a) * 2.0 - 1.5), Math.abs(this.x1 + this.y1 + this.a) / 3.0f);
            this.x2 = (float)((double)this.x2 + 0.025);
            if (this.x2 >= 1.0f) {
                this.x2 = -1.0f;
            }
            this.y2 = (float)((double)this.y2 + 0.035);
            if (this.y2 >= 1.0f) {
                this.y2 = -1.0f;
            }
            this.b = (float)((double)this.b + 0.0125);
            if (this.b >= 1.0f) {
                this.b = -1.0f;
            }
            this.a(location.clone().add(Math.cos(-this.x2) * 2.0 - 1.5, Math.cos(this.y2) * 4.0 - 2.0, Math.cos(-this.b) * 2.0 - 1.5), Math.abs(this.x2 + this.y2 + this.b) / 3.0f);
        }

        private void a(Location location, float f2) {
            VarParticle.PARTICLE_COLOURED.play(location.getWorld(), location, Color.fromRGB((int)((int)(f2 * 255.0f)), (int)((int)(f2 * 255.0f)), (int)((int)(f2 * 255.0f))));
        }
    }

}

