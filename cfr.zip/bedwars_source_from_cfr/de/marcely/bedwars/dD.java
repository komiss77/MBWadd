/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import org.bukkit.entity.Player;

public abstract class dD {
    private final String identifier;

    public dD(String string) {
        this.identifier = string;
    }

    public abstract String e(Player var1);

    public String getIdentifier() {
        return this.identifier;
    }
}

