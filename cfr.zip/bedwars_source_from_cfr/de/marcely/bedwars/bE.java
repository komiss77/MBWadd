/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Sheep
 *  org.bukkit.entity.TNTPrimed
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class bE
extends by {
    private Arena arena;
    private Team team;
    private Sheep a;
    private BukkitTask d;

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = playerUseExtraItemEvent.getPlayer();
        Block block = playerUseExtraItemEvent.getClickedBlock();
        BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (block == null) {
            this.done();
            return;
        }
        this.arena = (Arena)playerUseExtraItemEvent.getArena();
        this.team = this.arena.a(player);
        s.a(player, Achievement.r);
        this.L();
        Location location = block.getLocation();
        Location location2 = new Location(location.getWorld(), location.getX() + (double)blockFace.getModX(), location.getY() + (double)blockFace.getModY(), location.getZ() + (double)blockFace.getModZ());
        this.a(location2);
    }

    @Override
    public void K() {
        if (this.a == null) {
            return;
        }
        this.a.remove();
        this.d.cancel();
    }

    private void a(Location location) {
        Sheep sheep = this.a = (Sheep)location.getWorld().spawnEntity(location, EntityType.SHEEP);
        sheep.setMaxHealth(5.0);
        sheep.setHealth(5.0);
        sheep.setColor(this.team.getDyeColor());
        Version.a().a((Entity)sheep, ConfigValue.tntsheep_speed);
        Version.a().a((Entity)sheep, 50);
        sheep = (TNTPrimed)location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        sheep.setFuseTicks(100);
        sheep.setYield(5.0f);
        this.a.setPassenger((Entity)sheep);
        Sound.EXTRAITEM_TNTSHEEP_FUSE.play(location);
        this.d = new BukkitRunnable(){

            public void run() {
                bE.this.tick();
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 10L);
    }

    private void tick() {
        if (this.a.isDead()) {
            this.done();
            return;
        }
        Player player = s.a(this.arena, this.a.getLocation(), this.team);
        if (player != null) {
            Version.a().a((Entity)this.a, (Entity)player);
        }
    }

}

