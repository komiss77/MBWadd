/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ap;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

@Deprecated
public class aq
implements Cloneable {
    private String name;
    private String v;
    private ItemStack icon = new ItemStack(Material.STONE);
    private List<ItemStack> prices = new ArrayList<ItemStack>();
    private List<ap> products = new ArrayList<ap>();

    public aq(String string) {
        this.setName(string);
        this.s(string);
    }

    public aq(String string, Material material) {
        this.name = string;
        this.v = string;
        this.icon = new ItemStack(material);
    }

    public void setName(String string) {
        this.name = string;
    }

    public void s(String string) {
        this.v = string;
    }

    public void setIcon(ItemStack itemStack) {
        this.icon = itemStack;
    }

    public void a(Material material) {
        this.setIcon(new ItemStack(material));
    }

    public void a(Material material, int n2) {
        this.setIcon(new ItemStack(material, 1, (short)n2));
    }

    public List<ap> j() {
        return null;
    }

    public aq b() {
        try {
            return (aq)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public String getName() {
        return this.name;
    }

    public String getRealName() {
        return this.v;
    }

    public ItemStack getIcon() {
        return this.icon;
    }

    public List<ItemStack> getPrices() {
        return this.prices;
    }

    public List<ap> getProducts() {
        return this.products;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return this.b();
    }
}

