/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dI;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class dE
extends dI {
    public dE() {
        super("current-team-color");
    }

    @Override
    protected String a(Player player, Arena arena) {
        Team team = arena.a(player);
        return team != null ? "" + (Object)team.getChatColor() : "";
    }
}

