/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cR;

public abstract class cZ
extends cR {
}

