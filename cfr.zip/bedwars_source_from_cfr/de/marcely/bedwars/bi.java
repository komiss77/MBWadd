/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.weather.WeatherChangeEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.weather.WeatherChangeEvent;

public class bi {
    public static void a(WeatherChangeEvent weatherChangeEvent) {
        if (weatherChangeEvent.toWeatherState() && ConfigValue.no_rain) {
            for (Player player : s.a(weatherChangeEvent.getWorld(), true)) {
                Version.a().d(player, false);
            }
        }
    }
}

