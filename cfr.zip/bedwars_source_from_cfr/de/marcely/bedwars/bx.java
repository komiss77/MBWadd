/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.bA;
import de.marcely.bedwars.bB;
import de.marcely.bedwars.bD;
import de.marcely.bedwars.bE;
import de.marcely.bedwars.bF;
import de.marcely.bedwars.bG;
import de.marcely.bedwars.bH;
import de.marcely.bedwars.bv;
import de.marcely.bedwars.by;
import de.marcely.bedwars.bz;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import javax.annotation.Nullable;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public enum bx {
    b,
    c,
    d,
    e,
    f,
    g,
    h,
    i,
    j;
    
    private final bv a = new bv(this, null);
    private static /* synthetic */ int[] n;

    public ItemStack getItemStack() {
        switch (bx.o()[this.ordinal()]) {
            case 1: {
                return ConfigValue.teleporter_item.clone();
            }
            case 2: {
                return ConfigValue.minishop_item.clone();
            }
            case 3: {
                return ConfigValue.rescueplatform_item.clone();
            }
            case 4: {
                return ConfigValue.tntsheep_item.clone();
            }
            case 5: {
                return ConfigValue.magneticshoes_item.clone();
            }
            case 6: {
                return ConfigValue.trap_item.clone();
            }
            case 7: {
                return ConfigValue.bridge_item.clone();
            }
            case 8: {
                return ConfigValue.guarddog_item.clone();
            }
            case 9: {
                return new ItemStack(Material.COMPASS);
            }
        }
        return null;
    }

    @Nullable
    public by a() {
        switch (bx.o()[this.ordinal()]) {
            case 1: {
                return new bF();
            }
            case 2: {
                return new bB();
            }
            case 3: {
                return new bD();
            }
            case 4: {
                return new bE();
            }
            case 6: {
                return new bH();
            }
            case 7: {
                return new bz();
            }
            case 8: {
                return new bA();
            }
            case 9: {
                return new bG();
            }
        }
        return null;
    }

    public String e(@Nullable CommandSender commandSender) {
        Language language = Language.getLanguage("Shop_Item_" + this.name().replace("_", ""));
        if (language == null) {
            throw new IllegalStateException("Message entry of item " + this.name().replace("_", "") + " doesn't exist");
        }
        return b.a(language).f(commandSender);
    }

    public ExtraItem getExtraItem() {
        this.a.setItemStack(this.getItemStack());
        return this.a;
    }

    public static bx a(ItemStack itemStack) {
        for (bx bx2 : bx.values()) {
            if (!i.a(bx2.getItemStack(), itemStack)) continue;
            return bx2;
        }
        return null;
    }

    static /* synthetic */ int[] o() {
        if (n != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[bx.values().length];
        try {
            arrn[bx.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[bx.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        n = arrn;
        return n;
    }
}

