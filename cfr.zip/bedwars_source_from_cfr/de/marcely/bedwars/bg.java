/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Chunk
 *  org.bukkit.Location
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.event.world.ChunkLoadEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.List;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.world.ChunkLoadEvent;

public class bg {
    public static void a(ChunkLoadEvent chunkLoadEvent) {
        Chunk chunk = chunkLoadEvent.getChunk();
        String string = String.valueOf(chunk.getX()) + "." + chunk.getZ();
        for (Arena arena : s.af) {
            if (arena.b() != ArenaStatus.f || arena.L.contains(string)) continue;
            for (Entity entity : chunk.getEntities()) {
                if (entity.getType() != EntityType.DROPPED_ITEM || !arena.isInside(entity.getLocation())) continue;
                entity.remove();
            }
            arena.L.add(string);
        }
    }
}

