/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ch;
import de.marcely.bedwars.game.stats.c;

public class cd
extends ch {
    public static cd a = new cd();

    @Override
    protected String a(c c2) {
        return "" + c2.getBedsDestroyed();
    }
}

