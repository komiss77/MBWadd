/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class et
extends ex {
    public static final byte REPLY_SUCCESS = -1;
    public static final byte C = 0;
    public static final byte D = 1;
    public static final byte E = 2;
    public static final byte F = 3;
    public byte reply;

    @Override
    public ey a() {
        return ey.b;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.reply = bufferedReadStream.readByte();
    }
}

