/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.io.netty.channel.Channel
 *  net.minecraft.util.io.netty.channel.ChannelDuplexHandler
 *  net.minecraft.util.io.netty.channel.ChannelHandler
 *  net.minecraft.util.io.netty.channel.ChannelHandler$Sharable
 *  net.minecraft.util.io.netty.channel.ChannelHandlerContext
 *  net.minecraft.util.io.netty.channel.ChannelPipeline
 *  net.minecraft.util.io.netty.channel.ChannelPromise
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cA;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.dZ;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.NoSuchElementException;
import net.minecraft.util.io.netty.channel.Channel;
import net.minecraft.util.io.netty.channel.ChannelDuplexHandler;
import net.minecraft.util.io.netty.channel.ChannelHandler;
import net.minecraft.util.io.netty.channel.ChannelHandlerContext;
import net.minecraft.util.io.netty.channel.ChannelPipeline;
import net.minecraft.util.io.netty.channel.ChannelPromise;
import org.bukkit.entity.Player;

@ChannelHandler.Sharable
public class dW
extends ChannelDuplexHandler
implements dZ {
    private final dY a;
    private Channel channel = null;
    private boolean ae = false;

    public dW(dY dY2) {
        this.a = dY2;
    }

    @Override
    public dY a() {
        return this.a;
    }

    @Override
    public boolean isInjected() {
        return this.channel != null && this.channel.isActive() && this.channel.pipeline().names().contains("MBedwars_NI");
    }

    @Override
    public boolean inject() {
        if (this.isInjected()) {
            return false;
        }
        try {
            Object obj = NMSClass.m.cast((Object)this.a.getPlayer());
            Object object = obj.getClass().getMethod("getHandle", new Class[0]).invoke(obj, new Object[0]);
            Object object2 = object.getClass().getDeclaredField("playerConnection").get(object);
            Object object3 = object2.getClass().getDeclaredField("networkManager").get(object2);
            Field field = object3.getClass().getDeclaredField(Version.a().t() >= 2 ? "m" : "k");
            field.setAccessible(true);
            this.channel = (Channel)field.get(object3);
            try {
                this.channel.pipeline().addBefore("packet_handler", "MBedwars_NI", (ChannelHandler)this);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                this.channel.pipeline().remove("MBedwars_NI");
                this.channel.pipeline().addBefore("packet_handler", "MBedwars_NI", (ChannelHandler)this);
            }
        }
        catch (IllegalAccessException | NoSuchFieldException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
        }
        catch (NoSuchElementException noSuchElementException) {
            return false;
        }
        return true;
    }

    @Override
    public boolean Y() {
        if (!this.isInjected()) {
            return false;
        }
        try {
            this.channel.pipeline().remove("MBedwars_NI");
        }
        catch (NoSuchElementException noSuchElementException) {
            // empty catch block
        }
        this.channel = null;
        return true;
    }

    public void channelRead(ChannelHandlerContext channelHandlerContext, Object object) throws Exception {
        try {
            Method method;
            String[] arrstring;
            if (NMSClass.H.isInstance(object)) {
                Field field = NMSClass.H.getDeclaredField("a");
                field.setAccessible(true);
                int n2 = field.getInt(object);
                field = NMSClass.H.getDeclaredField("action");
                field.setAccessible(true);
                Object object2 = field.get(object);
                String string = (String)object2.getClass().getMethod("name", new Class[0]).invoke(object2, new Object[0]);
                if (string.equals("INTERACT")) {
                    this.a.d(n2);
                } else if (string.equals("ATTACK")) {
                    this.a.e(n2);
                }
            } else if (NMSClass.Q.isInstance(object) && (arrstring = this.a.c((String)(method = NMSClass.Q.getDeclaredMethod("c", new Class[0])).invoke(object, new Object[0]))) != null) {
                Object obj = NMSClass.P.getDeclaredConstructor(String[].class).newInstance(new Object[]{arrstring});
                Version.a().sendPacket(this.a.getPlayer(), obj);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        super.channelRead(channelHandlerContext, object);
    }

    public void write(ChannelHandlerContext channelHandlerContext, Object object, ChannelPromise channelPromise) throws Exception {
        boolean bl2 = false;
        try {
            if (NMSClass.R.isInstance(object)) {
                Field field = NMSClass.R.getDeclaredField("a");
                field.setAccessible(true);
                long l2 = (Long)field.get(object);
                field = NMSClass.R.getDeclaredField("b");
                field.setAccessible(true);
                long l3 = (Long)field.get(object);
                bl2 = this.a.a(l2, l3);
            } else if (NMSClass.ab.isInstance(object)) {
                int n2 = s.a(NMSClass.ab, "a").getInt(object);
                if (cA.a(n2)) {
                    s.a(NMSClass.ab, "c").set(object, (byte)0);
                }
            } else if (NMSClass.K.isInstance(object)) {
                int n3 = s.a(NMSClass.K, "a").getInt(object);
                if (cA.a(n3)) {
                    s.a(NMSClass.K, "c").setInt(object, (int)Math.floor(-640.0));
                }
            } else if (NMSClass.U.isInstance(object)) {
                float f2 = ((Float)s.a(NMSClass.U, "a").get(object)).floatValue();
                int n4 = (Integer)s.a(NMSClass.U, "b").get(object);
                float f3 = ((Float)s.a(NMSClass.U, "c").get(object)).floatValue();
                bl2 = this.a.a(f2, n4, f3);
            } else if (NMSClass.L.isInstance(object)) {
                int n5 = (Integer)s.a(NMSClass.L, "a").get(object);
                if (n5 == this.a.getPlayer().getEntityId()) {
                    List list = (List)s.a(NMSClass.L, "b").get(object);
                    for (Object e2 : list) {
                        int n6 = (Integer)s.a(e2.getClass(), "b").get(e2);
                        Object object2 = s.a(e2.getClass(), "c").get(e2);
                        if (n6 != 6) continue;
                        bl2 = this.a.b(((Float)object2).floatValue());
                    }
                }
            } else if (NMSClass.E.isInstance(object)) {
                int n7 = (Integer)s.a(NMSClass.E, "a").get(object);
                Object object3 = s.a(NMSClass.E, "b").get(object);
                Object object4 = s.a(NMSClass.E, "c").get(object);
                bl2 = this.a.a(n7, object3, object4);
            } else if (NMSClass.Y.isInstance(object)) {
                int n8 = (Integer)s.a(NMSClass.Y, "a").get(object);
                int n9 = (Integer)s.a(NMSClass.Y, "b").get(object);
                this.a.a(n8, n9, this.ae);
            } else if (NMSClass.Z != null) {
                int[] arrn = (int[])s.a(NMSClass.Z, "a").get(object);
                int[] arrn2 = (int[])s.a(NMSClass.Z, "b").get(object);
                for (int i2 = 0; i2 < arrn.length; ++i2) {
                    this.a.a(arrn[i2], arrn2[i2], this.ae);
                }
            } else if (NMSClass.ad.isInstance(object)) {
                bl2 = this.a.Z();
                if (!bl2) {
                    this.ae = true;
                }
            } else if (NMSClass.ae.isInstance(object) && this.ae) {
                this.ae = false;
                this.a.ad();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (!bl2) {
            super.write(channelHandlerContext, object, channelPromise);
        }
    }
}

