/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cR;
import de.marcely.bedwars.dD;
import org.bukkit.entity.Player;

public abstract class du
extends cR {
    public abstract String a(Player var1, String var2);

    public abstract void a(dD var1);

    public abstract void b(dD var1);

    public abstract void Z();
}

