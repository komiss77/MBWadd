/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class J
extends NormalPacket {
    public String name;
    public String j;

    @Override
    public byte getPacketID() {
        return 35;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
        bufferedWriteStream.writeString(this.j);
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
        this.j = bufferedReadStream.readString();
    }
}

