/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.event.entity.EntityDeathEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.EntityDeathEvent;

public class aF {
    public static void a(EntityDeathEvent entityDeathEvent) {
        Arena arena;
        if (Version.a().getVersionNumber() >= 8 && entityDeathEvent.getEntityType() == EntityType.VILLAGER && entityDeathEvent.getEntity().getVehicle() != null && entityDeathEvent.getEntity().getVehicle().getType() == EntityType.ARMOR_STAND) {
            arena = (ArmorStand)entityDeathEvent.getEntity().getVehicle();
            if (!arena.isVisible()) {
                arena.remove();
                return;
            }
            String string = entityDeathEvent.getEntity().getCustomName();
            if (string.equals(ConfigValue.dealer_title) || string.startsWith(ConfigValue.lobbyvillager_prefix) || Team.a(null, string) != null) {
                entityDeathEvent.getEntity().getVehicle().remove();
            }
        }
        if (entityDeathEvent.getEntity().getType() == EntityType.PLAYER) {
            return;
        }
        arena = s.a(entityDeathEvent.getEntity().getLocation());
        if (arena != null && arena.b() == ArenaStatus.f) {
            entityDeathEvent.getDrops().clear();
            entityDeathEvent.setDroppedExp(0);
        }
    }
}

