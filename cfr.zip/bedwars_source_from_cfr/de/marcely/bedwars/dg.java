/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cR;
import de.marcely.bedwars.df;
import org.bukkit.entity.Player;

public abstract class dg
extends cR {
    public abstract void a(Player var1, df var2);
}

