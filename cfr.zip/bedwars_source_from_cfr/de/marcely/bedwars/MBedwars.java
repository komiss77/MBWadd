/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 *  org.apache.commons.io.FileUtils
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.plugin.messaging.Messenger
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import com.google.common.io.Files;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.ak;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.api.BedwarsAddon;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.as;
import de.marcely.bedwars.at;
import de.marcely.bedwars.au;
import de.marcely.bedwars.bC;
import de.marcely.bedwars.bK;
import de.marcely.bedwars.bu;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cB;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.command.arena.CommandHandler;
import de.marcely.bedwars.command.arena.f;
import de.marcely.bedwars.command.d;
import de.marcely.bedwars.config.Config;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.h;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.dv;
import de.marcely.bedwars.e;
import de.marcely.bedwars.eb;
import de.marcely.bedwars.ef;
import de.marcely.bedwars.ei;
import de.marcely.bedwars.f;
import de.marcely.bedwars.g;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.game.arena.b;
import de.marcely.bedwars.game.arena.picker.condition.e;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.holographic.j;
import de.marcely.bedwars.message.a;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.io.FileUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.Messenger;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class MBedwars
extends JavaPlugin
implements CommandExecutor {
    public static MBedwars a = null;
    public Map<String, Arena> a = new HashMap();
    public static f a = null;
    public static g a = null;
    public static Map<Plugin, BedwarsAddon> b = new HashMap<Plugin, BedwarsAddon>();
    public static CommandHandler a;
    public static dv a;
    public static de.marcely.bedwars.a a;
    @Deprecated
    public static PluginState a;
    public static final de.marcely.bedwars.e a;

    static {
        a = new dv();
        a = new de.marcely.bedwars.a();
        a = new de.marcely.bedwars.e();
    }

    public void onEnable() {
        a = PluginState.b;
        a = this;
        MBedwars.a();
        MBedwars.d();
        if (Version.init()) {
            String string3 = Version.a().c("spawn-npcs");
            String string = Version.a().c("spawn-protection");
            if (Version.a().getVersionNumber() >= 13 && !Version.a().af()) {
                de.marcely.bedwars.d.a("Server has been started without the '--forceUpgrade' parameter.\nThis may cause some crashes when upgrading from an older version");
            }
            if (string3 != null && string3.equals("false")) {
                de.marcely.bedwars.d.a("'spawn-npcs' is disabled in the server.properties!\nChange that to true to prevent issues.");
            }
            if (string == null || !s.isInteger(string) || Integer.valueOf(string) >= 1) {
                de.marcely.bedwars.d.a("'spawn-protection' hasn't been set to 0 in the server.properties!\nChange that to prevent possible issues with players who won't be able to place/break blocks at a specific region in your arena.");
            }
            if (a == PluginState.f) {
                return;
            }
            if (!MBedwars.a().isTaskable()) {
                return;
            }
            new BukkitRunnable(){
                boolean a = true;

                public void run() {
                    a.a(this.a ? e.a.c : e.a.f);
                    this.a = false;
                }
            }.runTaskTimer((Plugin)this, 1L, 72000L);
            s.e = Version.a().getVersionNumber() >= 8 ? Material.BARRIER : Material.CLAY_BALL;
            s.k = new Location(s.a(), 0.0, 0.0, 0.0);
            s.a = Thread.currentThread();
            s.a = new a();
            s.a = new l(true);
            a = new CommandHandler();
            cB.init();
            s.b.run();
            s.b = new cS();
            s.b.loadLibraries();
            for (Player player : Version.a().getOnlinePlayers()) {
                dY dY2 = new dY(player);
                dY2.inject();
                s.Z.put(player, dY2);
                dY2.a(new de.marcely.bedwars.c());
                s.b.z(player);
                Arena arena = s.a(player.getLocation());
                if (arena == null) continue;
                s.b(player, arena);
            }
            new BukkitRunnable(){

                public void run() {
                    final long l2 = System.currentTimeMillis();
                    s.c(new Runnable(){

                        @Override
                        public void run() {
                            de.marcely.bedwars.d.c("Updated stats after " + (double)(System.currentTimeMillis() - l2) / 1000.0 + " seconds");
                        }
                    });
                }

            }.runTaskTimer((Plugin)a, (long)(ConfigValue.restart_oncearenaend ? 100 : 18000), 60000L);
            s.A("de.marcely.bedwars.game.arena.KickReason");
            s.A("de.marcely.bedwars.versions.NMSClass");
            if (Version.a().getVersionNumber() >= 8) {
                ConfigValue.rescueplatform_item = new ItemStack(Material.SLIME_BLOCK);
                ConfigValue.rescueplatform_material = Material.SLIME_BLOCK;
            } else {
                ConfigValue.rescueplatform_item = new ItemStack(Material.STAINED_GLASS);
                ConfigValue.rescueplatform_material = Material.STAINED_GLASS;
            }
            this.getServer().getPluginManager().registerEvents((Listener)new as(), (Plugin)this);
            this.getServer().getPluginManager().registerEvents((Listener)new au(), (Plugin)this);
            if (Version.a().getVersionNumber() >= 10) {
                this.getServer().getPluginManager().registerEvents((Listener)new at(), (Plugin)this);
            }
            BedwarsAPI.registerMBedwarsCommand("bw");
            BedwarsAPI.registerMBedwarsCommand("bedwars");
            BedwarsAPI.registerMBedwarsCommand("mbedwars");
            DefaultUpgradeType.init();
            bu.init();
            e.init();
            h.onEnable();
            Config.a(true, null);
            c.onEnable();
            UserAchievements.onEnable();
            ak.onEnable();
            if (!MBedwars.a().isTaskable()) {
                return;
            }
            new BukkitRunnable(){

                public void run() {
                    s.a.start();
                    for (int i2 = s.ag.size() - 1; i2 >= 0; --i2) {
                        s.ag.get(i2).a().D();
                    }
                    s.a.a(l.a.c);
                }
            }.runTaskTimer((Plugin)this, 1L, 1L);
            new BukkitRunnable(){

                public void run() {
                    s.af();
                    s.ag();
                }
            }.runTaskLater((Plugin)this, 1L);
            if (ConfigValue.autojoin_way == Config.AutoJoin_SendBackWay.b || ConfigValue.bungeecord_enabled) {
                this.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
            }
            if (ConfigValue.bungeecord_enabled) {
                a = new f(ConfigValue.bungeecord_hub_address);
                a = new g((Plugin)this, a);
                de.marcely.bedwars.h.onEnable();
            }
            a = PluginState.c;
        } else {
            a = PluginState.d;
        }
    }

    public void onDisable() {
        a = PluginState.e;
        try {
            a.a(ei.a.f);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        s.b.stop();
        for (Player player : cA.E.keySet()) {
            cA.a(player, cD.c);
        }
        for (Arena arena : s.af) {
            arena.a(KickReason.c);
            arena.B();
            if (!arena.B()) continue;
            arena.a.cancel();
        }
        if (s.af.size() >= 1) {
            de.marcely.bedwars.config.b.saveAll();
        }
        for (RankingStatue rankingStatue : new ArrayList<RankingStatue>(s.ad)) {
            if (rankingStatue == null) continue;
            rankingStatue.remove(false);
        }
        bC.removeAll();
        if (s.b != null) {
            s.b.shutdown();
        }
        de.marcely.bedwars.game.stats.d.P();
        s.i(false);
        for (Player player : GUI.openInventories.keySet()) {
            player.closeInventory();
        }
        if (s.Z != null) {
            for (Player player : s.Z.keySet()) {
                dY dY2 = s.Z.get((Object)player);
                dY2.Y();
            }
            s.Z.clear();
        }
        for (Thread thread : MThread.getRunningThreads()) {
            if (!(thread instanceof MThread)) continue;
            thread.stop();
        }
        if (ConfigValue.bungeecord_enabled) {
            de.marcely.bedwars.h.onDisable();
        }
        UserAchievements.e();
        c.e();
        a = PluginState.f;
    }

    public boolean c() {
        return true;
    }

    public static void a() {
        for (File file : s.a()) {
            if (file.exists()) continue;
            file.mkdir();
        }
    }

    public static String getVersion() {
        return "4.0.13";
    }

    public static void h(String string, String string2) {
        for (File file : new File(string).listFiles()) {
            if (file.isHidden() || file.isDirectory()) continue;
            try {
                Files.copy((File)file, (File)new File(String.valueOf(string2) + file.getName()));
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    public static void p(String string) {
        File file = new File(string);
        if (file.isDirectory()) {
            boolean bl2 = true;
            for (File file2 : file.listFiles()) {
                if (file2.isFile()) {
                    file2.delete();
                    continue;
                }
                bl2 = false;
            }
            if (bl2) {
                file.delete();
            }
        }
    }

    public static void a(String string, String string2, boolean bl2) {
        try {
            if (!bl2 && new File(string2).exists()) {
                return;
            }
            URL uRL = JavaPlugin.class.getClassLoader().getResource(string);
            FileOutputStream fileOutputStream = new FileOutputStream(string2);
            InputStream inputStream = uRL.openStream();
            byte[] arrby = new byte[4096];
            int n2 = inputStream.read(arrby);
            while (n2 != -1) {
                fileOutputStream.write(arrby, 0, n2);
                n2 = inputStream.read(arrby);
            }
            fileOutputStream.close();
            inputStream.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static boolean d() {
        return a != null && a.h();
    }

    public static void moveFile(File file, File file2) {
        try {
            FileUtils.moveFile((File)file, (File)file2);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    private static void d() {
        MBedwars.i("config.yml", s.a(s.s));
        MBedwars.i("achievements-config.yml", s.a(s.u));
        MBedwars.i("hologram-lines.yml", s.a(s.t));
        MBedwars.i("itemspawners.yml", s.a(s.v));
        MBedwars.i("lobby-config.yml", s.a(s.w));
        MBedwars.i("ranking-lines.yml", s.a(s.x));
        MBedwars.i("scoreboard-ingame.yml", s.a(s.y));
        MBedwars.i("scoreboard-lobby.yml", s.a(s.z));
        MBedwars.i("shop-config.yml", s.a(s.A));
        MBedwars.i("sounds-config.yml", s.a(s.C));
        MBedwars.i("upgrade-shop-config.yml", s.a(s.B));
    }

    private static void i(String string, String string2) {
        File file = new File(s.f, string);
        File file2 = new File(s.f, string2);
        if (!file2.exists() && file.exists()) {
            de.marcely.bedwars.d.c("Moving '" + s.a(file) + "' to '" + s.a(file2) + "'");
            MBedwars.moveFile(file, file2);
        }
    }

    public static PluginState a() {
        return a;
    }

    public ClassLoader a() {
        return super.getClassLoader();
    }

    public boolean a(CommandSender commandSender) {
        if (Config.g() > 0) {
            return false;
        }
        for (Arena arena : s.af) {
            arena.a(KickReason.c);
        }
        ((de.marcely.bedwars.command.arena.f)((d)MBedwars.a.a((String)"arena").a()).a.a((String)"gui").a()).e.clear();
        UserAchievements.e();
        c.e();
        Language.getPack().clear();
        Config.a(false, commandSender);
        return true;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static enum PluginState {
        b(true, de.marcely.bedwars.api.PluginState.Enabling),
        c(true, de.marcely.bedwars.api.PluginState.Running),
        d(false, de.marcely.bedwars.api.PluginState.StartFailed),
        e(false, de.marcely.bedwars.api.PluginState.Disabling),
        f(false, de.marcely.bedwars.api.PluginState.Disabled);
        
        private final boolean taskable;
        private final de.marcely.bedwars.api.PluginState a;

        private PluginState(boolean bl2, de.marcely.bedwars.api.PluginState pluginState) {
            this.taskable = bl2;
            this.a = pluginState;
        }

        public boolean isTaskable() {
            return this.taskable;
        }

        public de.marcely.bedwars.api.PluginState a() {
            return this.a;
        }
    }

}

