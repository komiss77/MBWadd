/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dD;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;

public abstract class dI
extends dD {
    public dI(String string) {
        super("playerarena-" + string);
    }

    @Override
    public String e(Player player) {
        Arena arena = s.a(player);
        if (arena != null) {
            return this.a(player, arena);
        }
        return "/";
    }

    protected abstract String a(Player var1, Arena var2);
}

