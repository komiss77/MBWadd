/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ex {
    public abstract ey a();

    protected abstract void a(BufferedWriteStream var1);

    protected abstract void a(BufferedReadStream var1);

    public void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.a().getId());
        this.a(bufferedWriteStream);
    }

    @Nullable
    public static ex a(BufferedReadStream bufferedReadStream) {
        ey ey2 = ey.a(bufferedReadStream.readByte());
        if (ey2 != null) {
            ex ex2 = ey2.a();
            ex2.a(bufferedReadStream);
            return ex2;
        }
        return null;
    }
}

