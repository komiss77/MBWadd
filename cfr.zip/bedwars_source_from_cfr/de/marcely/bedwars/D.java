/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;

public class D
extends NormalPacket {
    public a a;

    @Override
    public byte getPacketID() {
        return 17;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.a.name());
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.a = a.a(bufferedReadStream.readString());
        if (this.a == null) {
            this.a = a.f;
        }
    }

    public static enum a {
        b,
        c,
        d,
        e,
        f;
        

        @Nullable
        public static a a(String string) {
            for (a a2 : a.values()) {
                if (!a2.name().equals(string)) continue;
                return a2;
            }
            return null;
        }
    }

}

