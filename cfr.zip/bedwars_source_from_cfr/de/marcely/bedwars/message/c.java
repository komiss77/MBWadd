/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.message;

import de.marcely.bedwars.message.b;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

public interface c {
    public String a(@Nullable CommandSender var1, b var2);
}

