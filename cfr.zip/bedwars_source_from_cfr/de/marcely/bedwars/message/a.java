/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.message;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.message.c;
import de.marcely.bedwars.message.d;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public class a
implements c {
    private static /* synthetic */ int[] r;

    @Override
    public String a(@Nullable CommandSender commandSender, b b2) {
        if (commandSender == null) {
            commandSender = Bukkit.getConsoleSender();
        }
        String string = null;
        switch (a.s()[b2.a().a().ordinal()]) {
            case 1: {
                string = b2.a().s();
                break;
            }
            case 2: {
                string = b2.a().a().getMessage(commandSender);
            }
        }
        if (string == null) {
            throw new RuntimeException("Input is null");
        }
        if (b2.V()) {
            string = Language.replaceLanguageTranslations(commandSender, string);
        }
        if (b2.T()) {
            string = String.valueOf(Language.Prefix.getMessage(commandSender)) + " " + string;
        }
        if (b2.getPlaceholders().size() >= 1) {
            for (Map.Entry<String, String> entry : b2.getPlaceholders().entrySet()) {
                if (entry.getKey() == null || entry.getValue() == null) continue;
                string = string.replace("{" + entry.getKey() + "}", entry.getValue());
            }
        }
        if (b2.U()) {
            string = Language.stringToChatColor(string);
        }
        return string;
    }

    static /* synthetic */ int[] s() {
        if (r != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[d.a.values().length];
        try {
            arrn[d.a.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[d.a.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        r = arrn;
        return r;
    }
}

