/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.message;

import de.marcely.bedwars.Language;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class d {
    private a a;
    private Language a;
    private String O;

    public a a() {
        return this.a;
    }

    public void a(a a2) {
        this.a = a2;
    }

    public Language a() {
        return this.a;
    }

    public void b(Language language) {
        this.a = language;
    }

    public String s() {
        return this.O;
    }

    public void z(String string) {
        this.O = string;
    }

    public static enum a {
        b,
        c;
        
    }

}

