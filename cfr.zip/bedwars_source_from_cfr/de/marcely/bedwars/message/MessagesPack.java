/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.message;

import de.marcely.bedwars.Language;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MessagesPack {
    private final Map<String, Map<Language, String>> N = new HashMap<String, Map<Language, String>>();
    private Map<Language, String> O;

    public MessagesPack() {
        this.a(new HashMap<Language, String>(0));
    }

    public void a(Locale locale, Map<Language, String> map) {
        this.N.put(locale.toString(), map);
    }

    public void a(Map<Language, String> map) {
        this.O = map;
    }

    public void clear() {
        this.N.clear();
    }

    public String a(String string, Language language) {
        String string2;
        Map<Language, String> map = this.N.get(string);
        if (map == null) {
            map = this.O;
        }
        return (string2 = map.get((Object)language)) != null ? string2 : language.getDefaultEnglish();
    }

    public String a(Locale locale, Language language) {
        return this.a(locale.toString(), language);
    }
}

