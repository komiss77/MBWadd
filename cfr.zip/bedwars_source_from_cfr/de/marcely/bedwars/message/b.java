/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.message;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.message.c;
import de.marcely.bedwars.message.d;
import de.marcely.bedwars.util.g;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.t;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class b
implements g.a {
    private static g<b> a = new g<b>(8){

        public b d() {
            return new b(null);
        }

        @Override
        public /* synthetic */ g.a a() {
            return this.d();
        }
    };
    private d a = new d();
    private Map<String, String> M = new HashMap<String, String>(4);
    private boolean ab = false;
    private boolean ac = false;
    private boolean ad = false;

    private b() {
    }

    @Override
    public void reset() {
        this.M.clear();
        this.ab = false;
        this.ac = false;
        this.ad = false;
        this.a.a(null);
        this.a.b(null);
        this.a.z(null);
    }

    public b a(String string, String string2) {
        this.M.put(string, string2);
        return this;
    }

    public boolean T() {
        return this.ab;
    }

    public boolean U() {
        return this.ac;
    }

    public boolean V() {
        return this.ad;
    }

    public b a() {
        this.ab = true;
        return this;
    }

    public b b() {
        this.ac = true;
        return this;
    }

    public b c() {
        this.ad = true;
        return this;
    }

    public boolean W() {
        return this.a.a() == null;
    }

    public boolean X() {
        if (this.W()) {
            return false;
        }
        a.a(this);
        return true;
    }

    @Nullable
    public String f(@Nullable CommandSender commandSender) {
        return this.b(commandSender, true);
    }

    @Nullable
    public String b(@Nullable CommandSender commandSender, boolean bl2) {
        if (this.W()) {
            throw new IllegalStateException("Instance is already freed");
        }
        String string = null;
        try {
            string = s.a.a(commandSender, this);
        }
        catch (Error error) {
            error.printStackTrace();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (bl2) {
            this.X();
        }
        return string;
    }

    public static b a(Language language) {
        t.c((Object)language);
        b b2 = a.b();
        b2.a.a(d.a.c);
        b2.a.b(language);
        return b2;
    }

    @Nullable
    public static b a(String string) {
        t.c(string);
        b b2 = a.b();
        b2.a.a(d.a.b);
        b2.a.z(string);
        return b2;
    }

    public d a() {
        return this.a;
    }

    public Map<String, String> getPlaceholders() {
        return this.M;
    }

    /* synthetic */ b(b b2) {
        this();
    }

}

