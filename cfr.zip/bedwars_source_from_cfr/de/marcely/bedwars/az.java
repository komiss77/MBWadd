/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.bx;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.config.q;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.game.stats.StatsSign;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class az {
    public static void a(final BlockBreakEvent blockBreakEvent) {
        Object object;
        Arena arena;
        Player player = blockBreakEvent.getPlayer();
        final Block block = blockBreakEvent.getBlock();
        if (a.b(block)) {
            if (s.hasPermission((CommandSender)player, Permission.Command_AddSign)) {
                for (Map.Entry object22 : s.S.entrySet()) {
                    XYZW bl2 = (XYZW)object22.getKey();
                    if (bl2.getWorld() == null && !b.o() && !s.g(bl2.getWorldString())) {
                        s.S.remove(bl2);
                    }
                    if (!block.getWorld().equals((Object)bl2.getWorld()) || bl2.getX() != (double)block.getX() || bl2.getY() != (double)block.getY() || bl2.getZ() != (double)block.getZ()) continue;
                    s.S.remove(bl2);
                    s.ai();
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Removed_Sign).a());
                    return;
                }
            }
            if (s.hasPermission((CommandSender)player, Permission.Command_AddStatsSign) && s.T.remove(block.getLocation().toString()) != null) {
                q.save();
                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Removed_Sign).a());
                return;
            }
        }
        if ((arena = s.a(player)) != null) {
            if (arena.b() == ArenaStatus.f) {
                h h2;
                Object object2;
                XYZ xYZ;
                object = block.getType();
                boolean bl2 = false;
                boolean bl3 = bl2 = object == ConfigValue.bed_block;
                if (!bl2 && Version.a().getVersionNumber() >= 13 && object == Material.AIR) {
                    String string = ((w)Version.a().a()).a(block.getWorld(), block.getX(), block.getY(), block.getZ());
                    if (ConfigValue.bed_block == Material.BED_BLOCK && string.endsWith("_bed")) {
                        bl2 = true;
                    } else {
                        object2 = string.split("_");
                        if (((Object)object2).length >= 2) {
                            String string2 = "legacy_" + String.join((CharSequence)"_", (CharSequence[])Arrays.copyOfRange(object2, 1, ((Object)object2).length));
                            bl2 = string2.equals(object.name().toLowerCase());
                        }
                    }
                }
                if (bl2 && (object2 = (h2 = arena.a()).a(block.getLocation())) != null) {
                    blockBreakEvent.setCancelled(true);
                    if (ConfigValue.bed_onlydestroyablewith_tnt) {
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Bed_OnlyDestroyAbleWith_TNT));
                        return;
                    }
                    if (!ConfigValue.ownbed_destroyable && object2 == arena.a(player)) {
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotAllowed_BedDestroy));
                        return;
                    }
                    blockBreakEvent.setCancelled(true);
                    new BukkitRunnable((Team)((Object)object2), arena, player){
                        private final /* synthetic */ Arena val$arena;
                        private final /* synthetic */ Player val$player;
                        private final /* synthetic */ Block a;
                        {
                            block = team;
                            this.val$arena = arena;
                            this.val$player = player;
                        }

                        public void run() {
                            for (Block block2 : h2.a(block)) {
                                block2.setType(Material.AIR, false);
                            }
                            this.val$arena.a(this.val$player, this.a.getLocation(), block);
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 0L);
                    return;
                }
                if (object == ConfigValue.rescueplatform_material) {
                    blockBreakEvent.setCancelled(true);
                    new BukkitRunnable(){

                        public void run() {
                            blockBreakEvent.getBlock().setType(Material.AIR);
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 1L);
                    return;
                }
                if (block.getType() == Material.TNT) {
                    for (Map.Entry entry : arena.o.entrySet()) {
                        xYZ = XYZ.valueOf(block.getLocation());
                        if (!XYZ.ofString((String)entry.getKey()).equals(xYZ)) continue;
                        arena.o.remove(entry.getKey());
                        break;
                    }
                }
                if (arena.a(block.getLocation())) {
                    blockBreakEvent.setCancelled(true);
                    return;
                }
                if (block.getType() == Material.ENDER_CHEST || block.getType() == Material.WEB) {
                    new BukkitRunnable(){

                        public void run() {
                            if (block.getType() != null && block.getType() != Material.AIR) {
                                s.f(blockBreakEvent.getBlock());
                                blockBreakEvent.getBlock().getWorld().dropItemNaturally(blockBreakEvent.getBlock().getLocation(), new ItemStack(block.getType(), 1));
                            }
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 0L);
                }
                for (Map.Entry entry : arena.n.entrySet()) {
                    xYZ = XYZ.valueOf(block.getLocation());
                    if (!XYZ.ofString((String)entry.getKey()).equals(xYZ)) continue;
                    arena.n.remove(entry.getKey());
                    break;
                }
                if (ConfigValue.destroyblock_builtbyplayers && !arena.a(block)) {
                    blockBreakEvent.setCancelled(true);
                    return;
                }
                Arena arena2 = s.a(block.getLocation());
                if (ConfigValue.placeableblock_whitelist_enabled && !s.W.containsKey(object) && !ConfigValue.placeableblock_whitelist.contains(object) && block.getType() != bx.g.getItemStack().getType() || arena2 == null || !arena2.equals(arena)) {
                    blockBreakEvent.setCancelled(true);
                } else {
                    object2 = block.getDrops();
                    if (object2.size() >= 1 && ((ItemStack)object2.iterator().next()).getType() != block.getType()) {
                        blockBreakEvent.setCancelled(true);
                        block.getWorld().dropItemNaturally(block.getLocation().add((double)(s.RAND.nextFloat() * 0.5f) + 0.25, (double)(s.RAND.nextFloat() * 0.5f) + 0.25, (double)(s.RAND.nextFloat() * 0.5f) + 0.25), new ItemStack(block.getType()));
                        block.setType(Material.AIR);
                    } else {
                        blockBreakEvent.setCancelled(false);
                    }
                }
            } else {
                blockBreakEvent.setCancelled(true);
            }
        } else if (cA.E.containsKey((Object)player)) {
            blockBreakEvent.setCancelled(true);
        } else {
            object = s.a(block.getLocation());
            if (object != null) {
                blockBreakEvent.setCancelled(!s.hasPermission((CommandSender)player, Permission.ArenaBuild));
            }
        }
    }

}

