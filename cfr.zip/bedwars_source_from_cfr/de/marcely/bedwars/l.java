/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 */
package de.marcely.bedwars;

import de.marcely.bedwars.d;
import de.marcely.bedwars.k;
import de.marcely.bedwars.util.MThread;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import org.bukkit.Bukkit;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class l
implements k {
    private int packetSize = 1024;
    private DatagramSocket socket = null;
    private MThread a = null;

    public l() {
    }

    public l(int n2) {
        this.packetSize = n2;
    }

    public int a() {
        return this.packetSize;
    }

    public DatagramSocket a() {
        return this.socket;
    }

    public boolean isInjected() {
        return this.socket != null;
    }

    public boolean j() {
        return this.a != null;
    }

    public MThread a() {
        return this.a;
    }

    public boolean inject() {
        if (!this.isInjected()) {
            try {
                this.socket = new DatagramSocket(null);
                InetSocketAddress inetSocketAddress = new InetSocketAddress(InetAddress.getLocalHost(), Bukkit.getServer().getPort());
                this.socket.bind(inetSocketAddress);
            }
            catch (SocketException | UnknownHostException iOException) {
                d.d("Failed to bind into socket!");
                d.e("Maybe restarting your server will fix that.");
                iOException.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }

    public boolean close() {
        if (this.isInjected()) {
            this.l();
            this.socket.close();
            this.socket = null;
            return true;
        }
        return false;
    }

    public DatagramPacket a(InetAddress inetAddress, int n2, byte[] arrby) {
        DatagramPacket datagramPacket = new DatagramPacket(arrby, arrby.length, inetAddress, n2);
        try {
            this.socket.send(datagramPacket);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        return datagramPacket;
    }

    public boolean k() {
        if (!this.j()) {
            this.a = new MThread(MThread.ThreadType.a){

                @Override
                public void run() {
                    while (l.this.j()) {
                        byte[] arrby = new byte[1024];
                        DatagramPacket datagramPacket = new DatagramPacket(arrby, arrby.length);
                        try {
                            l.this.socket.receive(datagramPacket);
                        }
                        catch (IOException iOException) {
                            // empty catch block
                        }
                        if (datagramPacket == null || datagramPacket.getLength() < 1) continue;
                        l.this.b(datagramPacket);
                    }
                }
            };
            this.a.start();
            return true;
        }
        return false;
    }

    public boolean l() {
        if (this.j()) {
            this.a.interrupt();
            this.a = null;
            return true;
        }
        return false;
    }

    @Override
    public void b(DatagramPacket datagramPacket) {
    }

}

