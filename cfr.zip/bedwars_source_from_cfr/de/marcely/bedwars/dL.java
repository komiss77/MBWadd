/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dI;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dL
extends dI {
    public dL() {
        super("teamsize");
    }

    @Override
    protected String a(Player player, Arena arena) {
        return "" + arena.getPerTeamPlayers();
    }
}

