/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.stats.c;

public abstract class ct
extends bS<c> {
    @Override
    public bP.c a() {
        return bP.c.c;
    }

    @Override
    public String c(Arena arena) {
        return null;
    }
}

