/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.World
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 */
package de.marcely.bedwars;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

public class bM {
    public String type;
    public d c;

    public bM(String string, d d2) {
        this.type = string;
        this.c = d2;
    }

    public void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.type);
        this.c.write(bufferedWriteStream);
    }

    @Nullable
    public Entity b(World world) {
        EntityType entityType = s.a(this.type);
        if (entityType == null) {
            return null;
        }
        Entity entity = Version.a().a(world, entityType, this.c);
        return entity;
    }

    public static bM a(BufferedReadStream bufferedReadStream) {
        return new bM(bufferedReadStream.readString(), (d)Value.a(bufferedReadStream));
    }

    public static bM a(Entity entity) {
        return new bM(entity.getType().toString(), Version.a().a(entity));
    }
}

