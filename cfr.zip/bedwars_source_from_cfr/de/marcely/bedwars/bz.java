/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import org.bukkit.DyeColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class bz
extends by {
    private BukkitTask d;

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = playerUseExtraItemEvent.getPlayer();
        Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        int n2 = s.a(player, ConfigValue.bridge_material);
        if (n2 == 0) {
            s.a((CommandSender)player, b.a(Language.Bridge_NotEnoughMaterials).a("material", ConfigValue.bridge_material.name().replace("_", "").toLowerCase()));
            this.done();
            return;
        }
        Team team = arena.a(player);
        Location location = player.getLocation().add(0.0, -1.0, 0.0);
        Vector vector = location.toVector();
        int n3 = n2 > ConfigValue.bridge_maxlength ? ConfigValue.bridge_maxlength : n2;
        location.setPitch(0.0f);
        if (n3 > 0) {
            s.a(player, Achievement.n);
            this.L();
            this.a(arena, player, team, location, vector, n3);
        }
    }

    @Override
    public void K() {
        if (this.d != null) {
            this.d.cancel();
        }
    }

    private void a(final Arena arena, final Player player, final Team team, final Location location, final Vector vector, final int n2) {
        Location location2 = vector.toLocation(arena.getWorld());
        Block block = location2.getBlock();
        if (arena.isInside(location2) && s.a(player, ConfigValue.bridge_material) >= 1 && !block.getType().isSolid() && bz.a(location2, arena)) {
            Sound.BRIDGE_BUILD.play(location2);
            for (int i2 = 0; i2 < 3; ++i2) {
                VarParticle.PARTICLE_CLOUD.play(location2.getWorld(), location2, 1);
            }
            block.setType(ConfigValue.bridge_material);
            a.a(block, team.getDyeColor());
            s.a(player, ConfigValue.bridge_material);
            if (ConfigValue.destroyblock_builtbyplayers || ConfigValue.tnt_canbreakblocks_breakby_player) {
                arena.b(block);
            }
        }
        if (n2 > 0) {
            this.d = new BukkitRunnable(){

                public void run() {
                    Vector vector2 = vector.add(location.getDirection());
                    bz.this.a(arena, player, team, location, vector2, n2 - 1);
                }
            }.runTaskLater((Plugin)MBedwars.a, 2L);
        } else {
            this.done();
        }
    }

    private static boolean a(Location location, Arena arena) {
        if (arena.a(location)) {
            return false;
        }
        for (Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(location.add(0.5, 0.5, 0.5), 0.5, 0.5, 0.5)) {
            if (!(entity instanceof LivingEntity) || Version.a().getVersionNumber() >= 8 && entity.getType() == EntityType.PLAYER && ((Player)entity).getGameMode() == GameMode.SPECTATOR) continue;
            return false;
        }
        return true;
    }

}

