/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.e;
import de.marcely.bedwars.util.r;

public class bV
extends bS<Arena> {
    public static bV a = new bV();

    @Override
    public bP.c a() {
        return bP.c.e;
    }

    @Override
    public String c(Arena arena) {
        if (arena.a == null) {
            return Language.Countdown_Stopped.getMessage();
        }
        int n2 = arena.a.getValue() % 60;
        int n3 = (int)Math.floor(arena.a.getValue() / 60);
        return String.valueOf(r.a("" + n3, '0', 2)) + ":" + r.a("" + n2, '0', 2);
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.c((Arena)object);
    }
}

