/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Ageable
 *  org.bukkit.entity.AnimalTamer
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Creature
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Slime
 *  org.bukkit.entity.Tameable
 *  org.bukkit.entity.Wolf
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.EntityTargetEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Creature;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class bA
extends by
implements Listener {
    private Arena arena;
    private Team team;
    private BukkitTask d;
    private Creature a;
    private LivingEntity a;

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = playerUseExtraItemEvent.getPlayer();
        Block block = playerUseExtraItemEvent.getClickedBlock();
        BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (block == null) {
            this.done();
            return;
        }
        this.arena = (Arena)playerUseExtraItemEvent.getArena();
        this.team = this.arena.a(player);
        s.a(player, Achievement.o);
        Location location = block.getLocation();
        Location location2 = new Location(location.getWorld(), location.getX() + (double)blockFace.getModX(), location.getY() + (double)blockFace.getModY(), location.getZ() + (double)blockFace.getModZ());
        this.L();
        this.a(location2);
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }

    @Override
    public void K() {
        HandlerList.unregisterAll((Listener)this);
        if (this.a != null) {
            this.a.remove();
            this.d.cancel();
        }
    }

    private void a(Location location) {
        Entity entity = location.getWorld().spawnEntity(location, ConfigValue.guarddog_type);
        if (!(entity instanceof Creature)) {
            d.d("guarddog-type: " + (Object)ConfigValue.guarddog_type + " isn't a creature! Guarddogs don't spawn because of that.", "Main");
            this.done();
            return;
        }
        Creature creature = (Creature)entity;
        creature.setMaxHealth(20.0);
        creature.setHealth(20.0);
        creature.setRemoveWhenFarAway(false);
        this.a = creature;
        if (entity instanceof Tameable) {
            creature = (Tameable)entity;
            creature.setTamed(true);
            creature.setOwner(new AnimalTamer(){

                public String getName() {
                    return "_I HAVE NO OWNER RIP 2k18_";
                }

                public UUID getUniqueId() {
                    return UUID.randomUUID();
                }
            });
        }
        if (entity instanceof Ageable) {
            ((Ageable)entity).setAdult();
        }
        if (entity instanceof Wolf) {
            ((Wolf)entity).setCollarColor(this.team.getDyeColor());
        }
        if (s.a(entity)) {
            Version.a().c(entity);
        }
        this.d = new BukkitRunnable(){

            public void run() {
                bA.this.tick();
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 30L);
        if (Version.a().getVersionNumber() >= 8) {
            entity = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
            entity.setSmall(true);
            entity.setMarker(true);
            entity.setVisible(false);
            this.a = entity;
        } else {
            entity = (Slime)location.getWorld().spawnEntity(location, EntityType.SLIME);
            entity.setSize(0);
            Version.a().b(entity, true);
            entity.setHealth(Double.MAX_VALUE);
            this.a = entity;
        }
    }

    private void tick() {
        if (this.a.isDead() || this.a.getWorld() != this.arena.getWorld()) {
            this.done();
            return;
        }
        Location location = new ArrayList(this.arena.getPlayers().size());
        for (Map.Entry<Player, Team> entry : this.arena.l.entrySet()) {
            Player player3 = entry.getKey();
            Team team = entry.getValue();
            if (this.team == team || player3.getWorld() != this.a.getWorld() || !(player3.getLocation().distance(this.a.getLocation()) <= 12.0) || cA.E.containsKey((Object)player3)) continue;
            location.add(player3);
        }
        if (location.size() >= 1) {
            if (location.size() >= 2) {
                location.sort((player, player2) -> Double.compare(player.getLocation().distance(this.a.getLocation()), player2.getLocation().distance(this.a.getLocation())));
            }
            this.a.setTarget((LivingEntity)location.get(0));
            return;
        }
        location = this.arena.a().d().get((Object)this.team).toBukkit(this.arena.getWorld());
        if (location != null) {
            if (this.a.getLocation().distance(location) >= 32.0) {
                this.a.teleport(s.b(location.clone().add(0.0, 1.0, 0.0)));
                return;
            }
            if (this.a.getLocation().distance(location) >= 8.0) {
                this.b(location);
                return;
            }
        }
        this.a.setTarget(null);
    }

    private void b(Location location) {
        this.a.teleport(location);
        this.a.setTarget(this.a);
    }

    @EventHandler
    public void a(EntityDamageEvent entityDamageEvent) {
        EntityDamageEvent.DamageCause damageCause;
        if (entityDamageEvent.getEntity() == this.a && ((damageCause = entityDamageEvent.getCause()) == EntityDamageEvent.DamageCause.VOID || damageCause == EntityDamageEvent.DamageCause.FALL)) {
            entityDamageEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void a(EntityTargetEvent entityTargetEvent) {
        Player player;
        Team team;
        if (entityTargetEvent.getEntity() == this.a && entityTargetEvent.getTarget() instanceof Player && (team = this.arena.a(player = (Player)entityTargetEvent.getTarget())) != null && team == this.team) {
            entityTargetEvent.setCancelled(true);
        }
    }

}

