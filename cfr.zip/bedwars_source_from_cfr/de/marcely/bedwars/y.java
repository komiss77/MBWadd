/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.j;

public class y
extends j {
    private Arena arena;
    private ArenaStatus a;

    public y(Arena arena, ArenaStatus arenaStatus) {
        this.arena = arena;
        this.a = arenaStatus;
    }

    public Arena getArena() {
        return this.arena;
    }

    public ArenaStatus a() {
        return this.a;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.j.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.a.getID();
    }
}

