/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.metadata.Metadatable
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.bx;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.awt.Color;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class bF
extends by
implements Listener {
    private static final String E = "MBW_EI_TP_USE";
    private Player player;
    private int slot;
    private BukkitTask d;
    private float c;
    private int W;
    private int X;
    private a a;

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        final ItemStack itemStack = playerUseExtraItemEvent.getItem();
        long l2 = s.a((Metadatable)player, E, 0L);
        if (System.currentTimeMillis() - l2 <= (long)(ConfigValue.teleporter_countdown * 1000)) {
            this.done();
            return;
        }
        s.a(player, Achievement.q);
        Sound.EXTRAITEM_TELEPORTER_USE.play(player);
        if (!ConfigValue.teleporter_countdown_enabled) {
            this.L();
            arena.a(player, arena.a().a(arena.a(player)).toBukkit(arena.getWorld()));
            this.done();
            return;
        }
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
        player.setMetadata(E, (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        s.a((CommandSender)player, b.a(Language.Teleporter));
        this.player = playerUseExtraItemEvent.getPlayer();
        this.X = ConfigValue.teleporter_countdown * 20;
        this.c = player.getExp();
        this.W = player.getLevel();
        this.slot = player.getInventory().getHeldItemSlot();
        this.a = new a();
        if (bx.b.getItemStack().getType() == Material.SULPHUR) {
            itemStack.setType(Material.GLOWSTONE_DUST);
        }
        this.d = new BukkitRunnable(){

            public void run() {
                if (bF.this.X == 0) {
                    itemStack.setAmount(itemStack.getAmount() - 1);
                    if (itemStack.getAmount() <= 0) {
                        player.getInventory().setItem(bF.this.slot, new ItemStack(Material.AIR));
                    } else {
                        itemStack.setType(bx.b.getItemStack().getType());
                        player.getInventory().setItem(bF.this.slot, itemStack);
                    }
                    if (arena != null) {
                        arena.a(player, s.b(arena.a().a(arena.a(player)).toBukkit(arena.getWorld())));
                    }
                    bF.this.done();
                    return;
                }
                bF.this.tick();
                bF.this.a.c(bF.this);
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 1L);
    }

    @Override
    public void K() {
        if (this.d != null) {
            HandlerList.unregisterAll((Listener)this);
            this.player.removeMetadata(E, (Plugin)MBedwars.a);
            this.d.cancel();
            this.a.d(this);
            this.player.setExp(this.c);
            this.player.setLevel(this.W);
            ItemStack itemStack = this.player.getInventory().getItem(this.slot);
            if (itemStack != null) {
                itemStack.setType(bx.b.getItemStack().getType());
            }
        }
    }

    private void tick() {
        this.player.setExp((float)((double)this.X / (double)(ConfigValue.teleporter_countdown * 20)));
        this.player.setLevel(this.X / 20 + 1);
        --this.X;
        int n2 = this.X / 15;
        if (n2 <= 2) {
            n2 = 2;
        } else if (n2 > 25) {
            n2 = 25;
        }
        if (this.X % n2 == 0) {
            Sound.TELEPORTER_COUNTING.play(this.player.getLocation());
        }
    }

    @EventHandler
    protected void a(InventoryClickEvent inventoryClickEvent) {
        if (inventoryClickEvent.getWhoClicked() == this.player && inventoryClickEvent.getSlot() == this.slot) {
            inventoryClickEvent.setCancelled(true);
        }
    }

    @EventHandler
    protected void a(PlayerDropItemEvent playerDropItemEvent) {
        if (playerDropItemEvent.getPlayer() == this.player && playerDropItemEvent.getPlayer().getInventory().getHeldItemSlot() == this.slot) {
            playerDropItemEvent.setCancelled(true);
        }
    }

    @EventHandler
    protected void a(PlayerMoveEvent playerMoveEvent) {
        if (playerMoveEvent.getPlayer() == this.player && playerMoveEvent.getFrom().distance(playerMoveEvent.getTo()) >= 0.2) {
            s.a((CommandSender)this.player, b.a(Language.Teleporter_Failed));
            this.done();
        }
    }

    private static class a {
        final float d = 1.75f;
        final float e = 1.75f / ((float)ConfigValue.teleporter_countdown * 20.0f);
        int Y = 0;
        float y = 0.0f;

        private a() {
        }

        public void c(bF bF2) {
            if (this.y < 1.75f) {
                if (this.Y < 360) {
                    this.Y += 5;
                    this.a(this.y, this.Y, bF2.player.getLocation().add(0.0, (double)this.y, 0.0).clone(), 1.75f);
                } else {
                    this.Y = 0;
                }
                this.y += this.e;
            }
        }

        private void a(float f2, float f3, Location location, float f4) {
            float f5 = f2 / f4;
            double d2 = Math.toRadians(f3);
            double d3 = Math.toRadians(f3 + 120.0f);
            double d4 = Math.toRadians(f3 + 240.0f);
            location.add(Math.cos(d2) * 1.0, 0.0, Math.sin(d2) * 2.0);
            this.b(location, f5);
            location.subtract(Math.cos(d2) * 1.0, 0.0, Math.sin(d2) * 1.0);
            location.add(Math.cos(d3) * 1.0, 0.0, Math.sin(d3) * 1.0);
            this.b(location, f5);
            location.subtract(Math.cos(d3) * 1.0, 0.0, Math.sin(d3) * 1.0);
            location.add(Math.cos(d4) * 1.0, 0.0, Math.sin(d4) * 1.0);
            this.b(location, f5);
            location.subtract(Math.cos(d4) * 1.0, 0.0, Math.sin(d4) * 1.0);
        }

        private void b(Location location, float f2) {
            for (Player player : de.marcely.bedwars.util.b.getOnlinePlayers()) {
                VarParticle.PARTICLE_COLOURED.play(player, location, s.a(Color.getHSBColor(f2, 1.0f, 1.0f)));
            }
        }

        public void d(bF bF2) {
            new BukkitRunnable(bF2){
                final Location loc;
                final float f;
                float g;
                {
                    this.loc = bF2.player.getLocation().clone();
                    this.f = a2.y;
                    this.g = 0.0f;
                }

                public void run() {
                    float f2 = this.f - this.g;
                    while ((f2 -= 0.3f) > 0.0f) {
                        this.a(f2, Y, this.loc.clone().add(0.0, (double)f2, 0.0), this.f);
                    }
                    this.g += 0.05f;
                    if (this.g >= this.f) {
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
        }

    }

}

