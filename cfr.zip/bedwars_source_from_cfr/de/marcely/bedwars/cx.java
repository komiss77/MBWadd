/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cx
extends ct {
    public static cx a = new cx();

    public String b(c c2) {
        return "" + c2.a();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

