/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

public class bo
extends Exception {
    private static final long serialVersionUID = 1L;

    public bo() {
        this("This is not allowed!");
    }

    public bo(String string) {
        super(string);
    }
}

