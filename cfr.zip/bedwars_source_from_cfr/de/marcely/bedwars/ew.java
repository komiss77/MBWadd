/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class ew
extends ex {
    public static final byte H = 0;
    public static final byte I = 16;
    public static final byte J = 17;
    public static final byte K = 48;
    public byte L;
    public String message;

    @Override
    public ey a() {
        return ey.j;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.L = bufferedReadStream.readByte();
        this.message = bufferedReadStream.readString();
    }
}

