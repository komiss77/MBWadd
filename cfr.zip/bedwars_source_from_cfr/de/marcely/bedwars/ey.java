/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.bedwars.en;
import de.marcely.bedwars.eo;
import de.marcely.bedwars.ep;
import de.marcely.bedwars.eq;
import de.marcely.bedwars.er;
import de.marcely.bedwars.es;
import de.marcely.bedwars.et;
import de.marcely.bedwars.eu;
import de.marcely.bedwars.ev;
import de.marcely.bedwars.ew;
import de.marcely.bedwars.ex;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ey
extends Enum<ey> {
    public static final /* enum */ ey a = new ey(0);
    public static final /* enum */ ey b = new ey(1);
    public static final /* enum */ ey c = new ey(2);
    public static final /* enum */ ey d = new ey(3);
    public static final /* enum */ ey e = new ey(16);
    public static final /* enum */ ey f = new ey(17);
    public static final /* enum */ ey g = new ey(32);
    public static final /* enum */ ey h = new ey(33);
    public static final /* enum */ ey i = new ey(48);
    public static final /* enum */ ey j = new ey(49);
    private final byte id;
    private static /* synthetic */ int[] t;
    private static final /* synthetic */ ey[] a;

    static {
        a = new ey[]{a, b, c, d, e, f, g, h, i, j};
    }

    private ey(int n3) {
        this.id = (byte)n3;
    }

    public ex a() {
        switch (ey.u()[this.ordinal()]) {
            case 1: {
                return new es();
            }
            case 2: {
                return new et();
            }
            case 3: {
                return new eu();
            }
            case 4: {
                return new ev();
            }
            case 5: {
                return new eq();
            }
            case 6: {
                return new er();
            }
            case 7: {
                return new eo();
            }
            case 8: {
                return new ep();
            }
            case 9: {
                return new en();
            }
            case 10: {
                return new ew();
            }
        }
        return null;
    }

    @Nullable
    public static ey a(byte by2) {
        for (ey ey2 : ey.values()) {
            if (ey2.getId() != by2) continue;
            return ey2;
        }
        return null;
    }

    public byte getId() {
        return this.id;
    }

    public static ey[] values() {
        ey[] arrey = a;
        int n2 = arrey.length;
        ey[] arrey2 = new ey[n2];
        System.arraycopy(arrey, 0, arrey2, 0, n2);
        return arrey2;
    }

    public static ey valueOf(String string) {
        return Enum.valueOf(ey.class, string);
    }

    static /* synthetic */ int[] u() {
        if (t != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ey.values().length];
        try {
            arrn[ey.i.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.g.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.h.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.e.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.f.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ey.j.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        t = arrn;
        return t;
    }
}

