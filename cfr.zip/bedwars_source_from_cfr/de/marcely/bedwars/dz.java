/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dy;
import de.marcely.bedwars.game.arena.Arena;
import java.util.List;
import org.bukkit.entity.Player;

public class dz
extends dy {
    public dz(Arena arena) {
        super(arena, "players");
    }

    @Override
    public String e(Player player) {
        return "" + this.arena.getPlayers().size();
    }
}

