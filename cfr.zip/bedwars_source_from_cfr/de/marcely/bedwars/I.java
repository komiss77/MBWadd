/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class I
extends NormalPacket {
    public String name;

    @Override
    public byte getPacketID() {
        return 33;
    }

    @Override
    protected void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
    }

    @Override
    protected void read(BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
    }
}

