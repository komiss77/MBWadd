/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class er
extends ex {
    public d[] a;

    @Override
    public ey a() {
        return ey.f;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.a = new d[bufferedReadStream.readUnsignedByte()];
        for (int i2 = 0; i2 < this.a.length; ++i2) {
            d d2 = new d();
            d2.read(bufferedReadStream);
            this.a[i2] = d2;
        }
    }
}

