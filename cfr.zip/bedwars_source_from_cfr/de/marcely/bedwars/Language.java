/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.message.MessagesPack;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public enum Language {
    Prefix((Object)ChatColor.DARK_AQUA + "[Bedwars]"),
    All_Commands("All commands:"),
    Configurations_Reload_Start((Object)ChatColor.GREEN + "Configurations are now reloading!"),
    Configurations_Reload_End((Object)ChatColor.GREEN + "Configurations were reloaded after " + (Object)ChatColor.DARK_GREEN + "{time} seconds"),
    Configurations_Reload_AlreadyLoading((Object)ChatColor.RED + "Configurations are currently already reloading!"),
    Info_MadeBy("Made by"),
    Info_Website("Website"),
    Info_Version("Version"),
    Info_NewestVersion("Newest version"),
    Page("Page"),
    Help("Help"),
    Team("Team"),
    None("none"),
    Unkown_Page((Object)ChatColor.RED + "Unkown page " + (Object)ChatColor.DARK_RED + "{page}"),
    Unkown_Argument((Object)ChatColor.RED + "Unkown argument " + (Object)ChatColor.DARK_RED + "{arg}"),
    Unkown_Block((Object)ChatColor.RED + "Unkown block " + (Object)ChatColor.DARK_RED + "{block}"),
    Unkown_Place((Object)ChatColor.RED + "Unkown place " + (Object)ChatColor.DARK_RED + "{place}"),
    Unkown_Itemspawner((Object)ChatColor.RED + "Unkown itemspawner " + (Object)ChatColor.DARK_RED + "{itemspawner}"),
    Version_New((Object)ChatColor.GREEN + "A new version has been found! " + (Object)ChatColor.DARK_GREEN + "{version}"),
    Version_NoNew((Object)ChatColor.RED + "No new version has been found!"),
    Error_Occured((Object)ChatColor.RED + "An error occured!"),
    Error_Occured_Syntax((Object)ChatColor.RED + "A syntax error occured: " + (Object)ChatColor.GOLD + "{message}"),
    No_Permissions((Object)ChatColor.RED + "You've got no permissions!"),
    OnlyAs_Player((Object)ChatColor.RED + "This works only as a player!"),
    Not_Ingame((Object)ChatColor.RED + "You're not in a round!"),
    Not_Ingame_Player((Object)ChatColor.DARK_RED + "{player} " + (Object)ChatColor.RED + "is not in an round!"),
    Not_Supported((Object)ChatColor.RED + "This is not supported for your Version! Please update to version " + (Object)ChatColor.DARK_RED + "{version} " + (Object)ChatColor.RED + "or higher"),
    Missing_ArenanameOrMadeby((Object)ChatColor.RED + "Missing arena-name or made-by"),
    Color_Yellow("yellow"),
    Color_Orange("orange"),
    Color_Red("red"),
    Color_Blue("blue"),
    Color_LightBlue("light blue"),
    Color_Cyan("cyan"),
    Color_LightGreen("light green"),
    Color_Green("green"),
    Color_Purple("purple"),
    Color_Pink("pink"),
    Color_White("white"),
    Color_LightGray("light gray"),
    Color_Gray("gray"),
    Color_Brown("brown"),
    Color_Black("black"),
    Missing_WorldeditPoints((Object)ChatColor.RED + "Missing worldedit points!"),
    Saved_Arena((Object)ChatColor.GREEN + "Arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been saved!"),
    Saved_Bed((Object)ChatColor.GREEN + "Saved bed for the team {colorcode}{color} " + (Object)ChatColor.GREEN + "in the arena " + (Object)ChatColor.DARK_GREEN + "{arena}"),
    DontForget_WorldeditPoints((Object)ChatColor.AQUA + "Don't forged to mark the points with worldedit!"),
    Exists_Arena((Object)ChatColor.RED + "The arena " + (Object)ChatColor.DARK_RED + "{arena} " + (Object)ChatColor.RED + "already exists!"),
    KickEveryoneWith((Object)ChatColor.GRAY + "Kick everyone with the command " + (Object)ChatColor.DARK_GRAY + "{command}"),
    SavedChanged_Arena((Object)ChatColor.GREEN + "The arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been changed and saved!"),
    SavedChanged_Points((Object)ChatColor.GREEN + "The points by the arena have been successfully changed!"),
    Spawner_Bronze("bronze"),
    Spawner_Iron("iron"),
    Spawner_Gold("gold"),
    Added_Itemspawner((Object)ChatColor.GREEN + "Itemspawner " + (Object)ChatColor.DARK_GREEN + "{spawnertype} " + (Object)ChatColor.GREEN + "has been successfully added!"),
    Added_Sign((Object)ChatColor.DARK_GREEN + "Sign " + (Object)ChatColor.GREEN + "has been successfully added!"),
    Removed_Sign((Object)ChatColor.GOLD + "Removed sign"),
    Removed_Itemspawners((Object)ChatColor.DARK_GREEN + "{number} " + (Object)ChatColor.GREEN + "Itemspawners have been removed!"),
    Start_Round((Object)ChatColor.GREEN + "Round is starting now."),
    Stop_Round((Object)ChatColor.GREEN + "Round has been stopped."),
    Kicked_Player((Object)ChatColor.GREEN + "Successfully kicked " + (Object)ChatColor.DARK_GREEN + "{player}" + (Object)ChatColor.GREEN + " from " + (Object)ChatColor.DARK_GREEN + "{arena}"),
    Kicked_Player_ToPlayer((Object)ChatColor.RED + "You were kicked from this round!"),
    List_Arenas((Object)ChatColor.YELLOW + "All arenas: " + (Object)ChatColor.GOLD),
    Only_BetaMember((Object)ChatColor.RED + "You are now allowed to join while bedwars is in the beta!"),
    NotAvaible_Color((Object)ChatColor.RED + "Unkown color " + (Object)ChatColor.DARK_RED + "{color}"),
    JoinMessage_stopped((Object)ChatColor.RED + "This arena is currently stopped!"),
    JoinMessage_reseting((Object)ChatColor.RED + "This arena is currently reseting itself!"),
    JoinMessage_full((Object)ChatColor.RED + "This arena is currently full!"),
    JoinMessage_running((Object)ChatColor.RED + "This arena is already running!"),
    JoinMessage_alreadyInside((Object)ChatColor.RED + "You are already inside the arena!"),
    JoinMessage((Object)ChatColor.GOLD + "{player} " + (Object)ChatColor.YELLOW + "has joined this round."),
    LeaveMessage((Object)ChatColor.GOLD + "{player} " + (Object)ChatColor.YELLOW + "left this round."),
    NotFound_Player((Object)ChatColor.DARK_RED + "{player} " + (Object)ChatColor.RED + "has not been found!"),
    NotFound_Arena((Object)ChatColor.RED + "There's no arena with the name " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + "!"),
    NotFound_Arena_Loading((Object)ChatColor.GOLD + "(Arena is currently loading)"),
    NotFound_Author((Object)ChatColor.RED + "There's no author named " + (Object)ChatColor.DARK_RED + "{author}" + (Object)ChatColor.RED + "!"),
    Get_Bed((Object)ChatColor.GREEN + "You've got the bed of {colorcode}{color}"),
    Countdown_Start((Object)ChatColor.GOLD + "The countdown is starting now!"),
    Countdown_Stop((Object)ChatColor.GOLD + "The countdown has been stopped!"),
    Countdown_Counting((Object)ChatColor.GOLD + "This round is starting in " + (Object)ChatColor.YELLOW + "{number} " + (Object)ChatColor.GOLD + "seconds!"),
    Countdown_Changed((Object)ChatColor.GOLD + "The countdown has been changed to " + (Object)ChatColor.YELLOW + "{number} " + (Object)ChatColor.GOLD + "seconds!"),
    Countdown_Voting_Counting((Object)ChatColor.GOLD + "The arena voting ends in " + (Object)ChatColor.YELLOW + "{number} " + (Object)ChatColor.GOLD + "seconds!"),
    TooFew_Materials((Object)ChatColor.RED + "You've got too few materials to buy this!"),
    TooLess_Players((Object)ChatColor.RED + "There're too less players in this round!"),
    NeedMore_Players_Than((Object)ChatColor.RED + "You need more players than " + (Object)ChatColor.DARK_RED + "{amount}" + (Object)ChatColor.RED + "!"),
    Win_Money((Object)ChatColor.GOLD + "You've won " + (Object)ChatColor.YELLOW + "{number}" + (Object)ChatColor.GOLD + "$!"),
    Player_NotIngameAnymore((Object)ChatColor.DARK_RED + "{player} " + (Object)ChatColor.RED + "is not ingame anymore!"),
    Player_NotFound((Object)ChatColor.DARK_RED + "{player} " + (Object)ChatColor.RED + "has not been found!"),
    Player_Cheating((Object)ChatColor.GOLD + "{player} " + (Object)ChatColor.YELLOW + "has been kicked because he was cheating!"),
    Player_Loosing((Object)ChatColor.GOLD + "{player} " + (Object)ChatColor.YELLOW + "has lost this round!"),
    Players("Players"),
    Team_Won((Object)ChatColor.YELLOW + "The {colorcode}{color} " + (Object)ChatColor.YELLOW + "team has won this round!"),
    Team_NotAddedYet((Object)ChatColor.RED + "The {teamcolor}{team} " + (Object)ChatColor.RED + "team has not been added yet to the arena " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + "!"),
    ChangeTeam_Full((Object)ChatColor.GRAY + "The {colorcode}{color} " + (Object)ChatColor.GRAY + "team is already full!"),
    ChangeTeam_AlreadyInside((Object)ChatColor.GRAY + "You are already a member of the {colorcode}{color}" + (Object)ChatColor.GRAY + " team!"),
    ChangeTeam_Changed((Object)ChatColor.GRAY + "You are now playing in the {colorcode}{color} " + (Object)ChatColor.GRAY + "team"),
    Changed_Postitions((Object)ChatColor.GREEN + "The positions have been successfully changed!"),
    Changed_LobbyLocation((Object)ChatColor.GREEN + "The lobby position of the arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been successfully changed!"),
    Changed_TeamSpawn((Object)ChatColor.GREEN + "The spawn position of the team {colorcode}{color} " + (Object)ChatColor.GREEN + "has been successfully changed!"),
    Changed_ArenaWorld((Object)ChatColor.GREEN + "The world of the arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been changed to " + (Object)ChatColor.DARK_GREEN + "{world}"),
    Changed_TopStatue_Location((Object)ChatColor.GREEN + "The coordinates by the topstatue " + (Object)ChatColor.DARK_GREEN + "{place} " + (Object)ChatColor.GREEN + "has been successfully changed!"),
    Spawn_Ranking((Object)ChatColor.GREEN + "A ranking statue at place " + (Object)ChatColor.DARK_GREEN + "{place}" + (Object)ChatColor.GREEN + " has been successfully spawned!"),
    Changed_GameDoneLocation((Object)ChatColor.GREEN + "The " + (Object)ChatColor.DARK_GREEN + "gamedonelocation " + (Object)ChatColor.GREEN + "has been successfully changed!"),
    Hologram_Remove((Object)ChatColor.GREEN + "The hologram with the ID " + (Object)ChatColor.DARK_GREEN + "{id} " + (Object)ChatColor.GREEN + "has been successfully removed!"),
    Hologram_Remove_IDNotExists((Object)ChatColor.RED + "There's no hologram with the ID " + (Object)ChatColor.DARK_RED + "{id}" + (Object)ChatColor.RED + "!"),
    Hologram_Add((Object)ChatColor.GREEN + "A new hologram with the ID " + (Object)ChatColor.DARK_GREEN + "{id}" + (Object)ChatColor.GREEN + " has been successfully added!"),
    Hologram_List("Holograms"),
    Stats_Rank("Rank: " + (Object)ChatColor.YELLOW),
    Stats_Won("Won: " + (Object)ChatColor.YELLOW),
    Stats_Lost("Lost: " + (Object)ChatColor.YELLOW),
    Stats_WL("W/L: " + (Object)ChatColor.YELLOW),
    Stats_RoundsPlayed("Rounds played: " + (Object)ChatColor.YELLOW),
    Stats_Kills("Kills: " + (Object)ChatColor.YELLOW),
    Stats_Deaths("Deaths: " + (Object)ChatColor.YELLOW),
    Stats_KD("K/D: " + (Object)ChatColor.YELLOW),
    Stats_BedsDestroyed("Beds destroyed: " + (Object)ChatColor.YELLOW),
    Stats_PlayTime("Time played: " + (Object)ChatColor.YELLOW),
    Destroyed_Bed((Object)ChatColor.WHITE + "The bed of team {teamcolor}{team} " + (Object)ChatColor.WHITE + "has been destroyed by " + (Object)ChatColor.GRAY + "{player}" + (Object)ChatColor.WHITE + "!"),
    Number_NotOne((Object)ChatColor.DARK_RED + "{number} " + (Object)ChatColor.RED + "is not a number!"),
    Stats_By("Stats by {player}"),
    NotWorking((Object)ChatColor.RED + "This won't work!"),
    Kicked_Everyone((Object)ChatColor.GREEN + "Everyone has been successfully kicked!"),
    Currently_NotWorking((Object)ChatColor.RED + "This is currently not working!"),
    GUI_Create_Title((Object)ChatColor.GOLD + "Create"),
    GUI_Setup_Title((Object)ChatColor.GOLD + "Setup"),
    GUI_Achievements_Title((Object)ChatColor.GOLD + "Achievements"),
    GUI_SelectTeam_Title((Object)ChatColor.GOLD + "Select team"),
    GUI_RunningGames_Title((Object)ChatColor.GOLD + "Running games"),
    GUI_Spectator_Teleporter((Object)ChatColor.YELLOW + "Teleport"),
    GUI_VoteArena_Title((Object)ChatColor.GOLD + "Vote for an arena"),
    GUI_VoteArena_Votes((Object)ChatColor.AQUA + "{number} " + (Object)ChatColor.DARK_AQUA + "votes"),
    RunningGames_NoOne((Object)ChatColor.RED + "No arena is currently running!"),
    Enabled_Arena((Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "is now " + (Object)ChatColor.DARK_GREEN + "enabled!"),
    Disabled_Arena((Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "is now " + (Object)ChatColor.DARK_RED + "disabled!"),
    Create_Arena((Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been successfully created!"),
    Remove_Arena((Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "has been sucessfully removed!"),
    Usage((Object)ChatColor.GOLD + "Usage: " + (Object)ChatColor.YELLOW + "{usage}"),
    Usage_ArenaCreate_Region((Object)ChatColor.GOLD + "Usage (Region):"),
    Usage_ArenaCreate_World((Object)ChatColor.GOLD + "Usage (World):"),
    Usage_ArenaCreate_MapVote((Object)ChatColor.GOLD + "Usage (Arena Voting):"),
    Updated_Sign("Sign has been successfully updated!"),
    Search_Update("Searching for an update..."),
    Offline_UpdateService("The update-service is probably offline!"),
    InWork_Job("This job is already in work!"),
    newUpdate("A new update has been found"),
    noNewUpdate("There is currently no update for this resource!"),
    Arena_HasToBeStopped((Object)ChatColor.RED + "The arena " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + " has to be stopped!"),
    Arena_JoinIssue_WorldDoesntExists((Object)ChatColor.RED + "The arena " + (Object)ChatColor.DARK_RED + "{arena" + (Object)ChatColor.RED + " has an issue: The world doesn't exists!"),
    Arena_JoinIssue_VotingEnabled((Object)ChatColor.RED + "Ooops: " + (Object)ChatColor.RED + "This is a normal arena but voting is enabled!"),
    Arena_JoinIssue_VotingDisabled((Object)ChatColor.RED + "Ooops: " + (Object)ChatColor.RED + "This is a voting arena but voting is disabled!"),
    FixProblemsBeforeEnabled((Object)ChatColor.RED + "Please fix these problems before enabling:"),
    Use_TrueOrFalse((Object)ChatColor.RED + "Use <true/false>!"),
    Reseting_Now((Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "is now getting regenerated!"),
    Reseting_Start_Failed((Object)ChatColor.RED + "Failed to start regeneration of the arena " + (Object)ChatColor.DARK_RED + "{arena}"),
    Reseting_Start_Failed_AlreadyRunning((Object)ChatColor.RED + "Failed to start the regeneration proccess of the arena " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + " as already an other one is running"),
    NotSameWorld_Arena((Object)ChatColor.RED + "You are not in the world of " + (Object)ChatColor.DARK_RED + "{arena} " + (Object)ChatColor.RED + "(" + (Object)ChatColor.DARK_RED + "{world}" + (Object)ChatColor.RED + ")!"),
    Problem_Arena_World((Object)ChatColor.RED + "There is a problem with the world of the arena " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + "!"),
    FixProblemWith((Object)ChatColor.YELLOW + "Fix this problem with: " + (Object)ChatColor.GOLD),
    Spawned_LobbyVillager((Object)ChatColor.DARK_GREEN + "lobbyvillager " + (Object)ChatColor.GREEN + "has been successfully spawned!"),
    Spawned_TeamSelectVillager((Object)ChatColor.DARK_GREEN + "teamselectvillager " + (Object)ChatColor.GREEN + "has been successfully spawned!"),
    Spawned_Dealer((Object)ChatColor.DARK_GREEN + "Dealer " + (Object)ChatColor.GREEN + "has been successfully spawned!"),
    Spawned_UpgradeDealer((Object)ChatColor.DARK_GREEN + "Upgrade Dealer " + (Object)ChatColor.GREEN + "has been successfully spawned!"),
    NotLooking_AtSign((Object)ChatColor.RED + "You're not looking at a sign!"),
    Sign_Lobby((Object)ChatColor.YELLOW + "Lobby"),
    Sign_Running((Object)ChatColor.GOLD + "Running"),
    Sign_Stopped((Object)ChatColor.RED + "Stopped"),
    Sign_Reseting((Object)ChatColor.GREEN + "Reseting"),
    Enabled("Enabled"),
    Disabled("Disabled"),
    NotAllowed_BedDestroy((Object)ChatColor.RED + "You're not allowed to destroy your own bed!"),
    NotAllowed_SelectColor((Object)ChatColor.RED + "You're not allowed to select the color {colorcode}{color}" + (Object)ChatColor.RED + "!"),
    Lobby_Item_Achievements((Object)ChatColor.GOLD + "Achievements"),
    Lobby_Item_ForceStart((Object)ChatColor.YELLOW + "Force start"),
    Lobby_Item_Leave((Object)ChatColor.RED + "Leave"),
    Lobby_Item_SelectTeam((Object)ChatColor.YELLOW + "Select team"),
    Lobby_Item_VoteArena((Object)ChatColor.YELLOW + "Vote for an arena"),
    Lobby_PrintMapInfo_ArenaName("Arena Name"),
    Lobby_PrintMapInfo_BuildBy("Build by"),
    Spectator_Item_Teleporter((Object)ChatColor.YELLOW + "Teleport"),
    Spectator_Item_ChangeSpeed((Object)ChatColor.YELLOW + "Change Speed"),
    Spectator_Item_Leave((Object)ChatColor.RED + "Leave"),
    Spectator_Item_NextRound((Object)ChatColor.GOLD + "Change Arena"),
    Trap((Object)ChatColor.YELLOW + "Someone walked over your trap!"),
    Teleporter((Object)ChatColor.YELLOW + "Teleporting you in a few seconds..."),
    Teleporter_Failed((Object)ChatColor.RED + "Teleportation has been stopped!"),
    Bridge_NotEnoughMaterials((Object)ChatColor.RED + "You need more materials of " + (Object)ChatColor.DARK_RED + "{material}" + (Object)ChatColor.RED + "!"),
    Give_Itemspawner((Object)ChatColor.GREEN + "Gave you " + (Object)ChatColor.DARK_GREEN + "{amount}" + (Object)ChatColor.GREEN + " of " + (Object)ChatColor.DARK_GREEN + "{itemspawner}"),
    Teleport_Success((Object)ChatColor.GREEN + "You were successfully teleported to the arena " + (Object)ChatColor.DARK_GREEN + "{arena}"),
    Lobby_Waiting((Object)ChatColor.GOLD + "Waiting for " + (Object)ChatColor.YELLOW + "{amount}" + (Object)ChatColor.GOLD + "..."),
    Lobby_Enough((Object)ChatColor.GOLD + "There're enough players in this round!"),
    Addons_Enabled("Enabled addons:"),
    Addons_Disabled("Disabled addons:"),
    Addon_Unkown((Object)ChatColor.RED + "Unkown addon " + (Object)ChatColor.DARK_RED + "{id}"),
    Addon_Enabled((Object)ChatColor.GREEN + "The addon " + (Object)ChatColor.DARK_GREEN + "{name}" + (Object)ChatColor.GREEN + " is now " + (Object)ChatColor.DARK_GREEN + "enabled" + (Object)ChatColor.GREEN + "!"),
    Addon_Disabled((Object)ChatColor.GREEN + "The addon " + (Object)ChatColor.DARK_GREEN + "{name}" + (Object)ChatColor.GREEN + " is now " + (Object)ChatColor.DARK_RED + "disabled" + (Object)ChatColor.GREEN + "!"),
    Addon_Research((Object)ChatColor.GREEN + "Found " + (Object)ChatColor.DARK_GREEN + "{number}" + (Object)ChatColor.GREEN + " new addons!"),
    Addon_Command_None((Object)ChatColor.RED + "This Add-On doesn't have any commands!"),
    Addon_Command_Unkown((Object)ChatColor.RED + "Unkown command " + (Object)ChatColor.DARK_RED + "{command}"),
    Addon_Command_List((Object)ChatColor.GOLD + "Commands for " + (Object)ChatColor.YELLOW + "{addon}"),
    AlreadyInside_Arena((Object)ChatColor.RED + "You're already inside an arena!"),
    Requires_WorldEdit((Object)ChatColor.DARK_RED + "WorldEdit " + (Object)ChatColor.RED + "is required for that!"),
    CrashMessage_MissingBed("Missing bed locations"),
    CrashMessage_MissingTeamSpawn("Missing team-spawnpoints"),
    CrashMessage_MissingLobbyLocation("Missing lobby location"),
    CrashMessage_MissingGameDoneLocation("Missing game-done-location"),
    CrashMessage_TooFewItemSpawners("Bronze itemspawner are missing"),
    ItemSpawner_List("Item Spawner:"),
    Commands_List("Commands:"),
    Regeneration_Done((Object)ChatColor.GREEN + "The arena " + (Object)ChatColor.DARK_GREEN + "{arena}" + (Object)ChatColor.GREEN + " has been successfully regenerated after " + (Object)ChatColor.DARK_GREEN + "{time} seconds" + (Object)ChatColor.GREEN + "!"),
    Regeneration_Stopped((Object)ChatColor.RED + "The regeneration of " + (Object)ChatColor.DARK_RED + "{arena}" + (Object)ChatColor.RED + " has been cancelled after " + (Object)ChatColor.DARK_RED + "{time} seconds"),
    WorldEdit_Changed((Object)ChatColor.GREEN + "Changed the position {id} to " + (Object)ChatColor.DARK_GREEN + "x{x} y{y} z{z}"),
    GetPositionAxe((Object)ChatColor.GREEN + "Gave you the " + (Object)ChatColor.DARK_GREEN + "position axe"),
    Tracker_TrackedPlayer((Object)ChatColor.GREEN + "This compass is now looking at the nearest tracked enemy."),
    Tracker_ReuseDelay((Object)ChatColor.RED + "Wait " + (Object)ChatColor.DARK_RED + "{time} seconds" + (Object)ChatColor.RED + " until you can use a tracker again!"),
    Tracker_Failed_OnlyOne((Object)ChatColor.DARK_RED + "Failed to track nearest enemy: " + (Object)ChatColor.RED + "You are the only player in this round!"),
    Spectator_Join((Object)ChatColor.GOLD + "You're now a spectator!"),
    Spectator_Leave((Object)ChatColor.GOLD + "You're not a spectator anymore."),
    Spectator_HowToQuit((Object)ChatColor.YELLOW + "Leave this round using the command " + (Object)ChatColor.GOLD + "/bw leave"),
    RecalculateStats_Sure1((Object)ChatColor.YELLOW + "Are you sure that you want to recalculate the stats?"),
    RecalculateStats_Sure2((Object)ChatColor.YELLOW + "The process will already be executed automatically and can cause lag!"),
    RecalculateStats_Sure3((Object)ChatColor.GOLD + "If so, then rewrite this command within a few seconds."),
    RecalculateStats_Done((Object)ChatColor.GREEN + "Done after " + (Object)ChatColor.DARK_GREEN + "{time} seconds" + (Object)ChatColor.GREEN + "."),
    EndLobby_Counting((Object)ChatColor.GOLD + "Teleporting you in " + (Object)ChatColor.YELLOW + "{number}" + " seconds " + (Object)ChatColor.GOLD + "to the lobby"),
    EndLobby_Title("{teamcolor" + (Object)ChatColor.BOLD + "{team" + (Object)ChatColor.WHITE + " won this round!"),
    EndLobby_Title_Nobody((Object)ChatColor.RED + (Object)ChatColor.UNDERLINE + "Nobody" + (Object)ChatColor.WHITE + " won this round."),
    ArenaVoting_NoAvaibleArenas((Object)ChatColor.RED + "There's no arena left. Sorry!"),
    ArenaVoting_ArenasUpdated((Object)ChatColor.GOLD + "The arenas in the arena voting has been updated."),
    ArenaVoting_Recount_NoArenaToVote((Object)ChatColor.RED + "Reseting the countdown: There's no arena to vote for!"),
    ArenaVoting_End((Object)ChatColor.GOLD + "The following arena won the voting: " + (Object)ChatColor.YELLOW + "{arena}"),
    ArenaVoting_Recount_TooFewPlayers((Object)ChatColor.RED + "Need " + (Object)ChatColor.DARK_RED + "{number}" + (Object)ChatColor.RED + " more players to play on this arena!"),
    ArenaVoting_MinPlayers("Min. players:"),
    ForceStart_Already((Object)ChatColor.RED + "Game is already starting!"),
    Scoreboard_Lobby_ArenaName("Arena name:"),
    Scoreboard_Lobby_Players("Players:"),
    Bed_OnlyDestroyAbleWith_TNT((Object)ChatColor.RED + "You can only destroy this bed with tnt!"),
    ItemSpawner_Hologram_Title("{spawnercolor}{spawner} " + (Object)ChatColor.WHITE + "spawning in " + (Object)ChatColor.GRAY + "{time}" + (Object)ChatColor.WHITE + " seconds"),
    MaxPlayers("Max. players"),
    Shop_D_HyPixel_Avaible((Object)ChatColor.DARK_GRAY + "Available:"),
    Shop_D_HyPixel_ClickToBrowse((Object)ChatColor.YELLOW + "Click to browse!"),
    Shop_D_HyPixel_Items((Object)ChatColor.DARK_GRAY + "Items:"),
    Shop_D_HyPixel_ClickToPurchase((Object)ChatColor.YELLOW + "Click to purchase!"),
    Shop_D_HyPixel_Cost((Object)ChatColor.GRAY + "Cost: " + (Object)ChatColor.WHITE + "{color}{amount} {type}"),
    Shop_D_HyPixel_GoBack((Object)ChatColor.GREEN + "Go Back"),
    Shop_D_HyPixel_TooExpensive((Object)ChatColor.RED + "You don't have enough {type}!"),
    Shop_D_HiveMC_ClickToView((Object)ChatColor.AQUA + "{icon} Click to view " + (Object)ChatColor.BOLD + "{item}"),
    Shop_D_HiveMC_GoBack((Object)ChatColor.RED + (Object)ChatColor.BOLD + "Go back"),
    Shop_D_HiveMC_ReturnToMenu((Object)ChatColor.GRAY + "Return to menu"),
    Shop_D_HiveMC_ClickToGoBack((Object)ChatColor.AQUA + "{icon} Click to go back"),
    Shop_D_HiveMC_ClickToBuy((Object)ChatColor.AQUA + "{icon} Click to buy"),
    Shop_D_HiveMC_Cost((Object)ChatColor.GOLD + "Cost"),
    Shop_D_Rewinside_ShopType_New("You are using the new and improved shop"),
    Shop_D_Rewinside_ShopType_Old("You are using the old shop"),
    Shop_D_Rewinside_ShopType_Switch("Click here to switch between the versions"),
    Shop_D_BergwerkLABS_CurrentPage((Object)ChatColor.AQUA + "Current page"),
    Shop_D_BergwerkLABS_ChangePage((Object)ChatColor.AQUA + "Page {page}"),
    Shop_D_BergwerkLABS_Buy((Object)ChatColor.GREEN + "Buy " + (Object)ChatColor.GRAY + (Object)ChatColor.ITALIC + "<Left click>"),
    Shop_D_BergwerkLABS_Buy_TooExpensive((Object)ChatColor.GRAY + "Too expensive!"),
    Shop_D_HyPixelV2_ClickToView((Object)ChatColor.YELLOW + "Click to view!"),
    Shop_D_HyPixelV2_Seperator_Categories((Object)ChatColor.DARK_GRAY + "\u2b06" + (Object)ChatColor.GRAY + " Categories"),
    Shop_D_HyPixelV2_Seperator_Items((Object)ChatColor.DARK_GRAY + "\u2b07" + (Object)ChatColor.GRAY + " Items"),
    ShopData_NotLoadedYet((Object)ChatColor.RED + "The shop is currently loading!"),
    Lobby_CountdownTitle_GoodLuck((Object)ChatColor.GOLD + "Good Luck!"),
    MiniShop_Title("{title}" + (Object)ChatColor.GRAY + " disappears in " + (Object)ChatColor.DARK_GRAY + "{time} seconds"),
    ArenaGUI_Back((Object)ChatColor.RED + "Back"),
    ArenaGUI_Page_Main("Main"),
    ArenaGUI_Page_Teams("Teams"),
    ArenaGUI_Page_Itemspawners("Itemspawners"),
    ArenaGUI_Page_Flags("Flags"),
    ArenaGUI_Page_Main_Configure((Object)ChatColor.YELLOW + "Configure"),
    ArenaGUI_Page_Main_SetLobby((Object)ChatColor.YELLOW + "Set lobby at your position"),
    ArenaGUI_Page_Main_Rename((Object)ChatColor.YELLOW + "Change name"),
    ArenaGUI_Page_Main_Enable((Object)ChatColor.YELLOW + "Set enabled"),
    ArenaGUI_Page_Main_Disable((Object)ChatColor.YELLOW + "Set disabled"),
    ArenaGUI_Page_Main_Regenerate((Object)ChatColor.YELLOW + "Force regeneration"),
    ArenaGUI_Page_Main_SaveBlocks((Object)ChatColor.YELLOW + "Save blocks/entities"),
    ArenaGUI_Page_Main_SetWorld((Object)ChatColor.YELLOW + "Change world to your world"),
    ArenaGUI_Page_Main_SetPosition((Object)ChatColor.YELLOW + "Change corners of arena"),
    ArenaGUI_Page_Main_Teleport((Object)ChatColor.YELLOW + "Teleport to the arena"),
    ArenaGUI_Page_Main_Info((Object)ChatColor.YELLOW + "View informations"),
    ArenaGUI_Page_Main_Enter((Object)ChatColor.YELLOW + "Enter the arena"),
    ArenaGUI_Page_Main_EnterSpectator((Object)ChatColor.YELLOW + "Enter the arena as a spectator"),
    ArenaGUI_Page_Main_SetSpectatorSpawn((Object)ChatColor.YELLOW + "Set the spawnpoint for spectators"),
    ArenaGUI_Page_Teams_SetSpawn((Object)ChatColor.YELLOW + "Set spawn at your position"),
    ArenaGUI_Page_Teams_GetBed((Object)ChatColor.YELLOW + "Get bed block"),
    ArenaGUI_Page_Itemspawners_Remove((Object)ChatColor.RED + "Remove itemspawners at your position"),
    ArenaGUI_Page_Itemspawners_Add((Object)ChatColor.YELLOW + "Add spawner at your position"),
    ArenaGUI_Page_Itemspawners_Get((Object)ChatColor.YELLOW + "Get {amount} of the items"),
    ArenaGUI_Page_Flags_Modify((Object)ChatColor.YELLOW + "Modify '" + (Object)ChatColor.GOLD + "{name" + (Object)ChatColor.YELLOW + "' ({type})"),
    Flag_Modfiy_Success((Object)ChatColor.GREEN + "Successfully changed " + (Object)ChatColor.DARK_GREEN + "{name} " + (Object)ChatColor.GREEN + "to " + (Object)ChatColor.DARK_GREEN + "{to}"),
    Flag_Modfiy_WrongType((Object)ChatColor.DARK_RED + "{value} " + (Object)ChatColor.RED + "is not an instance of " + (Object)ChatColor.DARK_RED + "{type}"),
    ArenaType_NotSupported((Object)ChatColor.RED + "This is not supported for the type " + (Object)ChatColor.DARK_RED + "{type}" + (Object)ChatColor.RED + " of the arena " + (Object)ChatColor.DARK_RED + "{name}"),
    Arena_AutoSavedBlocks((Object)ChatColor.YELLOW + "Blocks inside the arena were automatically saved!"),
    Ranking_Unranked("Unranked"),
    Clone_Arena((Object)ChatColor.GREEN + "Successfully cloned arena " + (Object)ChatColor.DARK_GREEN + "{arena1} " + (Object)ChatColor.GREEN + "to " + (Object)ChatColor.DARK_GREEN + "{arena2}"),
    Wait_AllArenasLoaded((Object)ChatColor.RED + "Wait until every arena has been successfully loaded!"),
    Voteable_Arenas((Object)ChatColor.GOLD + "Voteable arenas:"),
    Voteable_Arenas_More((Object)ChatColor.GRAY + "{amount} " + (Object)ChatColor.WHITE + "more arenas..."),
    Please_SaveArena((Object)ChatColor.GOLD + "Make sure to save your arena with: " + (Object)ChatColor.YELLOW + "/bw arena saveblocks <arena name>"),
    GetSetupItem((Object)ChatColor.GREEN + "Gave you the " + (Object)ChatColor.DARK_GREEN + "setup item"),
    Upgrade_Maximum((Object)ChatColor.RED + "Max"),
    Upgrade_Buy_Max((Object)ChatColor.RED + "You can't upgrade this anymore!"),
    OneTimePurchase((Object)ChatColor.RED + "You are allowed to buy this only once!"),
    ArenasGUI_Title((Object)ChatColor.AQUA + "Arenas"),
    Arena_CollidingArena1((Object)ChatColor.RED + "Please change the location of your arena."),
    Arena_CollidingArena2((Object)ChatColor.RED + "It's intersecting with the arena: " + (Object)ChatColor.DARK_RED + "{arena}"),
    Arena_CollidingArena3((Object)ChatColor.GOLD + "To change the location use the following command: " + (Object)ChatColor.YELLOW + "{command}"),
    Backup_List((Object)ChatColor.GOLD + "Backup Files:"),
    Backup_Create_Success((Object)ChatColor.GREEN + "Created a backup with the name " + (Object)ChatColor.DARK_GREEN + "{name" + (Object)ChatColor.GREEN + " after " + (Object)ChatColor.DARK_GREEN + "{time} " + (Object)ChatColor.GREEN + "seconds"),
    Backup_Create_Exists((Object)ChatColor.RED + "There's already a backup with the name " + (Object)ChatColor.DARK_RED + "{name}"),
    Backup_Delete_Success((Object)ChatColor.GREEN + "Deleted a backup with the name " + (Object)ChatColor.DARK_GREEN + "{name}"),
    Backup_Unkown((Object)ChatColor.RED + "Unkown backup " + (Object)ChatColor.DARK_RED + "{name}"),
    Backup_Restore_Success((Object)ChatColor.GREEN + "Successfully restored the backup " + (Object)ChatColor.DARK_GREEN + "{name" + " after " + (Object)ChatColor.DARK_GREEN + "{time}" + (Object)ChatColor.GREEN + " seconds"),
    Backup_Restore_Ask1((Object)ChatColor.GOLD + "Are you really sure that you want to restore the backup " + (Object)ChatColor.YELLOW + "{name}" + (Object)ChatColor.GOLD + "?"),
    Backup_Restore_Ask2((Object)ChatColor.GOLD + "If so, then please write the same command within the next 10 seconds"),
    Scoreboard_BedState_Alive((Object)ChatColor.GREEN + "Alive"),
    Scoreboard_BedState_Destroyed((Object)ChatColor.RED + "Destroyed"),
    Death_Spectate_RespawnIn((Object)ChatColor.GOLD + "Respawn in " + (Object)ChatColor.YELLOW + "{time} " + (Object)ChatColor.GOLD + "seconds"),
    Spectator_ChangeArena_NoneAvailable((Object)ChatColor.RED + "No free arena is available!"),
    Cages_Enable((Object)ChatColor.GREEN + "Cages for the arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "are now " + (Object)ChatColor.DARK_GREEN + "enabled!"),
    Cages_Disable((Object)ChatColor.GREEN + "Cages for the arena " + (Object)ChatColor.DARK_GREEN + "{arena} " + (Object)ChatColor.GREEN + "are now " + (Object)ChatColor.RED + "disabled!"),
    Cages_Set((Object)ChatColor.GREEN + "Changed location of the cage for arena " + (Object)ChatColor.DARK_GREEN + "{arena" + (Object)ChatColor.GREEN + " and team " + (Object)ChatColor.DARK_GREEN + "{team}"),
    Cages_Info_Title("Cages Data"),
    Cages_Info_Arena("Arena Name"),
    Cages_Info_IsEnabled("Is Enabled"),
    Cages_Info_TeamsLeft("Teams Left"),
    Cages_Info_TeamsSet("Teams Set"),
    Cages_Warning_Missing((Object)ChatColor.GOLD + "Warning: " + (Object)ChatColor.YELLOW + "Some cages weren't set yet!"),
    Shop_BuyGroup_Buy_LowerTier((Object)ChatColor.RED + "You already have a higher tier item"),
    SpectatorAdd_Failed_MissingLocation((Object)ChatColor.RED + "Failed to add you as a spectator, as there are no available points to teleport you at."),
    SaveBlocks_Fail_Players((Object)ChatColor.DARK_RED + "Failed to save the blocks: " + (Object)ChatColor.RED + "There are players in the world."),
    CreateArena_Fail_MainWorld((Object)ChatColor.RED + "It is not possible to create an arena with the type world in your main world!"),
    SaveBlocks_Start((Object)ChatColor.GOLD + "Started blocks saving operation for the arena " + (Object)ChatColor.YELLOW + "{arena}" + (Object)ChatColor.GOLD + ". Estimated time: " + (Object)ChatColor.YELLOW + "{time}"),
    SaveBlocks_Fail_AlreadyRunning((Object)ChatColor.DARK_RED + "Failed to save the blocks: " + (Object)ChatColor.RED + "Operation is already running."),
    SaveBlocks_Fail_NotStopped((Object)ChatColor.DARK_RED + "Failed to save the blocks: " + (Object)ChatColor.RED + "It's not stopped. (Stop it with /bw arena setenabled {arena} false)"),
    SaveBlocks_Fail_Unkown((Object)ChatColor.DARK_RED + "Failed to save the blocks: " + (Object)ChatColor.RED + "A weird error of the type '{type}' has occured"),
    Regeneration_Fail_SavingBlocks((Object)ChatColor.DARK_RED + "Failed to start regeneration: " + (Object)ChatColor.RED + "It's currently saving blocks."),
    DeathMessage_Killed_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "has been killed by " + (Object)ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + (Object)ChatColor.GRAY + "with " + (Object)ChatColor.RED + "\u2764{heartpercent}%"),
    DeathMessage_Killed_2("{teamcolor}{player} " + (Object)ChatColor.GRAY + "lost a fight against " + (Object)ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + (Object)ChatColor.GRAY + "with " + (Object)ChatColor.RED + "\u2764{heartpercent}%"),
    DeathMessage_Killed_3("{teamcolor}{player} " + (Object)ChatColor.GRAY + "was slain by " + (Object)ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + (Object)ChatColor.GRAY + "with " + (Object)ChatColor.RED + "\u2764{heartpercent}%"),
    DeathMessage_Void_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "fell out of the world"),
    DeathMessage_Void_2("{teamcolor}{player} " + (Object)ChatColor.GRAY + "fell down a bridge and is still falling"),
    DeathMessage_Explosion_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "exploded in dozents of pieces"),
    DeathMessage_Explosion_2("{teamcolor}{player} " + (Object)ChatColor.GRAY + "blew up"),
    DeathMessage_Fall_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "broke all of his legs"),
    DeathMessage_Fall_2("{teamcolor}{player} " + (Object)ChatColor.GRAY + "fell down from a high place"),
    DeathMessage_Fire_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "was burned to death"),
    DeathMessage_Fire_2("{teamcolor}{player} " + (Object)ChatColor.GRAY + "was burned alive"),
    DeathMessage_Default_1("{teamcolor}{player} " + (Object)ChatColor.GRAY + "died"),
    Spectator("Spectator"),
    Countdown_Stopped("Stopped"),
    ItemShop("Item shop"),
    UpgradeShop("Upgrade shop"),
    Motd_Loading("Loading..."),
    Shop_Price("Price: &7{number} {spawnercolor}{spawnertype}"),
    Shop_Page_Block("Block"),
    Shop_Page_Food("Food"),
    Shop_Page_Armor("Armor"),
    Shop_Page_Sword("Sword"),
    Shop_Page_Bow("Bow"),
    Shop_Page_Pickaxe("Pickaxe"),
    Shop_Page_Potion("Potion"),
    Shop_Page_Special("Special"),
    Shop_Page_Extra("Extra"),
    Shop_Item_HardenedClay("Hardened Clay"),
    Shop_Item_Endstone("Endstone"),
    Shop_Item_Chest("Chest"),
    Shop_Item_Enderchest("Enderchest"),
    Shop_Item_Ladder("Ladder"),
    Shop_Item_Web("Web"),
    Shop_Item_Apple("Apple"),
    Shop_Item_GrilledPork("Grilled pork"),
    Shop_Item_Cake("Cake"),
    Shop_Item_GoldenApple("Golden apple"),
    Shop_Item_LeatherHelmet("Leather helmet"),
    Shop_Item_LeatherLeggings("Leather leggings"),
    Shop_Item_LeatherBoots("Leather boots"),
    Shop_Item_ChainmailChestplateLVL1("Chainmail chestplate " + (Object)ChatColor.GRAY + "LVL 1"),
    Shop_Item_ChainmailChestplateLVL2("Chainmail chestplate " + (Object)ChatColor.GRAY + "LVL 2"),
    Shop_Item_ChainmailChestplateLVL3("Chainmail chestplate " + (Object)ChatColor.GRAY + "LVL 3"),
    Shop_Item_KnockbackStick("Knockback stick"),
    Shop_Item_SwordLVL1("Sword " + (Object)ChatColor.GRAY + "LVL 1"),
    Shop_Item_SwordLVL2("Sword " + (Object)ChatColor.GRAY + "LVL 2"),
    Shop_Item_SwordLVL3("Sword " + (Object)ChatColor.GRAY + "LVL 3"),
    Shop_Item_BowLVL1("Bow " + (Object)ChatColor.GRAY + "LVL 1"),
    Shop_Item_BowLVL2("Bow " + (Object)ChatColor.GRAY + "LVL 2"),
    Shop_Item_BowLVL3("Bow " + (Object)ChatColor.GRAY + "LVL 3"),
    Shop_Item_Arrow("Arrow"),
    Shop_Item_PickaxeLVL1("Pickaxe " + (Object)ChatColor.GRAY + "LVL 1"),
    Shop_Item_PickaxeLVL2("Pickaxe " + (Object)ChatColor.GRAY + "LVL 2"),
    Shop_Item_PickaxeLVL3("Pickaxe " + (Object)ChatColor.GRAY + "LVL 3"),
    Shop_Item_PotionSwiftness("Potion of swiftness"),
    Shop_Item_PotionRegeneration("Potion of regeneration"),
    Shop_Item_PotionHealing("Potion of healing"),
    Shop_Item_PotionStrength("Potion of strength"),
    Shop_Item_Enderpearl("Enderpearl"),
    Shop_Item_Teleporter("Teleporter"),
    Shop_Item_Minishop("Minishop"),
    Shop_Item_Rescueplatform("Rescue platform"),
    Shop_Item_Tntsheep("TNT sheep"),
    Shop_Item_MagnetShoes("Magnet Shoes"),
    Shop_Item_Trap("Trap"),
    Shop_Item_Bridge("Bridge"),
    Shop_Item_GuardDog("Guard Dog"),
    Shop_Item_Tracker("Tracker"),
    Shop_Item_FishingRod("Fisching Rod"),
    Shop_Item_Snowball("Snowball"),
    UpgradeShop_Name_SwordDamage("Sharpness"),
    UpgradeShop_Lore_SwordDamage("Increases the sword damage"),
    UpgradeShop_Name_Resistence("Armor Resistence"),
    UpgradeShop_Lore_Resistence("Increases the armor resistence"),
    UpgradeShop_Name_HealRange("Heal Station"),
    UpgradeShop_Lore_HealRange("Heals you in your base"),
    UpgradeShop_Name_SpawnerMultiplier("Spawner Multiplier"),
    UpgradeShop_Lore_SpawnerMultiplier("Increases the spawn rate in your base"),
    UpgradeShop_Name_EnemyMiningFatique("Mining Fatique"),
    UpgradeShop_Lore_EnemyMiningFatique("Decreases the mining speed for enemies entering your base"),
    UpgradeShop_Name_EnemyTrap("Trap"),
    UpgradeShop_Lore_EnemyTrap("Gives blind and slowness effect to the next player"),
    Achievement_get_title("New achievement!"),
    Achievements_name_rageQuit("Rage quit"),
    Achievements_name_winRound("Winner"),
    Achievements_name_loseRound("Looser"),
    Achievements_name_ownBedDestroyed("Unlucky"),
    Achievements_name_bestBow("OP"),
    Achievements_name_useRescuePlatform("That was close!"),
    Achievements_name_useEndepearl("Enderman"),
    Achievements_name_useMinishop("Shopping Mama"),
    Achievements_name_killSomeoneWithBow("Katniss"),
    Achievements_name_winIn3Minutes("Already over?!"),
    Achievements_name_killSomeoneWithHalfAHeart("Lucky strike"),
    Achievements_name_win100Rounds("Champion"),
    Achievements_name_useBridge("Bridge constructor"),
    Achievements_name_useGuardDog("Police guard"),
    Achievements_name_effectMagnetShoes("Magnetic force"),
    Achievements_name_useTeleporter("Beam me up, scotty!"),
    Achievements_name_useTNTSheep("Boom, boom, baby!"),
    Achievements_name_useTracker("I am going to find you. And kill you."),
    Achievements_name_placeTrap("Mine"),
    Achievements_name_runOverTrap("IT'S A TRAP!"),
    Achievements_name_rankingInTop3("E-Sports player"),
    Achievements_name_goodKD("Professional player"),
    Achievements_name_highPlayTime("#NoLife"),
    Achievements_name_writeGGAtEnd("GG"),
    Achievements_name_winWithoutBed("Can't Touch This"),
    Achievements_name_die10SecsAfterBedDestruction("You didn't!"),
    Achievements_name_optainEveryAchievement("Addicted"),
    Achievements_text_rageQuit("Leave a running round"),
    Achievements_text_winRound("Win at least one round"),
    Achievements_text_loseRound("Lose one round"),
    Achievements_text_ownBedDestroyed("If your bed is getting destroyed"),
    Achievements_text_bestBow("Build the best bow"),
    Achievements_text_useRescuePlatform("Use once a rescue platform-item"),
    Achievements_text_useEndepearl("Use once an enderpearl"),
    Achievements_text_useMinishop("Use once a minishop"),
    Achievements_text_killSomeoneWithBow("Kill someone with a bow"),
    Achievements_text_winIn3Minutes("Win a round in 3 minutes"),
    Achievements_text_killSomeoneWithHalfAHeart("Kill an enemy with half a heart"),
    Achievements_text_win100Rounds("Win 100 rounds"),
    Achievements_text_useBridge("Use once the bridge-item"),
    Achievements_text_useGuardDog("Breed once the guard dog"),
    Achievements_text_effectMagnetShoes("When your magnet shoes defended once a knockback"),
    Achievements_text_useTeleporter("Use once the teleporter item"),
    Achievements_text_useTNTSheep("Breed once a sheep with TNT on it by the tntsheep-item"),
    Achievements_text_useTracker("Use once the tracker"),
    Achievements_text_placeTrap("Build once a trap"),
    Achievements_text_runOverTrap("Fire a trap by running over it"),
    Achievements_text_rankingInTop3("Be in the Top 3 in the ranking"),
    Achievements_text_goodKD("Have a K/D that's higher as 5.0"),
    Achievements_text_highPlayTime("Play at least 5 hours"),
    Achievements_text_writeGGAtEnd("Write 'GG' at the end of a game"),
    Achievements_text_winWithoutBed("Win with your bed destroyed"),
    Achievements_text_die10SecsAfterBedDestruction("Die 10 seconds after your bed has been destroyed"),
    Achievements_text_optainEveryAchievement("Optain every achievement");
    
    private static MessagesPack pack;
    private final String defaultEnglish;

    static {
        pack = new MessagesPack();
    }

    private Language(String string2) {
        this.defaultEnglish = Language.chatColorToString(string2);
    }

    public String getMessage() {
        return this.getMessage(null, true);
    }

    public String getMessage(boolean bl2) {
        return this.getMessage(null, bl2);
    }

    public String getMessage(@Nullable CommandSender commandSender) {
        return this.getMessage(commandSender, true);
    }

    public String getMessage(@Nullable CommandSender commandSender, boolean bl2) {
        String string = null;
        if (commandSender != null && commandSender instanceof Player) {
            string = Version.a().g((Player)commandSender);
        }
        return this.finalizeGetMessage(this.getRawMessage(string), bl2);
    }

    public String getRawMessage(@Nullable String string) {
        return pack.a(string, this);
    }

    private String finalizeGetMessage(@Nullable String string, boolean bl2) {
        if (string == null) {
            return "";
        }
        string = Language.stringToChatColor(string);
        if (bl2 && ConfigValue.messages_with_prefix.contains((Object)this)) {
            return String.valueOf(Language.getPrefix()) + string;
        }
        return string;
    }

    public static String getPrefix() {
        return Language.getPrefix(null);
    }

    public static String getPrefix(CommandSender commandSender) {
        return String.valueOf(Prefix.getMessage(commandSender, false)) + " ";
    }

    public static String chatColorToString(String string) {
        for (ChatColor chatColor : ChatColor.values()) {
            string = string.replace("" + (Object)chatColor, "&" + chatColor.getChar());
        }
        return string;
    }

    public static String stringToChatColor(String string) {
        for (ChatColor chatColor : ChatColor.values()) {
            string = string.replace("&" + chatColor.getChar(), "" + (Object)chatColor);
        }
        return string;
    }

    public static Language getLanguage(String string) {
        for (Language language : Language.values()) {
            if (!language.name().equalsIgnoreCase(string)) continue;
            return language;
        }
        return null;
    }

    public static String replaceLanguageTranslations(String string) {
        return Language.replaceLanguageTranslations(null, string);
    }

    public static String replaceLanguageTranslations(@Nullable CommandSender commandSender, String string) {
        for (Language language : Language.values()) {
            string = string.replace("%" + language.name() + "%", language.getMessage(commandSender));
        }
        return string;
    }

    public static List<Language> getNotChangedMessagee() {
        ArrayList<Language> arrayList = new ArrayList<Language>(Arrays.asList(Language.values()));
        return arrayList;
    }

    public static void sendNotFoundArenaMessage(CommandSender commandSender, String string) {
        s.a(commandSender, de.marcely.bedwars.message.b.a(NotFound_Arena).a("arena", string));
        if (b.a(string)) {
            s.a(commandSender, de.marcely.bedwars.message.b.a(NotFound_Arena_Loading));
        }
    }

    public static MessagesPack getPack() {
        return pack;
    }

    public String getDefaultEnglish() {
        return this.defaultEnglish;
    }
}

