/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dR;
import de.marcely.bedwars.game.stats.c;

public class dN
extends dR {
    public dN() {
        super("bedsdestroyed");
    }

    @Override
    public String c(c c2) {
        return "" + c2.getBedsDestroyed();
    }
}

