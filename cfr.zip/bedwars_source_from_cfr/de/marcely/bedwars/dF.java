/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dI;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class dF
extends dI {
    public dF() {
        super("current-team");
    }

    @Override
    protected String a(Player player, Arena arena) {
        Team team = arena.a(player);
        return team != null ? team.a((CommandSender)player, true) : "";
    }
}

