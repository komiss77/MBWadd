/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cE;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.holographic.b;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.holographic.i;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class cJ
extends f<cF> {
    private boolean S;
    private boolean T;
    private boolean U;
    private String[] lines;
    private List<c<? extends b>> aa = new ArrayList<c<? extends b>>();

    public cJ(g g2, Location location) {
        super(g2, location);
    }

    @Override
    public i a() {
        return i.b;
    }

    @Override
    public void a(cF cF2) {
        this.S = cF2.S;
        this.T = cF2.T;
        this.U = cF2.U;
        this.a(cF2.lines);
    }

    @Deprecated
    @Override
    public float getHeight() {
        return 0.0f;
    }

    @Override
    public void teleport(Location location) {
        this.setLocation(location);
    }

    @Override
    protected void setLocation(Location location) {
        this.location = location;
        this.V();
    }

    @Deprecated
    @Override
    public void setCustomName(@Nullable String string) {
    }

    @Deprecated
    @Override
    protected void a(int n2, Object object) throws Exception {
    }

    @Override
    public void I(Player player) {
        for (c<? extends b> c2 : this.aa) {
            ((f)((Object)c2.a())).I(player);
        }
    }

    @Override
    public void T() {
        for (Player player : this.v()) {
            this.I(player);
        }
    }

    public void f(List<String> list) {
        this.a((String[])list.stream().toArray(n2 -> new String[n2]));
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void a(String ... arrstring) {
        if (arrstring == null) {
            this.lines = new String[0];
            for (c<? extends b> c4 : this.aa) {
                for (Player player : this.v()) {
                    ((f)((Object)c4.a())).H(player);
                }
            }
            this.aa.clear();
            return;
        }
        if (this.aa.size() == arrstring.length) {
            for (int n2 = 0; n2 < this.aa.size(); ++n2) {
                c<? extends b> c3 = this.aa.get(n2);
                ((f)((Object)c3.a())).setCustomName(arrstring[arrstring.length - n2 - 1]);
            }
            this.T();
            return;
        }
        for (c<? extends b> c2 : this.aa) {
            for (Player player : this.v()) {
                ((f)((Object)c2.a())).H(player);
            }
        }
        this.aa.clear();
        this.lines = arrstring;
        int n2 = 0;
        if (this.S) {
            for (String string : arrstring) {
                if (string.length() <= n2) continue;
                n2 = string.length();
            }
        }
        for (int i2 = arrstring.length - 1; i2 >= 0; --i2) {
            void var4_18;
            String string = arrstring[i2];
            if (string.isEmpty()) {
                String string2 = " ";
            }
            if (this.S) {
                void var4_17;
                int n3 = (n2 - var4_17.length()) / 2;
                for (int i3 = 0; i3 < n3; ++i3) {
                    String string3 = " " + (String)var4_18 + " ";
                }
            }
            if (Version.a().getVersionNumber() >= 8) {
                cE cE2 = new cE();
                cE2.name = var4_18;
                cE2.b = true;
                cE2.d = cE2.f = Boolean.valueOf(this.U);
                c<cI> c3 = c.a(cI.class, this.location.clone(), cE2);
                c3.a().b(this.a());
                this.aa.add(c3);
                for (Player player : this.v()) {
                    c3.a().G(player);
                }
            }
            this.V();
        }
    }

    private void V() {
        for (int i2 = this.aa.size() - 1; i2 >= 0; --i2) {
            c<? extends b> c2 = this.aa.get(i2);
            Location location = null;
            location = this.U ? this.location.clone().add(0.0, (double)i2 * 0.21 - (this.T ? 0.9875 : 0.0) + 1.1805, 0.0) : this.location.clone().add(0.0, (double)i2 * 0.21 - (this.T ? 1.975 : 0.0), 0.0);
            ((f)((Object)c2.a())).teleport(location);
        }
    }

    @Override
    protected void D(Player player) {
        for (c<? extends b> c2 : this.aa) {
            ((f)((Object)c2.a())).G(player);
        }
    }

    @Override
    protected void E(Player player) {
        for (c<? extends b> c2 : this.aa) {
            ((f)((Object)c2.a())).H(player);
        }
    }

    @Override
    public void F(Player player) {
        for (c<? extends b> c2 : this.aa) {
            ((f)((Object)c2.a())).F(player);
        }
    }

    public boolean M() {
        return this.S;
    }

    public boolean N() {
        return this.T;
    }

    public boolean isSmall() {
        return this.U;
    }

    public String[] getLines() {
        return this.lines;
    }

    public List<c<? extends b>> x() {
        return this.aa;
    }
}

