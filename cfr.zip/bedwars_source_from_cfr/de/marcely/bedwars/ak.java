/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.regeneration.RegionData;
import de.marcely.bedwars.util.MThread;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

@Deprecated
public class ak {
    public static void onEnable() {
    }

    public static void a(File file, RegionData regionData) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(regionData);
            objectOutputStream.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public static RegionData a(File file, Arena arena) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            RegionData regionData = (RegionData)objectInputStream.readObject();
            objectInputStream.close();
            return regionData;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static boolean d(String string) {
        File file = new File("plugins/MBedwars/data/arenablocks/" + string + ".yml");
        if (file.exists()) {
            file.delete();
            return true;
        }
        return false;
    }

    public static boolean exists(String string) {
        return new File("plugins/MBedwars/data/arenablocks/" + string + ".yml").exists();
    }

    public static void a(final a a2, final File file, final Arena arena) {
        new MThread(MThread.ThreadType.m, arena.getName()){

            @Override
            public void run() {
                a2.a(ak.a(file, arena));
            }
        }.start();
    }

    @Deprecated
    public static abstract class a {
        public abstract void a(RegionData var1);
    }

}

