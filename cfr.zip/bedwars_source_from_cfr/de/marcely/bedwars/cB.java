/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.cC;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class cB {
    public static final List<cC> U = new ArrayList<cC>();
    public static final List<SpectatorItem> V = new ArrayList<SpectatorItem>();

    public static void init() {
        U.clear();
        for (b b2 : b.values()) {
            U.add(b2.a());
        }
    }

    public static void a(Player player, SpectateReason spectateReason) {
        s.M(player);
        for (SpectatorItem spectatorItem : V) {
            if (spectateReason == SpectateReason.DEATH && !spectatorItem.a().a(player, spectateReason)) continue;
            player.getInventory().setItem(spectatorItem.getSlot(), i.a(spectatorItem.getItem().clone(), spectatorItem.q()));
        }
    }

    @Nullable
    public static SpectatorItem a(int n2) {
        for (SpectatorItem spectatorItem : V) {
            if (spectatorItem.getSlot() != n2) continue;
            return spectatorItem;
        }
        return null;
    }

    @Nullable
    public static cC a(String string) {
        for (cC cC2 : U) {
            if (!cC2.getIdentifier().equalsIgnoreCase(string)) continue;
            return cC2;
        }
        return null;
    }
}

