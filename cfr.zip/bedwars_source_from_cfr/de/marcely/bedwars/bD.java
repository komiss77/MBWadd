/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.by;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.Random;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class bD
extends by {
    private BukkitTask d;

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        Player player = playerUseExtraItemEvent.getPlayer();
        Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        Location location = player.getLocation().clone();
        if (location.getY() < 0.0 || location.getY() >= (double)arena.getWorld().getMaxHeight()) {
            this.done();
            return;
        }
        final List<Block> list = arena.a(location.add(0.0, -2.0, 0.0), ConfigValue.rescueplatform_material, ConfigValue.rescueplatform_width);
        if (list.size() == 0) {
            this.done();
            return;
        }
        s.a(player, Achievement.g);
        Sound.EXTRAITEM_RESCUEPLATFORM_USE.play(player);
        this.L();
        if (ConfigValue.rescueplatform_autobreak_enabled) {
            this.d = new BukkitRunnable(){

                public void run() {
                    bD.this.c(list);
                }
            }.runTaskLater((Plugin)MBedwars.a, (long)(ConfigValue.rescueplatform_autobreak_time * 20));
        } else {
            this.done();
        }
    }

    @Override
    public void K() {
        if (this.d != null) {
            this.d.cancel();
        }
    }

    private void c(final List<Block> list) {
        this.d = new BukkitRunnable(){

            public void run() {
                if (list.size() == 0) {
                    bD.this.done();
                    return;
                }
                Block block = (Block)list.remove(s.RAND.nextInt(list.size()));
                if (block.getType() == ConfigValue.rescueplatform_material) {
                    block.setType(Material.AIR);
                    VarParticle.PARTICLE_COLOURED.play(block.getWorld(), block.getLocation().add(0.5, 0.5, 0.5), Color.GREEN);
                    Sound.EXTRAITEM_RESCUEPLATFORM_AUTOBREAK.play(block.getLocation());
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 5L, 5L);
    }

}

