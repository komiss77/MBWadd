/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerRespawnEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerRespawnEvent;

public class bd {
    public static void a(PlayerRespawnEvent playerRespawnEvent) {
        Player player = playerRespawnEvent.getPlayer();
        if (cA.E.containsKey((Object)player)) {
            Arena arena = cA.E.get((Object)player).getArena();
            if (arena.isInside(player.getLocation())) {
                playerRespawnEvent.setRespawnLocation(player.getLocation());
            } else {
                Location location = cA.a(arena);
                if (location != null) {
                    playerRespawnEvent.setRespawnLocation(location);
                } else {
                    s.a((CommandSender)player, b.a(Language.SpectatorAdd_Failed_MissingLocation));
                }
            }
        } else {
            Arena arena = s.a(player);
            if (arena != null) {
                arena.a(player, playerRespawnEvent);
            }
        }
    }
}

