/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.PacketType
 *  com.comphenix.protocol.PacketType$Play
 *  com.comphenix.protocol.PacketType$Play$Client
 *  com.comphenix.protocol.PacketType$Play$Server
 *  com.comphenix.protocol.ProtocolManager
 *  com.comphenix.protocol.events.ListenerPriority
 *  com.comphenix.protocol.events.PacketAdapter
 *  com.comphenix.protocol.events.PacketContainer
 *  com.comphenix.protocol.events.PacketEvent
 *  com.comphenix.protocol.events.PacketListener
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.cV;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.dZ;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ec
extends PacketAdapter
implements dZ {
    private final dY a;
    private boolean af = false;
    private boolean ae = false;

    public ec(dY dY2) {
        super((Plugin)MBedwars.a, ListenerPriority.NORMAL, ec.a());
        this.a = dY2;
    }

    private static PacketType[] a() {
        ArrayList<PacketType> arrayList = new ArrayList<PacketType>();
        arrayList.addAll(Arrays.asList(new PacketType[]{PacketType.Play.Client.USE_ENTITY, PacketType.Play.Client.TAB_COMPLETE, PacketType.Play.Server.UPDATE_TIME, PacketType.Play.Server.UPDATE_HEALTH, PacketType.Play.Server.ENTITY_METADATA, PacketType.Play.Server.MAP_CHUNK, PacketType.Play.Server.ENTITY, PacketType.Play.Server.ENTITY_TELEPORT, PacketType.Play.Server.ENTITY, PacketType.Play.Server.POSITION, PacketType.Play.Server.RESPAWN}));
        if (Version.a().getVersionNumber() <= 8) {
            arrayList.addAll(Arrays.asList(new PacketType[]{PacketType.Play.Server.MAP_CHUNK_BULK, PacketType.Play.Server.REL_ENTITY_MOVE}));
        }
        return (PacketType[])arrayList.stream().toArray(n2 -> new PacketType[n2]);
    }

    @Override
    public dY a() {
        return this.a;
    }

    @Override
    public boolean isInjected() {
        if (!this.af) {
            return false;
        }
        ProtocolManager protocolManager = s.b.get(cV.class).a;
        return protocolManager != null && !protocolManager.isClosed();
    }

    @Override
    public boolean inject() {
        ProtocolManager protocolManager = s.b.get(cV.class).a;
        if (this.af || protocolManager == null || protocolManager.isClosed()) {
            return false;
        }
        protocolManager.addPacketListener((PacketListener)this);
        this.af = true;
        return true;
    }

    @Override
    public boolean Y() {
        if (!this.isInjected()) {
            return false;
        }
        ProtocolManager protocolManager = s.b.get(cV.class).a;
        protocolManager.removePacketListener((PacketListener)this);
        this.af = false;
        return true;
    }

    public void onPacketReceiving(PacketEvent packetEvent) {
        Player player = packetEvent.getPlayer();
        if (player != this.a.getPlayer()) {
            return;
        }
        PacketType packetType = packetEvent.getPacketType();
        Object object = packetEvent.getPacket().getHandle();
        try {
            Method method;
            String[] arrstring;
            if (packetType == PacketType.Play.Client.USE_ENTITY) {
                Field field = NMSClass.H.getDeclaredField("a");
                field.setAccessible(true);
                int n2 = field.getInt(object);
                field = NMSClass.H.getDeclaredField("action");
                field.setAccessible(true);
                Object object2 = field.get(object);
                String string = (String)object2.getClass().getMethod("name", new Class[0]).invoke(object2, new Object[0]);
                if (string.equals("INTERACT")) {
                    this.a.d(n2);
                } else if (string.equals("ATTACK")) {
                    this.a.e(n2);
                }
            } else if (Version.a().getVersionNumber() <= 9 && packetType == PacketType.Play.Client.TAB_COMPLETE && (arrstring = this.a.c((String)(method = NMSClass.Q.getDeclaredMethod("a", new Class[0])).invoke(object, new Object[0]))) != null) {
                Object obj = NMSClass.P.getDeclaredConstructor(String[].class).newInstance(new Object[]{arrstring});
                Version.a().sendPacket(player, obj);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void onPacketSending(PacketEvent packetEvent) {
        Player player = packetEvent.getPlayer();
        if (player != this.a.getPlayer()) {
            return;
        }
        PacketType packetType = packetEvent.getPacketType();
        Object object = packetEvent.getPacket().getHandle();
        boolean bl2 = false;
        try {
            if (packetType == PacketType.Play.Server.UPDATE_TIME) {
                Field field = NMSClass.R.getDeclaredField("a");
                field.setAccessible(true);
                long l2 = (Long)field.get(object);
                field = NMSClass.R.getDeclaredField("b");
                field.setAccessible(true);
                long l3 = (Long)field.get(object);
                bl2 = this.a.a(l2, l3);
            } else if (packetType == PacketType.Play.Server.REL_ENTITY_MOVE || packetType == PacketType.Play.Server.REL_ENTITY_MOVE_LOOK) {
                int n2 = s.a(NMSClass.ab, "a").getInt(object);
                if (cA.a(n2)) {
                    s.a(NMSClass.ab, "c").set(object, (byte)0);
                }
            } else if (packetType == PacketType.Play.Server.ENTITY_TELEPORT) {
                int n3 = s.a(NMSClass.K, "a").getInt(object);
                if (cA.a(n3)) {
                    if (Version.a().getVersionNumber() >= 9) {
                        s.a(NMSClass.K, "c").setDouble(object, -20.0);
                    } else {
                        s.a(NMSClass.K, "c").setInt(object, (int)Math.floor(-640.0));
                    }
                }
            } else if (packetType == PacketType.Play.Server.UPDATE_HEALTH) {
                float f2 = ((Float)s.a(NMSClass.U, "a").get(object)).floatValue();
                int n4 = (Integer)s.a(NMSClass.U, "b").get(object);
                float f3 = ((Float)s.a(NMSClass.U, "c").get(object)).floatValue();
                bl2 = this.a.a(f2, n4, f3);
            } else if (packetType == PacketType.Play.Server.ENTITY_METADATA) {
                int n5 = (Integer)s.a(NMSClass.L, "a").get(object);
                if (n5 == this.a.getPlayer().getEntityId()) {
                    List list = (List)s.a(NMSClass.L, "b").get(object);
                    for (Object e2 : list) {
                        int n6 = -1;
                        Object object2 = null;
                        if (Version.a().getVersionNumber() >= 9) {
                            Object object3 = s.a(e2.getClass(), "a").get(e2);
                            n6 = s.a(object3.getClass(), "a").getInt(object3);
                            object2 = s.a(e2.getClass(), "b").get(e2);
                        } else {
                            n6 = s.a(e2.getClass(), "b").getInt(e2);
                            object2 = s.a(e2.getClass(), "c").get(e2);
                        }
                        if (Version.a().getVersionNumber() >= 14) {
                            if (n6 != 8) continue;
                            bl2 = this.a.b(((Float)object2).floatValue());
                            continue;
                        }
                        if (Version.a().getVersionNumber() >= 10) {
                            if (n6 != 7) continue;
                            bl2 = this.a.b(((Float)object2).floatValue());
                            continue;
                        }
                        if (n6 != 6) continue;
                        bl2 = this.a.b(((Float)object2).floatValue());
                    }
                }
            } else if (packetType == PacketType.Play.Server.ENTITY_EQUIPMENT) {
                int n7 = (Integer)s.a(NMSClass.E, "a").get(object);
                Object object4 = s.a(NMSClass.E, "b").get(object);
                Object object5 = s.a(NMSClass.E, "c").get(object);
                bl2 = this.a.a(n7, object4, object5);
            } else if (packetType == PacketType.Play.Server.MAP_CHUNK) {
                int n8 = (Integer)s.a(NMSClass.Y, "a").get(object);
                int n9 = (Integer)s.a(NMSClass.Y, "b").get(object);
                this.a.a(n8, n9, this.ae);
            } else if (packetType == PacketType.Play.Server.MAP_CHUNK_BULK) {
                int[] arrn = (int[])s.a(NMSClass.Z, "a").get(object);
                int[] arrn2 = (int[])s.a(NMSClass.Z, "b").get(object);
                for (int i2 = 0; i2 < arrn.length; ++i2) {
                    this.a.a(arrn[i2], arrn2[i2], this.ae);
                }
            } else if (packetType == PacketType.Play.Server.RESPAWN) {
                bl2 = this.a.Z();
                if (!bl2) {
                    this.ae = true;
                }
            } else if (packetType == PacketType.Play.Server.POSITION && this.ae) {
                this.ae = false;
                this.a.ad();
            }
            if (bl2) {
                packetEvent.setCancelled(true);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}

