/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerExpChangeEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cA;
import de.marcely.bedwars.cz;
import java.util.Map;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerExpChangeEvent;

public class aT {
    public static void a(PlayerExpChangeEvent playerExpChangeEvent) {
        if (cA.E.containsKey((Object)playerExpChangeEvent.getPlayer())) {
            playerExpChangeEvent.setAmount(0);
        }
    }
}

