/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.dy;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import java.util.List;
import org.bukkit.entity.Player;

public class dC
extends dy {
    public dC(Arena arena) {
        super(arena, "teams");
    }

    @Override
    public String e(Player player) {
        return "" + this.arena.a().r().size();
    }
}

