/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.j;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class z
extends j {
    private Arena arena;
    private int c;
    private int e;

    public z(Arena arena, int n2, int n3) {
        this.arena = arena;
        this.c = n2;
        this.e = n3;
    }

    public Arena getArena() {
        return this.arena;
    }

    public int c() {
        return this.c;
    }

    public int d() {
        return this.e;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.o.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.c();
    }
}

