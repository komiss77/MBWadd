/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.Util;
import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cu
extends ct {
    public static cu a = new cu();

    public String b(c c2) {
        return Util.millisToName(c2.getPlayTime());
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

