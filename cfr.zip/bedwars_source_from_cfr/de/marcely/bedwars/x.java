/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.j;

public class x
extends j {
    private Arena arena;
    private int to;

    public x(Arena arena, int n2) {
        this.arena = arena;
        this.to = n2;
    }

    public Arena getArena() {
        return this.arena;
    }

    public int b() {
        return this.to;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.h.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.to;
    }
}

