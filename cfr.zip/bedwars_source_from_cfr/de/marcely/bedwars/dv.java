/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cS;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.dD;
import de.marcely.bedwars.du;
import de.marcely.bedwars.dw;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;

public class dv {
    private List<dD> ab = new ArrayList<dD>();

    public void ab() {
        for (dw dw2 : dw.values()) {
            if (dw2.R()) continue;
            try {
                this.a(dw2.getClazz().newInstance());
            }
            catch (IllegalAccessException | InstantiationException reflectiveOperationException) {
                reflectiveOperationException.printStackTrace();
            }
        }
    }

    public boolean a(dD dD2) {
        if (this.ab.contains(dD2)) {
            return false;
        }
        if (ConfigValue.placeholderapi_enabled && ConfigValue.placeholderapi_registercustom) {
            for (du du2 : s.b.a(du.class)) {
                du2.a(dD2);
            }
        }
        this.ab.add(dD2);
        return true;
    }

    public boolean b(dD dD2) {
        if (this.ab.contains(dD2)) {
            this.ab.remove(dD2);
            return true;
        }
        return false;
    }
}

