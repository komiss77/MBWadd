/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.f;
import de.marcely.bedwars.h;
import de.marcely.bedwars.i;

public abstract class j {
    public abstract String d();

    public a a() {
        String string = this.getClass().getPackage().getName();
        return a.valueOf(String.valueOf(string.split("\\.")[string.split("\\.").length - 1].toUpperCase()) + "_" + this.getClass().getName());
    }

    public void a(f f2) {
        h.b(new i(this, f2));
    }

    public void c(i i2) {
        h.b(i2);
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a(0);
        public static final /* enum */ a b = new a(1);
        public static final /* enum */ a c = new a(2);
        public static final /* enum */ a d = new a(3);
        public static final /* enum */ a e = new a(4);
        public static final /* enum */ a f = new a(5);
        public static final /* enum */ a g = new a(6);
        public static final /* enum */ a h = new a(7);
        public static final /* enum */ a i = new a(8);
        public static final /* enum */ a j = new a(9);
        public static final /* enum */ a k = new a(10);
        public static final /* enum */ a l = new a(11);
        public static final /* enum */ a m = new a(12);
        public static final /* enum */ a n = new a(13);
        public static final /* enum */ a o = new a(14);
        private int b;
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o};
        }

        private a(int n3) {
            this.b = n3;
        }

        public int getID() {
            return this.b;
        }

        public static a a(int n2) {
            for (a a2 : a.values()) {
                if (a2.getID() != n2) continue;
                return a2;
            }
            return null;
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

