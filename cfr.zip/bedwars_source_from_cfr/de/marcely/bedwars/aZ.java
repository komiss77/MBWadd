/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Effect
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.Map;
import java.util.Set;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class aZ {
    public static void a(PlayerMoveEvent playerMoveEvent) {
        Location location;
        Arena arena;
        Object object;
        Player player = playerMoveEvent.getPlayer();
        if (cA.E.containsKey((Object)player)) {
            object = playerMoveEvent.getTo();
            arena = cA.E.get((Object)player).getArena();
            if (!arena.isInside((Location)object)) {
                player.playEffect((Location)object, Effect.ENDER_SIGNAL, 5);
                player.setAllowFlight(true);
                if (arena.isInside(playerMoveEvent.getFrom())) {
                    location = player.getLocation().toVector().subtract(playerMoveEvent.getTo().toVector()).multiply(1.1);
                    s.a((Entity)player, (Vector)location);
                }
                Sound.SPECTATOR_BORDER.play(player);
                playerMoveEvent.setCancelled(true);
            }
        }
        if ((object = s.a(player)) != null) {
            if (((Arena)object).b() == ArenaStatus.f) {
                arena = player.getLocation().getBlock().getType();
                if (ConfigValue.diein_water && arena != null && arena == Material.STATIONARY_WATER) {
                    ((Arena)object).o(player);
                }
                location = playerMoveEvent.getPlayer().getLocation().getBlock().getLocation();
                Arena arena2 = arena;
                if (arena == Material.TRIPWIRE) {
                    arena2 = Material.STRING;
                }
                if (arena2 != null && arena2 == ConfigValue.trap_item.getType()) {
                    for (Map.Entry<String, Player> entry : ((Arena)object).n.entrySet()) {
                        XYZ xYZ = XYZ.ofString(entry.getKey());
                        if (!xYZ.equals(XYZ.valueOf(location)) || ((Arena)object).a(playerMoveEvent.getPlayer()) == ((Arena)object).a(entry.getValue())) continue;
                        Player player2 = playerMoveEvent.getPlayer();
                        Player player3 = entry.getValue();
                        s.a(player2, Achievement.u);
                        Sound.TRAP_CAUSE.play(player2);
                        player2.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 160, 1));
                        player2.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0));
                        s.a((CommandSender)player3, b.a(Language.Trap));
                        Sound.TRAP_OWNER.play(player3);
                        playerMoveEvent.setCancelled(true);
                        VarParticle.PARTICLE_SMOKE.play(location.getWorld(), location, 1);
                        location.getBlock().setType(Material.AIR);
                        break;
                    }
                }
                if (ConfigValue.diein_border_bottom && !player.isDead() && ((Arena)object).a() == RegenerationType.c && player.getLocation().getY() < ((Arena)object).getPosMin().getY()) {
                    player.setLastDamageCause(new EntityDamageEvent((Entity)player, EntityDamageEvent.DamageCause.VOID, 4));
                    ((Arena)object).o(player);
                }
            } else if (((Arena)object).b().F() && playerMoveEvent.getTo().getY() <= 0.0) {
                player.setFallDistance(0.0f);
                ((Arena)object).a(player, ((Arena)object).getLobby().clone().setDirection(player.getLocation().getDirection()));
                Sound.LOBBY_OUTOFMAP.play(player);
                player.playEffect(player.getLocation(), Effect.ENDER_SIGNAL, 0);
            }
        }
    }
}

