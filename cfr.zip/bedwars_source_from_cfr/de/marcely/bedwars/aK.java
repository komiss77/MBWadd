/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.event.inventory.InventoryType$SlotType
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.api.gui.Clickable;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class aK {
    public static void a(InventoryClickEvent inventoryClickEvent) {
        Object object;
        Player player = (Player)inventoryClickEvent.getWhoClicked();
        if (GUI.openInventories.containsKey((Object)player)) {
            object = (SimpleGUI)GUI.openInventories.get((Object)player);
            if (inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() == InventoryType.PLAYER && inventoryClickEvent.isShiftClick() && ((SimpleGUI)object).isCancellable()) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
            if ((inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() != InventoryType.PLAYER || inventoryClickEvent.getClick() == ClickType.DOUBLE_CLICK) && ((SimpleGUI)object).isCancellable()) {
                ItemStack itemStack;
                AnvilGUI anvilGUI;
                inventoryClickEvent.setCancelled(true);
                if (object instanceof Clickable) {
                    Clickable clickable = (Clickable)object;
                    GUIItem gUIItem = clickable.getItemAt(inventoryClickEvent.getSlot());
                    if (gUIItem != null) {
                        gUIItem.onClick(player, inventoryClickEvent.isLeftClick(), inventoryClickEvent.isShiftClick());
                    }
                } else if (object instanceof AnvilGUI && inventoryClickEvent.getSlot() == 2 && (anvilGUI = (AnvilGUI)object).getWroteListener() != null && (itemStack = inventoryClickEvent.getInventory().getItem(2)) != null) {
                    String string = i.b(itemStack);
                    if (Version.a().getVersionNumber() >= 13) {
                        itemStack.setType(Material.AIR);
                    }
                    if (string.length() >= 1) {
                        player.closeInventory();
                        anvilGUI.getWroteListener().run(i.b(itemStack));
                    }
                }
            }
        }
        if ((object = s.a(player)) != null) {
            if (((Arena)object).b().F()) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
            if (((Arena)object).b() == ArenaStatus.f && !ConfigValue.armor_interactable && inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() == InventoryType.PLAYER && inventoryClickEvent.getSlotType() == InventoryType.SlotType.ARMOR) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
        }
        if (cA.E.containsKey((Object)player)) {
            inventoryClickEvent.setCancelled(true);
        }
    }
}

