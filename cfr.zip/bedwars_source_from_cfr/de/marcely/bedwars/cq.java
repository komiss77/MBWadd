/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cq
extends ct {
    public static cq a = new cq();

    public String b(c c2) {
        return "" + c2.b();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

