/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.World
 *  org.bukkit.event.world.WorldUnloadEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.holographic.j;
import de.marcely.bedwars.util.s;
import org.bukkit.World;
import org.bukkit.event.world.WorldUnloadEvent;

public class bk {
    public static void a(WorldUnloadEvent worldUnloadEvent) {
        s.b.a(worldUnloadEvent.getWorld());
    }
}

