/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.Inventory
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.SimpleGUI;
import java.util.Map;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;

public class aM {
    public static void a(InventoryDragEvent inventoryDragEvent) {
        Player player = (Player)inventoryDragEvent.getWhoClicked();
        if (GUI.openInventories.containsKey((Object)player) && inventoryDragEvent.getInventory().getType() != InventoryType.PLAYER && ((SimpleGUI)GUI.openInventories.get((Object)player)).isCancellable()) {
            inventoryDragEvent.setCancelled(true);
        }
    }
}

