/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.holographic.d;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.holographic.i;
import de.marcely.bedwars.holographic.j;
import de.marcely.bedwars.util.s;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class c<T extends f<?>> {
    private final T a;
    private byte q = (byte)-1;
    private List<Player> X = new ArrayList<Player>(4);
    private final List<g> listeners = new ArrayList<g>(4);
    private j.a a;

    public c(T t2) {
        this.a = t2;
    }

    public World getWorld() {
        return this.getLocation().getWorld();
    }

    public Location getLocation() {
        return ((f)this.a).getLocation();
    }

    public int getEntityId() {
        return ((f)this.a).getEntityId();
    }

    public List<Player> v() {
        return ((f)this.a).v();
    }

    public void Q() {
        s.b.b(this);
    }

    public void remove() {
        s.b.c(this);
    }

    public void a(g g2) {
        this.listeners.add(g2);
    }

    public boolean a(g g2) {
        return this.listeners.remove(g2);
    }

    @Nullable
    public static <T extends f<?>> c<T> a(Class<T> class_, Location location, h h2) {
        try {
            i i2 = i.a(class_);
            if (i2.j != h2.getClass()) {
                throw new IllegalStateException(String.valueOf(class_.getName()) + " expects " + i2.j.getName() + " as parameter");
            }
            a a2 = new a();
            f f2 = (f)class_.getConstructor(g.class, Location.class).newInstance(new Object[]{a2, location});
            c<f> c2 = new c<f>(f2);
            a2.hologram = c2;
            c.a(f2, h2);
            return c2;
        }
        catch (InvocationTargetException invocationTargetException) {
            invocationTargetException.getTargetException().printStackTrace();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return null;
    }

    private static <T extends h> void a(f<T> f2, Object object) {
        f2.a((h)object);
    }

    public T a() {
        return this.a;
    }

    public byte a() {
        return this.q;
    }

    public void a(byte by2) {
        this.q = by2;
    }

    public List<Player> w() {
        return this.X;
    }

    public List<g> getListeners() {
        return this.listeners;
    }

    public j.a a() {
        return this.a;
    }

    public void a(j.a a2) {
        this.a = a2;
    }

    private static class a
    extends d {
        public c<?> hologram;

        @Override
        public List<Player> v() {
            return this.hologram.a != null ? c.a(this.hologram).Z : Arrays.asList(new Player[0]);
        }

        @Override
        public void R() {
            for (g g2 : this.hologram.listeners) {
                g2.R();
            }
        }
    }

}

