/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.holographic.e;

public interface b {
    public e a();
}

