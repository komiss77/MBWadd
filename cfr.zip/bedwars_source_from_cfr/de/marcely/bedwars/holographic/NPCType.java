/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.bq;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.d;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.UUID;

public class NPCType {
    private a a;
    private Object[] args;

    public NPCType(a a2) {
        if (a2 == a.d) {
            new bq("Please use the getNPC method!").printStackTrace();
            return;
        }
        this.a = a2;
    }

    private NPCType(a a2, Object[] arrobject) {
        this.a = a2;
        this.args = arrobject;
    }

    public a a() {
        return this.a;
    }

    public Object[] getArguments() {
        return this.args;
    }

    public static NPCType a(UUID uUID) {
        return new NPCType(a.d, new Object[]{uUID});
    }

    public static NPCType a(String string) {
        return new NPCType(a.c, new Object[]{cE.b(string)});
    }

    public static NPCType b(String string) {
        String string2 = null;
        for (int i2 = 0; i2 < string.length(); ++i2) {
            char c2 = string.charAt(i2);
            if (c2 != '[' && c2 != '{') continue;
            string2 = string.substring(0, i2);
            string = string.substring(i2 + 1, string.length() - 1);
            break;
        }
        a a2 = a.a(string2);
        if (a2 != null) {
            if (a2 == a.d) {
                String[] arrstring = string.split(",");
                if (arrstring.length == 1) {
                    if (arrstring[0].equalsIgnoreCase("self")) {
                        return new NPCType(a.e);
                    }
                    if (!s.i(arrstring[0])) {
                        d.b("Config: ENTITY TYPE - NPC: UUID argument is not valid!");
                        return null;
                    }
                    return NPCType.a(UUID.fromString(arrstring[0]));
                }
                d.b("Config: ENTITY TYPE - NPC: Max. args only 1!");
                return null;
            }
            if (a2 == a.c) {
                if (Version.a().getVersionNumber() <= 7) {
                    d.b("Config: ENTITY TYPE - ARMOR STAND: Armor Stands aren't supported for your version");
                    return null;
                }
                return NPCType.a("{" + string + "}");
            }
            return new NPCType(a2);
        }
        return null;
    }

    public String toString() {
        if (this.a == a.c) {
            return String.valueOf(this.a.name()) + this.args[0].toString();
        }
        if (this.a == a.e) {
            return "NPC[self]";
        }
        if (this.a == a.b) {
            return this.a.name();
        }
        String string = "";
        int n2 = 1;
        if (this.args != null) {
            for (Object object : this.args) {
                string = String.valueOf(string) + object.toString();
                if (n2 != this.args.length) {
                    string = String.valueOf(string) + ",";
                }
                ++n2;
            }
        }
        return !string.equals("") ? String.valueOf(this.a.name()) + "[" + string + "]" : this.a.name();
    }

    public static enum a {
        b,
        c,
        d,
        e;
        

        public static a a(String string) {
            for (a a2 : a.values()) {
                if (!a2.name().equalsIgnoreCase(string)) continue;
                return a2;
            }
            return null;
        }
    }

}

