/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.holographic;

public class h {
}

