/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import org.bukkit.entity.Player;

public interface a {
    public boolean a(float var1);

    public float getHealth();

    public void a(Player var1, float var2);
}

