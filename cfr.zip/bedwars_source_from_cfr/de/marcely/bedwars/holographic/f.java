/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.cF;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.holographic.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class f<T extends h> {
    protected g a;
    protected Location location;
    protected Location f;
    protected int entityId;
    protected Object g;
    private c<cJ> b;

    public f(g g2, Location location) {
        this.a = g2;
        this.location = location;
        this.f = location.clone();
    }

    public abstract i a();

    public abstract float getHeight();

    public abstract void a(T var1);

    protected abstract void D(Player var1);

    protected abstract void E(Player var1);

    public abstract void F(Player var1);

    public void G(Player player) {
        this.D(player);
        if (this.b != null) {
            this.b.a().G(player);
        }
    }

    public void H(Player player) {
        this.E(player);
        if (this.b != null) {
            this.b.a().H(player);
        }
    }

    protected List<Player> v() {
        return this.a.v();
    }

    protected void S() {
        for (Player player : this.v()) {
            this.H(player);
            this.G(player);
        }
    }

    public void teleport(Location location) {
        this.setLocation(location);
        for (Player player : this.v()) {
            this.F(player);
        }
    }

    protected void setLocation(Location location) {
        this.location = location;
        try {
            NMSClass.q.getMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE).invoke(this.g, location.getX(), location.getY(), location.getZ(), Float.valueOf(location.getYaw()), Float.valueOf(location.getPitch()));
        }
        catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
        }
        NMSClass.a(this.g, location.getYaw());
    }

    public void setCustomName(@Nullable String string) {
        if (this.b != null) {
            this.b.remove();
            this.b = null;
        }
        if (string != null) {
            cF cF2 = new cF();
            cF2.a(string.split("\\\\n"));
            this.b = c.a(cJ.class, this.location.clone().add(0.0, (double)(this.getHeight() - 0.18f), 0.0), cF2);
        }
    }

    protected void y(@Nullable String string) {
        try {
            if (string != null) {
                if (Version.a().getVersionNumber() >= 13) {
                    NMSClass.q.getMethod("setCustomName", NMSClass.W).invoke(this.g, s.c(string));
                } else {
                    NMSClass.q.getMethod("setCustomName", String.class).invoke(this.g, string);
                }
            }
            NMSClass.q.getMethod("setCustomNameVisible", Boolean.TYPE).invoke(this.g, string != null);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void a(int n2, Object object) throws Exception {
        Object object2 = NMSClass.q.getMethod("getDataWatcher", new Class[0]).invoke(this.g, new Object[0]);
        object2.getClass().getMethod("watch", Integer.TYPE, Object.class).invoke(object2, n2, object);
    }

    public void I(Player player) {
        try {
            if (Version.a().getVersionNumber() <= 7) {
                Version.a().b((Entity)NMSClass.q.getMethod("getBukkitEntity", new Class[0]).invoke(this.g, new Object[0]), true);
            }
            Field field = NMSClass.q.getDeclaredField("datawatcher");
            field.setAccessible(true);
            Object object = field.get(this.g);
            ? obj = NMSClass.L.getDeclaredConstructor(Integer.TYPE, NMSClass.N, Boolean.TYPE).newInstance(this.entityId, object, true);
            Version.a().sendPacket(player, obj);
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchFieldException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
        }
    }

    public void T() {
        for (Player player : this.v()) {
            this.I(player);
        }
    }

    public g a() {
        return this.a;
    }

    public void b(g g2) {
        this.a = g2;
    }

    public Location getLocation() {
        return this.location;
    }

    public Location a() {
        return this.f;
    }

    public int getEntityId() {
        return this.entityId;
    }
}

