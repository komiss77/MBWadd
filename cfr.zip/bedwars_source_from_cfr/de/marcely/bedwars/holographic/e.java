/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class e {
    private final f<?> a;
    private final Object[] a;

    public e(f<?> f2) {
        this.a = f2;
        this.a = new Object[a.size()];
    }

    public void a(a a2, ItemStack itemStack) {
        try {
            this.a[a2.ordinal()] = e.a(this.a.getEntityId(), a2, itemStack);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void send(Player player) {
        for (Object object : this.a) {
            if (object == null) continue;
            Version.a().sendPacket(player, object);
        }
    }

    @Nullable
    private static Object a(int n2, a a2, @Nullable ItemStack itemStack) {
        if (itemStack == null) {
            return null;
        }
        try {
            Object object = NMSClass.D.getMethod("asNMSCopy", ItemStack.class).invoke(null, new Object[]{itemStack});
            if (Version.a().getVersionNumber() < 9) {
                return NMSClass.E.getDeclaredConstructor(Integer.TYPE, Integer.TYPE, NMSClass.F).newInstance(n2, a2.ar, object);
            }
            return NMSClass.E.getDeclaredConstructor(Integer.TYPE, NMSClass.G, NMSClass.F).newInstance(n2, NMSClass.G.getMethod("valueOf", String.class).invoke(null, a2.b), object);
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a(4, "HEAD");
        public static final /* enum */ a b = new a(3, "CHEST");
        public static final /* enum */ a c = new a(2, "LEGS");
        public static final /* enum */ a d = new a(1, "FEET");
        public static final /* enum */ a e = new a(0, "MAINHAND");
        public static final /* enum */ a f = new a(5, "OFFHAND");
        public final int ar;
        public final String b;
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{a, b, c, d, e, f};
        }

        private a(int n3, String string2) {
            this.ar = n3;
            this.b = string2;
        }

        public static int size() {
            return Version.a().getVersionNumber() >= 9 ? 6 : 5;
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

