/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.cE;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.cG;
import de.marcely.bedwars.cH;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.cK;
import de.marcely.bedwars.cL;
import de.marcely.bedwars.cM;
import de.marcely.bedwars.cN;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.holographic.h;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class i
extends Enum<i> {
    public static final /* enum */ i a = new i(cI.class, cE.class);
    public static final /* enum */ i b = new i(cJ.class, cF.class);
    public static final /* enum */ i c = new i(cM.class, cF.class);
    public static final /* enum */ i d = new i(cK.class, cG.class);
    public static final /* enum */ i e = new i(cL.class, cG.class);
    public static final /* enum */ i f = new i(cN.class, cH.class);
    public final Class<? extends f<?>> i;
    public final Class<? extends h> j;
    private static final /* synthetic */ i[] a;

    static {
        a = new i[]{a, b, c, d, e, f};
    }

    private i(Class<? extends f<?>> class_, Class<? extends h> class_2) {
        this.i = class_;
        this.j = class_2;
    }

    @Nullable
    public static i a(Class<? extends f<?>> class_) {
        for (i i2 : i.values()) {
            if (i2.i != class_) continue;
            return i2;
        }
        return null;
    }

    public static i[] values() {
        i[] arri = a;
        int n2 = arri.length;
        i[] arri2 = new i[n2];
        System.arraycopy(arri, 0, arri2, 0, n2);
        return arri2;
    }

    public static i valueOf(String string) {
        return Enum.valueOf(i.class, string);
    }
}

