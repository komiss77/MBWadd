/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import java.util.List;
import org.bukkit.entity.Player;

public interface g {
    public List<Player> v();

    public void R();

    public void B(Player var1);

    public void C(Player var1);
}

