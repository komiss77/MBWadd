/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.holographic.g;
import java.util.List;
import org.bukkit.entity.Player;

public class d
implements g {
    @Override
    public List<Player> v() {
        return null;
    }

    @Override
    public void R() {
    }

    @Override
    public void B(Player player) {
    }

    @Override
    public void C(Player player) {
    }
}

