/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.holographic;

import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class j {
    private final short c = (short)5;
    private final Map<World, f> G = new HashMap<World, f>();
    private final BlockingQueue<e> a = new ArrayBlockingQueue<e>(32);
    private boolean isRunning = false;

    public void b(de.marcely.bedwars.holographic.c<?> c2) {
        this.a(new b(0, c2));
    }

    public void c(de.marcely.bedwars.holographic.c<?> c2) {
        this.a(new b(1, c2));
    }

    public void a(Player player, World world, int n2, int n3) {
        f f2 = this.G.get((Object)world);
        if (f2 == null) {
            return;
        }
        a a2 = f2.a(n2, n3);
        if (a2 == null) {
            return;
        }
        this.a(new c(2, player, world, n2, n3));
    }

    public void U() {
        this.a(new e(4));
    }

    public void a(World world) {
        if (!this.G.containsKey((Object)world)) {
            return;
        }
        this.a(new g(5, world));
    }

    public void J(Player player) {
        this.a(new d(3, player));
    }

    @Nullable
    public de.marcely.bedwars.holographic.c<?> a(World world, int n2) {
        f f2 = this.G.get((Object)world);
        if (f2 == null) {
            return null;
        }
        for (a a2 : f2.H.values()) {
            for (de.marcely.bedwars.holographic.c<?> c2 : a2.Y) {
                if (c2.getEntityId() != n2) continue;
                return c2;
            }
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(e var1_1) {
        if (this.isRunning()) ** GOTO lbl4
        return;
lbl-1000: // 1 sources:
        {
            s.sleep(10L);
lbl4: // 2 sources:
            ** while (this.a.remainingCapacity() == 0)
        }
lbl5: // 1 sources:
        this.a.add(var1_1);
    }

    public synchronized boolean run() {
        if (this.isRunning()) {
            return false;
        }
        this.isRunning = true;
        new MThread(MThread.ThreadType.t){

            @Override
            public void run() {
                while (j.this.isRunning()) {
                    s.sleep(200L);
                    try {
                        j.this.tick();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        }.start();
        return true;
    }

    public synchronized boolean stop() {
        if (!this.isRunning()) {
            return false;
        }
        this.isRunning = false;
        for (Map.Entry<World, f> entry : this.G.entrySet()) {
            for (Map.Entry<Long, a> entry2 : entry.getValue().H.entrySet()) {
                a a2 = entry2.getValue();
                for (de.marcely.bedwars.holographic.c<?> c2 : a2.Y) {
                    for (Player player : a2.Z) {
                        ((de.marcely.bedwars.holographic.f)c2.a()).H(player);
                    }
                }
            }
        }
        this.G.clear();
        return true;
    }

    private void tick() {
        Object object;
        Object object2;
        Object object3;
        Object object4;
        e e2;
        for (Map.Entry<World, f> entry : this.G.entrySet()) {
            object3 = entry.getKey();
            object2 = entry.getValue().H.entrySet().iterator();
            while (object2.hasNext()) {
                Map.Entry<Long, a> entry2 = object2.next();
                object4 = entry2.getValue();
                if (((a)object4).L()) {
                    object2.remove();
                    continue;
                }
                object = entry2.getKey();
                int n2 = de.marcely.bedwars.util.c.a((long)object);
                int n3 = de.marcely.bedwars.util.c.b((long)object);
                Iterator<de.marcely.bedwars.holographic.c<?>> iterator = ((a)object4).Y.iterator();
                List<Player> list = Version.a().b((World)object3, n2, n3);
                List<Player> list2 = null;
                ArrayList<Player> arrayList = null;
                if (list == null || list.size() == 0) {
                    if (((a)object4).Z.size() >= 1) {
                        arrayList = new ArrayList<Player>(((a)object4).Z);
                        ((a)object4).Z.clear();
                    }
                } else if (((a)object4).Z.size() == 0) {
                    list2 = list;
                    ((a)object4).Z.addAll(list);
                } else {
                    list2 = new ArrayList<Player>(list);
                    arrayList = new ArrayList<Player>(((a)object4).Z);
                    list2.removeAll(((a)object4).Z);
                    arrayList.removeAll(list);
                    ((a)object4).Z = list;
                }
                while (iterator.hasNext()) {
                    Location location;
                    long l2;
                    de.marcely.bedwars.holographic.c<?> c2 = iterator.next();
                    if (c2.getWorld() != object3) {
                        iterator.remove();
                        continue;
                    }
                    if (c2.a() >= 1 && list != null) {
                        for (Player player : list) {
                            if (c2.getLocation().distance(player.getLocation()) < (double)c2.a()) {
                                if (c2.w().contains((Object)player)) continue;
                                ((de.marcely.bedwars.holographic.f)c2.a()).H(player);
                                c2.w().add(player);
                                continue;
                            }
                            if (!c2.w().remove((Object)player)) continue;
                            ((de.marcely.bedwars.holographic.f)c2.a()).G(player);
                        }
                    }
                    if (arrayList != null) {
                        for (Player player : arrayList) {
                            ((de.marcely.bedwars.holographic.f)c2.a()).H(player);
                        }
                    }
                    if (list2 != null) {
                        for (Player player : list2) {
                            if (c2.w().contains((Object)player)) continue;
                            ((de.marcely.bedwars.holographic.f)c2.a()).G(player);
                        }
                    }
                    if ((l2 = de.marcely.bedwars.util.c.b((location = c2.getLocation()).getBlockX() >> 4, location.getBlockZ() >> 4)) == object) continue;
                    a a2 = s.a(entry.getValue().H, l2, new a());
                    iterator.remove();
                    a2.Y.add(c2);
                    c2.a(a2);
                }
            }
        }
        Object var1_10 = null;
        block14 : while ((e2 = (e)this.a.poll()) != null) {
            switch (e2.x) {
                case 0: {
                    b b2 = (b)e2;
                    object3 = ((de.marcely.bedwars.holographic.f)b2.hologram.a()).getLocation();
                    long l3 = de.marcely.bedwars.util.c.b(object3.getBlockX() >> 4, object3.getBlockZ() >> 4);
                    object4 = s.a(this.G, object3.getWorld(), new f());
                    a a3 = s.a(((f)object4).H, l3, new a());
                    b2.hologram.a(a3);
                    a3.Y.add(b2.hologram);
                    for (Player player : a3.Z) {
                        ((de.marcely.bedwars.holographic.f)b2.hologram.a()).G(player);
                    }
                    continue block14;
                }
                case 1: {
                    long l4;
                    a a4;
                    b b3 = (b)e2;
                    object3 = ((de.marcely.bedwars.holographic.f)b3.hologram.a()).getLocation();
                    object2 = this.G.get((Object)object3.getWorld());
                    b3.hologram.a((a)null);
                    if (object2 == null || (a4 = ((f)object2).H.get(l4 = ((f)object2).a(object3.getBlockX() >> 4, object3.getBlockZ() >> 4))) == null) continue block14;
                    a4.Y.remove(b3.hologram);
                    for (Player player : a4.Z) {
                        ((de.marcely.bedwars.holographic.f)b3.hologram.a()).H(player);
                    }
                    continue block14;
                }
                case 2: {
                    c c3 = (c)e2;
                    object3 = this.G.get((Object)c3.world);
                    if (object3 == null || (object2 = ((f)object3).a(c3.x, c3.z)) == null) continue block14;
                    for (de.marcely.bedwars.holographic.c c4 : ((a)object2).Y) {
                        ((de.marcely.bedwars.holographic.f)c4.a()).H(c3.player);
                    }
                    ((a)object2).Z.remove((Object)c3.player);
                    break;
                }
                case 3: {
                    d d2 = (d)e2;
                    object3 = d2.player;
                    object2 = this.G.get((Object)object3.getWorld());
                    if (object2 == null) continue block14;
                    for (a a5 : ((f)object2).H.values()) {
                        Player player;
                        if (!a5.Z.remove(object3)) continue;
                        player = a5.Y.iterator();
                        while (player.hasNext()) {
                            object = player.next();
                            ((de.marcely.bedwars.holographic.f)((de.marcely.bedwars.holographic.c)object).a()).H((Player)object3);
                        }
                    }
                    continue block14;
                }
                case 4: {
                    for (f f2 : this.G.values()) {
                        f2.U();
                    }
                    continue block14;
                }
                case 5: {
                    g g2 = (g)e2;
                    object3 = this.G.remove((Object)g2.world);
                    if (object3 == null) continue block14;
                    ((f)object3).U();
                }
            }
        }
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    public class a {
        public List<de.marcely.bedwars.holographic.c<?>> Y = new ArrayList(4);
        public List<Player> Z = new ArrayList<Player>();

        public j a() {
            return j.this;
        }

        public void U() {
            for (Player player : this.Z) {
                for (de.marcely.bedwars.holographic.c<?> c2 : this.Y) {
                    ((de.marcely.bedwars.holographic.f)c2.a()).H(player);
                }
            }
            this.Z.clear();
        }

        public boolean L() {
            return this.Y.size() == 0;
        }
    }

    private static class b
    extends e {
        public final de.marcely.bedwars.holographic.c<?> hologram;

        public b(byte by2, de.marcely.bedwars.holographic.c<?> c2) {
            super(by2);
            this.hologram = c2;
        }
    }

    private static class c
    extends d {
        public final World world;
        public final int x;
        public final int z;

        public c(byte by2, Player player, World world, int n2, int n3) {
            super(by2, player);
            this.world = world;
            this.x = n2;
            this.z = n3;
        }
    }

    private static class d
    extends e {
        public final Player player;

        public d(byte by2, Player player) {
            super(by2);
            this.player = player;
        }
    }

    private static class e {
        public static final byte r = 0;
        public static final byte s = 1;
        public static final byte t = 2;
        public static final byte u = 3;
        public static final byte v = 4;
        public static final byte w = 5;
        public final byte x;

        public e(byte by2) {
            this.x = by2;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public class f {
        public Map<Long, a> H = new HashMap<Long, a>(4);

        private long a(int n2, int n3) {
            return de.marcely.bedwars.util.c.b(n2, n3);
        }

        @Nullable
        public a a(int n2, int n3) {
            return this.H.get(this.a(n2, n3));
        }

        public void U() {
            for (a a2 : this.H.values()) {
                a2.U();
            }
        }
    }

    private static class g
    extends e {
        public final World world;

        public g(byte by2, World world) {
            super(by2);
            this.world = world;
        }
    }

}

