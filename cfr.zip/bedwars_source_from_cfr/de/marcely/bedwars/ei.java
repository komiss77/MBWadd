/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocket
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketAdapter
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketException
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFactory
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFrame
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketListener
 */
package de.marcely.bedwars;

import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocket;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketAdapter;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketException;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFactory;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFrame;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketListener;
import de.marcely.bedwars.el;
import de.marcely.bedwars.extlibrary.d;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class ei
extends WebSocketAdapter {
    private final WebSocket a;
    private final el a;
    private boolean aq = false;

    public ei(URI uRI) throws IOException {
        this.a = new WebSocketFactory().createSocket(uRI);
        this.a = new el(this);
        this.a.addListener((WebSocketListener)this);
    }

    public abstract void onConnect();

    public abstract void b(a var1);

    public abstract void a(d[] var1);

    public abstract void a(boolean var1, String var2);

    public void onConnected(WebSocket webSocket, Map<String, List<String>> map) {
        this.a.run();
    }

    public void onDisconnected(WebSocket webSocket, WebSocketFrame webSocketFrame, WebSocketFrame webSocketFrame2, boolean bl2) {
        if (this.aq) {
            return;
        }
        try {
            if (bl2) {
                this.b(a.g);
            } else {
                this.b(a.f);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.aq = true;
    }

    public void onConnectError(WebSocket webSocket, WebSocketException webSocketException) throws Exception {
        webSocketException.printStackTrace();
    }

    public void onError(WebSocket webSocket, WebSocketException webSocketException) throws Exception {
        webSocketException.printStackTrace();
    }

    public void onBinaryMessage(WebSocket webSocket, byte[] arrby) throws Exception {
        this.a.a(arrby);
    }

    public boolean isConnected() {
        return this.a.isOpen();
    }

    public void connect() {
        this.aq = false;
        try {
            this.a.connect();
        }
        catch (WebSocketException webSocketException) {
            this.b(a.h);
        }
    }

    public void a(a a2) {
        if (!this.aq) {
            try {
                this.b(a2);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        this.aq = true;
        this.a.a((a)null);
        this.a.disconnect();
    }

    public WebSocket a() {
        return this.a;
    }

    public el a() {
        return this.a;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a();
        public static final /* enum */ a b = new a();
        public static final /* enum */ a c = new a();
        public static final /* enum */ a d = new a();
        public static final /* enum */ a e = new a();
        public static final /* enum */ a f = new a();
        public static final /* enum */ a g = new a();
        public static final /* enum */ a h = new a();
        public static final /* enum */ a i = new a();
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{a, b, c, d, e, f, g, h, i};
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

