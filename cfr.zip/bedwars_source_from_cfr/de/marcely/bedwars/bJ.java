/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bI;
import de.marcely.bedwars.bK;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.util.f;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import javax.annotation.Nullable;

public class bJ {
    private static final byte VERSION = 0;
    private static final byte m = 0;
    private static final byte n = 5;
    private static final byte[] a = new byte[]{77, 97, 114, 99, 101, 108, 121, 115, 73, 110, 118, 83, 121, 115, 116, 101, 109};

    public static void a(bI bI2) throws Exception {
        bJ.a(bI2, new File(s.l, String.valueOf(bI2.getId().toString()) + ".mlyinv"));
    }

    public static void a(bI bI2, File file) throws Exception {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(a);
        fileOutputStream.write(0);
        BufferedWriteStream bufferedWriteStream = new BufferedWriteStream(new DeflaterOutputStream((OutputStream)fileOutputStream, new Deflater(5)));
        try {
            bJ.a(bI2, bufferedWriteStream);
        }
        catch (Exception exception) {
            bufferedWriteStream.close();
            throw exception;
        }
        bufferedWriteStream.close();
    }

    private static void a(bI bI2, BufferedWriteStream bufferedWriteStream) throws Exception {
        bufferedWriteStream.writeByte((byte)0);
        bufferedWriteStream.writeString(Version.a().a().name());
        bufferedWriteStream.writeString(bI2.getId().toString());
        bufferedWriteStream.writeBoolean(bI2.isIngame());
        bI2.a().write(bufferedWriteStream);
    }

    @Nullable
    public static bI a(bK bK2, UUID uUID) throws Exception {
        File file = new File(s.l, String.valueOf(uUID.toString()) + ".mlyinv");
        if (!file.exists()) {
            return null;
        }
        return bJ.a(bK2, file);
    }

    public static bI a(bK bK2, File file) throws Exception {
        if (!file.exists()) {
            throw new IllegalStateException("File does not exist");
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        BufferedReadStream bufferedReadStream = new BufferedReadStream(fileInputStream);
        if (!bufferedReadStream.readAndCheckMagic(a)) {
            bufferedReadStream.close();
            throw new IOException("Invalid magic");
        }
        byte by2 = bufferedReadStream.readByte();
        if (by2 < 0 || by2 > 0) {
            bufferedReadStream.close();
            throw new IOException("Unsupported file version (" + by2 + ")");
        }
        byte[] arrby = f.readFully(new InflaterInputStream(fileInputStream), -1, true);
        bufferedReadStream.close();
        return bJ.a(bK2, new BufferedReadStream(arrby));
    }

    private static bI a(bK bK2, BufferedReadStream bufferedReadStream) throws Exception {
        byte by2 = bufferedReadStream.readByte();
        if (by2 < 0 || by2 > 0) {
            throw new IOException("Unsupported version (" + by2 + ")");
        }
        bufferedReadStream.readString();
        UUID uUID = UUID.fromString(bufferedReadStream.readString());
        boolean bl2 = bufferedReadStream.readBoolean();
        d d2 = (d)d.a(bufferedReadStream);
        bI bI2 = new bI(bK2, uUID);
        bI2.f(bl2);
        bI2.a(d2);
        return bI2;
    }
}

