/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.j;

public class w
extends j {
    private Arena arena;
    private String i;

    public w(Arena arena, String string) {
        this.arena = arena;
        this.i = string;
    }

    public Arena getArena() {
        return this.arena;
    }

    public String getTo() {
        return this.i;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.k.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.i.replace("/", "&sKEYslash;");
    }
}

