/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bN;
import de.marcely.bedwars.bo;
import de.marcely.bedwars.util.f;
import de.marcely.bedwars.util.n;
import de.marcely.bedwars.versions.Version;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import org.bukkit.Location;

public class bO
extends bN {
    public static final byte VERSION = 1;
    private static final byte n = 5;
    private static final byte[] a = new byte[]{77, 97, 114, 99, 101, 108, 121, 115, 82, 103, 110, 83, 121, 115, 116, 101, 109};
    private final File file;

    public bO(File file, int n2, int n3, int n4) {
        super(n2, n3, n4);
        this.file = file;
    }

    public bO(File file, Version version, long l2, int n2, int n3, int n4) {
        super(n2, n3, n4);
        this.file = file;
    }

    public void a(Location location, final Runnable runnable, n<Long> n2) throws Exception {
        if (this.file.exists()) {
            this.file.delete();
        }
        this.file.createNewFile();
        FileOutputStream fileOutputStream = new FileOutputStream(this.file);
        fileOutputStream.write(a);
        fileOutputStream.write(1);
        final BufferedWriteStream bufferedWriteStream = new BufferedWriteStream(new DeflaterOutputStream((OutputStream)fileOutputStream, new Deflater(5)));
        super.a(bufferedWriteStream, location, new Runnable(){

            @Override
            public void run() {
                bufferedWriteStream.close();
                runnable.run();
            }
        }, n2);
    }

    @Override
    public void a(BufferedWriteStream bufferedWriteStream, Location location, Runnable runnable, n<Long> n2) {
        new bo().printStackTrace();
    }

    public static bN.b a(File file, Location location, boolean bl2) throws Exception {
        if (!file.exists()) {
            return new bN.b(bN.c.g, "?");
        }
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(file);
            BufferedReadStream bufferedReadStream = new BufferedReadStream(fileInputStream);
            if (!bufferedReadStream.readAndCheckMagic(a)) {
                bufferedReadStream.close();
                return new bN.b(bN.c.b, "?");
            }
            byte by2 = 0;
            by2 = bufferedReadStream.readByte();
            if (by2 < 0 || by2 > 1) {
                bufferedReadStream.close();
                return new bN.b(bN.c.h, "?");
            }
            BufferedReadStream bufferedReadStream2 = null;
            if (by2 == 0) {
                bufferedReadStream2 = new BufferedReadStream(fileInputStream);
            } else {
                byte[] arrby = f.readFully(new InflaterInputStream(fileInputStream), -1, true);
                bufferedReadStream2 = new BufferedReadStream(arrby);
            }
            return bN.a(bufferedReadStream2, location, bl2);
        }
        catch (Exception exception) {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
            throw exception;
        }
    }

    public File getFile() {
        return this.file;
    }

}

