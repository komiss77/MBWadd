/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import java.io.InputStream;

public class T {
    public static InputStream getResourceAsStream(String string) {
        return MBedwars.a.getResource("de/marcely/bedwars/config/language/" + string);
    }
}

