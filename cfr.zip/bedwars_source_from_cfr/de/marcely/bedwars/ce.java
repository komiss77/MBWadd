/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ch;
import de.marcely.bedwars.game.stats.c;

public class ce
extends ch {
    public static ce a = new ce();

    @Override
    protected String a(c c2) {
        return "" + c2.getDeaths();
    }
}

