/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

public class B {
    public static final byte VERSION = 0;
    public static final byte TYPE_PING = 0;
    public static final byte TYPE_PONG = 1;
    public static final byte b = 2;
    public static final byte c = 3;
    public static final byte TYPE_LOGIN = 16;
    public static final byte TYPE_LOGIN_REPLY = 17;
    public static final byte d = 18;
    public static final byte e = 32;
    public static final byte f = 33;
    public static final byte g = 34;
    public static final byte h = 35;
    public static final byte i = 48;
    public static final byte j = 49;
}

