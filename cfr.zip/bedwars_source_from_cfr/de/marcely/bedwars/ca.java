/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bZ;
import de.marcely.bedwars.game.arena.Arena;
import java.util.List;
import org.bukkit.entity.Player;

public class ca
extends bZ {
    public static ca a = new ca();

    @Override
    public bP.c a() {
        return bP.c.a;
    }

    @Override
    public String c(Arena arena) {
        return "" + arena.getPlayers().size();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.c((Arena)object);
    }
}

