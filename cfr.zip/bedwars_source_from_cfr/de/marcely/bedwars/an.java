/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.d;
import java.sql.ResultSet;
import java.sql.SQLException;

@Deprecated
public class an {
    public static String a(String string, String string2) {
        return "CREATE TABLE IF NOT EXISTS " + string + " (" + string2 + ")";
    }

    public static String a(String string, String string2, String string3, String string4) {
        return "ALTER TABLE " + string + " ADD " + string2 + " " + string3 + " NOT NULL DEFAULT '" + string4 + "'";
    }

    public static String a(String string, String string2, String string3) {
        return "INSERT INTO " + string + " (" + string2 + ") VALUES (" + string3 + ")";
    }

    public static String a(String string, String string2, String string3, String string4, String string5) {
        return "UPDATE " + string + " SET " + string4 + " = '" + string5 + "' WHERE " + string2 + " = '" + string3 + "'";
    }

    public static String b(String string, String string2, String string3) {
        return "SELECT COUNT(*) FROM " + string + " WHERE " + string2 + "='" + string3 + "'";
    }

    public static String b(String string, String string2) {
        return "SELECT " + string2 + " FROM " + string;
    }

    public static String c(String string, String string2, String string3) {
        return "SELECT * FROM " + string + " WHERE " + string2 + " = '" + string3 + "'";
    }

    public static boolean a(ResultSet resultSet) {
        try {
            resultSet.next();
            return resultSet.getInt(1) >= 1;
        }
        catch (SQLException sQLException) {
            d.a(sQLException);
            return false;
        }
    }
}

