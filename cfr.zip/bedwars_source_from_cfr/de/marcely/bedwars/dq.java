/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.inventivetalent.nicknamer.NickNamerPlugin
 *  org.inventivetalent.nicknamer.api.NickManager
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.dp;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.inventivetalent.nicknamer.NickNamerPlugin;
import org.inventivetalent.nicknamer.api.NickManager;

public class dq
extends dp {
    private NickManager a;

    @Override
    public cT a() {
        return cT.h;
    }

    @Override
    public void onEnable() {
        this.a = ((NickNamerPlugin)Bukkit.getPluginManager().getPlugin("NickNamer")).getAPI();
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String c(Player player) {
        if (this.a.isNicked(player.getUniqueId())) {
            return this.a.getNick(player.getUniqueId());
        }
        return null;
    }

    @Override
    public String d(Player player) {
        return null;
    }
}

