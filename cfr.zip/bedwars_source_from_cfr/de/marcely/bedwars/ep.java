/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ex;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.bedwars.ey;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;

public class ep
extends ex {
    public d b;
    public byte z;
    @Nullable
    public byte[] data;

    @Override
    public ey a() {
        return ey.h;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.b = new d();
        this.b.read(bufferedReadStream);
        this.z = bufferedReadStream.readByte();
        this.data = bufferedReadStream.readByteArray();
    }
}

