/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.util.org.apache.commons.io.FileUtils
 *  org.apache.commons.io.FileUtils
 */
package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.annotation.Nullable;
import net.minecraft.util.org.apache.commons.io.FileUtils;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class b {
    private final File file;
    private final String name;

    public b(String string) {
        this.file = new File(s.n, String.valueOf(string) + ".zip");
        this.name = string;
    }

    @Nullable
    public Long a() {
        if (this.file.exists()) {
            return null;
        }
        long l2 = System.currentTimeMillis();
        try {
            this.file.createNewFile();
            ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(this.file));
            zipOutputStream.setLevel(5);
            this.a(s.f, zipOutputStream);
            zipOutputStream.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        return System.currentTimeMillis() - l2;
    }

    private void a(File file, ZipOutputStream zipOutputStream) throws IOException {
        for (File file2 : file.listFiles()) {
            int n2;
            if (file2.isDirectory()) {
                if (file2.getAbsolutePath().equals(s.n.getAbsolutePath())) continue;
                this.a(file2, zipOutputStream);
                continue;
            }
            zipOutputStream.putNextEntry(new ZipEntry(s.a(file2)));
            FileInputStream fileInputStream = new FileInputStream(file2);
            byte[] arrby = new byte[1024];
            while ((n2 = fileInputStream.read(arrby)) > 0) {
                zipOutputStream.write(arrby, 0, n2);
            }
            fileInputStream.close();
        }
    }

    public boolean b() {
        try {
            this.delete(s.g);
            if (Version.a().getVersionNumber() >= 8) {
                org.apache.commons.io.FileUtils.copyDirectory((File)s.f, (File)s.g);
            } else {
                FileUtils.copyDirectory((File)s.f, (File)s.g);
            }
            for (File file : s.f.listFiles()) {
                if (file.getName().equals(s.h.getName())) continue;
                this.delete(file);
            }
            for (File file : s.h.listFiles()) {
                if (file.getName().equals(s.n.getName())) continue;
                this.delete(file);
            }
            ZipFile zipFile = new ZipFile(this.file);
            Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
            while (enumeration.hasMoreElements()) {
                ZipEntry zipEntry = enumeration.nextElement();
                File file = new File(s.f, zipEntry.getName());
                if (Version.a().getVersionNumber() >= 8) {
                    org.apache.commons.io.FileUtils.copyInputStreamToFile((InputStream)zipFile.getInputStream(zipEntry), (File)file);
                    continue;
                }
                FileUtils.copyInputStreamToFile((InputStream)zipFile.getInputStream(zipEntry), (File)file);
            }
            zipFile.close();
            return true;
        }
        catch (Exception exception) {
            return false;
        }
    }

    private void delete(File file) {
        if (!file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                this.delete(file2);
            }
        }
        file.delete();
    }

    public static b[] a() {
        ArrayList<b> arrayList = new ArrayList<b>();
        for (File file : s.n.listFiles()) {
            if (!file.getName().endsWith(".zip")) continue;
            arrayList.add(new b(file.getName().substring(0, file.getName().length() - 4)));
        }
        return arrayList.toArray(new b[arrayList.size()]);
    }

    public File getFile() {
        return this.file;
    }

    public String getName() {
        return this.name;
    }
}

