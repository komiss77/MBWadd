/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class b
extends Value<byte[]> {
    public b() {
        this(new byte[0]);
    }

    public b(byte[] arrby) {
        super(o.k, arrby);
    }

    @Override
    public String g() {
        return new String((byte[])this.value, StandardCharsets.UTF_8);
    }

    @Override
    public void t(String string) throws Exception {
        this.value = string.getBytes(StandardCharsets.UTF_8);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByteArray((byte[])this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readByteArray();
    }

    @Override
    public String toString() {
        String string = "";
        for (int i2 = 0; i2 < ((byte[])this.value).length; ++i2) {
            string = String.valueOf(string) + ((byte[])this.value)[i2];
            if (i2 + 1 >= ((byte[])this.value).length) continue;
            string = String.valueOf(string) + ", ";
        }
        return "[" + string + "]";
    }
}

