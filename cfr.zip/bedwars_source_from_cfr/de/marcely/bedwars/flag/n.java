/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class n
extends Value<String> {
    public n() {
        this("");
    }

    public n(String string) {
        super(o.h, string);
    }

    @Override
    public String g() {
        return (String)this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = string;
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString((String)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readString();
    }

    @Override
    public String toString() {
        return "\"" + (String)this.value + "\"";
    }
}

