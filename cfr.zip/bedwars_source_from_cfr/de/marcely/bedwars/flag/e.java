/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.br;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class e
extends Value<Collection<Value<?>>> {
    public e() {
        this(new LinkedList());
    }

    public e(Collection<Value<?>> collection) {
        super(o.j, collection);
    }

    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }

    @Override
    public void t(String string) throws Exception {
        new br().printStackTrace();
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((Collection)this.value).size());
        for (Value value : (Collection)this.value) {
            value.write(bufferedWriteStream);
        }
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        int n2 = bufferedReadStream.readUnsignedShort();
        this.value = new ArrayDeque(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            ((Collection)this.value).add(Value.a(bufferedReadStream));
        }
    }

    @Override
    public String toString() {
        String string = "";
        Iterator iterator = ((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            string = String.valueOf(string) + ((Value)iterator.next()).toString();
            if (!iterator.hasNext()) continue;
            string = String.valueOf(string) + ", ";
        }
        return "[" + string + "]";
    }

    public void a(Value<?> value) {
        ((Collection)this.value).add(value);
    }
}

