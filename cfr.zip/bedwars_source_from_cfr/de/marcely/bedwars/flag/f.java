/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class f
extends Value<Double> {
    public f() {
        this(0.0);
    }

    public f(Double d2) {
        super(o.g, d2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Double.parseDouble(string);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeDouble((Double)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readDouble();
    }
}

