/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.br;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class k
extends Value<long[]> {
    public k() {
        this(new long[0]);
    }

    public k(long[] arrl) {
        super(o.n, arrl);
    }

    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }

    @Override
    public void t(String string) throws Exception {
        new br().printStackTrace();
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((long[])this.value).length);
        for (int i2 = 0; i2 < ((long[])this.value).length; ++i2) {
            bufferedWriteStream.writeSignedLong(((long[])this.value)[i2]);
        }
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        int n2 = bufferedReadStream.readUnsignedShort();
        this.value = new long[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            ((long[])this.value)[i2] = bufferedReadStream.readSignedLong();
        }
    }

    @Override
    public String toString() {
        String string = "";
        for (int i2 = 0; i2 < ((long[])this.value).length; ++i2) {
            string = String.valueOf(string) + ((long[])this.value)[i2];
            if (i2 + 1 >= ((long[])this.value).length) continue;
            string = String.valueOf(string) + ", ";
        }
        return "[" + string + "]";
    }
}

