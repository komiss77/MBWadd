/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class c
extends Value<Byte> {
    public c() {
        this((byte)0);
    }

    public c(Byte by2) {
        super(o.b, by2);
    }

    @Override
    public String g() {
        return new String(new byte[]{(Byte)this.value});
    }

    @Override
    public void t(String string) throws Exception {
        this.value = string.getBytes()[0];
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte((Byte)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readByte();
    }
}

