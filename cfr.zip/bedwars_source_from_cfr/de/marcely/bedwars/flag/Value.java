/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;

public abstract class Value<T> {
    private o a;
    protected T value;

    public Value(o o2) {
        this(o2, null);
    }

    public Value(o o2, T t2) {
        this.a = o2;
        this.value = t2;
    }

    public abstract String g();

    public abstract void t(String var1) throws Exception;

    protected abstract void a(BufferedWriteStream var1);

    protected abstract void a(BufferedReadStream var1);

    public void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.a.getId());
        this.a(bufferedWriteStream);
    }

    @Nullable
    public static Value<?> a(BufferedReadStream bufferedReadStream) {
        byte by2 = bufferedReadStream.readByte();
        o o2 = o.a(by2);
        if (o2 == null) {
            return null;
        }
        Value<?> value = o2.a();
        value.a(bufferedReadStream);
        return value;
    }

    public String toString() {
        return this.value.toString();
    }

    public o a() {
        return this.a;
    }

    public T getValue() {
        return this.value;
    }

    public void setValue(T t2) {
        this.value = t2;
    }
}

