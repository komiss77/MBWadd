/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.a;
import de.marcely.bedwars.flag.b;
import de.marcely.bedwars.flag.c;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.flag.e;
import de.marcely.bedwars.flag.f;
import de.marcely.bedwars.flag.h;
import de.marcely.bedwars.flag.i;
import de.marcely.bedwars.flag.j;
import de.marcely.bedwars.flag.k;
import de.marcely.bedwars.flag.l;
import de.marcely.bedwars.flag.m;
import de.marcely.bedwars.flag.n;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class o
extends Enum<o> {
    public static final /* enum */ o b = new o(0);
    public static final /* enum */ o c = new o(1);
    public static final /* enum */ o d = new o(2);
    public static final /* enum */ o e = new o(3);
    public static final /* enum */ o f = new o(4);
    public static final /* enum */ o g = new o(5);
    public static final /* enum */ o h = new o(6);
    public static final /* enum */ o i = new o(7);
    public static final /* enum */ o j = new o(8);
    public static final /* enum */ o k = new o(9);
    public static final /* enum */ o l = new o(10);
    public static final /* enum */ o m = new o(11);
    public static final /* enum */ o n = new o(12);
    private byte id;
    private static /* synthetic */ int[] h;
    private static final /* synthetic */ o[] a;

    static {
        a = new o[]{b, c, d, e, f, g, h, i, j, k, l, m, n};
    }

    private o(byte by2) {
        this.id = by2;
    }

    public Value<?> a() {
        switch (o.h()[this.ordinal()]) {
            case 1: {
                return new c();
            }
            case 2: {
                return new m();
            }
            case 3: {
                return new j();
            }
            case 4: {
                return new l();
            }
            case 5: {
                return new h();
            }
            case 6: {
                return new f();
            }
            case 7: {
                return new n();
            }
            case 8: {
                return new a();
            }
            case 9: {
                return new e();
            }
            case 10: {
                return new b();
            }
            case 11: {
                return new i();
            }
            case 12: {
                return new d();
            }
            case 13: {
                return new k();
            }
        }
        return null;
    }

    @Nullable
    public static o a(byte by2) {
        for (o o2 : o.values()) {
            if (o2.id != by2) continue;
            return o2;
        }
        return null;
    }

    public byte getId() {
        return this.id;
    }

    public static o[] values() {
        o[] arro = a;
        int n2 = arro.length;
        o[] arro2 = new o[n2];
        System.arraycopy(arro, 0, arro2, 0, n2);
        return arro2;
    }

    public static o valueOf(String string) {
        return Enum.valueOf(o.class, string);
    }

    static /* synthetic */ int[] h() {
        if (h != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[o.values().length];
        try {
            arrn[o.k.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.l.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.n.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.m.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[o.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        h = arrn;
        return h;
    }
}

