/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class a
extends Value<Boolean> {
    public a() {
        this(false);
    }

    public a(Boolean bl2) {
        super(o.i, bl2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Boolean.valueOf(string);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeBoolean((Boolean)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readBoolean();
    }
}

