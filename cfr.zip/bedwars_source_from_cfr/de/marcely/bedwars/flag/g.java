/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class g {
    private final String key;
    Value<?> value;

    public g(String string, Value<?> value) {
        this.key = string;
        this.value = value;
    }

    public void write(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.key);
        this.value.write(bufferedWriteStream);
    }

    public <T extends Value<?>> T a(Class<T> class_) {
        return (T)this.getValue();
    }

    public String toString() {
        return "{Key: \"" + this.key + "\", ValueType: \"" + (Object)((Object)this.value.a()) + "\", Value: " + this.value.toString() + "}";
    }

    public static g a(BufferedReadStream bufferedReadStream) {
        return new g(bufferedReadStream.readString(), Value.a(bufferedReadStream));
    }

    public String getKey() {
        return this.key;
    }

    public Value<?> getValue() {
        return this.value;
    }

    public void b(Value<?> value) {
        this.value = value;
    }
}

