/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.br;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class i
extends Value<int[]> {
    public i() {
        this(new int[0]);
    }

    public i(int[] arrn) {
        super(o.l, arrn);
    }

    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }

    @Override
    public void t(String string) throws Exception {
        new br().printStackTrace();
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((int[])this.value).length);
        for (int i2 = 0; i2 < ((int[])this.value).length; ++i2) {
            bufferedWriteStream.writeSignedInt(((int[])this.value)[i2]);
        }
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        int n2 = bufferedReadStream.readUnsignedShort();
        this.value = new int[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            ((int[])this.value)[i2] = bufferedReadStream.readSignedInt();
        }
    }
}

