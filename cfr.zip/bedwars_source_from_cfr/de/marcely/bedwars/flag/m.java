/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class m
extends Value<Short> {
    public m() {
        this((short)0);
    }

    public m(Short s2) {
        super(o.c, s2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Short.parseShort(string);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedShort((Short)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readSignedShort();
    }
}

