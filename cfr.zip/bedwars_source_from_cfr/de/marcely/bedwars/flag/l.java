/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class l
extends Value<Long> {
    public l() {
        this(0L);
    }

    public l(Long l2) {
        super(o.e, l2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Long.parseLong(string);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedLong((Long)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readSignedLong();
    }
}

