/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.br;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.g;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import javax.annotation.Nullable;

public class d
extends Value<Collection<g>> {
    public d() {
        this(new LinkedList<g>());
    }

    public d(Collection<g> collection) {
        super(o.m, collection);
    }

    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }

    @Override
    public void t(String string) throws Exception {
        new br().printStackTrace();
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((Collection)this.value).size());
        for (g g2 : (Collection)this.value) {
            g2.write(bufferedWriteStream);
        }
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        int n2 = bufferedReadStream.readUnsignedShort();
        this.value = new ArrayDeque(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            ((Collection)this.value).add(g.a(bufferedReadStream));
        }
    }

    @Override
    public String toString() {
        String string = "";
        Iterator iterator = ((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            string = String.valueOf(string) + ((g)iterator.next()).toString();
            if (!iterator.hasNext()) continue;
            string = String.valueOf(string) + ", ";
        }
        return "[" + string + "]";
    }

    @Nullable
    public g a(String string) {
        for (g g2 : (Collection)this.value) {
            if (!g2.getKey().equals(string)) continue;
            return g2;
        }
        return null;
    }

    public boolean e(String string) {
        Iterator iterator = ((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            if (!((g)iterator.next()).getKey().equals(string)) continue;
            iterator.remove();
            return true;
        }
        return false;
    }

    public void a(g g2) {
        ((Collection)this.getValue()).add(g2);
    }

    public void clear() {
        ((Collection)this.getValue()).clear();
    }
}

