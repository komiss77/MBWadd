/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class j
extends Value<Integer> {
    public j() {
        this(0);
    }

    public j(Integer n2) {
        super(o.d, n2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Integer.parseInt(string);
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedInt((Integer)this.value);
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = bufferedReadStream.readSignedInt();
    }
}

