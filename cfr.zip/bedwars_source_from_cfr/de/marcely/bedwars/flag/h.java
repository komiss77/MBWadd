/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.flag;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.o;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class h
extends Value<Float> {
    public h() {
        this(Float.valueOf(0.0f));
    }

    public h(Float f2) {
        super(o.f, f2);
    }

    @Override
    public String g() {
        return "" + this.value;
    }

    @Override
    public void t(String string) throws Exception {
        this.value = Float.valueOf(Float.parseFloat(string));
    }

    @Override
    protected void a(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeFloat(((Float)this.value).floatValue());
    }

    @Override
    protected void a(BufferedReadStream bufferedReadStream) {
        this.value = Float.valueOf(bufferedReadStream.readFloat());
    }
}

