/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.ak;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.regeneration.RegionData;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import de.marcely.bedwars.game.regeneration.serializable.RBlockContainer;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

@Deprecated
public class al
extends de.marcely.bedwars.game.regeneration.a {
    private boolean running;
    private int regenerationSpeed;

    public al(Arena arena, @Nullable CommandSender commandSender) {
        super(RegenerationType.c, arena, commandSender);
    }

    @Override
    protected void a(File file) {
        ak.a(new ak.a(){

            @Override
            public void a(RegionData regionData) {
                if (regionData == null) {
                    al.this.b(false, "The file '/MBedwars/arenablocks/" + al.this.arena.getName() + ".yml' is corrupted!!");
                    return;
                }
                if (regionData.getBlocks().size() == 0) {
                    al.this.b(false, "The file '/MBedwars/arenablocks/" + al.this.arena.getName() + ".yml' is empty!!");
                    return;
                }
                List<b> list = b.a(regionData.getBlocks());
                al.a(al.this, true);
                if (Version.a().getVersionNumber() >= 9) {
                    new de.marcely.bedwars.al$1$1(true);
                }
                final a a2 = new a(ConfigValue.regeneration_threadsafe, list, regionData, 0, 0, -1, 0, (int)al.this.arena.getPosMin().getX(), (int)al.this.arena.getPosMin().getY(), (int)al.this.arena.getPosMin().getZ());
                if (ConfigValue.regeneration_threadsafe) {
                    new MThread(MThread.ThreadType.m, al.this.arena.getName()){

                        @Override
                        public void run() {
                            try {
                                while (al.this.running) {
                                    al.this.a(a2);
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                al.a(al.this, false);
                                new de.marcely.bedwars.al$1$2$1();
                            }
                        }

                    }.start();
                } else {
                    new BukkitRunnable(){

                        public void run() {
                            if (!al.this.running) {
                                this.cancel();
                                return;
                            }
                            try {
                                al.this.a(a2);
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                al.a(al.this, false);
                                al.this.g(false);
                            }
                        }
                    }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
                }
            }

        }, file, this.arena);
    }

    private void a(a a2) {
        if (a2.C == 0) {
            for (Entity entity : this.arena.getWorld().getEntities()) {
                if (entity.getType() == EntityType.PLAYER || entity.getType() == EntityType.DROPPED_ITEM || !this.arena.isInside(entity.getLocation())) continue;
                entity.remove();
            }
            ++a2.C;
            Version.a().a(this.arena.getWorld(), true);
        } else if (a2.C == 1) {
            for (int i2 = 0; i2 < 20000; ++i2) {
                ++a2.D;
                if ((double)a2.D > this.arena.getPosMax().getX()) {
                    a2.D = (int)this.arena.getPosMin().getX();
                    ++a2.E;
                }
                if ((double)a2.E > this.arena.getPosMax().getY()) {
                    a2.E = (int)this.arena.getPosMin().getY();
                    ++a2.F;
                }
                if ((double)a2.F > this.arena.getPosMax().getZ()) {
                    ++a2.C;
                    break;
                }
                Version.a().a(new Location(this.arena.getWorld(), (double)a2.D, (double)a2.E, (double)a2.F), Material.AIR, (byte)0);
            }
        } else if (a2.C == 2) {
            if (a2.G < a2.b.getBlocks().size()) {
                int n2 = a2.G + 20000;
                if (n2 > a2.b.getBlocks().size()) {
                    n2 = a2.b.getBlocks().size();
                }
                for (int i3 = a2.G; i3 < n2; ++i3) {
                    if (i3 % 50000 == 0) {
                        ++a2.H;
                    }
                    RBlock rBlock = a2.z.get((int)a2.H).blocks.get(i3 - a2.H * 50000);
                    try {
                        if (a2.q) {
                            Version.a().a(new Location(this.arena.getWorld(), (double)rBlock.getX(), (double)rBlock.getY(), (double)rBlock.getZ()), rBlock.getType(), rBlock.getData());
                            continue;
                        }
                        rBlock.a(this.arena.getWorld(), this.arena);
                        continue;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
                a2.G = n2;
            } else {
                ++a2.C;
                a2.G = 0;
                a2.H = -1;
                Version.a().a(this.arena.getWorld(), false);
            }
        } else if (a2.C == 3) {
            if (a2.G < a2.b.getBlocks().size()) {
                new de.marcely.bedwars.al$2(true, a2);
            } else {
                ++a2.C;
            }
        } else if (a2.C == 4) {
            int n3 = this.regenerationSpeed / 25000;
            if (n3 <= 0) {
                n3 = 1;
            }
            for (int i4 = 0; i4 < n3; ++i4) {
                int n4 = a2.I + i4;
                if (n4 >= a2.b.getEntities().size()) break;
                REntity rEntity = a2.b.getEntities().get(n4);
                new de.marcely.bedwars.al$3(rEntity);
            }
            a2.I += n3;
            ++a2.C;
        } else if (a2.C == 5) {
            if (Version.a().getVersionNumber() >= 8) {
                ++a2.C;
            } else {
                new de.marcely.bedwars.al$4(true, a2);
            }
        } else if (a2.C == 6) {
            this.running = false;
            new de.marcely.bedwars.al$5();
        }
    }

    @Override
    protected void s() {
        this.running = false;
    }

    @Override
    protected void a(File file, c c2) {
        ak.a(file, this.a());
        c2.a(c.a.a);
    }

    private RegionData a() {
        ArrayList<RBlock> arrayList = new ArrayList<RBlock>();
        ArrayList<REntity> arrayList2 = new ArrayList<REntity>();
        XYZ xYZ = this.arena.getPosMin();
        XYZ xYZ2 = this.arena.getPosMax();
        int n2 = (int)xYZ.getX();
        while ((double)n2 < xYZ2.getX()) {
            int n3 = (int)xYZ.getY();
            while ((double)n3 < xYZ2.getY()) {
                int n4 = (int)xYZ.getZ();
                while ((double)n4 < xYZ2.getZ()) {
                    Block block = this.arena.getWorld().getBlockAt(n2, n3, n4);
                    if (block.getType() != Material.AIR) {
                        arrayList.add(new RBlock(block));
                    }
                    ++n4;
                }
                ++n3;
            }
            ++n2;
        }
        for (Entity entity : this.arena.getWorld().getEntities()) {
            if (entity.getType() == EntityType.PLAYER || entity.getType() == EntityType.DROPPED_ITEM || !this.arena.isInside(entity.getLocation())) continue;
            arrayList2.add(new REntity(entity));
        }
        return new RegionData(arrayList, arrayList2);
    }

    static /* synthetic */ void a(al al2, boolean bl2) {
        al2.running = bl2;
    }

    private static class a {
        public final boolean q;
        public final List<b> z;
        public final RegionData b;
        public int C;
        public int G;
        public int H;
        public int I;
        public int D;
        public int E;
        public int F;

        public a(boolean bl2, List<b> list, RegionData regionData, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
            this.q = bl2;
            this.z = list;
            this.b = regionData;
            this.C = n2;
            this.G = n3;
            this.H = n4;
            this.I = n5;
            this.D = n6;
            this.E = n7;
            this.F = n8;
        }
    }

    public static class b {
        public static final int J = 50000;
        public final List<RBlock> blocks;

        public b(List<RBlock> list) {
            this.blocks = list;
        }

        public static List<b> a(List<RBlock> list) {
            ArrayList<b> arrayList = new ArrayList<b>();
            for (int i2 = 0; i2 <= list.size() / 50000; ++i2) {
                ArrayList<RBlock> arrayList2 = new ArrayList<RBlock>();
                int n2 = list.size() - i2 * 50000 > 50000 ? 50000 : list.size() - i2 * 50000;
                for (int i3 = 0; i3 < n2; ++i3) {
                    arrayList2.add(list.get(i2 * 50000 + i3));
                }
                arrayList.add(new b(arrayList2));
            }
            return arrayList;
        }
    }

}

