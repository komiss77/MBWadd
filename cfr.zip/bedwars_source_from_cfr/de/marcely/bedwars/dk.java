/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  me.blvckbytes.autonicker.NickSession
 *  me.blvckbytes.autonicker.api.NickAPI
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.dp;
import me.blvckbytes.autonicker.NickSession;
import me.blvckbytes.autonicker.api.NickAPI;
import org.bukkit.entity.Player;

public class dk
extends dp {
    @Override
    public cT a() {
        return cT.g;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String c(Player player) {
        NickSession nickSession = NickAPI.getSession((Player)player);
        if (nickSession.isNicked()) {
            return nickSession.current_nick;
        }
        return null;
    }

    @Override
    public String d(Player player) {
        NickSession nickSession = NickAPI.getSession((Player)player);
        if (nickSession.isNicked()) {
            return nickSession.real_name;
        }
        return null;
    }
}

