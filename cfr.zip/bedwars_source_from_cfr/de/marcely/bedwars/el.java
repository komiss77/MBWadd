/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.marcely.bedwars.com.neovisionaries.ws.client.WebSocket
 */
package de.marcely.bedwars;

import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocket;
import de.marcely.bedwars.eh;
import de.marcely.bedwars.ei;
import de.marcely.bedwars.ej;
import de.marcely.bedwars.ek;
import de.marcely.bedwars.em;
import de.marcely.bedwars.eo;
import de.marcely.bedwars.es;
import de.marcely.bedwars.ex;
import de.marcely.bedwars.extlibrary.d;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.HashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class el {
    private static final byte VERSION = 2;
    public static final String Y = "4.0.13";
    private static final String Z = "Q=7DTZPAd9Lvgx7R";
    private final ei a;
    private final ek a;
    private ej e;
    public Map<Byte, em> ae = new HashMap<Byte, em>();
    private byte y = (byte)-127;

    public el(ei ei2) {
        this.a = ei2;
        this.a = new eh(this);
        this.e = ej.b;
    }

    public void a(ei.a a2) {
        this.a(ej.b);
        if (a2 == null) {
            return;
        }
        this.a.a(a2);
    }

    public void run() {
        this.a(ej.c);
        es es2 = new es();
        es2.k = (byte)2;
        es2.aa = Y;
        es2.ab = Z;
        es2.B = 0;
        this.a(es2);
    }

    public void a(ej ej2) {
        this.e = ej2;
    }

    public void a(byte[] arrby) {
        try {
            ex ex2 = ex.a(new BufferedReadStream(arrby));
            if (ex2 != null) {
                this.a.a(ex2, this.e);
            } else {
                de.marcely.bedwars.d.n("Received unkown packet with the ID '" + arrby[0] + "'");
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(ex ex2) {
        BufferedWriteStream bufferedWriteStream = new BufferedWriteStream();
        try {
            ex2.write(bufferedWriteStream);
            this.a.a().sendBinary(bufferedWriteStream.toByteArray());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(d d2, em em2) {
        byte by2 = this.y;
        this.y = (byte)(by2 + 1);
        byte by3 = by2;
        this.ae.put(by3, em2);
        eo eo2 = new eo();
        eo2.a = d2.a;
        eo2.version = d2.version;
        eo2.e = d2.e;
        eo2.z = by3;
        this.a(eo2);
    }

    public ei a() {
        return this.a;
    }

    public ej a() {
        return this.e;
    }
}

