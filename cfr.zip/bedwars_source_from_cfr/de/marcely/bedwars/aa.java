/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ab;
import de.marcely.bedwars.ac;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import org.bukkit.entity.Player;

@Deprecated
public class aa {
    private List<a> t = new ArrayList<a>();
    private static HashMap<Player, c> c = new HashMap();
    private int entityId;
    private List<Player> players = new ArrayList<Player>();
    private b a = Version.a().getVersionNumber() >= 8 ? new ac() : new ab();

    public void a(a a2) {
        this.t.add(a2);
    }

    public void b(a a2) {
        this.t.remove(a2);
    }

    public void a(int n2) {
        this.entityId = n2;
    }

    protected void e(Player player) {
        if (this.players.contains((Object)player)) {
            return;
        }
        this.players.add(player);
        c c2 = null;
        boolean bl2 = false;
        if (!c.containsKey((Object)player)) {
            bl2 = true;
            c2 = new c();
            c2.player = player;
            c.put(player, c2);
        } else {
            c2 = c.get((Object)player);
        }
        c2.u.add(this);
        if (bl2) {
            this.a.a(c2);
        }
    }

    protected void f(Player player) {
        if (!this.players.contains((Object)player)) {
            return;
        }
        this.players.remove((Object)player);
        c c2 = c.get((Object)player);
        c2.u.remove(this);
        if (c2.u.size() == 0) {
            c.remove((Object)player);
            if (player.isOnline()) {
                try {
                    Method method = c2.d.getClass().getMethod("remove", NMSClass.J);
                    method.setAccessible(true);
                    method.invoke(c2.d, c2.e);
                }
                catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException exception) {
                    exception.printStackTrace();
                }
                catch (InvocationTargetException invocationTargetException) {
                    // empty catch block
                }
            }
            c.remove((Object)player);
        }
    }

    public static void onDisable() {
        for (Player player : c.keySet()) {
            c c2 = c.get((Object)player);
            try {
                Method method = c2.d.getClass().getMethod("remove", NMSClass.J);
                method.setAccessible(true);
                method.invoke(c2.d, c2.e);
            }
            catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException exception) {
                exception.printStackTrace();
            }
            catch (InvocationTargetException invocationTargetException) {
                // empty catch block
            }
        }
    }

    public List<a> i() {
        return this.t;
    }

    public int getEntityId() {
        return this.entityId;
    }

    public static interface a {
        public void g(Player var1);

        public void h(Player var1);
    }

    @Deprecated
    public static interface b {
        public void a(c var1);
    }

    @Deprecated
    public static class c {
        public Player player;
        public Object d;
        public Object e;
        public List<aa> u = new ArrayList<aa>();
    }

}

