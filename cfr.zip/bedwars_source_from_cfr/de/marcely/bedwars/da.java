/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  de.dytanic.cloudnet.bridge.CloudServer
 *  de.dytanic.cloudnet.lib.server.ServerState
 */
package de.marcely.bedwars;

import de.dytanic.cloudnet.bridge.CloudServer;
import de.dytanic.cloudnet.lib.server.ServerState;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.cZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.util.s;

public class da
extends cZ {
    private d a;
    private Arena arena;
    private static /* synthetic */ int[] l;

    @Override
    public cT a() {
        return cT.b;
    }

    @Override
    public void onEnable() {
        this.arena = s.b(ConfigValue.cloudsystem_arena);
        if (this.arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.b(this.arena, d.a.g);
        this.b(this.arena, d.a.e);
        this.a = new d(){

            @Override
            public void a(Arena arena, d.a a2) {
                da.this.b(arena, a2);
            }
        };
        this.arena.a(this.a);
    }

    private void b(Arena arena, d.a a2) {
        CloudServer cloudServer = CloudServer.getInstance();
        if (a2 == d.a.e && arena.b() == ArenaStatus.f) {
            cloudServer.changeToIngame();
            return;
        }
        cloudServer.setServerState(da.a(arena.b()));
        cloudServer.setMotd(ConfigValue.cloudsystem_extra.a(arena));
        cloudServer.update();
    }

    @Override
    public void onDisable() {
        if (this.arena != null) {
            this.arena.a(this.a);
        }
    }

    private static ServerState a(ArenaStatus arenaStatus) {
        switch (da.m()[arenaStatus.ordinal()]) {
            case 3: {
                return ServerState.INGAME;
            }
            case 2: {
                return ServerState.LOBBY;
            }
        }
        return ServerState.OFFLINE;
    }

    static /* synthetic */ int[] m() {
        if (l != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ArenaStatus.values().length];
        try {
            arrn[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        l = arrn;
        return l;
    }

}

