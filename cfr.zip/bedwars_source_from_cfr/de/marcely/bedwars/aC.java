/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.CreatureSpawnEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent$SpawnReason
 */
package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class aC {
    public static void a(CreatureSpawnEvent creatureSpawnEvent) {
        block7 : {
            block6 : {
                Arena arena = s.a(creatureSpawnEvent.getLocation());
                CreatureSpawnEvent.SpawnReason spawnReason = creatureSpawnEvent.getSpawnReason();
                if (spawnReason == CreatureSpawnEvent.SpawnReason.CUSTOM || spawnReason == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) {
                    if (arena != null && !ConfigValue.entityspawning_enabled) {
                        creatureSpawnEvent.setCancelled(false);
                    }
                } else if (arena != null && !ConfigValue.entityspawning_enabled) {
                    creatureSpawnEvent.setCancelled(true);
                }
                if (creatureSpawnEvent.getEntityType() != EntityType.VILLAGER) break block6;
                for (Player player : new ArrayList<Player>(s.aj)) {
                    if (player.getLocation().getX() != creatureSpawnEvent.getLocation().getX() || player.getLocation().getY() != creatureSpawnEvent.getLocation().getY() || player.getLocation().getZ() != creatureSpawnEvent.getLocation().getZ()) continue;
                    creatureSpawnEvent.setCancelled(false);
                    if (Version.a().getVersionNumber() > 8) continue;
                    s.aj.remove((Object)player);
                }
                break block7;
            }
            if (Version.a().getVersionNumber() < 8 || creatureSpawnEvent.getEntityType() != EntityType.ARMOR_STAND) break block7;
            for (Player player : new ArrayList<Player>(s.aj)) {
                if (player.getLocation().getX() != creatureSpawnEvent.getLocation().getX() || player.getLocation().getZ() != creatureSpawnEvent.getLocation().getZ()) continue;
                creatureSpawnEvent.setCancelled(false);
                if (Version.a().getVersionNumber() < 9) continue;
                s.aj.remove((Object)player);
            }
        }
    }
}

