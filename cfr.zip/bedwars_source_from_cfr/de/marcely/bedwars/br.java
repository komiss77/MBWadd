/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

public class br
extends Exception {
    private static final long serialVersionUID = 1L;

    public br() {
        this("This is not supported!");
    }

    public br(String string) {
        super(string);
    }
}

