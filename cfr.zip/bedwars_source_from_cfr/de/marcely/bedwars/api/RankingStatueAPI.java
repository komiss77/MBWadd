/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 */
package de.marcely.bedwars.api;

import java.util.UUID;
import javax.annotation.Nullable;
import org.bukkit.Location;

public interface RankingStatueAPI {
    public void setLocation(Location var1);

    public int getPlace();

    @Nullable
    public Location getLocation();

    @Nullable
    public UUID getCurrentHolderUUID();

    @Nullable
    public String getCurrentHolderName();

    public boolean exists();

    public boolean remove();

    public boolean remove(boolean var1);
}

