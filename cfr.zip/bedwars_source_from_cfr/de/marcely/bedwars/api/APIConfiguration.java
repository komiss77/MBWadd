/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.command.d;

public class APIConfiguration {
    public boolean teamsEnabled = true;
    public boolean bedsEnabled = true;
    public boolean itemspawnersEnabled = true;

    public void update() {
        MBedwars.a.refresh();
        ((d)MBedwars.a.a((String)"arena").a()).a.refresh();
    }
}

