/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.game.shop.upgrade.UpgradeType;

public class CustomUpgradeType
extends UpgradeType {
    public CustomUpgradeType(String string) {
        super(string, false);
    }
}

