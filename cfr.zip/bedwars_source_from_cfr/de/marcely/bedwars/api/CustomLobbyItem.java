/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.game.LobbyItem;
import org.bukkit.entity.Player;

public abstract class CustomLobbyItem
extends LobbyItem.a {
    public CustomLobbyItem(String string) {
        super(LobbyItem.LobbySpecialType.f, string);
    }

    public abstract void onUse(Player var1);
}

