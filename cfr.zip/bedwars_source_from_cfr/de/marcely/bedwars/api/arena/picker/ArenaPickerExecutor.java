/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.api.Arena;
import java.util.List;
import javax.annotation.Nullable;

public interface ArenaPickerExecutor {
    @Nullable
    public Arena run(List<Arena> var1, Arena var2);
}

