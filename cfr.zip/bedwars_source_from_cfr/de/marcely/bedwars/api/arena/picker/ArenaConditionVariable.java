/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;

public abstract class ArenaConditionVariable<T extends ArenaConditionVariableType<?>> {
    private final String name;
    private final Class<T> type;

    public ArenaConditionVariable(String string, Class<T> class_) {
        this.name = string;
        this.type = class_;
    }

    public abstract T getValue(Arena var1);

    public String getName() {
        return this.name;
    }

    public Class<T> getType() {
        return this.type;
    }
}

