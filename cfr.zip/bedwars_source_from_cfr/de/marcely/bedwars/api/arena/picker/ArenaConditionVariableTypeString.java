/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;

public class ArenaConditionVariableTypeString
extends ArenaConditionVariableType<String> {
    public ArenaConditionVariableTypeString(String string) {
        super(string);
    }

    @Override
    public byte getType() {
        return 1;
    }

    @Override
    public boolean equal(String string) {
        return ((String)this.entry).equals(string);
    }

    @Override
    public boolean notEqual(String string) {
        return !((String)this.entry).equals(string);
    }

    @Override
    public boolean greaterThan(String string) {
        throw new IllegalStateException("Operation not supported");
    }

    @Override
    public boolean lessThan(String string) {
        throw new IllegalStateException("Operation not supported");
    }

    @Override
    public boolean greaterThanOrEqual(String string) {
        throw new IllegalStateException("Operation not supported");
    }

    @Override
    public boolean lessThanOrEqual(String string) {
        throw new IllegalStateException("Operation not supported");
    }
}

