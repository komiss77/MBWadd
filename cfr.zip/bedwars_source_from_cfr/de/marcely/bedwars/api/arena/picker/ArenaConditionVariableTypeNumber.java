/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;

public class ArenaConditionVariableTypeNumber
extends ArenaConditionVariableType<Float> {
    public ArenaConditionVariableTypeNumber(float f2) {
        super(Float.valueOf(f2));
    }

    @Override
    public byte getType() {
        return 0;
    }

    @Override
    public boolean equal(Float f2) {
        return ((Float)this.entry).floatValue() == f2.floatValue();
    }

    @Override
    public boolean notEqual(Float f2) {
        return ((Float)this.entry).floatValue() != f2.floatValue();
    }

    @Override
    public boolean greaterThan(Float f2) {
        return ((Float)this.entry).floatValue() > f2.floatValue();
    }

    @Override
    public boolean lessThan(Float f2) {
        return ((Float)this.entry).floatValue() < f2.floatValue();
    }

    @Override
    public boolean greaterThanOrEqual(Float f2) {
        return ((Float)this.entry).floatValue() >= f2.floatValue();
    }

    @Override
    public boolean lessThanOrEqual(Float f2) {
        return ((Float)this.entry).floatValue() <= f2.floatValue();
    }
}

