/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

public enum ArenaStatus {
    Stopped(de.marcely.bedwars.game.arena.ArenaStatus.d),
    Lobby(de.marcely.bedwars.game.arena.ArenaStatus.e),
    Running(de.marcely.bedwars.game.arena.ArenaStatus.f),
    Reseting(de.marcely.bedwars.game.arena.ArenaStatus.g),
    EndLobby(de.marcely.bedwars.game.arena.ArenaStatus.h);
    
    private final de.marcely.bedwars.game.arena.ArenaStatus nms;

    private ArenaStatus(de.marcely.bedwars.game.arena.ArenaStatus arenaStatus) {
        this.nms = arenaStatus;
    }

    public static ArenaStatus fromNMS(de.marcely.bedwars.game.arena.ArenaStatus arenaStatus) {
        for (ArenaStatus arenaStatus2 : ArenaStatus.values()) {
            if (arenaStatus2.nms != arenaStatus) continue;
            return arenaStatus2;
        }
        return null;
    }

    public de.marcely.bedwars.game.arena.ArenaStatus getNms() {
        return this.nms;
    }
}

