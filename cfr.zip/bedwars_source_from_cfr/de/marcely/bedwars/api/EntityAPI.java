/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.Team;
import de.marcely.bedwars.game.IEntity;
import de.marcely.bedwars.game.location.XYZYPW;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;

public class EntityAPI {
    public void save() {
        s.al();
    }

    public void removeAll() {
        s.i(false);
    }

    public void summonDealer(Location location) {
        s.a(IEntity.a(location));
    }

    public void summonHub(Location location, Arena arena) {
        s.a(IEntity.a(location, (de.marcely.bedwars.game.arena.Arena)arena));
    }

    public void summonHub(Location location, int n2, int n3) {
        s.a(IEntity.a(location, n2, n3));
    }

    public void summonTeamSelect(Location location, Team team) {
        s.a(IEntity.a(location, team.getInternal()));
    }

    public void summonUpgradeDealer(Location location) {
        s.a(IEntity.b(location));
    }

    public List<Location> getDealers() {
        return this.find(IEntity.IEntityType.Dealer);
    }

    public List<Location> getHub() {
        return this.find(IEntity.IEntityType.Hub);
    }

    public List<Location> getTeamSelect() {
        return this.find(IEntity.IEntityType.TeamSelect);
    }

    public List<Location> getUpgradeDealer() {
        return this.find(IEntity.IEntityType.UpgradeDealer);
    }

    private List<Location> find(IEntity.IEntityType iEntityType) {
        ArrayList<Location> arrayList = new ArrayList<Location>();
        for (IEntity iEntity : (List)s.U.get((Object)iEntityType)) {
            if (iEntity.a().getWorld() == null) continue;
            arrayList.add(iEntity.a().toBukkit());
        }
        return arrayList;
    }

    public int remove(Location location) {
        return this.remove(location, true);
    }

    public int remove(Location location, boolean bl2) {
        int n2 = 0;
        for (IEntity.IEntityType iEntityType : IEntity.IEntityType.values()) {
            n2 += this.remove(location, iEntityType, false);
        }
        if (bl2) {
            this.save();
        }
        return n2;
    }

    public int remove(Location location, IEntity.IEntityType iEntityType) {
        return this.remove(location, iEntityType, true);
    }

    public int remove(Location location, IEntity.IEntityType iEntityType, boolean bl2) {
        XYZYPW xYZYPW = XYZYPW.valueOf(location);
        int n2 = 0;
        for (int i2 = ((List)s.U.get((Object)iEntityType)).size() - 1; i2 >= 0; --i2) {
            IEntity iEntity = (IEntity)((List)s.U.get((Object)iEntityType)).get(i2);
            if (!iEntity.a().equals(xYZYPW)) continue;
            ++n2;
            s.b(iEntity, bl2);
        }
        return n2;
    }
}

