/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package de.marcely.bedwars.api.event;

import de.marcely.bedwars.game.shop.ShopDesignData;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class PlayerOpenShopEvent
extends Event
implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player player;
    private ShopDesignData design;
    private boolean cancel = false;

    public PlayerOpenShopEvent(Player player, ShopDesignData shopDesignData) {
        this.player = player;
        this.design = shopDesignData;
    }

    public void setDesign(ShopDesignData shopDesignData) {
        this.design = shopDesignData;
    }

    public Player getPlayer() {
        return this.player;
    }

    public ShopDesignData getDesign() {
        return this.design;
    }

    public boolean isCancelled() {
        return this.cancel;
    }

    public void setCancelled(boolean bl2) {
        this.cancel = bl2;
    }

    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}

