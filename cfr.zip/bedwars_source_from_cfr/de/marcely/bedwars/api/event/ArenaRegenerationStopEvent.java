/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
package de.marcely.bedwars.api.event;

import de.marcely.bedwars.api.Arena;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class ArenaRegenerationStopEvent
extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private Arena arena;
    private CommandSender sender;

    public ArenaRegenerationStopEvent(Arena arena, CommandSender commandSender) {
        this.arena = arena;
    }

    public Arena getArena() {
        return this.arena;
    }

    @Nullable
    public CommandSender getSender() {
        return this.sender;
    }

    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}

