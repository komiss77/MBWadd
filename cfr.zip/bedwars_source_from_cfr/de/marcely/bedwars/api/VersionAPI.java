/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.util.b;
import de.marcely.bedwars.versions.Version;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class VersionAPI {
    public static ItemStack removeAttributes(ItemStack itemStack) {
        return Version.a().removeAttributes(itemStack);
    }

    public static ItemStack addGlow(ItemStack itemStack) {
        return Version.a().addGlow(itemStack);
    }

    public static void showSmallTitle(Player player, String string) {
        Version.a().b(string, player);
    }

    public static void showSmallTitle(Player player, String string, int n2) {
        Version.a().a(string, player, n2);
    }

    public static void showBigTitle(Player player, String string) {
        Version.a().c(string, player);
    }

    public static void showBigTitle(Player player, String string, int n2) {
        Version.a().b(string, player, n2);
    }

    public static void showTitle(Player player, String string, String string2) {
        Version.a().a(string, string2, player);
    }

    public static void showTitle(Player player, String string, String string2, int n2) {
        Version.a().a(string, string2, player, n2);
    }

    public static List<Entity> getNearbyEntities(Location location, double d2, double d3, double d4) {
        return b.getNearbyEntities(location, d2, d3, d4);
    }

    public static List<Player> getNearbyPlayers(Location location, int n2, int n3) {
        return b.a(location, n2, n3);
    }
}

