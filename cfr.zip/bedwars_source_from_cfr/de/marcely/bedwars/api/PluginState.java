/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.MBedwars;

public enum PluginState {
    Enabling(true),
    Running(true),
    StartFailed(false),
    Disabling(false),
    Disabled(false);
    
    private boolean taskable;

    private PluginState(boolean bl2) {
        this.taskable = bl2;
    }

    public MBedwars.PluginState getInternal() {
        for (MBedwars.PluginState pluginState : MBedwars.PluginState.values()) {
            if (pluginState.a() != this) continue;
            return pluginState;
        }
        return null;
    }

    public static PluginState fromInternal() {
        for (PluginState pluginState : PluginState.values()) {
            if (MBedwars.a().a() != pluginState) continue;
            return pluginState;
        }
        return null;
    }

    public boolean isTaskable() {
        return this.taskable;
    }
}

