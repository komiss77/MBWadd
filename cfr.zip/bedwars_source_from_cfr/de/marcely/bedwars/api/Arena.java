/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.AddPlayerFail;
import de.marcely.bedwars.api.ArenaStatus;
import de.marcely.bedwars.api.DropType;
import de.marcely.bedwars.api.KickReason;
import de.marcely.bedwars.api.RegenerationType;
import de.marcely.bedwars.api.Team;
import de.marcely.bedwars.api.TeamColors;
import de.marcely.bedwars.game.location.XYZ;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface Arena {
    public void addItemSpawner(DropType var1, XYZ var2);

    public void setWorld(World var1);

    public void setStatus(ArenaStatus var1);

    public void setStatus(ArenaStatus var1, boolean var2);

    public void setName(String var1);

    public void setLobby(Location var1);

    public void setAuthor(String var1);

    public void setTeamPlayers(int var1);

    public void setMinPlayers(int var1);

    @Nullable
    public World getWorld();

    public XYZ getPosMin();

    public XYZ getPosMax();

    public int getPerTeamPlayers();

    @Nullable
    public Location getLobby();

    public boolean hasLobby();

    @Nullable
    public ItemStack getIcon();

    public TeamColors GetTeamColors();

    public List<Player> getPlayers();

    public List<Player> getSpectators();

    @Nullable
    public Team GetPlayerTeam(Player var1);

    public int getTeamPlayers();

    public ArenaStatus GetStatus();

    public RegenerationType GetRegenerationType();

    public HashMap<XYZ, DropType> getItemSpawners();

    public String getAuthor();

    public int getMinPlayers();

    public boolean hasCustomName();

    public String getCustomName();

    public String getDisplayName();

    public String getName();

    public void setHasCustomName(boolean var1);

    public void setCustomName(String var1);

    public boolean isCurrentlyRegenerating();

    @Nullable
    public AddPlayerFail addPlayer(Player var1);

    @Nullable
    public AddPlayerFail addPlayer(Player var1, @Nullable Team var2);

    public boolean kickPlayer(Player var1);

    public boolean kickPlayer(Player var1, KickReason var2);

    public void kickAllPlayers();

    public void kickAllPlayers(KickReason var1);

    public void broadcast(String var1);

    public void broadcast(Sound var1);

    public long getGameStartTime();

    public boolean isInside(Location var1);

    public void save();

    public void saveBlocks();

    public long getRunningTime();

    public int getMaxPlayers();

    public boolean isSleeping();

    public List<Player> getPlayersInTeam(Team var1);

    public List<Team> getRemainingTeams();

    public void teleportHere(Player var1);

    public void _0destroyBed(Player var1, Location var2, Team var3);

    public void _0end(Team var1);

    public void _0setIngameScoreboard(Player var1);

    public void _0setLobbyScoreboard(Player var1);

    public boolean _0remove();
}

