/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.game.LobbyItem;

public enum LobbyItemType {
    Leave(LobbyItem.LobbySpecialType.a),
    SelectTeam(LobbyItem.LobbySpecialType.b),
    VoteArena(LobbyItem.LobbySpecialType.c),
    ForceStart(LobbyItem.LobbySpecialType.d),
    Achievements(LobbyItem.LobbySpecialType.e),
    Custom(LobbyItem.LobbySpecialType.f);
    
    private final LobbyItem.LobbySpecialType nms;

    private LobbyItemType(LobbyItem.LobbySpecialType lobbySpecialType) {
        this.nms = lobbySpecialType;
    }

    public static LobbyItemType fromNMS(LobbyItem.LobbySpecialType lobbySpecialType) {
        for (LobbyItemType lobbyItemType : LobbyItemType.values()) {
            if (lobbyItemType.nms != lobbySpecialType) continue;
            return lobbyItemType;
        }
        return null;
    }

    public LobbyItem.LobbySpecialType getNms() {
        return this.nms;
    }
}

