/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.sql.SQLConnection;

public interface SQLUpdateListener {
    public void onConnect(SQLConnection var1);

    public void onDisconnect();
}

