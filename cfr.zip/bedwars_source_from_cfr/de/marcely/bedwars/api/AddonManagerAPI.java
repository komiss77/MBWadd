/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars.api;

import java.io.File;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.plugin.Plugin;

public interface AddonManagerAPI {
    public void setAddonState(Plugin var1, boolean var2);

    @Nullable
    public Boolean getAddonState(Plugin var1);

    public List<Plugin> getEnabledAddons();

    public List<Plugin> getDisabledAddons();

    public int getAddonID(Plugin var1);

    public Plugin getAddonByName(String var1);

    public Plugin getAddonByID(int var1);

    public int research();

    public void recheck();

    public File[] getSearchDirectories();
}

