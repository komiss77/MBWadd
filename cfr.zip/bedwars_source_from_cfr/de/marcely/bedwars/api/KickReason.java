/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

public enum KickReason {
    Leave(de.marcely.bedwars.game.arena.KickReason.b),
    Kick(de.marcely.bedwars.game.arena.KickReason.c),
    Lose(de.marcely.bedwars.game.arena.KickReason.d),
    End(de.marcely.bedwars.game.arena.KickReason.e),
    Draw(de.marcely.bedwars.game.arena.KickReason.g),
    MapVote_SwitchArena(de.marcely.bedwars.game.arena.KickReason.h),
    Others(de.marcely.bedwars.game.arena.KickReason.c);
    
    private final de.marcely.bedwars.game.arena.KickReason internal;

    private KickReason(de.marcely.bedwars.game.arena.KickReason kickReason) {
        this.internal = kickReason;
    }

    public static KickReason fromInternal(de.marcely.bedwars.game.arena.KickReason kickReason) {
        for (KickReason kickReason2 : KickReason.values()) {
            if (kickReason2.internal != kickReason) continue;
            return kickReason2;
        }
        return Others;
    }

    public de.marcely.bedwars.game.arena.KickReason getInternal() {
        return this.internal;
    }
}

