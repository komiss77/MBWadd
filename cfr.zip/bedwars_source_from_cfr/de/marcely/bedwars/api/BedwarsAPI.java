/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.a;
import de.marcely.bedwars.aD;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.api.APIConfiguration;
import de.marcely.bedwars.api.AchievementsAPI;
import de.marcely.bedwars.api.AddPlayerFail;
import de.marcely.bedwars.api.AddonManagerAPI;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.ArenaPickerAPI;
import de.marcely.bedwars.api.ArenaStatus;
import de.marcely.bedwars.api.CustomLobbyItem;
import de.marcely.bedwars.api.DropType;
import de.marcely.bedwars.api.EntityAPI;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.api.KickReason;
import de.marcely.bedwars.api.LobbyItem;
import de.marcely.bedwars.api.PluginState;
import de.marcely.bedwars.api.RankingStatueAPI;
import de.marcely.bedwars.api.RegenerationType;
import de.marcely.bedwars.api.SQLUpdateListener;
import de.marcely.bedwars.api.Spawner;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.api.StatsAPI;
import de.marcely.bedwars.api.StatsSignAPI;
import de.marcely.bedwars.api.Team;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.config.Config;
import de.marcely.bedwars.config.m;
import de.marcely.bedwars.ee;
import de.marcely.bedwars.ef;
import de.marcely.bedwars.eg;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.game.stats.StatsSign;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.sql.SQLConnection;
import de.marcely.bedwars.util.FutureResult;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class BedwarsAPI {
    private static final APIConfiguration apiConfig = new APIConfiguration();
    private static final List<String> registredCommands = new ArrayList<String>();
    private static final EntityAPI entityAPI = new EntityAPI();
    private static final ArenaPickerAPI arenaPickerAPI = new ArenaPickerAPI();

    @Nullable
    public static Arena getArena(String string) {
        return s.b(string);
    }

    @Nullable
    public static Arena getArena(Player player) {
        return s.a(player);
    }

    @Nullable
    public static Arena getArena(Location location) {
        return s.a(location);
    }

    public static List<Arena> getArenas() {
        ArrayList<Arena> arrayList = new ArrayList<Arena>();
        for (de.marcely.bedwars.game.arena.Arena arena : s.af) {
            arrayList.add(arena);
        }
        return arrayList;
    }

    public static List<Arena> getArenas(Location location) {
        ArrayList<Arena> arrayList = new ArrayList<Arena>();
        List<de.marcely.bedwars.game.arena.Arena> list = s.getArenas(location);
        for (de.marcely.bedwars.game.arena.Arena arena : list) {
            arrayList.add(arena);
        }
        return arrayList;
    }

    @Nullable
    public static Arena createArena(String string, World world, RegenerationType regenerationType, @Nullable String string2) {
        if (s.b(string) != null) {
            return null;
        }
        if (string == null) {
            new NullPointerException("Name is null").printStackTrace();
        }
        if (world == null) {
            new NullPointerException("World is null").printStackTrace();
        }
        if (regenerationType == null) {
            new NullPointerException("RegenerationType is null").printStackTrace();
        }
        if (string2 == null) {
            string2 = "";
        }
        de.marcely.bedwars.game.arena.Arena arena = new de.marcely.bedwars.game.arena.Arena();
        arena.setName(string);
        arena.setWorld(world);
        arena.a(regenerationType.getNms());
        arena.v(string2);
        return arena;
    }

    @Deprecated
    @Nullable
    public static AddPlayerFail addPlayerToArena(Player player, Arena arena) {
        return BedwarsAPI.addPlayerToArena(player, arena, null);
    }

    @Deprecated
    @Nullable
    public static AddPlayerFail addPlayerToArena(Player player, Arena arena, Team team) {
        return arena.addPlayer(player, team);
    }

    @Deprecated
    public static boolean kickPlayerFromArena(Player player, Arena arena) {
        return BedwarsAPI.kickPlayerFromArena(KickReason.Kick, player, arena);
    }

    @Deprecated
    public static boolean kickPlayerFromArena(KickReason kickReason, Player player, Arena arena) {
        return arena.kickPlayer(player, kickReason);
    }

    @Nullable
    public static StatsAPI getPlayerStatsNow(OfflinePlayer offlinePlayer) {
        try {
            if (!offlinePlayer.isOnline()) {
                return c.a(offlinePlayer.getName(), offlinePlayer.getUniqueId()).get();
            }
            return (StatsAPI)((Object)c.a((Player)offlinePlayer));
        }
        catch (InterruptedException | ExecutionException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    @Deprecated
    @Nullable
    public static StatsAPI getPlayerStatsNow(UUID uUID) {
        try {
            return c.a(uUID).get();
        }
        catch (InterruptedException | ExecutionException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static Future<StatsAPI> getPlayerStats(UUID uUID) {
        final Future<c> future = c.a(uUID);
        final FutureResult<StatsAPI> futureResult = new FutureResult<StatsAPI>();
        s.a(future, new Runnable(){

            @Override
            public void run() {
                try {
                    futureResult.a((StatsAPI)future.get());
                }
                catch (InterruptedException | ExecutionException exception) {
                    futureResult.die();
                    exception.printStackTrace();
                }
            }
        });
        return futureResult;
    }

    @Deprecated
    public static StatsAPI getPlayerStats(OfflinePlayer offlinePlayer) {
        return BedwarsAPI.getPlayerStatsNow(offlinePlayer);
    }

    public static AchievementsAPI getPlayerAchievementsNow(Player player) {
        return BedwarsAPI.getPlayerAchievementsNow(player.getUniqueId());
    }

    @Nullable
    public static AchievementsAPI getPlayerAchievementsNow(UUID uUID) {
        try {
            return UserAchievements.a(uUID).get();
        }
        catch (InterruptedException | ExecutionException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static Future<AchievementsAPI> getPlayerAchievements(Player player) {
        return BedwarsAPI.getPlayerAchievements(player.getUniqueId());
    }

    public static Future<AchievementsAPI> getPlayerAchievements(UUID uUID) {
        final Future<UserAchievements> future = UserAchievements.a(uUID);
        final FutureResult<AchievementsAPI> futureResult = new FutureResult<AchievementsAPI>();
        s.a(futureResult, new Runnable(){

            @Override
            public void run() {
                try {
                    futureResult.a((AchievementsAPI)future.get());
                }
                catch (InterruptedException | ExecutionException exception) {
                    futureResult.die();
                    exception.printStackTrace();
                }
            }
        });
        return futureResult;
    }

    @Deprecated
    public static boolean enterSpectatorMode(Player player, Arena arena) {
        return cA.a(player, (de.marcely.bedwars.game.arena.Arena)arena, SpectateReason.PLUGIN);
    }

    public static boolean enterSpectatorMode(Player player, Arena arena, SpectateReason spectateReason) {
        return cA.a(player, (de.marcely.bedwars.game.arena.Arena)arena, spectateReason);
    }

    @Deprecated
    public static boolean kickFromSpectatorMode(Player player) {
        return cA.a(player, cD.h);
    }

    @Deprecated
    public static List<RankingStatueAPI> getStatues(int n2) {
        ArrayList<RankingStatueAPI> arrayList = new ArrayList<RankingStatueAPI>(8);
        Iterator<RankingStatueAPI> iterator = BedwarsAPI.getStatuesIterator(n2);
        while (iterator.hasNext()) {
            arrayList.add(iterator.next());
        }
        return arrayList;
    }

    public static Iterator<RankingStatueAPI> getStatuesIterator(int n2) {
        return new Iterator<RankingStatueAPI>(n2){
            final Iterator<RankingStatue> parent;
            {
                this.parent = s.a(n2);
            }

            @Override
            public boolean hasNext() {
                return this.parent.hasNext();
            }

            @Override
            public RankingStatueAPI next() {
                return this.parent.next();
            }
        };
    }

    public static Iterator<StatsSignAPI> getStatsSignsIterator(int n2) {
        return new Iterator<StatsSignAPI>(n2){
            final Iterator<StatsSign> parent;
            {
                this.parent = s.b(n2);
            }

            @Override
            public boolean hasNext() {
                return this.parent.hasNext();
            }

            @Override
            public StatsSignAPI next() {
                return this.parent.next();
            }
        };
    }

    public static List<RankingStatueAPI> getStatues() {
        ArrayList<RankingStatueAPI> arrayList = new ArrayList<RankingStatueAPI>();
        for (RankingStatue rankingStatue : s.ad) {
            arrayList.add(rankingStatue);
        }
        return arrayList;
    }

    public static void updateRanking() {
        s.updateRanking();
    }

    public static void reloadConfig() {
        BedwarsAPI.reloadConfig(true);
    }

    public static void reloadConfig(boolean bl2) {
        if (bl2) {
            for (Arena arena : BedwarsAPI.getArenas()) {
                if (arena.GetStatus() != ArenaStatus.Running) continue;
                arena.kickAllPlayers();
            }
        }
        Config.load();
    }

    public static boolean registerExtraItem(ExtraItem extraItem) {
        return s.ak.add(extraItem);
    }

    public static boolean unregisterExtraItem(ExtraItem extraItem) {
        return s.ak.remove(extraItem);
    }

    public static boolean registerSpawner(Spawner spawner) {
        return s.al.add(spawner);
    }

    public static boolean unregisterSpawner(Spawner spawner) {
        return s.al.remove(spawner);
    }

    public static boolean registerLobbyItem(CustomLobbyItem customLobbyItem) {
        return s.am.add(customLobbyItem);
    }

    public static boolean unregisterLobbyItem(CustomLobbyItem customLobbyItem) {
        return s.am.remove(customLobbyItem);
    }

    public static ShopDesignData createCustomShopDesignInstance(ShopDesign shopDesign, String string) {
        return new ShopDesignData(shopDesign, string);
    }

    public static List<ShopDesignData> getShopDesigns() {
        return ShopDesignData.getDesigns();
    }

    public static ShopDesignData getShopDesign(String string) {
        return ShopDesignData.getDesignByName(string);
    }

    public static ShopDesignData getShopDesign() {
        return m.a;
    }

    @Nullable
    public static LobbyItem getLobbyItem(String string) {
        return s.a(string);
    }

    @Nullable
    public static LobbyItem getLobbyItem(int n2) {
        return s.a(n2);
    }

    @Nullable
    public static DropType getDropType(String string) {
        return de.marcely.bedwars.game.DropType.a(string);
    }

    @Nullable
    public static DropType getDropType(ItemStack itemStack) {
        return de.marcely.bedwars.game.DropType.a(itemStack);
    }

    public static List<DropType> getDropTypes() {
        ArrayList<DropType> arrayList = new ArrayList<DropType>();
        for (de.marcely.bedwars.game.DropType dropType : de.marcely.bedwars.game.DropType.values()) {
            arrayList.add(dropType);
        }
        return arrayList;
    }

    @Nullable
    public static Player getLastDamager(Player player) {
        aD.a a2 = aD.f.get((Object)player);
        return a2 != null ? a2.damager : null;
    }

    public static boolean registerMBedwarsCommand(String string) {
        if (MBedwars.a.getCommand(string) == null && !registredCommands.contains(string)) {
            return false;
        }
        MBedwars.a.getCommand(string).setExecutor((CommandExecutor)MBedwars.a);
        registredCommands.add(string);
        return true;
    }

    public static boolean unregisterMBedwarsCommand(String string) {
        if (MBedwars.a.getCommand(string) == null || !MBedwars.a.getCommand(string).getExecutor().equals(MBedwars.a)) {
            return false;
        }
        MBedwars.a.getCommand(string).setExecutor(new CommandExecutor(){

            public boolean onCommand(CommandSender commandSender, Command command, String string, String[] arrstring) {
                return false;
            }
        });
        registredCommands.remove(string);
        return true;
    }

    public static List<String> getMBedwarsCommands() {
        return new ArrayList<String>(registredCommands);
    }

    public static boolean isSQLConnected() {
        return s.isSQLConnected();
    }

    @Nullable
    public static SQLConnection getSQLConnection() {
        return s.b != null && s.b.a() == eg.c ? ((ee)s.b).b : null;
    }

    public static void addSQLConnectionListener(SQLUpdateListener sQLUpdateListener) {
        s.an.add(sQLUpdateListener);
    }

    public static boolean removeSQLConnectionListener(SQLUpdateListener sQLUpdateListener) {
        return s.an.remove(sQLUpdateListener);
    }

    public static void addConfigsLoadStartListener(Runnable runnable) {
        s.ap.add(runnable);
    }

    public static boolean removeConfigsLoadStartListener(Runnable runnable) {
        return s.ap.add(runnable);
    }

    public static void addConfigsLoadEndListener(Runnable runnable) {
        s.ao.add(runnable);
    }

    public static boolean removeConfigsLoadEndListener(Runnable runnable) {
        return s.ao.add(runnable);
    }

    public static Version getVersionManager() {
        return Version.a().a();
    }

    public static AddonManagerAPI getAddonManager() {
        return MBedwars.a;
    }

    @Deprecated
    public static CommandHandler getCommandHandler() {
        return MBedwars.a;
    }

    @Deprecated
    public static APIConfiguration getOpenAPIConfiguration() {
        return apiConfig;
    }

    public static PluginState getPluginState() {
        return PluginState.fromInternal();
    }

    public static EntityAPI getEntityAPI() {
        return entityAPI;
    }

    public static ArenaPickerAPI getArenaPickerAPI() {
        return arenaPickerAPI;
    }

}

