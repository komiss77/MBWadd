/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.Team;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.location.XYZYP;
import java.util.List;
import javax.annotation.Nullable;

public interface TeamColors {
    public Arena getArena();

    public List<Team> GetEnabledTeams();

    public void setTeamEnabled(Team var1, boolean var2);

    public boolean isTeamEnabled(Team var1);

    @Nullable
    public XYZD getBedLocation(Team var1);

    public void setBedLocation(Team var1, XYZD var2);

    @Nullable
    public XYZYP getSpawnLocation(Team var1);

    public void setSpawnLocation(Team var1, XYZYP var2);

    public boolean isBedDestroyed(Team var1);

    public void _0setBedDestroyed(Team var1, boolean var2);

    public void _0reset();
}

