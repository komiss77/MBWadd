/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.ExtraItemListener;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.api.event.ShopBuyEvent;

public class ExtraItemAdapter
implements ExtraItemListener {
    @Override
    public void onShopBuy(ShopBuyEvent shopBuyEvent) {
    }

    @Override
    public void onUse(PlayerUseExtraItemEvent playerUseExtraItemEvent) {
    }
}

