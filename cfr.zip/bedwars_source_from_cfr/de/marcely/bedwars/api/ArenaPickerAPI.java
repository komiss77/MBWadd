/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;
import de.marcely.bedwars.api.arena.picker.ArenaPickerExecutor;
import de.marcely.bedwars.util.s;
import java.util.Map;
import javax.annotation.Nullable;

public class ArenaPickerAPI {
    public boolean registerConditionVariable(ArenaConditionVariable<?> arenaConditionVariable) {
        if (s.aa.containsKey(arenaConditionVariable.getName())) {
            return false;
        }
        s.aa.put(arenaConditionVariable.getName(), arenaConditionVariable);
        return true;
    }

    @Nullable
    public ArenaConditionVariable<?> unregisterConditionVariable(String string) {
        return s.aa.remove(string);
    }

    public boolean registerPickerExecutor(String string, ArenaPickerExecutor arenaPickerExecutor) {
        if (s.ab.containsKey(string)) {
            return false;
        }
        s.ab.put(string, arenaPickerExecutor);
        return true;
    }

    @Nullable
    public ArenaPickerExecutor unregisterPickerExecutor(String string) {
        return s.ab.remove(string);
    }
}

