/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

public enum RegenerationType {
    Region(de.marcely.bedwars.game.arena.RegenerationType.c),
    World(de.marcely.bedwars.game.arena.RegenerationType.d),
    MapVote(de.marcely.bedwars.game.arena.RegenerationType.e);
    
    private final de.marcely.bedwars.game.arena.RegenerationType nms;

    private RegenerationType(de.marcely.bedwars.game.arena.RegenerationType regenerationType) {
        this.nms = regenerationType;
    }

    public boolean isNormal() {
        return this.nms.J();
    }

    public static RegenerationType fromNMS(de.marcely.bedwars.game.arena.RegenerationType regenerationType) {
        for (RegenerationType regenerationType2 : RegenerationType.values()) {
            if (regenerationType2.nms != regenerationType) continue;
            return regenerationType2;
        }
        return null;
    }

    public de.marcely.bedwars.game.arena.RegenerationType getNms() {
        return this.nms;
    }
}

