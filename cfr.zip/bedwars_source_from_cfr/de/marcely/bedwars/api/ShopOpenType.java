/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

public enum ShopOpenType {
    MINISHOP,
    VILLAGER,
    DEBUG,
    CUSTOM,
    UNKOWN;
    
}

