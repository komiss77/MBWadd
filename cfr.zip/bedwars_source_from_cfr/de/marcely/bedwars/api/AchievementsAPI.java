/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.achievements.Achievement;
import java.util.UUID;

public interface AchievementsAPI {
    public UUID getUUID();

    public boolean has(Achievement var1);

    public void set(Achievement var1, boolean var2);
}

