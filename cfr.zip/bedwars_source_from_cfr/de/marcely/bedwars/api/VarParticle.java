/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Color
 *  org.bukkit.Effect
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Player$Spigot
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.versions.Version;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class VarParticle {
    public static final VarParticle PARTICLE_CLOUD = VarParticle.ofName("CLOUD");
    public static final VarParticle PARTICLE_SMOKE = VarParticle.ofName("SMOKE");
    public static final VarParticle PARTICLE_COLOURED;
    private static Method METHOD_PLAYER_SPAWN_PARTICLE;
    private final ParticleKeepType keepType;
    private Effect effect;
    private Particle particle;
    private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType;

    static {
        if (Version.a().getVersionNumber() >= 9) {
            try {
                METHOD_PLAYER_SPAWN_PARTICLE = Player.class.getMethod("spawnParticle", Particle.class, Location.class, Integer.TYPE, Object.class);
            }
            catch (NoSuchMethodException | SecurityException exception) {
                exception.printStackTrace();
            }
        }
        PARTICLE_COLOURED = Version.a().getVersionNumber() >= 13 ? VarParticle.ofName("REDSTONE") : VarParticle.ofName("COLOURED_DUST");
    }

    public VarParticle(Effect effect) {
        this.keepType = ParticleKeepType.EFFECT;
        this.effect = effect;
    }

    public VarParticle(Particle particle) {
        this.keepType = ParticleKeepType.PARTICLE;
        this.particle = particle;
    }

    public String getName() {
        switch (VarParticle.$SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType()[this.keepType.ordinal()]) {
            case 1: {
                return this.effect.name();
            }
            case 2: {
                return this.particle.name();
            }
        }
        return null;
    }

    public void play(World world, Location location, int n2) {
        for (Player player : world.getPlayers()) {
            this.play(player, location, n2);
        }
    }

    public void play(World world, Location location, Color color) {
        for (Player player : world.getPlayers()) {
            this.play(player, location, color);
        }
    }

    public void play(Player player, Location location, int n2) {
        switch (VarParticle.$SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType()[this.keepType.ordinal()]) {
            case 1: {
                player.playEffect(location, this.effect, n2);
                break;
            }
            case 2: {
                try {
                    METHOD_PLAYER_SPAWN_PARTICLE.invoke((Object)player, new Object[]{this.particle, location, 1, null});
                    break;
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

    public void play(Player player, Location location, Color color) {
        switch (VarParticle.$SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType()[this.keepType.ordinal()]) {
            case 1: {
                float f2 = (float)color.getRed() / 255.0f;
                if (f2 == 0.0f) {
                    f2 = Float.MIN_NORMAL;
                }
                if (Version.a().getVersionNumber() < 13) {
                    player.spigot().playEffect(location, this.effect, 0, 1, f2, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, 1.0f, 0, 32);
                    break;
                }
                player.playEffect(location, this.effect, 0);
                break;
            }
            case 2: {
                try {
                    if (Version.a().getVersionNumber() >= 13) {
                        Object obj = Class.forName("org.bukkit.Particle$DustOptions").getConstructor(Color.class, Float.TYPE).newInstance(new Object[]{color, Float.valueOf(1.0f)});
                        METHOD_PLAYER_SPAWN_PARTICLE.invoke((Object)player, new Object[]{this.particle, location, 1, obj});
                        break;
                    }
                    METHOD_PLAYER_SPAWN_PARTICLE.invoke((Object)player, new Object[]{this.particle, location, 1, null});
                    break;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

    @Nullable
    public static VarParticle ofName(String string) {
        if (Version.a().getVersionNumber() >= 9) {
            for (Particle particle : Particle.values()) {
                if (!particle.name().equalsIgnoreCase(string) && !particle.name().replace("_", "").equalsIgnoreCase(string)) continue;
                return new VarParticle(particle);
            }
        }
        for (Particle particle : Effect.values()) {
            if (!particle.name().equalsIgnoreCase(string) && !particle.name().replace("_", "").equalsIgnoreCase(string)) continue;
            return new VarParticle((Effect)particle);
        }
        return null;
    }

    public ParticleKeepType getKeepType() {
        return this.keepType;
    }

    public Effect getEffect() {
        return this.effect;
    }

    public Particle getParticle() {
        return this.particle;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType() {
        if ($SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ParticleKeepType.values().length];
        try {
            arrn[ParticleKeepType.EFFECT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ParticleKeepType.PARTICLE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType = arrn;
        return $SWITCH_TABLE$de$marcely$bedwars$api$VarParticle$ParticleKeepType;
    }

    public static enum ParticleKeepType {
        EFFECT,
        PARTICLE;
        
    }

}

