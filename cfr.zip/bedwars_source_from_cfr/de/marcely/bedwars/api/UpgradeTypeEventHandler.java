/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

public class UpgradeTypeEventHandler {
}

