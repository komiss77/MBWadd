/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.ExtraItemListener;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

public class ExtraItem {
    private final String name;
    private ItemStack is;
    private final List<ExtraItemListener> listeners = new ArrayList<ExtraItemListener>(4);

    public ExtraItem(String string, ItemStack itemStack) {
        this(string, itemStack, null);
    }

    @Deprecated
    public ExtraItem(String string, ItemStack itemStack, EntityType entityType) {
        this.name = string;
        this.is = entityType != null ? Version.a().a(itemStack, entityType) : itemStack;
    }

    public void setItemStack(ItemStack itemStack) {
        this.is = itemStack;
    }

    public String getName() {
        return this.name;
    }

    public ItemStack getItemStack() {
        return this.is.clone();
    }

    public ItemStack getItemStack(int n2) {
        ItemStack itemStack = this.is;
        itemStack.setAmount(n2);
        return itemStack;
    }

    public void registerListener(ExtraItemListener extraItemListener) {
        this.listeners.add(extraItemListener);
    }

    public boolean unregisterListener(ExtraItemListener extraItemListener) {
        return this.listeners.remove(extraItemListener);
    }

    public List<ExtraItemListener> getListeners() {
        return this.listeners;
    }
}

