/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.game.arena.Arena;
import javax.annotation.Nullable;

public enum AddPlayerFail {
    Full(Arena.AddPlayerFail.a),
    AlreadyInside(Arena.AddPlayerFail.b),
    OnlyVoteArenas(Arena.AddPlayerFail.c),
    OnlyNormalArenas(Arena.AddPlayerFail.d),
    Plugin(Arena.AddPlayerFail.e);
    
    private final Arena.AddPlayerFail internal;

    private AddPlayerFail(Arena.AddPlayerFail addPlayerFail) {
        this.internal = addPlayerFail;
    }

    @Nullable
    public static AddPlayerFail fromInternal(Arena.AddPlayerFail addPlayerFail) {
        for (AddPlayerFail addPlayerFail2 : AddPlayerFail.values()) {
            if (addPlayerFail2.internal != addPlayerFail) continue;
            return addPlayerFail2;
        }
        return null;
    }

    public Arena.AddPlayerFail getInternal() {
        return this.internal;
    }
}

