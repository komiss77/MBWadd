/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.Team;

public interface UpgradeStateAPI {
    public Arena getArena();

    public Team GetTeam();
}

