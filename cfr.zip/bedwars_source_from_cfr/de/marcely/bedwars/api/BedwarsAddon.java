/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.a;
import de.marcely.configmanager2.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class BedwarsAddon {
    private Plugin plugin;
    private List<BedwarsAddonCommand> commands = new ArrayList<BedwarsAddonCommand>();
    private ConfigManager configmanager = null;

    public BedwarsAddon(Plugin plugin) {
        this.plugin = plugin;
        MBedwars.b.put(plugin, this);
    }

    public void registerCommand(BedwarsAddonCommand bedwarsAddonCommand) {
        this.commands.add(bedwarsAddonCommand);
    }

    public BedwarsAddonCommand getCommand(String string) {
        for (BedwarsAddonCommand bedwarsAddonCommand : this.commands) {
            if (!bedwarsAddonCommand.command.equalsIgnoreCase(string)) continue;
            return bedwarsAddonCommand;
        }
        return null;
    }

    public List<BedwarsAddonCommand> getCommands() {
        return this.commands;
    }

    public ConfigManager getConfig() {
        if (this.configmanager == null) {
            this.configmanager = new ConfigManager(MBedwars.a.getName(), "/add-ons/" + this.plugin.getName() + ".yml");
        }
        return this.configmanager;
    }

    public Plugin getPlugin() {
        return this.plugin;
    }

    public int getID() {
        return MBedwars.a.getAddonID(this.plugin);
    }

    public static abstract class BedwarsAddonCommand {
        protected String command;
        protected String usage;
        protected String fullUsage;

        public BedwarsAddonCommand(String string) {
            this(string, "");
        }

        public BedwarsAddonCommand(String string, String string2) {
            this.command = string;
            this.usage = string2;
        }

        public String getCommand() {
            return this.command;
        }

        public String getUsage() {
            return this.usage;
        }

        public abstract void onWrite(CommandSender var1, String[] var2, String var3);
    }

}

