/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.Effect
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.Spawner;
import de.marcely.bedwars.api.VarParticle;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;

public interface DropType {
    public void setName(String var1);

    public void setConfigItemstack(ItemStack var1);

    public void setCustomSpawner(@Nullable Spawner var1);

    public void setSpawnDelay(double var1);

    public void setSpawnRadius(int var1);

    public void setSound(@Nullable Sound var1);

    public void setTranquil(boolean var1);

    public void setMerging(boolean var1);

    public void setHologram(@Nullable Material var1);

    public void setChatColor(@Nullable ChatColor var1);

    @Deprecated
    public void setEffect(@Nullable Effect var1);

    public void setVarParticle(@Nullable VarParticle var1);

    public String getName();

    @Nullable
    public ItemStack getActualItemstack();

    @Nullable
    public ItemStack getConfigItemstack();

    @Nullable
    public Spawner getCustomSpawner();

    public double getSpawnDelay();

    public int getSpawnRadius();

    @Nullable
    public Sound getSound();

    public boolean isTranquil();

    public boolean isMerging();

    @Nullable
    public Material getHologram();

    @Nullable
    public ChatColor getChatColor();

    @Deprecated
    @Nullable
    public Effect getEffect();

    public VarParticle getVarParticle();

    public boolean isDisabledForRound();

    public void setDisabledForRound(boolean var1);
}

