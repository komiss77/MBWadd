/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.Color
 *  org.bukkit.DyeColor
 */
package de.marcely.bedwars.api;

import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;

public enum Team {
    Yellow(de.marcely.bedwars.game.Team.c),
    Orange(de.marcely.bedwars.game.Team.d),
    Red(de.marcely.bedwars.game.Team.e),
    Blue(de.marcely.bedwars.game.Team.f),
    Light_Blue(de.marcely.bedwars.game.Team.g),
    Cyan(de.marcely.bedwars.game.Team.h),
    Light_Green(de.marcely.bedwars.game.Team.i),
    Green(de.marcely.bedwars.game.Team.j),
    Purple(de.marcely.bedwars.game.Team.k),
    Pink(de.marcely.bedwars.game.Team.l),
    White(de.marcely.bedwars.game.Team.m),
    Light_Gray(de.marcely.bedwars.game.Team.n),
    Gray(de.marcely.bedwars.game.Team.o),
    Brown(de.marcely.bedwars.game.Team.p),
    Black(de.marcely.bedwars.game.Team.q);
    
    private final de.marcely.bedwars.game.Team internal;

    private Team(de.marcely.bedwars.game.Team team) {
        this.internal = team;
    }

    @Nullable
    public static Team fromInternal(de.marcely.bedwars.game.Team team) {
        if (team == null) {
            return null;
        }
        for (Team team2 : Team.values()) {
            if (team2.internal != team) continue;
            return team2;
        }
        return null;
    }

    public String getName() {
        return this.internal.getName();
    }

    public String getName(boolean bl2) {
        return this.internal.getName(bl2);
    }

    public String getShortName() {
        return this.internal.m();
    }

    public ChatColor getChatColor() {
        return this.internal.getChatColor();
    }

    public DyeColor getDyeColor() {
        return this.internal.getDyeColor();
    }

    public Color getColor() {
        return this.internal.getColor();
    }

    public static Team getTeamByName(String string) {
        return Team.fromInternal(de.marcely.bedwars.game.Team.a(string));
    }

    public static Team getTeamByName(String string, boolean bl2) {
        return Team.fromInternal(de.marcely.bedwars.game.Team.a(string, bl2));
    }

    public static Team getTeamByChatColor(ChatColor chatColor) {
        return Team.fromInternal(de.marcely.bedwars.game.Team.a(chatColor));
    }

    public static Team getTeamByDyeColor(DyeColor dyeColor) {
        return Team.fromInternal(de.marcely.bedwars.game.Team.a(dyeColor));
    }

    public de.marcely.bedwars.game.Team getInternal() {
        return this.internal;
    }
}

