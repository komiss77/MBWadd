/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.api;

import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.api.event.ShopBuyEvent;

public interface ExtraItemListener {
    public void onShopBuy(ShopBuyEvent var1);

    public void onUse(PlayerUseExtraItemEvent var1);
}

