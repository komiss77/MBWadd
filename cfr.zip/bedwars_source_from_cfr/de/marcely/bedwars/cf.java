/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ch;
import de.marcely.bedwars.game.stats.c;

public class cf
extends ch {
    public static cf a = new cf();

    @Override
    protected String a(c c2) {
        return "" + c2.b();
    }
}

