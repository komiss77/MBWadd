/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.j;

public class A
extends j {
    private String h;

    public A(String string) {
        this.h = string;
    }

    public String f() {
        return this.h;
    }

    @Override
    public String d() {
        return j.a.e.getID() + "/" + this.f();
    }

    public static A a(String string) {
        String[] arrstring = string.split("/");
        if (arrstring.length == 2) {
            return new A(arrstring[1]);
        }
        return null;
    }
}

