/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.sql;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.SQLUpdateListener;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.extlibrary.ExtLibrary;
import de.marcely.bedwars.sql.SQLResult;
import de.marcely.bedwars.sql.SQLTask;
import de.marcely.bedwars.sql.SQLType;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.List;
import java.util.Stack;
import javax.annotation.Nullable;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SQLConnection {
    private static final int TIMEOUT = 12;
    private static final int TIMEOUT_WARN_COOLDOWN = 180000;
    public boolean doLog = true;
    private final String connectionString;
    private final String username;
    private final String password;
    private final SQLType type;
    private final boolean threaded;
    private boolean connected = false;
    private boolean isConnecting = false;
    private Stack<SQLTask> tasks = new Stack();
    private MThread thread;
    private BukkitTask task;
    private long lastTimeoutWarn = 0L;
    private int timeoutWarnsSinceLastTime = 0;

    public SQLConnection(SQLType sQLType, String string, int n2, String string2, String string3, String string4, boolean bl2) {
        this(sQLType, "jdbc:" + sQLType.getName() + "://" + string + ":" + n2 + "/" + string2 + ConfigValue.sql_parameters, string3, string4, bl2);
    }

    public SQLConnection(SQLType sQLType, File file, boolean bl2) {
        this(sQLType, "jdbc:" + sQLType.getName() + "://" + file.getAbsolutePath(), null, null, bl2);
    }

    public SQLConnection(SQLType sQLType, String string, String string2, String string3, boolean bl2) {
        this.type = sQLType;
        this.username = string2;
        this.password = string3;
        this.threaded = bl2;
        this.connectionString = string;
    }

    private void loadDriver() {
        try {
            Class.forName(this.type.getDriver());
        }
        catch (ClassNotFoundException classNotFoundException) {
            classNotFoundException.printStackTrace();
        }
    }

    @Nullable
    private Connection open() throws Exception {
        if (this.type == SQLType.SQLite) {
            try {
                Class.forName("org.sqlite.JDBC");
            }
            catch (ClassNotFoundException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }
        } else if (this.type.getExtLibrary() != null) {
            long l2 = System.currentTimeMillis();
            while (!this.type.getExtLibrary().loaded) {
                if (System.currentTimeMillis() > l2 + 15000L) {
                    d.g("FAILED TO OPEN SQL CONNECTION: Failed to download/read needed drivers. Make sure that you have a working internet connection");
                    return null;
                }
                Thread.sleep(1000L);
            }
            this.loadDriver();
        }
        if (this.username != null) {
            return DriverManager.getConnection(this.connectionString, this.username, this.password);
        }
        return DriverManager.getConnection(this.connectionString);
    }

    public boolean connect() {
        return this.connect(null);
    }

    public boolean connect(final @Nullable Runnable runnable) {
        if (this.isConnected()) {
            return false;
        }
        this.isConnecting = true;
        if (this.threaded) {
            this.thread = new MThread(MThread.ThreadType.b){

                @Override
                public void run() {
                    try {
                        Connection connection = SQLConnection.this.open();
                        connection.close();
                        if (SQLConnection.this.doLog) {
                            for (SQLUpdateListener sQLUpdateListener : s.an) {
                                sQLUpdateListener.onConnect(SQLConnection.this);
                            }
                            d.f("Successfully connected to the SQL server");
                        }
                        SQLConnection.access$1(SQLConnection.this, true);
                        SQLConnection.access$2(SQLConnection.this, false);
                        if (runnable != null) {
                            runnable.run();
                        }
                    }
                    catch (SQLException sQLException) {
                        d.a(sQLException);
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    SQLConnection.access$2(SQLConnection.this, false);
                    while (SQLConnection.this.isConnected()) {
                        SQLConnection.this.finishTasks();
                        try {
                            1.sleep(1000L);
                        }
                        catch (InterruptedException interruptedException) {
                            // empty catch block
                        }
                    }
                }
            };
            this.thread.start();
        } else {
            try {
                Connection connection = this.open();
                connection.close();
                if (this.doLog) {
                    for (SQLUpdateListener sQLUpdateListener : s.an) {
                        sQLUpdateListener.onConnect(this);
                    }
                    d.f("Successfully connected to the SQL server");
                }
                this.connected = true;
                this.isConnecting = false;
                if (runnable != null) {
                    runnable.run();
                }
            }
            catch (SQLException sQLException) {
                d.a(sQLException);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            this.isConnecting = false;
            if (this.task == null) {
                this.task = new BukkitRunnable(){

                    public void run() {
                        if (SQLConnection.this.isConnected()) {
                            SQLConnection.this.finishTasks();
                        } else {
                            this.cancel();
                        }
                    }
                }.runTaskTimer((Plugin)MBedwars.a, 20L, 20L);
            }
        }
        return true;
    }

    public boolean disconnect() {
        if (!this.isConnected()) {
            return false;
        }
        this.connected = false;
        if (this.thread != null) {
            this.thread = null;
        } else if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        for (SQLUpdateListener sQLUpdateListener : s.an) {
            sQLUpdateListener.onDisconnect();
        }
        return true;
    }

    public boolean addTask(SQLTask sQLTask) {
        if (!this.isConnected()) {
            return false;
        }
        this.tasks.push(sQLTask);
        return true;
    }

    private void finishTasks() {
        if (!this.tasks.empty()) {
            try {
                Connection connection = this.open();
                while (!this.tasks.isEmpty()) {
                    SQLTask sQLTask = this.tasks.pop();
                    sQLTask.finished(this.doTask(sQLTask, connection));
                }
                connection.close();
            }
            catch (SQLException sQLException) {
                d.a(sQLException);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }

    @Nullable
    public SQLResult doTask(SQLTask sQLTask) {
        SQLResult sQLResult = null;
        try {
            Connection connection = this.open();
            sQLResult = this.doTask(sQLTask, connection);
            if (!sQLTask.isWithResult()) {
                connection.close();
            }
        }
        catch (SQLException sQLException) {
            d.a(sQLException);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return sQLResult;
    }

    @Nullable
    private SQLResult doTask(SQLTask sQLTask, Connection connection) {
        while (this.isConnecting()) {
            try {
                Thread.sleep(50L);
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
        if (!this.isConnected()) {
            d.g("Failed to execute a SQL task as we aren't connected. Restart/Reload this plugin to reconnect.");
            return null;
        }
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sQLTask.getTask());
            for (int i2 = 0; i2 < sQLTask.getParameters().size(); ++i2) {
                preparedStatement.setObject(i2 + 1, sQLTask.getParameters().get(i2));
            }
            preparedStatement.setQueryTimeout(12000);
            if (sQLTask.isWithResult()) {
                ResultSet resultSet = preparedStatement.executeQuery();
                SQLResult sQLResult = new SQLResult(connection, resultSet);
                sQLTask.finished(sQLResult);
                return new SQLResult(connection, resultSet);
            }
            preparedStatement.executeUpdate();
            sQLTask.finished(null);
            preparedStatement.close();
            return null;
        }
        catch (SQLTimeoutException sQLTimeoutException) {
            if (System.currentTimeMillis() >= this.lastTimeoutWarn + 180000L) {
                d.g("Very slow network! Timed out after 12 seconds. " + this.timeoutWarnsSinceLastTime + " Queries have been canceled.");
                this.lastTimeoutWarn = System.currentTimeMillis();
                this.timeoutWarnsSinceLastTime = 0;
            } else {
                ++this.timeoutWarnsSinceLastTime;
            }
        }
        catch (SQLException sQLException) {
            sQLTask.failed(sQLException);
        }
        return null;
    }

    public SQLType getType() {
        return this.type;
    }

    public boolean isThreaded() {
        return this.threaded;
    }

    public boolean isConnected() {
        return this.connected;
    }

    public boolean isConnecting() {
        return this.isConnecting;
    }

    public Stack<SQLTask> getTasks() {
        return this.tasks;
    }

    static /* synthetic */ void access$1(SQLConnection sQLConnection, boolean bl2) {
        sQLConnection.connected = bl2;
    }

    static /* synthetic */ void access$2(SQLConnection sQLConnection, boolean bl2) {
        sQLConnection.isConnecting = bl2;
    }

}

