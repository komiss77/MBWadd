/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.sql;

import de.marcely.bedwars.d;
import de.marcely.bedwars.sql.SQLResult;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public abstract class SQLTask {
    private final String task;
    private final boolean withResult;
    private final List<Object> parameters = new ArrayList<Object>();

    public SQLTask(String string, boolean bl2) {
        this.task = string;
        this.withResult = bl2;
    }

    public abstract void finished(@Nullable SQLResult var1);

    public void failed(SQLException sQLException) {
        d.a(sQLException);
    }

    public SQLTask addParameter(Object object) {
        this.parameters.add(object);
        return this;
    }

    public String getTask() {
        return this.task;
    }

    public boolean isWithResult() {
        return this.withResult;
    }

    public List<Object> getParameters() {
        return this.parameters;
    }
}

