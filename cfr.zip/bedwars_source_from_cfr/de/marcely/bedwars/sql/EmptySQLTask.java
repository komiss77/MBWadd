/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.sql;

import de.marcely.bedwars.sql.SQLResult;
import de.marcely.bedwars.sql.SQLTask;

public class EmptySQLTask
extends SQLTask {
    public EmptySQLTask(String string, boolean bl2) {
        super(string, bl2);
    }

    @Override
    public void finished(SQLResult sQLResult) {
    }
}

