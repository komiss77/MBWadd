/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.sql;

import de.marcely.bedwars.extlibrary.ExtLibrary;
import javax.annotation.Nullable;

public enum SQLType {
    MySQL("mysql"),
    MariaDB("mariadb", ExtLibrary.c, "org.mariadb.jdbc.Driver"),
    MSSQL("sqlserver"),
    SQLite("sqlite");
    
    private final String name;
    @Nullable
    private final ExtLibrary extLibrary;
    @Nullable
    private final String driver;

    private SQLType(String string2) {
        this(string2, null, null);
    }

    private SQLType(String string2, @Nullable ExtLibrary extLibrary, String string3) {
        this.name = string2;
        this.extLibrary = extLibrary;
        this.driver = string3;
    }

    public static SQLType getSQLType(String string) {
        for (SQLType sQLType : SQLType.values()) {
            if (!sQLType.name.equalsIgnoreCase(string) && !sQLType.name().equalsIgnoreCase(string)) continue;
            return sQLType;
        }
        return null;
    }

    public String getName() {
        return this.name;
    }

    @Nullable
    public ExtLibrary getExtLibrary() {
        return this.extLibrary;
    }

    @Nullable
    public String getDriver() {
        return this.driver;
    }
}

