/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SQLResult {
    private final Connection connection;
    private final ResultSet result;

    public SQLResult(Connection connection, ResultSet resultSet) {
        this.connection = connection;
        this.result = resultSet;
    }

    public void closeAll() throws SQLException {
        this.connection.close();
        this.result.close();
    }

    public ResultSet getResult() {
        return this.result;
    }
}

