/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bS;
import de.marcely.bedwars.game.arena.Arena;

public abstract class bZ
extends bS<Arena> {
}

