/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.BedPlaceEvent;
import de.marcely.bedwars.bx;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class aB {
    public static void a(BlockPlaceEvent blockPlaceEvent) {
        final Player player = blockPlaceEvent.getPlayer();
        final Block block = blockPlaceEvent.getBlock();
        Arena arena = s.a(player);
        final byte by2 = block.getData();
        ItemStack itemStack = blockPlaceEvent.getItemInHand();
        if (arena != null) {
            if (arena.b() == ArenaStatus.f) {
                Arena arena2 = s.a(block.getLocation());
                if (arena2 == null || arena.a(block.getLocation())) {
                    blockPlaceEvent.setCancelled(true);
                } else {
                    Material material = k.a(block.getType());
                    if (ConfigValue.placeableblock_whitelist_enabled && !s.W.containsKey((Object)material) && !ConfigValue.placeableblock_whitelist.contains((Object)material) && block.getType() != bx.g.getItemStack().getType()) {
                        blockPlaceEvent.setCancelled(true);
                    } else {
                        blockPlaceEvent.setCancelled(false);
                        if (material == bx.g.getItemStack().getType()) {
                            arena.n.put(XYZ.valueOf(block.getLocation()).toString(), blockPlaceEvent.getPlayer());
                            s.a(player, Achievement.t);
                        }
                        if (block.getType() == Material.TNT) {
                            blockPlaceEvent.setCancelled(false);
                            new BukkitRunnable(){

                                public void run() {
                                    block.setType(Material.AIR);
                                }
                            }.runTaskLater((Plugin)MBedwars.a, 1L);
                            block.getWorld().spawnEntity(block.getLocation(), EntityType.PRIMED_TNT);
                            return;
                        }
                        arena.o.put(XYZ.valueOf(block.getLocation()).toString(), blockPlaceEvent.getPlayer());
                        if (ConfigValue.destroyblock_builtbyplayers || ConfigValue.tnt_canbreakblocks && ConfigValue.tnt_canbreakblocks_breakby_player) {
                            arena.b(block);
                        }
                        if (itemStack != null && itemStack.getType() == Material.CHEST) {
                            final Location location = block.getLocation();
                            blockPlaceEvent.setCancelled(true);
                            if (s.e(location)) {
                                Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)MBedwars.a, new Runnable(){

                                    @Override
                                    public void run() {
                                        s.a(player, Material.CHEST);
                                        location.getWorld().getBlockAt(location).setType(Material.CHEST);
                                        location.getWorld().getBlockAt(location).setData(by2);
                                    }
                                }, 1L);
                            }
                        }
                    }
                }
            } else {
                blockPlaceEvent.setCancelled(true);
            }
        } else {
            Arena arena3 = s.a(block.getLocation());
            if (arena3 != null) {
                blockPlaceEvent.setCancelled(!s.hasPermission((CommandSender)player, Permission.ArenaBuild));
                if (arena3 != null && s.hasPermission((CommandSender)player, Permission.ArenaBuild)) {
                    Team team;
                    String string = itemStack.getItemMeta().getDisplayName();
                    if (string == null || !r.b(s.W, string)) {
                        return;
                    }
                    boolean bl2 = false;
                    Object object = block.getType();
                    boolean bl3 = bl2 = object == ConfigValue.bed_block;
                    if (!bl2 && Version.a().getVersionNumber() >= 13 && object == Material.AIR) {
                        String string2 = ((w)Version.a().a()).a(block.getWorld(), block.getX(), block.getY(), block.getZ());
                        if (ConfigValue.bed_block == Material.BED_BLOCK && string2.endsWith("_bed")) {
                            bl2 = true;
                        } else {
                            String[] arrstring = string2.split("_");
                            if (arrstring.length >= 2) {
                                string2 = "legacy_" + String.join((CharSequence)"_", Arrays.copyOfRange(arrstring, 1, arrstring.length));
                                bl2 = string2.equals(object.name().toLowerCase());
                            }
                        }
                    }
                    if ((team = Team.a((CommandSender)player, r.removeChatColor(r.c(s.W, string)))) != null) {
                        if (arena3.a().r().contains((Object)team)) {
                            if (!arena3.a().J()) {
                                return;
                            }
                            object = new BedPlaceEvent(player, arena, team, block.getLocation());
                            Bukkit.getPluginManager().callEvent((Event)object);
                            if (!((BedPlaceEvent)((Object)object)).isCancelled()) {
                                arena3.a().a(XYZD.valueOf(block, ConfigValue.bed_block == Material.BED_BLOCK), team);
                                b.b(arena3);
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Saved_Bed).a("arena", arena3.getName()).a("color", team.a((CommandSender)player)).a("colorcode", "" + (Object)team.getChatColor()));
                            }
                        } else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Team_NotAddedYet).a("team", team.a((CommandSender)player, true)).a("teamcolor", "" + (Object)team.getChatColor()).a("arena", arena3.getName()));
                        }
                    }
                    return;
                }
                if (s.hasPermission((CommandSender)player, Permission.GetArena) && block.getType() == Material.SOUL_SAND) {
                    List<Arena> list = s.getArenas(block.getLocation());
                    player.sendMessage("");
                    player.sendMessage((Object)ChatColor.GOLD + "Arenas:");
                    for (Arena arena4 : list) {
                        player.sendMessage((Object)ChatColor.YELLOW + arena4.getName());
                    }
                    player.sendMessage("");
                }
            }
        }
    }

}

