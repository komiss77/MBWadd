/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.PlaceholderAPI
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.d;
import de.marcely.bedwars.dD;
import de.marcely.bedwars.du;
import java.util.ArrayList;
import java.util.List;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public class dt
extends du {
    private a a;

    @Override
    public cT a() {
        return cT.n;
    }

    @Override
    public void onEnable() {
        this.a = new a();
        if (this.a.register()) {
            d.c("Successfully hooked to PlaceholderAPI");
        } else {
            d.c("Failed to hook into PlaceholderAPI");
        }
    }

    @Override
    public void onDisable() {
    }

    @Override
    public String a(Player player, String string) {
        return PlaceholderAPI.setPlaceholders((Player)player, (String)string);
    }

    @Override
    public void a(dD dD2) {
        this.a.c(dD2);
    }

    @Override
    public void b(dD dD2) {
        this.a.d(dD2);
    }

    @Override
    public void Z() {
        PlaceholderAPI.unregisterExpansion((PlaceholderExpansion)this.a);
        this.a.aa();
    }

    private static class a
    extends PlaceholderExpansion {
        private final List<dD> ab = new ArrayList<dD>();

        private a() {
        }

        public boolean Q() {
            return true;
        }

        public boolean canRegister() {
            return true;
        }

        public String getAuthor() {
            return "Marcely's Bedwars Team";
        }

        public String getIdentifier() {
            return "mbedwars";
        }

        public String getVersion() {
            return MBedwars.getVersion();
        }

        public String onPlaceholderRequest(Player player, String string) {
            for (dD dD2 : this.ab) {
                if (!dD2.getIdentifier().equals(string)) continue;
                return dD2.e(player);
            }
            return null;
        }

        public void c(dD dD2) {
            this.ab.add(dD2);
        }

        public void d(dD dD2) {
            this.ab.remove(dD2);
        }

        public void aa() {
            this.ab.clear();
        }
    }

}

