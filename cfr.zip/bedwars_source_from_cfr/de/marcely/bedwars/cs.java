/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.ct;
import de.marcely.bedwars.game.stats.c;

public class cs
extends ct {
    public static cs a = new cs();

    public String b(c c2) {
        return "" + c2.getLoses();
    }

    @Override
    public /* synthetic */ String a(Object object) {
        return this.b((c)object);
    }
}

