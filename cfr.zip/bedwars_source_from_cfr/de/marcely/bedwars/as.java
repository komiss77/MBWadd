/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.CreatureSpawnEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDeathEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.entity.EntityTeleportEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.inventory.CraftItemEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.event.inventory.InventoryDragEvent
 *  org.bukkit.event.inventory.InventoryOpenEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerBedEnterEvent
 *  org.bukkit.event.player.PlayerCommandPreprocessEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerExpChangeEvent
 *  org.bukkit.event.player.PlayerGameModeChangeEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.event.player.PlayerPortalEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 *  org.bukkit.event.player.PlayerToggleFlightEvent
 *  org.bukkit.event.server.PluginDisableEvent
 *  org.bukkit.event.server.ServerListPingEvent
 *  org.bukkit.event.weather.WeatherChangeEvent
 *  org.bukkit.event.world.ChunkLoadEvent
 *  org.bukkit.event.world.ChunkUnloadEvent
 *  org.bukkit.event.world.WorldLoadEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.aB;
import de.marcely.bedwars.aC;
import de.marcely.bedwars.aD;
import de.marcely.bedwars.aE;
import de.marcely.bedwars.aF;
import de.marcely.bedwars.aG;
import de.marcely.bedwars.aH;
import de.marcely.bedwars.aI;
import de.marcely.bedwars.aJ;
import de.marcely.bedwars.aK;
import de.marcely.bedwars.aL;
import de.marcely.bedwars.aM;
import de.marcely.bedwars.aN;
import de.marcely.bedwars.aO;
import de.marcely.bedwars.aP;
import de.marcely.bedwars.aQ;
import de.marcely.bedwars.aR;
import de.marcely.bedwars.aS;
import de.marcely.bedwars.aT;
import de.marcely.bedwars.aU;
import de.marcely.bedwars.aV;
import de.marcely.bedwars.aX;
import de.marcely.bedwars.aY;
import de.marcely.bedwars.aZ;
import de.marcely.bedwars.aw;
import de.marcely.bedwars.ax;
import de.marcely.bedwars.az;
import de.marcely.bedwars.ba;
import de.marcely.bedwars.bb;
import de.marcely.bedwars.bc;
import de.marcely.bedwars.bd;
import de.marcely.bedwars.be;
import de.marcely.bedwars.bf;
import de.marcely.bedwars.bg;
import de.marcely.bedwars.bh;
import de.marcely.bedwars.bi;
import de.marcely.bedwars.bj;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.WorldLoadEvent;

public class as
implements Listener {
    public static boolean u = false;

    @EventHandler
    public void a(PlayerJoinEvent playerJoinEvent) {
        aY.a(playerJoinEvent);
    }

    @EventHandler
    public void a(PlayerQuitEvent playerQuitEvent) {
        bc.a(playerQuitEvent);
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void a(PlayerDeathEvent playerDeathEvent) {
        aR.a(playerDeathEvent);
    }

    @EventHandler
    public void a(EntityDeathEvent entityDeathEvent) {
        aF.a(entityDeathEvent);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(PlayerRespawnEvent playerRespawnEvent) {
        bd.a(playerRespawnEvent);
    }

    @EventHandler
    public void a(InventoryClickEvent inventoryClickEvent) {
        aK.a(inventoryClickEvent);
    }

    @EventHandler
    public void a(InventoryDragEvent inventoryDragEvent) {
        aM.a(inventoryDragEvent);
    }

    @EventHandler
    public void a(InventoryCloseEvent inventoryCloseEvent) {
        aL.a(inventoryCloseEvent);
    }

    @EventHandler
    public void a(PlayerInteractEntityEvent playerInteractEntityEvent) {
        u = true;
        aX.a(playerInteractEntityEvent);
    }

    @EventHandler
    public void a(BlockBreakEvent blockBreakEvent) {
        az.a(blockBreakEvent);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(BlockPlaceEvent blockPlaceEvent) {
        aB.a(blockPlaceEvent);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(CreatureSpawnEvent creatureSpawnEvent) {
        aC.a(creatureSpawnEvent);
    }

    @EventHandler
    public void a(PlayerTeleportEvent playerTeleportEvent) {
        be.a(playerTeleportEvent);
    }

    @EventHandler
    public void a(InventoryOpenEvent inventoryOpenEvent) {
        aN.a(inventoryOpenEvent);
    }

    @EventHandler
    public void a(FoodLevelChangeEvent foodLevelChangeEvent) {
        aI.a(foodLevelChangeEvent);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(PlayerPickupItemEvent playerPickupItemEvent) {
        ba.b(playerPickupItemEvent);
    }

    @EventHandler
    public void a(PlayerInteractEvent playerInteractEvent) {
        aV.a(playerInteractEvent);
    }

    @EventHandler
    public void a(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        aE.a(entityDamageByEntityEvent);
    }

    @EventHandler
    public void a(EntityDamageEvent entityDamageEvent) {
        aD.a(entityDamageEvent);
    }

    @EventHandler
    public void a(PlayerMoveEvent playerMoveEvent) {
        aZ.a(playerMoveEvent);
    }

    @EventHandler
    public void a(PlayerToggleFlightEvent playerToggleFlightEvent) {
        bf.a(playerToggleFlightEvent);
    }

    @EventHandler
    public void a(PlayerGameModeChangeEvent playerGameModeChangeEvent) {
        aU.a(playerGameModeChangeEvent);
    }

    @EventHandler
    public void a(PlayerDropItemEvent playerDropItemEvent) {
        aS.a(playerDropItemEvent);
    }

    @EventHandler
    public void a(EntityExplodeEvent entityExplodeEvent) {
        aG.a(entityExplodeEvent);
    }

    @EventHandler
    public void a(ServerListPingEvent serverListPingEvent) {
        ax.a(serverListPingEvent);
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(AsyncPlayerChatEvent asyncPlayerChatEvent) {
        aP.a(asyncPlayerChatEvent);
    }

    @EventHandler
    public void a(PlayerExpChangeEvent playerExpChangeEvent) {
        aT.a(playerExpChangeEvent);
    }

    @EventHandler
    public void a(WeatherChangeEvent weatherChangeEvent) {
        bi.a(weatherChangeEvent);
    }

    @EventHandler
    public void a(EntityTeleportEvent entityTeleportEvent) {
        aH.a(entityTeleportEvent);
    }

    @EventHandler
    public void a(PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        aQ.a(playerCommandPreprocessEvent);
    }

    @EventHandler
    public void a(WorldLoadEvent worldLoadEvent) {
        bj.a(worldLoadEvent);
    }

    @EventHandler
    public void a(ChunkLoadEvent chunkLoadEvent) {
        bg.a(chunkLoadEvent);
    }

    @EventHandler
    public void a(PlayerPortalEvent playerPortalEvent) {
        bb.a(playerPortalEvent);
    }

    @EventHandler
    public void a(PlayerBedEnterEvent playerBedEnterEvent) {
        aO.a(playerBedEnterEvent);
    }

    @EventHandler
    public void a(CraftItemEvent craftItemEvent) {
        aJ.a(craftItemEvent);
    }

    @EventHandler
    public void a(ChunkUnloadEvent chunkUnloadEvent) {
        bh.b(chunkUnloadEvent);
    }

    @EventHandler
    public void a(PluginDisableEvent pluginDisableEvent) {
        aw.a(pluginDisableEvent);
    }
}

