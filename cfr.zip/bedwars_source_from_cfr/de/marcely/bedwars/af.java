/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.d;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

@Deprecated
public class af {
    private static final int w = 59;
    private static final String URL = "http://mbedwars.marcely.de/versions.req?bwv={bwversion}&mcv={mcversion}&ip={ip}&mac={mac}";
    private static boolean n = false;

    public static void update() {
        af.c(true);
    }

    public static void c(boolean bl2) {
        af.a(3, bl2);
    }

    public static void a(final int n2, final boolean bl2) {
        n = true;
        if (n2 <= 0) {
            d.b("=============================");
            d.b("Sorry, but we were unable to identify your version.");
            d.b("Please try it again with a working internet connection!");
            d.b("============================");
            n = false;
            return;
        }
        MThread mThread = new MThread(MThread.ThreadType.e){

            @Override
            public void run() {
                try {
                    String string = MBedwars.getVersion();
                    String string2 = Version.a().a().name();
                    String string3 = String.valueOf(Bukkit.getIp()) + ":" + Bukkit.getPort();
                    s.sleep(200L);
                    HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(af.URL.replace("{bwversion}", string).replace("{mcversion}", string2).replace("{ip}", string3).replace("{mac}", s.t())).openConnection();
                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    httpURLConnection.connect();
                    s.sleep(50L);
                    if (httpURLConnection.getResponseCode() == 200) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        MBedwars mBedwars = MBedwars.a;
                        String string4 = null;
                        while ((string4 = bufferedReader.readLine()) != null) {
                            if (!string4.equals("59")) continue;
                            af.d(false);
                            return;
                        }
                        d.b("=============================");
                        d.b("It seems like that your current version (" + MBedwars.getVersion() + ") is outdated.");
                        d.b("Please install the latest version to fix that!");
                        d.b("============================");
                        MBedwars.a = MBedwars.PluginState.f;
                        af.d(false);
                        MBedwars.a.getCommands().clear();
                        s.Y = null;
                        s.Z = null;
                        new BukkitRunnable((Plugin)mBedwars){
                            private final /* synthetic */ Plugin a;
                            {
                                this.a = plugin;
                            }

                            public void run() {
                                Bukkit.getPluginManager().disablePlugin(this.a);
                            }
                        }.runTask((Plugin)mBedwars);
                    } else {
                        af.a(n2 - 1, bl2);
                    }
                }
                catch (IOException iOException) {
                    af.a(n2 - 1, bl2);
                }
            }

        };
        if (bl2) {
            mThread.start();
        } else {
            mThread.run();
        }
    }

    public static boolean q() {
        return n;
    }

    static /* synthetic */ void d(boolean bl2) {
        n = bl2;
    }

}

