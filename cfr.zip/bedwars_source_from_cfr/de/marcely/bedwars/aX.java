/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.player.PlayerEvent
 *  org.bukkit.event.player.PlayerInteractEntityEvent
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.api.ExtraItemListener;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.IEntity;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.shop.Shop;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;

public class aX {
    public static Map<IEntity, GUI> i = new HashMap<IEntity, GUI>();

    public static void a(PlayerInteractEntityEvent playerInteractEntityEvent) {
        Entity entity = playerInteractEntityEvent.getRightClicked();
        Player player = playerInteractEntityEvent.getPlayer();
        if (entity == null || player == null) {
            return;
        }
        Arena arena = s.a(player);
        if (cA.E.containsKey((Object)player)) {
            playerInteractEntityEvent.setCancelled(true);
            return;
        }
        if (entity.getType().toString().equals("ARMOR_STAND")) {
            for (RankingStatue rankingStatue : s.ad) {
                if (rankingStatue.b() == null || rankingStatue.b().getEntityId() != entity.getEntityId()) continue;
                playerInteractEntityEvent.setCancelled(true);
                return;
            }
        }
        if (entity.getType() == EntityType.VILLAGER && arena != null) {
            playerInteractEntityEvent.setCancelled(true);
            if (arena.b() == ArenaStatus.f && entity.getType() == EntityType.VILLAGER) {
                Shop.eOpen(player, arena, entity.hasMetadata("mbw_isMinishop") ? ShopOpenType.MINISHOP : ShopOpenType.VILLAGER);
            }
        }
        if (arena != null) {
            if (arena.b().F()) {
                playerInteractEntityEvent.setCancelled(true);
            } else if (arena.b() == ArenaStatus.f) {
                RankingStatue rankingStatue;
                if (playerInteractEntityEvent.isCancelled()) {
                    return;
                }
                rankingStatue = player.getItemInHand();
                ExtraItem extraItem = s.a(player, (ItemStack)rankingStatue);
                if (extraItem != null) {
                    PlayerUseExtraItemEvent playerUseExtraItemEvent = new PlayerUseExtraItemEvent(extraItem, arena, (PlayerEvent)playerInteractEntityEvent, (ItemStack)rankingStatue);
                    Bukkit.getPluginManager().callEvent((Event)playerUseExtraItemEvent);
                    if (playerUseExtraItemEvent.isCancelled()) {
                        return;
                    }
                    playerInteractEntityEvent.setCancelled(true);
                    for (ExtraItemListener extraItemListener : extraItem.getListeners()) {
                        try {
                            extraItemListener.onUse(playerUseExtraItemEvent);
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    public static void t() {
        for (Map.Entry<IEntity, GUI> entry : i.entrySet()) {
            IEntity iEntity = entry.getKey();
            GUI gUI = entry.getValue();
            ArrayList<Arena> arrayList = new ArrayList<Arena>();
            for (int i2 = 0; i2 < gUI.getHeight() * 9; ++i2) {
                Arena arena;
                GUIItem gUIItem = gUI.getItemAt(i2);
                if (gUIItem == null || gUIItem.getItemStack() == null) continue;
                String string = r.removeChatColor(i.b(gUIItem.getItemStack()));
                if (i.b(gUIItem.getItemStack()).equals("") || (arena = s.b(string)) == null) continue;
                arrayList.add(arena);
            }
            aX.a(iEntity, arrayList, gUI.getTitle().substring(ConfigValue.lobbyvillager_prefix.length()));
        }
    }

    public static GUI a(IEntity iEntity, List<Arena> list, String string) {
        GUI gUI = aX.a(iEntity);
        if (gUI == null) {
            gUI = new GUI(String.valueOf(ConfigValue.lobbyvillager_prefix) + string, 0);
            i.put(iEntity, gUI);
        } else {
            gUI.clear();
        }
        for (final Arena arena : list) {
            List<String> list2 = arena.o();
            gUI.addItem(new GUIItem(i.a(i.a(arena.getIcon(), (Object)ChatColor.UNDERLINE + arena.getDisplayName()), list2.toArray(new String[list2.size()]))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    String string = s.b(player, arena);
                    if (string != null) {
                        player.sendMessage(string);
                    }
                }
            });
            if (!ConfigValue.gui_hubvillager_centered) continue;
            gUI.centerAtYAll(GUI.CenterFormatType.Beautiful);
        }
        return gUI;
    }

    private static GUI a(IEntity iEntity) {
        for (Map.Entry<IEntity, GUI> entry : new ArrayList<Map.Entry<IEntity, GUI>>(i.entrySet())) {
            if (entry.getKey().a() != null) {
                if (!entry.getKey().equals(iEntity)) continue;
                return entry.getValue();
            }
            s.b(entry.getKey());
        }
        return null;
    }

}

