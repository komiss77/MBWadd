/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.game.shop.ShopDesignType;
import de.marcely.bedwars.util.s;
import de.marcely.configmanager2.ConfigManager;
import java.io.File;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class ao {
    public static ConfigManager a = new ConfigManager(s.A);
    public static ShopDesignData a = ShopDesignType.Normal.getData();
}

