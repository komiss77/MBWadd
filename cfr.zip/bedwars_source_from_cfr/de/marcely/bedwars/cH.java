/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.util.s;
import java.util.Random;

public class cH
extends h {
    public String name = "";
    public int id = s.RAND.nextInt(16);
    public boolean V;

    public cH a(String string) {
        this.name = string;
        return this;
    }

    public cH a(int n2) {
        this.id = n2;
        return this;
    }
}

