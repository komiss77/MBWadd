/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.bP;
import de.marcely.bedwars.bS;
import de.marcely.bedwars.bU;
import de.marcely.bedwars.bW;
import de.marcely.bedwars.bX;
import de.marcely.bedwars.bY;
import de.marcely.bedwars.ca;
import de.marcely.bedwars.cb;
import de.marcely.bedwars.cc;
import de.marcely.bedwars.cd;
import de.marcely.bedwars.ce;
import de.marcely.bedwars.cf;
import de.marcely.bedwars.cg;
import de.marcely.bedwars.ci;
import de.marcely.bedwars.cj;
import de.marcely.bedwars.ck;
import de.marcely.bedwars.cl;
import de.marcely.bedwars.cn;
import de.marcely.bedwars.co;
import de.marcely.bedwars.cp;
import de.marcely.bedwars.cq;
import de.marcely.bedwars.cr;
import de.marcely.bedwars.cs;
import de.marcely.bedwars.cu;
import de.marcely.bedwars.cv;
import de.marcely.bedwars.cw;
import de.marcely.bedwars.cx;
import de.marcely.bedwars.cy;

public class bQ
extends bP {
    @Override
    protected void a(bP.b b2) {
        this.a(b2, "arena", bY.a);
        this.a(b2, "players", ca.a);
        this.a(b2, "maxplayers", bW.a);
        this.a(b2, "teams", cb.a);
        this.a(b2, "maxplayersinteam", bX.a);
        this.a(b2, "countdown", bU.a);
        this.a(b2, "stats:rank", cv.a);
        this.a(b2, "stats:wins", cy.a);
        this.a(b2, "stats:loses", cs.a);
        this.a(b2, "stats:kills", cr.a);
        this.a(b2, "stats:deaths", cp.a);
        this.a(b2, "stats:bedsdestroyed", co.a);
        this.a(b2, "stats:roundsplayed", cw.a);
        this.a(b2, "stats:playtime", cu.a);
        this.a(b2, "stats:kd", cq.a);
        this.a(b2, "stats:wl", cx.a);
        this.a(b2, "gstats:kills", cg.a);
        this.a(b2, "gstats:deaths", ce.a);
        this.a(b2, "gstats:bedsdestroyed", cd.a);
        this.a(b2, "gstats:kd", cf.a);
        this.a(b2, "server:onlineplayers", cn.a);
        this.a(b2, "ip", ci.a);
        this.a(b2, "date", cc.a);
        this.a(b2, "team", cl.a);
        this.a(b2, "teamcolor", ck.a);
        this.a(b2, "bedstate", cj.a);
    }
}

