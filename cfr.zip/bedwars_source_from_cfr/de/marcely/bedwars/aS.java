/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerDropItemEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.Map;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerDropItemEvent;

public class aS {
    public static void a(PlayerDropItemEvent playerDropItemEvent) {
        Player player = playerDropItemEvent.getPlayer();
        Arena arena = s.a(player);
        if (arena != null && arena.b().F() || cA.E.containsKey((Object)player)) {
            playerDropItemEvent.setCancelled(true);
        } else if (!GUI.openInventories.containsKey((Object)player) && GUI.openInventoriesDelayed.containsKey((Object)player) && ((SimpleGUI)GUI.openInventoriesDelayed.get((Object)player)).hasAntiDrop()) {
            playerDropItemEvent.getItemDrop().remove();
        }
    }
}

