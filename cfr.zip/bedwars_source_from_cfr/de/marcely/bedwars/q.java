/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.j;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class q
extends j {
    private Arena arena;

    public q(Arena arena) {
        this.arena = arena;
    }

    public Arena getArena() {
        return this.arena;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.f.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.arena.b().getID() + "/" + this.arena.getPlayers().size() + "/" + this.arena.getMaxPlayers() + "/" + this.arena.getIcon().getType().name() + ":" + this.arena.getIcon().getDurability() + "/" + this.arena.n().replace("/", "&sKEYslash;") + "/" + this.arena.a().r().size() + "/" + this.arena.getTeamPlayers();
    }
}

