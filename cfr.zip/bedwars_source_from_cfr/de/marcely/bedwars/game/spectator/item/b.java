/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.game.spectator.item.ChangeSpeedItemHandler;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.c;
import de.marcely.bedwars.game.spectator.item.d;
import de.marcely.bedwars.game.spectator.item.e;

public enum b {
    b("tpto-player", true),
    c("change-speed", true),
    d("leave", false),
    e("leave-nextround", false);
    
    private final String identifier;
    private final boolean Q;
    private static /* synthetic */ int[] o;

    private b(String string2, boolean bl2) {
        this.identifier = string2;
        this.Q = bl2;
    }

    public a a() {
        switch (b.p()[this.ordinal()]) {
            case 1: {
                return new e();
            }
            case 2: {
                return new ChangeSpeedItemHandler();
            }
            case 3: {
                return new c();
            }
            case 4: {
                return new d();
            }
        }
        return null;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public boolean K() {
        return this.Q;
    }

    static /* synthetic */ int[] p() {
        if (o != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[b.values().length];
        try {
            arrn[b.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[b.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[b.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[b.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        o = arrn;
        return o;
    }
}

