/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.KickReason;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.b;
import de.marcely.bedwars.util.s;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class d
extends a {
    public d() {
        super(b.e);
    }

    @Override
    protected void a(Player player, SpectatorItem spectatorItem, Arena arena) {
        Arena arena2 = s.c();
        if (arena2 != null) {
            if (arena.getPlayers().contains((Object)player)) {
                arena.kickPlayer(player, KickReason.Leave);
            } else {
                cA.a(player, cD.f);
            }
            String string = s.b(player, arena2);
            if (string != null) {
                player.sendMessage(string);
            }
        } else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Spectator_ChangeArena_NoneAvailable));
        }
    }
}

