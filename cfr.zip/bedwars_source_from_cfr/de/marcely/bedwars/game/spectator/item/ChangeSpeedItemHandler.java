/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.b;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class ChangeSpeedItemHandler
extends a {
    public ChangeSpeedItemHandler() {
        super(b.c);
    }

    @Override
    protected void a(Player player, SpectatorItem spectatorItem, Arena arena) {
        if (ConfigValue.spectator_changespeed_types.size() == 0) {
            return;
        }
        SpeedType speedType = ChangeSpeedItemHandler.a(player.getFlySpeed());
        if (speedType != null) {
            speedType = ChangeSpeedItemHandler.a(speedType);
        } else {
            ConfigValue.spectator_changespeed_types.get(0);
        }
        String string = "";
        for (int i2 = 0; i2 < ConfigValue.spectator_changespeed_types.size(); ++i2) {
            SpeedType speedType2 = ConfigValue.spectator_changespeed_types.get(i2);
            string = speedType2.equals(speedType) ? String.valueOf(string) + speedType2.name : String.valueOf(string) + (Object)ChatColor.GRAY + r.removeChatColor(speedType2.name);
            if (i2 + 1 >= ConfigValue.spectator_changespeed_types.size()) continue;
            string = String.valueOf(string) + (Object)ChatColor.BLACK + " | ";
        }
        player.setFlySpeed(s.a(speedType.h));
        Version.a().b(player, string);
    }

    @Nullable
    private static SpeedType a(float f2) {
        for (SpeedType speedType : ConfigValue.spectator_changespeed_types) {
            if (s.a(speedType.h) != f2) continue;
            return speedType;
        }
        return null;
    }

    private static SpeedType a(SpeedType speedType) {
        int n2 = ConfigValue.spectator_changespeed_types.indexOf(speedType) + 1;
        if (n2 >= ConfigValue.spectator_changespeed_types.size()) {
            n2 = 0;
        }
        return ConfigValue.spectator_changespeed_types.get(n2);
    }

    public static class SpeedType {
        public final String name;
        public final float h;

        public SpeedType(String string, float f2) {
            this.name = string;
            this.h = f2;
        }
    }

}

