/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.cC;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.b;
import org.bukkit.entity.Player;

public abstract class a
extends cC {
    private final b a;

    public a(b b2) {
        super(b2.getIdentifier());
        this.a = b2;
    }

    protected abstract void a(Player var1, SpectatorItem var2, Arena var3);

    @Override
    public void onUse(Player player, SpectatorItem spectatorItem, de.marcely.bedwars.api.Arena arena) {
        this.a(player, spectatorItem, (Arena)arena);
    }

    @Override
    public boolean a(Player player, SpectateReason spectateReason) {
        return this.a.K();
    }

    public b a() {
        return this.a;
    }
}

