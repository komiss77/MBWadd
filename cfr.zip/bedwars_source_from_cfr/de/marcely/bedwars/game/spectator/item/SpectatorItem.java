/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.cC;
import de.marcely.bedwars.message.b;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class SpectatorItem {
    private final int slot;
    private final ItemStack item;
    private final String name;
    private final String J;
    private final cC a;

    public SpectatorItem(int n2, ItemStack itemStack, String string, cC cC2) {
        this(n2, itemStack, string, cC2, true);
    }

    public SpectatorItem(int n2, ItemStack itemStack, String string, cC cC2, boolean bl2) {
        this.slot = n2;
        this.item = itemStack;
        this.name = string;
        this.J = b.a(string).b().c().f(null);
        this.a = cC2;
    }

    public int getSlot() {
        return this.slot;
    }

    public ItemStack getItem() {
        return this.item;
    }

    public String getName() {
        return this.name;
    }

    public String q() {
        return this.J;
    }

    public cC a() {
        return this.a;
    }
}

