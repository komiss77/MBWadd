/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.Sound;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.b;
import org.bukkit.entity.Player;

public class c
extends a {
    public c() {
        super(b.d);
    }

    @Override
    protected void a(Player player, SpectatorItem spectatorItem, Arena arena) {
        Sound.LOBBY_LEAVE.play(player);
        cA.a(player, cD.b);
    }
}

