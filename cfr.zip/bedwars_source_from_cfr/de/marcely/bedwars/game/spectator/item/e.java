/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.be;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.spectator.item.a;
import de.marcely.bedwars.game.spectator.item.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class e
extends a {
    public e() {
        super(b.b);
    }

    @Override
    protected void a(Player player, SpectatorItem spectatorItem, final Arena arena) {
        GUI gUI = new GUI(de.marcely.bedwars.message.b.a(Language.GUI_Spectator_Teleporter).f((CommandSender)player), 1);
        for (final Player player2 : arena.getPlayers()) {
            Team team = arena.a(player2);
            gUI.addItem(new GUIItem(i.a(i.a(player2.getName(), 1), (Object)team.getChatColor() + s.getPlayerDisplayName(player2))){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    Arena arena2;
                    if (player2.isOnline() && (arena2 = s.a(player2)) != null && arena2.equals(arena)) {
                        be.D.add(player);
                        player.teleport(player2.getLocation());
                    }
                }
            });
        }
        if (ConfigValue.gui_spectatortp_centered) {
            gUI.centerAtYAll(GUI.CenterFormatType.Normal);
        }
        gUI.setBackground(new DecGUIItem(i.a(ConfigValue.gui_spectatortp_backgroundmaterial, " ")));
        gUI.open(player);
    }

}

