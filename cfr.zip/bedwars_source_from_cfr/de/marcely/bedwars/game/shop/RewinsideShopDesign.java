/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.api.gui.VillagerGUI;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.ShopVillagerGUIBuilder;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class RewinsideShopDesign
extends ShopDesign {
    private HashMap<Player, Boolean> usingNewOne = new HashMap();

    @Override
    public SimpleShopGUIBuilder open(final ShopDesign.OpenEvent openEvent) {
        if (openEvent.getOpen() != null && !this.playerIsUsingNewOne(openEvent.getPlayer())) {
            ShopVillagerGUIBuilder shopVillagerGUIBuilder = new ShopVillagerGUIBuilder(openEvent);
            for (ShopItem n2 : this.getShopItems(openEvent)) {
                ShopPrice shopPrice = n2.getPrices().get(0);
                if (n2.getProducts().size() == 1) {
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(n2.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()))));
                } else {
                    ShopPrice shopPrice2 = n2.getPrices().get(1);
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(n2.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount())), new DecGUIItem(i.a(shopPrice2.getSpawner().getActualItemstack(), shopPrice2.getAmount()))));
                }
                if (n2.getProducts().size() >= 2) {
                    d.d("The Rewinside old shop design only displays 1 product per item!", "Shop");
                }
                if (n2.getPrices().size() < 3) continue;
                d.d("The Rewinside old shop design only displays 1 or 2 prices per item!", "Shop");
            }
            return shopVillagerGUIBuilder;
        }
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
        }
        for (ShopPage shopPage : openEvent.getPages()) {
            shopGUIBuilder.addItem(shopPage);
        }
        if (openEvent.getOpen() != null) {
            int n2 = shopGUIBuilder.getHeight();
            for (ShopItem shopItem : this.getShopItems(openEvent)) {
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithinY(n2, 6));
            }
        } else {
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            shopGUIBuilder.setItemAt(new GUIItem(i.a(i.a(new ItemStack(Material.SLIME_BALL), this.playerIsUsingNewOne(openEvent.getPlayer()) ? b.a(Language.Shop_D_Rewinside_ShopType_New).f((CommandSender)openEvent.getPlayer()) : b.a(Language.Shop_D_Rewinside_ShopType_Old).f((CommandSender)openEvent.getPlayer())), new String[]{b.a(Language.Shop_D_Rewinside_ShopType_Switch).f((CommandSender)openEvent.getPlayer())})){

                @Override
                public void onClick(Player player, boolean bl2, boolean bl3) {
                    RewinsideShopDesign.this.usingNewOne.put(player, !RewinsideShopDesign.this.playerIsUsingNewOne(player));
                    openEvent.refresh();
                }
            }, 4, shopGUIBuilder.getHeight() - 1);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal);
        return shopGUIBuilder;
    }

    private List<ShopItem> getShopItems(ShopDesign.OpenEvent openEvent) {
        for (ShopItem shopItem : openEvent.getOpen().getItems()) {
            ArrayList<String> arrayList = new ArrayList<String>();
            arrayList.add("");
            for (ShopPrice shopPrice : shopItem.getPrices()) {
                arrayList.add(" " + (Object)ChatColor.GRAY + shopPrice.getPrice(openEvent.getPlayer()) + " " + (Object)shopPrice.getSpawner().getChatColor() + shopPrice.getSpawner().getName(true));
            }
            shopItem.setIcon(i.a(shopItem.getIcon(), arrayList));
        }
        return openEvent.getOpen().getItems();
    }

    private boolean playerIsUsingNewOne(Player player) {
        if (!this.usingNewOne.containsKey((Object)player)) {
            return true;
        }
        return this.usingNewOne.get((Object)player);
    }

}

