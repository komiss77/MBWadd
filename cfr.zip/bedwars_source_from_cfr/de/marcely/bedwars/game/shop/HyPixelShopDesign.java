/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class HyPixelShopDesign
extends ShopDesign {
    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null) {
            for (ShopPage shopPage : openEvent.getPages()) {
                ArrayList<String> arrayList = new ArrayList<String>();
                arrayList.add(b.a(Language.Shop_D_HyPixel_Avaible).f((CommandSender)openEvent.getPlayer()));
                for (ShopItem shopItem : shopPage.getItems()) {
                    arrayList.add((Object)ChatColor.DARK_GRAY + " \u2022 " + (Object)ChatColor.GRAY + shopItem.getDisplayName());
                }
                arrayList.add("");
                arrayList.add(b.a(Language.Shop_D_HyPixel_ClickToBrowse).f((CommandSender)openEvent.getPlayer()));
                shopPage.setIcon(i.a(shopPage.getIcon(), arrayList));
                shopGUIBuilder.addItem(shopPage, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        } else {
            for (ShopItem shopItem : openEvent.getOpen().getItems()) {
                if (shopItem.getPrices().size() >= 2) {
                    d.d("The HyPixel shop design only displays 1 price per item!", "Shop");
                }
                ArrayList<String> arrayList = new ArrayList<String>();
                ShopPrice shopPrice = shopItem.getPrices().get(0);
                arrayList.add(b.a(Language.Shop_D_HyPixel_Items).f((CommandSender)openEvent.getPlayer()));
                for (ShopProduct shopProduct : shopItem.getProducts()) {
                    arrayList.add((Object)ChatColor.DARK_GRAY + " \u2022 " + (Object)ChatColor.GRAY + shopProduct.getDisplayName() + (Object)ChatColor.DARK_GRAY + " x" + shopProduct.getAmount());
                }
                arrayList.add("");
                arrayList.add(b.a(Language.Shop_D_HyPixel_Cost).a("amount", "" + shopPrice.getPrice(openEvent.getPlayer())).a("type", shopPrice.getSpawner().getName(true)).a("color", "" + (shopPrice.getSpawner().getChatColor() != null ? shopPrice.getSpawner().getChatColor() : "")).f((CommandSender)openEvent.getPlayer()));
                arrayList.add("");
                arrayList.add(b.a(shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) > 0 ? Language.Shop_D_HyPixel_ClickToPurchase : Language.Shop_D_HyPixel_TooExpensive).a("amount", "" + shopPrice.getPrice(openEvent.getPlayer())).a("type", shopPrice.getSpawner().getName(true)).a("color", "" + (shopPrice.getSpawner().getChatColor() != null ? shopPrice.getSpawner().getChatColor() : "")).f((CommandSender)openEvent.getPlayer()));
                shopItem.setIcon(i.a(shopItem.getIcon(), arrayList));
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            shopGUIBuilder.setHomeItemAt(i.a(new ItemStack(Material.ARROW), b.a(Language.Shop_D_HyPixel_GoBack).f((CommandSender)openEvent.getPlayer())), 4, shopGUIBuilder.getHeight() - 1);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
        return shopGUIBuilder;
    }
}

