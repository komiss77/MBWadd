/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.game.shop.ShopPage;

public abstract class SimpleShopGUIBuilder {
    ShopPage openPage;

    public abstract SimpleGUI export();

    public ShopPage getOpenPage() {
        return this.openPage;
    }

    public void setOpenPage(ShopPage shopPage) {
        this.openPage = shopPage;
    }
}

