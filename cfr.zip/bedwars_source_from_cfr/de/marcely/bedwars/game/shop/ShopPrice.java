/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Permission;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ShopPrice
implements Cloneable {
    private ShopItem item;
    @Nullable
    private DropType spawner = null;
    private int amount = 1;
    @Nullable
    private Integer amountPerm = null;

    public ShopPrice(ShopItem shopItem) {
        this.item = shopItem;
    }

    public int getPrice(Player player) {
        return this.amountPerm != null && s.hasPermission((CommandSender)player, Permission.ShopCustomPrice) ? this.amountPerm : this.amount;
    }

    public int getAmountPlayerCanBuy(Player player, boolean bl2) {
        if (this.getSpawner().getActualItemstack() != null && this.getSpawner().getActualItemstack().getType() != null && this.getSpawner().getActualItemstack().getType() != Material.AIR) {
            int n2 = s.a(player, i.a(this.getSpawner().getActualItemstack().clone(), (Object)this.getSpawner().getChatColor() + this.getSpawner().getName(true)));
            if (n2 >= this.getPrice(player)) {
                int n3 = 1;
                if (bl2) {
                    n3 = n2 / this.amount;
                }
                if (n3 > this.item.getCapsMultiply()) {
                    n3 = this.item.getCapsMultiply();
                }
                return n3;
            }
            return 0;
        }
        return 0;
    }

    public ShopPrice clone() {
        try {
            ShopPrice shopPrice = (ShopPrice)super.clone();
            shopPrice.spawner = this.spawner.b();
            return shopPrice;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public ShopItem getItem() {
        return this.item;
    }

    public void setItem(ShopItem shopItem) {
        this.item = shopItem;
    }

    @Nullable
    public DropType getSpawner() {
        return this.spawner;
    }

    public void setSpawner(@Nullable DropType dropType) {
        this.spawner = dropType;
    }

    public int getAmount() {
        return this.amount;
    }

    public void setAmount(int n2) {
        this.amount = n2;
    }

    @Nullable
    public Integer getAmountPerm() {
        return this.amountPerm;
    }

    public void setAmountPerm(@Nullable Integer n2) {
        this.amountPerm = n2;
    }
}

