/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopItemProduct;
import de.marcely.bedwars.game.shop.ShopSpecialProduct;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public abstract class ShopProduct
implements Cloneable {
    protected ShopItem item;
    private int amount = 1;
    private boolean autoWear = false;

    public ShopProduct(ShopItem shopItem) {
        this.item = shopItem;
    }

    public abstract ItemStack getItemStack();

    public abstract String getDisplayName();

    public abstract String getIdentifier();

    protected abstract ItemStack postPrepareGive(Player var1, ItemStack var2);

    public void give(Player player, Team team, int n2, Arena arena) {
        this.give(player, n2, arena.a(player, team, this.getItemStack()), team);
    }

    public ItemStack getGiveItem(Player player, Team team, int n2, Arena arena) {
        return this.getGiveItem(player, n2, arena.a(player, team, this.getItemStack()), team);
    }

    public ItemStack getGiveItem(ItemStack itemStack, Player player, Team team, int n2, Arena arena) {
        return this.getGiveItem(itemStack, player, n2, arena.a(player, team, this.getItemStack()), team);
    }

    public void give(Player player, int n2, Map<Enchantment, Integer> map, Team team) {
        ItemStack itemStack = this.getGiveItem(player, n2 * this.getAmount(), map, team);
        if (!this.autoWear || !s.a(player, itemStack, true)) {
            s.a(player, itemStack);
        }
    }

    public ItemStack getGiveItem(Player player, int n2, Map<Enchantment, Integer> map, Team team) {
        return this.getGiveItem(null, player, n2, map, team);
    }

    public ItemStack getGiveItem(@Nullable ItemStack itemStack, Player player, int n2, Map<Enchantment, Integer> map, Team team) {
        boolean bl2;
        boolean bl3 = bl2 = itemStack == null;
        if (itemStack == null) {
            itemStack = this.getItemStack();
        }
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemStack.setAmount(n2);
        if (!this.item.getDisplayName().isEmpty()) {
            itemMeta.setDisplayName((Object)ChatColor.WHITE + this.item.getDisplayName());
        }
        for (Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            if (bl2) {
                entry.setValue(entry.getValue() + itemStack.getEnchantmentLevel(entry.getKey()));
            }
            itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), true);
        }
        itemStack.setItemMeta(itemMeta);
        if (ConfigValue.dye_block) {
            itemStack = i.a(itemStack, team);
        }
        return this.postPrepareGive(player, itemStack);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Nullable
    public static ShopProduct newInstance(String string, ShopItem shopItem) {
        String string2 = string;
        switch (string2.hashCode()) {
            case -2008465223: {
                if (string2.equals("special")) return new ShopSpecialProduct(shopItem);
                return null;
            }
            case 3242771: {
                if (!string2.equals("item")) return null;
                return new ShopItemProduct(shopItem);
            }
        }
        return null;
    }

    public ShopProduct clone() {
        try {
            return (ShopProduct)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public ShopItem getItem() {
        return this.item;
    }

    public void setItem(ShopItem shopItem) {
        this.item = shopItem;
    }

    public int getAmount() {
        return this.amount;
    }

    public void setAmount(int n2) {
        this.amount = n2;
    }

    public boolean isAutoWear() {
        return this.autoWear;
    }

    public void setAutoWear(boolean bl2) {
        this.autoWear = bl2;
    }
}

