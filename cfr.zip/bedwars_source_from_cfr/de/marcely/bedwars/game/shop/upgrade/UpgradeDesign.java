/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.upgrade.SimpleUpgradeGUIBuilder;
import de.marcely.bedwars.game.shop.upgrade.UpgradeItem;
import java.util.List;
import org.bukkit.entity.Player;

public abstract class UpgradeDesign {
    public ShopDesign.ClickListener listener;

    public abstract SimpleUpgradeGUIBuilder open(OpenEvent var1);

    public static class OpenEvent {
        private final UpgradeDesign design;
        private final Player player;
        private final List<UpgradeItem> items;

        public OpenEvent(UpgradeDesign upgradeDesign, Player player, List<UpgradeItem> list) {
            this.design = upgradeDesign;
            this.player = player;
            this.items = list;
        }

        public UpgradeDesign getDesign() {
            return this.design;
        }

        public Player getPlayer() {
            return this.player;
        }

        public List<UpgradeItem> getItems() {
            return this.items;
        }
    }

}

