/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;

public class UpgradeTypeConfig {
    private final DefaultUpgradeType type;
    private String name = "";
    private String lore = "";

    public UpgradeTypeConfig(DefaultUpgradeType defaultUpgradeType) {
        this.type = defaultUpgradeType;
    }

    public DefaultUpgradeType getType() {
        return this.type;
    }

    public String getName() {
        return this.name;
    }

    public String getLore() {
        return this.lore;
    }

    public void setName(String string) {
        this.name = string;
    }

    public void setLore(String string) {
        this.lore = string;
    }
}

