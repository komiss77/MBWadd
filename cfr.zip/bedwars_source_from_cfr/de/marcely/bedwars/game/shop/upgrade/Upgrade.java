/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.upgrade.UpgradeEnchantment;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Upgrade {
    private final UpgradeType type;
    private final int lvl;
    private final DropType price;
    private final int priceAmount;
    private final ItemStack icon;
    private final Value<?> value;
    private List<UpgradeEnchantment> enchantments = null;
    private String name = null;
    private String lore = null;
    int maxLvl;

    public Upgrade(UpgradeType upgradeType, int n2, ItemStack itemStack, DropType dropType, int n3, @Nullable Value<?> value) {
        this.type = upgradeType;
        this.lvl = n2;
        this.icon = itemStack;
        this.price = dropType;
        this.priceAmount = n3;
        this.value = value;
    }

    public ItemStack getIcon() {
        return this.icon.clone();
    }

    public boolean canBuy(Player player) {
        if (this.price == null) {
            return false;
        }
        int n2 = s.a(player, i.a(this.price.getActualItemstack(), (Object)this.price.getChatColor() + this.price.getName(true)));
        return n2 >= this.priceAmount;
    }

    @Nullable
    public Upgrade getNextLevel() {
        return this.lvl < this.maxLvl ? s.a(this.type, this.lvl + 1) : null;
    }

    public UpgradeType getType() {
        return this.type;
    }

    public int getLvl() {
        return this.lvl;
    }

    public DropType getPrice() {
        return this.price;
    }

    public int getPriceAmount() {
        return this.priceAmount;
    }

    public Value<?> getValue() {
        return this.value;
    }

    public List<UpgradeEnchantment> getEnchantments() {
        return this.enchantments;
    }

    public void setEnchantments(List<UpgradeEnchantment> list) {
        this.enchantments = list;
    }

    public String getName() {
        return this.name;
    }

    public String getLore() {
        return this.lore;
    }

    public void setName(String string) {
        this.name = string;
    }

    public void setLore(String string) {
        this.lore = string;
    }

    public int getMaxLvl() {
        return this.maxLvl;
    }

    public void setMaxLvl(int n2) {
        this.maxLvl = n2;
    }

    public static class UpgradeBuilder {
        public UpgradeType type;
        public int lvl;
        public ItemStack icon;
        public DropType price;
        public int priceAmount;
        public Value<?> value;
        public List<UpgradeEnchantment> enchantments = new ArrayList<UpgradeEnchantment>();
        public String name = null;
        public String lore = null;

        public void setValue(String string) throws Exception {
            this.value = this.type.getValueClass().newInstance();
            this.value.t(string);
        }

        @Nullable
        public Upgrade build() {
            Upgrade upgrade = new Upgrade(this.type, this.lvl, this.icon, this.price, this.priceAmount, this.value);
            upgrade.setEnchantments(this.enchantments);
            if (this.name != null) {
                upgrade.setName(this.name);
            }
            if (this.lore != null) {
                upgrade.setLore(this.lore);
            }
            return upgrade;
        }
    }

}

