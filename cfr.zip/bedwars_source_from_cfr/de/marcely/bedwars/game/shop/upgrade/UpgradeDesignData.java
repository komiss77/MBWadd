/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.bo;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesignType;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;

public class UpgradeDesignData {
    private final UpgradeDesign design;
    private final String name;
    private final int id;
    private final UpgradeDesignType type;
    private static final List<UpgradeDesignData> designs = new ArrayList<UpgradeDesignData>();

    public UpgradeDesignData(UpgradeDesign upgradeDesign, String string) {
        this(upgradeDesign, string, -1, UpgradeDesignType.Custom);
    }

    @Deprecated
    public UpgradeDesignData(UpgradeDesign upgradeDesign, String string, int n2, UpgradeDesignType upgradeDesignType) {
        this.design = upgradeDesign;
        this.name = string;
        this.id = n2;
        this.type = upgradeDesignType;
    }

    public boolean register() {
        if (designs.contains(this)) {
            return false;
        }
        return designs.add(this);
    }

    public boolean unregister() {
        if (!this.isCustom()) {
            new bo("Only works for custom designs!").printStackTrace();
            return false;
        }
        return designs.remove(this);
    }

    public boolean isCustom() {
        return this.type == UpgradeDesignType.Custom;
    }

    public static UpgradeDesignData getDesignByName(String string) {
        UpgradeDesignData upgradeDesignData2;
        if (s.isInteger(string) && (upgradeDesignData2 = UpgradeDesignData.getDesignByID(Integer.valueOf(string))) != null) {
            return upgradeDesignData2;
        }
        for (UpgradeDesignData upgradeDesignData2 : designs) {
            if (!upgradeDesignData2.name.equalsIgnoreCase(string)) continue;
            return upgradeDesignData2;
        }
        return null;
    }

    public static UpgradeDesignData getDesignByID(int n2) {
        for (UpgradeDesignData upgradeDesignData : designs) {
            if (upgradeDesignData.id != n2) continue;
            return upgradeDesignData;
        }
        return null;
    }

    public UpgradeDesign getDesign() {
        return this.design;
    }

    public String getName() {
        return this.name;
    }

    public int getId() {
        return this.id;
    }

    public UpgradeDesignType getType() {
        return this.type;
    }

    public static List<UpgradeDesignData> getDesigns() {
        return designs;
    }
}

