/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.upgrade.SimpleUpgradeGUIBuilder;
import de.marcely.bedwars.game.shop.upgrade.Upgrade;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeGUIBuilder;
import de.marcely.bedwars.game.shop.upgrade.UpgradeItem;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class HyPixelUpgradeDesign
extends UpgradeDesign {
    private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState;

    @Override
    public SimpleUpgradeGUIBuilder open(UpgradeDesign.OpenEvent openEvent) {
        UpgradeGUIBuilder upgradeGUIBuilder = new UpgradeGUIBuilder(openEvent);
        for (UpgradeItem upgradeItem : openEvent.getItems()) {
            String string = "??";
            switch (HyPixelUpgradeDesign.$SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState()[upgradeItem.getState().ordinal()]) {
                case 1: {
                    string = b.a(Language.TooFew_Materials).f((CommandSender)openEvent.getPlayer());
                    break;
                }
                case 2: {
                    string = b.a(Language.Shop_D_HyPixel_ClickToPurchase).f((CommandSender)openEvent.getPlayer());
                    break;
                }
                case 3: {
                    string = b.a(Language.Upgrade_Maximum).f((CommandSender)openEvent.getPlayer());
                }
            }
            upgradeItem.setIcon(i.b(upgradeItem.getIcon(), "", b.a(Language.Shop_D_HyPixel_Cost).a("amount", "" + upgradeItem.getUpgrade().getPriceAmount()).a("type", upgradeItem.getUpgrade().getPrice().getName(true)).a("color", "" + (upgradeItem.getUpgrade().getPrice().getChatColor() != null ? upgradeItem.getUpgrade().getPrice().getChatColor() : "")).f((CommandSender)openEvent.getPlayer()), "", string));
            upgradeGUIBuilder.addItem(upgradeItem, GUI.AddItemFlag.createWithin(2, 6, 1, 6));
        }
        upgradeGUIBuilder.setHeight(upgradeGUIBuilder.getHeight() + 1);
        return upgradeGUIBuilder;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState() {
        if ($SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[UpgradeItem.UpgradeState.values().length];
        try {
            arrn[UpgradeItem.UpgradeState.MAXIMUM.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[UpgradeItem.UpgradeState.NOT_UPGRADEABLE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[UpgradeItem.UpgradeState.UPGRADEABLE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState = arrn;
        return $SWITCH_TABLE$de$marcely$bedwars$game$shop$upgrade$UpgradeItem$UpgradeState;
    }
}

