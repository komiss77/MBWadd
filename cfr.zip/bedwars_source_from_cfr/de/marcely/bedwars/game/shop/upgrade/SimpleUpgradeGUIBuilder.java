/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.api.gui.SimpleGUI;

public abstract class SimpleUpgradeGUIBuilder {
    public abstract SimpleGUI export();
}

