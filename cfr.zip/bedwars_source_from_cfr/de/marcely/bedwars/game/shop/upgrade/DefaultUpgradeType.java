/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.f;
import de.marcely.bedwars.flag.j;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;

public enum DefaultUpgradeType {
    TEAM_SWORD_DAMAGE("team_sword_damage", (Object)ChatColor.AQUA + "%UpgradeShop_Name_SwordDamage%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_SwordDamage%", j.class),
    TEAM_ARMOR_RESISTANCE("team_armor_resistance", (Object)ChatColor.AQUA + "%UpgradeShop_Name_Resistence%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_Resistence%", j.class),
    SPAWN_HEALRANGE("spawn_healrange", (Object)ChatColor.AQUA + "%UpgradeShop_Name_HealRange%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_HealRange%", j.class),
    SPAWN_ITEMSPAWNER_MULTIPLIER("spawn_itemspawner_multiplier", (Object)ChatColor.AQUA + "%UpgradeShop_Name_SpawnerMultiplier%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_SpawnerMultiplier%", f.class),
    SPAWN_ENEMY_MININGFATIQUE("spawn_enemy_miningfatique", (Object)ChatColor.AQUA + "%UpgradeShop_Name_EnemyMiningFatique%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_EnemyMiningFatique%", j.class),
    SPAWN_ENEMY_TRAP("spawn_enemy_trap", (Object)ChatColor.AQUA + "%UpgradeShop_Name_EnemyTrap%", (Object)ChatColor.GRAY + "%UpgradeShop_Lore_EnemyTrap%", j.class),
    SPY(true, "spy", "", "", null);
    
    private final UpgradeType obj;

    private DefaultUpgradeType(String string2, String string3, String string4, @Nullable Class<? extends Value<?>> class_) {
        this(false, string2, string3, string4, class_);
    }

    private DefaultUpgradeType(boolean bl2, String string2, String string3, String string4, @Nullable Class<? extends Value<?>> class_) {
        this.obj = new UpgradeType(string2, bl2);
        this.obj.setDefaultName(Language.chatColorToString(string3));
        this.obj.setDefaultLore(Language.chatColorToString(string4));
        this.obj.setValueClass(class_);
        s.b(this.obj);
    }

    public ItemStack getItemStack() {
        return null;
    }

    public static void init() {
    }

    @Nullable
    public static DefaultUpgradeType byName(String string) {
        for (DefaultUpgradeType defaultUpgradeType : DefaultUpgradeType.values()) {
            if (!defaultUpgradeType.name().equalsIgnoreCase(string)) continue;
            return defaultUpgradeType;
        }
        return null;
    }

    public UpgradeType getObj() {
        return this.obj;
    }
}

