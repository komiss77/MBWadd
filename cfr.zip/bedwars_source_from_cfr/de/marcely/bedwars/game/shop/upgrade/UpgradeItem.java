/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.game.shop.upgrade.Upgrade;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class UpgradeItem {
    private final Upgrade upgrade;
    private ItemStack icon;
    private final UpgradeState state;

    public UpgradeItem(Upgrade upgrade, UpgradeState upgradeState) {
        String string = upgrade.getName() != null ? upgrade.getName() : upgrade.getType().getDefaultName();
        String string2 = upgrade.getLore() != null ? upgrade.getLore() : upgrade.getType().getDefaultLore();
        this.upgrade = upgrade;
        this.icon = Version.a().removeAttributes(i.a(i.a(upgrade.getIcon(), (Object)ChatColor.WHITE + b.a(string).c().b().f(null)), s.d(b.a((Object)ChatColor.WHITE + string2).c().b().f(null))));
        this.state = upgradeState;
    }

    public Upgrade getUpgrade() {
        return this.upgrade;
    }

    public ItemStack getIcon() {
        return this.icon;
    }

    public void setIcon(ItemStack itemStack) {
        this.icon = itemStack;
    }

    public UpgradeState getState() {
        return this.state;
    }

    public static enum UpgradeState {
        NOT_UPGRADEABLE,
        UPGRADEABLE,
        MAXIMUM;
        
    }

}

