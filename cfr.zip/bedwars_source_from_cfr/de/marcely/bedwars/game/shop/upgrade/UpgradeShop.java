/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.r;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.arena.i;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import de.marcely.bedwars.game.shop.upgrade.SimpleUpgradeGUIBuilder;
import de.marcely.bedwars.game.shop.upgrade.Upgrade;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesignData;
import de.marcely.bedwars.game.shop.upgrade.UpgradeEnchantment;
import de.marcely.bedwars.game.shop.upgrade.UpgradeItem;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.s;
import de.marcely.configmanager2.MultiKeyMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.annotation.Nullable;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class UpgradeShop {
    public static void eOpen(Player player, Arena arena) {
        if (arena == null) {
            new NullPointerException("arena is null").printStackTrace();
            return;
        }
        UpgradeShop.open(player, arena, r.a);
    }

    public static void open(final Player player, @Nullable Arena arena, final UpgradeDesignData upgradeDesignData) {
        i i2;
        s.a.start();
        Team team = arena != null ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
        UpgradeDesign upgradeDesign = upgradeDesignData.getDesign();
        i i3 = i2 = arena != null ? arena.r.get((Object)team) : null;
        if (i2 == null) {
            i2 = new i(null, team);
        }
        Sound.UPGRADESHOP_OPEN.play(player);
        upgradeDesign.listener = new ShopDesign.ClickListener(){

            @Override
            public void onClick(Player player2, Object object, boolean bl2, boolean bl3, int n2) {
                Arena arena = s.a(player2);
                if (arena == null || object == null) {
                    return;
                }
                if (object instanceof UpgradeItem) {
                    UpgradeShop.buy((UpgradeItem)object, player, arena, upgradeDesignData);
                }
            }
        };
        ArrayList<UpgradeItem> arrayList = new ArrayList<UpgradeItem>();
        for (DefaultUpgradeType defaultUpgradeType : DefaultUpgradeType.values()) {
            int n2 = i2.a(defaultUpgradeType.getObj());
            Upgrade upgrade = s.a(defaultUpgradeType.getObj(), n2);
            if (n2 <= 1 && upgrade == null) continue;
            arrayList.add(new UpgradeItem(upgrade, n2 < s.a(defaultUpgradeType.getObj()).getLvl() ? (upgrade.canBuy(player) ? UpgradeItem.UpgradeState.UPGRADEABLE : UpgradeItem.UpgradeState.NOT_UPGRADEABLE) : UpgradeItem.UpgradeState.MAXIMUM));
        }
        upgradeDesign.open(new UpgradeDesign.OpenEvent(upgradeDesign, player, arrayList)).export().open(player);
        s.a.a(l.a.g);
    }

    private static void buy(UpgradeItem upgradeItem, Player player, Arena arena, UpgradeDesignData upgradeDesignData) {
        if (arena == null || arena.b() != ArenaStatus.f) {
            return;
        }
        UpgradeType upgradeType = upgradeItem.getUpgrade().getType();
        Team team = arena.a(player);
        i i2 = arena.r.get((Object)team);
        if (i2 == null) {
            return;
        }
        int n2 = i2.a(upgradeType);
        if (team == null) {
            return;
        }
        if (!upgradeItem.getUpgrade().canBuy(player)) {
            s.a((CommandSender)player, b.a(Language.TooFew_Materials));
            Sound.UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS.play(player);
            return;
        }
        if (n2 >= s.a(upgradeType).getLvl()) {
            s.a((CommandSender)player, b.a(Language.Upgrade_Buy_Max));
            Sound.UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS.play(player);
            return;
        }
        DropType dropType = upgradeItem.getUpgrade().getPrice();
        if (dropType == null) {
            return;
        }
        s.a(player, dropType.getActualItemstack().getType(), upgradeItem.getUpgrade().getPriceAmount());
        i2.a(upgradeType, n2 + 1);
        Sound.UPGRADESHOP_BUYSUCCESS.play(player);
        if (upgradeType.equals(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj())) {
            for (Player player2 : arena.a(team)) {
                s.b(player2, Enchantment.DAMAGE_ALL, arena.a(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj(), team));
            }
        } else if (upgradeType.equals(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj())) {
            for (Player player3 : arena.a(team)) {
                s.a(player3, Enchantment.PROTECTION_ENVIRONMENTAL, arena.a(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj(), team));
            }
        } else if (upgradeType.equals(DefaultUpgradeType.SPAWN_ITEMSPAWNER_MULTIPLIER.getObj())) {
            XYZD xYZD = arena.a().a(team);
            for (Map.Entry entry : arena.a().entrySet()) {
                if (!(xYZD.distance((XYZ)entry.getValue()) <= (double)ConfigValue.upgrade_spawnsize)) continue;
                for (Object object : new ArrayList(arena.t.get(entry.getKey()))) {
                    if (!object.c.equals((XYZ)entry.getValue())) continue;
                    arena.t.get(entry.getKey()).remove(object);
                    break;
                }
                arena.t.get(entry.getKey()).add(new Arena.b((DropType)entry.getKey(), (XYZ)entry.getValue(), arena.a(DefaultUpgradeType.SPAWN_ITEMSPAWNER_MULTIPLIER.getObj(), team)));
            }
        }
        Upgrade upgrade = upgradeItem.getUpgrade().getNextLevel();
        if (upgrade != null && upgrade.getEnchantments() != null) {
            for (UpgradeEnchantment upgradeEnchantment : upgrade.getEnchantments()) {
                for (Object object : arena.a(team)) {
                    if (upgradeEnchantment.getType() == UpgradeEnchantment.UpgradeEnchantmentType.SWORD) {
                        s.b(object, upgradeEnchantment.getEnchantment(), upgradeEnchantment.getLevel());
                        continue;
                    }
                    if (upgradeEnchantment.getType() != UpgradeEnchantment.UpgradeEnchantmentType.ARMOR) continue;
                    s.a(object, upgradeEnchantment.getEnchantment(), upgradeEnchantment.getLevel());
                }
            }
        }
        UpgradeShop.open(player, arena, upgradeDesignData);
    }

}

