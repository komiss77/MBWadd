/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.bq;
import de.marcely.bedwars.game.shop.upgrade.HyPixelUpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.NormalUpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesignData;
import javax.annotation.Nullable;

public enum UpgradeDesignType {
    Normal(new NormalUpgradeDesign(), 0, false),
    HyPixel(new HyPixelUpgradeDesign(), 1, false),
    Custom;
    
    @Nullable
    private final UpgradeDesignData data;
    private final boolean isBeta;

    private UpgradeDesignType() {
        this.data = null;
        this.isBeta = false;
    }

    private UpgradeDesignType(UpgradeDesign upgradeDesign, int n3, boolean bl2) {
        this.data = new UpgradeDesignData(upgradeDesign, this.name(), n3, this);
        this.isBeta = bl2;
        if (!this.data.register()) {
            new bq().printStackTrace();
        }
    }

    public static UpgradeDesignType byName(String string) {
        for (UpgradeDesignType upgradeDesignType : UpgradeDesignType.values()) {
            if (!upgradeDesignType.name().equalsIgnoreCase(string)) continue;
            return upgradeDesignType;
        }
        return null;
    }

    @Nullable
    public UpgradeDesignData getData() {
        return this.data;
    }

    public boolean isBeta() {
        return this.isBeta;
    }
}

