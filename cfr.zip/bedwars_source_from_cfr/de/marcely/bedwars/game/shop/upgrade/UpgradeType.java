/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.flag.Value;

public class UpgradeType {
    final String identifier;
    final boolean isBeta;
    Class<? extends Value<?>> valueClass;
    String defaultName = "Namless Upgrade";
    String defaultLore = "/";

    public UpgradeType(String string, boolean bl2) {
        this.identifier = string;
        this.isBeta = bl2;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public boolean isBeta() {
        return this.isBeta;
    }

    public Class<? extends Value<?>> getValueClass() {
        return this.valueClass;
    }

    public void setValueClass(Class<? extends Value<?>> class_) {
        this.valueClass = class_;
    }

    public String getDefaultName() {
        return this.defaultName;
    }

    public String getDefaultLore() {
        return this.defaultLore;
    }

    public void setDefaultName(String string) {
        this.defaultName = string;
    }

    public void setDefaultLore(String string) {
        this.defaultLore = string;
    }
}

