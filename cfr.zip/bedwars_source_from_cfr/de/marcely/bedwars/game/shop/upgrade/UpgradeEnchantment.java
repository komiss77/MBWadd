/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.enchantments.Enchantment
 */
package de.marcely.bedwars.game.shop.upgrade;

import javax.annotation.Nullable;
import org.bukkit.enchantments.Enchantment;

public class UpgradeEnchantment {
    private final UpgradeEnchantmentType type;
    private final Enchantment enchantment;
    private final int level;

    public UpgradeEnchantment(UpgradeEnchantmentType upgradeEnchantmentType, Enchantment enchantment, int n2) {
        this.type = upgradeEnchantmentType;
        this.enchantment = enchantment;
        this.level = n2;
    }

    public UpgradeEnchantmentType getType() {
        return this.type;
    }

    public Enchantment getEnchantment() {
        return this.enchantment;
    }

    public int getLevel() {
        return this.level;
    }

    public static enum UpgradeEnchantmentType {
        SWORD,
        ARMOR;
        

        @Nullable
        public static UpgradeEnchantmentType ofName(String string) {
            for (UpgradeEnchantmentType upgradeEnchantmentType : UpgradeEnchantmentType.values()) {
                if (!upgradeEnchantmentType.name().equalsIgnoreCase(upgradeEnchantmentType.name())) continue;
                return upgradeEnchantmentType;
            }
            return null;
        }
    }

}

