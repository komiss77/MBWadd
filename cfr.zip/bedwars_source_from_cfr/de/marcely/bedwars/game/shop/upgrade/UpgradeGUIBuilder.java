/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.upgrade.SimpleUpgradeGUIBuilder;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesign;
import de.marcely.bedwars.game.shop.upgrade.UpgradeItem;
import de.marcely.bedwars.message.b;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class UpgradeGUIBuilder
extends SimpleUpgradeGUIBuilder {
    private final UpgradeDesign.OpenEvent event;
    private final GUI gui;

    public UpgradeGUIBuilder(UpgradeDesign.OpenEvent openEvent) {
        this.event = openEvent;
        this.gui = new GUI(b.a(ConfigValue.upgradedealer_title_gui).c().f(null), 0){

            @Override
            protected void onSetItem(int n2, int n3, GUIItem gUIItem) {
            }
        };
        this.gui.autoRefresh = false;
    }

    public boolean addItem(UpgradeItem upgradeItem) {
        return this.gui.addItem(this.getGUIItem(upgradeItem));
    }

    public boolean addItem(ItemStack itemStack) {
        return this.gui.addItem(this.getGUIItem(itemStack));
    }

    public boolean addItem(UpgradeItem upgradeItem, @Nullable GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(upgradeItem), addItemFlag);
    }

    public boolean addItem(ItemStack itemStack, @Nullable GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(itemStack), addItemFlag);
    }

    public void setItemAt(UpgradeItem upgradeItem, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(upgradeItem), n2, n3);
    }

    public void setItemAt(UpgradeItem upgradeItem, int n2) {
        this.gui.setItemAt(this.getGUIItem(upgradeItem), n2);
    }

    public void setItemAt(ItemStack itemStack, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n2, n3);
    }

    public void setItemAt(ItemStack itemStack, int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n2);
    }

    public void setHeight(int n2) {
        this.gui.setHeight(n2);
    }

    public int getHeight() {
        return this.gui.getHeight();
    }

    private GUIItem getGUIItem(final UpgradeItem upgradeItem) {
        return new GUIItem(upgradeItem.getIcon()){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                UpgradeGUIBuilder.access$0((UpgradeGUIBuilder)UpgradeGUIBuilder.this).getDesign().listener.onClick(player, upgradeItem, bl2, bl3, 0);
            }
        };
    }

    private GUIItem getGUIItem(ItemStack itemStack) {
        GUIItem gUIItem = new GUIItem(itemStack){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
            }
        };
        return gUIItem;
    }

    @Override
    public SimpleGUI export() {
        return this.gui;
    }

    static /* synthetic */ UpgradeDesign.OpenEvent access$0(UpgradeGUIBuilder upgradeGUIBuilder) {
        return upgradeGUIBuilder.event;
    }

}

