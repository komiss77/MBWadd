/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.api.Spawner;
import de.marcely.bedwars.api.event.PlayerOpenShopEvent;
import de.marcely.bedwars.api.event.ShopBuyEvent;
import de.marcely.bedwars.api.event.ShopGUIBuildEvent;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.config.m;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.shop.BuyGroup;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class Shop {
    public static void eOpen(Player player, Arena arena, ShopOpenType shopOpenType) {
        if (arena == null) {
            new NullPointerException("arena is null").printStackTrace();
            return;
        }
        PlayerOpenShopEvent playerOpenShopEvent = new PlayerOpenShopEvent(player, m.a);
        Bukkit.getPluginManager().callEvent((Event)playerOpenShopEvent);
        if (playerOpenShopEvent.isCancelled()) {
            return;
        }
        Shop.open(player, arena, null, playerOpenShopEvent.getDesign(), shopOpenType);
    }

    public static void open(Player player, @Nullable Arena arena, ShopOpenType shopOpenType) {
        Shop.open(player, arena, null, shopOpenType);
    }

    public static void open(Player player, ShopOpenType shopOpenType) {
        Shop.open(player, null, null, shopOpenType);
    }

    public static void open(Player player, @Nullable Arena arena, @Nullable ShopPage shopPage, ShopOpenType shopOpenType) {
        Shop.open(player, null, shopPage, m.a, shopOpenType);
    }

    public static void open(Player player, @Nullable ShopPage shopPage, ShopOpenType shopOpenType) {
        Shop.open(player, null, shopPage, m.a, shopOpenType);
    }

    public static void open(Player player, ShopDesignData shopDesignData, ShopOpenType shopOpenType) {
        Shop.open(player, null, null, shopDesignData, shopOpenType);
    }

    public static void open(Player player, @Nullable Arena arena, @Nullable ShopPage shopPage, ShopDesignData shopDesignData, ShopOpenType shopOpenType) {
        Shop.open(player, arena, shopPage, shopDesignData, shopOpenType, 0);
    }

    public static void open(final Player player, final @Nullable Arena arena, final @Nullable ShopPage shopPage, final ShopDesignData shopDesignData, final ShopOpenType shopOpenType, final int n2) {
        s.a.start();
        Sound.VILLAGERSHOP_OPEN.play(player);
        ShopDesign shopDesign = shopDesignData.getDesign().clone();
        shopDesign.listener = new ShopDesign.ClickListener(){

            @Override
            public void onClick(Player player, Object object, boolean bl2, boolean bl3, int n22) {
                Arena arena = s.a(player);
                if (object == null) {
                    Shop.open(player, arena, null, shopDesignData, shopOpenType);
                    return;
                }
                if (object instanceof ShopPage) {
                    ShopPage shopPage2 = (ShopPage)object;
                    if (shopPage == null || !shopPage2.getName().equals(shopPage.getName()) || n2 != n22) {
                        Shop.open(player, arena, shopPage2, shopDesignData, shopOpenType, n22);
                    }
                } else if (object instanceof ShopItem) {
                    ShopItem shopItem = (ShopItem)object;
                    ItemStack itemStack = shopItem.getIcon();
                    i.a(itemStack, new String[0]);
                    i.a(itemStack, (Object)ChatColor.WHITE + shopItem.getName());
                    Shop.buy(arena, player, shopItem, bl3, shopOpenType);
                }
            }
        };
        ArrayList<ShopPage> arrayList = new ArrayList<ShopPage>(s.ah.size());
        ShopPage object2 = null;
        for (ShopPage shopPage2 : s.ah) {
            ShopPage object3 = shopPage2.clone();
            Object object = object3.getIcon();
            if (!object3.getDisplayName().isEmpty()) {
                object = i.a(object3.getIcon(), (Object)ChatColor.WHITE + object3.getDisplayName());
            }
            object3.setIcon(Version.a().removeAttributes(i.a((ItemStack)object, new String[0])));
            if (shopPage != null && object3.getName().equals(shopPage.getName())) {
                object2 = object3;
            }
            arrayList.add(object3);
            object = object3.getItems().iterator();
            Team team = arena != null && arena.a(player) != null ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
            while (object.hasNext()) {
                ShopItem shopItem = (ShopItem)object.next();
                if (shopItem.getBuyGroup() != null && shopItem.getBuyGroupLevel() == 0) {
                    object.remove();
                    continue;
                }
                ItemStack itemStack = shopItem.getIcon();
                if (!shopItem.getDisplayName().isEmpty()) {
                    itemStack = i.a(shopItem.getIcon(), (Object)ChatColor.WHITE + shopItem.getDisplayName());
                }
                itemStack = i.a(itemStack, team);
                ItemMeta itemMeta = itemStack.getItemMeta();
                for (Map.Entry<Enchantment, Integer> entry : shopItem.getIconEnchantments().entrySet()) {
                    itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), true);
                }
                itemStack.setItemMeta(itemMeta);
                shopItem.setIcon(itemStack);
            }
        }
        SimpleShopGUIBuilder simpleShopGUIBuilder = shopDesign.open(new ShopDesign.OpenEvent(shopDesign, player, arrayList, object2, n2){

            @Override
            public void refresh() {
                Shop.open(player, arena, shopPage, shopDesignData, shopOpenType);
            }
        });
        if (simpleShopGUIBuilder.getOpenPage() == null) {
            ShopGUIBuildEvent shopGUIBuildEvent = new ShopGUIBuildEvent(player, shopDesign, simpleShopGUIBuilder.export());
            Bukkit.getPluginManager().callEvent(shopGUIBuildEvent);
            if (shopGUIBuildEvent.getGUI() != null) {
                shopGUIBuildEvent.getGUI().open(player);
            }
        } else {
            Shop.open(player, arena, simpleShopGUIBuilder.getOpenPage(), shopDesignData, shopOpenType);
        }
        s.a.a(l.a.f);
    }

    private static void buy(@Nullable Arena arena, Player player, ShopItem shopItem, boolean bl2, ShopOpenType shopOpenType) {
        List<ShopItem> list;
        int n2 = shopItem.getAmountPlayerCanBuy(player, bl2);
        Team team = arena != null && arena.a(player) != null ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
        ShopBuyEvent shopBuyEvent = new ShopBuyEvent(arena, player, shopItem, n2, shopOpenType, bl2, Shop.getProblems(arena, player, team, shopItem, n2));
        Bukkit.getPluginManager().callEvent((Event)shopBuyEvent);
        for (ShopPrice object2 : shopItem.getPrices()) {
            DropType dropType = object2.getSpawner();
            if (dropType.getCustomSpawner() == null) continue;
            dropType.getCustomSpawner().onBuyEvent(shopBuyEvent);
        }
        n2 = shopBuyEvent.getAmount();
        if (shopBuyEvent.getProblems().size() >= 1) {
            try {
                shopBuyEvent.getProblems().get(0).handleFeedback(shopBuyEvent);
            }
            catch (Error error) {
                error.printStackTrace();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            return;
        }
        Sound.VILLAGERSHOP_BUYSUCCESS.play(player);
        if (arena != null && (shopItem.isOneTimePurchase() || shopItem.isKeepOnDeath()) && !(list = arena.u.get((Object)player)).contains(shopItem.getOriginal())) {
            list.add(shopItem.getOriginal());
        }
        if (shopItem.getBuyGroup() != null) {
            arena.v.get((Object)team).put(shopItem.getOriginal().getBuyGroup(), shopItem.getBuyGroupLevel());
        }
        if (shopBuyEvent.isTakingPayments()) {
            for (ShopPrice shopPrice : shopItem.getPrices()) {
                s.a(player, shopPrice.getSpawner().getActualItemstack().getType(), n2 * shopPrice.getPrice(player));
            }
        }
        if (shopBuyEvent.isGivingProducts()) {
            for (ShopProduct shopProduct : shopItem.getProducts()) {
                shopProduct.give(player, team, n2, arena);
            }
        }
    }

    private static List<ShopBuyEvent.ShopBuyProblem> getProblems(@Nullable Arena arena, Player player, Team team, ShopItem shopItem, int n2) {
        ArrayList<ShopBuyEvent.ShopBuyProblem> arrayList = new ArrayList<ShopBuyEvent.ShopBuyProblem>();
        if (!shopItem.hasPermission(player)) {
            arrayList.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_INSUFFICIENT_PERMISSIONS);
        }
        if (shopItem.isOneTimePurchase() && arena != null && arena.u.get((Object)player).contains(shopItem.getOriginal())) {
            arrayList.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_ONETIMEPURCHASE);
        }
        if (shopItem.getBuyGroup() != null) {
            int n3 = arena.v.get((Object)team).getOrDefault(shopItem.getOriginal().getBuyGroup(), 0);
            if (shopItem.getBuyGroupLevel() <= n3) {
                arrayList.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_BUYGROUP);
            }
        }
        if (n2 == 0) {
            arrayList.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_NOT_ENOUGH_ITEMS);
        }
        return arrayList;
    }

}

