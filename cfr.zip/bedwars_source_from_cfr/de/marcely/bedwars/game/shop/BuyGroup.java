/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.game.shop.ShopItem;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BuyGroup
implements Cloneable {
    private final String name;
    private Map<Integer, List<ShopItem>> items = new LinkedHashMap<Integer, List<ShopItem>>();

    public BuyGroup(String string) {
        this.name = string;
    }

    public BuyGroup clone() {
        try {
            BuyGroup buyGroup = (BuyGroup)super.clone();
            buyGroup.items = new LinkedHashMap<Integer, List<ShopItem>>();
            for (Map.Entry<Integer, List<ShopItem>> entry : this.items.entrySet()) {
                buyGroup.items.put(entry.getKey(), new ArrayList(entry.getValue()));
            }
            return buyGroup;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public String getName() {
        return this.name;
    }

    public Map<Integer, List<ShopItem>> getItems() {
        return this.items;
    }
}

