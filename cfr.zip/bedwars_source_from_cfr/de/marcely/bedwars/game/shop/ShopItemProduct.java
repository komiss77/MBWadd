/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Material
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopProduct;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ShopItemProduct
extends ShopProduct
implements Cloneable {
    public static final String IDENTIFIER = "item";
    @Nullable
    private ItemStack itemStack = null;
    private final Map<Enchantment, Integer> enchantments = new HashMap<Enchantment, Integer>();

    public ShopItemProduct(ShopItem shopItem) {
        super(shopItem);
    }

    @Override
    public ItemStack getItemStack() {
        return this.itemStack != null ? this.itemStack.clone() : null;
    }

    @Override
    public String getDisplayName() {
        return this.itemStack.getType().name().toLowerCase().replace("_", " ");
    }

    @Override
    public String getIdentifier() {
        return IDENTIFIER;
    }

    @Override
    protected ItemStack postPrepareGive(Player player, ItemStack itemStack) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        for (Map.Entry<Enchantment, Integer> entry : this.enchantments.entrySet()) {
            itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), true);
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }

    @Override
    public ShopItemProduct clone() {
        return (ShopItemProduct)super.clone();
    }

    public void setItemStack(@Nullable ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public Map<Enchantment, Integer> getEnchantments() {
        return this.enchantments;
    }
}

