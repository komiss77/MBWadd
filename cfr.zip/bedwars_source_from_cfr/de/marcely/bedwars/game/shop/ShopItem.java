/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Permission;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.shop.BuyGroup;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.ShopSpecialProduct;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ShopItem
implements Cloneable {
    private ShopPage page;
    private final String name;
    private final String displayName;
    private List<ShopProduct> products = new ArrayList<ShopProduct>();
    private List<ShopPrice> prices = new ArrayList<ShopPrice>();
    private ItemStack icon = new ItemStack(Material.STONE);
    private final Map<Enchantment, Integer> iconEnchantments = new HashMap<Enchantment, Integer>();
    private boolean keepOnDeath = false;
    private boolean oneTimePurchase = false;
    private int capsMultiply = 1;
    private BuyGroup buyGroup;
    private int buyGroupLevel;
    private Integer forceSlot;
    private ShopItem original = null;

    public ShopItem(ShopPage shopPage, String string) {
        this.page = shopPage;
        this.name = string;
        this.displayName = b.a(string).b().c().f(null);
    }

    public ShopItem getOriginal() {
        return this.original != null ? this.original.getOriginal() : this;
    }

    public void setIcon(ItemStack itemStack) {
        this.icon = itemStack;
    }

    public ItemStack getIcon() {
        if (this.getProducts().size() == 1) {
            this.icon.setAmount(this.getProducts().get(0).getAmount());
        }
        return this.icon;
    }

    public int getAmountPlayerCanBuy(Player player, boolean bl2) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (ShopPrice shopPrice : this.prices) {
            arrayList.add(shopPrice.getAmountPlayerCanBuy(player, bl2));
        }
        return (Integer)Collections.min(arrayList);
    }

    public boolean hasPermission(Player player) {
        if (ConfigValue.specialitem_requiredpermission) {
            for (ShopProduct shopProduct : this.products) {
                if (!(shopProduct instanceof ShopSpecialProduct) || s.hasPermission((CommandSender)player, Permission.SpecialItem.replace("id", ((ShopSpecialProduct)shopProduct).getExtraItem().getName()))) continue;
                return false;
            }
        }
        return true;
    }

    public ShopItem clone() {
        try {
            ShopItem shopItem = (ShopItem)super.clone();
            shopItem.products = new ArrayList<ShopProduct>(this.products.size());
            for (ShopProduct shopProduct : this.products) {
                ShopProduct cloneable = shopProduct.clone();
                cloneable.setItem(shopItem);
                shopItem.products.add(cloneable);
            }
            shopItem.prices = new ArrayList<ShopPrice>(this.prices.size());
            for (ShopPrice shopPrice : this.prices) {
                ShopPrice shopPrice2 = shopPrice.clone();
                shopPrice2.setItem(shopItem);
                shopItem.prices.add(shopPrice2);
            }
            shopItem.icon = this.icon != null ? this.icon.clone() : null;
            shopItem.iconEnchantments.putAll(this.iconEnchantments);
            shopItem.original = this.original != null ? this.original : this;
            shopItem.buyGroup = this.buyGroup != null ? this.buyGroup.clone() : null;
            return shopItem;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public ShopPage getPage() {
        return this.page;
    }

    public void setPage(ShopPage shopPage) {
        this.page = shopPage;
    }

    public String getName() {
        return this.name;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public List<ShopProduct> getProducts() {
        return this.products;
    }

    public List<ShopPrice> getPrices() {
        return this.prices;
    }

    public Map<Enchantment, Integer> getIconEnchantments() {
        return this.iconEnchantments;
    }

    public boolean isKeepOnDeath() {
        return this.keepOnDeath;
    }

    public boolean isOneTimePurchase() {
        return this.oneTimePurchase;
    }

    public void setKeepOnDeath(boolean bl2) {
        this.keepOnDeath = bl2;
    }

    public void setOneTimePurchase(boolean bl2) {
        this.oneTimePurchase = bl2;
    }

    public int getCapsMultiply() {
        return this.capsMultiply;
    }

    public void setCapsMultiply(int n2) {
        this.capsMultiply = n2;
    }

    public BuyGroup getBuyGroup() {
        return this.buyGroup;
    }

    public void setBuyGroup(BuyGroup buyGroup) {
        this.buyGroup = buyGroup;
    }

    public int getBuyGroupLevel() {
        return this.buyGroupLevel;
    }

    public void setBuyGroupLevel(int n2) {
        this.buyGroupLevel = n2;
    }

    public Integer getForceSlot() {
        return this.forceSlot;
    }

    public void setForceSlot(Integer n2) {
        this.forceSlot = n2;
    }
}

