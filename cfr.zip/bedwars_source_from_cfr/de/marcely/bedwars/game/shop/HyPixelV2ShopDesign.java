/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class HyPixelV2ShopDesign
extends ShopDesign {
    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        Object object;
        Object object2;
        int n2;
        Object object3;
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getPages().size() == 0) {
            shopGUIBuilder.setHeight(3);
            shopGUIBuilder.setItemAt(i.a(new ItemStack(s.e), (Object)ChatColor.RED + "/"), 4, 1);
            return shopGUIBuilder;
        }
        ShopPage shopPage = openEvent.getOpen() != null ? openEvent.getOpen() : openEvent.getPages().get(0);
        for (ShopPage shopPage2 : openEvent.getPages()) {
            object2 = shopPage2.getIcon();
            object2 = i.a((ItemStack)object2, (Object)ChatColor.GREEN + shopPage2.getDisplayName());
            if (shopPage2 != shopPage) {
                object2 = i.a((ItemStack)object2, new String[]{Language.Shop_D_HyPixelV2_ClickToView.getMessage((CommandSender)openEvent.getPlayer())});
            }
            shopPage2.setIcon((ItemStack)object2);
            shopGUIBuilder.addItem(shopPage2);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal);
        shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        for (n2 = 0; n2 < 9; ++n2) {
            boolean bl2 = false;
            for (int i2 = 0; i2 < shopGUIBuilder.getHeight() - 1; ++i2) {
                object3 = shopGUIBuilder.getGui().getItemAt(n2, i2);
                Object object4 = object = object3 != null ? i.a(((GUIItem)object3).getItemStack()) : null;
                if (object == null || object.size() < 1) continue;
                bl2 = true;
                break;
            }
            object2 = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)((byte)(bl2 ? 7 : 13)));
            object2 = i.a(i.a((ItemStack)object2, new String[]{Language.Shop_D_HyPixelV2_Seperator_Items.getMessage((CommandSender)openEvent.getPlayer())}), Language.Shop_D_HyPixelV2_Seperator_Categories.getMessage((CommandSender)openEvent.getPlayer()));
            shopGUIBuilder.setItemAt((ItemStack)object2, n2, shopGUIBuilder.getHeight() - 1);
        }
        n2 = shopGUIBuilder.getHeight();
        shopGUIBuilder.setHeight(6);
        for (ShopItem shopItem : shopPage.getItems()) {
            if (shopItem.getPrices().size() >= 2) {
                d.d("The HyPixelV2 shop design only displays 1 price per item!", "Shop");
            }
            object3 = new ArrayList();
            object3.add(b.a(Language.Shop_D_HyPixel_Cost).a("amount", "" + ((ShopPrice)object).getPrice(openEvent.getPlayer())).a("type", ((ShopPrice)object).getSpawner().getName(true)).a("color", "" + (((ShopPrice)(object = shopItem.getPrices().get(0))).getSpawner().getChatColor() != null ? ((ShopPrice)object).getSpawner().getChatColor() : "")).f((CommandSender)openEvent.getPlayer()));
            object3.add("");
            object3.add(b.a(shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) > 0 ? Language.Shop_D_HyPixel_ClickToPurchase : Language.Shop_D_HyPixel_TooExpensive).a("amount", "" + ((ShopPrice)object).getPrice(openEvent.getPlayer())).a("type", ((ShopPrice)object).getSpawner().getName(true)).a("color", "" + (((ShopPrice)object).getSpawner().getChatColor() != null ? ((ShopPrice)object).getSpawner().getChatColor() : "")).f((CommandSender)openEvent.getPlayer()));
            shopItem.setIcon(i.a(shopItem.getIcon(), (List<String>)object3));
            shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithin(1, 8, n2, 6));
        }
        return shopGUIBuilder;
    }
}

