/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class MinesuchtShopDesign
extends ShopDesign {
    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        int n2;
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
        }
        ItemStack itemStack = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 7), " ");
        for (n2 = 0; n2 < 9; ++n2) {
            shopGUIBuilder.addItem(itemStack);
        }
        for (ShopPage shopPage : openEvent.getPages()) {
            shopGUIBuilder.addItem(shopPage);
        }
        for (n2 = 1; n2 < shopGUIBuilder.getHeight(); ++n2) {
            shopGUIBuilder.centerAtY(n2, GUI.CenterFormatType.Normal);
        }
        shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        for (n2 = 0; n2 < 9; ++n2) {
            shopGUIBuilder.setItemAt(itemStack, n2, shopGUIBuilder.getHeight() - 1);
        }
        n2 = shopGUIBuilder.getHeight();
        if (openEvent.getOpen() != null) {
            int n3;
            shopGUIBuilder.setHeight(6);
            int n4 = (int)((float)(6 - n2) / 1.5f);
            for (ShopItem shopItem : openEvent.getOpen().getItems()) {
                ArrayList<String> arrayList = new ArrayList<String>(shopItem.getPrices().size());
                arrayList.add("");
                for (ShopPrice shopPrice : shopItem.getPrices()) {
                    arrayList.add((Object)shopPrice.getSpawner().getChatColor() + " " + shopPrice.getPrice(openEvent.getPlayer()) + " " + shopPrice.getSpawner().getName());
                }
                shopItem.setIcon(i.a(shopItem.getIcon(), arrayList));
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithinY(n4, 6));
            }
            for (n3 = n4; n3 < 6; ++n3) {
                shopGUIBuilder.centerAtY(n3, GUI.CenterFormatType.Beautiful);
            }
            for (n3 = 0; n3 < 9; ++n3) {
                shopGUIBuilder.centerAtX(n3, GUI.CenterFormatType.Beautiful, n2, 6);
            }
        }
        return shopGUIBuilder;
    }
}

