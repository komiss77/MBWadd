/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ShopGUIBuilder
extends SimpleShopGUIBuilder {
    private final ShopDesign.OpenEvent event;
    private final GUI gui;

    public ShopGUIBuilder(ShopDesign.OpenEvent openEvent) {
        this.event = openEvent;
        this.gui = new GUI(b.a(ConfigValue.dealer_title_gui).c().f(null), 0){

            @Override
            protected void onSetItem(int n2, int n3, GUIItem gUIItem) {
            }
        };
        this.gui.autoRefresh = false;
    }

    public boolean addItem(ShopItem shopItem) {
        return this.gui.addItem(this.getGUIItem(shopItem));
    }

    public boolean addItem(ShopPage shopPage) {
        return this.gui.addItem(this.getGUIItem(shopPage));
    }

    public boolean addItem(ShopPage shopPage, int n2) {
        return this.gui.addItem(this.getGUIItem(shopPage, n2));
    }

    public boolean addItem(ItemStack itemStack) {
        return this.gui.addItem(this.getGUIItem(itemStack));
    }

    public boolean addItem(ShopItem shopItem, @Nullable GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(shopItem), addItemFlag);
    }

    public boolean addItem(ShopPage shopPage, @Nullable GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(shopPage), addItemFlag);
    }

    public boolean addItemWithData(ShopPage shopPage, @Nullable GUI.AddItemFlag addItemFlag, int n2) {
        return this.gui.addItem(this.getGUIItem(shopPage, n2), addItemFlag);
    }

    public boolean addItem(ItemStack itemStack, @Nullable GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(itemStack), addItemFlag);
    }

    public void setItemAt(ShopItem shopItem, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(shopItem), n2, n3);
    }

    public void setItemAt(ShopItem shopItem, int n2) {
        this.gui.setItemAt(this.getGUIItem(shopItem), n2);
    }

    public void setItemAt(ShopPage shopPage, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(shopPage), n2, n3);
    }

    public void setItemAt(ShopPage shopPage, int n2) {
        this.gui.setItemAt(this.getGUIItem(shopPage), n2);
    }

    public void setItemAtWithData(ShopPage shopPage, int n2, int n3, int n4) {
        this.gui.setItemAt(this.getGUIItem(shopPage, n4), n2, n3);
    }

    public void setItemAtWithData(ShopPage shopPage, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(shopPage, n3), n2);
    }

    public void setItemAt(ItemStack itemStack, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n2, n3);
    }

    public void setItemAtWithData(ShopPage shopPage, ItemStack itemStack, int n2, int n3, int n4) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopPage, n4), n2, n3);
    }

    public void setItemAt(ShopItem shopItem, ItemStack itemStack, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopItem), n2, n3);
    }

    public void setItemAt(ItemStack itemStack, int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n2);
    }

    public void setItemAtWithData(ShopPage shopPage, ItemStack itemStack, int n2, int n3) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopPage, n3), n2);
    }

    public void setItemAt(ShopItem shopItem, ItemStack itemStack, int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopItem), n2);
    }

    public void setItemAt(GUIItem gUIItem, int n2, int n3) {
        this.gui.setItemAt(gUIItem, n2, n3);
    }

    public void setItemAt(GUIItem gUIItem, int n2) {
        this.gui.setItemAt(gUIItem, n2);
    }

    public void setHomeItemAt(ItemStack itemStack, int n2, int n3) {
        this.gui.setItemAt(this.getHomeGUIItem(itemStack), n2, n3);
    }

    public void setHomeItemAt(ItemStack itemStack, int n2) {
        this.gui.setItemAt(this.getHomeGUIItem(itemStack), n2);
    }

    public void setHeight(int n2) {
        this.gui.setHeight(n2);
    }

    public void setTitle(String string) {
        this.gui.setTitle(string);
    }

    public int getHeight() {
        return this.gui.getHeight();
    }

    public String getTitle() {
        return this.gui.getTitle();
    }

    private GUIItem getGUIItem(ShopItem shopItem) {
        return this.getGUIItem(shopItem.getIcon(), shopItem);
    }

    private GUIItem getGUIItem(ItemStack itemStack, final ShopItem shopItem) {
        GUIItem gUIItem = new GUIItem(itemStack){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                if (ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener != null) {
                    ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener.onClick(player, shopItem, bl2, bl3, 0);
                }
            }
        };
        gUIItem.attachment = shopItem;
        return gUIItem;
    }

    private GUIItem getGUIItem(ShopPage shopPage, int n2) {
        return this.getGUIItem(shopPage.getIcon(), shopPage, n2);
    }

    public GUIItem getGUIItem(ItemStack itemStack, final ShopPage shopPage, final int n2) {
        GUIItem gUIItem = new GUIItem(itemStack){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                if (ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener != null) {
                    ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener.onClick(player, shopPage, bl2, bl3, n2);
                }
            }
        };
        gUIItem.attachment = shopPage;
        return gUIItem;
    }

    private GUIItem getGUIItem(ShopPage shopPage) {
        return this.getGUIItem(shopPage, 0);
    }

    private GUIItem getGUIItem(ItemStack itemStack) {
        GUIItem gUIItem = new GUIItem(itemStack){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
            }
        };
        return gUIItem;
    }

    private GUIItem getHomeGUIItem(ItemStack itemStack) {
        GUIItem gUIItem = new GUIItem(itemStack){

            @Override
            public void onClick(Player player, boolean bl2, boolean bl3) {
                if (ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener != null) {
                    ShopGUIBuilder.access$0((ShopGUIBuilder)ShopGUIBuilder.this).getShopDesign().listener.onClick(player, null, bl2, bl3, 0);
                }
            }
        };
        return gUIItem;
    }

    public void centerAtY(int n2, GUI.CenterFormatType centerFormatType, int n3, int n4) {
        this.gui.centerAtY(n2, centerFormatType, n3, n4);
    }

    public void centerAtY(int n2, GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtY(n2, centerFormatType);
    }

    public void centerYAll(GUI.CenterFormatType centerFormatType, int n2, int n3) {
        this.gui.centerAtYAll(centerFormatType, n2, n3);
    }

    public void centerYAll(GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtYAll(centerFormatType);
    }

    public void centerAtX(int n2, GUI.CenterFormatType centerFormatType, int n3, int n4) {
        this.gui.centerAtX(n2, centerFormatType, n3, n4);
    }

    public void centerAtX(int n2, GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtX(n2, centerFormatType);
    }

    public void centerXAll(GUI.CenterFormatType centerFormatType, int n2, int n3) {
        this.gui.centerAtXAll(centerFormatType, n2, n3);
    }

    public void centerXAll(GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtXAll(centerFormatType);
    }

    @Override
    public SimpleGUI export() {
        GUIItem[][] arrgUIItem = this.gui.getItems();
        GUIItem[][] arrgUIItem2 = s.a(arrgUIItem);
        for (int i2 = 0; i2 < arrgUIItem.length; ++i2) {
            for (int i3 = 0; i3 < arrgUIItem[i2].length; ++i3) {
                Cloneable cloneable;
                int n2;
                GUIItem gUIItem = arrgUIItem2[i2][i3];
                if (gUIItem == null || gUIItem.attachment == null) continue;
                if (gUIItem.attachment instanceof ShopItem) {
                    cloneable = (ShopItem)gUIItem.attachment;
                    if (((ShopItem)cloneable).getForceSlot() == null) continue;
                    if (arrgUIItem[i2][i3] == gUIItem) {
                        arrgUIItem[i2][i3] = null;
                    }
                    n2 = (int)Math.ceil((double)(((ShopItem)cloneable).getForceSlot() + 1) / 9.0);
                    if (this.gui.getHeight() < n2) {
                        this.gui.setHeight(n2);
                    }
                    this.gui.setItemAt(gUIItem, ((ShopItem)cloneable).getForceSlot());
                    continue;
                }
                if (!(gUIItem.attachment instanceof ShopPage) || ((ShopPage)(cloneable = (ShopPage)gUIItem.attachment)).getForceSlot() == null) continue;
                if (arrgUIItem[i2][i3] == gUIItem) {
                    arrgUIItem[i2][i3] = null;
                }
                n2 = (int)Math.ceil((double)(((ShopPage)cloneable).getForceSlot() + 1) / 9.0);
                if (this.gui.getHeight() < n2) {
                    this.gui.setHeight(n2);
                }
                this.gui.setItemAt(gUIItem, ((ShopPage)cloneable).getForceSlot());
            }
        }
        return this.gui;
    }

    public GUI getGui() {
        return this.gui;
    }

    static /* synthetic */ ShopDesign.OpenEvent access$0(ShopGUIBuilder shopGUIBuilder) {
        return shopGUIBuilder.event;
    }

}

