/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopProduct;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ShopSpecialProduct
extends ShopProduct
implements Cloneable {
    public static final String IDENTIFIER = "special";
    private ExtraItem extraItem = null;

    public ShopSpecialProduct(ShopItem shopItem) {
        super(shopItem);
    }

    @Override
    public ItemStack getItemStack() {
        return this.extraItem.getItemStack();
    }

    @Override
    public String getDisplayName() {
        return this.extraItem.getName();
    }

    @Override
    public String getIdentifier() {
        return IDENTIFIER;
    }

    @Override
    protected ItemStack postPrepareGive(Player player, ItemStack itemStack) {
        return itemStack;
    }

    @Override
    public ShopSpecialProduct clone() {
        return (ShopSpecialProduct)super.clone();
    }

    public ExtraItem getExtraItem() {
        return this.extraItem;
    }

    public void setExtraItem(ExtraItem extraItem) {
        this.extraItem = extraItem;
    }
}

