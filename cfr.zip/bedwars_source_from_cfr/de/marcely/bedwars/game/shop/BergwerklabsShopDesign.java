/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class BergwerklabsShopDesign
extends ShopDesign {
    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null && openEvent.getPages().size() >= 1) {
            shopGUIBuilder.setOpenPage(openEvent.getPages().get(0));
        } else if (openEvent.getOpen().getItems().size() >= 1) {
            int n2;
            int n3;
            ItemStack itemStack = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 15), " ");
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
            for (ShopPage shopPage : openEvent.getPages()) {
                shopPage.setIcon(i.a(shopPage.getIcon(), (Object)ChatColor.GOLD + ">> " + (Object)ChatColor.YELLOW + shopPage.getDisplayName()));
                shopGUIBuilder.addItem(shopPage);
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            for (n3 = 0; n3 < 9; ++n3) {
                shopGUIBuilder.setItemAt(itemStack, n3, shopGUIBuilder.getHeight() - 1);
            }
            if (openEvent.getOpen().getItems().size() == 0) {
                return shopGUIBuilder;
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 4);
            n3 = openEvent.getData();
            int n4 = n3 / 6 + 1;
            int n5 = openEvent.getOpen().getItems().size() - n3;
            if (n5 > 6) {
                n5 = 6;
                shopGUIBuilder.setItemAtWithData(openEvent.getOpen(), i.a(new ItemStack(Material.PAPER), b.a(Language.Shop_D_BergwerkLABS_ChangePage).a("page", "" + (n4 + 1)).f((CommandSender)openEvent.getPlayer())), 8, shopGUIBuilder.getHeight() - 3, n3 + n5);
            } else {
                shopGUIBuilder.setItemAt(i.a(new ItemStack(s.e), " "), 8, shopGUIBuilder.getHeight() - 3);
            }
            if (n3 >= 1) {
                shopGUIBuilder.setItemAtWithData(openEvent.getOpen(), i.a(new ItemStack(Material.PAPER), b.a(Language.Shop_D_BergwerkLABS_ChangePage).a("page", "" + (n4 - 1)).f((CommandSender)openEvent.getPlayer())), 8, shopGUIBuilder.getHeight() - 4, n3 - 6);
            } else {
                shopGUIBuilder.setItemAt(Version.a().addGlow(i.a(new ItemStack(Material.BOOK), b.a(Language.Shop_D_BergwerkLABS_CurrentPage).f((CommandSender)openEvent.getPlayer()))), 8, shopGUIBuilder.getHeight() - 4);
            }
            for (n2 = 0; n2 < n5; ++n2) {
                ShopItem shopItem = openEvent.getOpen().getItems().get(n2 + n3);
                if (shopItem.getPrices().size() >= 2) {
                    d.d("The BergwerkLABS shop design only displays 1 price!", "Shop");
                }
                ShopPrice shopPrice = shopItem.getPrices().get(0);
                int n6 = n2 + 1;
                shopGUIBuilder.setItemAt(i.a(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()), (Object)shopPrice.getSpawner().getChatColor() + shopPrice.getSpawner().getName()), n6, shopGUIBuilder.getHeight() - 4);
                shopGUIBuilder.setItemAt(shopItem.getIcon(), n6, shopGUIBuilder.getHeight() - 3);
                ItemStack itemStack2 = null;
                itemStack2 = shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) >= 1 ? i.a(new ItemStack(Material.INK_SACK, 1, 10), b.a(Language.Shop_D_BergwerkLABS_Buy).f((CommandSender)openEvent.getPlayer())) : i.a(new ItemStack(Material.INK_SACK, 1, 8), b.a(Language.Shop_D_BergwerkLABS_Buy_TooExpensive).f((CommandSender)openEvent.getPlayer()));
                shopGUIBuilder.setItemAt(shopItem, itemStack2, n6, shopGUIBuilder.getHeight() - 1);
            }
            for (n2 = 0; n2 < 9; ++n2) {
                shopGUIBuilder.setItemAt(itemStack, n2, shopGUIBuilder.getHeight() - 2);
            }
        }
        return shopGUIBuilder;
    }
}

