/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class NormalShopDesign
extends ShopDesign {
    private final ItemStack GLASS_CENTER = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 11), " ");

    @Override
    public ShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
        }
        for (ShopPage shopPage : openEvent.getPages()) {
            shopGUIBuilder.addItem(shopPage);
        }
        if (openEvent.getOpen() != null) {
            int n2;
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            for (n2 = 0; n2 < 9; ++n2) {
                shopGUIBuilder.setItemAt(this.GLASS_CENTER, n2, shopGUIBuilder.getHeight() - 1);
            }
            n2 = shopGUIBuilder.getHeight() - 2;
            for (int i2 = 0; i2 < (openEvent.getOpen().getItems().size() + 8) / 9; ++i2) {
                int n3;
                ArrayList<ShopItem> arrayList = new ArrayList<ShopItem>();
                int n4 = openEvent.getOpen().getItems().size() - i2 * 9 > 9 ? 9 : openEvent.getOpen().getItems().size() - i2 * 9;
                for (n3 = 0; n3 < n4; ++n3) {
                    arrayList.add(openEvent.getOpen().getItems().get(n3 + i2 * 9));
                }
                shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 2);
                n2 += 2;
                n3 = 0;
                for (ShopItem shopItem : arrayList) {
                    if (shopItem.getPrices().size() >= 2) {
                        d.d("The Normal shop design only displays 1 price!", "Shop");
                    }
                    ShopPrice shopPrice = shopItem.getPrices().get(0);
                    shopGUIBuilder.setItemAt(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()), n3, n2);
                    shopGUIBuilder.setItemAt(shopItem, n3, n2 + 1);
                    ++n3;
                }
            }
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Beautiful);
        return shopGUIBuilder;
    }
}

