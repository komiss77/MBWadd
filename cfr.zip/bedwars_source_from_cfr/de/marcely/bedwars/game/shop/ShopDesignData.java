/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.bo;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopDesignType;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;

public class ShopDesignData {
    private final ShopDesign design;
    private final String name;
    private final int id;
    private final ShopDesignType type;
    private static final List<ShopDesignData> designs = new ArrayList<ShopDesignData>();

    public ShopDesignData(ShopDesign shopDesign, String string) {
        this(shopDesign, string, -1, ShopDesignType.Custom);
    }

    @Deprecated
    public ShopDesignData(ShopDesign shopDesign, String string, int n2, ShopDesignType shopDesignType) {
        this.design = shopDesign;
        this.name = string;
        this.id = n2;
        this.type = shopDesignType;
    }

    public boolean register() {
        if (designs.contains(this)) {
            return false;
        }
        return designs.add(this);
    }

    public boolean unregister() {
        if (!this.isCustom()) {
            new bo("Only works for custom designs!").printStackTrace();
            return false;
        }
        return designs.remove(this);
    }

    public boolean isCustom() {
        return this.type == ShopDesignType.Custom;
    }

    public static ShopDesignData getDesignByName(String string) {
        ShopDesignData shopDesignData2;
        if (s.isInteger(string) && (shopDesignData2 = ShopDesignData.getDesignByID(Integer.valueOf(string))) != null) {
            return shopDesignData2;
        }
        for (ShopDesignData shopDesignData2 : designs) {
            if (!shopDesignData2.name.equalsIgnoreCase(string)) continue;
            return shopDesignData2;
        }
        return null;
    }

    public static ShopDesignData getDesignByID(int n2) {
        for (ShopDesignData shopDesignData : designs) {
            if (shopDesignData.id != n2) continue;
            return shopDesignData;
        }
        return null;
    }

    public ShopDesign getDesign() {
        return this.design;
    }

    public String getName() {
        return this.name;
    }

    public int getId() {
        return this.id;
    }

    public ShopDesignType getType() {
        return this.type;
    }

    public static List<ShopDesignData> getDesigns() {
        return designs;
    }
}

