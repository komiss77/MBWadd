/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.api.gui.VillagerGUI;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.command.CommandSender;

public class ShopVillagerGUIBuilder
extends SimpleShopGUIBuilder {
    private final VillagerGUI gui = new VillagerGUI(b.a(ConfigValue.dealer_title_gui).c().f(null));
    private List<VillagerGUI.VillagerOffer> offers = new ArrayList<VillagerGUI.VillagerOffer>();

    public ShopVillagerGUIBuilder(ShopDesign.OpenEvent openEvent) {
    }

    public void addOffer(VillagerGUI.VillagerOffer villagerOffer) {
        this.offers.add(villagerOffer);
    }

    public boolean removeOffer(VillagerGUI.VillagerOffer villagerOffer) {
        return this.offers.remove(villagerOffer);
    }

    public List<VillagerGUI.VillagerOffer> getOffers() {
        return this.offers;
    }

    @Override
    public SimpleGUI export() {
        this.gui.getOffers().addAll(this.offers);
        return this.gui;
    }
}

