/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.api.gui.VillagerGUI;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.ShopVillagerGUIBuilder;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.util.i;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class GommeHDShopDesign
extends ShopDesign {
    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        if (openEvent.getOpen() == null) {
            int n2;
            ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
            for (n2 = 0; n2 < 9; ++n2) {
                shopGUIBuilder.addItem(this.createGlassPane());
            }
            for (ShopPage shopPage : openEvent.getPages()) {
                shopGUIBuilder.addItem(shopPage);
            }
            n2 = shopGUIBuilder.getHeight();
            shopGUIBuilder.setHeight(n2 + 1);
            for (int i2 = 0; i2 < 9; ++i2) {
                shopGUIBuilder.addItem(this.createGlassPane(), GUI.AddItemFlag.createWithinY(n2, n2 + 1));
            }
            return shopGUIBuilder;
        }
        ShopVillagerGUIBuilder shopVillagerGUIBuilder = new ShopVillagerGUIBuilder(openEvent);
        for (ShopItem shopItem : openEvent.getOpen().getItems()) {
            if (shopItem.getProducts().size() >= 1 && shopItem.getPrices().size() >= 1) {
                ShopPrice shopPrice = shopItem.getPrices().get(0);
                if (shopItem.getProducts().size() == 1) {
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()))));
                } else {
                    ShopPrice shopPrice2 = shopItem.getPrices().get(1);
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount())), new DecGUIItem(i.a(shopPrice2.getSpawner().getActualItemstack(), shopPrice2.getAmount()))));
                }
            }
            if (shopItem.getProducts().size() >= 2) {
                d.d("The GommeHD shop design only displays 1 product per item!", "Shop");
            }
            if (shopItem.getPrices().size() < 3) continue;
            d.d("The GommeHD shop design only displays 1 or 2 prices per item!", "Shop");
        }
        return shopVillagerGUIBuilder;
    }

    private ItemStack createGlassPane() {
        return i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, 15), " ");
    }
}

