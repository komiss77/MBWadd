/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import java.util.List;
import org.bukkit.entity.Player;

public abstract class ShopDesign
implements Cloneable {
    public ClickListener listener;

    public abstract SimpleShopGUIBuilder open(OpenEvent var1);

    public ShopDesign clone() {
        try {
            return (ShopDesign)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public static interface ClickListener {
        public void onClick(Player var1, Object var2, boolean var3, boolean var4, int var5);
    }

    public static abstract class OpenEvent {
        private final ShopDesign shopDesign;
        private final Player player;
        private final List<ShopPage> pages;
        private final ShopPage open;
        private final int data;
        public SimpleShopGUIBuilder builder;
        private boolean openingPage = false;

        public OpenEvent(ShopDesign shopDesign, Player player, List<ShopPage> list, ShopPage shopPage, int n2) {
            this.player = player;
            this.shopDesign = shopDesign;
            this.pages = list;
            this.open = shopPage;
            this.data = n2;
        }

        public abstract void refresh();

        public ShopDesign getShopDesign() {
            return this.shopDesign;
        }

        public Player getPlayer() {
            return this.player;
        }

        public List<ShopPage> getPages() {
            return this.pages;
        }

        public ShopPage getOpen() {
            return this.open;
        }

        public int getData() {
            return this.data;
        }

        public boolean isOpeningPage() {
            return this.openingPage;
        }
    }

}

