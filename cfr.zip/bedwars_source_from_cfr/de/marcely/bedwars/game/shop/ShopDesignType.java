/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.bq;
import de.marcely.bedwars.game.shop.BergwerklabsShopDesign;
import de.marcely.bedwars.game.shop.GommeHDShopDesign;
import de.marcely.bedwars.game.shop.HiveMCShopDesign;
import de.marcely.bedwars.game.shop.HyPixelShopDesign;
import de.marcely.bedwars.game.shop.HyPixelV2ShopDesign;
import de.marcely.bedwars.game.shop.MinesuchtShopDesign;
import de.marcely.bedwars.game.shop.NormalShopDesign;
import de.marcely.bedwars.game.shop.RewinsideShopDesign;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;

public enum ShopDesignType {
    Normal(new NormalShopDesign(), 0, false),
    HyPixel(new HyPixelShopDesign(), 1, false),
    HiveMC(new HiveMCShopDesign(), 2, false),
    GommeHD(new GommeHDShopDesign(), 3, false),
    Rewinside(new RewinsideShopDesign(), 4, false),
    Minesucht(new MinesuchtShopDesign(), 5, false),
    BergwerkLABS(new BergwerklabsShopDesign(), 6, false),
    HyPixelV2(new HyPixelV2ShopDesign(), 7, false),
    Custom;
    
    @Nullable
    private final ShopDesignData data;
    private final boolean isBeta;

    private ShopDesignType() {
        this.data = null;
        this.isBeta = false;
    }

    private ShopDesignType(ShopDesign shopDesign, int n3, boolean bl2) {
        this.data = new ShopDesignData(shopDesign, this.name(), n3, this);
        this.isBeta = bl2;
        if (!this.data.register()) {
            new bq().printStackTrace();
        }
    }

    @Deprecated
    public static ShopDesignType byName(String string) {
        if (s.isInteger(string)) {
            return ShopDesignType.byId(Integer.valueOf(string));
        }
        for (ShopDesignType shopDesignType : ShopDesignType.values()) {
            if (!shopDesignType.name().equalsIgnoreCase(string)) continue;
            return shopDesignType;
        }
        return null;
    }

    @Deprecated
    public static ShopDesignType byId(int n2) {
        for (ShopDesignType shopDesignType : ShopDesignType.values()) {
            if (shopDesignType.data.getId() != n2) continue;
            return shopDesignType;
        }
        return null;
    }

    @Nullable
    public ShopDesignData getData() {
        return this.data;
    }

    public boolean isBeta() {
        return this.isBeta;
    }
}

