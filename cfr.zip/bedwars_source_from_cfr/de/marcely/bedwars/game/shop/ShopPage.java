/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class ShopPage
implements Cloneable {
    private final String name;
    private final String displayName;
    private List<ShopItem> items = new ArrayList<ShopItem>();
    private ItemStack icon = new ItemStack(Material.STONE);
    private Integer forceSlot;

    public ShopPage(String string) {
        this.name = string;
        this.displayName = b.a(string).c().b().f(null);
    }

    public ItemStack getIcon() {
        return this.icon.clone();
    }

    public ShopPage clone() {
        try {
            ShopPage shopPage = (ShopPage)super.clone();
            shopPage.items = new ArrayList<ShopItem>(this.items.size());
            for (ShopItem shopItem : this.items) {
                shopItem = shopItem.clone();
                shopItem.setPage(shopPage);
                shopPage.items.add(shopItem);
            }
            return shopPage;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public String getName() {
        return this.name;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public List<ShopItem> getItems() {
        return this.items;
    }

    public void setIcon(ItemStack itemStack) {
        this.icon = itemStack;
    }

    public Integer getForceSlot() {
        return this.forceSlot;
    }

    public void setForceSlot(Integer n2) {
        this.forceSlot = n2;
    }
}

