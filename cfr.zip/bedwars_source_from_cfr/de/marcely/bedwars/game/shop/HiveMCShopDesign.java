/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.game.shop.ShopGUIBuilder;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopPage;
import de.marcely.bedwars.game.shop.ShopPrice;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.SimpleShopGUIBuilder;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class HiveMCShopDesign
extends ShopDesign {
    private static final String ICON = "\u25b6";

    @Override
    public SimpleShopGUIBuilder open(ShopDesign.OpenEvent openEvent) {
        ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null) {
            for (ShopPage shopPage : openEvent.getPages()) {
                shopPage.setIcon(i.a(shopPage.getIcon(), "", b.a(Language.Shop_D_HiveMC_ClickToView).a("icon", ICON).a("item", shopPage.getDisplayName()).f((CommandSender)openEvent.getPlayer())));
                shopGUIBuilder.addItem(shopPage, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        } else {
            ShopItem shopItem2;
            int n2;
            for (ShopItem shopItem2 : openEvent.getOpen().getItems()) {
                ArrayList<String> arrayList = new ArrayList<String>();
                for (int i2 = 1; i2 < shopItem2.getProducts().size(); ++i2) {
                    ShopProduct shopProduct = shopItem2.getProducts().get(i2);
                    arrayList.add((Object)ChatColor.WHITE + (Object)ChatColor.BOLD + shopProduct.getAmount() + "x " + (Object)ChatColor.AQUA + (Object)ChatColor.BOLD + shopProduct.getDisplayName());
                }
                arrayList.add("");
                arrayList.add(b.a(Language.Shop_D_HiveMC_Cost).f((CommandSender)openEvent.getPlayer()));
                for (ShopPrice shopPrice : shopItem2.getPrices()) {
                    arrayList.add("  " + (Object)ChatColor.AQUA + shopPrice.getPrice(openEvent.getPlayer()) + " " + shopPrice.getSpawner().getName(true));
                }
                arrayList.add("");
                arrayList.add(b.a(Language.Shop_D_HiveMC_ClickToBuy).a("icon", ICON).f((CommandSender)openEvent.getPlayer()));
                shopItem2.setIcon(i.a(i.a(shopItem2.getIcon(), arrayList), (Object)ChatColor.WHITE + (Object)ChatColor.BOLD + shopItem2.getProducts().get(0).getAmount() + "x " + (Object)ChatColor.AQUA + (Object)ChatColor.BOLD + shopItem2.getProducts().get(0).getDisplayName()));
                shopGUIBuilder.addItem(shopItem2, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            shopItem2 = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)s.RAND.nextInt(15)), " ");
            for (n2 = 0; n2 < 9; ++n2) {
                shopGUIBuilder.setItemAt((ItemStack)shopItem2, n2, 0);
                shopGUIBuilder.setItemAt((ItemStack)shopItem2, n2, shopGUIBuilder.getHeight() - 1);
            }
            for (n2 = 0; n2 < shopGUIBuilder.getHeight(); ++n2) {
                shopGUIBuilder.setItemAt((ItemStack)shopItem2, 0, n2);
                shopGUIBuilder.setItemAt((ItemStack)shopItem2, 8, n2);
            }
            shopGUIBuilder.setHomeItemAt(i.a(i.a(new ItemStack(s.e), "", b.a(Language.Shop_D_HiveMC_ReturnToMenu).f((CommandSender)openEvent.getPlayer()), "", b.a(Language.Shop_D_HiveMC_ClickToGoBack).a("icon", ICON).f((CommandSender)openEvent.getPlayer())), b.a(Language.Shop_D_HiveMC_GoBack).f((CommandSender)openEvent.getPlayer())), 4, shopGUIBuilder.getHeight() - 1);
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
        }
        return shopGUIBuilder;
    }
}

