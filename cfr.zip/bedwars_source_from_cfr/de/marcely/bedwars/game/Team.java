/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.Color
 *  org.bukkit.DyeColor
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.command.CommandSender;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Team
extends Enum<Team> {
    public static final /* enum */ Team c = new Team(ChatColor.YELLOW, DyeColor.YELLOW, Color.YELLOW);
    public static final /* enum */ Team d = new Team(ChatColor.GOLD, DyeColor.ORANGE, Color.ORANGE);
    public static final /* enum */ Team e = new Team(ChatColor.RED, DyeColor.RED, Color.RED);
    public static final /* enum */ Team f = new Team(ChatColor.DARK_BLUE, DyeColor.BLUE, Color.BLUE);
    public static final /* enum */ Team g = new Team(ChatColor.BLUE, DyeColor.LIGHT_BLUE, Color.NAVY);
    public static final /* enum */ Team h = new Team(ChatColor.AQUA, DyeColor.CYAN, Color.fromRGB((int)0, (int)255, (int)255));
    public static final /* enum */ Team i = new Team(ChatColor.GREEN, DyeColor.LIME, Color.LIME);
    public static final /* enum */ Team j = new Team(ChatColor.DARK_GREEN, DyeColor.GREEN, Color.GREEN);
    public static final /* enum */ Team k = new Team(ChatColor.DARK_PURPLE, DyeColor.PURPLE, Color.PURPLE);
    public static final /* enum */ Team l = new Team(ChatColor.LIGHT_PURPLE, DyeColor.PINK, Color.FUCHSIA);
    public static final /* enum */ Team m = new Team(ChatColor.WHITE, DyeColor.WHITE, Color.WHITE);
    public static final /* enum */ Team n = new Team(ChatColor.GRAY, DyeColor.SILVER, Color.SILVER);
    public static final /* enum */ Team o = new Team(ChatColor.DARK_GRAY, DyeColor.GRAY, Color.GRAY);
    public static final /* enum */ Team p = new Team(ChatColor.DARK_RED, DyeColor.BROWN, Color.fromRGB((int)139, (int)69, (int)19));
    public static final /* enum */ Team q = new Team(ChatColor.BLACK, DyeColor.BLACK, Color.BLACK);
    private ChatColor b;
    private DyeColor a;
    private Color a;
    private static Map<Team, String> j;
    private static /* synthetic */ int[] i;
    private static final /* synthetic */ Team[] a;

    static {
        a = new Team[]{c, d, e, f, g, h, i, j, k, l, m, n, o, p, q};
        j = new HashMap();
    }

    private Team(ChatColor chatColor, DyeColor dyeColor, Color color) {
        this.b = chatColor;
        this.a = dyeColor;
        this.a = color;
    }

    public String getName() {
        return this.a(null);
    }

    public String getName(boolean bl2) {
        return this.a(null, bl2);
    }

    public String a(@Nullable CommandSender commandSender) {
        return this.a(commandSender, true);
    }

    public String a(@Nullable CommandSender commandSender, boolean bl2) {
        String string = this.a(commandSender, this);
        if (string == null || string.isEmpty()) {
            string = this.name();
        }
        if (bl2) {
            return String.valueOf(string.substring(0, 1).toUpperCase()) + string.substring(1, string.length());
        }
        return string;
    }

    public String m() {
        return this.d(null);
    }

    public String d(@Nullable CommandSender commandSender) {
        String string = this.a(commandSender, true);
        String string2 = "";
        boolean bl2 = false;
        for (int i2 = 0; i2 < string.length(); ++i2) {
            char c2 = string.charAt(i2);
            if (Character.isUpperCase(c2) || bl2) {
                string2 = String.valueOf(string2) + Character.toUpperCase(c2);
                bl2 = false;
                continue;
            }
            if (c2 != ' ') continue;
            bl2 = true;
        }
        return string2;
    }

    private String a(@Nullable CommandSender commandSender, Team team) {
        switch (Team.j()[team.ordinal()]) {
            case 1: {
                return b.a(Language.Color_Yellow).f(commandSender);
            }
            case 2: {
                return b.a(Language.Color_Orange).f(commandSender);
            }
            case 3: {
                return b.a(Language.Color_Red).f(commandSender);
            }
            case 4: {
                return b.a(Language.Color_Blue).f(commandSender);
            }
            case 5: {
                return b.a(Language.Color_LightBlue).f(commandSender);
            }
            case 6: {
                return b.a(Language.Color_Cyan).f(commandSender);
            }
            case 7: {
                return b.a(Language.Color_LightGreen).f(commandSender);
            }
            case 8: {
                return b.a(Language.Color_Green).f(commandSender);
            }
            case 9: {
                return b.a(Language.Color_Purple).f(commandSender);
            }
            case 10: {
                return b.a(Language.Color_Pink).f(commandSender);
            }
            case 11: {
                return b.a(Language.Color_White).f(commandSender);
            }
            case 12: {
                return b.a(Language.Color_LightGray).f(commandSender);
            }
            case 13: {
                return b.a(Language.Color_Gray).f(commandSender);
            }
            case 14: {
                return b.a(Language.Color_Brown).f(commandSender);
            }
            case 15: {
                return b.a(Language.Color_Black).f(commandSender);
            }
        }
        return null;
    }

    public ChatColor getChatColor() {
        return this.b;
    }

    public DyeColor getDyeColor() {
        return this.a;
    }

    public Color getColor() {
        return this.a;
    }

    public static Team a(String string) {
        return Team.a(null, string);
    }

    public static Team a(String string, boolean bl2) {
        return Team.a(null, string, bl2);
    }

    public static Team a(@Nullable CommandSender commandSender, String string) {
        return Team.a(commandSender, string, false);
    }

    public static Team a(@Nullable CommandSender commandSender, String string, boolean bl2) {
        if (string == null) {
            return null;
        }
        for (Team object : Team.values()) {
            if (!string.equalsIgnoreCase(object.toString()) && !string.equalsIgnoreCase(object.toString().replace("_", "")) && !string.equalsIgnoreCase(object.toString().replace("_", "").replace(" ", "")) && !string.equalsIgnoreCase(object.a(commandSender)) && !string.equalsIgnoreCase(object.a(commandSender).replace(" ", ""))) continue;
            return object;
        }
        if (bl2) {
            for (Map.Entry entry : j.entrySet()) {
                Team team = (Team)((Object)entry.getKey());
                String string2 = (String)entry.getValue();
                if (string.equalsIgnoreCase(string2)) {
                    return team;
                }
                if (!string.equalsIgnoreCase(string2.replace(" ", ""))) continue;
                return team;
            }
        }
        return null;
    }

    public static List<String> l() {
        return Team.c(null);
    }

    public static List<String> b(boolean bl2) {
        return Team.b(null, bl2);
    }

    public static List<String> a(boolean bl2, boolean bl3) {
        return Team.a(null, bl2, bl3);
    }

    public static List<String> c(@Nullable CommandSender commandSender) {
        return Team.a(commandSender, true, false);
    }

    public static List<String> b(@Nullable CommandSender commandSender, boolean bl2) {
        return Team.a(commandSender, bl2, false);
    }

    public static List<String> a(@Nullable CommandSender commandSender, boolean bl2, boolean bl3) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Team team : Team.values()) {
            arrayList.add(bl3 ? team.a(commandSender, bl2).replace(" ", "") : team.a(commandSender, bl2));
        }
        return arrayList;
    }

    public static Team a(ChatColor chatColor) {
        for (Team team : Team.values()) {
            if (team.getChatColor() != chatColor) continue;
            return team;
        }
        return null;
    }

    public static Team a(DyeColor dyeColor) {
        for (Team team : Team.values()) {
            if (team.getDyeColor() != dyeColor) continue;
            return team;
        }
        return null;
    }

    public static void a(Team team, String string) {
        j.put(team, string);
    }

    public static void y() {
        j.clear();
    }

    public static Team[] values() {
        Team[] arrteam = a;
        int n2 = arrteam.length;
        Team[] arrteam2 = new Team[n2];
        System.arraycopy(arrteam, 0, arrteam2, 0, n2);
        return arrteam2;
    }

    public static Team valueOf(String string) {
        return Enum.valueOf(Team.class, string);
    }

    static /* synthetic */ int[] j() {
        if (i != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[Team.values().length];
        try {
            arrn[Team.q.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.f.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.p.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.h.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.o.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.j.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.g.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.n.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.i.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.l.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.k.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.m.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[Team.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        i = arrn;
        return i;
    }
}

