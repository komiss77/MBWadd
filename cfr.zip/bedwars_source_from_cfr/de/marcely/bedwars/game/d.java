/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.game.SimpleBlock;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class d
implements Serializable {
    private static final long serialVersionUID = -176089766393982401L;
    public List<SimpleBlock> s = new ArrayList<SimpleBlock>();

    public d() {
    }

    public d(List<SimpleBlock> list) {
        this.s = list;
    }

    public void a(SimpleBlock simpleBlock) {
        this.s.add(simpleBlock);
    }

    public void a(Location location, Material material) {
        this.s.add(new SimpleBlock(location, material));
    }

    public void a(int n2, int n3, int n4, Material material) {
        this.s.add(new SimpleBlock(n2, n3, n4, material));
    }

    public void a(Block block) {
        this.s.add(new SimpleBlock(block));
    }

    public HashMap<String, SimpleBlock> b() {
        HashMap<String, SimpleBlock> hashMap = new HashMap<String, SimpleBlock>();
        for (SimpleBlock simpleBlock : this.s) {
            hashMap.put(String.valueOf(simpleBlock.x) + "," + simpleBlock.y + "," + simpleBlock.z, simpleBlock);
        }
        return hashMap;
    }
}

