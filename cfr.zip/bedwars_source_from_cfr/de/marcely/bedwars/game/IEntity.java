/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.bq;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.cG;
import de.marcely.bedwars.cH;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.cK;
import de.marcely.bedwars.cL;
import de.marcely.bedwars.cN;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.location.XYZYPW;
import de.marcely.bedwars.holographic.NPCType;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.io.Serializable;
import java.util.Arrays;
import java.util.UUID;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class IEntity
implements Serializable {
    private static final long serialVersionUID = 1L;
    private IEntityType type;
    private XYZYPW loc;
    private Object[] param;
    private transient c<?> hologram;

    public IEntity(IEntityType iEntityType, Location location, Object[] arrobject) {
        this(iEntityType, XYZYPW.valueOf(location), arrobject);
    }

    public IEntity(IEntityType iEntityType, XYZYPW xYZYPW, Object[] arrobject) {
        this.type = iEntityType;
        this.loc = xYZYPW;
        this.param = arrobject;
    }

    public void x() {
        if (!this.isSpawnable()) {
            new bq().printStackTrace();
            return;
        }
        NPCType nPCType = this.type.a();
        NPCType.a a2 = nPCType.a();
        if (a2 == NPCType.a.b) {
            this.hologram = c.a(cN.class, this.loc.toBukkit(), new cH().a(this.type.a(this)));
        } else if (a2 == NPCType.a.d) {
            this.hologram = c.a(cK.class, this.loc.toBukkit(), new cG().a(this.type.a(this)).a((UUID)nPCType.getArguments()[0]));
        } else if (a2 == NPCType.a.e) {
            this.hologram = c.a(cL.class, this.loc.toBukkit(), new cG().a(this.type.a(this)));
        } else if (a2 == NPCType.a.c) {
            this.hologram = c.a(cI.class, this.loc.toBukkit(), ((cE)nPCType.getArguments()[0]).a(this.type.a(this)));
        }
        this.hologram.Q();
        if (this.type == IEntityType.TeamSelect && this.hologram.a() instanceof de.marcely.bedwars.holographic.b) {
            de.marcely.bedwars.holographic.b b2 = (de.marcely.bedwars.holographic.b)this.hologram.a();
            b2.a().a(e.a.a, new ItemStack(Material.STAINED_CLAY, 1, (short)((Team)((Object)this.param[0])).getDyeColor().getWoolData()));
        }
    }

    public void remove() {
        this.hologram.remove();
    }

    public static IEntity a(Location location) {
        return new IEntity(IEntityType.Dealer, XYZYPW.valueOf(location), new Object[0]);
    }

    public static IEntity a(Location location, int n2, int n3) {
        return new IEntity(IEntityType.Hub, XYZYPW.valueOf(location), Arrays.asList(0, n2, n3).toArray());
    }

    public static IEntity a(Location location, Arena arena) {
        return new IEntity(IEntityType.Hub, XYZYPW.valueOf(location), Arrays.asList(1, arena.getName()).toArray());
    }

    public static IEntity a(Location location, Team team) {
        return new IEntity(IEntityType.TeamSelect, XYZYPW.valueOf(location), Arrays.asList(new Team[]{team}).toArray());
    }

    public static IEntity b(Location location) {
        return new IEntity(IEntityType.UpgradeDealer, XYZYPW.valueOf(location), new Object[0]);
    }

    public boolean isSpawnable() {
        return this.loc.getWorld() != null;
    }

    public IEntityType a() {
        return this.type;
    }

    public XYZYPW a() {
        return this.loc;
    }

    public Object[] a() {
        return this.param;
    }

    public c<?> a() {
        return this.hologram;
    }

    public static enum IEntityType {
        Dealer,
        Hub,
        TeamSelect,
        UpgradeDealer;
        
        private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType;

        public NPCType a() {
            switch (IEntityType.i()[this.ordinal()]) {
                case 1: {
                    return ConfigValue.entitytype_dealer;
                }
                case 2: {
                    return ConfigValue.entitytype_hub;
                }
                case 3: {
                    return ConfigValue.entitytype_teamselect;
                }
                case 4: {
                    return ConfigValue.entitytype_upgradedealer;
                }
            }
            return null;
        }

        public String a(IEntity iEntity) {
            switch (IEntityType.i()[this.ordinal()]) {
                case 1: {
                    return b.a(ConfigValue.dealer_title).c().f(null);
                }
                case 2: {
                    if ((Integer)iEntity.param[0] == 0) {
                        return String.valueOf(ConfigValue.lobbyvillager_prefix) + iEntity.param[1] + "x" + iEntity.param[2];
                    }
                    if ((Integer)iEntity.param[0] == 1) {
                        Arena arena;
                        return String.valueOf(ConfigValue.lobbyvillager_prefix) + ((arena = s.b((String)iEntity.param[1])) != null ? arena.getDisplayName() : iEntity.param[1]);
                    }
                }
                case 3: {
                    return ((Team)((Object)iEntity.param[0])).a(null, true);
                }
                case 4: {
                    return b.a(ConfigValue.upgradedealer_title).c().f(null);
                }
            }
            return null;
        }

        static /* synthetic */ int[] i() {
            if ($SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType != null) {
                int[] arrn;
                return arrn;
            }
            int[] arrn = new int[IEntityType.values().length];
            try {
                arrn[IEntityType.Dealer.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[IEntityType.Hub.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[IEntityType.TeamSelect.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[IEntityType.UpgradeDealer.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            $SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType = arrn;
            return $SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType;
        }
    }

}

