/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.api.LobbyItemType;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.inventory.ItemStack;

public class LobbyItem
implements de.marcely.bedwars.api.LobbyItem {
    private int slot;
    private ItemStack is;
    private a a = null;
    private List<String> commands = new ArrayList<String>();

    public LobbyItem(int n2, ItemStack itemStack) {
        this(n2, itemStack, null);
    }

    public LobbyItem(int n2, ItemStack itemStack, a a2) {
        this.slot = n2;
        this.is = itemStack;
        this.a = a2;
    }

    @Override
    public void addCommand(String string) {
        this.commands.add(string);
    }

    @Override
    public int getSlot() {
        return this.slot;
    }

    @Override
    public ItemStack getItemStack() {
        return this.is;
    }

    public a a() {
        return this.a;
    }

    @Override
    public List<String> getCommands() {
        return this.commands;
    }

    @Override
    public void setSlot(int n2) {
        this.slot = n2;
    }

    @Override
    public void setItemStack(ItemStack itemStack) {
        this.is = itemStack;
    }

    public void a(a a2) {
        this.a = a2;
    }

    @Override
    public LobbyItemType getType() {
        return this.a() != null ? LobbyItemType.fromNMS(this.a().getType()) : null;
    }

    public static class a {
        private final LobbySpecialType type;
        private final String name;

        public a(LobbySpecialType lobbySpecialType) {
            this(lobbySpecialType, lobbySpecialType.name());
        }

        public a(LobbySpecialType lobbySpecialType, String string) {
            this.type = lobbySpecialType;
            this.name = string;
        }

        public LobbySpecialType getType() {
            return this.type;
        }

        public String getName() {
            return this.name;
        }
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class LobbySpecialType
    extends Enum<LobbySpecialType> {
        public static final /* enum */ LobbySpecialType a = new LobbySpecialType();
        public static final /* enum */ LobbySpecialType b = new LobbySpecialType();
        public static final /* enum */ LobbySpecialType c = new LobbySpecialType();
        public static final /* enum */ LobbySpecialType d = new LobbySpecialType();
        public static final /* enum */ LobbySpecialType e = new LobbySpecialType();
        public static final /* enum */ LobbySpecialType f = new LobbySpecialType();
        private static final /* synthetic */ LobbySpecialType[] a;

        static {
            a = new LobbySpecialType[]{a, b, c, d, e, f};
        }

        public static LobbySpecialType a(String string) {
            for (LobbySpecialType lobbySpecialType : LobbySpecialType.values()) {
                if (!lobbySpecialType.name().equalsIgnoreCase(string)) continue;
                return lobbySpecialType;
            }
            return null;
        }

        public static LobbySpecialType[] values() {
            LobbySpecialType[] arrlobbySpecialType = a;
            int n2 = arrlobbySpecialType.length;
            LobbySpecialType[] arrlobbySpecialType2 = new LobbySpecialType[n2];
            System.arraycopy(arrlobbySpecialType, 0, arrlobbySpecialType2, 0, n2);
            return arrlobbySpecialType2;
        }

        public static LobbySpecialType valueOf(String string) {
            return Enum.valueOf(LobbySpecialType.class, string);
        }
    }

}

