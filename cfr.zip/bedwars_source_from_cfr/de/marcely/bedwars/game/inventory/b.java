/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.inventory;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.inventory.PlayerData;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.UUID;
import org.bukkit.entity.Player;

@Deprecated
public class b {
    public static PlayerData a(Player player) throws Exception {
        if (ConfigValue.inventory_backup) {
            FileInputStream fileInputStream = new FileInputStream(b.a(player.getUniqueId()));
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            PlayerData playerData = (PlayerData)objectInputStream.readObject();
            objectInputStream.close();
            return playerData;
        }
        if (ConfigValue.inventory_clear) {
            s.M(player);
        }
        return new PlayerData(player);
    }

    public static void a(PlayerData playerData) {
        try {
            if (ConfigValue.inventory_backup) {
                FileOutputStream fileOutputStream = new FileOutputStream(b.a(playerData.getUniqueId()));
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(playerData);
                objectOutputStream.close();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static File a(UUID uUID) {
        return new File("plugins/MBedwars/data/playerinvs/" + uUID + ".yml");
    }
}

