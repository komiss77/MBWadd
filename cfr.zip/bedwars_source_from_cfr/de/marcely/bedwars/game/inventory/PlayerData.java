/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.potion.PotionEffect
 */
package de.marcely.bedwars.game.inventory;

import de.marcely.bedwars.game.inventory.a;
import de.marcely.bedwars.game.inventory.b;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;

@Deprecated
public class PlayerData
implements Serializable {
    private static final long serialVersionUID = -6702784113641141250L;
    private UUID uuid;
    private String inventory;
    private String inventory_armor;
    private boolean flying = false;
    private boolean ingame = false;
    private GameMode gamemode = GameMode.ADVENTURE;
    private int level = 0;
    private int food = 20;
    private float exp = 0.0f;
    private double health = 20.0;
    private List<String> activePotions = new ArrayList<String>();
    private XYZW compassTarget = new XYZW(s.a(), 0.0, 0.0, 0.0);

    public PlayerData(Player player) {
        this.uuid = player.getUniqueId();
        this.inventory = a.a(player.getInventory().getContents());
        this.inventory_armor = a.a(player.getInventory().getArmorContents());
        this.flying = player.getAllowFlight();
        this.gamemode = player.getGameMode();
        this.level = player.getLevel();
        this.food = player.getFoodLevel();
        this.exp = player.getExp();
        this.health = de.marcely.bedwars.util.b.a(player);
        this.compassTarget = XYZW.valueOf(player.getCompassTarget());
        for (PotionEffect potionEffect : player.getActivePotionEffects()) {
            this.activePotions.add(a.a(potionEffect));
        }
    }

    public void u(Player player) {
        ItemStack[] arritemStack = a.a(this.inventory);
        if (arritemStack.length > Version.a().u()) {
            arritemStack = Arrays.copyOfRange(arritemStack, 0, Version.a().u());
        }
        player.getInventory().setContents(arritemStack);
        player.getInventory().setArmorContents(a.a(this.inventory_armor));
        player.updateInventory();
        player.setAllowFlight(this.flying);
        player.setGameMode(this.gamemode);
        player.setLevel(this.level);
        player.setFoodLevel(this.food);
        player.setExp(this.exp);
        player.setHealth(this.health <= player.getHealth() ? this.health : player.getMaxHealth());
        player.setCompassTarget(this.compassTarget.toBukkit());
        if (this.activePotions.size() != 0) {
            for (String string : this.activePotions) {
                player.addPotionEffect(a.a(string));
            }
        }
    }

    public void a(ItemStack[] arritemStack) {
        this.inventory = a.a(arritemStack);
    }

    public void b(ItemStack[] arritemStack) {
        this.inventory_armor = a.a(arritemStack);
    }

    public void setFlying(boolean bl2) {
        this.flying = bl2;
    }

    public void setGameMode(GameMode gameMode) {
        this.gamemode = gameMode;
    }

    public void setLevel(int n2) {
        this.level = n2;
    }

    public void setFoodLevel(int n2) {
        this.food = n2;
    }

    public void setExp(float f2) {
        this.exp = f2;
    }

    public void setHealth(double d2) {
        this.health = d2;
    }

    public void d(List<String> list) {
        this.activePotions = list;
    }

    public void f(boolean bl2) {
        this.ingame = bl2;
    }

    public UUID getUniqueId() {
        return this.uuid;
    }

    public ItemStack[] a() {
        return a.a(this.inventory);
    }

    public ItemStack[] b() {
        return a.a(this.inventory_armor);
    }

    public boolean isFlying() {
        return this.flying;
    }

    public GameMode getGameMode() {
        return this.gamemode;
    }

    public int getLevel() {
        return this.level;
    }

    public int getFoodLevel() {
        return this.food;
    }

    public float getExp() {
        return this.exp;
    }

    public double getHealth() {
        return this.health;
    }

    public List<String> s() {
        return this.activePotions;
    }

    public boolean isIngame() {
        return this.ingame;
    }

    public void save() {
        b.a(this);
    }
}

