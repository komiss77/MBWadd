/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.org.apache.commons.codec.binary.Base64
 *  org.apache.commons.codec.binary.Base64
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.util.io.BukkitObjectInputStream
 *  org.bukkit.util.io.BukkitObjectOutputStream
 *  org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder
 */
package de.marcely.bedwars.game.inventory;

import de.marcely.bedwars.versions.Version;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.codec.binary.Base64;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class a {
    public static String a(ItemStack[] arritemStack) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            BukkitObjectOutputStream bukkitObjectOutputStream = new BukkitObjectOutputStream((OutputStream)byteArrayOutputStream);
            bukkitObjectOutputStream.writeInt(arritemStack.length);
            for (ItemStack itemStack : arritemStack) {
                bukkitObjectOutputStream.writeObject((Object)itemStack);
            }
            bukkitObjectOutputStream.close();
            return Base64Coder.encodeLines((byte[])byteArrayOutputStream.toByteArray());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static ItemStack[] a(String string) {
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Base64Coder.decodeLines((String)string));
            BukkitObjectInputStream bukkitObjectInputStream = new BukkitObjectInputStream((InputStream)byteArrayInputStream);
            int n2 = bukkitObjectInputStream.readInt();
            ItemStack[] arritemStack = new ItemStack[n2];
            for (int i2 = 0; i2 < n2; ++i2) {
                arritemStack[i2] = (ItemStack)bukkitObjectInputStream.readObject();
            }
            bukkitObjectInputStream.close();
            return arritemStack;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static String a(PotionEffect potionEffect) {
        String string = String.valueOf(potionEffect.getType().getId()) + "." + potionEffect.getDuration() + "." + potionEffect.getAmplifier();
        if (Version.a().getVersionNumber() >= 8) {
            return Base64.encodeBase64String((byte[])string.getBytes());
        }
        return net.minecraft.util.org.apache.commons.codec.binary.Base64.encodeBase64String((byte[])string.getBytes());
    }

    public static PotionEffect a(String string) {
        try {
            String string2 = null;
            string2 = Version.a().getVersionNumber() >= 8 ? new String(Base64.decodeBase64((String)string)) : new String(net.minecraft.util.org.apache.commons.codec.binary.Base64.decodeBase64((String)string));
            String[] arrstring = string2.split("\\.");
            return new PotionEffect(PotionEffectType.getById((int)Integer.valueOf(arrstring[0])), Integer.valueOf(arrstring[1]).intValue(), Integer.valueOf(arrstring[2]).intValue());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }
}

