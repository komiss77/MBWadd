/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game.regeneration;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.regeneration.a;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.game.regeneration.d;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import java.io.File;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class e
extends a {
    public e(Arena arena, CommandSender commandSender) {
        super(RegenerationType.d, arena, commandSender);
    }

    @Override
    protected void a(final File file) {
        final e e2 = this;
        if (ConfigValue.regeneration_threadsafe) {
            new MThread(MThread.ThreadType.m, this.arena.getName()){

                @Override
                public void run() {
                    while (e2.isRunning()) {
                        e.this.b(file);
                        s.sleep(1000L);
                    }
                }
            }.start();
        } else {
            new BukkitRunnable(){

                public void run() {
                    if (!e2.isRunning()) {
                        this.cancel();
                        return;
                    }
                    e.this.b(file);
                }
            }.runTaskTimer((Plugin)MBedwars.a, 0L, 20L);
        }
    }

    private void b(File file) {
        World world = d.a(this.arena.getWorld(), file);
        new de.marcely.bedwars.game.regeneration.e$3(true, world);
    }

    @Override
    protected void s() {
    }

    @Override
    protected void a(File file, c c2) {
        c2.a(d.a(this.arena.getWorld(), file));
    }

}

