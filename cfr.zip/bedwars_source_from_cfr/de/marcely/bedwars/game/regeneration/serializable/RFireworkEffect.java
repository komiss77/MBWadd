/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.FireworkEffect$Builder
 *  org.bukkit.FireworkEffect$Type
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.regeneration.serializable.RColor;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;

@Deprecated
public class RFireworkEffect
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private List<RColor> color;
    private List<RColor> color_fade;
    private FireworkEffect.Type type;
    private boolean flicker;
    private boolean trail;

    public RFireworkEffect(FireworkEffect fireworkEffect) {
        this.color = this.b(fireworkEffect.getColors());
        this.color_fade = this.b(fireworkEffect.getFadeColors());
        this.type = fireworkEffect.getType();
        this.flicker = fireworkEffect.hasFlicker();
        this.trail = fireworkEffect.hasTrail();
    }

    public FireworkEffect a() {
        FireworkEffect.Builder builder = FireworkEffect.builder();
        builder.withColor(this.c(this.color));
        builder.withFade(this.c(this.color_fade));
        builder.with(this.type);
        if (this.flicker) {
            builder.withFlicker();
        }
        if (this.trail) {
            builder.withTrail();
        }
        return builder.build();
    }

    private List<RColor> b(List<Color> list) {
        ArrayList<RColor> arrayList = new ArrayList<RColor>();
        for (Color color : list) {
            arrayList.add(new RColor(color));
        }
        return arrayList;
    }

    private List<Color> c(List<RColor> list) {
        ArrayList<Color> arrayList = new ArrayList<Color>();
        for (RColor rColor : list) {
            arrayList.add(rColor.a());
        }
        return arrayList;
    }
}

