/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.d;
import de.marcely.bedwars.game.SimpleBlock;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.regeneration.serializable.RBlockContainer;
import de.marcely.bedwars.versions.Version;
import java.io.Serializable;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

@Deprecated
public class RBlock
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private int x;
    private int y;
    private int z;
    private String type;
    private byte data;
    private RBlockContainer container = null;

    public RBlock(Block block) {
        this.x = block.getX();
        this.y = block.getY();
        this.z = block.getZ();
        this.type = block.getType().name();
        this.data = block.getData();
        if (RBlockContainer.RBlockContainerType.a(block.getType()) != null) {
            this.container = new RBlockContainer(block);
        }
    }

    public RBlock(SimpleBlock simpleBlock) {
        this.x = simpleBlock.x;
        this.y = simpleBlock.y;
        this.z = simpleBlock.z;
        this.type = simpleBlock.block;
        if (simpleBlock.data != null) {
            this.data = simpleBlock.data;
        }
    }

    public Material getType() {
        try {
            return Material.valueOf((String)this.type);
        }
        catch (Exception exception) {
            d.b("There was a issue getting the material of a block at x" + this.x + "y" + this.y + "z" + this.z + ". It has been replaced by air!");
            return Material.AIR;
        }
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public void a(World world, Arena arena) {
        block3 : {
            Block block = world.getBlockAt(this.x, this.y, this.z);
            Version.a().a(block.getLocation(), this.getType(), this.data);
            if (this.container != null) {
                try {
                    this.container.d(block);
                }
                catch (Exception exception) {
                    if (Version.a().getVersionNumber() < 13 || exception.getMessage() == null || !exception.getMessage().contains("cannot be cast to org.bukkit.block.Furnace")) break block3;
                    d.a("This blocks of this arena are still of 1.12 and older. Please resave them with /bw arena saveblocks " + arena.getDisplayName(), arena);
                }
            }
        }
    }

    public byte getData() {
        return this.data;
    }

    public RBlockContainer a() {
        return this.container;
    }
}

