/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.regeneration.serializable.RPotionEffectType;
import java.io.Serializable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

@Deprecated
public class RPotionEffect
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private RPotionEffectType type;
    private int duration;
    private int amplifier;
    private boolean ambient;
    private boolean particles;

    public RPotionEffect(PotionEffect potionEffect) {
        this.type = new RPotionEffectType(potionEffect.getType());
        this.duration = potionEffect.getDuration();
        this.amplifier = potionEffect.getAmplifier();
        this.ambient = potionEffect.isAmbient();
        this.particles = potionEffect.hasParticles();
    }

    public PotionEffect a() {
        return new PotionEffect(this.type.a(), this.duration, this.amplifier, this.ambient, this.particles);
    }
}

