/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Rabbit
 *  org.bukkit.entity.Rabbit$Type
 */
package de.marcely.bedwars.game.regeneration.serializable;

import java.io.Serializable;
import org.bukkit.entity.Rabbit;

@Deprecated
public class RRabbitType
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private String type;

    public RRabbitType(Rabbit.Type type) {
        this.type = type.name();
    }

    public Rabbit.Type a() {
        return Rabbit.Type.valueOf((String)this.type);
    }
}

