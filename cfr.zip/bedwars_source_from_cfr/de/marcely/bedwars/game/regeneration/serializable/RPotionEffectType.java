/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.potion.PotionEffectType
 */
package de.marcely.bedwars.game.regeneration.serializable;

import java.io.Serializable;
import org.bukkit.potion.PotionEffectType;

@Deprecated
public class RPotionEffectType
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private String name;

    public RPotionEffectType(PotionEffectType potionEffectType) {
        this.name = potionEffectType.getName();
    }

    public PotionEffectType a() {
        return PotionEffectType.getByName((String)this.name);
    }
}

