/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.material.MaterialData
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.regeneration.serializable.RItemMeta;
import java.io.Serializable;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.MaterialData;

@Deprecated
public class RItemStack
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private Material material;
    private int amount;
    private short durability;
    private RItemMeta itemmeta = null;

    public RItemStack(ItemStack itemStack) {
        if (itemStack == null) {
            itemStack = new ItemStack(Material.AIR);
        }
        this.material = itemStack.getType();
        this.amount = itemStack.getAmount();
        this.durability = itemStack.getDurability();
        if (itemStack.getItemMeta() != null) {
            this.itemmeta = new RItemMeta(itemStack.getItemMeta());
        }
    }

    public void c(ItemStack itemStack) {
        itemStack.setType(this.material);
        itemStack.setAmount(this.amount);
        itemStack.setDurability(this.durability);
        if (this.itemmeta != null) {
            this.itemmeta.b(itemStack);
        }
    }

    public ItemStack d() {
        ItemStack itemStack = new ItemStack(this.material, this.amount, this.durability);
        if (this.itemmeta != null) {
            this.itemmeta.b(itemStack);
        }
        return itemStack;
    }

    public MaterialData a() {
        return new MaterialData(this.material, (byte)this.durability);
    }
}

