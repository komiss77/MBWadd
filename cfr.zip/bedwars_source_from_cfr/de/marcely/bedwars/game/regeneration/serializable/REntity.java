/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.d;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.game.location.XYZYPW;
import de.marcely.bedwars.game.regeneration.serializable.REntityContainer;
import java.io.Serializable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
@Deprecated
public class REntity
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private XYZW loc;
    private XYZYPW nLoc;
    private String type;
    private boolean customNameVisible;
    private String customName;
    private int entityId;
    private Integer passangerId;
    private REntityContainer container;
    private transient Entity latestSpawned = null;

    public REntity(Entity entity) {
        if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM) {
            this.nLoc = XYZYPW.valueOf(entity.getLocation());
            this.type = entity.getType().name();
            this.customNameVisible = entity.isCustomNameVisible();
            this.customName = entity.getCustomName();
            this.entityId = entity.getEntityId();
            this.container = new REntityContainer(entity);
            if (entity.getPassenger() != null && entity.getPassenger().getType() != EntityType.PLAYER && entity.getPassenger().getType() != EntityType.DROPPED_ITEM) {
                this.passangerId = entity.getPassenger().getEntityId();
            }
        } else {
            throw new NullPointerException("This doesn't support " + entity.getType().name());
        }
    }

    public int p() {
        return this.entityId;
    }

    public Integer b() {
        return this.passangerId;
    }

    public Entity a() {
        return this.latestSpawned;
    }

    public Entity b() {
        Entity entity = null;
        try {
            this.a(this.loc.getWorld());
        }
        catch (Exception exception) {
            this.a(this.nLoc.getWorld());
        }
        return entity;
    }

    public EntityType getType() {
        return EntityType.valueOf((String)this.type);
    }

    public Entity a(World world) {
        Entity entity = null;
        try {
            entity = world.spawnEntity(new Location(world, this.loc.getX(), this.loc.getY(), this.loc.getZ()), this.getType());
            d.e("[Regeneration] We recommend you to use /bw arena regenerate <arena name> again!");
        }
        catch (Exception exception) {
            if (this.getType() == EntityType.ITEM_FRAME) {
                XYZYPW xYZYPW = this.nLoc.clone();
                if (this.container.itemframe_direction == BlockFace.NORTH) {
                    xYZYPW.setZ((int)xYZYPW.getZ() - 1);
                } else if (this.container.itemframe_direction == BlockFace.SOUTH) {
                    xYZYPW.setZ((int)xYZYPW.getZ() - 1);
                } else if (this.container.itemframe_direction == BlockFace.EAST) {
                    xYZYPW.setZ((int)xYZYPW.getZ() - 1);
                } else if (this.container.itemframe_direction == BlockFace.WEST) {
                    xYZYPW.setZ((int)xYZYPW.getZ() - 1);
                }
                entity = world.spawnEntity(new Location(world, xYZYPW.getX(), xYZYPW.getY(), xYZYPW.getZ()), this.getType());
            }
            entity = world.spawnEntity(new Location(world, this.nLoc.getX(), this.nLoc.getY(), this.nLoc.getZ(), this.nLoc.getYaw(), this.nLoc.getPitch()), this.getType());
        }
        entity.setCustomNameVisible(this.customNameVisible);
        entity.setCustomName(this.customName);
        this.container.a(entity);
        this.latestSpawned = entity;
        return entity;
    }
}

