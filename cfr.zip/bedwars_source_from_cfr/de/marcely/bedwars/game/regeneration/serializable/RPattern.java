/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.DyeColor
 *  org.bukkit.block.banner.Pattern
 *  org.bukkit.block.banner.PatternType
 */
package de.marcely.bedwars.game.regeneration.serializable;

import java.io.Serializable;
import org.bukkit.DyeColor;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;

@Deprecated
public class RPattern
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private DyeColor color;
    private PatternType type;

    public RPattern(Pattern pattern) {
        this.color = pattern.getColor();
        this.type = pattern.getPattern();
    }

    public Pattern a() {
        return new Pattern(this.color, this.type);
    }
}

