/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Art
 *  org.bukkit.DyeColor
 *  org.bukkit.Material
 *  org.bukkit.Rotation
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Ageable
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Arrow
 *  org.bukkit.entity.Bat
 *  org.bukkit.entity.Boat
 *  org.bukkit.entity.Creeper
 *  org.bukkit.entity.Enderman
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Guardian
 *  org.bukkit.entity.Horse
 *  org.bukkit.entity.Horse$Color
 *  org.bukkit.entity.Horse$Style
 *  org.bukkit.entity.IronGolem
 *  org.bukkit.entity.ItemFrame
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Minecart
 *  org.bukkit.entity.Ocelot
 *  org.bukkit.entity.Ocelot$Type
 *  org.bukkit.entity.Painting
 *  org.bukkit.entity.Pig
 *  org.bukkit.entity.PigZombie
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.Rabbit
 *  org.bukkit.entity.Rabbit$Type
 *  org.bukkit.entity.Sheep
 *  org.bukkit.entity.Skeleton
 *  org.bukkit.entity.Skeleton$SkeletonType
 *  org.bukkit.entity.Slime
 *  org.bukkit.entity.Villager
 *  org.bukkit.entity.Villager$Profession
 *  org.bukkit.entity.Wolf
 *  org.bukkit.entity.Zombie
 *  org.bukkit.entity.minecart.CommandMinecart
 *  org.bukkit.inventory.EntityEquipment
 *  org.bukkit.inventory.HorseInventory
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.material.MaterialData
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.util.EulerAngle
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.regeneration.serializable.RItemStack;
import de.marcely.bedwars.game.regeneration.serializable.RPotionEffect;
import de.marcely.bedwars.game.regeneration.serializable.RRabbitType;
import de.marcely.bedwars.util.d;
import de.marcely.bedwars.versions.Version;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.Art;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Rotation;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Guardian;
import org.bukkit.entity.Horse;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Painting;
import org.bukkit.entity.Pig;
import org.bukkit.entity.PigZombie;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Rabbit;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.HorseInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.MaterialData;
import org.bukkit.potion.PotionEffect;
import org.bukkit.util.EulerAngle;
import org.bukkit.util.Vector;

@Deprecated
public class REntityContainer
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private XYZ velocity;
    private RItemStack helmet = new RItemStack(new ItemStack(Material.AIR));
    private RItemStack chestplate = new RItemStack(new ItemStack(Material.AIR));
    private RItemStack leggings = new RItemStack(new ItemStack(Material.AIR));
    private RItemStack boots = new RItemStack(new ItemStack(Material.AIR));
    private boolean canPickupItems;
    private boolean removeWhenFarAway;
    private List<RPotionEffect> activePotionEffects = new ArrayList<RPotionEffect>();
    private double maxHealth;
    private double health;
    private Integer leashEntityId = null;
    private boolean noAI;
    private boolean bounce;
    private boolean breed;
    private boolean adult;
    private boolean agelock;
    private int age;
    private RItemStack[] content;
    private double minecart_damage;
    private double minecart_maxSpeed;
    private XYZ minecart_derailedVector;
    private RItemStack minecart_block;
    private boolean minecart_slowWhenEmpty;
    private int slime_size;
    private XYZ armorstand_headpose;
    private XYZ armorstand_bodypose;
    private XYZ armorstand_leftarmpose;
    private XYZ armorstand_rightarmpose;
    private XYZ armorstand_leftlegpose;
    private XYZ armorstand_rightlegpose;
    private boolean armorstand_small;
    private boolean armorstand_visible;
    private boolean armorstand_gravity;
    private boolean armorstand_baseplate;
    private boolean arrow_critical;
    private int arrow_knockbackStrength;
    private boolean bat_awake;
    private double boat_maxSpeed;
    private double boat_occupiedDeceleration;
    private double boat_unoccupiedDeceleration;
    private boolean boat_workOnLand;
    private boolean creeper_powered;
    private RItemStack enderman_item;
    private boolean guardian_elder;
    private Horse.Color horse_color;
    private RItemStack horse_armor;
    private RItemStack horse_saddle;
    private boolean horse_chest;
    private Horse.Style horse_style;
    private boolean irongolem_playerCreated;
    public BlockFace itemframe_direction;
    private RItemStack itemframe_item;
    private Rotation itemframe_rotation;
    private String minecartcommand_command;
    private Ocelot.Type ocelot_type;
    private boolean ocelot_sitting;
    private Art painting_art;
    private boolean pig_saddle;
    private int pigzombie_anger;
    private boolean pigzombie_angry;
    private RRabbitType rabbit_type;
    private boolean sheep_sheared;
    private Skeleton.SkeletonType skeleton_type;
    private Villager.Profession villager_profession;
    private DyeColor wolf_color;
    private boolean wolf_angry;
    private boolean wolf_sitting;
    private boolean zombie_baby;

    public REntityContainer(Entity entity) {
        LivingEntity livingEntity;
        EntityType entityType = entity.getType();
        if (entity instanceof LivingEntity) {
            livingEntity = (LivingEntity)entity;
            this.velocity = XYZ.valueOf(livingEntity.getVelocity());
            this.canPickupItems = livingEntity.getCanPickupItems();
            for (PotionEffect potionEffect : livingEntity.getActivePotionEffects()) {
                this.activePotionEffects.add(new RPotionEffect(potionEffect));
            }
            this.removeWhenFarAway = livingEntity.getRemoveWhenFarAway();
            this.maxHealth = livingEntity.getMaxHealth();
            this.health = livingEntity.getHealth();
            if (livingEntity.getEquipment() != null) {
                this.helmet = new RItemStack(livingEntity.getEquipment().getHelmet());
                this.chestplate = new RItemStack(livingEntity.getEquipment().getChestplate());
                this.leggings = new RItemStack(livingEntity.getEquipment().getLeggings());
                this.boots = new RItemStack(livingEntity.getEquipment().getBoots());
            }
            if (livingEntity.isLeashed() && livingEntity.getLeashHolder().getType() != EntityType.PLAYER && livingEntity.getLeashHolder().getType() != EntityType.DROPPED_ITEM) {
                this.leashEntityId = livingEntity.getLeashHolder().getEntityId();
            }
            if (Version.a().getVersionNumber() <= 8) {
                this.noAI = Version.a().b(entity);
            }
        }
        if (entity instanceof Projectile) {
            livingEntity = (Projectile)entity;
            this.bounce = livingEntity.doesBounce();
        }
        if (entity instanceof Ageable) {
            livingEntity = (Ageable)entity;
            this.breed = livingEntity.canBreed();
            this.adult = livingEntity.isAdult();
            this.agelock = livingEntity.getAgeLock();
            this.age = livingEntity.getAge();
        }
        if (entity instanceof InventoryHolder) {
            livingEntity = (InventoryHolder)entity;
            this.content = new RItemStack[livingEntity.getInventory().getSize()];
            for (int i2 = 0; i2 < livingEntity.getInventory().getSize(); ++i2) {
                this.content[i2] = new RItemStack(livingEntity.getInventory().getItem(i2));
            }
        }
        if (entity instanceof Minecart) {
            livingEntity = (Minecart)entity;
            this.minecart_damage = livingEntity.getDamage();
            this.minecart_maxSpeed = livingEntity.getMaxSpeed();
            this.minecart_derailedVector = XYZ.valueOf(livingEntity.getDerailedVelocityMod());
            this.minecart_block = new RItemStack(livingEntity.getDisplayBlock().toItemStack());
            this.minecart_slowWhenEmpty = livingEntity.isSlowWhenEmpty();
        }
        if (entity instanceof Slime) {
            livingEntity = (Slime)entity;
            this.slime_size = livingEntity.getSize();
        }
        if (entityType == EntityType.ARMOR_STAND) {
            livingEntity = (ArmorStand)entity;
            this.armorstand_headpose = d.a(livingEntity.getHeadPose());
            this.armorstand_bodypose = d.a(livingEntity.getBodyPose());
            this.armorstand_leftarmpose = d.a(livingEntity.getLeftArmPose());
            this.armorstand_rightarmpose = d.a(livingEntity.getRightArmPose());
            this.armorstand_leftlegpose = d.a(livingEntity.getLeftLegPose());
            this.armorstand_rightlegpose = d.a(livingEntity.getRightLegPose());
            this.armorstand_small = livingEntity.isSmall();
            this.armorstand_visible = livingEntity.isVisible();
            this.armorstand_gravity = livingEntity.hasGravity();
            this.armorstand_baseplate = livingEntity.hasBasePlate();
        } else if (entityType == EntityType.ARROW) {
            livingEntity = (Arrow)entity;
            this.arrow_critical = livingEntity.isCritical();
            this.arrow_knockbackStrength = livingEntity.getKnockbackStrength();
        } else if (entityType == EntityType.BAT) {
            livingEntity = (Bat)entity;
            this.bat_awake = livingEntity.isAwake();
        } else if (entityType == EntityType.BOAT) {
            livingEntity = (Boat)entity;
            this.boat_maxSpeed = livingEntity.getMaxSpeed();
            this.boat_occupiedDeceleration = livingEntity.getOccupiedDeceleration();
            this.boat_unoccupiedDeceleration = livingEntity.getUnoccupiedDeceleration();
            this.boat_workOnLand = livingEntity.getWorkOnLand();
        } else if (entityType == EntityType.CREEPER) {
            livingEntity = (Creeper)entity;
            this.creeper_powered = livingEntity.isPowered();
        } else if (entityType == EntityType.ENDERMAN) {
            livingEntity = (Enderman)entity;
            this.enderman_item = new RItemStack(livingEntity.getCarriedMaterial().toItemStack());
        } else if (entityType == EntityType.GUARDIAN) {
            livingEntity = (Guardian)entity;
            this.guardian_elder = livingEntity.isElder();
        } else if (entityType == EntityType.HORSE) {
            livingEntity = (Horse)entity;
            this.horse_color = livingEntity.getColor();
            this.horse_armor = new RItemStack(livingEntity.getInventory().getArmor());
            this.horse_saddle = new RItemStack(livingEntity.getInventory().getSaddle());
            this.horse_style = livingEntity.getStyle();
        } else if (entityType == EntityType.IRON_GOLEM) {
            livingEntity = (IronGolem)entity;
            this.irongolem_playerCreated = livingEntity.isPlayerCreated();
        } else if (entityType == EntityType.ITEM_FRAME) {
            livingEntity = (ItemFrame)entity;
            this.itemframe_direction = livingEntity.getFacing();
            this.itemframe_item = new RItemStack(livingEntity.getItem());
            this.itemframe_rotation = livingEntity.getRotation();
        } else if (entityType == EntityType.MINECART_COMMAND) {
            livingEntity = (CommandMinecart)entity;
            this.minecartcommand_command = livingEntity.getCommand();
        } else if (entityType == EntityType.OCELOT) {
            livingEntity = (Ocelot)entity;
            this.ocelot_type = livingEntity.getCatType();
            this.ocelot_sitting = livingEntity.isSitting();
        } else if (entityType == EntityType.PAINTING) {
            livingEntity = (Painting)entity;
            this.painting_art = livingEntity.getArt();
        } else if (entityType == EntityType.PIG) {
            livingEntity = (Pig)entity;
            this.pig_saddle = livingEntity.hasSaddle();
        } else if (entityType == EntityType.PIG_ZOMBIE) {
            livingEntity = (PigZombie)entity;
            this.pigzombie_anger = livingEntity.getAnger();
            this.pigzombie_angry = livingEntity.isAngry();
        } else if (entityType == EntityType.RABBIT) {
            livingEntity = (Rabbit)entity;
            this.rabbit_type = new RRabbitType(livingEntity.getRabbitType());
        } else if (entityType == EntityType.SHEEP) {
            livingEntity = (Sheep)entity;
            this.sheep_sheared = livingEntity.isSheared();
        } else if (entityType == EntityType.SKELETON) {
            livingEntity = (Skeleton)entity;
            this.skeleton_type = livingEntity.getSkeletonType();
        } else if (entityType == EntityType.VILLAGER) {
            livingEntity = (Villager)entity;
            this.villager_profession = livingEntity.getProfession();
        } else if (entityType == EntityType.WOLF) {
            livingEntity = (Wolf)entity;
            this.wolf_color = livingEntity.getCollarColor();
            this.wolf_angry = livingEntity.isAngry();
            this.wolf_sitting = livingEntity.isSitting();
        } else if (entityType == EntityType.ZOMBIE) {
            livingEntity = (Zombie)entity;
            this.zombie_baby = livingEntity.isBaby();
        }
    }

    public void a(Entity entity) {
        LivingEntity livingEntity;
        EntityType entityType = entity.getType();
        if (entity instanceof LivingEntity) {
            livingEntity = (LivingEntity)entity;
            livingEntity.setVelocity(this.velocity.toVector());
            livingEntity.setCanPickupItems(this.canPickupItems);
            for (RPotionEffect object : this.activePotionEffects) {
                livingEntity.addPotionEffect(object.a());
            }
            livingEntity.setRemoveWhenFarAway(this.removeWhenFarAway);
            livingEntity.setMaxHealth(this.maxHealth);
            livingEntity.setHealth(this.health);
            if (livingEntity.getEquipment() != null) {
                livingEntity.getEquipment().setHelmet(this.helmet.d());
                livingEntity.getEquipment().setChestplate(this.chestplate.d());
                livingEntity.getEquipment().setLeggings(this.leggings.d());
                livingEntity.getEquipment().setBoots(this.boots.d());
            }
            if (Version.a().getVersionNumber() <= 8) {
                Version.a().b(entity, this.noAI);
            }
        }
        if (entity instanceof Projectile) {
            livingEntity = (Projectile)entity;
            livingEntity.setBounce(this.bounce);
        }
        if (entity instanceof Ageable) {
            livingEntity = (Ageable)entity;
            livingEntity.setBreed(this.breed);
            if (this.adult) {
                livingEntity.setAdult();
            } else {
                livingEntity.setBaby();
            }
            livingEntity.setAgeLock(this.agelock);
            livingEntity.setAge(this.age);
        }
        if (entity instanceof InventoryHolder) {
            livingEntity = (InventoryHolder)entity;
            ItemStack[] arritemStack = new ItemStack[this.content.length];
            for (int i2 = 0; i2 < this.content.length; ++i2) {
                arritemStack[i2] = this.content[i2].d();
            }
            livingEntity.getInventory().setContents(arritemStack);
        }
        if (entity instanceof Minecart) {
            livingEntity = (Minecart)entity;
            livingEntity.setDamage(this.minecart_damage);
            livingEntity.setMaxSpeed(this.minecart_maxSpeed);
            livingEntity.setDerailedVelocityMod(this.minecart_derailedVector.toVector());
            livingEntity.setDisplayBlock(this.minecart_block.a());
            livingEntity.setSlowWhenEmpty(this.minecart_slowWhenEmpty);
        }
        if (entityType == EntityType.SLIME) {
            livingEntity = (Slime)entity;
            livingEntity.setSize(this.slime_size);
        } else if (entityType == EntityType.ARMOR_STAND) {
            livingEntity = (ArmorStand)entity;
            livingEntity.setHeadPose(d.a(this.armorstand_headpose));
            livingEntity.setBodyPose(d.a(this.armorstand_bodypose));
            livingEntity.setLeftArmPose(d.a(this.armorstand_leftarmpose));
            livingEntity.setRightArmPose(d.a(this.armorstand_rightarmpose));
            livingEntity.setLeftLegPose(d.a(this.armorstand_leftlegpose));
            livingEntity.setRightLegPose(d.a(this.armorstand_rightlegpose));
            livingEntity.setSmall(this.armorstand_small);
            livingEntity.setVisible(this.armorstand_visible);
            livingEntity.setGravity(this.armorstand_gravity);
            livingEntity.setBasePlate(this.armorstand_baseplate);
        } else if (entityType == EntityType.ARROW) {
            livingEntity = (Arrow)entity;
            livingEntity.setCritical(this.arrow_critical);
            livingEntity.setKnockbackStrength(this.arrow_knockbackStrength);
        } else if (entityType == EntityType.BAT) {
            livingEntity = (Bat)entity;
            livingEntity.setAwake(this.bat_awake);
        } else if (entityType == EntityType.BOAT) {
            livingEntity = (Boat)entity;
            livingEntity.setMaxSpeed(this.boat_maxSpeed);
            livingEntity.setOccupiedDeceleration(this.boat_occupiedDeceleration);
            livingEntity.setUnoccupiedDeceleration(this.boat_unoccupiedDeceleration);
            livingEntity.setWorkOnLand(this.boat_workOnLand);
        } else if (entityType == EntityType.CREEPER) {
            livingEntity = (Creeper)entity;
            livingEntity.setPowered(this.creeper_powered);
        } else if (entityType == EntityType.ENDERMAN) {
            livingEntity = (Enderman)entity;
            livingEntity.setCarriedMaterial(this.enderman_item.a());
        } else if (entityType == EntityType.GUARDIAN) {
            livingEntity = (Guardian)entity;
            livingEntity.setElder(this.guardian_elder);
        } else if (entityType == EntityType.HORSE) {
            livingEntity = (Horse)entity;
            livingEntity.setColor(this.horse_color);
            livingEntity.getInventory().setArmor(this.horse_armor.d());
            livingEntity.getInventory().setSaddle(this.horse_saddle.d());
            livingEntity.setCarryingChest(this.horse_chest);
            livingEntity.setStyle(this.horse_style);
        } else if (entityType == EntityType.IRON_GOLEM) {
            livingEntity = (IronGolem)entity;
            livingEntity.setPlayerCreated(this.irongolem_playerCreated);
        } else if (entityType == EntityType.ITEM_FRAME) {
            livingEntity = (ItemFrame)entity;
            livingEntity.setItem(this.itemframe_item.d());
            livingEntity.setRotation(this.itemframe_rotation);
        } else if (entityType == EntityType.MINECART_COMMAND) {
            livingEntity = (CommandMinecart)entity;
            livingEntity.setCommand(this.minecartcommand_command);
        } else if (entityType == EntityType.OCELOT) {
            livingEntity = (Ocelot)entity;
            if (Version.a().getVersionNumber() <= 13) {
                livingEntity.setCatType(this.ocelot_type);
            }
            livingEntity.setSitting(this.ocelot_sitting);
        } else if (entityType == EntityType.PAINTING) {
            livingEntity = (Painting)entity;
            livingEntity.setArt(this.painting_art, true);
        } else if (entityType == EntityType.PIG) {
            livingEntity = (Pig)entity;
            livingEntity.setSaddle(this.pig_saddle);
        } else if (entityType == EntityType.PIG_ZOMBIE) {
            livingEntity = (PigZombie)entity;
            livingEntity.setAnger(this.pigzombie_anger);
            livingEntity.setAngry(this.pigzombie_angry);
        } else if (entityType == EntityType.RABBIT) {
            livingEntity = (Rabbit)entity;
            livingEntity.setRabbitType(this.rabbit_type.a());
        } else if (entityType == EntityType.SHEEP) {
            livingEntity = (Sheep)entity;
            livingEntity.setSheared(this.sheep_sheared);
        } else if (entityType == EntityType.SKELETON) {
            livingEntity = (Skeleton)entity;
            livingEntity.setSkeletonType(this.skeleton_type);
        } else if (entityType == EntityType.VILLAGER) {
            livingEntity = (Villager)entity;
            livingEntity.setProfession(this.villager_profession);
        } else if (entityType == EntityType.WOLF) {
            livingEntity = (Wolf)entity;
            livingEntity.setCollarColor(this.wolf_color);
            livingEntity.setAngry(this.wolf_angry);
            livingEntity.setSitting(this.wolf_sitting);
        } else if (entityType == EntityType.ZOMBIE) {
            livingEntity = (Zombie)entity;
            livingEntity.setBaby(this.zombie_baby);
        }
    }
}

