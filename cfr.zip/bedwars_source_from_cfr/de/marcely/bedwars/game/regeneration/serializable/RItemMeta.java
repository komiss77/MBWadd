/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.FireworkEffect
 *  org.bukkit.block.banner.Pattern
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.BannerMeta
 *  org.bukkit.inventory.meta.BookMeta
 *  org.bukkit.inventory.meta.EnchantmentStorageMeta
 *  org.bukkit.inventory.meta.FireworkMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.LeatherArmorMeta
 *  org.bukkit.inventory.meta.PotionMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.potion.PotionEffect
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.e;
import de.marcely.bedwars.game.regeneration.serializable.RColor;
import de.marcely.bedwars.game.regeneration.serializable.RFireworkEffect;
import de.marcely.bedwars.game.regeneration.serializable.RPattern;
import de.marcely.bedwars.game.regeneration.serializable.RPotionEffect;
import de.marcely.bedwars.util.s;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.block.banner.Pattern;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;

@Deprecated
public class RItemMeta
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private String displayName;
    private Map<e, Integer> enchantments;
    private List<String> lore;
    private List<ItemFlag> flags;
    private RItemMetaType type;
    private String skull_owner;
    private List<RPattern> banner_patterns;
    private List<RPotionEffect> potion_effects;
    private RColor leatherarmor_color;
    private int firework_power;
    private List<RFireworkEffect> firework_effects;
    private String book_title;
    private String book_author;
    private List<String> book_pages;
    private Map<e, Integer> enchantedstorage_enchantments;

    public RItemMeta(ItemMeta itemMeta) {
        this.displayName = itemMeta.getDisplayName();
        this.enchantments = this.a(itemMeta.getEnchants());
        List list = this.lore = itemMeta.getLore() != null ? itemMeta.getLore() : new ArrayList();
        if (s.a(ItemMeta.class, "getItemFlags", new Class[0])) {
            this.flags = new ArrayList<ItemFlag>(itemMeta.getItemFlags());
        }
        if (itemMeta instanceof SkullMeta) {
            this.type = RItemMetaType.Skull;
            SkullMeta skullMeta = (SkullMeta)itemMeta;
            this.skull_owner = skullMeta.getOwner();
        } else if (itemMeta instanceof BannerMeta) {
            this.type = RItemMetaType.Banner;
            BannerMeta bannerMeta = (BannerMeta)itemMeta;
            ArrayList<RPattern> arrayList = new ArrayList<RPattern>();
            for (Pattern pattern : bannerMeta.getPatterns()) {
                arrayList.add(new RPattern(pattern));
            }
            this.banner_patterns = arrayList;
        } else if (itemMeta instanceof PotionMeta) {
            this.type = RItemMetaType.Potion;
            PotionMeta potionMeta = (PotionMeta)itemMeta;
            this.potion_effects = new ArrayList<RPotionEffect>();
            for (PotionEffect potionEffect : potionMeta.getCustomEffects()) {
                this.potion_effects.add(new RPotionEffect(potionEffect));
            }
        } else if (itemMeta instanceof LeatherArmorMeta) {
            this.type = RItemMetaType.LeatherArmor;
            LeatherArmorMeta leatherArmorMeta = (LeatherArmorMeta)itemMeta;
            this.leatherarmor_color = new RColor(leatherArmorMeta.getColor());
        } else if (itemMeta instanceof FireworkMeta) {
            this.type = RItemMetaType.Firework;
            FireworkMeta fireworkMeta = (FireworkMeta)itemMeta;
            ArrayList<RFireworkEffect> arrayList = new ArrayList<RFireworkEffect>();
            for (FireworkEffect fireworkEffect : fireworkMeta.getEffects()) {
                arrayList.add(new RFireworkEffect(fireworkEffect));
            }
            this.firework_power = fireworkMeta.getPower();
            this.firework_effects = arrayList;
        } else if (itemMeta instanceof BookMeta) {
            this.type = RItemMetaType.Book;
            BookMeta bookMeta = (BookMeta)itemMeta;
            this.book_title = bookMeta.getTitle();
            this.book_author = bookMeta.getAuthor();
            this.book_pages = new ArrayList<String>(bookMeta.getPages());
        } else if (itemMeta instanceof EnchantmentStorageMeta) {
            this.type = RItemMetaType.EnchantmentStorage;
            EnchantmentStorageMeta enchantmentStorageMeta = (EnchantmentStorageMeta)itemMeta;
            this.enchantedstorage_enchantments = this.a(enchantmentStorageMeta.getStoredEnchants());
        } else {
            this.type = RItemMetaType.Normal;
        }
    }

    public void b(ItemStack itemStack) {
        ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(this.displayName);
        for (Map.Entry<Enchantment, Integer> entry : this.b(this.enchantments).entrySet()) {
            itemMeta.addEnchant(entry.getKey(), entry.getValue().intValue(), true);
        }
        itemMeta.setLore(this.lore);
        try {
            for (ItemFlag itemFlag : this.flags) {
                itemMeta.addItemFlags(new ItemFlag[]{itemFlag});
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (this.type == RItemMetaType.Skull) {
            SkullMeta skullMeta = (SkullMeta)itemMeta;
            skullMeta.setOwner(this.skull_owner);
        } else if (this.type == RItemMetaType.Banner) {
            BannerMeta bannerMeta = (BannerMeta)itemMeta;
            for (RPattern rPattern : this.banner_patterns) {
                bannerMeta.addPattern(rPattern.a());
            }
        } else if (this.type == RItemMetaType.Potion) {
            PotionMeta potionMeta = (PotionMeta)itemMeta;
            for (RPotionEffect rPotionEffect : this.potion_effects) {
                potionMeta.addCustomEffect(rPotionEffect.a(), true);
            }
        } else if (this.type == RItemMetaType.LeatherArmor) {
            LeatherArmorMeta leatherArmorMeta = (LeatherArmorMeta)itemMeta;
            leatherArmorMeta.setColor(this.leatherarmor_color.a());
        } else if (this.type == RItemMetaType.Firework) {
            FireworkMeta fireworkMeta = (FireworkMeta)itemMeta;
            fireworkMeta.setPower(this.firework_power);
            for (RFireworkEffect rFireworkEffect : this.firework_effects) {
                fireworkMeta.addEffect(rFireworkEffect.a());
            }
        } else if (this.type == RItemMetaType.Book) {
            BookMeta bookMeta = (BookMeta)itemMeta;
            bookMeta.setTitle(this.book_title);
            bookMeta.setAuthor(this.book_author);
            bookMeta.setPages(this.book_pages);
        } else if (this.type == RItemMetaType.EnchantmentStorage) {
            EnchantmentStorageMeta enchantmentStorageMeta = (EnchantmentStorageMeta)itemMeta;
            for (Map.Entry<Enchantment, Integer> entry : this.b(this.enchantedstorage_enchantments).entrySet()) {
                enchantmentStorageMeta.addStoredEnchant(entry.getKey(), entry.getValue().intValue(), true);
            }
        }
        itemStack.setItemMeta(itemMeta);
    }

    private Map<e, Integer> a(Map<Enchantment, Integer> map) {
        HashMap<e, Integer> hashMap = new HashMap<e, Integer>();
        for (Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            hashMap.put(e.a(entry.getKey()), entry.getValue());
        }
        return hashMap;
    }

    private Map<Enchantment, Integer> b(Map<e, Integer> map) {
        HashMap<Enchantment, Integer> hashMap = new HashMap<Enchantment, Integer>();
        for (Map.Entry<e, Integer> entry : map.entrySet()) {
            hashMap.put(entry.getKey().a(), entry.getValue());
        }
        return hashMap;
    }

    public static enum RItemMetaType {
        Normal,
        Skull,
        Banner,
        Potion,
        LeatherArmor,
        Firework,
        Book,
        EnchantmentStorage;
        
    }

}

