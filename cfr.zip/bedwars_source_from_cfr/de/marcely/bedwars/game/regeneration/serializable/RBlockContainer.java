/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.SkullType
 *  org.bukkit.block.Beacon
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Chest
 *  org.bukkit.block.Dispenser
 *  org.bukkit.block.Dropper
 *  org.bukkit.block.Furnace
 *  org.bukkit.block.Hopper
 *  org.bukkit.block.ShulkerBox
 *  org.bukkit.block.Sign
 *  org.bukkit.block.Skull
 *  org.bukkit.inventory.FurnaceInventory
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.game.regeneration.serializable.RItemStack;
import de.marcely.bedwars.game.regeneration.serializable.RPotionEffectType;
import de.marcely.bedwars.util.s;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.block.Beacon;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.Dispenser;
import org.bukkit.block.Dropper;
import org.bukkit.block.Furnace;
import org.bukkit.block.Hopper;
import org.bukkit.block.ShulkerBox;
import org.bukkit.block.Sign;
import org.bukkit.block.Skull;
import org.bukkit.inventory.FurnaceInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

@Deprecated
public class RBlockContainer
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private RBlockContainerType type;
    private String title;
    private List<RItemStack> items;
    private short furnace_burnTime;
    private short furnace_cookTime;
    private RPotionEffectType beacon_primary;
    private RPotionEffectType beacon_secoundary;
    private String[] sign_lines;
    private String skull_owner;
    private BlockFace skull_rotation;
    private SkullType skull_type;

    public RBlockContainer(Block block) {
        this.type = RBlockContainerType.a(block.getType());
        if (this.type == RBlockContainerType.Chest) {
            Chest chest = (Chest)block.getState();
            this.title = chest.getBlockInventory().getTitle();
            this.items = this.a(chest.getBlockInventory().getContents());
        } else if (this.type == RBlockContainerType.Furnace) {
            Furnace furnace = (Furnace)block.getState();
            this.title = furnace.getInventory().getTitle();
            this.furnace_burnTime = furnace.getBurnTime();
            this.furnace_cookTime = furnace.getCookTime();
            this.items = new ArrayList<RItemStack>();
            this.items.add(new RItemStack(furnace.getInventory().getSmelting()));
            this.items.add(new RItemStack(furnace.getInventory().getFuel()));
            this.items.add(new RItemStack(furnace.getInventory().getResult()));
        } else if (this.type == RBlockContainerType.Dropper) {
            Dropper dropper = (Dropper)block.getState();
            this.title = dropper.getInventory().getTitle();
            this.items = this.a(dropper.getInventory().getContents());
        } else if (this.type == RBlockContainerType.Dispenser) {
            Dispenser dispenser = (Dispenser)block.getState();
            this.title = dispenser.getInventory().getTitle();
            this.items = this.a(dispenser.getInventory().getContents());
        } else if (this.type == RBlockContainerType.Hopper) {
            Hopper hopper = (Hopper)block.getState();
            this.title = hopper.getInventory().getTitle();
            this.items = this.a(hopper.getInventory().getContents());
        } else if (this.type == RBlockContainerType.Beacon) {
            Beacon beacon = (Beacon)block.getState();
            this.title = beacon.getInventory().getTitle();
            Object object = s.a((Object)beacon, "getPrimaryEffect", new Class[0], new Object[0], false);
            Object object2 = s.a((Object)beacon, "getSecoundaryEffect", new Class[0], new Object[0], false);
            if (object != null) {
                this.beacon_primary = new RPotionEffectType(((PotionEffect)object).getType());
            }
            if (object2 != null) {
                this.beacon_secoundary = new RPotionEffectType(((PotionEffect)object2).getType());
            }
        } else if (this.type == RBlockContainerType.Shulker_Box) {
            ShulkerBox shulkerBox = (ShulkerBox)block.getState();
            this.title = shulkerBox.getInventory().getTitle();
            this.items = this.a(shulkerBox.getInventory().getContents());
        } else if (this.type == RBlockContainerType.Sign) {
            Sign sign = (Sign)block.getState();
            this.sign_lines = sign.getLines();
        } else if (this.type == RBlockContainerType.Skull) {
            Skull skull = (Skull)block.getState();
            this.skull_owner = skull.getOwner();
            this.skull_rotation = skull.getRotation();
            this.skull_type = skull.getSkullType();
        } else {
            throw new NullPointerException("block is not a container!");
        }
    }

    public void d(Block block) {
        if (this.type == RBlockContainerType.Chest) {
            Chest chest = (Chest)block.getState();
            chest.getBlockInventory().setContents(this.a(this.items));
        } else if (this.type == RBlockContainerType.Furnace) {
            Furnace furnace = (Furnace)block.getState();
            furnace.setBurnTime(this.furnace_burnTime);
            furnace.setCookTime(this.furnace_cookTime);
            furnace.getInventory().setSmelting(this.items.get(0).d());
            furnace.getInventory().setFuel(this.items.get(1).d());
            furnace.getInventory().setResult(this.items.get(2).d());
        } else if (this.type == RBlockContainerType.Dropper) {
            Dropper dropper = (Dropper)block.getState();
            dropper.getInventory().setContents(this.a(this.items));
        } else if (this.type == RBlockContainerType.Dispenser) {
            Dispenser dispenser = (Dispenser)block.getState();
            dispenser.getInventory().setContents(this.a(this.items));
        } else if (this.type == RBlockContainerType.Hopper) {
            Hopper hopper = (Hopper)block.getState();
            hopper.getInventory().setContents(this.a(this.items));
        } else if (this.type == RBlockContainerType.Beacon) {
            Beacon beacon = (Beacon)block.getState();
            Class[] arrclass = new Class[1];
            Object[] arrobject = new Object[1];
            arrclass[0] = PotionEffectType.class;
            if (this.beacon_primary != null) {
                arrobject[0] = this.beacon_primary.a();
                s.a((Object)beacon, "setPrimaryEffect", arrclass, arrobject);
            } else if (this.beacon_secoundary != null) {
                arrobject[0] = this.beacon_secoundary.a();
                s.a((Object)beacon, "setSecoundaryEffect", arrclass, arrobject);
            }
        } else if (this.type == RBlockContainerType.Shulker_Box) {
            ShulkerBox shulkerBox = (ShulkerBox)block.getState();
            shulkerBox.getInventory().setContents(this.a(this.items));
        } else if (this.type == RBlockContainerType.Sign) {
            Sign sign = (Sign)block.getState();
            for (int i2 = 0; i2 < 4; ++i2) {
                sign.setLine(i2, this.sign_lines[i2]);
            }
            sign.update();
        } else if (this.type == RBlockContainerType.Skull) {
            Skull skull = (Skull)block.getState();
            skull.setOwner(this.skull_owner);
            skull.setRotation(this.skull_rotation);
            skull.setSkullType(this.skull_type);
            skull.update();
        }
    }

    private List<RItemStack> a(ItemStack[] arritemStack) {
        ArrayList<RItemStack> arrayList = new ArrayList<RItemStack>();
        for (ItemStack itemStack : arritemStack) {
            arrayList.add(new RItemStack(itemStack));
        }
        return arrayList;
    }

    private ItemStack[] a(List<RItemStack> list) {
        ItemStack[] arritemStack = new ItemStack[list.size()];
        for (int i2 = 0; i2 < list.size(); ++i2) {
            arritemStack[i2] = list.get(i2).d();
        }
        return arritemStack;
    }

    public static enum RBlockContainerType {
        Chest("CHEST", "TRAPPED_CHEST"),
        Furnace("FURNACE", "BURNING_FURNACE"),
        Dropper("DROPPER"),
        Dispenser("DISPENSER"),
        Hopper("HOPPER"),
        Beacon("BEACON"),
        Shulker_Box("BLACK_SHULKER_BOX", "BLUE_SHULKER_BOX", "BROWN_SHULKER_BOX", "CYAN_SHULKER_BOX", "GRAY_SHULKER_BOX", "GREEN_SHULKER_BOX", "LIGHT_BLUE_SHULKER_BOX", "LIME_SHULKER_BOX", "MAGENTA_SHULKER_BOX", "ORANGE_SHULKER_BOX", "PINK_SHULKER_BOX", "PURPLE_SHULKER_BOX", "RED_SHULKER_BOX", "SILVER_SHULKER_BOX", "WHITE_SHULKER_BOX", "YELLOW_SHULKER_BOX"),
        Sign("SIGN_POST", "WALL_SIGN"),
        Skull("SKULL");
        
        private List<String> material;

        private RBlockContainerType(String ... arrstring) {
            this.material = Arrays.asList(arrstring);
        }

        public static RBlockContainerType a(Material material) {
            for (RBlockContainerType rBlockContainerType : RBlockContainerType.values()) {
                if (!rBlockContainerType.material.contains(material.name())) continue;
                return rBlockContainerType;
            }
            return null;
        }
    }

}

