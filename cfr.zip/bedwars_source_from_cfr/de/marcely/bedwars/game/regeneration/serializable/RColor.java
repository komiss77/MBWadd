/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 */
package de.marcely.bedwars.game.regeneration.serializable;

import java.io.Serializable;
import org.bukkit.Color;

@Deprecated
public class RColor
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private int rgb;

    public RColor(Color color) {
        this.rgb = color.asRGB();
    }

    public Color a() {
        return Color.fromRGB((int)this.rgb);
    }
}

