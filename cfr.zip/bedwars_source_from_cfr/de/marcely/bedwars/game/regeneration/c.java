/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.regeneration;

public interface c {
    public void a(a var1);

    public void a(long var1);

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a a = new a();
        public static final /* enum */ a b = new a();
        public static final /* enum */ a c = new a();
        public static final /* enum */ a d = new a();
        public static final /* enum */ a e = new a();
        public static final /* enum */ a f = new a();
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{a, b, c, d, e, f};
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

