/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.regeneration;

import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import java.io.Serializable;
import java.util.List;

@Deprecated
public class RegionData
implements Serializable {
    private static final long serialVersionUID = 4508008698825268258L;
    private List<RBlock> blocks;
    private List<REntity> entities;

    public RegionData(List<RBlock> list, List<REntity> list2) {
        this.blocks = list;
        this.entities = list2;
    }

    public List<RBlock> getBlocks() {
        return this.blocks;
    }

    public List<REntity> getEntities() {
        return this.entities;
    }

    public RBlock a(int n2, int n3, int n4) {
        for (RBlock rBlock : this.blocks) {
            if (rBlock.getX() != n2 || rBlock.getY() != n3 || rBlock.getZ() != n4) continue;
            return rBlock;
        }
        return null;
    }

    public REntity a(int n2) {
        for (REntity rEntity : this.entities) {
            if (rEntity.p() != n2) continue;
            return rEntity;
        }
        return null;
    }
}

