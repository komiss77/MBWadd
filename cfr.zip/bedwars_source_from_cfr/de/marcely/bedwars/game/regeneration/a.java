/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandSender
 *  org.bukkit.event.Event
 */
package de.marcely.bedwars.game.regeneration;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.event.ArenaRegenerationStopEvent;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.event.Event;

public abstract class a {
    protected final RegenerationType f;
    protected final Arena arena;
    private final CommandSender sender;
    private boolean running = false;
    private long startTime;
    private final List<Runnable> T = new ArrayList<Runnable>();

    public a(RegenerationType regenerationType, Arena arena, @Nullable CommandSender commandSender) {
        this.f = regenerationType;
        this.arena = arena;
        this.sender = commandSender;
    }

    protected abstract void a(File var1);

    protected abstract void s();

    protected abstract void a(File var1, c var2);

    protected void g(boolean bl2) {
        this.b(bl2, null);
    }

    public void b(boolean bl2, @Nullable String string) {
        if (bl2 && this.sender != null) {
            s.a(this.sender, de.marcely.bedwars.message.b.a(Language.Regeneration_Done).a("arena", this.arena != null ? this.arena.getName() : "Unkown").a("time", "" + (double)(System.currentTimeMillis() - this.startTime) / 1000.0));
        } else if (!bl2) {
            if (this.sender != null) {
                s.a(this.sender, de.marcely.bedwars.message.b.a(Language.Regeneration_Stopped).a("arena", this.arena != null ? this.arena.getName() : "Unkown").a("time", "" + (double)(System.currentTimeMillis() - this.startTime) / 1000.0));
            }
            if (string != null && !string.equals("Cancelled")) {
                d.a(string, this.arena);
            }
        }
        this.running = false;
        new de.marcely.bedwars.game.regeneration.a$1();
    }

    public void b(Runnable runnable) {
        this.T.add(runnable);
    }

    public boolean run() {
        if (this.running) {
            return false;
        }
        if (ConfigValue.regeneration_threadsafe) {
            de.marcely.bedwars.versions.a.setEnabled(false);
        }
        this.running = true;
        this.a(this.a());
        this.startTime = System.currentTimeMillis();
        return true;
    }

    public boolean cancel() {
        if (!this.running) {
            return false;
        }
        this.running = false;
        this.s();
        this.b(false, "Cancelled");
        return true;
    }

    public void b(c c2) {
        if (c2 == null) {
            c2 = new c(){

                @Override
                public void a(c.a a2) {
                }

                @Override
                public void a(long l2) {
                }
            };
        }
        this.a(this.a(), c2);
    }

    public File a() {
        return new File("plugins/MBedwars/data/arenablocks/" + this.arena.getName() + ".yml");
    }

    public RegenerationType b() {
        return this.f;
    }

    public Arena getArena() {
        return this.arena;
    }

    public CommandSender getSender() {
        return this.sender;
    }

    public boolean isRunning() {
        return this.running;
    }

    public List<Runnable> t() {
        return this.T;
    }

}

