/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.WorldCreator
 *  org.bukkit.WorldType
 *  org.bukkit.entity.Player
 *  org.bukkit.generator.BlockPopulator
 *  org.bukkit.generator.ChunkGenerator
 *  org.bukkit.generator.ChunkGenerator$BiomeGrid
 *  org.bukkit.generator.ChunkGenerator$ChunkData
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game.regeneration;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.util.f;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.entity.Player;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class d {
    public static c.a a(World world, File file) {
        Object object3;
        Object object2;
        if (s.a() == null || s.a().getSpawnLocation() == null) {
            de.marcely.bedwars.d.a("Tried to teleport players to the main world to save world files. This failed as there is no main world or no spawn location in that world. Fix that!");
            return c.a.f;
        }
        if (s.a(world)) {
            return c.a.b;
        }
        for (Object object3 : world.getPlayers()) {
            object3.teleport(s.a().getSpawnLocation());
        }
        if (world.getPlayers().size() >= 1) {
            return c.a.b;
        }
        Bukkit.unloadWorld((World)world, (boolean)true);
        if (file.exists()) {
            file.delete();
        }
        object3 = new File(String.valueOf(world.getName()) + "/region/");
        try {
            object2 = new ZipOutputStream(new FileOutputStream(file));
            for (File file2 : ((File)object3).listFiles()) {
                int n2;
                if (!file2.getName().endsWith(".mca")) continue;
                FileInputStream fileInputStream = new FileInputStream(file2);
                ((ZipOutputStream)object2).putNextEntry(new ZipEntry(file2.getName()));
                byte[] arrby = new byte[1024];
                while ((n2 = fileInputStream.read(arrby)) > 0) {
                    ((ZipOutputStream)object2).write(arrby, 0, n2);
                }
                fileInputStream.close();
            }
            ((ZipOutputStream)object2).close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        object2 = new WorldCreator(world.getName());
        object2.copy(world);
        Bukkit.createWorld((WorldCreator)object2);
        return c.a.a;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Nullable
    public static World a(final World world, File file) {
        try {
            boolean bl2 = s.a != Thread.currentThread();
            Object object = s.a().getName();
            if (((String)object).equals(world.getName()) || (String.valueOf(object) + "_nether").equals(world.getName()) || (String.valueOf(object) + "_the_end").equals(world.getName())) {
                de.marcely.bedwars.d.b("WARNING: IT'S NOT POSSIBLE TO REGENERATE MAIN WORLDS!!!");
                return null;
            }
            Object object2 = new File(String.valueOf(world.getName()) + "/region/");
            if (!bl2) {
                for (Player player : world.getPlayers()) {
                    player.teleport(s.a().getSpawnLocation());
                }
                if (world.getPlayers().size() >= 1) {
                    de.marcely.bedwars.d.b("WARNING: FAILED TO UNLOAD THE WORLD AS (PROBABLY) A PLUGIN HAS BLOCKED THIS OPERATION. Enabling 'regeneration-threadsafe' in the config.cm2 file may fix that");
                    return null;
                }
                Bukkit.unloadWorld((World)world, (boolean)false);
            }
            for (File file2 : ((File)object2).listFiles()) {
                if (file2 == null || file2.getName() == null) {
                    return null;
                }
                if (!file2.getName().endsWith(".mca")) continue;
                file2.delete();
            }
            object = new ZipFile(file);
            object2 = ((ZipFile)object).entries();
            while (object2.hasMoreElements()) {
                ZipEntry zipEntry = (ZipEntry)object2.nextElement();
                InputStream inputStream = ((ZipFile)object).getInputStream(zipEntry);
                File file3 = new File(String.valueOf(world.getName()) + "/region/" + zipEntry.getName());
                if (file3.exists()) {
                    file3.delete();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file3);
                f.copy(inputStream, fileOutputStream);
                inputStream.close();
                fileOutputStream.close();
            }
            ((ZipFile)object).close();
            if (bl2) {
                Version.a().c(world);
                Version.a().b(world);
                new BukkitRunnable(){

                    public void run() {
                        for (Player player : world.getPlayers()) {
                            if (Version.a().getVersionNumber() <= 13) {
                                Version.a().J(player);
                                continue;
                            }
                            player.teleport(s.a().getSpawnLocation());
                        }
                    }
                }.runTaskLater((Plugin)MBedwars.a, 20L);
                return world;
            }
            return Bukkit.createWorld((WorldCreator)new WorldCreator(world.getName()).copy(world));
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public static WorldCreator a(String string) {
        WorldCreator worldCreator = new WorldCreator(string);
        if (Version.a().getVersionNumber() >= 13) {
            worldCreator.type(WorldType.CUSTOMIZED);
            worldCreator.generator(new ChunkGenerator(){

                public List<BlockPopulator> getDefaultPopulators(World world) {
                    return Arrays.asList(new BlockPopulator[0]);
                }

                public boolean canSpawn(World world, int n2, int n3) {
                    return true;
                }

                public ChunkGenerator.ChunkData generateChunkData(World world, Random random, int n2, int n3, ChunkGenerator.BiomeGrid biomeGrid) {
                    return this.createChunkData(world);
                }
            });
        } else if (Version.a().getVersionNumber() >= 8) {
            worldCreator.type(WorldType.CUSTOMIZED);
            worldCreator.generator(new ChunkGenerator(){

                public List<BlockPopulator> getDefaultPopulators(World world) {
                    return Arrays.asList(new BlockPopulator[0]);
                }

                public boolean canSpawn(World world, int n2, int n3) {
                    return true;
                }

                public byte[] generate(World world, Random random, int n2, int n3) {
                    return new byte[32768];
                }
            });
        } else {
            worldCreator.type(WorldType.FLAT);
        }
        return worldCreator;
    }

}

