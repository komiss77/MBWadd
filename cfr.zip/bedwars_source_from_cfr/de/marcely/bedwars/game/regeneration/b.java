/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Chunk
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game.regeneration;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.al;
import de.marcely.bedwars.bM;
import de.marcely.bedwars.bN;
import de.marcely.bedwars.bO;
import de.marcely.bedwars.bq;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.regeneration.a;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.n;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntFunction;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class b
extends a {
    private boolean running;
    private byte o = 0;
    private int Z;
    private Iterator<Location> a;

    public b(Arena arena, @Nullable CommandSender commandSender) {
        super(RegenerationType.c, arena, commandSender);
    }

    @Override
    protected void a(File file, c c2) {
        bO bO2 = new bO(file, (int)(this.arena.getPosMax().getX() - this.arena.getPosMin().getX()), (int)(this.arena.getPosMax().getY() - this.arena.getPosMin().getY()), (int)(this.arena.getPosMax().getZ() - this.arena.getPosMin().getZ()));
        for (Entity entity : this.arena.getWorld().getEntities()) {
            if (entity.getType() == EntityType.PLAYER || entity.getType() == EntityType.DROPPED_ITEM || !this.arena.isInside(entity.getLocation())) continue;
            bO2.entities.add(bM.a(entity));
        }
        try {
            bO2.a(this.arena.getPosMin().toBukkit(this.arena.getWorld()), () -> c2.a(c.a.a), l2 -> c2.a((long)l2));
        }
        catch (Exception exception) {
            c2.a(c.a.f);
        }
    }

    @Override
    protected void a(File file) {
        new MThread(MThread.ThreadType.m, this.arena.getName()){

            @Override
            public void run() {
                bN.b b2 = null;
                try {
                    b2 = bO.a(new File("plugins/MBedwars/data/arenablocks/" + b.this.arena.getName() + ".yml"), b.this.arena.getPosMin().toBukkit(b.this.arena.getWorld()), ConfigValue.regeneration_threadsafe);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    b.this.b(false, "A big error occured while loading the file");
                    return;
                }
                final bN.b b3 = b2;
                if (b2.a != bN.c.j) {
                    if (b2.a == bN.c.b) {
                        al al2 = new al(b.this.arena, b.this.getSender()){

                            @Override
                            public void b(boolean bl2, @Nullable String string) {
                                if (!bl2) {
                                    b.this.b(false, "An error occured while loading the file (it's also not a v2 region regenerator file): " + (Object)((Object)b3.a));
                                } else {
                                    d.a("This arena is still using an old regenerator. Please write '/bw arena saveblocks " + this.arena.getName() + "' to save and use the newer v3 regenerator", this.arena);
                                    b.this.g(true);
                                }
                            }
                        };
                        al2.run();
                    } else if (b2.a == bN.c.e) {
                        b.this.b(false, "An error occured while loading the file (MCVersion: " + b2.H + "): " + (Object)((Object)b2.a));
                    } else {
                        b.this.b(false, "An error occured while loading the file: " + (Object)((Object)b2.a));
                    }
                    return;
                }
                b.a(b.this, true);
                if (Version.a().getVersionNumber() >= 9) {
                    new de.marcely.bedwars.game.regeneration.b$1$2(true);
                }
                if (ConfigValue.regeneration_threadsafe) {
                    new MThread(MThread.ThreadType.m, b.this.arena.getName()){

                        @Override
                        public void run() {
                            try {
                                while (b.this.running) {
                                    b.this.a(b3.c, b3.a);
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                b.a(b.this, false);
                                new de.marcely.bedwars.game.regeneration.b$1$3$1();
                            }
                        }

                    }.start();
                } else {
                    new BukkitRunnable(){

                        public void run() {
                            if (!b.this.running) {
                                this.cancel();
                                return;
                            }
                            try {
                                b.this.a(b3.c, b3.a);
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                                b.a(b.this, false);
                                b.this.g(false);
                            }
                        }
                    }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
                }
            }

        }.start();
    }

    private void a(bN bN2, bN.a a2) {
        block17 : {
            if (this.o == 0) {
                Runnable runnable = new Runnable(){

                    @Override
                    public void run() {
                        for (Entity entity : b.this.arena.getWorld().getEntities()) {
                            if (entity.getType() == EntityType.PLAYER || !b.this.arena.isInside(entity.getLocation())) continue;
                            Version.a().b(entity);
                        }
                        b b2 = b.this;
                        b.a(b2, (byte)(b2.o + 1));
                        b.a(b.this, s.a(b.this.arena.getPosMin().toBukkit(b.this.arena.getWorld()), (int)(b.this.arena.getPosMax().getX() - b.this.arena.getPosMin().getX()), (int)(b.this.arena.getPosMax().getY() - b.this.arena.getPosMin().getY()), (int)(b.this.arena.getPosMax().getZ() - b.this.arena.getPosMin().getZ())));
                        Version.a().a(b.this.arena.getWorld(), true);
                    }
                };
                if (Version.a().getVersionNumber() < 13) {
                    runnable.run();
                } else {
                    new de.marcely.bedwars.game.regeneration.b$3(true, runnable);
                }
            } else if (this.o == 1) {
                long l2 = System.currentTimeMillis();
                while (this.a.hasNext()) {
                    Location location = this.a.next();
                    Version.a().a(location, Material.AIR, (byte)0);
                    if (System.currentTimeMillis() - l2 < (long)ConfigValue.regeneration_speed_ms) continue;
                    break block17;
                }
                this.o = (byte)(this.o + 1);
            } else if (this.o == 2) {
                long l3 = System.currentTimeMillis();
                try {
                    do {
                        if (a2.next()) continue;
                        this.o = (byte)(this.o + 1);
                        Version.a().a(this.arena.getWorld(), false);
                    } while (System.currentTimeMillis() - l3 < (long)ConfigValue.regeneration_speed_ms);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    this.b(false, "A big error occured while loading the file");
                    this.running = false;
                    return;
                }
            } else if (this.o == 3) {
                int n2 = 10;
                new de.marcely.bedwars.game.regeneration.b$4(true, bN2);
            } else if (this.o == 4) {
                new de.marcely.bedwars.game.regeneration.b$5(true);
            } else if (this.o == 5) {
                this.running = false;
                new de.marcely.bedwars.game.regeneration.b$6();
            }
        }
    }

    @Override
    protected void s() {
        this.running = false;
    }

    public static boolean d(String string) {
        File file = new File("plugins/MBedwars/data/arenablocks/" + string + ".yml");
        if (file.exists()) {
            file.delete();
            return true;
        }
        return false;
    }

    static /* synthetic */ void a(b b2, boolean bl2) {
        b2.running = bl2;
    }

    static /* synthetic */ void a(b b2, byte by2) {
        b2.o = by2;
    }

    static /* synthetic */ void a(b b2, Iterator iterator) {
        b2.a = iterator;
    }

    static /* synthetic */ void a(b b2, int n2) {
        b2.Z = n2;
    }

}

