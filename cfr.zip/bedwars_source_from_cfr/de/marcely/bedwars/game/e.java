/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.enchantments.Enchantment
 */
package de.marcely.bedwars.game;

import org.bukkit.enchantments.Enchantment;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class e
extends Enum<e> {
    public static final /* enum */ e a = new e("PROTECTION_ENVIRONMENTAL");
    public static final /* enum */ e b = new e("PROTECTION_FIRE");
    public static final /* enum */ e c = new e("PROTECTION_FALL");
    public static final /* enum */ e d = new e("PROTECTION_EXPLOSIONS");
    public static final /* enum */ e e = new e("PROTECTION_PROJECTILE");
    public static final /* enum */ e f = new e("OXYGEN");
    public static final /* enum */ e g = new e("WATER_WORKER");
    public static final /* enum */ e h = new e("THORNS");
    public static final /* enum */ e i = new e("DEPTH_STRIDER");
    public static final /* enum */ e j = new e("FROST_WALKER");
    public static final /* enum */ e k = new e("BINDING_CURSE");
    public static final /* enum */ e l = new e("DAMAGE_ALL");
    public static final /* enum */ e m = new e("DAMAGE_UNDEAD");
    public static final /* enum */ e n = new e("DAMAGE_ARTHROPODS");
    public static final /* enum */ e o = new e("KNOCKBACK");
    public static final /* enum */ e p = new e("FIRE_ASPECT");
    public static final /* enum */ e q = new e("LOOT_BONUS_MOBS");
    public static final /* enum */ e r = new e("DIG_SPEED");
    public static final /* enum */ e s = new e("SILK_TOUCH");
    public static final /* enum */ e t = new e("DURABILITY");
    public static final /* enum */ e u = new e("LOOT_BONUS_BLOCKS");
    public static final /* enum */ e v = new e("ARROW_DAMAGE");
    public static final /* enum */ e w = new e("ARROW_KNOCKBACK");
    public static final /* enum */ e x = new e("ARROW_FIRE");
    public static final /* enum */ e y = new e("ARROW_INFINITE");
    public static final /* enum */ e z = new e("LUCK");
    public static final /* enum */ e A = new e("LURE");
    public static final /* enum */ e B = new e("MENDING");
    public static final /* enum */ e C = new e("VANISHING_CURSE");
    private String B;
    private static final /* synthetic */ e[] a;

    static {
        a = new e[]{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A, B, C};
    }

    private e(String string2) {
        this.B = string2;
    }

    public static e a(Enchantment enchantment) {
        for (e e2 : e.values()) {
            if (!e2.B.equals(enchantment.getName())) continue;
            return e2;
        }
        return null;
    }

    public Enchantment a() {
        return Enchantment.getByName((String)this.B);
    }

    public static e a(String string) {
        for (e e2 : e.values()) {
            if (!e2.name().equalsIgnoreCase(string) && !e2.name().replace("_", "").equalsIgnoreCase(string) && !e2.name().replace("_", " ").equalsIgnoreCase(string) && !e2.B.equalsIgnoreCase(string) && !e2.B.replace("_", "").equalsIgnoreCase(string) && !e2.B.replace("_", " ").equalsIgnoreCase(string)) continue;
            return e2;
        }
        return null;
    }

    public static e[] values() {
        e[] arre = a;
        int n2 = arre.length;
        e[] arre2 = new e[n2];
        System.arraycopy(arre, 0, arre2, 0, n2);
        return arre2;
    }

    public static e valueOf(String string) {
        return Enum.valueOf(e.class, string);
    }
}

