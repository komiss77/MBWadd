/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class a {
    private List<Player> players;
    private boolean x;
    private String x = "";
    private String y;
    private BukkitTask a;
    private BukkitTask b;

    public a() {
        this(new ArrayList<Player>());
    }

    public a(List<Player> list) {
        this.players = list;
    }

    public boolean d(Player player) {
        return this.players.add(player);
    }

    public boolean e(Player player) {
        return this.players.remove((Object)player);
    }

    public void setMessage(String string) {
        this.v();
        this.x = string;
        this.w();
    }

    public void b(String string, int n2) {
        this.v();
        this.y = this.x;
        this.x = string;
        this.w();
        this.b = new BukkitRunnable(){

            public void run() {
                a.this.v();
            }
        }.runTaskLater((Plugin)MBedwars.a, (long)n2);
    }

    public void v() {
        if (this.b != null) {
            this.x = this.y;
            this.b.cancel();
            this.b = null;
        }
    }

    public void run() {
        if (this.a == null) {
            this.a = new BukkitRunnable(){

                public void run() {
                    a.this.w();
                }
            }.runTaskTimer((Plugin)MBedwars.a, 0L, (long)(this.x ? 58 : 30));
        }
    }

    public void stop() {
        if (this.a != null) {
            this.a.cancel();
            this.a = null;
            if (this.b != null) {
                this.v();
            }
        }
    }

    public void refresh() {
        this.stop();
        this.run();
    }

    public boolean isRunning() {
        return this.a != null;
    }

    private void w() {
        if (!this.isRunning()) {
            return;
        }
        for (Player player : this.players) {
            Version.a().b(player, this.x);
        }
    }

    public List<Player> getPlayers() {
        return this.players;
    }

    public void a(List<Player> list) {
        this.players = list;
    }

    public boolean z() {
        return this.x;
    }

    public void setAnimated(boolean bl2) {
        this.x = bl2;
    }

    public String h() {
        return this.x;
    }

    public String i() {
        return this.y;
    }

}

