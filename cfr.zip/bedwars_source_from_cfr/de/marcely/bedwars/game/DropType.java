/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.ChatColor
 *  org.bukkit.Effect
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.command.CommandSender
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.api.Spawner;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class DropType
implements de.marcely.bedwars.api.DropType,
Cloneable {
    private static List<DropType> G = new ArrayList<DropType>();
    private String id = null;
    private ItemStack d = new ItemStack(Material.STONE);
    private String A;
    private double b;
    private VarParticle a;
    private Sound b = null;
    private ChatColor a;
    private String name = "";
    private int M = 0;
    private boolean y = false;
    private boolean z = false;
    private Material a = null;
    private boolean A = false;
    public ItemStack icon = null;

    public DropType() {
    }

    public DropType(String string, ItemStack itemStack, String string2, double d2, VarParticle varParticle, Sound sound, ChatColor chatColor) {
        this.id = string;
        this.d = itemStack;
        this.name = string2;
        this.b = d2;
        this.a = varParticle;
        this.b = sound;
        this.a = chatColor;
    }

    public DropType(String string, Spawner spawner, String string2, double d2, VarParticle varParticle, Sound sound, ChatColor chatColor) {
        this.id = string;
        this.A = spawner.getName();
        this.name = string2;
        this.b = d2;
        this.a = varParticle;
        this.b = sound;
        this.a = chatColor;
    }

    @Nullable
    public String k() {
        return this.id;
    }

    public String getId() {
        if (this.id != null) {
            return this.id;
        }
        return this.name;
    }

    @Override
    public String getName() {
        return this.a((CommandSender)null);
    }

    public String getName(boolean bl2) {
        return this.a(null, bl2);
    }

    public String a(@Nullable CommandSender commandSender) {
        return this.a(commandSender, true);
    }

    public String a(@Nullable CommandSender commandSender, boolean bl2) {
        if (this.name == null) {
            return "";
        }
        String string = b.a(this.name).c().f(commandSender);
        if (string == null) {
            string = "Error";
        }
        if (bl2 && string.length() >= 1) {
            return String.valueOf(string.substring(0, 1).toUpperCase()) + string.substring(1, string.length());
        }
        return string;
    }

    public String getRealName() {
        return this.name;
    }

    @Nullable
    @Override
    public Spawner getCustomSpawner() {
        return this.A != null ? s.a(this.A) : null;
    }

    @Override
    public ItemStack getActualItemstack() {
        Spawner spawner = this.getCustomSpawner();
        if (spawner != null) {
            return spawner.getShopIcon();
        }
        return this.c();
    }

    public static DropType a(ItemStack itemStack) {
        for (DropType dropType : DropType.values()) {
            if (dropType.c().getType() != itemStack.getType() || dropType.c().getDurability() != itemStack.getDurability()) continue;
            return dropType;
        }
        return null;
    }

    public static DropType a(String string) {
        for (DropType dropType : DropType.values()) {
            if (dropType.getName().equalsIgnoreCase(string) || dropType.getRealName().equalsIgnoreCase(string) || dropType.id != null && dropType.id.equalsIgnoreCase(string)) {
                return dropType;
            }
            Language language = Language.getLanguage(dropType.getRealName().replace("%", ""));
            if (language == null || !language.getDefaultEnglish().equalsIgnoreCase(string)) continue;
            return dropType;
        }
        return null;
    }

    public static List<DropType> values() {
        return G;
    }

    public static List<String> k() {
        return DropType.b(null);
    }

    public static List<String> a(boolean bl2) {
        return DropType.a(null, bl2);
    }

    public static List<String> b(@Nullable CommandSender commandSender) {
        return DropType.a(commandSender, true);
    }

    public static List<String> a(@Nullable CommandSender commandSender, boolean bl2) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (DropType dropType : G) {
            arrayList.add(dropType.a(commandSender, bl2));
        }
        return arrayList;
    }

    public static boolean a(DropType dropType) {
        return G.add(dropType);
    }

    public static void clear() {
        G.clear();
    }

    public static boolean a(String string, boolean bl2) {
        if (bl2) {
            for (DropType dropType : DropType.values()) {
                if (!dropType.getName().equalsIgnoreCase(string)) continue;
                return true;
            }
        } else {
            for (DropType dropType : DropType.values()) {
                if (!dropType.getName().equals(string)) continue;
                return true;
            }
        }
        return false;
    }

    public DropType b() {
        try {
            DropType dropType = (DropType)super.clone();
            dropType.d = this.d.clone();
            return dropType;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    @Override
    public void setName(String string) {
        this.name = string;
    }

    @Override
    public void setConfigItemstack(ItemStack itemStack) {
        this.d = itemStack;
    }

    @Override
    public void setCustomSpawner(Spawner spawner) {
        this.A = spawner != null ? spawner.getName() : null;
    }

    @Override
    public void setSpawnRadius(int n2) {
        this.M = n2;
    }

    @Override
    public void setSound(Sound sound) {
        this.b = sound;
    }

    @Override
    public ItemStack getConfigItemstack() {
        return this.d;
    }

    @Override
    public int getSpawnRadius() {
        return this.M;
    }

    @Override
    public Sound getSound() {
        return this.b;
    }

    @Override
    public boolean isDisabledForRound() {
        return this.A;
    }

    @Override
    public void setDisabledForRound(boolean bl2) {
        this.A = bl2;
    }

    @Deprecated
    @Override
    public void setEffect(Effect effect) {
        if (effect == null) {
            this.a = null;
            return;
        }
        this.a = new VarParticle(effect);
    }

    @Deprecated
    @Override
    public Effect getEffect() {
        if (this.a == null || this.a.getKeepType() != VarParticle.ParticleKeepType.EFFECT) {
            return null;
        }
        return this.a.getEffect();
    }

    public void setId(String string) {
        this.id = string;
    }

    public void a(ItemStack itemStack) {
        this.d = itemStack;
    }

    public ItemStack c() {
        return this.d;
    }

    public void u(String string) {
        this.A = string;
    }

    public String l() {
        return this.A;
    }

    @Override
    public void setSpawnDelay(double d2) {
        this.b = d2;
    }

    @Override
    public double getSpawnDelay() {
        return this.b;
    }

    @Override
    public void setVarParticle(VarParticle varParticle) {
        this.a = varParticle;
    }

    @Override
    public VarParticle getVarParticle() {
        return this.a;
    }

    @Override
    public void setChatColor(ChatColor chatColor) {
        this.a = chatColor;
    }

    @Override
    public ChatColor getChatColor() {
        return this.a;
    }

    @Override
    public void setTranquil(boolean bl2) {
        this.y = bl2;
    }

    @Override
    public void setMerging(boolean bl2) {
        this.z = bl2;
    }

    @Override
    public boolean isTranquil() {
        return this.y;
    }

    @Override
    public boolean isMerging() {
        return this.z;
    }

    @Override
    public void setHologram(Material material) {
        this.a = material;
    }

    @Override
    public Material getHologram() {
        return this.a;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return this.b();
    }
}

