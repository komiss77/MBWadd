/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Color
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game;

import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.game.location.XYZ;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class b {
    private static final int SIZE = 10;
    private static final int K = 35;

    public static void a(Player player, XYZ xYZ, XYZ xYZ2) {
        int n2;
        int n3;
        double d2 = xYZ.getX();
        double d3 = xYZ.getY();
        double d4 = xYZ.getZ();
        double d5 = xYZ2.getX();
        double d6 = xYZ2.getY();
        double d7 = xYZ2.getZ();
        double d8 = player.getLocation().getX();
        double d9 = player.getLocation().getY();
        double d10 = player.getLocation().getZ();
        if (d8 - d2 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d9 + (double)n3 >= xYZ.getY()) || !(d9 + (double)n3 <= xYZ2.getY()) || !(d10 + (double)n2 >= xYZ.getZ()) || !(d10 + (double)n2 <= xYZ2.getZ())) continue;
                    b.a(player, d2, d9 + (double)n3, d10 + (double)n2);
                }
            }
        }
        if (d9 - d3 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d8 + (double)n2 >= xYZ.getX()) || !(d8 + (double)n2 <= xYZ2.getX()) || !(d10 + (double)n3 >= xYZ.getZ()) || !(d10 + (double)n3 <= xYZ2.getZ())) continue;
                    b.a(player, d8 + (double)n2, d3, d10 + (double)n3);
                }
            }
        }
        if (d10 - d4 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d8 + (double)n2 >= xYZ.getX()) || !(d8 + (double)n2 <= xYZ2.getX()) || !(d9 + (double)n3 >= xYZ.getY()) || !(d9 + (double)n3 <= xYZ2.getY())) continue;
                    b.a(player, d8 + (double)n2, d9 + (double)n3, d4);
                }
            }
        }
        if (d5 - d8 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d9 + (double)n3 >= xYZ.getY()) || !(d9 + (double)n3 <= xYZ2.getY()) || !(d10 + (double)n2 >= xYZ.getZ()) || !(d10 + (double)n2 <= xYZ2.getZ())) continue;
                    b.a(player, d5, d9 + (double)n3, d10 + (double)n2);
                }
            }
        }
        if (d6 - d9 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d8 + (double)n2 >= xYZ.getX()) || !(d8 + (double)n2 <= xYZ2.getX()) || !(d10 + (double)n3 >= xYZ.getZ()) || !(d10 + (double)n3 <= xYZ2.getZ())) continue;
                    b.a(player, d8 + (double)n2, d6, d10 + (double)n3);
                }
            }
        }
        if (d7 - d10 <= 35.0) {
            for (n2 = -10; n2 < 10; ++n2) {
                for (n3 = -10; n3 < 10; ++n3) {
                    if (!(d8 + (double)n2 >= xYZ.getX()) || !(d8 + (double)n2 <= xYZ2.getX()) || !(d9 + (double)n3 >= xYZ.getY()) || !(d9 + (double)n3 <= xYZ2.getY())) continue;
                    b.a(player, d8 + (double)n2, d9 + (double)n3, d7);
                }
            }
        }
    }

    private static void a(Player player, double d2, double d3, double d4) {
        Location location = new Location(player.getWorld(), d2, d3, d4);
        float f2 = (float)location.distance(player.getLocation());
        float f3 = 0.0f;
        float f4 = 0.0f;
        float f5 = 0.0f;
        if (f2 < 0.0f || f2 >= 35.0f) {
            return;
        }
        if (f2 < 6.0f) {
            f4 = f5 = f2 / 6.0f;
            f3 = f5;
        } else {
            f3 = f5 = (f4 = (35.0f - f2) / 35.0f);
        }
        Color color = Color.fromRGB((int)((int)(f3 * 255.0f)), (int)((int)(f4 * 255.0f)), (int)((int)(f5 * 255.0f)));
        VarParticle.PARTICLE_COLOURED.play(player, location, color);
    }
}

