/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 */
package de.marcely.bedwars.game.location;

import de.marcely.bedwars.game.location.XYZ;
import java.io.Serializable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

public class XYZW
extends XYZ
implements Serializable {
    private static final long serialVersionUID = 1L;
    private String world;

    public XYZW(World world, double d2, double d3, double d4) {
        this(world.getName(), d2, d3, d4);
    }

    public XYZW(String string, double d2, double d3, double d4) {
        super(d2, d3, d4);
        this.world = string;
    }

    public XYZW(Location location) {
        this(location.getWorld(), location.getX(), location.getY(), location.getZ());
    }

    public World getWorld() {
        return this.world != null ? Bukkit.getWorld((String)this.world) : null;
    }

    public String getWorldString() {
        return this.world;
    }

    public void setWorld(World world) {
        this.world = world.getName();
    }

    public void setWorldString(String string) {
        this.world = string;
    }

    public boolean equals(XYZW xYZW) {
        return xYZW.getWorldString() == this.world && xYZW.getX() == this.getX() && xYZW.getY() == this.getY() && xYZW.getZ() == this.getZ();
    }

    public Location toBukkit() {
        return new Location(this.getWorld(), this.getX(), this.getY(), this.getZ());
    }

    public Block toBlock() {
        return this.getWorld().getBlockAt((int)this.x, (int)this.y, (int)this.z);
    }

    public static XYZW valueOf(Location location) {
        if (location == null) {
            return new XYZW((World)Bukkit.getWorlds().get(0), 0.0, 0.0, 0.0);
        }
        return new XYZW(location.getWorld(), location.getX(), location.getY(), location.getZ());
    }
}

