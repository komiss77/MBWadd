/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 */
package de.marcely.bedwars.game.location;

import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import java.io.Serializable;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;

public class XYZD
extends XYZ
implements Serializable {
    private static final long serialVersionUID = 1054369555018442319L;
    private int d = 0;
    private static /* synthetic */ int[] $SWITCH_TABLE$org$bukkit$block$BlockFace;

    public XYZD() {
    }

    public XYZD(double d2, double d3, double d4, int n2) {
        super(d2, d3, d4);
        this.d = n2;
    }

    public int getD() {
        return this.d;
    }

    public void setD(int n2) {
        this.d = n2;
    }

    @Nullable
    public BlockFace getDAsBlockFace() {
        switch (this.d) {
            case 0: {
                return BlockFace.SOUTH;
            }
            case 1: {
                return BlockFace.WEST;
            }
            case 2: {
                return BlockFace.NORTH;
            }
            case 3: {
                return BlockFace.EAST;
            }
        }
        return null;
    }

    public boolean equals(XYZD xYZD) {
        return xYZD.getX() == this.getX() && xYZD.getY() == this.getY() && xYZD.getZ() == this.getZ() && xYZD.getD() == this.d;
    }

    public static XYZD valueOf(Location location) {
        return new XYZD(location.getX(), location.getY(), location.getZ(), 0);
    }

    public static XYZD valueOf(Block block) {
        return XYZD.valueOf(block, block.getType() == Material.BED_BLOCK);
    }

    public static XYZD valueOf(Block block, boolean bl2) {
        Location location = block.getLocation();
        int n2 = 0;
        if (bl2 && Version.a().getVersionNumber() >= 13) {
            BlockFace blockFace = ((w)Version.a().a()).a(block);
            switch (XYZD.$SWITCH_TABLE$org$bukkit$block$BlockFace()[blockFace.ordinal()]) {
                case 3: {
                    n2 = 0;
                    break;
                }
                case 4: {
                    n2 = 1;
                    break;
                }
                case 1: {
                    n2 = 2;
                    break;
                }
                case 2: {
                    n2 = 3;
                    break;
                }
                default: {
                    break;
                }
            }
        } else {
            n2 = block.getData();
        }
        return new XYZD(location.getX(), location.getY(), location.getZ(), n2);
    }

    @Nullable
    public static XYZD ofString(String string) {
        String[] arrstring = string.split(",");
        if (arrstring.length == 4) {
            for (int i2 = 0; i2 < 3; ++i2) {
                if (s.isDouble(arrstring[i2])) continue;
                return null;
            }
            if (!s.isInteger(arrstring[3])) {
                return null;
            }
            return new XYZD(Double.valueOf(arrstring[0]), Double.valueOf(arrstring[1]), Double.valueOf(arrstring[2]), Integer.valueOf(arrstring[3]));
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z + "," + this.d;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$org$bukkit$block$BlockFace() {
        if ($SWITCH_TABLE$org$bukkit$block$BlockFace != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[BlockFace.values().length];
        try {
            arrn[BlockFace.DOWN.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.EAST.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.EAST_NORTH_EAST.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.EAST_SOUTH_EAST.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.NORTH.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.NORTH_EAST.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.NORTH_NORTH_EAST.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.NORTH_NORTH_WEST.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.NORTH_WEST.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SELF.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SOUTH.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SOUTH_EAST.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SOUTH_SOUTH_EAST.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SOUTH_SOUTH_WEST.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.SOUTH_WEST.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.UP.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.WEST.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.WEST_NORTH_WEST.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[BlockFace.WEST_SOUTH_WEST.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$org$bukkit$block$BlockFace = arrn;
        return $SWITCH_TABLE$org$bukkit$block$BlockFace;
    }
}

