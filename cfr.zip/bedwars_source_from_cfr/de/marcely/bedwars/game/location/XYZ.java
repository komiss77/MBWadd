/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars.game.location;

import de.marcely.bedwars.util.s;
import java.io.Serializable;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;

public class XYZ
implements Serializable,
Cloneable {
    private static final long serialVersionUID = 1054369555018442319L;
    protected double x = 0.0;
    protected double y = 0.0;
    protected double z = 0.0;

    public XYZ() {
    }

    public XYZ(double d2, double d3, double d4) {
        this.x = d2;
        this.y = d3;
        this.z = d4;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    public void setX(double d2) {
        this.x = d2;
    }

    public void setY(double d2) {
        this.y = d2;
    }

    public void setZ(double d2) {
        this.z = d2;
    }

    public void setXYZ(double d2, double d3, double d4) {
        this.x = d2;
        this.y = d3;
        this.z = d4;
    }

    public boolean somethingNull() {
        return this.x == 0.0 && this.y == 0.0 && this.z == 0.0;
    }

    public boolean equals(XYZ xYZ) {
        return xYZ.getX() == this.x && xYZ.getY() == this.y && xYZ.getZ() == this.z;
    }

    public Location toBukkit(World world) {
        return new Location(world, this.x, this.y, this.z);
    }

    public Vector toVector() {
        return new Vector(this.x, this.y, this.z);
    }

    public XYZ add(double d2, double d3, double d4) {
        XYZ xYZ = this.clone();
        xYZ.x += d2;
        xYZ.y += d3;
        xYZ.z += d4;
        return xYZ;
    }

    public double distance(XYZ xYZ) {
        return s.distance(this.x, xYZ.x) + s.distance(this.y, xYZ.y) + s.distance(this.z, xYZ.z);
    }

    public Block toBlock(World world) {
        return world.getBlockAt((int)this.x, (int)this.y, (int)this.z);
    }

    public void floor() {
        this.x = (int)this.x;
        this.y = (int)this.y;
        this.z = (int)this.z;
    }

    public static XYZ valueOf(Location location) {
        return new XYZ(location.getX(), location.getY(), location.getZ());
    }

    public static XYZ valueOf(Vector vector) {
        return new XYZ(vector.getX(), vector.getY(), vector.getZ());
    }

    @Nullable
    public static XYZ ofString(String string) {
        String[] arrstring = string.split(",");
        if (arrstring.length == 3) {
            for (String string2 : arrstring) {
                if (s.isDouble(string2)) continue;
                return null;
            }
            return new XYZ(Double.valueOf(arrstring[0]), Double.valueOf(arrstring[1]), Double.valueOf(arrstring[2]));
        }
        return null;
    }

    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z;
    }

    public XYZ clone() {
        try {
            return (XYZ)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }
}

