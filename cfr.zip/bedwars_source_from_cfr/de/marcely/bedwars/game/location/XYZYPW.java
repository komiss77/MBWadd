/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package de.marcely.bedwars.game.location;

import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZW;
import java.io.Serializable;
import org.bukkit.Location;
import org.bukkit.World;

public class XYZYPW
extends XYZW
implements Serializable,
Cloneable {
    private static final long serialVersionUID = 1L;
    private float yaw = 0.0f;
    private float pitch = 0.0f;

    public XYZYPW(World world, double d2, double d3, double d4, float f2, float f3) {
        this(world.getName(), d2, d3, d4, f2, f3);
    }

    public XYZYPW(String string, double d2, double d3, double d4, float f2, float f3) {
        super(string, d2, d3, d4);
        this.yaw = f2;
        this.pitch = f3;
    }

    public XYZYPW(Location location) {
        this(location.getWorld(), location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setYaw(float f2) {
        this.yaw = f2;
    }

    public void setPitch(float f2) {
        this.pitch = f2;
    }

    public boolean equals(XYZYPW xYZYPW) {
        return xYZYPW.getWorldString().equals(xYZYPW.getWorldString()) && xYZYPW.getX() == this.getX() && xYZYPW.getY() == this.getY() && xYZYPW.getZ() == this.getZ() && xYZYPW.getYaw() == this.getYaw() && xYZYPW.getPitch() == this.getPitch();
    }

    @Override
    public Location toBukkit() {
        return new Location(this.getWorld(), this.getX(), this.getY(), this.getZ(), this.getYaw(), this.getPitch());
    }

    public XYZ toXYZ() {
        return new XYZ(this.getX(), this.getY(), this.getZ());
    }

    public static XYZYPW valueOf(Location location) {
        return new XYZYPW(location);
    }

    @Override
    public XYZYPW clone() {
        return (XYZYPW)super.clone();
    }
}

