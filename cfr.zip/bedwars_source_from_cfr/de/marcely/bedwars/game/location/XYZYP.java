/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package de.marcely.bedwars.game.location;

import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.util.s;
import java.io.Serializable;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;

public class XYZYP
extends XYZ
implements Serializable {
    private static final long serialVersionUID = 1054369555018442319L;
    private float yaw = 0.0f;
    private float pitch = 0.0f;

    public XYZYP() {
    }

    public XYZYP(double d2, double d3, double d4, float f2, float f3) {
        super(d2, d3, d4);
        this.yaw = f2;
        this.pitch = f3;
    }

    public float getYaw() {
        return this.yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setYaw(float f2) {
        this.yaw = f2;
    }

    public void setPitch(float f2) {
        this.pitch = f2;
    }

    public boolean equals(XYZYP xYZYP) {
        return xYZYP.getX() == this.getX() && xYZYP.getY() == this.getY() && xYZYP.getZ() == this.getZ() && xYZYP.getYaw() == this.yaw && xYZYP.getPitch() == this.pitch;
    }

    @Override
    public Location toBukkit(World world) {
        return new Location(world, this.getX(), this.getY(), this.getZ(), this.getYaw(), this.getPitch());
    }

    public static XYZYP valueOf(Location location) {
        return new XYZYP(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
    }

    @Nullable
    public static XYZYP ofString(String string) {
        String[] arrstring = string.split(",");
        if (arrstring.length == 5) {
            for (String string2 : arrstring) {
                if (s.isDouble(string2)) continue;
                return null;
            }
            return new XYZYP(Double.valueOf(arrstring[0]), Double.valueOf(arrstring[1]), Double.valueOf(arrstring[2]), (float)Double.valueOf(arrstring[3]).doubleValue(), (float)Double.valueOf(arrstring[4]).doubleValue());
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z + "," + this.yaw + "," + this.pitch;
    }
}

