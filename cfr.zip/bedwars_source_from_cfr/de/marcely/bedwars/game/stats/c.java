/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.StatsAPI;
import de.marcely.bedwars.bo;
import de.marcely.bedwars.ef;
import de.marcely.bedwars.util.FutureResult;
import de.marcely.bedwars.util.SoftHashMap;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.t;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class c
implements StatsAPI {
    private String name;
    private UUID uuid;
    private final boolean R;
    private c b;
    private int ag = -1;
    private int ah = 0;
    private int ai = 0;
    private int aj = 0;
    private int ak = 0;
    private int al = 0;
    private int am = 0;
    private long k = 0L;
    private int an = 0;
    private int ao = 0;
    private static Map<UUID, c> F = new SoftHashMap<UUID, c>();
    public static final String L = "MBedwars_stats";

    public c(String string, UUID uUID, boolean bl2) {
        t.c(uUID);
        this.name = string;
        this.uuid = uUID;
        this.R = bl2;
        if (!bl2) {
            this.O();
        }
    }

    @Override
    public void setRank(int n2) {
        this.ag = n2;
        if (n2 <= 3 && n2 >= 1) {
            s.a(this.uuid, Achievement.v);
        }
    }

    @Override
    public void setWins(int n2) {
        this.ah = n2;
    }

    @Override
    public void setLoses(int n2) {
        this.ai = n2;
    }

    @Override
    public void setKills(int n2) {
        if (this.b != null) {
            this.b.setKills(n2 - this.aj + this.b.aj);
        }
        this.aj = n2;
        if (this.b() >= 5.0) {
            new de.marcely.bedwars.game.stats.c$1();
        }
    }

    @Override
    public void setDeaths(int n2) {
        if (this.b != null) {
            this.b.setDeaths(n2 - this.ak + this.b.ak);
        }
        this.ak = n2;
    }

    @Override
    public void setBedsDestroyed(int n2) {
        if (this.b != null) {
            this.b.setBedsDestroyed(n2 - this.al + this.b.al);
        }
        this.al = n2;
    }

    @Override
    public void setRoundsPlayed(int n2) {
        this.am = n2;
    }

    @Override
    public void setPlayTime(long l2) {
        this.k = l2;
        if (s.a(l2) >= 5L) {
            s.a(this.uuid, Achievement.x);
        }
    }

    @Override
    public String getPlayerName() {
        return this.name;
    }

    @Override
    public void setCoins(int n2) {
        this.an = n2;
    }

    @Override
    public void setFinalKills(int n2) {
        if (this.b != null) {
            this.b.setFinalKills(n2 - this.ao + this.b.ao);
        }
        this.ao = n2;
    }

    @Override
    public UUID getUUID() {
        return this.uuid;
    }

    @Override
    public int getRank() {
        return this.ag;
    }

    @Override
    public int getWins() {
        return this.ah;
    }

    @Override
    public int getLoses() {
        return this.ai;
    }

    @Override
    public int getKills() {
        return this.aj;
    }

    @Override
    public int getDeaths() {
        return this.ak;
    }

    @Override
    public int getBedsDestroyed() {
        return this.al;
    }

    @Override
    public int getRoundsPlayed() {
        return this.am;
    }

    @Override
    public long getPlayTime() {
        return this.k;
    }

    @Override
    public int getCoins() {
        return this.an;
    }

    public int q() {
        return this.ao;
    }

    public void x(String string) {
        this.name = string;
    }

    public void b(UUID uUID) {
        this.uuid = uUID;
    }

    public void O() {
        if (this.R) {
            new bo().printStackTrace();
        }
        this.b = new c(this.name, this.uuid, true);
    }

    public Double a() {
        if (this.getLoses() == 0 && this.getWins() > 0) {
            return this.getWins();
        }
        DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
        decimalFormatSymbols.setInfinity("Infinity");
        decimalFormatSymbols.setNaN("?");
        DecimalFormat decimalFormat = new DecimalFormat("#.##", decimalFormatSymbols);
        String string = decimalFormat.format((double)this.getWins() / (double)this.getLoses());
        if (string.equals("Infinity") || string.equals("?")) {
            string = "0.0";
        }
        return Double.valueOf(string);
    }

    public Double b() {
        if (this.getDeaths() == 0 && this.getKills() > 0) {
            return this.getKills();
        }
        DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
        decimalFormatSymbols.setInfinity("Infinity");
        decimalFormatSymbols.setNaN("?");
        DecimalFormat decimalFormat = new DecimalFormat("#.##", decimalFormatSymbols);
        String string = decimalFormat.format((double)this.getKills() / (double)this.getDeaths());
        if (string.equals("Infinity") || string.equals("?")) {
            string = "0.0";
        }
        return Double.valueOf(string);
    }

    @Override
    public void save() {
        s.b.b(this);
    }

    @Deprecated
    public static Future<c> a(UUID uUID) {
        return c.a(null, uUID);
    }

    public static Future<c> a(Player player) {
        return c.a(s.f(player), player.getUniqueId());
    }

    public static synchronized Future<c> a(final String string, final UUID uUID) {
        final FutureResult<c> futureResult = new FutureResult<c>();
        c c2 = null;
        c2 = uUID != null ? F.get(uUID) : c.a(string);
        if (c2 != null) {
            futureResult.a(c2);
        } else {
            final Future<c> future = s.b.a(uUID, string);
            s.a(future, new Runnable(){

                @Override
                public void run() {
                    try {
                        c c2 = (c)future.get();
                        if (c2 == null) {
                            if (uUID != null) {
                                c2 = new c(string, uUID, false);
                            } else {
                                futureResult.a(null);
                                return;
                            }
                        }
                        c2.O();
                        F.put(uUID, c2);
                        futureResult.a(c2);
                    }
                    catch (InterruptedException | ExecutionException exception) {
                        futureResult.die();
                        exception.printStackTrace();
                    }
                }
            });
        }
        return futureResult;
    }

    @Deprecated
    public static Future<c> b(UUID uUID) {
        return c.b(Bukkit.getOfflinePlayer((UUID)uUID).getName(), uUID);
    }

    public static Future<c> b(String string, UUID uUID) {
        return s.b.a(uUID, string);
    }

    public static Future<Boolean> c(UUID uUID) {
        return s.b.d(uUID);
    }

    public String r() {
        return "plugins/MBedwars/data/playerstats/" + this.getUUID().toString() + ".yml";
    }

    public static String a(UUID uUID) {
        return "plugins/MBedwars/data/playerstats/" + uUID.toString() + ".yml";
    }

    public static Future<c[]> b() {
        final Future<UUID[]> future = s.b.c();
        final FutureResult<c[]> futureResult = new FutureResult<c[]>();
        s.a(future, new Runnable(){

            @Override
            public void run() {
                try {
                    UUID[] arruUID = (UUID[])future.get();
                    final c[] arrc = new c[arruUID.length];
                    final a a2 = new a();
                    a.a(a2, arrc.length);
                    int n2 = 0;
                    while (n2 < arruUID.length) {
                        final Future<c> future2 = s.b.a(arruUID[n2], null);
                        final int n3 = n2++;
                        s.a(future2, new Runnable(){

                            @Override
                            public void run() {
                                try {
                                    arrc[n3] = (c)future2.get();
                                    a a22 = a2;
                                    a.a(a22, a22.aq - 1);
                                    if (a2.aq == 0) {
                                        futureResult.a(arrc);
                                    }
                                }
                                catch (InterruptedException | ExecutionException exception) {
                                    exception.printStackTrace();
                                }
                            }
                        });
                    }
                }
                catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                }
            }

        });
        return futureResult;
    }

    @Deprecated
    public static void onEnable() {
    }

    public static void a(UUID uUID) {
        F.remove(uUID);
    }

    public static void e() {
        F.clear();
    }

    @Nullable
    public static c a(String string) {
        for (c c2 : F.values()) {
            if (c2.name == null || !c2.name.equalsIgnoreCase(string)) continue;
            return c2;
        }
        return null;
    }

    public c b() {
        return this.b;
    }

    private static class a {
        private int aq;

        private a() {
        }

        static /* synthetic */ void a(a a2, int n2) {
            a2.aq = n2;
        }
    }

}

