/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockState
 *  org.bukkit.block.Sign
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.api.StatsSignAPI;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.q;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.s;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class StatsSign
implements StatsSignAPI {
    private final int place;
    private final Location location;
    private c a;

    public StatsSign(int n2, Location location) {
        this.place = n2;
        this.location = location;
    }

    public void update() {
        if (!a.b(this.location.getBlock())) {
            new BukkitRunnable(){

                public void run() {
                    StatsSign.this.remove(true);
                }
            }.runTask((Plugin)MBedwars.a);
            return;
        }
        Sign sign = (Sign)this.location.getBlock().getState();
        if (this.a != null) {
            for (int i2 = 1; i2 <= 4; ++i2) {
                String string = this.a(i2);
                sign.setLine(i2 - 1, string.replace("{player}", this.a.getPlayerName()).replace("{rank}", "" + this.place).replace("{wl}", "" + this.a.a()).replace("{kd}", "" + this.a.b()).replace("{wins}", "" + this.a.getWins()).replace("{loses}", "" + this.a.getLoses()).replace("{kills}", "" + this.a.getKills()).replace("{deaths}", "" + this.a.getDeaths()).replace("{bedsdestroyed}", "" + this.a.getBedsDestroyed()).replace("{roundsplayed}", "" + this.a.getRoundsPlayed()).replace("{playtime}", s.a(this.a.getPlayTime())));
            }
        } else {
            for (int i3 = 1; i3 <= 4; ++i3) {
                String string = this.a(i3);
                sign.setLine(i3 - 1, string.replace("{player}", "/").replace("{rank}", "" + this.place).replace("{wl}", "/").replace("{kd}", "/").replace("{wins}", "/").replace("{loses}", "/").replace("{kills}", "/").replace("{deaths}", "/").replace("{bedsdestroyed}", "/").replace("{roundsplayed}", "/").replace("{playtime}", "/"));
            }
        }
        sign.update();
    }

    private String a(int n2) {
        switch (n2) {
            case 1: {
                return ConfigValue.statssign_line1;
            }
            case 2: {
                return ConfigValue.statssign_line2;
            }
            case 3: {
                return ConfigValue.statssign_line3;
            }
            case 4: {
                return ConfigValue.statssign_line4;
            }
        }
        return null;
    }

    @Override
    public UUID getCurrentHolderUUID() {
        return this.a() != null ? this.a().getUUID() : null;
    }

    @Override
    public String getCurrentHolderName() {
        return this.a() != null ? this.a().getPlayerName() : null;
    }

    @Override
    public boolean exists() {
        return s.T.containsValue(this);
    }

    @Override
    public boolean remove() {
        return this.remove(true);
    }

    @Override
    public boolean remove(boolean bl2) {
        if (!this.exists()) {
            return false;
        }
        s.T.remove(this.toString());
        if (bl2) {
            q.save();
        }
        return true;
    }

    @Override
    public int getPlace() {
        return this.place;
    }

    @Override
    public Location getLocation() {
        return this.location;
    }

    public c a() {
        return this.a;
    }

    public void a(c c2) {
        this.a = c2;
    }

}

