/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.api.RankingStatueAPI;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.config.k;
import de.marcely.bedwars.config.l;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Vector;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class RankingStatue
implements RankingStatueAPI {
    private a a;
    private Location location;
    private c a = null;
    private float i = 0.0f;
    private final String K = "MHF_Question";
    private ArmorStand c = null;
    private de.marcely.bedwars.holographic.c<cJ> hologram = null;

    public RankingStatue(Object object) {
        this(null);
    }

    public RankingStatue(a a2) {
        this(a2, new Location(s.a(), 0.0, 0.0, 0.0));
    }

    public RankingStatue(a a2, Location location) {
        this(a2, location, null);
    }

    public RankingStatue(a a2, Location location, c c2) {
        this.a(a2);
        this.setLocation(location.clone());
        this.a(location.getYaw());
        this.a(c2);
    }

    @Override
    public void setLocation(Location location) {
        this.N();
        if (location != null) {
            location.setPitch(0.0f);
        }
        this.location = location;
        this.a();
    }

    public ArmorStand a() {
        if (this.getLocation() != null && this.a != null && Version.a().getVersionNumber() >= 8) {
            this.N();
            Location location = this.getLocation();
            String string = this.a() != null ? this.a().getPlayerName() : null;
            location.setYaw(this.a());
            this.c = (ArmorStand)this.location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
            this.c.setGravity(false);
            this.c.setChestplate(new ItemStack(this.a.a()));
            this.c.setLeggings(new ItemStack(this.a.b()));
            this.c.setBoots(new ItemStack(this.a.c()));
            this.c.setHelmet(string == null ? this.a("MHF_Question") : this.a(string));
            ArrayList<String> arrayList = new ArrayList<String>(k.m.size());
            if (string != null) {
                for (String string2 : k.m) {
                    arrayList.add(string2.replace("{player}", string).replace("{rank}", "" + this.a.getRank()).replace("{wl}", "" + this.a.a()).replace("{kd}", "" + this.a.b()).replace("{wins}", "" + this.a.getWins()).replace("{loses}", "" + this.a.getLoses()).replace("{kills}", "" + this.a.getKills()).replace("{deaths}", "" + this.a.getDeaths()).replace("{bedsdestroyed}", "" + this.a.getBedsDestroyed()).replace("{roundsplayed}", "" + this.a.getRoundsPlayed()).replace("{playtime}", s.a(this.a.getPlayTime())));
                }
            } else {
                for (String string3 : k.m) {
                    arrayList.add(string3.replace("{player}", "/").replace("{rank}", "" + this.a.getRank()).replace("{wl}", "/").replace("{kd}", "/").replace("{wins}", "/").replace("{loses}", "/").replace("{kills}", "/").replace("{deaths}", "/").replace("{bedsdestroyed}", "/").replace("{roundsplayed}", "/").replace("{playtime}", "/"));
                }
            }
            this.hologram = de.marcely.bedwars.holographic.c.a(cJ.class, location.clone().add(location.getDirection()), new cF().a(arrayList));
            this.hologram.Q();
            return this.c;
        }
        return null;
    }

    public ItemStack a(String string) {
        ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, 1, 3);
        SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
        skullMeta.setOwner(string);
        itemStack.setItemMeta((ItemMeta)skullMeta);
        return itemStack;
    }

    public ArmorStand b() {
        return this.c;
    }

    @Deprecated
    public void M() {
        if (this.location != null) {
            ArmorStand armorStand;
            Location location = this.location.clone().add(this.location.getDirection());
            for (Entity entity : b.getNearbyEntities(location, 1.0, 5.0, 1.0)) {
                if (entity.getType() != EntityType.ARMOR_STAND || (armorStand = (ArmorStand)entity).isVisible() || armorStand.hasGravity()) continue;
                armorStand.remove();
            }
            for (Entity entity : b.getNearbyEntities(this.location, 0.2, 0.2, 0.2)) {
                if (entity.getType() != EntityType.ARMOR_STAND || (armorStand = (ArmorStand)entity).hasGravity()) continue;
                entity.remove();
                break;
            }
        }
    }

    private void N() {
        if (this.c != null && !this.c.isDead()) {
            this.c.remove();
        } else if (this.location != null) {
            for (Entity entity : b.getNearbyEntities(this.location, 0.1, 0.1, 0.1)) {
                ArmorStand armorStand;
                if (entity.getType() != EntityType.ARMOR_STAND || (armorStand = (ArmorStand)entity).hasGravity()) continue;
                armorStand.remove();
            }
        }
        if (this.hologram != null) {
            this.hologram.remove();
            this.hologram = null;
        }
    }

    @Override
    public int getPlace() {
        return this.a().getRank();
    }

    @Override
    public UUID getCurrentHolderUUID() {
        return this.a() != null ? this.a().getUUID() : null;
    }

    @Override
    public String getCurrentHolderName() {
        return this.a() != null ? this.a().getPlayerName() : null;
    }

    @Override
    public boolean exists() {
        return s.ad.contains(this);
    }

    @Override
    public boolean remove() {
        return this.remove(true);
    }

    @Override
    public boolean remove(boolean bl2) {
        if (!this.exists()) {
            return false;
        }
        s.ad.remove(this);
        if (bl2) {
            l.save();
        }
        this.N();
        return true;
    }

    public a a() {
        return this.a;
    }

    public void a(a a2) {
        this.a = a2;
    }

    @Override
    public Location getLocation() {
        return this.location;
    }

    public c a() {
        return this.a;
    }

    public void a(c c2) {
        this.a = c2;
    }

    public float a() {
        return this.i;
    }

    public void a(float f2) {
        this.i = f2;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class a
    extends Enum<a> {
        public static final /* enum */ a b = new a(1, Material.GOLD_CHESTPLATE, Material.GOLD_LEGGINGS, Material.GOLD_BOOTS);
        public static final /* enum */ a c = new a(2, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS);
        public static final /* enum */ a d = new a(3, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS);
        private int af;
        private Material b;
        private Material c;
        private Material d;
        private static final /* synthetic */ a[] a;

        static {
            a = new a[]{b, c, d};
        }

        private a(int n3, Material material, Material material2, Material material3) {
            this.af = n3;
            this.b = material;
            this.c = material2;
            this.d = material3;
        }

        public int getRank() {
            return this.af;
        }

        public Material a() {
            return this.b;
        }

        public Material b() {
            return this.c;
        }

        public Material c() {
            return this.d;
        }

        public static a a(int n2) {
            for (a a2 : a.values()) {
                if (a2.getRank() != n2) continue;
                return a2;
            }
            return null;
        }

        public static a[] values() {
            a[] arra = a;
            int n2 = arra.length;
            a[] arra2 = new a[n2];
            System.arraycopy(arra, 0, arra2, 0, n2);
            return arra2;
        }

        public static a valueOf(String string) {
            return Enum.valueOf(a.class, string);
        }
    }

}

