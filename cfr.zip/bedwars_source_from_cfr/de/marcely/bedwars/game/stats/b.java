/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.util.FutureResult;
import de.marcely.bedwars.util.s;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class b {
    public static c[] a = new c[10];

    public b(String string) {
    }

    public static Future<Void> a() {
        final Future<c[]> future = c.b();
        final FutureResult<Void> futureResult = new FutureResult<Void>();
        s.a(future, new Runnable(){

            @Override
            public void run() {
                c[] arrc = null;
                try {
                    arrc = (c[])future.get();
                    if (arrc == null) {
                        return;
                    }
                }
                catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                }
                Arrays.fill(a, null);
                ArrayList<Map.Entry<Double, c>> arrayList = new ArrayList<Map.Entry<Double, c>>();
                for (c c2 : arrc) {
                    if (c2 == null) continue;
                    double d2 = -1.0;
                    switch (ConfigValue.ranking_sortation) {
                        case 0: {
                            d2 = c2.getWins();
                            break;
                        }
                        case 1: {
                            d2 = c2.getLoses();
                            break;
                        }
                        case 2: {
                            d2 = c2.getRoundsPlayed();
                            break;
                        }
                        case 3: {
                            d2 = c2.a();
                            break;
                        }
                        case 4: {
                            d2 = c2.getKills();
                            break;
                        }
                        case 5: {
                            d2 = c2.getDeaths();
                            break;
                        }
                        case 6: {
                            d2 = c2.b();
                            break;
                        }
                        case 7: {
                            d2 = c2.getBedsDestroyed();
                            break;
                        }
                        case 8: {
                            d2 = c2.getRoundsPlayed();
                            break;
                        }
                        default: {
                            d.a("Unkown 'ranking-sortation' value '" + ConfigValue.ranking_sortation + "'");
                            futureResult.die();
                        }
                    }
                    arrayList.add(new AbstractMap.SimpleEntry<Double, c>(d2, c2));
                }
                arrayList.sort(new Comparator<Map.Entry<Double, c>>(){

                    public int a(Map.Entry<Double, c> entry, Map.Entry<Double, c> entry2) {
                        return entry2.getKey().compareTo(entry.getKey());
                    }

                    @Override
                    public /* synthetic */ int compare(Object object, Object object2) {
                        return this.a((Map.Entry)object, (Map.Entry)object2);
                    }
                });
                int n2 = 1;
                for (Map.Entry entry : arrayList) {
                    c c3 = (c)entry.getValue();
                    if (c3.getRank() != n2) {
                        c3.setRank(n2);
                        c3.save();
                    }
                    b.a[n2 - 1] = c3;
                    if (n2++ == a.length - 1) break;
                }
                futureResult.a(null);
            }

        });
        return futureResult;
    }

}

