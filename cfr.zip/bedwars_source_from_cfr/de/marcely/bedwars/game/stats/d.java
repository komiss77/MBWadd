/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.cF;
import de.marcely.bedwars.cM;
import de.marcely.bedwars.holographic.c;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;

public class d {
    private static List<c<cM>> W = new ArrayList<c<cM>>();

    public static void e(Location location) {
        c<cM> c2 = c.a(cM.class, location, new cF());
        c2.Q();
        W.add(c2);
    }

    public static void a(c<cM> c2) {
        c2.remove();
        W.remove(c2);
    }

    public static void f(Location location) {
        d.a(d.a(location));
    }

    public static void P() {
        for (c<cM> c2 : new ArrayList<c<cM>>(W)) {
            d.a(c2);
        }
    }

    private static c<cM> a(Location location) {
        for (c<cM> c2 : W) {
            Location location2 = c2.getLocation();
            if (!location2.getWorld().equals((Object)location.getWorld()) || location2.getX() != location.getX() || location2.getY() != location.getY() || location2.getZ() != location.getZ()) continue;
            return c2;
        }
        return null;
    }

    public static List<c<cM>> u() {
        return W;
    }
}

