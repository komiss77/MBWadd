/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.stats;

import java.util.UUID;

public class a {
    public final a[] a = new a[10];

    public void a(int n2, a a2) {
        this.a[n2 - 1] = a2;
    }

    public a a(int n2) {
        return this.a[n2 - 1];
    }

    public static class a {
        public final UUID uuid;
        public final String name;

        public a(UUID uUID, String string) {
            this.uuid = uUID;
            this.name = string;
        }
    }

}

