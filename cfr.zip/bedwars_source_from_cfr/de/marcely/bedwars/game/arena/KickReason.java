/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class KickReason
extends Enum<KickReason> {
    @Deprecated
    public static final /* enum */ KickReason a = new KickReason();
    public static final /* enum */ KickReason b = new KickReason();
    public static final /* enum */ KickReason c = new KickReason();
    public static final /* enum */ KickReason d = new KickReason();
    public static final /* enum */ KickReason e = new KickReason();
    public static final /* enum */ KickReason f = new KickReason();
    public static final /* enum */ KickReason g = new KickReason();
    public static final /* enum */ KickReason h = new KickReason();
    private static final /* synthetic */ KickReason[] a;

    static {
        a = new KickReason[]{a, b, c, d, e, f, g, h};
    }

    public static KickReason[] values() {
        KickReason[] arrkickReason = a;
        int n2 = arrkickReason.length;
        KickReason[] arrkickReason2 = new KickReason[n2];
        System.arraycopy(arrkickReason, 0, arrkickReason2, 0, n2);
        return arrkickReason2;
    }

    public static KickReason valueOf(String string) {
        return Enum.valueOf(KickReason.class, string);
    }
}

