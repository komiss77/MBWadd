/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.regeneration.a;
import de.marcely.bedwars.game.regeneration.b;
import de.marcely.bedwars.game.regeneration.e;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

public enum RegenerationType {
    c(true),
    d(true),
    e(false);
    
    private boolean N;
    private static /* synthetic */ int[] j;

    private RegenerationType(boolean bl2) {
        this.N = bl2;
    }

    public boolean J() {
        return this.N;
    }

    @Nullable
    public a a(Arena arena) {
        return this.a(arena, null);
    }

    @Nullable
    public a a(Arena arena, @Nullable CommandSender commandSender) {
        switch (RegenerationType.k()[this.ordinal()]) {
            case 1: {
                return new b(arena, commandSender);
            }
            case 2: {
                return new e(arena, commandSender);
            }
        }
        return null;
    }

    public static RegenerationType a(String string) {
        for (RegenerationType regenerationType : RegenerationType.values()) {
            if (!regenerationType.name().equalsIgnoreCase(string)) continue;
            return regenerationType;
        }
        return null;
    }

    static /* synthetic */ int[] k() {
        if (j != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[RegenerationType.values().length];
        try {
            arrn[RegenerationType.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[RegenerationType.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[RegenerationType.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        j = arrn;
        return j;
    }
}

