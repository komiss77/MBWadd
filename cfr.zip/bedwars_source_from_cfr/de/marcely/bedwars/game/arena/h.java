/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.DyeColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Bed
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.block.BlockState
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryType
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.api.TeamColors;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.arena.i;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.u;
import de.marcely.bedwars.versions.w;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Bed;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class h
implements TeamColors {
    private final Arena arena;
    private List<Team> i = new ArrayList<Team>();
    public Map<Team, XYZD> y = new HashMap<Team, XYZD>();
    private Map<Team, XYZYP> z = new HashMap<Team, XYZYP>();
    private Map<Team, i> A = new HashMap<Team, i>();
    private Map<Team, Long> B = new HashMap<Team, Long>();
    public Map<Team, Inventory> C = new HashMap<Team, Inventory>();

    public h(Arena arena) {
        this.arena = arena;
    }

    public Inventory a(Player player, Team team) {
        if (!this.C.containsKey((Object)team)) {
            Inventory inventory = Bukkit.createInventory((InventoryHolder)player, (InventoryType)InventoryType.CHEST);
            this.C.put(team, inventory);
        }
        return this.C.get((Object)team);
    }

    public void reset() {
        this.reset(false);
    }

    public void reset(boolean bl2) {
        this.B.clear();
        this.C.clear();
        this.A.clear();
        if (!bl2) {
            for (Team object : this.i) {
                if (this.arena.a(object).size() != 0) continue;
                this.B.put(object, System.currentTimeMillis());
            }
        }
        for (Map.Entry entry : this.e().entrySet()) {
            Team team = (Team)((Object)entry.getKey());
            XYZD xYZD = (XYZD)entry.getValue();
            if (xYZD == null) continue;
            if (this.arena.getWorld() == null) {
                d.b("World is null in TeamColors (1)", this.arena);
                continue;
            }
            Block block = this.arena.getWorld().getBlockAt((int)xYZD.getX(), (int)xYZD.getY(), (int)xYZD.getZ());
            if (!bl2 && this.B.containsKey((Object)team)) {
                block.setType(Material.AIR);
                continue;
            }
            if (ConfigValue.bed_block == Material.BED_BLOCK) {
                this.a(block, team, xYZD, false);
                block = block.getRelative(xYZD.getDAsBlockFace());
                this.a(block, team, xYZD, true);
                continue;
            }
            block.setType(ConfigValue.bed_block);
            if (!ConfigValue.bed_block_dye) continue;
            a.a(block, team.getDyeColor());
        }
    }

    private void a(Block block, Team team, XYZD xYZD, boolean bl2) {
        if (Version.a().getVersionNumber() <= 12) {
            b.a(block, Material.BED_BLOCK, false);
            block.setData((byte)(xYZD.getD() + (bl2 ? 8 : 0)), false);
            if (ConfigValue.bed_block_dye && Version.a().getVersionNumber() == 12) {
                Bed bed = (Bed)block.getState();
                bed.setColor(team.getDyeColor());
                bed.update();
            }
        } else {
            String string = "RED_BED";
            if (ConfigValue.bed_block_dye) {
                string = team.getDyeColor() == DyeColor.SILVER ? "LIGHT_GRAY" : team.getDyeColor().name();
            }
            ((w)Version.a().a()).b(block.getWorld(), block.getX(), block.getY(), block.getZ(), String.valueOf(string.toLowerCase()) + "_bed");
            ((w)Version.a().a()).a(block, xYZD.getDAsBlockFace(), bl2);
        }
    }

    public void J() {
        this.i.clear();
    }

    public boolean c(Team team) {
        if (!this.r().contains((Object)team)) {
            this.i.add(team);
            return true;
        }
        return false;
    }

    public void b(List<Team> list) {
        this.i = list;
    }

    public boolean a(Team team, boolean bl2) {
        if (bl2 && !this.B.containsKey((Object)team)) {
            this.B.put(team, System.currentTimeMillis());
        } else if (!bl2 && this.B.containsKey((Object)team)) {
            this.B.remove((Object)team);
        } else {
            return false;
        }
        this.arena.a.G();
        return true;
    }

    public void a(Location location, Team team) {
        this.a(XYZYP.valueOf(location), team);
    }

    public void a(XYZYP xYZYP, Team team) {
        this.z.put(team, xYZYP);
    }

    public void a(XYZD xYZD, Team team) {
        this.y.put(team, xYZD);
    }

    public XYZD a(Team team) {
        if (this.arena.b() == ArenaStatus.f && this.i.contains((Object)team) && this.y.get((Object)team) == null) {
            d.b("Bed of '" + team.name() + "' in the arena '" + this.arena.getName() + "' is broken! Make sure to place it again.");
        }
        return this.y.get((Object)team);
    }

    public XYZYP a(Team team) {
        return this.z.get((Object)team);
    }

    public List<Team> r() {
        return this.i;
    }

    public Map<Team, XYZYP> d() {
        return this.z;
    }

    public Map<Team, XYZD> e() {
        return this.y;
    }

    public boolean d(Team team) {
        return this.B.containsKey((Object)team);
    }

    public Set<Team> a() {
        return this.B.keySet();
    }

    @Override
    public Arena getArena() {
        return this.arena;
    }

    public long a(Team team) {
        return this.B.get((Object)team);
    }

    public Block[] a(Team team) {
        if (ConfigValue.bed_block == Material.BED_BLOCK) {
            Block[] arrblock = new Block[2];
            XYZD xYZD = this.a(team);
            arrblock[0] = xYZD.toBlock(this.arena.getWorld());
            arrblock[1] = arrblock[0].getRelative(xYZD.getDAsBlockFace());
            return arrblock;
        }
        return new Block[]{this.a(team).toBlock(this.arena.getWorld())};
    }

    public Block[] a() {
        Block[] arrblock = new Block[this.i.size() * (ConfigValue.bed_block == Material.BED_BLOCK ? 2 : 1)];
        for (int i2 = 0; i2 < this.i.size(); ++i2) {
            Block[] arrblock2 = this.a(this.i.get(i2));
            for (int i3 = 0; i3 < arrblock2.length; ++i3) {
                arrblock[i2 * arrblock2.length + i3] = arrblock2[i3];
            }
        }
        return arrblock;
    }

    @Nullable
    public Team a(Location location) {
        for (Team team : this.r()) {
            if (this.a(team) == null || !s.a(XYZ.valueOf(location), this.a(team))) continue;
            return team;
        }
        return null;
    }

    @Override
    public void setTeamEnabled(de.marcely.bedwars.api.Team team, boolean bl2) {
        if (bl2) {
            if (!this.i.contains((Object)team.getInternal())) {
                this.i.remove((Object)team.getInternal());
            }
        } else if (this.i.contains((Object)team.getInternal())) {
            this.i.add(team.getInternal());
        }
    }

    @Override
    public boolean isTeamEnabled(de.marcely.bedwars.api.Team team) {
        return this.i.contains((Object)team.getInternal());
    }

    @Override
    public void setBedLocation(de.marcely.bedwars.api.Team team, XYZD xYZD) {
        this.a(xYZD, team.getInternal());
    }

    @Override
    public XYZYP getSpawnLocation(de.marcely.bedwars.api.Team team) {
        return this.z.containsKey((Object)team.getInternal()) ? this.z.get((Object)team.getInternal()) : null;
    }

    @Override
    public void setSpawnLocation(de.marcely.bedwars.api.Team team, XYZYP xYZYP) {
        this.a(xYZYP, team.getInternal());
    }

    @Override
    public boolean isBedDestroyed(de.marcely.bedwars.api.Team team) {
        return this.B.containsKey((Object)team.getInternal());
    }

    @Override
    public void _0setBedDestroyed(de.marcely.bedwars.api.Team team, boolean bl2) {
        if (bl2) {
            if (!this.B.containsKey((Object)team.getInternal())) {
                this.B.put(team.getInternal(), System.currentTimeMillis());
            }
        } else if (this.B.containsKey((Object)team.getInternal())) {
            this.B.remove((Object)team.getInternal());
        }
    }

    @Override
    public void _0reset() {
        this.reset();
    }

    @Override
    public XYZD getBedLocation(de.marcely.bedwars.api.Team team) {
        return this.y.containsKey((Object)team.getInternal()) ? this.y.get((Object)team.getInternal()) : null;
    }

    @Override
    public List<de.marcely.bedwars.api.Team> GetEnabledTeams() {
        ArrayList<de.marcely.bedwars.api.Team> arrayList = new ArrayList<de.marcely.bedwars.api.Team>();
        for (Team team : this.i) {
            arrayList.add(de.marcely.bedwars.api.Team.fromInternal(team));
        }
        return arrayList;
    }

    public Map<Team, i> f() {
        return this.A;
    }
}

