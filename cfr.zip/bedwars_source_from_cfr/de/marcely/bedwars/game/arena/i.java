/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.api.UpgradeStateAPI;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.util.s;
import java.util.HashMap;
import java.util.Map;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class i
implements UpgradeStateAPI {
    private final Arena arena;
    private final Team team;
    private Map<UpgradeType, Integer> D = new HashMap<UpgradeType, Integer>();

    public i(Arena arena, Team team) {
        this.arena = arena;
        this.team = team;
    }

    public void a(UpgradeType upgradeType, int n2) {
        this.D.put(upgradeType, n2);
    }

    public int a(UpgradeType upgradeType) {
        if (this.D.containsKey(upgradeType)) {
            return this.D.get(upgradeType);
        }
        return 0;
    }

    public boolean a(UpgradeType upgradeType) {
        return s.a(upgradeType, this.a(upgradeType) + 1) != null;
    }

    public void clear() {
        this.D.clear();
    }

    public Team getTeam() {
        return this.team;
    }

    @Override
    public de.marcely.bedwars.api.Team GetTeam() {
        return de.marcely.bedwars.api.Team.fromInternal(this.team);
    }

    @Override
    public Arena getArena() {
        return this.arena;
    }
}

