/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.message.b;
import org.bukkit.command.CommandSender;

public class CrashMessage {
    private CrashMessageType type;
    private String information;
    private String custom_message;
    private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType;

    public CrashMessage(CrashMessageType crashMessageType) {
        this(crashMessageType, null);
    }

    public CrashMessage(CrashMessageType crashMessageType, String string) {
        this.type = crashMessageType;
        this.information = string;
    }

    public CrashMessageType getType() {
        return this.type;
    }

    public String getInformation() {
        return this.information;
    }

    public String getMessage() {
        switch (CrashMessage.$SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType()[this.type.ordinal()]) {
            case 1: {
                return b.a(Language.CrashMessage_MissingBed).f(null);
            }
            case 4: {
                return b.a(Language.CrashMessage_MissingGameDoneLocation).f(null);
            }
            case 3: {
                return b.a(Language.CrashMessage_MissingLobbyLocation).f(null);
            }
            case 2: {
                return b.a(Language.CrashMessage_MissingTeamSpawn).f(null);
            }
            case 5: {
                return b.a(Language.CrashMessage_TooFewItemSpawners).f(null);
            }
            case 6: {
                return this.custom_message;
            }
        }
        return null;
    }

    public static CrashMessage createCustomCrashMessage(String string) {
        return CrashMessage.createCustomCrashMessage(string, null);
    }

    public static CrashMessage createCustomCrashMessage(String string, String string2) {
        CrashMessage crashMessage = new CrashMessage(CrashMessageType.custom, string2);
        crashMessage.custom_message = string;
        return crashMessage;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType() {
        if ($SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[CrashMessageType.values().length];
        try {
            arrn[CrashMessageType.custom.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[CrashMessageType.missingBed.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[CrashMessageType.missingGameDoneLocation.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[CrashMessageType.missingLobbyLocation.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[CrashMessageType.missingTeamSpawn.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[CrashMessageType.tooFewItemSpawners.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType = arrn;
        return $SWITCH_TABLE$de$marcely$bedwars$game$arena$CrashMessage$CrashMessageType;
    }

    public static enum CrashMessageType {
        missingBed,
        missingTeamSpawn,
        missingLobbyLocation,
        missingGameDoneLocation,
        tooFewItemSpawners,
        custom;
        
    }

}

