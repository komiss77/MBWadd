/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;

public abstract class a {
    public abstract boolean a(Arena var1);
}

