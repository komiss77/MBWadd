/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeNumber;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeString;
import de.marcely.bedwars.bl;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionComparisonOperator;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;
import de.marcely.bedwars.game.arena.picker.condition.a;
import de.marcely.bedwars.game.arena.picker.condition.b;
import de.marcely.bedwars.game.arena.picker.condition.c;
import de.marcely.bedwars.util.s;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Constructor;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Stack;
import javax.annotation.Nullable;

public class d {
    private int offset = 0;

    public d() {
    }

    public d(int n2) {
        this.offset = n2;
    }

    public c a(String string) throws bl {
        return this.a(string.getBytes(StandardCharsets.UTF_8));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public c a(byte[] var1_1) throws bl {
        var2_2 = false;
        var3_3 = true;
        var4_4 = 10;
        var5_5 = 11;
        var6_6 = 2;
        var7_7 = new ByteArrayOutputStream();
        var8_8 = 0;
        var9_9 = 0;
        var10_10 = new Stack<c>();
        var11_11 = null;
        var12_12 = null;
        var13_13 = null;
        var10_10.push(new c(new ArrayList<a>()).b());
        while (this.offset < var1_1.length) {
            block33 : {
                block31 : {
                    block32 : {
                        var14_14 = var1_1[this.offset];
                        if (var8_8 == 0) {
                            if (var14_14 != 91) throw new bl("Missing first enclosing (Must start with a [)");
                            var8_8 = 1;
                        } else if (var14_14 == 93) {
                            var8_8 = 2;
                            if (var9_9 < 10 || var9_9 > 19) break;
                            var13_13 = var7_7.toByteArray();
                            break;
                        }
                        if (var9_9 != 11) break block31;
                        if (var14_14 != 34) break block32;
                        var13_13 = var7_7.toByteArray();
                        var7_7.reset();
                        var9_9 = 2;
                        break block33;
                    }
                    var7_7.write(var14_14);
                }
                if (var14_14 != 38 && var14_14 != 124) ** GOTO lbl56
                if (var9_9 != 10) {
                    if (var9_9 != 2) throw new bl("Found a truth condition (& or |) at the wrong position");
                }
                if (var11_11 == null && var12_12 == null && var13_13 == null) {
                    var9_9 = 0;
                } else {
                    if (var13_13 == null && var7_7.size() >= 1 && var9_9 >= 10 && var9_9 <= 19) {
                        var13_13 = var7_7.toByteArray();
                        var7_7.reset();
                    }
                    var15_16 = (c)var10_10.peek();
                    var16_18 = d.a(var11_11, var12_12, var13_13);
                    var15_16.b.add(var16_18);
                    if (var14_14 == 124) {
                        var15_16.b().add(new c(new ArrayList<a>(var15_16.b)).b());
                        var15_16.b.clear();
                    }
                    var11_11 = null;
                    var12_12 = null;
                    var13_13 = null;
                    var9_9 = 0;
lbl56: // 2 sources:
                    if (var14_14 == 40) {
                        var15_16 = (c)var10_10.peek();
                        var16_19 = new c().b();
                        var15_16.b().addAll(var15_16.b);
                        var15_16.b().add(var16_19);
                        var15_16.b.clear();
                        var10_10.push(var16_19);
                    } else if (var14_14 == 41) {
                        if (var10_10.size() <= 1) {
                            throw new bl("Can't go any deeper (Too many ) )");
                        }
                        if (var9_9 >= 10 && var9_9 <= 19) {
                            var13_13 = var7_7.toByteArray();
                            var7_7.reset();
                            var9_9 = 2;
                        }
                        if (var9_9 != 2) {
                            throw new bl("Found a ) at the wrong position");
                        }
                        var15_16 = (c)var10_10.pop();
                        if (var11_11 != null) {
                            var16_20 = d.a(var11_11, var12_12, var13_13);
                            var15_16.b.add(var16_20);
                            var15_16.b().add(new c(new ArrayList<a>(var15_16.b)).b());
                            var15_16.b.clear();
                            var11_11 = null;
                            var12_12 = null;
                            var13_13 = null;
                            var9_9 = 2;
                        }
                    }
                    if (var9_9 == 0) {
                        if (var14_14 >= 48 && var14_14 <= 58 || var14_14 >= 97 && var14_14 <= 122 || var14_14 >= 65 && var14_14 <= 90 || var14_14 == 95 || var14_14 == 64) {
                            var7_7.write(var14_14);
                        } else if (var14_14 == 62 || var14_14 == 60 || var14_14 == 61 || var14_14 == 33) {
                            var11_11 = var7_7.toByteArray();
                            var7_7.reset();
                            var7_7.write(var14_14);
                            var9_9 = 1;
                        }
                    } else if (var9_9 == 1) {
                        if (var14_14 == 62 || var14_14 == 60 || var14_14 == 61 || var14_14 == 33) {
                            var7_7.write(var14_14);
                        } else if (var14_14 >= 48 && var14_14 <= 57 || var14_14 == 46) {
                            var12_12 = var7_7.toByteArray();
                            var7_7.reset();
                            var7_7.write(var14_14);
                            var9_9 = 10;
                        } else if (var14_14 == 34) {
                            var12_12 = var7_7.toByteArray();
                            var7_7.reset();
                            var9_9 = 11;
                        }
                    } else if (var9_9 == 10 && (var14_14 >= 48 || var14_14 <= 57 || var14_14 == 46)) {
                        var7_7.write(var14_14);
                    }
                }
            }
            ++this.offset;
        }
        if (var8_8 == 1) {
            throw new bl("Missing last enclosing (Must end with a ])");
        }
        if (var10_10.size() >= 2) {
            throw new bl("Too many broken brackets (" + (var10_10.size() - 1) + " need to be closed with a ) )");
        }
        var14_15 = (c)var10_10.peek();
        if (var11_11 == null) return var14_15;
        var15_16 = d.a(var11_11, var12_12, var13_13);
        var14_15.b.add(var15_16);
        var14_15.b().add(new c(new ArrayList<a>(var14_15.b)));
        return var14_15;
    }

    private static b a(@Nullable byte[] arrby, @Nullable byte[] arrby2, @Nullable byte[] arrby3) throws bl {
        ArenaConditionVariable<?> arenaConditionVariable = new ArrayList<String>();
        if (arrby == null) {
            arenaConditionVariable.add("Variable");
        }
        if (arrby2 == null) {
            arenaConditionVariable.add("Comparison Operator");
        }
        if (arrby3 == null) {
            arenaConditionVariable.add("Compare Object");
        }
        if (arenaConditionVariable.size() >= 1) {
            throw new bl("Failed to add a child: Missing " + String.join((CharSequence)",", arenaConditionVariable));
        }
        arenaConditionVariable = null;
        ArenaConditionComparisonOperator arenaConditionComparisonOperator = null;
        Object object = null;
        Object object2 = new String(arrby).toLowerCase();
        arenaConditionVariable = s.aa.get(object2);
        if (arenaConditionVariable == null) {
            throw new bl("Unkown variable '" + (String)object2 + "'");
        }
        object2 = new String(arrby2);
        arenaConditionComparisonOperator = ArenaConditionComparisonOperator.a((String)object2);
        if (arenaConditionComparisonOperator == null) {
            throw new bl("Unkown comparison operator '" + (String)object2 + "'");
        }
        if (arenaConditionVariable.getType() == ArenaConditionVariableTypeNumber.class) {
            object2 = new String(arrby3);
            try {
                object = Float.valueOf(Float.parseFloat((String)object2));
            }
            catch (NumberFormatException numberFormatException) {
                throw new bl("Failed to parse number '" + (String)object2 + "'");
            }
        } else if (arenaConditionVariable.getType() == ArenaConditionVariableTypeString.class) {
            object = new String(arrby3, StandardCharsets.UTF_8);
        } else {
            throw new bl("Error: Unkown variable type" + arenaConditionVariable.getType().getSimpleName());
        }
        try {
            object2 = (ArenaConditionVariableType)arenaConditionVariable.getType().getConstructors()[0].newInstance(object);
            return new b(arenaConditionVariable, arenaConditionComparisonOperator, (ArenaConditionVariableType<?>)object2);
        }
        catch (Exception exception) {
            throw new bl("Comparison object type mismatch: Variable expects an other type");
        }
    }

    public int getOffset() {
        return this.offset;
    }

    public void setOffset(int n2) {
        this.offset = n2;
    }
}

