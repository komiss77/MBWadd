/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.game.arena.picker.condition.a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class c
extends a {
    public Collection<a> b = null;
    private final Collection<a> c;

    public c() {
        this(new ArrayList<a>());
    }

    public c(Collection<a> collection) {
        this.c = collection;
    }

    public c b() {
        this.b = new ArrayList<a>();
        return this;
    }

    @Override
    public boolean a(Arena arena) {
        boolean bl2 = !(this.c.iterator().next() instanceof c);
        for (a a2 : this.c) {
            if (a2.a(arena)) {
                if (bl2) continue;
                return true;
            }
            if (!bl2) continue;
            return false;
        }
        return bl2;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("Group{");
        CharSequence[] arrcharSequence = new String[this.c.size()];
        int n2 = 0;
        for (a a2 : this.c) {
            arrcharSequence[n2++] = a2.toString();
        }
        stringBuilder.append("childrens=[" + String.join((CharSequence)", ", arrcharSequence) + "]");
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public Collection<a> b() {
        return this.c;
    }
}

