/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.Team;
import de.marcely.bedwars.api.TeamColors;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeNumber;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeString;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.Map;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class e
extends Enum<e> {
    public static final /* enum */ e a = new e(new ArenaConditionVariable("players_per_team", ArenaConditionVariableTypeNumber.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeNumber(arena.getTeamPlayers());
        }
    });
    public static final /* enum */ e b = new e(new ArenaConditionVariable("teams", ArenaConditionVariableTypeNumber.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeNumber(arena.GetTeamColors().GetEnabledTeams().size());
        }
    });
    public static final /* enum */ e c = new e(new ArenaConditionVariable("max_players", ArenaConditionVariableTypeNumber.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeNumber(arena.getMaxPlayers());
        }
    });
    public static final /* enum */ e d = new e(new ArenaConditionVariable("ingame_players", ArenaConditionVariableTypeNumber.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeNumber(arena.getPlayers().size());
        }
    });
    public static final /* enum */ e e = new e(new ArenaConditionVariable("status", ArenaConditionVariableTypeNumber.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeNumber(arena.GetStatus().getNms().getID());
        }
    });
    public static final /* enum */ e f = new e(new ArenaConditionVariable("name", ArenaConditionVariableTypeString.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeString(arena.getName());
        }
    });
    public static final /* enum */ e g = new e(new ArenaConditionVariable("display_name", ArenaConditionVariableTypeString.class){

        public ArenaConditionVariableType getValue(Arena arena) {
            return new ArenaConditionVariableTypeString(arena.getDisplayName());
        }
    });
    private final ArenaConditionVariable a;
    private static final /* synthetic */ e[] a;

    static {
        a = new e[]{a, b, c, d, e, f, g};
    }

    private e(ArenaConditionVariable<?> arenaConditionVariable) {
        this.a = arenaConditionVariable;
    }

    public static void init() {
        if (s.aa.size() >= 1) {
            return;
        }
        for (e e2 : e.values()) {
            s.aa.put(e2.toString().toLowerCase(), e2.a);
        }
    }

    public ArenaConditionVariable a() {
        return this.a;
    }

    public static e[] values() {
        e[] arre = a;
        int n2 = arre.length;
        e[] arre2 = new e[n2];
        System.arraycopy(arre, 0, arre2, 0, n2);
        return arre2;
    }

    public static e valueOf(String string) {
        return Enum.valueOf(e.class, string);
    }

}

