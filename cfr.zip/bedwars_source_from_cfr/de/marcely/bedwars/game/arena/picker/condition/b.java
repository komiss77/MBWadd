/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionComparisonOperator;
import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;
import de.marcely.bedwars.game.arena.picker.condition.a;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class b
extends a {
    private final ArenaConditionVariable<?> a;
    private final ArenaConditionComparisonOperator a;
    private final ArenaConditionVariableType<?> a;

    public b(ArenaConditionVariable<?> arenaConditionVariable, ArenaConditionComparisonOperator arenaConditionComparisonOperator, ArenaConditionVariableType<?> arenaConditionVariableType) {
        this.a = arenaConditionVariable;
        this.a = arenaConditionComparisonOperator;
        this.a = arenaConditionVariableType;
    }

    @Override
    public boolean a(Arena arena) {
        return ((ArenaConditionVariableType)this.a.getValue(arena)).check(this.a, (ArenaConditionVariableType<?>)((Object)this.a));
    }

    public String toString() {
        return "Child{variable=" + this.a.getType().getSimpleName() + ", operator=\"" + this.a.getUsage() + "\", comparison object=\"" + ((ArenaConditionVariableType)((Object)this.a)).getEntry() + "\"}";
    }

    public ArenaConditionVariable<?> a() {
        return this.a;
    }

    public ArenaConditionComparisonOperator a() {
        return this.a;
    }

    public ArenaConditionVariableType<?> a() {
        return this.a;
    }
}

