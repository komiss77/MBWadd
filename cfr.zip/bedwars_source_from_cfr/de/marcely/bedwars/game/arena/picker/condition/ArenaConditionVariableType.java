/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionComparisonOperator;

public abstract class ArenaConditionVariableType<T> {
    public static final byte NUMBER = 0;
    public static final byte STRING = 1;
    protected final T entry;
    private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator;

    public ArenaConditionVariableType(T t2) {
        this.entry = t2;
    }

    public abstract byte getType();

    public abstract boolean equal(T var1);

    public abstract boolean notEqual(T var1);

    public abstract boolean greaterThan(T var1);

    public abstract boolean lessThan(T var1);

    public abstract boolean greaterThanOrEqual(T var1);

    public abstract boolean lessThanOrEqual(T var1);

    public boolean check(ArenaConditionComparisonOperator arenaConditionComparisonOperator, ArenaConditionVariableType<?> arenaConditionVariableType) {
        switch (ArenaConditionVariableType.$SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator()[arenaConditionComparisonOperator.ordinal()]) {
            case 1: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case 2: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case 3: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case 4: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case 5: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case 6: {
                return this.equal(arenaConditionVariableType.entry);
            }
        }
        throw new IllegalStateException("Operator " + (Object)((Object)arenaConditionComparisonOperator) + " not supported");
    }

    public T getEntry() {
        return this.entry;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator() {
        if ($SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ArenaConditionComparisonOperator.values().length];
        try {
            arrn[ArenaConditionComparisonOperator.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaConditionComparisonOperator.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaConditionComparisonOperator.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaConditionComparisonOperator.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaConditionComparisonOperator.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaConditionComparisonOperator.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator = arrn;
        return $SWITCH_TABLE$de$marcely$bedwars$game$arena$picker$condition$ArenaConditionComparisonOperator;
    }
}

