/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.bedwars.game.arena.picker.condition;

import javax.annotation.Nullable;

public enum ArenaConditionComparisonOperator {
    b("="),
    c("!="),
    d(">"),
    e("<"),
    f(">="),
    g("<=");
    
    private final String usage;

    private ArenaConditionComparisonOperator(String string2) {
        this.usage = string2;
    }

    @Nullable
    public static ArenaConditionComparisonOperator a(String string) {
        for (ArenaConditionComparisonOperator arenaConditionComparisonOperator : ArenaConditionComparisonOperator.values()) {
            if (!arenaConditionComparisonOperator.usage.equals(string)) continue;
            return arenaConditionComparisonOperator;
        }
        return null;
    }

    public String getUsage() {
        return this.usage;
    }
}

