/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.bq;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.entity.Player;

public class g {
    private static Arena arena;

    public static void c(Arena arena) {
        g.arena = arena;
        g.I();
    }

    private static void I() {
        Player player22;
        Object object2;
        Object object322;
        Object object4;
        if (arena.a().r().size() < 2) {
            new bq("Less then 2 enabled teams?!").printStackTrace();
        }
        HashMap<Player, Team> hashMap = new HashMap<Player, Team>(arena.b());
        for (Player player22 : hashMap.keySet()) {
            object2 = (Team)((Object)hashMap.get((Object)player22));
            if (g.a(hashMap) == null) {
                new NullPointerException("t1").printStackTrace();
            }
            hashMap.put(player22, (Team)((Object)(object2 == null ? g.a(hashMap) : object2)));
        }
        player22 = new ArrayList();
        for (Object object322 : hashMap.values()) {
            if (player22.contains(object322)) continue;
            player22.add(object322);
        }
        object322 = g.a(hashMap, false);
        object2 = g.d(hashMap);
        int n2 = g.a(hashMap, object322).size();
        int n3 = g.a(hashMap, object2).size();
        double d2 = (double)(n3 - n2) / 2.0 + (double)n2;
        HashMap<Team, List<Player>> hashMap2 = new HashMap<Team, List<Player>>();
        for (Team object4 : arena.a().r()) {
            hashMap2.put(object4, g.a(hashMap, object4));
        }
        for (Map.Entry entry : hashMap.entrySet()) {
            object4 = (Player)entry.getKey();
            Object object3 = (Team)((Object)entry.getValue());
            int n4 = ((List)hashMap2.get(object3)).size();
            if ((double)n4 == d2 || (double)n4 == d2 || !((double)n4 > (double)((int)d2) + 0.5) || (double)(n4 - 1) != d2) continue;
            List list = (List)hashMap2.get(object3);
            Team team = g.b(hashMap2);
            List list2 = (List)hashMap2.get((Object)team);
            list.remove(object4);
            list2.add(object4);
            hashMap2.put((Team)((Object)object3), list);
            hashMap2.put(team, list2);
        }
        for (Map.Entry entry : hashMap2.entrySet()) {
            for (Object object4 : (List)entry.getValue()) {
                hashMap.put((Player)object4, (Team)((Object)entry.getKey()));
            }
        }
        for (Player player : arena.getPlayers()) {
            object4 = arena.a(player);
            if (hashMap.get((Object)player) == null) {
                new bq("Teamsortation failed: Player '" + player.getName() + "' isn't in a team").printStackTrace();
                continue;
            }
            if (object4 != null && hashMap.get((Object)player) == object4) continue;
            arena.b(player, (Team)((Object)hashMap.get((Object)player)));
        }
    }

    private static Team a(Map<Player, Team> map) {
        return g.c(map);
    }

    private static Team b(Map<Team, List<Player>> map) {
        HashMap<Team, Integer> hashMap = new HashMap<Team, Integer>();
        for (Team team : arena.a().r()) {
            hashMap.put(team, map.containsKey((Object)team) ? map.get((Object)team).size() : 0);
        }
        int n2 = Integer.MAX_VALUE;
        Object object = null;
        for (Map.Entry entry : hashMap.entrySet()) {
            if ((Integer)entry.getValue() >= n2) continue;
            n2 = (Integer)entry.getValue();
            object = (Team)((Object)entry.getKey());
        }
        return object;
    }

    private static Team c(Map<Player, Team> map) {
        return g.a(map, true);
    }

    private static Team a(Map<Player, Team> map, boolean bl2) {
        HashMap<Team, Integer> hashMap = new HashMap<Team, Integer>();
        for (Team object : arena.a().r()) {
            hashMap.put(object, 0);
        }
        for (Map.Entry entry : map.entrySet()) {
            Team team = (Team)((Object)entry.getValue());
            if (team == null) continue;
            hashMap.put(team, (Integer)hashMap.get((Object)team) + 1);
        }
        int n2 = Integer.MAX_VALUE;
        Object object = null;
        for (Map.Entry entry : hashMap.entrySet()) {
            if ((Integer)entry.getValue() >= n2) continue;
            n2 = (Integer)entry.getValue();
            object = (Team)((Object)entry.getKey());
        }
        return object;
    }

    private static Team d(Map<Player, Team> map) {
        HashMap<Team, Integer> hashMap = new HashMap<Team, Integer>();
        for (Team object : arena.a().r()) {
            hashMap.put(object, 0);
        }
        for (Map.Entry entry : map.entrySet()) {
            Team team = (Team)((Object)entry.getValue());
            hashMap.put(team, (Integer)hashMap.get((Object)team) + 1);
        }
        int n2 = Integer.MIN_VALUE;
        Object object = null;
        for (Map.Entry entry : hashMap.entrySet()) {
            if ((Integer)entry.getValue() <= n2) continue;
            n2 = (Integer)entry.getValue();
            object = (Team)((Object)entry.getKey());
        }
        return object;
    }

    private static List<Player> a(Map<Player, Team> map, Team team) {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (Map.Entry<Player, Team> entry : map.entrySet()) {
            if (entry.getValue() != team) continue;
            arrayList.add(entry.getKey());
        }
        return arrayList;
    }
}

