/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.event.ArenaOutOfTimeEvent;
import de.marcely.bedwars.bq;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.command.t;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.arena.e;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.arena.i;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class b {
    private final Arena arena;
    private int O = 0;
    private boolean L = false;
    private int P = 0;
    private int Q = 0;
    private Map<DropType, Integer> x = new HashMap<DropType, Integer>();

    public b(Arena arena) {
        this.arena = arena;
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void D() {
        Object object3;
        int n2;
        Object object2;
        s.a.start();
        ++this.O;
        if (this.arena.b() == ArenaStatus.f) {
            if (!this.x.isEmpty()) {
                for (Map.Entry<DropType, Integer> entry : this.x.entrySet()) {
                    DropType dropType = entry.getKey();
                    n2 = entry.getValue();
                    if ((double)(n2 + 1) >= dropType.getSpawnDelay() * 20.0) {
                        this.arena.b(dropType);
                        this.x.put(dropType, 0);
                        continue;
                    }
                    for (Arena.b b2 : this.arena.t.get(dropType)) {
                        if (n2 != (int)(dropType.getSpawnDelay() * 20.0 / b2.value)) continue;
                        this.arena.a(dropType, b2.c);
                    }
                    this.x.put(dropType, n2 + 1);
                }
            } else {
                for (DropType dropType : DropType.values()) {
                    this.x.put(dropType, 0);
                }
            }
            if (this.O % ConfigValue.performance.t == 0 && ConfigValue.border && this.arena.a() == RegenerationType.c) {
                for (Player player : this.arena.getPlayers()) {
                    de.marcely.bedwars.game.b.a(player, this.arena.getPosMin(), this.arena.getPosMax());
                }
                for (Player player : this.arena.getSpectators()) {
                    de.marcely.bedwars.game.b.a(player, this.arena.getPosMin(), this.arena.getPosMax());
                }
            }
            if (this.O % ConfigValue.performance.p == 0) {
                for (Map.Entry<de.marcely.bedwars.holographic.c<cJ>, DropType> entry : this.arena.k.entrySet()) {
                    de.marcely.bedwars.holographic.c<cJ> c2 = entry.getKey();
                    de.marcely.bedwars.holographic.c<? extends de.marcely.bedwars.holographic.b> c3 = c2.a().x().get(0);
                    DropType dropType = entry.getValue();
                    if (c2.v().size() < 1) continue;
                    object3 = c2.getLocation();
                    double d2 = dropType.getSpawnDelay();
                    double d3 = (d2 * 20.0 - (double)this.x.get(dropType).intValue()) / 20.0;
                    object2 = (object3.getYaw() > 360.0f ? object3.getYaw() - 360.0f : object3.getYaw()) + (float)ConfigValue.spawnerhologram_speed / 4.0f * (float)ConfigValue.performance.p;
                    object3.setYaw((float)object2);
                    double d4 = (d2 - 0.4 <= d3 ? d2 - d3 - 0.4 : 0.0) + c2.a().a().getY();
                    object3.setY(d4);
                    ((f)((Object)c3.a())).teleport((Location)object3);
                    if (this.O % 20 != 0) continue;
                    c2.a().a(de.marcely.bedwars.message.b.a(Language.ItemSpawner_Hologram_Title).a("spawnercolor", "" + (Object)dropType.getChatColor()).a("spawner", dropType.getName(true)).a("time", "" + (int)d3).f(null).split("\\\\n"));
                }
            }
        }
        if (this.O % (20 / ConfigValue.performance.s) == 0 && this.arena.b().F() && this.arena.a != null && !this.arena.a.isStopped()) {
            this.arena.a.H();
        }
        if (this.O == 20) {
            this.O = 0;
            if (this.arena.b() == ArenaStatus.e) {
                if (this.arena.j() >= this.arena.k()) {
                    if (this.arena.a == null) {
                        return;
                    }
                    int n3 = this.arena.a.getValue();
                    for (Player player : this.arena.getPlayers()) {
                        if (n3 <= 10) {
                            for (Player player2 : this.arena.getPlayers()) {
                                player2.getInventory().setItem(4, null);
                            }
                        }
                        if (n3 <= 30 && n3 % 30 == 0 || n3 == 20 || n3 == 10 || n3 <= 5 && n3 >= 1) {
                            s.a((CommandSender)player, this.arena.a() != RegenerationType.e || !this.arena.D ? de.marcely.bedwars.message.b.a(Language.Countdown_Counting).a("number", "" + n3) : de.marcely.bedwars.message.b.a(Language.Countdown_Voting_Counting).a("number", "" + n3));
                            Sound.COUNTDOWN_COUNTING.play(player);
                            if (Version.a().ag() && (this.arena.a() != RegenerationType.e || !this.arena.D)) {
                                switch (n3) {
                                    case 5: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_5, player, 100);
                                        break;
                                    }
                                    case 4: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_4, player, 100, 0);
                                        break;
                                    }
                                    case 3: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_3, player, 100, 0);
                                        break;
                                    }
                                    case 2: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_2, player, 100, 0);
                                        break;
                                    }
                                    case 1: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_1, player, 100, 0);
                                    }
                                }
                            }
                        }
                        if (n3 != 0 || !Version.a().ag() || this.arena.a() == RegenerationType.e && this.arena.D) continue;
                        Sound.COUNTDOWN_DONECOUNTING.play(player);
                        Version.a().a(ConfigValue.lobby_countdowntitle_0, de.marcely.bedwars.message.b.a(Language.Lobby_CountdownTitle_GoodLuck).f((CommandSender)player), player, 100, 0, 40);
                    }
                    if (n3 == 9 && ConfigValue.lobby_printmapinfo_enabled) {
                        void var2_14;
                        Object var2_11 = null;
                        if (this.arena.a() == RegenerationType.e) {
                            if (this.arena.I.size() != 1) return;
                            Arena arena = this.arena.I.get((int)0).arena;
                        } else {
                            Arena arena = this.arena;
                        }
                        ArrayList<String> arrayList = new ArrayList<String>();
                        for (String string : ConfigValue.lobby_printmapinfo_lines) {
                            arrayList.add(de.marcely.bedwars.message.b.a(string).c().b().a("arena", var2_14.getDisplayName()).a("madeby", var2_14.n()).a("teams", "" + var2_14.a().r().size()).a("players", "" + var2_14.getPlayers().size()).a("maxplayers", "" + var2_14.getMaxPlayers()).a("teamsize", "" + var2_14.getTeamPlayers()).a("^#", " ").f(null));
                        }
                        for (Player player : this.arena.getPlayers()) {
                            if (this.arena.a() == RegenerationType.e && this.arena.D) continue;
                            for (Object object3 : arrayList) {
                                player.sendMessage((String)object3);
                            }
                            if (!Version.a().ag()) continue;
                            Version.a().c(ConfigValue.lobby_countdowntitle_arena.replace("{arena}", var2_14.getDisplayName()).replace("{players}", "" + this.arena.getPlayers().size()).replace("{maxplayers}", "" + var2_14.getMaxPlayers()).replace("{author}", this.arena.getAuthor()), player);
                        }
                    }
                    if (n3 == ConfigValue.forcestart_time) {
                        for (Player player : this.arena.getPlayers()) {
                            this.arena.p(player);
                        }
                    }
                    if (n3 >= 15 && this.arena.j() / this.arena.getMaxPlayers() * 100 >= 70) {
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Lobby_Enough));
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", "15"));
                        this.arena.a.setValue(15);
                    }
                    if (this.arena.a != null && this.arena.a() == RegenerationType.e && !this.arena.D && this.arena.I.size() == 0 && this.arena.getPlayers().size() < this.arena.k()) {
                        this.arena.a.setValue(0);
                    }
                    if (n3 <= 0) {
                        if (this.arena.a() == RegenerationType.e) {
                            if (this.arena.D) {
                                if (this.arena.I.size() >= 1) {
                                    int n4 = this.arena.m() / 2;
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n4);
                                    this.arena.D = false;
                                    ArrayList<Arena.a> arrayList = new ArrayList<Arena.a>();
                                    for (Arena.a a2 : this.arena.I) {
                                        if (arrayList.size() != 0 && ((Arena.a)arrayList.get((int)0)).P.size() > a2.P.size()) continue;
                                        if (arrayList.size() > 0 && ((Arena.a)arrayList.get((int)0)).P.size() < a2.P.size()) {
                                            arrayList.clear();
                                        }
                                        arrayList.add(a2);
                                    }
                                    if (arrayList.size() >= 2) {
                                        Arena.a a3 = (Arena.a)arrayList.get(s.RAND.nextInt(arrayList.size()));
                                        arrayList.clear();
                                        arrayList.add(a3);
                                    }
                                    this.arena.I.clear();
                                    this.arena.I.add((Arena.a)arrayList.get(0));
                                    Arena arena = ((Arena.a)arrayList.get((int)0)).arena;
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_End).a("arena", arena.getDisplayName()));
                                    if (this.arena.getPlayers().size() >= arena.k()) {
                                        for (Player player : this.arena.getPlayers()) {
                                            player.closeInventory();
                                        }
                                        for (Arena arena2 : s.af) {
                                            arena2.E();
                                        }
                                        this.arena.a().b(new ArrayList<Team>(arena.a().r()));
                                        for (Player player : this.arena.getPlayers()) {
                                            this.arena.p(player);
                                        }
                                        this.arena.a.F();
                                    } else {
                                        this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_Recount_TooFewPlayers).a("number", "" + (arena.k() - this.arena.getPlayers().size())));
                                        this.arena.D = true;
                                        n4 = this.arena.m();
                                        this.arena.a.stop();
                                        this.arena.a = this.arena.a(n4);
                                        this.arena.I.clear();
                                        this.arena.E();
                                        for (Player player : this.arena.getPlayers()) {
                                            this.arena.p(player);
                                        }
                                    }
                                } else {
                                    int n5 = (int)((double)this.arena.m() * 1.5);
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n5);
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_Recount_NoArenaToVote));
                                    for (Player player : this.arena.getPlayers()) {
                                        this.arena.p(player);
                                    }
                                }
                            } else if (this.arena.I.size() == 1 && this.arena.I.get((int)0).arena.b() == ArenaStatus.e) {
                                if (this.arena.getPlayers().size() >= this.arena.I.get((int)0).arena.getMinPlayers()) {
                                    this.arena.a.stop();
                                    this.arena.a = null;
                                    Arena arena = this.arena.I.get((int)0).arena;
                                    ArrayList<Player> arrayList = new ArrayList<Player>(this.arena.getPlayers());
                                    for (Player player : arrayList) {
                                        object3 = this.arena.a(player);
                                        this.arena.a(KickReason.h, player);
                                        Arena.AddPlayerFail addPlayerFail = arena.a(player, (Team)((Object)object3), true);
                                        if (addPlayerFail == null) continue;
                                        new bq("Error occured when adding player: " + addPlayerFail.name()).printStackTrace();
                                    }
                                } else {
                                    this.arena.D = true;
                                    int n6 = (int)((double)this.arena.m() * 1.5);
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n6);
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.TooLess_Players));
                                    if (n3 == ConfigValue.forcestart_time) {
                                        for (Player player : this.arena.getPlayers()) {
                                            this.arena.p(player);
                                        }
                                    }
                                }
                            } else {
                                this.arena.I.clear();
                                this.arena.D = true;
                                this.arena.E();
                                if (n3 == ConfigValue.forcestart_time) {
                                    for (Player player : this.arena.getPlayers()) {
                                        this.arena.p(player);
                                    }
                                }
                            }
                        } else {
                            this.arena.D();
                            this.arena.a.stop();
                            this.arena.a = null;
                        }
                    }
                } else {
                    ++this.P;
                    if (this.P >= 21) {
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Lobby_Waiting).a("amount", "" + (this.arena.k() - this.arena.j())));
                        this.P = 0;
                    }
                }
            } else if (this.arena.b() == ArenaStatus.f) {
                if (ConfigValue.timer_enabled) {
                    --this.arena.N;
                    if (this.arena.N >= 0) {
                        for (Player player : this.arena.getPlayers()) {
                            this.arena.a.r(player);
                        }
                        for (Player player : this.arena.getSpectators()) {
                            this.arena.a.r(player);
                        }
                    } else {
                        ArenaOutOfTimeEvent arenaOutOfTimeEvent = new ArenaOutOfTimeEvent(this.arena);
                        Bukkit.getPluginManager().callEvent((Event)arenaOutOfTimeEvent);
                        if (arenaOutOfTimeEvent.getNewTime() <= 0) {
                            this.arena.b((Team)null);
                        } else {
                            this.arena.N = arenaOutOfTimeEvent.getNewTime();
                        }
                    }
                }
                ++this.Q;
                if (this.Q >= ConfigValue.performance.u) {
                    this.Q = 0;
                    for (Map.Entry<Team, List<Player>> entry : this.arena.s.entrySet()) {
                        entry.getValue().clear();
                        entry.getValue().addAll(de.marcely.bedwars.util.b.a(this.arena.a().a(entry.getKey()).toBukkit(this.arena.getWorld()), ConfigValue.upgrade_spawnsize));
                        for (Player player : de.marcely.bedwars.util.b.a(this.arena.a().a(entry.getKey()).toBukkit(this.arena.getWorld()), ConfigValue.upgrade_spawnsize)) {
                            if (entry.getValue().contains((Object)player)) continue;
                            entry.getValue().add(player);
                        }
                    }
                }
                for (Map.Entry<Team, List<Player>> entry : this.arena.s.entrySet()) {
                    Team team = entry.getKey();
                    n2 = this.arena.a(DefaultUpgradeType.SPAWN_HEALRANGE.getObj(), team);
                    int n7 = this.arena.a(DefaultUpgradeType.SPAWN_ENEMY_MININGFATIQUE.getObj(), team);
                    int n8 = this.arena.a(DefaultUpgradeType.SPAWN_ENEMY_TRAP.getObj(), team);
                    for (Player player : entry.getValue()) {
                        Team team2 = this.arena.a(player);
                        if (team2 == null) continue;
                        if (team == team2) {
                            if (n2 < 1) continue;
                            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 140, n2 - 1));
                            continue;
                        }
                        if (n7 >= 1) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 140, n7 - 1));
                        }
                        if (n8 < 1) continue;
                        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, n8, 0));
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, n8, 0));
                        this.arena.r.get((Object)team).a(DefaultUpgradeType.SPAWN_ENEMY_TRAP.getObj(), 0);
                        Sound.TRAP_CAUSE.play(player);
                        object2 = this.arena.a(team).iterator();
                        while (object2.hasNext()) {
                            Player player3 = (Player)object2.next();
                            s.a((CommandSender)player3, de.marcely.bedwars.message.b.a(Language.Trap));
                            Sound.TRAP_OWNER.play(player3);
                        }
                    }
                }
            } else if (this.arena.b() == ArenaStatus.h) {
                if (this.arena.a == null) {
                    this.arena.a = this.arena.a(ConfigValue.endlobby_countdown_time);
                    this.L = false;
                } else {
                    int n9 = this.arena.a.getValue();
                    if (ConfigValue.endlobby_show_kick_time) {
                        for (Player player : this.arena.getPlayers()) {
                            if (n9 <= 30 && n9 % 30 == 0 || n9 == 20 || n9 == 10 || n9 <= 5 && n9 >= 1) {
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.EndLobby_Counting).a("number", "" + n9));
                                Sound.COUNTDOWN_COUNTING.play(player);
                                continue;
                            }
                            if (n9 != 0) continue;
                            Sound.COUNTDOWN_DONECOUNTING.play(player);
                        }
                    }
                    if (n9 <= 0) {
                        this.arena.a(KickReason.e);
                    } else if (this.arena.getPlayers().size() == 0) {
                        this.arena.a(ArenaStatus.g);
                        this.arena.a.stop();
                        this.arena.a = null;
                    } else if ((double)n9 <= (double)ConfigValue.endlobby_countdown_time / 100.0 * 70.0 && !this.L) {
                        this.L = true;
                        if (ConfigValue.lobby_endstats_enabled) {
                            t t2 = (t)MBedwars.a.a("stats").a();
                            for (Player player : this.arena.getPlayers()) {
                                t2.a((CommandSender)player, null, null, new String[0]);
                            }
                        }
                    }
                }
            }
        }
        s.a.a(l.a.b, this.arena.getName());
    }

    public Arena getArena() {
        return this.arena;
    }
}

