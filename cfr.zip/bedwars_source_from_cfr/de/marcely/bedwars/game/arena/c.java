/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Score
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.ScoreboardManager
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.config.f;
import de.marcely.bedwars.config.j;
import de.marcely.bedwars.d;
import de.marcely.bedwars.du;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

public class c {
    private final Arena arena;
    private boolean enabled = true;

    public c(Arena arena) {
        this.arena = arena;
    }

    public void setEnabled(boolean bl2) {
        this.enabled = bl2;
    }

    public void E() {
        if (this.arena.b() == ArenaStatus.e) {
            this.F();
        } else {
            this.G();
        }
    }

    public void F() {
        if (!this.enabled) {
            return;
        }
        for (Player player : this.arena.getPlayers()) {
            this.q(player);
        }
    }

    public void q(final Player player) {
        if (!this.enabled || !ConfigValue.scoreboard_enabled) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> future = de.marcely.bedwars.game.stats.c.a(player);
        s.a(future, new Runnable(){

            /*
             * WARNING - void declaration
             */
            @Override
            public void run() {
                try {
                    Score score;
                    de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)future.get();
                    ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();
                    Scoreboard scoreboard = scoreboardManager.getNewScoreboard();
                    Objective objective = scoreboard.registerNewObjective("MBWLobby", "MBWLobby");
                    String string = "";
                    objective.setDisplayName(c.this.a(j.title, player, c2));
                    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
                    int n2 = c.this.arena.l() + j.o.size();
                    for (String string2 : j.o) {
                        score = null;
                        if (!string2.replace(" ", "").isEmpty()) {
                            void object;
                            if (ConfigValue.placeholderapi_enabled) {
                                for (du du2 : s.b.a(du.class)) {
                                    String string3 = du2.a(player, (String)object);
                                }
                            }
                            score = objective.getScore(c.this.a(object.replace("&", ""), player, c2));
                        } else {
                            string = String.valueOf(string) + " ";
                            score = objective.getScore(string);
                        }
                        score.setScore(n2);
                        --n2;
                    }
                    n2 = -1;
                    for (String string4 : j.p) {
                        score = null;
                        if (!string4.replace(" ", "").isEmpty()) {
                            void var7_14;
                            if (ConfigValue.placeholderapi_enabled) {
                                for (du du2 : s.b.a(du.class)) {
                                    String string5 = du2.a(player, (String)var7_14);
                                }
                            }
                            score = objective.getScore(c.this.a(var7_14.replace("&", ""), player, c2));
                        } else {
                            string = String.valueOf(string) + " ";
                            score = objective.getScore(string);
                        }
                        score.setScore(n2--);
                    }
                    if (!j.t.isEmpty()) {
                        for (Team team : c.this.arena.a().r()) {
                            score = objective.getScore(c.this.a(j.t.replace("{color}", "" + (Object)team.getChatColor()).replace("{name}", team.getName(true)).replace("{playersinteam}", "" + c.this.arena.a(team).size()), player, c2));
                            score.setScore(c.this.arena.a(team).size());
                        }
                    }
                    player.setScoreboard(scoreboard);
                    c.this.r(player);
                }
                catch (Exception exception) {
                    d.b("Scoreboard 'Lobby' issue:");
                    exception.printStackTrace();
                }
            }
        });
    }

    private String a(String string, Player player, de.marcely.bedwars.game.stats.c c2) {
        if (!this.enabled) {
            return string;
        }
        Arena arena = this.arena.a() == RegenerationType.e && !this.arena.D ? this.arena.I.get((int)0).arena : this.arena;
        return this.a(arena, string, player, c2);
    }

    public void r(Player player) {
        if (!this.enabled) {
            return;
        }
        Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard.getObjective("MBWIngame") != null) {
            int n2 = this.arena.N / 60;
            String string = String.valueOf(this.arena.N - n2 * 60);
            if (string.length() == 1) {
                string = "0" + string;
            }
            scoreboard.getObjective("MBWIngame").setDisplayName(f.title.replace("{countdown}", String.valueOf(n2) + ":" + string));
        }
    }

    public void s(final Player player) {
        if (!this.enabled || !ConfigValue.scoreboard_enabled) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> future = de.marcely.bedwars.game.stats.c.a(player);
        s.a(future, new Runnable(){

            /*
             * WARNING - void declaration
             */
            @Override
            public void run() {
                try {
                    Score score;
                    de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)future.get();
                    ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();
                    Scoreboard scoreboard = scoreboardManager.getNewScoreboard();
                    Objective objective = scoreboard.registerNewObjective("MBWIngame", "MBWIngame");
                    String string = "";
                    objective.setDisplayName(c.this.b(f.title, player, c2));
                    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
                    int n2 = c.this.arena.l() + f.o.size();
                    for (String string2 : f.o) {
                        score = null;
                        if (!string2.replace(" ", "").isEmpty()) {
                            void object;
                            if (ConfigValue.placeholderapi_enabled) {
                                for (du du2 : s.b.a(du.class)) {
                                    String string3 = du2.a(player, (String)object);
                                }
                            }
                            score = objective.getScore(c.this.b(object.replace("&", ""), player, c2));
                        } else {
                            string = String.valueOf(string) + " ";
                            score = objective.getScore(string);
                        }
                        score.setScore(n2--);
                    }
                    n2 = -1;
                    for (String string4 : f.p) {
                        score = null;
                        if (!string4.replace(" ", "").isEmpty()) {
                            void var7_14;
                            if (ConfigValue.placeholderapi_enabled) {
                                for (du du2 : s.b.a(du.class)) {
                                    String string5 = du2.a(player, (String)var7_14);
                                }
                            }
                            score = objective.getScore(c.this.b(var7_14.replace("&", ""), player, c2));
                        } else {
                            string = String.valueOf(string) + " ";
                            score = objective.getScore(string);
                        }
                        score.setScore(n2--);
                    }
                    if (!f.t.isEmpty()) {
                        for (Team team : c.this.arena.a().r()) {
                            du du2;
                            int n3 = c.this.arena.a(team).size();
                            if (!ConfigValue.scoreboard_ingame_display_emptyteams && n3 == 0) continue;
                            du2 = objective.getScore(c.this.b(f.t.replace("{color}", "" + (Object)team.getChatColor()).replace("{name}", team.getName(true)).replace("{playersinteam}", "" + n3).replace("{heart}", c.a(!c.this.arena.a().d(team))).replace("{firstletter}", team.m()), player, c2));
                            du2.setScore(c.this.arena.a(team).size());
                        }
                    }
                    player.setScoreboard(scoreboard);
                    c.a((c)c.this).a.r(player);
                }
                catch (Exception exception) {
                    d.b("Scoreboard 'Ingame' issue:");
                    exception.printStackTrace();
                }
            }
        });
    }

    private static String a(boolean bl2) {
        return bl2 ? ConfigValue.scoreboard_heart_alive : ConfigValue.scoreboard_heart_dead;
    }

    private String b(String string, Player player, de.marcely.bedwars.game.stats.c c2) {
        Team team2;
        if (!this.enabled) {
            return string;
        }
        String string2 = "";
        for (Team team2 : this.arena.a().r()) {
            string2 = !this.arena.a().a().contains((Object)team2) && this.arena.a(team2).size() >= 1 ? String.valueOf(string2) + ConfigValue.scoreboard_ingame_teamsleft.replace("{team}", team2.getName()).replace("{teamcolor}", "" + (Object)team2.getChatColor()) : String.valueOf(string2) + ConfigValue.scoreboard_ingame_teamsleft_dead.replace("{team}", team2.getName()).replace("{teamcolor}", "" + (Object)team2.getChatColor());
        }
        team2 = this.arena.a(player);
        de.marcely.bedwars.game.stats.c c3 = c2.b();
        String string3 = b.a(Language.Spectator).f((CommandSender)player);
        ChatColor chatColor = ChatColor.BOLD;
        String string4 = "?";
        if (team2 != null) {
            string3 = team2.getName();
            chatColor = team2.getChatColor();
            string4 = this.arena.a().a().contains((Object)team2) ? b.a(Language.Scoreboard_BedState_Destroyed).f((CommandSender)player) : b.a(Language.Scoreboard_BedState_Alive).f((CommandSender)player);
        }
        return this.a(this.arena, string, player, c2).replace("{teamsleft}", string2).replace("{team}", string3).replace("{teamcolor}", "" + (Object)chatColor).replace("{bedstate}", string4).replace("{gstats:kills}", "" + c3.getKills()).replace("{gstats:deaths}", "" + c3.getDeaths()).replace("{gstats:bedsdestroyed}", "" + c3.getBedsDestroyed()).replace("{gstats:kd}", "" + c3.b());
    }

    private String a(Arena arena, String string, Player player, de.marcely.bedwars.game.stats.c c2) {
        if (!this.enabled) {
            return string;
        }
        return string.replace("{arena}", arena.getDisplayName()).replace("{players}", "" + arena.j()).replace("{maxplayers}", "" + arena.getMaxPlayers()).replace("{teams}", "" + arena.a().r().size()).replace("{maxplayersinteam}", "" + arena.getTeamPlayers()).replace("{date}", s.u()).replace("{ip}", ConfigValue.ip_display).replace("{stats:rank}", "" + (c2.getRank() >= 1 ? "" + c2.getRank() : b.a(Language.Ranking_Unranked))).replace("{stats:wins}", "" + c2.getWins()).replace("{stats:loses}", "" + c2.getLoses()).replace("{stats:kills}", "" + c2.getKills()).replace("{stats:deaths}", "" + c2.getDeaths()).replace("{stats:bedsdestroyed}", "" + c2.getBedsDestroyed()).replace("{stats:roundsplayed}", "" + c2.getRoundsPlayed()).replace("{stats:playtime}", s.a(c2.getPlayTime())).replace("{stats:kd}", "" + c2.b()).replace("{stats:wl}", "" + c2.a()).replace("{server:onlineplayers}", "" + de.marcely.bedwars.util.b.getOnlinePlayers().size());
    }

    public void G() {
        if (!this.enabled) {
            return;
        }
        for (Player player : this.arena.getPlayers()) {
            this.s(player);
        }
        for (Player player : this.arena.getSpectators()) {
            this.s(player);
        }
    }

    public static void t(Player player) {
        if (!ConfigValue.scoreboard_enabled || ConfigValue.scoreboard_enabled && c.g(player)) {
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
    }

    public static boolean g(Player player) {
        if (player.getScoreboard() == null) {
            return false;
        }
        for (Objective objective : player.getScoreboard().getObjectives()) {
            if (!objective.getName().equals("MBWLobby") && !objective.getName().equals("MBWIngame")) continue;
            return true;
        }
        return false;
    }

    public Arena getArena() {
        return this.arena;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

}

