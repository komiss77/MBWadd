/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.game.arena.Flag;
import java.util.ArrayList;
import java.util.List;

public class f
extends Flag {
    private final a a;

    private f(String string, Object object, Flag.VarType varType, a a2) {
        super(string, varType, object);
        this.a = a2;
    }

    public a a() {
        return this.a;
    }

    /* synthetic */ f(String string, Object object, Flag.VarType varType, a a2, f f2) {
        this(string, object, varType, a2);
    }

    public static enum a {
        b("", Flag.VarType.a),
        c(2, Flag.VarType.b),
        d(false, Flag.VarType.d),
        e("Default Custom Name", Flag.VarType.a);
        
        private final Object f;
        private final Flag.VarType type;

        private a(Object object, Flag.VarType varType) {
            this.f = object;
            this.type = varType;
        }

        public String getName() {
            return this.name().replace("_", "");
        }

        public static List<Flag> p() {
            ArrayList<Flag> arrayList = new ArrayList<Flag>();
            for (a a2 : a.values()) {
                arrayList.add(new f(a2.getName(), a2.f, a2.type, a2, null));
            }
            return arrayList;
        }

        public static a a(String string) {
            for (a a2 : a.values()) {
                if (!a2.getName().equalsIgnoreCase(string)) continue;
                return a2;
            }
            return null;
        }

        public Object getDefaultValue() {
            return this.f;
        }

        public Flag.VarType getType() {
            return this.type;
        }
    }

}

