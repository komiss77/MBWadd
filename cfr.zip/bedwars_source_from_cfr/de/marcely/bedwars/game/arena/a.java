/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.location.XYZYP;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;

public class a {
    private final Arena arena;
    private boolean enabled = false;
    private final Map<Team, XYZYP> w = new HashMap<Team, XYZYP>();

    public a(Arena arena) {
        this.arena = arena;
    }

    @Nullable
    public Location a(Team team) {
        return this.w.get((Object)team).toBukkit(this.arena.getWorld());
    }

    public Arena getArena() {
        return this.arena;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean bl2) {
        this.enabled = bl2;
    }

    public Map<Team, XYZYP> c() {
        return this.w;
    }
}

