/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.bq;

public abstract class Flag
implements Cloneable {
    private final String name;
    private final VarType type;
    private Object value;

    public Flag(String string, VarType varType) {
        this(string, varType, null);
    }

    public Flag(String string, VarType varType, Object object) {
        this.name = string;
        this.type = varType;
        this.setValue(object);
    }

    public void setValue(Object object) {
        if (!this.type.isInstance(object)) {
            new bq("Value isn't instance of VarType").printStackTrace();
            return;
        }
        this.value = this.type != VarType.a ? object : object.toString();
    }

    public String getName() {
        return this.name;
    }

    public VarType getType() {
        return this.type;
    }

    public Object getValue() {
        return this.value;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class VarType
    extends Enum<VarType> {
        public static final /* enum */ VarType a = new VarType();
        public static final /* enum */ VarType b = new VarType();
        public static final /* enum */ VarType c = new VarType();
        public static final /* enum */ VarType d = new VarType();
        private static /* synthetic */ int[] m;
        private static final /* synthetic */ VarType[] a;

        static {
            a = new VarType[]{a, b, c, d};
        }

        public boolean isInstance(Object object) {
            switch (VarType.n()[this.ordinal()]) {
                case 2: {
                    return object instanceof Integer;
                }
                case 3: {
                    return object instanceof Double;
                }
                case 4: {
                    return object instanceof Boolean;
                }
                case 1: {
                    return true;
                }
            }
            return false;
        }

        public static VarType[] values() {
            VarType[] arrvarType = a;
            int n2 = arrvarType.length;
            VarType[] arrvarType2 = new VarType[n2];
            System.arraycopy(arrvarType, 0, arrvarType2, 0, n2);
            return arrvarType2;
        }

        public static VarType valueOf(String string) {
            return Enum.valueOf(VarType.class, string);
        }

        static /* synthetic */ int[] n() {
            if (m != null) {
                int[] arrn;
                return arrn;
            }
            int[] arrn = new int[VarType.values().length];
            try {
                arrn[VarType.d.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[VarType.c.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[VarType.b.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                arrn[VarType.a.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            m = arrn;
            return m;
        }
    }

}

