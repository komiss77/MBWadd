/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Chunk
 *  org.bukkit.Effect
 *  org.bukkit.FireworkEffect
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.command.CommandSender
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Firework
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.player.PlayerRespawnEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.inventory.meta.FireworkMeta
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.aD;
import de.marcely.bedwars.aV;
import de.marcely.bedwars.aX;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.ae;
import de.marcely.bedwars.api.Spawner;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.api.TeamColors;
import de.marcely.bedwars.api.event.ArenaDeleteEvent;
import de.marcely.bedwars.api.event.ArenaRegenerationStartEvent;
import de.marcely.bedwars.api.event.ArenaStatusUpdateEvent;
import de.marcely.bedwars.api.event.BedBreakEvent;
import de.marcely.bedwars.api.event.DropEvent;
import de.marcely.bedwars.api.event.PlayerJoinArenaEvent;
import de.marcely.bedwars.api.event.PlayerQuitArenaEvent;
import de.marcely.bedwars.api.event.PlayerRoundDeathEvent;
import de.marcely.bedwars.api.event.PlayerRoundRespawnEvent;
import de.marcely.bedwars.api.event.RoundEndEvent;
import de.marcely.bedwars.api.event.RoundStartEvent;
import de.marcely.bedwars.api.event.TeamEliminateEvent;
import de.marcely.bedwars.bK;
import de.marcely.bedwars.be;
import de.marcely.bedwars.bq;
import de.marcely.bedwars.by;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.cS;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.cW;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.dD;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import de.marcely.bedwars.dv;
import de.marcely.bedwars.dw;
import de.marcely.bedwars.dy;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.LobbyItem;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.CrashMessage;
import de.marcely.bedwars.game.arena.Flag;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.game.arena.e;
import de.marcely.bedwars.game.arena.f;
import de.marcely.bedwars.game.arena.g;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.game.arena.i;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.location.XYZD;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.game.regeneration.c;
import de.marcely.bedwars.game.shop.BuyGroup;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.game.shop.ShopProduct;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import de.marcely.bedwars.game.shop.upgrade.Upgrade;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.j;
import de.marcely.bedwars.s;
import de.marcely.bedwars.t;
import de.marcely.bedwars.u;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.v;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.w;
import de.marcely.bedwars.x;
import de.marcely.bedwars.y;
import de.marcely.bedwars.z;
import de.marcely.configmanager2.MultiKeyMap;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.annotation.Nullable;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Chunk;
import org.bukkit.Effect;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Arena
implements de.marcely.bedwars.api.Arena {
    public XYZ a;
    public XYZ b;
    private String name;
    private de.marcely.bedwars.game.arena.b a;
    private h b;
    private int e;
    private World world;
    public String C;
    private Location b;
    public String D;
    private ItemStack icon = new ItemStack(Material.CLAY_BALL, 1);
    private ArenaStatus b;
    private XYZYP a;
    private final de.marcely.bedwars.game.arena.a a;
    private boolean B = true;
    private RegenerationType b = RegenerationType.c;
    public de.marcely.bedwars.game.regeneration.a a;
    public e a;
    public int N;
    public boolean C = false;
    public c a;
    private MultiKeyMap<DropType, XYZ> a = new c(this);
    public List<Location> H = new ArrayList<Location>();
    public Map<de.marcely.bedwars.holographic.c<cJ>, DropType> k = new HashMap<de.marcely.bedwars.holographic.c<cJ>, DropType>();
    public Map<Player, Team> l = new HashMap<Player, Team>();
    public Map<Player, Long> m = new HashMap<Player, Long>();
    private List<Flag> flags = f.a.p();
    private long f = 0L;
    public Map<String, Player> n = new HashMap<String, Player>();
    public Map<String, Player> o = new HashMap<String, Player>();
    public boolean D = true;
    public List<a> I = new ArrayList<a>();
    private List<d> J = new ArrayList<d>();
    public Map<Player, de.marcely.bedwars.game.a> p = new HashMap<Player, de.marcely.bedwars.game.a>();
    public Map<Team, de.marcely.bedwars.holographic.c<cJ>> q = new HashMap<Team, de.marcely.bedwars.holographic.c<cJ>>();
    public Map<Team, i> r = new HashMap<Team, i>();
    public Map<Team, List<Player>> s = new HashMap<Team, List<Player>>();
    public Map<DropType, List<b>> t = new HashMap<DropType, List<b>>();
    private List<String> K = new ArrayList<String>();
    public List<String> L = new ArrayList<String>();
    private List<dy> M = new ArrayList<dy>();
    public Map<Player, List<ShopItem>> u = new HashMap<Player, List<ShopItem>>();
    public Map<Team, Map<BuyGroup, Integer>> v = new HashMap<Team, Map<BuyGroup, Integer>>();
    public List<by> N = (int)new ArrayList();
    public boolean E = false;
    private HashMap<Player, List<Player>> e = (int)new HashMap();
    private static /* synthetic */ int[] j;

    public Arena() {
        this.a.setEnabled(true);
    }

    public int j() {
        return this.l.size();
    }

    @Override
    public int getTeamPlayers() {
        return this.e;
    }

    public ArenaStatus b() {
        return this.b;
    }

    public h a() {
        return this.b;
    }

    public MultiKeyMap<DropType, XYZ> a() {
        return this.a;
    }

    public List<XYZ> a(DropType dropType) {
        ArrayList<XYZ> arrayList = new ArrayList<XYZ>();
        for (Map.Entry entry : ((MultiKeyMap)((Object)this.a)).entrySet()) {
            if (!((DropType)entry.getKey()).equals(dropType)) continue;
            arrayList.add((XYZ)entry.getValue());
        }
        return arrayList;
    }

    @Override
    public ItemStack getIcon() {
        ItemStack itemStack = this.icon != null ? this.icon.clone() : new ItemStack(Material.CLAY_BALL);
        de.marcely.bedwars.util.i.a(itemStack, (Object)ChatColor.WHITE + this.getDisplayName());
        return itemStack;
    }

    public String n() {
        return (String)this.a(f.a.b).getValue();
    }

    public String[] b() {
        return this.n().split(", ");
    }

    public Map<Player, Team> b() {
        return this.l;
    }

    @Override
    public List<Player> getPlayers() {
        return new ArrayList<Player>(this.l.keySet());
    }

    @Override
    public int getMinPlayers() {
        return (Integer)this.a(f.a.c).getValue();
    }

    public int k() {
        if (this.a() == RegenerationType.e && !this.D && this.I.size() == 1) {
            return this.I.get((int)0).arena.getMinPlayers();
        }
        return this.getMinPlayers();
    }

    public int l() {
        if (this.a() == RegenerationType.e && !this.D && this.I.size() == 1) {
            return this.I.get((int)0).arena.getTeamPlayers();
        }
        return this.getTeamPlayers();
    }

    @Override
    public int getMaxPlayers() {
        return this.a() != RegenerationType.e ? this.getTeamPlayers() * this.a().r().size() : this.getTeamPlayers();
    }

    public RegenerationType a() {
        return this.b;
    }

    public double a() {
        if (this.b == RegenerationType.c) {
            double d2 = this.getPosMax().getX() - this.getPosMin().getX();
            double d3 = this.getPosMax().getY() - this.getPosMin().getY();
            double d4 = this.getPosMax().getZ() - this.getPosMin().getZ();
            return d2 * d3 * d4 / (double)(1000 * ConfigValue.regeneration_speed_ms);
        }
        if (this.b == RegenerationType.d) {
            return this.world != null ? (double)(this.world.getLoadedChunks().length / 250) : Double.NaN;
        }
        return Double.NaN;
    }

    public void a(XYZ xYZ) {
        this.a = xYZ;
    }

    public void b(XYZ xYZ) {
        this.b = xYZ;
    }

    @Override
    public void setName(String string) {
        this.name = string;
        if (MBedwars.d()) {
            this.a(new w(this, string));
        }
        de.marcely.bedwars.util.s.c(this, d.a.g);
    }

    public void a(RegenerationType regenerationType) {
        this.b = regenerationType;
    }

    @Override
    public void setTeamPlayers(int n2) {
        this.e = n2;
        if (MBedwars.d()) {
            this.a(new v(this, n2 * this.a().r().size()));
            this.a(new z(this, this.a().r().size(), n2));
        }
    }

    @Override
    public void setWorld(World world) {
        this.world = world;
        this.C = world.getName();
    }

    @Override
    public void setLobby(Location location) {
        this.b = location;
        this.D = location != null && location.getWorld() != null ? location.getWorld().getName() : null;
    }

    public void setIcon(ItemStack itemStack) {
        this.icon = itemStack;
        de.marcely.bedwars.util.s.c(this, d.a.f);
        if (MBedwars.d()) {
            this.a(new t(this, itemStack));
        }
    }

    public void v(String string) {
        this.a(f.a.b).setValue(string);
        if (MBedwars.d()) {
            this.a(new u(this, string));
        }
    }

    public boolean A() {
        return this.f + 180000L > System.currentTimeMillis();
    }

    public void a(ArenaStatus arenaStatus) {
        this.a(arenaStatus, false);
    }

    public void a(ArenaStatus arenaStatus, boolean bl2) {
        if (Thread.currentThread() != de.marcely.bedwars.util.s.a) {
            new de.marcely.bedwars.game.arena.Arena$1(true, arenaStatus, bl2);
            return;
        }
        if (!bl2) {
            if (this.b == ArenaStatus.f && arenaStatus != ArenaStatus.f) {
                for (de.marcely.bedwars.holographic.c object : this.k.keySet()) {
                    object.remove();
                }
                for (de.marcely.bedwars.holographic.c c2 : this.q.values()) {
                    c2.remove();
                }
                this.k.clear();
                this.q.clear();
                this.K.clear();
                this.u.clear();
            }
            if (arenaStatus == ArenaStatus.f) {
                for (de.marcely.bedwars.game.a a2 : this.p.values()) {
                    a2.setAnimated(false);
                    a2.refresh();
                }
            }
            if (arenaStatus == ArenaStatus.g && MBedwars.a().isTaskable()) {
                if (ConfigValue.restart_oncearenaend && (this.b == ArenaStatus.f || this.b == ArenaStatus.h)) {
                    Bukkit.shutdown();
                } else {
                    this.b((CommandSender)null);
                }
            } else if (this.B()) {
                this.a.cancel();
            }
            if (arenaStatus == ArenaStatus.d) {
                this.n.clear();
            }
        }
        if (this.b != arenaStatus) {
            Bukkit.getPluginManager().callEvent((Event)new ArenaStatusUpdateEvent(this, de.marcely.bedwars.api.ArenaStatus.fromNMS(this.b), de.marcely.bedwars.api.ArenaStatus.fromNMS(arenaStatus)));
        }
        this.b = arenaStatus;
        de.marcely.bedwars.util.s.c(this, d.a.e);
        de.marcely.bedwars.util.s.aj();
        de.marcely.bedwars.util.s.g(this);
        aX.t();
        if (MBedwars.d()) {
            this.a(new y(this, arenaStatus));
        }
    }

    @Override
    public void setMinPlayers(int n2) {
        this.a(f.a.c).setValue(n2);
    }

    @Nullable
    public AddPlayerFail a(Player player, Team team) {
        return this.a(player, team, false);
    }

    @Nullable
    public AddPlayerFail a(final Player player, Team team, boolean bl2) {
        if (de.marcely.bedwars.util.s.a(player) != null || cA.E.containsKey((Object)player)) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.b)));
            return AddPlayerFail.b;
        }
        if (this.j() >= this.getMaxPlayers()) {
            if (de.marcely.bedwars.util.s.hasPermission((CommandSender)player, Permission.JoinFull) && this.a(Permission.JoinFull) != null) {
                this.a(KickReason.c, this.a(Permission.JoinFull));
            } else {
                Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.a)));
                return AddPlayerFail.a;
            }
        }
        if (this.a() == RegenerationType.e && !ConfigValue.arenavoting_enabled && !bl2) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.d)));
            return AddPlayerFail.d;
        }
        if (this.a() != RegenerationType.e && ConfigValue.arenavoting_enabled && !bl2) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.c)));
            return AddPlayerFail.c;
        }
        PlayerJoinArenaEvent playerJoinArenaEvent = new PlayerJoinArenaEvent(player, this, null);
        Bukkit.getPluginManager().callEvent((Event)playerJoinArenaEvent);
        if (playerJoinArenaEvent.isCancelled()) {
            return AddPlayerFail.e;
        }
        player.closeInventory();
        de.marcely.bedwars.util.s.b.A(player);
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
        player.setGameMode(GameMode.ADVENTURE);
        player.getInventory().setHeldItemSlot(4);
        new BukkitRunnable(){

            public void run() {
                Arena.this.a(de.marcely.bedwars.message.b.a(Language.JoinMessage).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("players", "" + (Arena.this.getPlayers().size() + 1)).a("maxplayers", "" + Arena.this.getMaxPlayers()).a("arena", Arena.this.getDisplayName()));
                if (ConfigValue.player_color) {
                    for (Team team : Arena.this.a().r()) {
                        Version.a().a(Arena.this.a(team), Arena.this.getPlayers(), team.getChatColor());
                    }
                }
            }
        }.runTaskLater((Plugin)MBedwars.a, 10L);
        if (ConfigValue.tab_removenonplayers) {
            this.k(player);
        }
        this.l.put(player, team);
        this.m.put(player, System.currentTimeMillis());
        de.marcely.bedwars.util.s.l.put(player, this);
        if (this.a != null) {
            this.a.getPlayers().add(player);
        }
        this.d(player, team);
        this.a(player, this.getLobby().clone());
        this.c(player, true);
        this.C();
        if (ConfigValue.tab_removenonplayers) {
            for (Player a22 : this.getPlayers()) {
                this.l(a22);
            }
        }
        de.marcely.bedwars.game.a a2 = new de.marcely.bedwars.game.a(Arrays.asList(new Player[]{player}));
        a2.setAnimated(true);
        if (ConfigValue.actionbar_enabled) {
            a2.run();
        }
        this.p.put(player, a2);
        aX.t();
        if (MBedwars.d()) {
            this.a(new x(this, this.getPlayers().size()));
        }
        if (this.j() == this.k()) {
            int n2 = this.m();
            this.a = this.a(n2);
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Start));
            this.w("");
            for (Player player2 : this.getPlayers()) {
                this.p(player2);
            }
        } else {
            this.p(player);
            if (this.j() < this.k()) {
                this.c(de.marcely.bedwars.message.b.a(Language.Lobby_Waiting).a("amount", "" + (this.k() - this.getPlayers().size())).f((CommandSender)player), 300);
            }
        }
        if (this.j() == 1 && this.a() == RegenerationType.e) {
            this.D = true;
            this.E();
            if (this.D && this.a().r().size() >= 1) {
                this.a().r().clear();
            }
        }
        de.marcely.bedwars.util.s.c(this, d.a.c);
        this.a.E();
        new BukkitRunnable(){
            double y = 0.1;
            boolean K = true;

            public void run() {
                if (this.K) {
                    if (this.y < 1.7) {
                        this.y += Math.sin(this.y / 1.7);
                    } else {
                        this.K = false;
                    }
                } else if (this.y > 0.1) {
                    this.y -= this.y / 5.0;
                } else {
                    this.cancel();
                }
                for (Location location : de.marcely.bedwars.util.s.b(player.getLocation().add(0.0, this.y, 0.0), 0.6, 5)) {
                    ae.b.a(location.getWorld(), location, 1, 1, 0.0f, 1.0f, 1.0f, 1.0f, 0, 10);
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 2L, 3L);
        de.marcely.bedwars.util.s.g(this);
        return null;
    }

    public Player a(Permission permission) {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        arrayList.addAll(this.getPlayers());
        Collections.rotate(arrayList, arrayList.size());
        for (Player player : arrayList) {
            if (de.marcely.bedwars.util.s.hasPermission((CommandSender)player, permission)) continue;
            return player;
        }
        return null;
    }

    public boolean a(KickReason kickReason, final Player player) {
        a object3;
        Object object2;
        if (!this.l.containsKey((Object)player)) {
            return false;
        }
        Team team = this.a(player);
        if (this.a() == RegenerationType.e && (object3 = this.a(player)) != null) {
            object3.P.remove((Object)player);
            for (Object object2 : new ArrayList(aV.h.get(this))) {
                aV.b(this, (Player)object2);
            }
        }
        if (this.b() == ArenaStatus.f) {
            aD.f.remove((Object)player);
        }
        if (cA.E.containsKey((Object)player)) {
            cA.a(player, cD.e);
        }
        for (Player player2 : this.getPlayers()) {
            player2.showPlayer(player);
            player.showPlayer(player2);
        }
        final List<Player> list = this.getSpectators();
        for (Object object2 : list) {
            Version.a().a((Player)object2, Arrays.asList(new Player[]{player}), player.getGameMode());
        }
        if (MBedwars.a().isTaskable()) {
            new BukkitRunnable(){

                public void run() {
                    for (Player player2 : list) {
                        Version.a().a(player2, Arrays.asList(new Player[]{player}), player.getGameMode());
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 20L);
        }
        object2 = this.a(new Player[]{player});
        if (this.b() == ArenaStatus.f) {
            if (this.b.a().contains((Object)team) && System.currentTimeMillis() <= this.b.a(team) + 10000L) {
                de.marcely.bedwars.util.s.a(player, Achievement.A);
            }
            if (kickReason == KickReason.d) {
                if (ConfigValue.spectator_autojoin && object2.size() > 1) {
                    cA.a(player, this, SpectateReason.LOOSE);
                    if (ConfigValue.spectator_joinmessage) {
                        de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Spectator_HowToQuit));
                    }
                }
            } else {
                this.a(player, kickReason);
                this.b(player, true);
            }
            if (this.a(team).size() == 0) {
                this.b.a(team, true);
                this.b.a(team).toBukkit(this.getWorld()).getBlock().setType(Material.AIR);
                if (this.q.containsKey((Object)team)) {
                    de.marcely.bedwars.holographic.c<cJ> c2 = this.q.get((Object)team);
                    c2.remove();
                    this.q.remove((Object)team);
                }
                this.a(Sound.TEAM_ELIMINATED);
                Bukkit.getPluginManager().callEvent((Event)new TeamEliminateEvent(this, de.marcely.bedwars.api.Team.fromInternal(team), player, object2.size() <= 1));
            }
            if (object2.size() == 1) {
                this.b((Team)((Object)object2.get(0)));
            } else if (object2.size() == 0) {
                this.b((Team)null);
            }
        } else if (this.b() == ArenaStatus.e) {
            if (this.a != null && this.l.size() <= this.k()) {
                this.a.stop();
                this.a = null;
                for (Player player3 : this.getPlayers()) {
                    player3.setLevel(0);
                    player3.setExp(0.0f);
                }
                this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Stop));
            }
            this.a(player, kickReason);
            for (Player player4 : this.getPlayers()) {
                this.p(player4);
            }
        } else if (this.b() == ArenaStatus.h) {
            this.a(player, kickReason);
            if (this.getPlayers().size() == 0) {
                if (this.a != null) {
                    this.a.stop();
                    this.a = null;
                }
                this.a(ArenaStatus.g);
            }
        }
        if (kickReason != KickReason.h) {
            for (int i2 = 0; i2 < 6; ++i2) {
                ae.c.a(player.getWorld(), player.getLocation().add((double)de.marcely.bedwars.util.s.RAND.nextInt(6) / 10.0, (double)de.marcely.bedwars.util.s.RAND.nextInt(8) / 10.0 * (double)(de.marcely.bedwars.util.s.RAND.nextInt(2) + 1), (double)de.marcely.bedwars.util.s.RAND.nextInt(6) / 10.0), de.marcely.bedwars.util.s.RAND.nextInt(10));
            }
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 1.4, 0.4), 0);
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 0.6, 0.4), 0);
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 0.1, 0.4), 0);
            Bukkit.getPluginManager().callEvent((Event)new PlayerQuitArenaEvent(player, this, de.marcely.bedwars.api.KickReason.fromInternal(kickReason), de.marcely.bedwars.api.Team.fromInternal(team)));
        }
        return true;
    }

    private void a(Player player, KickReason kickReason) {
        if (ConfigValue.player_color && this.l.get((Object)player) != null) {
            Version.a().a(player, this.getPlayers(), this.l.get((Object)player).getChatColor());
            Version.a().a(player, this.getSpectators(), this.l.get((Object)player).getChatColor());
        }
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
        this.c(player, false);
        this.a(player, null, false);
        this.l.remove((Object)player);
        if (this.b() == ArenaStatus.e) {
            this.m.remove((Object)player);
        }
        de.marcely.bedwars.util.s.l.remove((Object)player);
        this.C();
        de.marcely.bedwars.game.a a2 = this.p.get((Object)player);
        a2.stop();
        this.p.remove((Object)player);
        this.a(de.marcely.bedwars.message.b.a(Language.LeaveMessage).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("players", "" + this.getPlayers().size()).a("maxplayers", "" + this.getMaxPlayers()).a("arena", this.getDisplayName()));
        if (this.a != null) {
            this.a.getPlayers().remove((Object)player);
        }
        c.t(player);
        aX.t();
        de.marcely.bedwars.util.s.g(this);
        if (MBedwars.d()) {
            this.a(new x(this, this.getPlayers().size()));
        }
        if (ConfigValue.player_color) {
            for (Map.Entry<Player, Team> player2 : this.l.entrySet()) {
                if (player2.getValue() == null) continue;
                Version.a().a(player2.getKey(), Arrays.asList(new Player[]{player}), player2.getValue().getChatColor());
            }
        }
        if (ConfigValue.tab_removenonplayers) {
            this.m(player);
            for (Player player2 : this.getPlayers()) {
                this.l(player2);
            }
        }
        de.marcely.bedwars.util.s.c(this, d.a.d);
        this.a.E();
        if (kickReason != KickReason.h) {
            de.marcely.bedwars.util.s.b(player, this);
            de.marcely.bedwars.util.s.b.z(player);
        }
    }

    @Override
    public void broadcast(String string) {
        for (Player player : this.getPlayers()) {
            player.sendMessage(string);
        }
        for (Player player : this.getSpectators()) {
            player.sendMessage(string);
        }
    }

    public void a(Language language) {
        this.a(de.marcely.bedwars.message.b.a(language));
    }

    public void a(de.marcely.bedwars.message.b b2) {
        de.marcely.bedwars.util.t.c(b2);
        for (Player player : this.getPlayers()) {
            de.marcely.bedwars.util.s.a((CommandSender)player, b2, false);
        }
        for (Player player : this.getSpectators()) {
            de.marcely.bedwars.util.s.a((CommandSender)player, b2, false);
        }
        b2.X();
    }

    public void a(String string, Player player) {
        player.sendMessage(string);
        this.broadcast(string);
    }

    @Deprecated
    @Override
    public void kickAllPlayers() {
        this.a(KickReason.c);
    }

    @Deprecated
    public void a(KickReason kickReason) {
        for (Player player : this.getPlayers()) {
            this.a(kickReason, player);
        }
    }

    public boolean b(@Nullable CommandSender commandSender) {
        if (this.getWorld() == null) {
            if (commandSender != null) {
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Problem_Arena_World).a("arena", commandSender.getName()));
                commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.FixProblemWith).f(commandSender)) + "/bw arena setworld " + this.getName());
            }
            return false;
        }
        ArenaRegenerationStartEvent arenaRegenerationStartEvent = new ArenaRegenerationStartEvent(this, commandSender, ConfigValue.regeneration_speed_ms, ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.REGENERATE);
        Bukkit.getPluginManager().callEvent((Event)arenaRegenerationStartEvent);
        if (arenaRegenerationStartEvent.getResult() == ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.REGENERATE) {
            if (!this.B()) {
                this.a(ArenaStatus.g, true);
                this.a = this.a().a(this, commandSender);
                return this.a.run();
            }
            this.C();
            this.b(commandSender);
            return false;
        }
        return arenaRegenerationStartEvent.getResult() == ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.DO_NOT_REGENERATE;
    }

    public boolean B() {
        return this.a != null && this.a.isRunning();
    }

    private boolean C() {
        if (this.B()) {
            boolean bl2 = this.a.cancel();
            if (bl2) {
                this.a(ArenaStatus.d, true);
            }
            return bl2;
        }
        return false;
    }

    public void a(DropType dropType, XYZ xYZ) {
        Location location;
        if (dropType.isDisabledForRound()) {
            return;
        }
        if (ConfigValue.itemspawner_effect && dropType.getEffect() != null) {
            for (int i2 = 0; i2 < de.marcely.bedwars.util.s.RAND.nextInt(2) + 2; ++i2) {
                location = xYZ.toBukkit(this.getWorld()).add(de.marcely.bedwars.util.s.RAND.nextDouble(), de.marcely.bedwars.util.s.RAND.nextDouble(), de.marcely.bedwars.util.s.RAND.nextDouble());
                this.getWorld().playEffect(location, dropType.getEffect(), 0);
            }
        }
        if (ConfigValue.itemspawner_sound && dropType.getSound() != null) {
            this.getWorld().playSound(xYZ.toBukkit(this.getWorld()), dropType.getSound(), 1.0f, 1.0f);
        }
        if (dropType.getActualItemstack() != null && dropType.getActualItemstack().getType() != null && dropType.getActualItemstack().getType() != Material.AIR) {
            Location location2 = xYZ.toBukkit(this.getWorld()).add(0.5, 0.0, 0.5);
            if (dropType.getSpawnRadius() > 0) {
                location2.add((double)(de.marcely.bedwars.util.s.RAND.nextInt(dropType.getSpawnRadius() + 1) * 2 - dropType.getSpawnRadius()), 0.0, (double)(de.marcely.bedwars.util.s.RAND.nextInt(dropType.getSpawnRadius() + 1) * 2 - dropType.getSpawnRadius()));
            }
            location = this.getWorld().dropItem(location2, dropType.getActualItemstack());
            if (dropType.isTranquil()) {
                de.marcely.bedwars.util.s.a((Entity)location, new Vector(0.0, 0.3, 0.0));
            }
            ItemStack itemStack = de.marcely.bedwars.util.i.a(location.getItemStack(), (Object)dropType.getChatColor() + dropType.getName());
            Location location3 = this.a(location2);
            boolean bl2 = location3 != null;
            int n2 = (int)((60.0 - dropType.getSpawnDelay() * 20.0) / 2.0);
            if (n2 < 1) {
                n2 = 1;
            } else if (n2 >= ConfigValue.performance.q) {
                n2 = ConfigValue.performance.q;
            }
            if (de.marcely.bedwars.util.s.RAND.nextInt(n2) == 0) {
                int n3 = 0;
                int n4 = 64;
                for (Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(location2, 8.0, 8.0, 8.0)) {
                    if (entity.getType() != EntityType.DROPPED_ITEM) continue;
                    ++n3;
                }
                if (n3 < 64 && bl2) {
                    this.H.remove((Object)location3);
                } else if (n3 > 64 && !bl2) {
                    this.H.add(location2);
                }
            }
            if (!dropType.isMerging() && !bl2) {
                ItemMeta itemMeta = itemStack.getItemMeta();
                itemMeta.setLore(Arrays.asList("" + de.marcely.bedwars.util.s.RAND.nextInt()));
                itemStack.setItemMeta(itemMeta);
            }
            location.setItemStack(itemStack);
        }
        if (dropType.getCustomSpawner() != null) {
            dropType.getCustomSpawner().onDropEvent(new DropEvent(dropType, xYZ.toBukkit(this.getWorld())));
        }
    }

    public void b(DropType dropType) {
        for (XYZ xYZ : this.a(dropType)) {
            this.a(dropType, xYZ);
        }
    }

    public Location a(Location location) {
        for (Location location2 : this.H) {
            if (!(location2.distance(location) <= 8.0)) continue;
            return location2;
        }
        return null;
    }

    public int a(Location location) {
        int n2 = 0;
        for (Map.Entry entry : ((MultiKeyMap)((Object)this.a)).entrySet()) {
            if (!((XYZ)entry.getValue()).equals(XYZ.valueOf(location))) continue;
            ((MultiKeyMap)((Object)this.a)).remove((DropType)entry.getKey(), (XYZ)entry.getValue());
            ++n2;
        }
        return n2;
    }

    public boolean D() {
        if (this.b() == ArenaStatus.e && this.j() >= this.k()) {
            reference var3_21;
            this.H.clear();
            if (ConfigValue.teambalance) {
                g.c(this);
            }
            this.a(de.marcely.bedwars.message.b.a(Language.Start_Round));
            for (Player object3 : this.getPlayers()) {
                var3_21 = de.marcely.bedwars.game.stats.c.a(object3);
                de.marcely.bedwars.util.s.a(var3_21, new Runnable(){

                    @Override
                    public void run() {
                        try {
                            de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)var3_21.get();
                            c2.setRoundsPlayed(c2.getRoundsPlayed() + 1);
                            c2.save();
                            c2.O();
                        }
                        catch (InterruptedException | ExecutionException exception) {
                            exception.printStackTrace();
                        }
                    }
                });
            }
            this.r.clear();
            this.s.clear();
            this.t.clear();
            for (DropType dropType : DropType.values()) {
                this.t.put(dropType, new ArrayList());
            }
            for (Team team : this.a().r()) {
                this.r.put(team, new i(this, team));
                this.s.put(team, new ArrayList());
                if (de.marcely.bedwars.util.s.X.size() < 1) continue;
                this.v.put(team, new HashMap());
            }
            this.L.clear();
            for (Chunk chunk : this.getWorld().getLoadedChunks()) {
                for (Entity entity : chunk.getEntities()) {
                    if (entity.getType() != EntityType.DROPPED_ITEM || !this.isInside(entity.getLocation())) continue;
                    entity.remove();
                }
                this.L.add(String.valueOf(chunk.getX()) + "." + chunk.getZ());
            }
            this.u.clear();
            if (ConfigValue.timer_enabled) {
                this.N = ConfigValue.timer;
            }
            for (Player player : this.getPlayers()) {
                this.u.put(player, new ArrayList());
                if (this.a(player) == null) {
                    this.b(player, this.a().r().get(de.marcely.bedwars.util.s.RAND.nextInt(this.a().r().size())));
                    new bq("Player '" + player.getName() + "' isn't in a team?!").printStackTrace();
                }
                this.a(player, this.a().a(this.a(player)).toBukkit(this.getWorld()));
                de.marcely.bedwars.util.s.M(player);
                if (!ConfigValue.giveitems_on_enabled) continue;
                Team team = this.a(player);
                for (ItemStack itemStack : ConfigValue.giveitems_on_roundstart) {
                    player.getInventory().addItem(new ItemStack[]{de.marcely.bedwars.util.i.a(itemStack, team)});
                }
                for (ItemStack itemStack : ConfigValue.giveitems_on_roundstart_armor) {
                    if (de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(itemStack, team), true)) continue;
                    de.marcely.bedwars.d.b("'" + (Object)itemStack.getType() + " isn't a valid armor (Config: giveitems-on-roundstart-armor)");
                }
            }
            for (Map.Entry entry : ((MultiKeyMap)((Object)this.a)).entrySet()) {
                Location location;
                ((DropType)entry.getKey()).setDisabledForRound(false);
                if (((DropType)entry.getKey()).getHologram() == null) continue;
                Location location2 = location.add(0.5, (double)((location = ((XYZ)entry.getValue()).toBukkit(this.getWorld()).clone()).clone().add(0.5, 1.0, 0.5).getBlock().getType() != Material.AIR ? -1.0f : ConfigValue.spawnerhologram_height), 0.5);
                Object[] arrobject = de.marcely.bedwars.message.b.a(Language.ItemSpawner_Hologram_Title).f(null).split("\\\\n");
                Arrays.fill(arrobject, " ");
                de.marcely.bedwars.holographic.c<cJ> c2 = de.marcely.bedwars.holographic.c.a(cJ.class, location2, new cF().c(false).b(false).a((String[])arrobject));
                de.marcely.bedwars.holographic.c<? extends de.marcely.bedwars.holographic.b> c3 = c2.a().x().get(0);
                c3.a().a().a(e.a.a, new ItemStack(((DropType)entry.getKey()).getHologram()));
                c2.Q();
                this.k.put(c2, (DropType)entry.getKey());
            }
            this.a().reset();
            for (Player player : this.getPlayers()) {
                this.a.s(player);
            }
            if (ConfigValue.bed_hologram_enabled) {
                for (Team team : this.a().r()) {
                    if (ConfigValue.bed_hologram_message_alive.isEmpty()) break;
                    if (this.a().a(team) == null || this.a(team).size() < 1) continue;
                    Location location = this.a().a(team).toBukkit(this.getWorld()).clone().add(0.5, -0.5, 0.5);
                    String string = ConfigValue.bed_hologram_message_alive.replace("{teamcolor}", "" + (Object)team.getChatColor()).replace("{team}", team.a(null, true)).replace("{heart}", ConfigValue.scoreboard_heart_alive);
                    de.marcely.bedwars.holographic.c<cJ> c4 = de.marcely.bedwars.holographic.c.a(cJ.class, location, new cF().b(false).a(string.split("\\\\n")));
                    c4.a((byte)6);
                    c4.Q();
                    this.q.put(team, c4);
                }
            }
            this.a(ArenaStatus.f);
            Bukkit.getPluginManager().callEvent((Event)new RoundStartEvent(this));
            de.marcely.bedwars.config.b.b(this);
            this.f = System.currentTimeMillis();
            if (ConfigValue.lobbybreak_enabled) {
                for (int i2 = -ConfigValue.lobbybreak_radius; i2 < ConfigValue.lobbybreak_radius; ++i2) {
                    for (int i3 = -ConfigValue.lobbybreak_radius; i3 < ConfigValue.lobbybreak_radius; ++i3) {
                        for (var3_21 = (reference)(-ConfigValue.lobbybreak_radius); var3_21 < ConfigValue.lobbybreak_radius; ++var3_21) {
                            Block block = this.getLobby().clone().add((double)i2, (double)i3, (double)var3_21).getBlock();
                            block.setType(Material.AIR);
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    public boolean isColor(String string) {
        for (Language language : Language.values()) {
            if (!language.name().startsWith("Color_") || !language.getMessage(null).equalsIgnoreCase(string)) continue;
            return true;
        }
        return false;
    }

    private void j(final Player player) {
        new BukkitRunnable(){

            public void run() {
                if (Arena.this.b() != ArenaStatus.f || !Arena.this.getPlayers().contains((Object)player)) {
                    return;
                }
                Team team = Arena.this.a(player);
                if (ConfigValue.giveitems_on_enabled) {
                    for (ItemStack object : ConfigValue.giveitems_on_respawn) {
                        player.getInventory().addItem(new ItemStack[]{de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(object, team), Arena.this.a(player, team, object))});
                    }
                    for (ItemStack itemStack : ConfigValue.giveitems_on_respawn_armor) {
                        if (de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(itemStack, team), Arena.this.a(player, team, itemStack)), true)) continue;
                        de.marcely.bedwars.d.b("'" + (Object)itemStack.getType() + "' isn't a valid armor (Config: giveitems-on-respawn-armor)");
                    }
                }
                for (ShopItem shopItem : Arena.this.u.get((Object)player)) {
                    if (!shopItem.isKeepOnDeath()) continue;
                    for (ShopProduct shopProduct : shopItem.getProducts()) {
                        shopProduct.give(player, team, 1, Arena.this);
                    }
                }
                Bukkit.getPluginManager().callEvent((Event)new PlayerRoundRespawnEvent(player, Arena.this));
            }
        }.runTaskLater((Plugin)MBedwars.a, 20L);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(final Player player, PlayerRespawnEvent playerRespawnEvent) {
        if (this.b().F()) {
            playerRespawnEvent.setRespawnLocation(this.getLobby());
            return;
        }
        if (this.b() != ArenaStatus.f) {
            playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.k);
            return;
        }
        player.setGameMode(GameMode.SURVIVAL);
        Team team = this.a(player);
        if (team != null) {
            boolean bl2 = this.b.d(team);
            PlayerRoundDeathEvent playerRoundDeathEvent = new PlayerRoundDeathEvent(playerRespawnEvent, this, bl2);
            Bukkit.getPluginManager().callEvent((Event)playerRoundDeathEvent);
            if (playerRoundDeathEvent.willKick()) {
                playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.k);
                new BukkitRunnable(){

                    public void run() {
                        Arena.this.a(KickReason.d, player);
                    }
                }.runTaskLater((Plugin)MBedwars.a, 1L);
                return;
            }
            if (!ConfigValue.death_spectate_enabled) {
                playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.b(this.a().a(team).toBukkit(this.world)));
                this.j(player);
                return;
            }
            if (!this.isInside(player.getLocation())) {
                playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.b(this.a().a(team).toBukkit(this.world)));
            } else {
                playerRespawnEvent.setRespawnLocation(player.getLocation());
            }
            this.a(player, team);
            return;
        }
        if (cA.E.containsKey((Object)player)) {
            playerRespawnEvent.setRespawnLocation(this.a().a(this.a().r().get(0)).toBukkit(this.getWorld()));
            return;
        }
        de.marcely.bedwars.util.s.b(player, this);
    }

    private void a(final Player player, final Team team) {
        cA.a(player, this, SpectateReason.DEATH);
        final de.marcely.bedwars.game.a a2 = this.p.get((Object)player);
        if (!a2.isRunning()) {
            a2.run();
        }
        a2.setAnimated(false);
        new BukkitRunnable(){
            int time = ConfigValue.death_spectate_time;

            public void run() {
                if (!Arena.this.getPlayers().contains((Object)player) || Arena.this.b() != ArenaStatus.f) {
                    this.cancel();
                }
                if (this.time > 0) {
                    a2.setMessage(de.marcely.bedwars.message.b.a(Language.Death_Spectate_RespawnIn).a("time", "" + this.time).f((CommandSender)player));
                    --this.time;
                } else {
                    Arena.this.z();
                    Arena.this.a(player, de.marcely.bedwars.util.s.b(Arena.this.a().a(team).toBukkit(Arena.this.world).clone().add(0.0, 0.1, 0.0)));
                    cA.a(player, cD.g);
                    de.marcely.bedwars.util.s.M(player);
                    Arena.this.j(player);
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 20L);
    }

    @Deprecated
    public boolean stop() {
        if (this.b() == ArenaStatus.f) {
            this.a(KickReason.c);
            this.a(ArenaStatus.e);
            return true;
        }
        return false;
    }

    public void b(Player player, Team team) {
        if (this.a(player) == team) {
            return;
        }
        this.d(player, team);
        this.p(player);
        de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_Changed).a("color", team.a((CommandSender)player)).a("colorcode", "" + (Object)team.getChatColor()));
    }

    public void c(Player player, Team team) {
        if (this.b() != ArenaStatus.e || !this.a().r().contains((Object)team)) {
            return;
        }
        Team team2 = this.a(player);
        if (team2 != null && team2 == team) {
            Sound.LOBBY_SELECTTEAM_ALREADYSELECTED.play(player);
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_AlreadyInside).a("color", team.getName()).a("colorcode", "" + (Object)team.getChatColor()));
            return;
        }
        if (this.a(team).size() >= this.l()) {
            Sound.LOBBY_SELECTTEAM_FULL.play(player);
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_Full).a("color", team.getName()).a("colorcode", "" + (Object)team.getChatColor()));
            return;
        }
        this.b(player, team);
        Sound.LOBBY_SELECTTEAM_SELECT.play(player);
    }

    public void a(Player player, Location location, Team team) {
        BedBreakEvent bedBreakEvent = new BedBreakEvent(player, this, de.marcely.bedwars.api.Team.fromInternal(team), location);
        Bukkit.getPluginManager().callEvent((Event)bedBreakEvent);
        if (bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.Normally) {
            this.a().a(team, true);
        }
        if (bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.Normally || bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.BreakButDontChangeInTeamColors) {
            Object object2;
            de.marcely.bedwars.holographic.c<cJ> c2 = this.q.get((Object)team);
            if (c2 != null) {
                c2.remove();
                this.q.remove((Object)team);
            }
            if (ConfigValue.bed_drops_amount >= 1 && (c2 = DropType.a(Language.replaceLanguageTranslations(null, ConfigValue.bed_drops_type))) != null) {
                de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(new ItemStack(((DropType)((Object)c2)).getActualItemstack().clone()), (Object)((DropType)((Object)c2)).getChatColor() + ((DropType)((Object)c2)).a(null, true)), ConfigValue.bed_drops_amount));
            }
            c2 = de.marcely.bedwars.game.stats.c.a(player);
            de.marcely.bedwars.util.s.a(c2, new Runnable((Future)((Object)c2)){
                private final /* synthetic */ Future d;
                {
                    this.d = future;
                }

                @Override
                public void run() {
                    try {
                        de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)this.d.get();
                        c2.setBedsDestroyed(c2.getBedsDestroyed() + 1);
                        c2.save();
                        Arena.this.a.G();
                    }
                    catch (InterruptedException | ExecutionException exception) {
                        exception.printStackTrace();
                    }
                }
            });
            for (Object object2 : this.getPlayers()) {
                if (this.a((Player)object2) != null && this.a((Player)object2) == team) {
                    Sound.BED_DESTROY.play((Player)object2);
                    continue;
                }
                Sound.BED_DESTROY_ENEMY.play((Player)object2);
            }
            object2 = de.marcely.bedwars.message.b.a(Language.Destroyed_Bed).a("team", team.getName()).a("teamcolor", "" + (Object)team.getChatColor()).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).f(null);
            for (Player player2 : this.getPlayers()) {
                Version.a().b((String)object2, player2);
            }
            for (Player player3 : this.getSpectators()) {
                Version.a().b((String)object2, player3);
            }
            for (dg dg2 : de.marcely.bedwars.util.s.b.a(dg.class)) {
                dg2.a(player, df.c);
            }
            if (ConfigValue.beddestroy_message_enabled) {
                Team team2 = this.a(player);
                this.a(de.marcely.bedwars.message.b.a(ConfigValue.beddestroy_message).b().c().a("team", team.getName()).a("teamcolor", "" + (Object)team.getChatColor()).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("playerteam", team2.getName()).a("playerteamcolor", "" + (Object)team2.getChatColor()));
            }
        }
    }

    public void a(Sound sound) {
        for (Player player : this.getPlayers()) {
            sound.play(player);
        }
        for (Player player : this.getSpectators()) {
            sound.play(player);
        }
    }

    public List<Team> a(Player ... arrplayer) {
        ArrayList<Team> arrayList = new ArrayList<Team>();
        List<Player> list = Arrays.asList(arrplayer);
        for (Player player : this.getPlayers()) {
            Team team;
            if (list.contains((Object)player) || arrayList.contains((Object)(team = this.a(player)))) continue;
            arrayList.add(team);
        }
        return arrayList;
    }

    public List<Player> a(Team team) {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (Player player : this.getPlayers()) {
            if (this.a(player) == null || this.a(player) != team) continue;
            arrayList.add(player);
        }
        return arrayList;
    }

    public boolean a(Team team) {
        return this.a(team).size() == this.getPlayers().size();
    }

    public boolean a(XYZ xYZ, Material material) {
        Location location = xYZ.toBukkit(this.getWorld());
        if (this.isInside(location)) {
            this.world.getBlockAt(location).setType(material);
            return true;
        }
        return false;
    }

    public List<CrashMessage> getProblems() {
        ArrayList<CrashMessage> arrayList = new ArrayList<CrashMessage>();
        if (de.marcely.bedwars.util.s.k == null) {
            arrayList.add(new CrashMessage(CrashMessage.CrashMessageType.missingGameDoneLocation));
        }
        if (!this.hasLobby()) {
            arrayList.add(new CrashMessage(CrashMessage.CrashMessageType.missingLobbyLocation));
        }
        if (this.a() != RegenerationType.e) {
            for (Team team : this.a().r()) {
                if (!this.a().d().containsKey((Object)team) && !arrayList.contains(new CrashMessage(CrashMessage.CrashMessageType.missingTeamSpawn))) {
                    arrayList.add(new CrashMessage(CrashMessage.CrashMessageType.missingTeamSpawn, team.getName()));
                }
                if (this.a().e().containsKey((Object)team)) continue;
                arrayList.add(new CrashMessage(CrashMessage.CrashMessageType.missingBed, team.getName()));
            }
        }
        return arrayList;
    }

    public Team a(Player player) {
        return this.l.get((Object)player);
    }

    @Override
    public List<Player> getSpectators() {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (Map.Entry<Player, cz> entry : cA.E.entrySet()) {
            if (!entry.getValue().getArena().equals(this)) continue;
            arrayList.add(entry.getKey());
        }
        return arrayList;
    }

    public void d(Player player, Team team) {
        this.a(player, team, true);
    }

    public void a(Player player, Team team, boolean bl2) {
        Team team2 = this.a(player);
        this.l.put(player, team);
        if (ConfigValue.player_color) {
            if (team != null) {
                Version.a().a(this.a(team), this.getPlayers(), team.getChatColor());
            } else {
                Version.a().d(player, this.getPlayers());
            }
        }
        if (team2 != null) {
            this.a(team2);
        }
        if (team != null) {
            this.a(team);
        }
        if (bl2) {
            this.a.E();
        }
    }

    private boolean a(j j2) {
        if (de.marcely.bedwars.util.s.af.contains(this)) {
            MBedwars.a.a(j2);
            return true;
        }
        return false;
    }

    @Override
    public boolean isInside(Location location) {
        if (this.b == RegenerationType.c) {
            return location.getWorld().equals((Object)this.getWorld()) && this.getPosMin().getX() < location.getX() && this.getPosMax().getX() > location.getX() && this.getPosMin().getY() < location.getY() && this.getPosMax().getY() > location.getY() && this.getPosMin().getZ() < location.getZ() && this.getPosMax().getZ() > location.getZ();
        }
        return location.getWorld().equals((Object)this.getWorld());
    }

    public boolean a(Chunk chunk) {
        if (!this.C.equals(chunk.getWorld().getName())) {
            return false;
        }
        return chunk.getX() >= (int)this.getPosMin().getX() >> 4 && chunk.getZ() >= (int)this.getPosMin().getZ() >> 4 && chunk.getX() <= (int)this.getPosMax().getX() >> 4 && chunk.getZ() <= (int)this.getPosMax().getZ() >> 4;
    }

    public void a(final de.marcely.bedwars.game.regeneration.c c2) {
        if (this.b() != ArenaStatus.d) {
            c2.a(c.a.e);
            return;
        }
        if (this.E) {
            c2.a(c.a.d);
            return;
        }
        this.E = true;
        de.marcely.bedwars.game.regeneration.a a2 = this.a().a(this);
        if (a2 != null) {
            try {
                a2.b(new de.marcely.bedwars.game.regeneration.c(){

                    @Override
                    public void a(c.a a2) {
                        Arena.this.E = false;
                        c2.a(a2);
                    }

                    @Override
                    public void a(long l2) {
                        c2.a(l2);
                    }
                });
                return;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                c2.a(c.a.f);
            }
        } else {
            c2.a(c.a.c);
        }
        this.E = false;
    }

    public void c(CommandSender commandSender) {
        this.a(commandSender, true, false);
    }

    public void a(CommandSender commandSender, boolean bl2) {
        this.a(commandSender, bl2, false);
    }

    public void a(final CommandSender commandSender, final boolean bl2, final boolean bl3) {
        this.a(new de.marcely.bedwars.game.regeneration.c(){
            boolean G = false;
            private static /* synthetic */ int[] k;

            @Override
            public void a(c.a a2) {
                switch (3.l()[a2.ordinal()]) {
                    case 1: {
                        if (!bl2) break;
                        if (!bl3) {
                            de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", Arena.this.getName()));
                            break;
                        }
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Arena_AutoSavedBlocks).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 2: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_Players).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 4: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_AlreadyRunning).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 5: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_NotStopped).a("arena", Arena.this.getName()));
                        break;
                    }
                    default: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_Unkown).a("arena", Arena.this.getName()).a("type", a2.name()));
                    }
                }
            }

            @Override
            public void a(long l2) {
                if (l2 < 2000L || this.G) {
                    return;
                }
                this.G = true;
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Start).a("arena", Arena.this.getName()).a("time", "~" + l2 / 1000L + "s"));
            }

            static /* synthetic */ int[] l() {
                if (k != null) {
                    int[] arrn;
                    return arrn;
                }
                int[] arrn = new int[c.a.values().length];
                try {
                    arrn[c.a.d.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[c.a.e.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[c.a.c.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[c.a.b.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[c.a.a.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    arrn[c.a.f.ordinal()] = 6;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                k = arrn;
                return k;
            }
        });
    }

    @Override
    public void teleportHere(Player player) {
        this.a(player, false);
    }

    public void a(final Player player, boolean bl2) {
        if (this.a() != null) {
            player.teleport(((XYZYP)this.a()).toBukkit(this.getWorld()));
            return;
        }
        double d2 = 0.0;
        double d3 = 0.0;
        double d4 = 0.0;
        if (this.a().d().size() >= 1) {
            this.a(player, this.a().d().get((Object)this.a().r().get(0)).toBukkit(this.getWorld()));
        } else if (this.hasLobby()) {
            this.a(player, this.getLobby());
        } else if (this.a() == RegenerationType.c) {
            double d5 = this.getPosMax().getX() - this.getPosMin().getX();
            double d6 = this.getPosMax().getZ() - this.getPosMin().getZ();
            d2 = this.getPosMin().getX() + d5 / 2.0;
            d4 = this.getPosMin().getZ() + d6 / 2.0;
            d3 = this.getWorld().getHighestBlockAt((int)d2, (int)d4).getY() + 2;
            final Location location = new Location(this.getWorld(), d2, d3, d4);
            this.a(player, location);
            new BukkitRunnable(){

                public void run() {
                    if (location.getY() == 0.0) {
                        player.setAllowFlight(true);
                        player.setFlying(true);
                        Arena.this.a(player, location.add(0.0, (double)(Arena.this.getWorld().getMaxHeight() / 2), 0.0));
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 20L);
        } else if (this.a() == RegenerationType.d) {
            final Location location = this.getWorld().getSpawnLocation().clone();
            this.a(player, location);
            new BukkitRunnable(){

                public void run() {
                    if (location.getY() == 0.0) {
                        player.setAllowFlight(true);
                        player.setFlying(true);
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 10L);
        }
        if (bl2) {
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Teleport_Success).a("arena", this.getName()));
        }
    }

    public boolean b(@Nullable Team team) {
        if (this.b() != ArenaStatus.f) {
            return false;
        }
        Bukkit.getPluginManager().callEvent((Event)new RoundEndEvent(this, de.marcely.bedwars.api.Team.fromInternal(team)));
        if (team != null) {
            this.a(de.marcely.bedwars.message.b.a(Language.Team_Won).a("color", team.getName()).a("colorcode", "" + (Object)team.getChatColor()));
            for (Player arrlocation3 : this.getPlayers()) {
                if (this.a(arrlocation3) == team) {
                    this.b(arrlocation3, false);
                    if (ConfigValue.prize_enabled) {
                        double d2;
                        double d3 = de.marcely.bedwars.util.s.b.a(cT.v) && de.marcely.bedwars.util.s.b.get(cW.class).a != null ? de.marcely.bedwars.util.s.b.get(cW.class).a.getBalance((OfflinePlayer)arrlocation3) : 0.0;
                        for (String string : ConfigValue.prize_commands) {
                            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)string.replace("{name}", arrlocation3.getName()));
                        }
                        if (de.marcely.bedwars.util.s.b.a(cT.v) && de.marcely.bedwars.util.s.b.get(cW.class).a != null && (d2 = de.marcely.bedwars.util.s.b.get(cW.class).a.getBalance((OfflinePlayer)arrlocation3)) > d3) {
                            de.marcely.bedwars.util.s.a((CommandSender)arrlocation3, de.marcely.bedwars.message.b.a(Language.Win_Money).a("number", "" + (d2 - d3)));
                        }
                    }
                    if (this.A()) {
                        de.marcely.bedwars.util.s.a(arrlocation3, Achievement.k);
                    }
                    if (this.b.a().contains((Object)team)) {
                        de.marcely.bedwars.util.s.a(arrlocation3, Achievement.z);
                    }
                    for (dg dg2 : de.marcely.bedwars.util.s.b.a(dg.class)) {
                        dg2.a(arrlocation3, df.a);
                    }
                    continue;
                }
                this.b(arrlocation3, true);
                for (dg dg3 : de.marcely.bedwars.util.s.b.a(dg.class)) {
                    dg3.a(arrlocation3, df.b);
                }
            }
        }
        this.H.clear();
        aV.g.remove(this);
        aV.h.remove(this);
        this.B();
        if (this.getPlayers().size() >= 1) {
            this.a(ArenaStatus.h);
            for (Player player : this.getPlayers()) {
                this.a(player, this.getLobby());
                de.marcely.bedwars.util.s.M(player);
            }
            for (Player player : this.getSpectators()) {
                player.setFallDistance(0.0f);
                de.marcely.bedwars.util.s.b(player, this);
                c.t(player);
            }
            Location location22 = this.getPlayers().iterator();
            while (location22.hasNext()) {
                Player player = location22.next();
                if (team != null) {
                    Version.a().a(de.marcely.bedwars.message.b.a(Language.EndLobby_Title).a("teamcolor", "" + (Object)team.getChatColor()).a("team", team.getName(true)).f((CommandSender)player), player, ConfigValue.endlobby_countdown_time / 2 * 20);
                    continue;
                }
                Version.a().a(de.marcely.bedwars.message.b.a(Language.EndLobby_Title_Nobody).f((CommandSender)player), player, ConfigValue.endlobby_countdown_time / 2 * 20);
            }
            if (team != null) {
                Location[] arrlocation = new Location[]{this.getLobby().clone().add(1.0, 0.0, 0.0), this.getLobby().clone().add(-1.0, 0.0, 0.0), this.getLobby().clone().add(0.0, 0.0, 1.0), this.getLobby().clone().add(0.0, 0.0, -1.0)};
                for (Location location22 : arrlocation) {
                    Firework firework = (Firework)this.getLobby().getWorld().spawnEntity(location22, EntityType.FIREWORK);
                    FireworkMeta fireworkMeta = firework.getFireworkMeta();
                    fireworkMeta.addEffect(de.marcely.bedwars.util.s.b());
                    firework.setFireworkMeta(fireworkMeta);
                }
            }
        } else {
            this.a(ArenaStatus.g);
        }
        return true;
    }

    public boolean c(@Nullable CommandSender commandSender) {
        if (!de.marcely.bedwars.util.s.af.contains(this)) {
            return false;
        }
        ArenaDeleteEvent object2 = new ArenaDeleteEvent(this, commandSender);
        Bukkit.getPluginManager().callEvent((Event)object2);
        if (object2.isCancelled()) {
            return false;
        }
        if (MBedwars.d()) {
            MBedwars.a.a(new s(this));
        }
        if (this.a != null && this.a.isRunning()) {
            this.a.cancel();
            this.a = null;
        }
        aV.g.remove(this);
        aV.h.remove(this);
        for (dy dy2 : this.M) {
            MBedwars.a.b(dy2);
        }
        this.M.clear();
        de.marcely.bedwars.util.s.c(this, d.a.b);
        de.marcely.bedwars.util.s.ag.remove(this);
        de.marcely.bedwars.util.s.af.remove(this);
        return true;
    }

    public List<Block> a(Location location, Material material, int n2) {
        ArrayList<Block> arrayList = new ArrayList<Block>();
        int n3 = location.getBlockX();
        int n4 = location.getBlockY();
        int n5 = location.getBlockZ();
        int n6 = n2 * n2;
        for (int i2 = n3 - n2; i2 <= n3 + n2; ++i2) {
            for (int i3 = n5 - n2; i3 <= n5 + n2; ++i3) {
                Block block;
                Location location2;
                if ((n3 - i2) * (n3 - i2) + (n5 - i3) * (n5 - i3) > n6 || (block = (location2 = new Location(location.getWorld(), (double)i2, (double)n4, (double)i3)).getBlock()).getType() != Material.AIR || !this.isInside(location2)) continue;
                block.setType(material);
                arrayList.add(block);
            }
        }
        return arrayList;
    }

    public XYZ a() {
        return this.a.add((this.b.getX() - this.a.getX()) / 2.0, (this.b.getY() - this.a.getY()) / 2.0, (this.b.getZ() - this.a.getZ()) / 2.0);
    }

    public List<Chunk> m() {
        int n2 = (int)this.a.getX() >> 4;
        int n3 = (int)this.a.getZ() >> 4;
        int n4 = (int)this.b.getX() >> 4;
        int n5 = (int)this.b.getZ() >> 4;
        ArrayList<Chunk> arrayList = new ArrayList<Chunk>((n4 - n2) * (n5 - n3));
        for (int i2 = n2; i2 <= n4; ++i2) {
            for (int i3 = n3; i3 <= n5; ++i3) {
                arrayList.add(this.world.getChunkAt(i2, i3));
            }
        }
        return arrayList;
    }

    public a a(Player player) {
        for (a a2 : this.I) {
            if (!a2.P.contains((Object)player)) continue;
            return a2;
        }
        return null;
    }

    public boolean E() {
        if (!this.D || this.a() != RegenerationType.e) {
            return false;
        }
        boolean bl2 = false;
        this.I.clear();
        List<Arena> list = de.marcely.bedwars.util.s.b(this.getMaxPlayers());
        int n2 = this.I.size();
        for (Arena arena : list) {
            if (n2 == ConfigValue.arenavoting_maxarenas) break;
            boolean bl3 = false;
            for (a a2 : this.I) {
                if (!a2.arena.getDisplayName().equals(arena.getDisplayName())) continue;
                bl3 = true;
                break;
            }
            if (bl3) continue;
            this.I.add(new a(arena));
            ++n2;
            bl2 = true;
        }
        return bl2;
    }

    public boolean f(Player player) {
        if (this.getPlayers().size() >= this.k()) {
            Sound.LOBBY_FORCESTART.play(player);
            this.a.b(ConfigValue.forcestart_time, false);
            for (Player player2 : this.getPlayers()) {
                this.p(player2);
            }
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", "" + ConfigValue.forcestart_time));
            return true;
        }
        if (ConfigValue.forcestart_ignoreminplayers) {
            Sound.LOBBY_FORCESTART.play(player);
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", "0"));
            this.D();
            return true;
        }
        return false;
    }

    public Flag a(String string) {
        for (Flag flag : this.flags) {
            if (flag.getName().equals(string)) {
                return flag;
            }
            f.a a2 = f.a.a(string);
            if (a2 == null) continue;
            return this.a(a2);
        }
        return null;
    }

    public Flag a(f.a a2) {
        for (Flag flag : this.flags) {
            if (!(flag instanceof f) || ((f)flag).a() != a2) continue;
            return flag;
        }
        return null;
    }

    public void a(d d2) {
        this.J.add(d2);
    }

    public boolean a(d d2) {
        return this.J.remove(d2);
    }

    public int m() {
        Double d2 = r.a(ConfigValue.lobby_countdownstart_calculation.replace("{teams}", "" + this.a().r().size()).replace("{teamplayers}", "" + this.getTeamPlayers()));
        if (d2 != null) {
            return (int)d2.doubleValue();
        }
        de.marcely.bedwars.d.b("Something in the config 'lobby-countdownstart-calculation' seems to be wrong! (Error)");
        return (this.getTeamPlayers() + this.a().r().size()) * 10 + 1;
    }

    public boolean a(Location location) {
        if (!ConfigValue.notbuildableradius_enabled) {
            return false;
        }
        if (ConfigValue.notbuildableradius_teamspawn > 0) {
            for (Team object : this.a().r()) {
                XYZYP xYZYP = this.a().a(object);
                if (xYZYP == null || !(xYZYP.toBukkit(this.getWorld()).distance(location) <= (double)ConfigValue.notbuildableradius_teamspawn)) continue;
                return true;
            }
        }
        if (ConfigValue.notbuildableradius_itemspawner > 0) {
            for (XYZ xYZ : ((MultiKeyMap)((Object)this.a)).values()) {
                if (!(xYZ.toBukkit(this.getWorld()).distance(location) <= (double)ConfigValue.notbuildableradius_itemspawner)) continue;
                return true;
            }
        }
        return false;
    }

    public boolean f(String string) {
        if (de.marcely.bedwars.util.s.a(string, this) != null) {
            return false;
        }
        String string2 = this.getName();
        de.marcely.bedwars.config.b.b(this);
        try {
            if (new File("plugins/MBedwars/data/arenablocks/" + string2 + ".yml").exists()) {
                Files.move(new File("plugins/MBedwars/data/arenablocks/" + string2 + ".yml").toPath(), new File("plugins/MBedwars/data/arenablocks/" + string + ".yml").toPath(), new CopyOption[0]);
            }
            Files.move(new File("plugins/MBedwars/data/arenadata/" + string2 + ".cfg").toPath(), new File("plugins/MBedwars/data/arenadata/" + string + ".cfg").toPath(), new CopyOption[0]);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        this.setName(string);
        de.marcely.bedwars.config.b.b(this);
        return true;
    }

    @Deprecated
    public Arena a() {
        try {
            return (Arena)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            cloneNotSupportedException.printStackTrace();
            return null;
        }
    }

    public e a(int n2) {
        return new e(ConfigValue.performance.s, n2, n2, this.getPlayers());
    }

    public void w(String string) {
        for (de.marcely.bedwars.game.a a2 : this.p.values()) {
            a2.setMessage(string);
        }
    }

    public void c(String string, int n2) {
        for (de.marcely.bedwars.game.a a2 : this.p.values()) {
            a2.b(string, n2);
        }
    }

    public List<de.marcely.bedwars.game.a> b(Team team) {
        ArrayList<de.marcely.bedwars.game.a> arrayList = new ArrayList<de.marcely.bedwars.game.a>();
        for (Map.Entry<Player, de.marcely.bedwars.game.a> entry : this.p.entrySet()) {
            Team team2 = this.a(entry.getKey());
            if (team2 == null || team2 != team) continue;
            arrayList.add(entry.getValue());
        }
        return arrayList;
    }

    public void z() {
        for (Team team : this.a().r()) {
            this.a(team);
        }
    }

    public void a(Team team) {
        List<de.marcely.bedwars.game.a> list = this.b(team);
        String string = (Object)team.getChatColor() + team.getName(true) + " " + (Object)ChatColor.DARK_GRAY + "[" + (Object)ChatColor.GRAY + this.a(team).size() + "/" + this.getTeamPlayers() + (Object)ChatColor.DARK_GRAY + "]";
        for (de.marcely.bedwars.game.a a2 : list) {
            a2.setMessage(string);
        }
    }

    public List<Player> n() {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        arrayList.addAll(Version.a().getOnlinePlayers());
        arrayList.removeAll(this.getPlayers());
        return arrayList;
    }

    public void b(Block block) {
        this.K.add(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }

    public void c(Block block) {
        this.K.remove(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }

    public boolean a(Block block) {
        return this.K.contains(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }

    public void A() {
        for (dw dw2 : dw.values()) {
            if (!dw2.R()) continue;
            try {
                Class<? extends dD> class_ = dw2.getClazz();
                dy dy2 = (dy)class_.getDeclaredConstructor(Arena.class).newInstance(this);
                this.M.add(dy2);
                MBedwars.a.a(dy2);
            }
            catch (IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException exception) {
                exception.printStackTrace();
            }
        }
    }

    public int a(UpgradeType upgradeType, Team team) {
        i i2 = this.r.get((Object)team);
        int n2 = i2.a(upgradeType);
        if (n2 > 0) {
            Upgrade upgrade = de.marcely.bedwars.util.s.a(upgradeType, n2);
            if (upgrade != null) {
                return (Integer)((de.marcely.bedwars.flag.j)upgrade.getValue()).getValue();
            }
            return 0;
        }
        return 0;
    }

    public double a(UpgradeType upgradeType, Team team) {
        i i2 = this.r.get((Object)team);
        int n2 = i2.a(upgradeType);
        if (n2 > 0) {
            Upgrade upgrade = de.marcely.bedwars.util.s.a(upgradeType, n2);
            if (upgrade != null) {
                return (Double)((de.marcely.bedwars.flag.f)upgrade.getValue()).getValue();
            }
            return 0.0;
        }
        return 0.0;
    }

    private void k(Player player) {
        ArrayList<Player> arrayList = new ArrayList<Player>();
        for (Player player2 : Version.a().getOnlinePlayers()) {
            if (player2 == player || player.canSee(player2)) continue;
            arrayList.add(player2);
        }
        this.e.put(player, arrayList);
        this.l(player);
    }

    private void l(Player player) {
        for (Player player2 : Version.a().getOnlinePlayers()) {
            if (player2 == player) continue;
            if (player.canSee(player2) && !this.getPlayers().contains((Object)player2)) {
                player.hidePlayer(player2);
                ((List)this.e.get((Object)player)).add(player2);
                continue;
            }
            if (player.canSee(player2) || !this.getPlayers().contains((Object)player2)) continue;
            player.showPlayer(player2);
            ((List)this.e.get((Object)player)).remove((Object)player2);
        }
    }

    private void m(Player player) {
        for (Player player2 : (List)this.e.get((Object)player)) {
            player.showPlayer(player2);
        }
        this.e.remove((Object)player);
    }

    public List<String> o() {
        ArrayList<String> arrayList = new ArrayList<String>();
        String[] arrstring = this.b();
        String string = "";
        int n2 = 1;
        int n3 = 0;
        int n4 = 1;
        for (String string2 : arrstring) {
            if (n2 == 3) {
                arrayList.add(String.valueOf(n3 == 0 ? (Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Info_MadeBy).f(null) + ": " : " ") + (Object)ChatColor.AQUA + string);
                string = "";
                n2 = 0;
                ++n3;
            }
            string = String.valueOf(string) + string2 + (n4 < arrstring.length ? ", " : "");
            ++n2;
            ++n4;
        }
        arrayList.add(String.valueOf(n3 == 0 ? (Object)ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Info_MadeBy).f(null) + ": " : " ") + (Object)ChatColor.AQUA + string);
        if (this.a() != RegenerationType.e) {
            arrayList.add((Object)ChatColor.AQUA + this.a().r().size() + (Object)ChatColor.DARK_AQUA + "x" + (Object)ChatColor.AQUA + this.getTeamPlayers());
        }
        arrayList.add((Object)ChatColor.GRAY + (Object)ChatColor.STRIKETHROUGH + "===================");
        arrayList.add(this.b().b(this));
        if (this.b() != ArenaStatus.g && this.b() != ArenaStatus.d) {
            arrayList.add((Object)ChatColor.YELLOW + this.getPlayers().size() + (Object)ChatColor.GOLD + " / " + (Object)ChatColor.YELLOW + this.getMaxPlayers());
        }
        return arrayList;
    }

    public boolean a(Arena arena) {
        if (this.a() == RegenerationType.d || arena.a() == RegenerationType.d) {
            return this.C.equals(arena.C);
        }
        if (this.a() == RegenerationType.c && arena.a() == RegenerationType.c) {
            double d2 = this.getPosMax().getX() - this.getPosMin().getX();
            double d3 = this.getPosMax().getY() - this.getPosMin().getY();
            double d4 = this.getPosMax().getZ() - this.getPosMin().getZ();
            double d5 = arena.getPosMax().getX() - arena.getPosMin().getX();
            double d6 = arena.getPosMax().getY() - arena.getPosMin().getY();
            double d7 = arena.getPosMax().getZ() - arena.getPosMin().getZ();
            return Math.abs(this.getPosMin().getX() - arena.getPosMin().getX()) < d2 + d5 && Math.abs(this.getPosMin().getY() - arena.getPosMin().getY()) < d3 + d6 && Math.abs(this.getPosMin().getZ() - arena.getPosMin().getZ()) < d4 + d7 && this.C.equals(arena.C);
        }
        return false;
    }

    public void n(Player player) {
        for (Arena arena : de.marcely.bedwars.util.s.af) {
            if (arena == this || !this.a(arena)) continue;
            player.sendMessage(" ");
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena1));
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena2).a("arena", arena.getName()));
            String string = null;
            switch (Arena.k()[this.a().ordinal()]) {
                case 1: {
                    string = "/bw arena setposition " + this.getName();
                    break;
                }
                case 2: {
                    string = "/bw arena setworld " + this.getName();
                    break;
                }
                default: {
                    return;
                }
            }
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena3).a("command", string));
            return;
        }
    }

    public void a(Player player, Location location) {
        location = location.clone().add(0.0, 0.1, 0.0);
        be.D.add(player);
        player.teleport(location);
    }

    private void b(final Player player, final boolean bl2) {
        if (!this.m.containsKey((Object)player)) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> future = de.marcely.bedwars.game.stats.c.a(player);
        de.marcely.bedwars.util.s.a(future, new Runnable(){

            @Override
            public void run() {
                try {
                    de.marcely.bedwars.game.stats.c c2 = (de.marcely.bedwars.game.stats.c)future.get();
                    c2.setPlayTime(c2.getPlayTime() + (System.currentTimeMillis() - Arena.this.m.get((Object)player)));
                    if (bl2) {
                        c2.setLoses(c2.getLoses() + 1);
                    } else {
                        c2.setWins(c2.getWins() + 1);
                    }
                    de.marcely.bedwars.util.s.a(player, bl2 ? Achievement.d : Achievement.c);
                    if (c2.getWins() >= 100) {
                        de.marcely.bedwars.util.s.a(player, Achievement.m);
                    }
                    c2.save();
                    Arena.this.m.remove((Object)player);
                }
                catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    public void B() {
        for (int i2 = this.N.size() - 1; i2 >= 0; --i2) {
            ((by)this.N.get(i2)).stop();
        }
    }

    public void c(Player player, boolean bl2) {
        if (ConfigValue.no_rain) {
            if (bl2) {
                Version.a().d(player, false);
            } else {
                Version.a().d(player, player.getWorld().getWeatherDuration() >= 1);
            }
        }
        if (ConfigValue.always_day && bl2) {
            Version.a().a(player, 5000L);
        }
    }

    public void C() {
        if (this.B) {
            if (this.getPlayers().size() >= 1) {
                this.B = false;
                de.marcely.bedwars.util.s.ag.add(this);
            }
        } else if (this.getPlayers().size() == 0) {
            this.B = true;
            de.marcely.bedwars.util.s.ag.remove(this);
            this.a.D();
        }
    }

    public void o(Player player) {
        Team team = this.a(player);
        if (team == null) {
            return;
        }
        if (player.getLocation().getY() <= 0.0) {
            this.a(player, this.a().a(team).toBukkit(this.world));
        }
        player.setHealth(0.0);
    }

    public void p(Player player) {
        if (this.b() != ArenaStatus.e) {
            return;
        }
        de.marcely.bedwars.util.s.M(player);
        Team team = this.a(player);
        for (LobbyItem lobbyItem : de.marcely.bedwars.util.s.ai) {
            if (lobbyItem.a() == null) {
                player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), team));
                continue;
            }
            if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.d) {
                if (this.j() < this.k() || this.a == null || this.a.getValue() <= ConfigValue.forcestart_time || this.a.I()) continue;
                for (Player player2 : this.getPlayers()) {
                    if (!de.marcely.bedwars.util.s.hasPermission((CommandSender)player2, Permission.Command_Forcestart)) continue;
                    player2.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), team));
                }
                continue;
            }
            if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.e && !de.marcely.bedwars.util.s.al) continue;
            if (this.a() == RegenerationType.e) {
                if (!(lobbyItem.a().getType() == LobbyItem.LobbySpecialType.b && !this.D || lobbyItem.a().getType() == LobbyItem.LobbySpecialType.c && this.D) && (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.b || lobbyItem.a().getType() == LobbyItem.LobbySpecialType.c)) continue;
                player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), team));
                continue;
            }
            if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.c) continue;
            player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), team));
        }
        if (ConfigValue.lobby_team_onchange_wearcloth_enabled && team != null) {
            for (ItemStack itemStack : ConfigValue.lobby_team_onchange_wearcloth_materials) {
                de.marcely.bedwars.util.s.b(player, de.marcely.bedwars.util.i.a(itemStack, team));
            }
        }
    }

    public Map<Enchantment, Integer> a(Player player, Team team, ItemStack itemStack) {
        HashMap<Enchantment, Integer> hashMap = new HashMap<Enchantment, Integer>();
        int n2 = this.a(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj(), team);
        int n3 = this.a(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj(), team);
        if (n2 >= 1 && k.b(itemStack.getType())) {
            hashMap.put(Enchantment.DAMAGE_ALL, n2);
        }
        if (n3 >= 1 && k.a(itemStack.getType())) {
            hashMap.put(Enchantment.PROTECTION_ENVIRONMENTAL, n3);
        }
        return hashMap;
    }

    @Override
    public boolean hasLobby() {
        return this.getLobby().getWorld() != null;
    }

    @Override
    public void setStatus(de.marcely.bedwars.api.ArenaStatus arenaStatus) {
        this.a(arenaStatus.getNms());
    }

    @Override
    public void setStatus(de.marcely.bedwars.api.ArenaStatus arenaStatus, boolean bl2) {
        this.a(arenaStatus.getNms(), bl2);
    }

    @Override
    public int getPerTeamPlayers() {
        return this.getTeamPlayers();
    }

    @Override
    public TeamColors GetTeamColors() {
        return this.a();
    }

    @Nullable
    @Override
    public de.marcely.bedwars.api.Team GetPlayerTeam(Player player) {
        return de.marcely.bedwars.api.Team.fromInternal(this.a(player));
    }

    @Override
    public de.marcely.bedwars.api.ArenaStatus GetStatus() {
        return de.marcely.bedwars.api.ArenaStatus.fromNMS(this.b());
    }

    @Override
    public de.marcely.bedwars.api.RegenerationType GetRegenerationType() {
        return de.marcely.bedwars.api.RegenerationType.fromNMS(this.a());
    }

    @Override
    public HashMap<XYZ, de.marcely.bedwars.api.DropType> getItemSpawners() {
        HashMap<XYZ, de.marcely.bedwars.api.DropType> hashMap = new HashMap<XYZ, de.marcely.bedwars.api.DropType>();
        for (Map.Entry entry : ((MultiKeyMap)((Object)this.a)).entrySet()) {
            hashMap.put((XYZ)entry.getValue(), (de.marcely.bedwars.api.DropType)entry.getKey());
        }
        return hashMap;
    }

    @Override
    public boolean isCurrentlyRegenerating() {
        return this.B();
    }

    @Override
    public de.marcely.bedwars.api.AddPlayerFail addPlayer(Player player) {
        AddPlayerFail addPlayerFail = this.a(player, (Team)null);
        return addPlayerFail != null ? de.marcely.bedwars.api.AddPlayerFail.fromInternal(addPlayerFail) : null;
    }

    @Override
    public de.marcely.bedwars.api.AddPlayerFail addPlayer(Player player, de.marcely.bedwars.api.Team team) {
        AddPlayerFail addPlayerFail = this.a(player, team.getInternal());
        return addPlayerFail != null ? de.marcely.bedwars.api.AddPlayerFail.fromInternal(addPlayerFail) : null;
    }

    @Override
    public boolean kickPlayer(Player player) {
        return this.a(KickReason.c, player);
    }

    @Override
    public boolean kickPlayer(Player player, de.marcely.bedwars.api.KickReason kickReason) {
        return this.a(kickReason.getInternal(), player);
    }

    @Override
    public void kickAllPlayers(de.marcely.bedwars.api.KickReason kickReason) {
        this.a(kickReason.getInternal());
    }

    @Override
    public void _0destroyBed(Player player, Location location, de.marcely.bedwars.api.Team team) {
        this.a(player, location, team.getInternal());
    }

    @Override
    public void _0end(de.marcely.bedwars.api.Team team) {
        this.b(team.getInternal());
    }

    @Override
    public void broadcast(Sound sound) {
        this.a(sound);
    }

    @Override
    public void _0setIngameScoreboard(Player player) {
        this.a.s(player);
    }

    @Override
    public void _0setLobbyScoreboard(Player player) {
        this.a.q(player);
    }

    @Override
    public void addItemSpawner(de.marcely.bedwars.api.DropType dropType, XYZ xYZ) {
        ((MultiKeyMap)((Object)this.a)).put((DropType)dropType, xYZ);
    }

    @Override
    public void setAuthor(String string) {
        this.v(string);
    }

    @Override
    public String getAuthor() {
        return this.n();
    }

    @Override
    public boolean _0remove() {
        return this.c((CommandSender)null);
    }

    @Override
    public void save() {
        de.marcely.bedwars.config.b.b(this);
    }

    @Override
    public void saveBlocks() {
        this.a((de.marcely.bedwars.game.regeneration.c)null);
    }

    @Override
    public long getRunningTime() {
        return 0L;
    }

    @Override
    public boolean hasCustomName() {
        return (Boolean)this.a(f.a.d).getValue();
    }

    @Override
    public String getCustomName() {
        return (String)this.a(f.a.e).getValue();
    }

    @Override
    public String getDisplayName() {
        return this.hasCustomName() ? this.getCustomName() : this.getName();
    }

    @Override
    public void setHasCustomName(boolean bl2) {
        this.a(f.a.d).setValue(bl2);
    }

    @Override
    public void setCustomName(String string) {
        this.a(f.a.e).setValue(string);
    }

    @Override
    public long getGameStartTime() {
        return this.f;
    }

    @Override
    public List<Player> getPlayersInTeam(de.marcely.bedwars.api.Team team) {
        return this.a(team.getInternal());
    }

    @Override
    public List<de.marcely.bedwars.api.Team> getRemainingTeams() {
        List<Team> list = this.a(new Player[0]);
        ArrayList<de.marcely.bedwars.api.Team> arrayList = new ArrayList<de.marcely.bedwars.api.Team>(list.size());
        for (Team team : list) {
            arrayList.add(de.marcely.bedwars.api.Team.fromInternal(team));
        }
        return arrayList;
    }

    @Override
    public XYZ getPosMin() {
        return this.a;
    }

    @Override
    public XYZ getPosMax() {
        return this.b;
    }

    @Override
    public String getName() {
        return this.name;
    }

    public de.marcely.bedwars.game.arena.b a() {
        return this.a;
    }

    @Override
    public World getWorld() {
        return this.world;
    }

    @Override
    public Location getLobby() {
        return this.b;
    }

    public XYZYP a() {
        return this.a;
    }

    public void a(XYZYP xYZYP) {
        this.a = xYZYP;
    }

    public de.marcely.bedwars.game.arena.a a() {
        return this.a;
    }

    @Override
    public boolean isSleeping() {
        return this.B;
    }

    public List<Flag> p() {
        return this.flags;
    }

    public List<d> q() {
        return this.J;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return this.a();
    }

    static /* synthetic */ int[] k() {
        if (j != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[RegenerationType.values().length];
        try {
            arrn[RegenerationType.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[RegenerationType.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[RegenerationType.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        j = arrn;
        return j;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static final class AddPlayerFail
    extends Enum<AddPlayerFail> {
        public static final /* enum */ AddPlayerFail a = new AddPlayerFail();
        public static final /* enum */ AddPlayerFail b = new AddPlayerFail();
        public static final /* enum */ AddPlayerFail c = new AddPlayerFail();
        public static final /* enum */ AddPlayerFail d = new AddPlayerFail();
        public static final /* enum */ AddPlayerFail e = new AddPlayerFail();
        private static final /* synthetic */ AddPlayerFail[] a;

        static {
            a = new AddPlayerFail[]{a, b, c, d, e};
        }

        public static AddPlayerFail[] values() {
            AddPlayerFail[] arraddPlayerFail = a;
            int n2 = arraddPlayerFail.length;
            AddPlayerFail[] arraddPlayerFail2 = new AddPlayerFail[n2];
            System.arraycopy(arraddPlayerFail, 0, arraddPlayerFail2, 0, n2);
            return arraddPlayerFail2;
        }

        public static AddPlayerFail valueOf(String string) {
            return Enum.valueOf(AddPlayerFail.class, string);
        }
    }

    public static class a {
        public final Arena arena;
        public List<Player> P = new ArrayList<Player>();

        public a(Arena arena) {
            this.arena = arena;
        }
    }

    public static class b {
        public final DropType d;
        public final XYZ c;
        public final double value;

        public b(DropType dropType, XYZ xYZ, double d2) {
            this.d = dropType;
            this.c = xYZ;
            this.value = d2;
        }
    }

}

