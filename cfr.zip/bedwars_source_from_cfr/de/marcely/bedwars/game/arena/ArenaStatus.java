/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.h;
import de.marcely.bedwars.message.b;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public enum ArenaStatus {
    d,
    e,
    f,
    g,
    h;
    
    private static /* synthetic */ int[] l;

    public int getID() {
        return this.ordinal() + 1;
    }

    public static ArenaStatus a(int n2) {
        for (ArenaStatus arenaStatus : ArenaStatus.values()) {
            if (arenaStatus.getID() != n2) continue;
            return arenaStatus;
        }
        return null;
    }

    public String o() {
        return this.b(null);
    }

    public String b(Arena arena) {
        switch (ArenaStatus.m()[this.ordinal()]) {
            case 1: {
                return b.a(Language.Sign_Stopped).f(null);
            }
            case 2: {
                if (arena != null) {
                    return b.a(Language.Sign_Lobby).a("ingame", "" + arena.j()).a("max", "" + arena.getMaxPlayers()).f(null);
                }
                return b.a(Language.Sign_Lobby).f(null);
            }
            case 3: {
                return b.a(Language.Sign_Running).f(null);
            }
            case 4: 
            case 5: {
                return b.a(Language.Sign_Reseting).f(null);
            }
        }
        return null;
    }

    public String[] a(Arena arena) {
        String[] arrstring = new String[]{ConfigValue.sign_line1, ConfigValue.sign_line2, ConfigValue.sign_line3, ConfigValue.sign_line4};
        for (int i2 = 0; i2 <= 3; ++i2) {
            arrstring[i2] = arrstring[i2].replace("{arena}", arena.getDisplayName()).replace("{players}", "" + arena.getPlayers().size()).replace("{maxplayers}", "" + arena.getMaxPlayers()).replace("{status}", this.b(arena)).replace("{teams}", "" + arena.a().r().size()).replace("{teamsize}", "" + arena.getTeamPlayers());
        }
        return arrstring;
    }

    public boolean F() {
        return this == e || this == h;
    }

    public boolean G() {
        return this == e || this == f || this == h;
    }

    public boolean H() {
        return this == e || this == f || this == h;
    }

    static /* synthetic */ int[] m() {
        if (l != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ArenaStatus.values().length];
        try {
            arrn[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        l = arrn;
        return l;
    }
}

