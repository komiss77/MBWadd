/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.MBedwars;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class e {
    private int O;
    private int R;
    private double value;
    private List<Player> players;
    private BukkitTask c;
    private int S;
    private boolean M = false;

    public e(int n2, int n3, int n4, List<Player> list) {
        this.O = n2;
        this.value = n3;
        this.R = n4;
        this.players = list;
    }

    public int n() {
        return this.O;
    }

    public int getValue() {
        return (int)this.value;
    }

    public int o() {
        return this.R;
    }

    public List<Player> getPlayers() {
        return this.players;
    }

    public void H() {
        if (this.M) {
            new SecurityException("Already stopped").printStackTrace();
        }
        if (this.c != null) {
            return;
        }
        this.value -= 1.0 / (double)this.O;
        this.update();
    }

    public void setValue(int n2) {
        this.b(n2, true);
    }

    public void b(int n2, boolean bl2) {
        if (this.M) {
            new SecurityException("Already stopped").printStackTrace();
        }
        if (!bl2) {
            if (this.c != null) {
                this.c.cancel();
                this.value = this.S;
            }
            int n3 = 20;
            final e e2 = this;
            double d2 = (double)n2 - this.value;
            final double d3 = d2 / 20.0;
            this.S = n2;
            this.c = new BukkitRunnable(){
                private int r = 0;

                public void run() {
                    ++this.r;
                    e e22 = e2;
                    e.a(e22, e22.value + d3);
                    e.this.update();
                    if (this.r >= 20) {
                        e.a(e2, null);
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
        } else {
            this.value = n2;
        }
    }

    public boolean stop() {
        if (!this.M && this.c != null) {
            this.c.cancel();
            this.M = true;
            return true;
        }
        return false;
    }

    private boolean update() {
        float f2 = (float)(this.value / (double)this.R);
        if (f2 < 0.0f || f2 > 1.0f) {
            this.stop();
            return false;
        }
        for (Player player : this.players) {
            player.setLevel((int)this.value);
            player.setExp(f2);
        }
        return true;
    }

    public boolean I() {
        return this.c != null;
    }

    public boolean isStopped() {
        return this.M;
    }

    static /* synthetic */ void a(e e2, double d2) {
        e2.value = d2;
    }

    static /* synthetic */ void a(e e2, BukkitTask bukkitTask) {
        e2.c = bukkitTask;
    }

}

