/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 */
package de.marcely.bedwars.game;

import java.io.Serializable;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class SimpleBlock
implements Serializable {
    private static final long serialVersionUID = 1280731586616867212L;
    public int x;
    public int y;
    public int z;
    public String block;
    public Byte data;

    public SimpleBlock() {
    }

    public SimpleBlock(Location location, Material material) {
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
        this.block = material.toString();
    }

    public SimpleBlock(Block block) {
        this.x = block.getLocation().getBlockX();
        this.y = block.getLocation().getBlockY();
        this.z = block.getLocation().getBlockZ();
        this.block = block.getType().toString();
        this.data = block.getData();
    }

    public SimpleBlock(int n2, int n3, int n4, Material material) {
        this.x = n2;
        this.y = n3;
        this.z = n4;
        this.block = material.toString();
    }

    public SimpleBlock(int n2, int n3, int n4, Material material, Byte by2) {
        this.x = n2;
        this.y = n3;
        this.z = n4;
        this.data = by2;
        this.block = material.toString();
    }

    public Material getMaterial() {
        return Material.getMaterial((String)this.block);
    }
}

