/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Score
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.Team
 */
package de.marcely.bedwars.game;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class c {
    private final String name;
    private final String z;
    private final Scoreboard a;
    private final Objective a;
    String title;
    private a[] a = new a[0];
    private List<a> F = new ArrayList<a>();
    private boolean finished = false;

    public c(String string, String string2, String string3) {
        this.name = string;
        this.z = string2;
        this.title = string3;
        this.a = Bukkit.getScoreboardManager().getNewScoreboard();
        this.a = this.a.registerNewObjective(string, string2);
        this.a.setDisplaySlot(DisplaySlot.SIDEBAR);
        this.a.setDisplayName(string3);
    }

    public void setTitle(String string) {
        this.title = string;
        this.a.setDisplayName(string);
    }

    public void i(Player player) {
        player.setScoreboard(this.a);
    }

    @Nullable
    public a a(String string) {
        if (this.finished) {
            new NullPointerException("Can not add rows if scoreboard is already finished").printStackTrace();
            return null;
        }
        try {
            a a2 = new a(this, string, this.a.length);
            this.F.add(a2);
            return a2;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public void finish() {
        if (this.finished) {
            new NullPointerException("Can not finish if scoreboard is already finished").printStackTrace();
            return;
        }
        this.finished = true;
        for (int i2 = this.F.size() - 1; i2 >= 0; --i2) {
            a a2 = this.F.get(i2);
            Team team = this.a.registerNewTeam(String.valueOf(this.name) + "." + this.z + "." + (i2 + 1));
            team.addEntry("" + (Object)ChatColor.values()[i2]);
            this.a.getScore("" + (Object)ChatColor.values()[i2]).setScore(this.F.size() - i2);
            a.a(a2, team);
            a2.setMessage(a2.message);
        }
        this.a = this.F.toArray(new a[this.F.size()]);
    }

    public String getName() {
        return this.name;
    }

    public String j() {
        return this.z;
    }

    public String getTitle() {
        return this.title;
    }

    public a[] a() {
        return this.a;
    }

    /*
     * Duplicate member names - consider using --renamedupmembers true
     */
    public static class a {
        private final c a;
        private Team a;
        private final int L;
        private String message;

        public a(c c2, String string, int n2) {
            this.a = c2;
            this.L = n2;
            this.message = string;
        }

        public void setMessage(String string) {
            this.message = string;
            if (this.a.finished) {
                String[] arrstring = a.b(string);
                this.a.setPrefix(arrstring[0]);
                this.a.setSuffix(arrstring[1]);
            }
        }

        private static String[] b(String string) {
            String[] arrstring = new String[2];
            ChatColor chatColor = ChatColor.WHITE;
            String string2 = null;
            Character c2 = null;
            arrstring[0] = "";
            for (int i2 = 0; i2 < string.length() / 2; ++i2) {
                char c3 = string.charAt(i2);
                if (c2 != null) {
                    ChatColor chatColor2 = a.a(new char[]{c2.charValue(), c3});
                    if (chatColor2 != null) {
                        if (chatColor2.isFormat()) {
                            string2 = chatColor2;
                        } else {
                            chatColor = chatColor2;
                            string2 = null;
                        }
                    }
                }
                String[] arrstring2 = arrstring;
                arrstring2[0] = String.valueOf(arrstring2[0]) + c3;
                c2 = Character.valueOf(c3);
            }
            arrstring[1] = (chatColor != null ? chatColor : "") + (string2 != null ? string2 : "") + string.substring(string.length() / 2);
            return arrstring;
        }

        @Nullable
        private static ChatColor a(char[] arrc) {
            for (ChatColor chatColor : ChatColor.values()) {
                char[] arrc2 = chatColor.toString().toCharArray();
                int n2 = 0;
                for (int i2 = 0; i2 < 2; ++i2) {
                    if (arrc2[i2] != arrc[i2]) continue;
                    ++n2;
                }
                if (n2 != 2) continue;
                return chatColor;
            }
            return null;
        }

        public c a() {
            return this.a;
        }

        public int i() {
            return this.L;
        }

        public String getMessage() {
            return this.message;
        }

        static /* synthetic */ void a(a a2, Team team) {
            a2.a = team;
        }
    }

}

