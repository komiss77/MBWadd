/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.inventory.ItemStack
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.j;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class t
extends j {
    private Arena arena;
    private ItemStack a;

    public t(Arena arena, ItemStack itemStack) {
        this.arena = arena;
        this.a = itemStack;
    }

    public Arena getArena() {
        return this.arena;
    }

    public ItemStack a() {
        return this.a;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.l.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.a.getType().name() + ":" + this.a.getDurability();
    }
}

