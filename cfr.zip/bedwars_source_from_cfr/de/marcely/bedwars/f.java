/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.d;
import de.marcely.bedwars.h;
import de.marcely.bedwars.i;
import de.marcely.bedwars.j;
import de.marcely.bedwars.m;
import de.marcely.bedwars.util.s;
import java.net.InetAddress;
import java.net.UnknownHostException;
import org.bukkit.entity.Player;

public class f {
    private String name;
    private String e;
    private int port;
    private InetAddress address;

    public f(String string) {
        block7 : {
            this.port = -1;
            this.name = "";
            String[] arrstring = string.split(":");
            if (arrstring.length == 2) {
                if (s.isInteger(arrstring[1])) {
                    this.e = arrstring[0];
                    this.port = Integer.valueOf(arrstring[1]);
                    try {
                        if (arrstring[0].equals("localhost") || arrstring[0].equals("127.0.0.1")) {
                            this.address = InetAddress.getLocalHost();
                            break block7;
                        }
                        this.address = InetAddress.getByName(arrstring[0]);
                    }
                    catch (UnknownHostException unknownHostException) {
                        d.d("Failed to register channel InetAddress:");
                        unknownHostException.printStackTrace();
                        string = null;
                        this.port = -1;
                    }
                } else {
                    d.d("WRONG bungeecord-hub-address CONSTRUCTION!! (port is numeric)");
                    string = null;
                    this.port = -1;
                }
            } else {
                d.d("WRONG bungeecord-hub-address CONSTRUCTION!!");
                string = null;
                this.port = -1;
            }
        }
    }

    public f(String string, int n2) {
        this("", string, n2);
    }

    public f(String string, String string2, int n2) {
        this.port = -1;
        this.name = string;
        this.e = string2;
        this.port = n2;
        try {
            this.address = InetAddress.getByName(string2);
        }
        catch (UnknownHostException unknownHostException) {
            d.d("Failed to register channel InetAddress:");
            unknownHostException.printStackTrace();
        }
    }

    public boolean h() {
        return this.e != null;
    }

    public void setName(String string) {
        this.name = string;
    }

    public String getName() {
        return this.name;
    }

    public String getIP() {
        return this.e;
    }

    public int getPort() {
        return this.port;
    }

    public InetAddress getInetAddress() {
        return this.address;
    }

    public void a(j j2) {
        h.b(new i(j2, this));
    }

    public void c(Player player) {
        m.a(player, this.getName());
    }
}

