/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cA;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.Map;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.FoodLevelChangeEvent;

public class aI {
    public static void a(FoodLevelChangeEvent foodLevelChangeEvent) {
        if (foodLevelChangeEvent.getEntity().getType() == EntityType.PLAYER) {
            Player player = (Player)foodLevelChangeEvent.getEntity();
            Arena arena = s.a(player);
            if (arena != null) {
                if (arena.b().F() || !ConfigValue.hunger) {
                    foodLevelChangeEvent.setCancelled(true);
                }
            } else if (cA.E.containsKey((Object)player)) {
                foodLevelChangeEvent.setCancelled(true);
            }
        }
    }
}

