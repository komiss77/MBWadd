/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

public class bp
extends Exception {
    private static final long serialVersionUID = 1L;

    public bp() {
        this("Not synchronized!");
    }

    public bp(String string) {
        super(string);
    }
}

