/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  systems.reformcloud.ReformCloudAPISpigot
 *  systems.reformcloud.meta.enums.ServerState
 *  systems.reformcloud.meta.info.ServerInfo
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.cZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.util.s;
import java.util.List;
import org.bukkit.entity.Player;
import systems.reformcloud.ReformCloudAPISpigot;
import systems.reformcloud.meta.enums.ServerState;
import systems.reformcloud.meta.info.ServerInfo;

public class dd
extends cZ {
    private d a;
    private static /* synthetic */ int[] l;

    @Override
    public cT a() {
        return cT.f;
    }

    @Override
    public void onEnable() {
        Arena arena = s.b(ConfigValue.cloudsystem_arena);
        if (arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.f(arena);
        this.a = new d(){

            @Override
            public void a(Arena arena, d.a a2) {
                dd.this.f(arena);
            }
        };
        arena.a(this.a);
    }

    private void f(Arena arena) {
        ServerInfo serverInfo = ReformCloudAPISpigot.getInstance().getServerInfo();
        serverInfo.setMotd(ConfigValue.cloudsystem_extra.a(arena));
        serverInfo.setOnline(arena.getPlayers().size());
        serverInfo.setServerState(this.a(arena.b()));
    }

    private ServerState a(ArenaStatus arenaStatus) {
        switch (dd.m()[arenaStatus.ordinal()]) {
            case 1: 
            case 3: {
                return ServerState.HIDDEN;
            }
            case 2: {
                return ServerState.READY;
            }
            case 4: 
            case 5: {
                return ServerState.NOT_READY;
            }
        }
        return ServerState.READY;
    }

    @Override
    public void onDisable() {
        Arena arena = s.b(ConfigValue.cloudsystem_arena);
        if (arena != null) {
            arena.a(this.a);
        }
    }

    static /* synthetic */ int[] m() {
        if (l != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ArenaStatus.values().length];
        try {
            arrn[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        l = arrn;
        return l;
    }

}

