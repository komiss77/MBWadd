/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  me.MathiasMC.PvPLevels.PvPLevelsAPI
 *  org.bukkit.entity.Player
 */
package de.marcely.bedwars;

import de.marcely.bedwars.cT;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import me.MathiasMC.PvPLevels.PvPLevelsAPI;
import org.bukkit.entity.Player;

public class dj
extends dg {
    private PvPLevelsAPI a;
    private static /* synthetic */ int[] q;

    @Override
    public cT a() {
        return cT.p;
    }

    @Override
    public void onEnable() {
        this.a = new PvPLevelsAPI();
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void a(Player player, df df2) {
        switch (dj.r()[df2.ordinal()]) {
            case 1: {
                this.d(player, ConfigValue.pvplevels_exp_win);
                break;
            }
            case 2: {
                this.d(player, ConfigValue.pvplevels_exp_lose);
                break;
            }
            case 3: {
                this.d(player, ConfigValue.pvplevels_exp_beddestroy);
                break;
            }
            case 4: {
                this.d(player, ConfigValue.pvplevels_exp_killplayer);
            }
        }
    }

    private void d(Player player, int n2) {
        this.a.AddXP(player, Integer.valueOf(n2));
        while (this.a.CurrentXP(player) >= this.a.CurrentXPRequired(player)) {
            this.a.RemoveXP(player, Integer.valueOf(this.a.CurrentXPRequired(player)));
            this.a.AddLevel(player, Integer.valueOf(1));
        }
    }

    static /* synthetic */ int[] r() {
        if (q != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[df.values().length];
        try {
            arrn[df.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[df.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        q = arrn;
        return q;
    }
}

