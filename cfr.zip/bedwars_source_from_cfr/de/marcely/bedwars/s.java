/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.j;

public class s
extends j {
    private Arena arena;

    public s(Arena arena) {
        this.arena = arena;
    }

    public Arena getArena() {
        return this.arena;
    }

    @Override
    public String d() {
        return String.valueOf(j.a.g.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;");
    }
}

