/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketNack
extends Packet {
    public Byte[] windows;

    @Override
    public byte getType() {
        return 6;
    }

    @Override
    protected void _encode(BufferedWriteStream bufferedWriteStream) {
        Byte[] arrbyte = this.windows;
        int n2 = arrbyte.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            byte by2 = arrbyte[i2];
            bufferedWriteStream.write(by2);
        }
    }

    @Override
    protected void _decode(BufferedReadStream bufferedReadStream) {
        this.windows = new Byte[bufferedReadStream.available()];
        for (int i2 = 0; i2 < this.windows.length; ++i2) {
            this.windows[i2] = bufferedReadStream.readByte();
        }
    }
}

