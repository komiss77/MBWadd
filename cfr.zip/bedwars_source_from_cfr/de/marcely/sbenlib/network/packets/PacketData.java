/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.crypto.spec.SecretKeySpec;

public class PacketData
extends Packet {
    public DataPacket data;
    public PacketsData packetsData;
    public SecretKeySpec _key;

    @Override
    public byte getType() {
        return 2;
    }

    @Override
    protected void _encode(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.data.getPacketID());
        this.data.encode(bufferedWriteStream);
    }

    @Override
    protected void _decode(BufferedReadStream bufferedReadStream) {
        byte by2 = bufferedReadStream.readByte();
        this.data = this.packetsData.getPacket(by2);
        if (this.data != null) {
            this.data.set_key(this._key);
            this.data.decode(bufferedReadStream);
        }
    }
}

