/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketLogin
extends Packet {
    public byte[] security_id;
    public int version_protocol;

    @Override
    public byte getType() {
        return 0;
    }

    @Override
    protected void _encode(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.write(this.security_id);
        bufferedWriteStream.writeUnsignedShort(this.version_protocol);
    }

    @Override
    protected void _decode(BufferedReadStream bufferedReadStream) {
        this.security_id = bufferedReadStream.read(16);
        this.version_protocol = bufferedReadStream.readUnsignedShort();
    }
}

