/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketClose
extends Packet {
    public String reason = "UNKOWN";

    @Override
    public byte getType() {
        return 7;
    }

    @Override
    protected void _encode(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.reason);
    }

    @Override
    protected void _decode(BufferedReadStream bufferedReadStream) {
        this.reason = bufferedReadStream.readString();
    }
}

