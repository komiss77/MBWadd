/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets.data;

import de.marcely.sbenlib.compression.AES;
import de.marcely.sbenlib.network.packets.data.NormalPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.IOException;
import javax.crypto.spec.SecretKeySpec;

public abstract class SecuredPacket
extends NormalPacket {
    @Override
    public byte getTypeID() {
        return 1;
    }

    @Override
    public abstract byte getPacketID();

    @Override
    protected abstract void write(BufferedWriteStream var1);

    @Override
    protected abstract void read(BufferedReadStream var1);

    @Override
    public void encode(BufferedWriteStream bufferedWriteStream) {
        if (this._key == null) {
            new NullPointerException("Missing key/session").printStackTrace();
            return;
        }
        BufferedWriteStream bufferedWriteStream2 = new BufferedWriteStream();
        this.write(bufferedWriteStream2);
        bufferedWriteStream.write(AES.encrypt(bufferedWriteStream2.toByteArray(), this._key));
        bufferedWriteStream2.close();
    }

    @Override
    public void decode(BufferedReadStream bufferedReadStream) {
        if (this._key == null) {
            new NullPointerException("Missing key/session").printStackTrace();
            return;
        }
        BufferedReadStream bufferedReadStream2 = new BufferedReadStream(AES.decrypt(bufferedReadStream.read(bufferedReadStream.available()), this._key));
        this.read(bufferedReadStream2);
        try {
            bufferedReadStream2.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }
}

