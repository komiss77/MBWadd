/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets.data;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.crypto.spec.SecretKeySpec;

public abstract class DataPacket {
    protected SecretKeySpec _key;
    public static final byte TYPE_NORMAL = 0;
    public static final byte TYPE_SECURED = 1;

    public abstract byte getTypeID();

    public abstract byte getPacketID();

    public abstract void encode(BufferedWriteStream var1);

    public abstract void decode(BufferedReadStream var1);

    public void set_key(SecretKeySpec secretKeySpec) {
        this._key = secretKeySpec;
    }
}

