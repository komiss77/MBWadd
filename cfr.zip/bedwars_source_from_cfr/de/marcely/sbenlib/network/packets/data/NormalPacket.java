/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets.data;

import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class NormalPacket
extends DataPacket {
    @Override
    public byte getTypeID() {
        return 0;
    }

    @Override
    public abstract byte getPacketID();

    protected abstract void write(BufferedWriteStream var1);

    protected abstract void read(BufferedReadStream var1);

    @Override
    public void encode(BufferedWriteStream bufferedWriteStream) {
        this.write(bufferedWriteStream);
    }

    @Override
    public void decode(BufferedReadStream bufferedReadStream) {
        this.read(bufferedReadStream);
    }
}

