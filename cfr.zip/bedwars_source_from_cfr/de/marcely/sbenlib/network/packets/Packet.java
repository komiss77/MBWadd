/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.IOException;

public abstract class Packet {
    public boolean _needACK;
    public static final byte TYPE_LOGIN = 0;
    public static final byte TYPE_LOGIN_REPLY = 1;
    public static final byte TYPE_DATA = 2;
    public static final byte TYPE_PING = 3;
    public static final byte TYPE_PONG = 4;
    public static final byte TYPE_ACK = 5;
    public static final byte TYPE_NACK = 6;
    public static final byte TYPE_CLOSE = 7;

    public byte[] encode() {
        BufferedWriteStream bufferedWriteStream = new BufferedWriteStream();
        byte by2 = 0;
        by2 = (byte)(by2 | this.getType() << 1);
        bufferedWriteStream.writeByte(by2);
        this._encode(bufferedWriteStream);
        bufferedWriteStream.close();
        return bufferedWriteStream.toByteArray();
    }

    public void decode(byte[] arrby) {
        BufferedReadStream bufferedReadStream = new BufferedReadStream(arrby);
        bufferedReadStream.readByte();
        this._decode(bufferedReadStream);
        try {
            bufferedReadStream.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public static byte getTypeOfHeader(byte by2) {
        return (byte)(by2 >> 1 & 7);
    }

    public abstract byte getType();

    protected abstract void _encode(BufferedWriteStream var1);

    protected abstract void _decode(BufferedReadStream var1);
}

