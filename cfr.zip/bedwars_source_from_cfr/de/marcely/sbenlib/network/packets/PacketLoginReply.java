/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketLoginReply
extends Packet {
    public static final byte REPLY_SUCCESS = 0;
    public static final byte REPLY_FAILED_PROTOCOL_OUTDATED_CLIENT = 1;
    public static final byte REPLY_FAILED_PROTOCOL_OUTDATED_SERVER = 2;
    public static final byte REPLY_FAILED_UNKOWN = 3;
    public byte reply;

    @Override
    public byte getType() {
        return 1;
    }

    @Override
    protected void _encode(BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.reply);
    }

    @Override
    protected void _decode(BufferedReadStream bufferedReadStream) {
        this.reply = bufferedReadStream.readByte();
    }
}

