/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.network;

import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.PacketClose;
import de.marcely.sbenlib.network.packets.PacketData;
import de.marcely.sbenlib.network.packets.PacketLogin;
import de.marcely.sbenlib.network.packets.PacketLoginReply;
import de.marcely.sbenlib.network.packets.PacketNack;
import de.marcely.sbenlib.network.packets.PacketPing;
import de.marcely.sbenlib.network.packets.PacketPong;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.network.packets.data.SecuredPacket;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;

public class PacketDecoder {
    @Nullable
    public static Packet decode(PacketsData packetsData, SecretKeySpec secretKeySpec, byte[] arrby) throws Exception {
        if (arrby.length == 0) {
            return null;
        }
        byte by2 = Packet.getTypeOfHeader(arrby[0]);
        switch (by2) {
            case 0: {
                PacketLogin packetLogin = new PacketLogin();
                packetLogin.decode(arrby);
                return packetLogin;
            }
            case 1: {
                PacketLoginReply packetLoginReply = new PacketLoginReply();
                packetLoginReply.decode(arrby);
                return packetLoginReply;
            }
            case 2: {
                PacketData packetData = new PacketData();
                packetData.packetsData = packetsData;
                packetData._key = secretKeySpec;
                packetData.decode(arrby);
                if (packetData.data != null && packetData.data instanceof SecuredPacket) {
                    ((SecuredPacket)packetData.data).set_key(secretKeySpec);
                }
                return packetData;
            }
            case 5: {
                PacketAck packetAck = new PacketAck();
                packetAck.decode(arrby);
                return packetAck;
            }
            case 6: {
                PacketNack packetNack = new PacketNack();
                packetNack.decode(arrby);
                return packetNack;
            }
            case 3: {
                PacketPing packetPing = new PacketPing();
                packetPing.decode(arrby);
                return packetPing;
            }
            case 4: {
                PacketPong packetPong = new PacketPong();
                packetPong.decode(arrby);
                return packetPong;
            }
            case 7: {
                PacketClose packetClose = new PacketClose();
                packetClose.decode(arrby);
                return packetClose;
            }
        }
        return null;
    }
}

