/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network;

public class Network {
    public static final int PROTOCOL_VERSION = 3;
    public static final int SECURITYID_LENGTH = 16;
    public static final long PING_UPDATE = 1500L;
    public static final long TIMEOUT = 6000L;
}

