/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network;

import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.client.protocol.Protocol;
import de.marcely.sbenlib.client.protocol.TCPProtocol;
import de.marcely.sbenlib.client.protocol.UDPProtocol;
import de.marcely.sbenlib.network.ConnectionInfo;

public enum ProtocolType {
    UDP(true, 512),
    TCP(false, 1500);
    
    private final boolean requiresAckNack;
    private final int maxPacketSize;
    private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType;

    private ProtocolType(boolean bl2, int n3) {
        this.requiresAckNack = bl2;
        this.maxPacketSize = n3;
    }

    public Protocol getClientInstance(ConnectionInfo connectionInfo, SocketHandler socketHandler, ServerEventListener serverEventListener) {
        switch (ProtocolType.$SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType()[this.ordinal()]) {
            case 1: {
                return new UDPProtocol(connectionInfo, socketHandler, serverEventListener);
            }
            case 2: {
                return new TCPProtocol(connectionInfo, socketHandler, serverEventListener);
            }
        }
        return null;
    }

    public boolean isRequiresAckNack() {
        return this.requiresAckNack;
    }

    public int getMaxPacketSize() {
        return this.maxPacketSize;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType() {
        if ($SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[ProtocolType.values().length];
        try {
            arrn[ProtocolType.TCP.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ProtocolType.UDP.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType = arrn;
        return $SWITCH_TABLE$de$marcely$sbenlib$network$ProtocolType;
    }
}

