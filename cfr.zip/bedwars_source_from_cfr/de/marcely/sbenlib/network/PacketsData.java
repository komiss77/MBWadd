/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network;

import de.marcely.sbenlib.network.packets.data.DataPacket;
import java.util.HashMap;
import java.util.Map;

public class PacketsData {
    private Map<Byte, DataPacket> packets = new HashMap<Byte, DataPacket>();

    public void addPacket(DataPacket dataPacket) {
        this.packets.put(dataPacket.getPacketID(), dataPacket);
    }

    public void addPackets(DataPacket ... arrdataPacket) {
        for (DataPacket dataPacket : arrdataPacket) {
            this.addPacket(dataPacket);
        }
    }

    public void removePacket(byte by2) {
        this.packets.remove(by2);
    }

    public DataPacket getPacket(byte by2) {
        return this.packets.get(by2);
    }

    public Map<Byte, DataPacket> getPackets() {
        return this.packets;
    }

    public void setPackets(Map<Byte, DataPacket> map) {
        this.packets = map;
    }
}

