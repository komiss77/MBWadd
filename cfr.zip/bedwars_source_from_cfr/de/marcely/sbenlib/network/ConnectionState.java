/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network;

public enum ConnectionState {
    NotStarted,
    Connecting,
    Connected,
    Disconnected;
    
}

