/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.network;

import de.marcely.sbenlib.compression.CompressionType;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.util.Util;
import java.net.InetAddress;

public class ConnectionInfo {
    public final InetAddress ip;
    public final int port;
    public final ProtocolType protocol;
    public final CompressionType compression;

    public ConnectionInfo(String string, int n2) {
        this(Util.getInetAddress(string), n2);
    }

    public ConnectionInfo(InetAddress inetAddress, int n2) {
        this(inetAddress, n2, ProtocolType.TCP, CompressionType.ZLib);
    }

    public ConnectionInfo(String string, int n2, ProtocolType protocolType, CompressionType compressionType) {
        this(Util.getInetAddress(string), n2, protocolType, compressionType);
    }

    public ConnectionInfo(InetAddress inetAddress, int n2, ProtocolType protocolType, CompressionType compressionType) {
        this.ip = inetAddress;
        this.port = n2;
        this.protocol = protocolType;
        this.compression = compressionType;
    }
}

