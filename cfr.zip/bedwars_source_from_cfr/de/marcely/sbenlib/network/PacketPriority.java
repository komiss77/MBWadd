/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.network;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;

public enum PacketPriority {
    NORMAL(0, false),
    DONT_LOSE(1, true),
    DONT_LOSE_AND_SORTED(2, true);
    
    private static Map<Byte, PacketPriority> VALUES;
    private final byte id;
    private final boolean sendAck;

    static {
        VALUES = new HashMap<Byte, PacketPriority>();
        for (PacketPriority packetPriority : PacketPriority.values()) {
            VALUES.put(packetPriority.id, packetPriority);
        }
    }

    private PacketPriority(byte by2, boolean bl2) {
        this.id = by2;
        this.sendAck = bl2;
    }

    @Nullable
    public static PacketPriority fromId(byte by2) {
        return VALUES.get(by2);
    }

    public byte getId() {
        return this.id;
    }

    public boolean isSendAck() {
        return this.sendAck;
    }
}

