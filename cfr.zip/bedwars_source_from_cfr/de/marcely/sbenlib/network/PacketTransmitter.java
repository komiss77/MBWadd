/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.network;

import de.marcely.sbenlib.compression.Compressor;
import de.marcely.sbenlib.network.PacketDecoder;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.PacketNack;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;

public abstract class PacketTransmitter {
    private static final int PACKET_HEADER_SIZE = 2;
    private static final int WINDOW_HIGHEST = 127;
    private static final int WINDOW_LOWEST = -127;
    private static final byte SORT_TYPE_START = 0;
    private static final byte SORT_TYPE_MIDDLE = 1;
    private static final byte SORT_TYPE_END = 2;
    private static final byte SORT_TYPE_SOLO = 3;
    private final PacketsData packets;
    private final int packetSize;
    private final Compressor compressor;
    private byte currentSendWindow = 0;
    private byte currentReceiveWindow = 1;
    private Map<Byte, byte[]> notAckedSendPackets = new HashMap<Byte, byte[]>();
    private Map<Byte, byte[]> queueSplitReceivePackets = new TreeMap<Byte, byte[]>();
    private List<Byte> missingPackets = new ArrayList<Byte>();
    private SecretKeySpec key;

    public PacketTransmitter(PacketsData packetsData, int n2, Compressor compressor) {
        this.packets = packetsData;
        this.packetSize = n2 - 2;
        this.compressor = compressor;
    }

    public void sendNacks() {
        if (this.missingPackets.size() == 0) {
            return;
        }
        PacketNack packetNack = new PacketNack();
        packetNack.windows = this.missingPackets.toArray(new Byte[this.missingPackets.size()]);
        try {
            this.sendPacket(packetNack, false);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void sendPacket(Packet packet, boolean bl2) throws Exception {
        int n2;
        int n3;
        boolean bl3;
        byte[] arrby;
        byte[] arrby2;
        byte[] arrby3 = packet.encode();
        if (this.compressor != null) {
            arrby = this.compressor.encode(arrby3);
            if (arrby.length < arrby3.length) {
                bl3 = true;
                arrby2 = arrby;
            } else {
                bl3 = false;
                arrby2 = arrby3;
            }
        } else {
            bl3 = false;
            arrby2 = arrby3;
        }
        arrby = new byte[(int)java.lang.Math.ceil((double)arrby2.length / (double)this.packetSize)][];
        if (arrby.length == 0) {
            arrby = new byte[1][2];
        } else {
            for (n2 = 0; n2 < arrby.length; ++n2) {
                n3 = arrby2.length - n2 * this.packetSize;
                if (n3 > this.packetSize) {
                    n3 = this.packetSize;
                }
                arrby[n2] = (byte)new byte[n3 + 2];
                System.arraycopy(arrby2, n2 * this.packetSize, arrby[n2], 2, n3);
            }
        }
        if (arrby.length >= 2) {
            bl2 = true;
            if (this.currentSendWindow + arrby.length > 127) {
                this.currentSendWindow = (byte)-128;
            }
        }
        for (n2 = 0; n2 < arrby.length; ++n2) {
            n3 = 3;
            if (arrby.length >= 2) {
                n3 = n2 == 0 ? 0 : (n2 + 1 == arrby.length ? 2 : 1);
            }
            arrby[n2][0] = (byte)(n3 | (bl2 ? 1 : 0) << 2 | (bl3 ? 1 : 0) << 3);
            arrby[n2][1] = bl2 ? this.getNextSendWindow() : (byte)0;
            this.send((byte[])arrby[n2]);
            if (!bl2) continue;
            this.notAckedSendPackets.put((byte)arrby[n2][1], (byte[])arrby[n2]);
        }
    }

    public void receiveAck(byte by2) {
        this.notAckedSendPackets.remove(by2);
    }

    public void receiveNack(byte by2) {
        byte[] arrby = this.notAckedSendPackets.get(by2);
        if (arrby != null) {
            this.send(arrby);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void handlePacket(byte[] var1_1) throws Exception {
        block18 : {
            block17 : {
                block14 : {
                    block15 : {
                        block16 : {
                            if (var1_1.length < 2) {
                                return;
                            }
                            var2_2 = (var1_1[0] & 8) == 8;
                            var3_3 = (var1_1[0] & 4) == 4;
                            var4_4 = (byte)(var1_1[0] & 3);
                            var5_5 = var1_1[1];
                            if (var3_3) {
                                var6_6 = new PacketAck();
                                var6_6.windows = new Byte[]{var5_5};
                                this.sendPacket((Packet)var6_6, false);
                            }
                            var6_6 = new byte[var1_1.length - 2];
                            System.arraycopy(var1_1, 2, var6_6, 0, var6_6.length);
                            if (!var3_3) break block14;
                            if (var5_5 == this.currentReceiveWindow) break block15;
                            if (var5_5 <= this.currentReceiveWindow) break block16;
                            var7_7 = this.currentReceiveWindow;
                            ** GOTO lbl29
                        }
                        if (this.missingPackets.contains(var5_5)) {
                            this.missingPackets.remove((Object)var5_5);
                        }
                        break block14;
                    }
                    this.currentReceiveWindow = this.getNextWindow(var5_5);
                    break block14;
lbl-1000: // 1 sources:
                    {
                        this.missingPackets.add(var7_7);
                        var7_7 = (byte)(var7_7 + 1);
lbl29: // 2 sources:
                        ** while (var7_7 < var5_5)
                    }
lbl30: // 1 sources:
                    this.currentReceiveWindow = this.getNextWindow(var5_5);
                }
                if (var4_4 == 3) {
                    this.handleData(var6_6, var2_2);
                    return;
                }
                var7_8 = null;
                var8_9 = null;
                if (var4_4 == 0) {
                    var7_8 = var5_5;
                } else if (var4_4 == 2) {
                    var8_9 = var5_5;
                }
                if (var7_8 != null) break block17;
                var7_8 = var5_5;
                ** GOTO lbl52
lbl-1000: // 1 sources:
                {
                    var9_10 = this.queueSplitReceivePackets.get(var7_8);
                    if (var9_10 == null) {
                        this.queueSplitReceivePackets.put(var5_5, var1_1);
                        return;
                    }
                    var10_12 = (byte)(var9_10[0] & 3);
                    if (var10_12 == 0) break;
lbl52: // 2 sources:
                    v0 = var7_8;
                    var7_8 = (byte)(v0 - 1);
                    ** while (v0.byteValue() >= -127)
                }
            }
            if (var8_9 != null) break block18;
            var8_9 = var5_5;
            ** GOTO lbl66
lbl-1000: // 1 sources:
            {
                var9_10 = this.queueSplitReceivePackets.get(var8_9);
                if (var9_10 == null) {
                    this.queueSplitReceivePackets.put(var5_5, var1_1);
                    return;
                }
                var10_12 = (byte)(var9_10[0] & 3);
                if (var10_12 == 2) break;
lbl66: // 2 sources:
                v1 = var8_9;
                var8_9 = (byte)(v1 + 1);
                ** while (v1.byteValue() <= 127)
            }
        }
        if (var4_4 == 2) {
            this.queueSplitReceivePackets.put(var5_5, var1_1);
        }
        var9_11 = var8_9 - var7_8 + 1;
        var10_13 = new byte[(var9_11 - 1) * this.packetSize + this.queueSplitReceivePackets.get(var8_9).length - 2];
        for (var11_14 = var7_8.byteValue(); var11_14 <= var8_9; var11_14 = (byte)(var11_14 + 1)) {
            var12_15 = this.queueSplitReceivePackets.remove(var11_14);
            System.arraycopy(var12_15, 2, var10_13, (var11_14 - var7_8) * this.packetSize, var12_15.length - 2);
        }
        this.handleData(var10_13, var2_2);
    }

    private void handleData(byte[] arrby, boolean bl2) throws Exception {
        Packet packet;
        if (bl2 && this.compressor != null) {
            arrby = this.compressor.decode(arrby);
        }
        if ((packet = PacketDecoder.decode(this.packets, this.key, arrby)) != null) {
            this.receive(packet);
        }
    }

    @Nullable
    private Byte getNextSendWindow() {
        this.currentSendWindow = this.getNextWindow(this.currentSendWindow);
        return this.currentSendWindow;
    }

    private byte getNextWindow(byte by2) {
        return (byte)(by2 + 1);
    }

    protected abstract void send(byte[] var1);

    public abstract void receive(Packet var1);

    public void setKey(SecretKeySpec secretKeySpec) {
        this.key = secretKeySpec;
    }
}

