/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class BufferedWriteStream
extends OutputStream {
    private OutputStream stream;
    private byte[] buffer;
    private int count = 0;

    public BufferedWriteStream(OutputStream outputStream) {
        this.stream = outputStream;
    }

    public BufferedWriteStream(int n2) {
        if (n2 < 0) {
            throw new IllegalArgumentException("Negative initial size: " + n2);
        }
        this.buffer = new byte[n2];
    }

    public BufferedWriteStream() {
        this(32);
    }

    @Override
    public void write(int n2) {
        if (this.stream != null) {
            try {
                this.stream.write(n2);
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        } else {
            int n3 = this.count + 1;
            if (n3 > this.buffer.length) {
                this.buffer = Arrays.copyOf(this.buffer, Math.max(this.buffer.length << 1, n3));
            }
            this.buffer[this.count] = (byte)n2;
            this.count = n3;
        }
    }

    @Override
    public void write(byte[] arrby) {
        try {
            super.write(arrby);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public void writeByte(byte by2) {
        this.write(by2);
    }

    public void writeUnsignedByte(int n2) {
        this.writeByte((byte)(n2 & 255));
    }

    public void writeByteArray(byte[] arrby) {
        this.writeUnsignedInt(arrby.length);
        this.write(arrby);
    }

    public void writeSignedInt(int n2) {
        this.write(ByteBuffer.allocate(4).putInt(n2).array());
    }

    public void writeUnsignedInt(long l2) {
        this.writeSignedInt((int)(l2 & 0xFFFFFFFFL));
    }

    public void writeSignedShort(short s2) {
        this.write(ByteBuffer.allocate(2).putShort(s2).array());
    }

    public void writeUnsignedShort(int n2) {
        this.writeSignedShort((short)(n2 & 65535));
    }

    public void writeFloat(float f2) {
        this.write(ByteBuffer.allocate(4).putFloat(f2).array());
    }

    public void writeDouble(double d2) {
        this.write(ByteBuffer.allocate(8).putDouble(d2).array());
    }

    public void writeSignedLong(long l2) {
        this.write(ByteBuffer.allocate(8).putLong(l2).array());
    }

    public void writeString(String string) {
        this.writeByteArray(string.getBytes(StandardCharsets.UTF_8));
    }

    public void writeBoolean(boolean bl2) {
        this.writeByte(bl2 ? (byte)1 : 0);
    }

    public byte[] toByteArray() {
        if (this.stream != null) {
            throw new UnsupportedOperationException("Output is a stream");
        }
        return Arrays.copyOf(this.buffer, this.count);
    }

    @Override
    public void close() {
        try {
            super.close();
            if (this.stream != null) {
                this.stream.close();
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }
}

