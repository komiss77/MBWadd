/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

public class Util {
    public static final Random RAND = new Random();

    public static InetAddress getInetAddress(String string) {
        try {
            return InetAddress.getByName(string);
        }
        catch (UnknownHostException unknownHostException) {
            unknownHostException.printStackTrace();
            return null;
        }
    }

    public static void sleep(long l2) {
        try {
            Thread.sleep(l2);
        }
        catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
    }

    public static byte[] generateRandomSecurityID() {
        byte[] arrby = new byte[16];
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            arrby[i2] = (byte)RAND.nextInt(255);
        }
        return arrby;
    }

    public static byte[] copyOfRange(byte[] arrby, int n2, int n3) {
        byte[] arrby2 = new byte[n3];
        System.arraycopy(arrby, n2, arrby2, 0, n3);
        return arrby2;
    }
}

