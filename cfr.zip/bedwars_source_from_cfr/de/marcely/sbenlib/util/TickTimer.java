/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

@Deprecated
public abstract class TickTimer {
    private static final List<TickTimer> timers = new ArrayList<TickTimer>();
    private final boolean repeating;
    private final long start;
    private final long delay;
    private Timer timer;

    public TickTimer(boolean bl2, long l2) {
        this(bl2, l2, 0L);
    }

    public TickTimer(boolean bl2, long l2, long l3) {
        this.repeating = bl2;
        this.delay = l2;
        this.start = l3;
    }

    public boolean isRunning() {
        return this.timer != null;
    }

    public boolean start() {
        if (this.isRunning()) {
            return false;
        }
        this.timer = new Timer();
        timers.add(this);
        if (this.repeating) {
            this.timer.schedule(new TimerTask(){

                @Override
                public void run() {
                    TickTimer.this.onRun();
                }
            }, this.start, this.delay);
        } else {
            this.timer.schedule(new TimerTask(){

                @Override
                public void run() {
                    TickTimer.this.onRun();
                }
            }, this.delay);
        }
        return true;
    }

    public boolean stop() {
        if (!this.isRunning()) {
            return false;
        }
        timers.remove(this);
        this.timer.cancel();
        this.timer = null;
        return true;
    }

    public abstract void onRun();

    public static List<TickTimer> getTimers() {
        return timers;
    }

    public boolean isRepeating() {
        return this.repeating;
    }

    public long getStart() {
        return this.start;
    }

    public long getDelay() {
        return this.delay;
    }

}

