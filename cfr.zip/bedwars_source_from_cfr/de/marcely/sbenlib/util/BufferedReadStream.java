/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class BufferedReadStream
extends InputStream {
    private InputStream stream;
    private byte[] buffer;
    private int pos = 0;
    private int mark = 0;

    public BufferedReadStream(InputStream inputStream) {
        this.stream = inputStream;
    }

    public BufferedReadStream(byte[] arrby) {
        this.buffer = arrby;
    }

    @Override
    public int read() {
        if (this.stream != null) {
            try {
                return this.stream.read();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return -1;
            }
        }
        return this.pos < this.buffer.length ? this.buffer[this.pos++] & 255 : -1;
    }

    @Override
    public int available() {
        try {
            return this.stream != null ? this.stream.available() : this.buffer.length - this.pos;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return -1;
        }
    }

    @Override
    public int read(byte[] arrby) {
        return this.read(arrby, 0, arrby.length);
    }

    @Override
    public int read(byte[] arrby, int n2, int n3) {
        try {
            return this.stream != null ? this.stream.read(arrby, n2, n3) : super.read(arrby, n2, n3);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return -1;
        }
    }

    @Override
    public long skip(long l2) {
        try {
            if (this.stream != null) {
                return this.stream.skip(l2);
            }
            this.pos = (int)((long)this.pos + l2);
            return l2;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return -1L;
        }
    }

    @Override
    public void mark(int n2) {
        if (this.stream != null) {
            this.stream.mark(n2);
        } else {
            this.mark = n2;
        }
    }

    @Override
    public boolean markSupported() {
        return this.stream != null ? this.stream.markSupported() : true;
    }

    @Override
    public void reset() {
        try {
            if (this.stream != null) {
                this.stream.reset();
            } else {
                this.pos = this.mark;
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public byte[] read(int n2) {
        if (n2 == 0) {
            return new byte[0];
        }
        byte[] arrby = new byte[n2];
        this.read(arrby);
        return arrby;
    }

    public byte readByte() {
        return (byte)this.read();
    }

    public int readUnsignedByte() {
        return this.readByte() & 255;
    }

    public byte[] readByteArray() {
        int n2 = (int)this.readUnsignedInt();
        byte[] arrby = this.read(n2);
        return arrby;
    }

    public int readSignedInt() {
        return ByteBuffer.wrap(this.read(4)).getInt();
    }

    public long readUnsignedInt() {
        return (long)this.readSignedInt() & 0xFFFFFFFFL;
    }

    public short readSignedShort() {
        return ByteBuffer.wrap(this.read(2)).getShort();
    }

    public int readUnsignedShort() {
        return this.readSignedShort() & 65535;
    }

    public float readFloat() {
        return ByteBuffer.wrap(this.read(4)).getFloat();
    }

    public double readDouble() {
        return ByteBuffer.wrap(this.read(8)).getDouble();
    }

    public long readSignedLong() {
        return ByteBuffer.wrap(this.read(8)).getLong();
    }

    public String readString() {
        byte[] arrby = this.readByteArray();
        return arrby != null ? new String(arrby, StandardCharsets.UTF_8) : null;
    }

    public boolean readBoolean() {
        return this.readByte() == 1;
    }

    public boolean readAndCheckMagic(byte[] arrby) {
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            int n2 = this.read();
            if (n2 > -1 && n2 == arrby[i2]) continue;
            return false;
        }
        return true;
    }
}

