/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

import java.util.ArrayList;
import java.util.List;

public abstract class SThread
extends Thread {
    private static final List<SThread> runningThreads = new ArrayList<SThread>();
    private final ThreadType type;

    public SThread() {
        this(ThreadType.Custom);
    }

    public SThread(ThreadType threadType) {
        this.type = threadType;
    }

    @Override
    public void run() {
        runningThreads.add(this);
        this._run();
        runningThreads.remove(this);
    }

    protected abstract void _run();

    public static List<SThread> getRunningThreads() {
        return runningThreads;
    }

    public ThreadType getType() {
        return this.type;
    }

    public static enum ThreadType {
        Protocol_TCP_Client,
        Protocol_TCP_Server,
        Protocol_UDP_Client,
        Protocol_UDP_Server,
        ShutdownHook_Client,
        Init,
        NetworkScheduler,
        Custom;
        
    }

}

