/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.util;

public class MathUtil {
    public static int getSubtractable(int n2, int n3) {
        while (n2 % n3 != 0) {
            ++n2;
        }
        return n2;
    }
}

