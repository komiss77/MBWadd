/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.compression;

import de.marcely.sbenlib.compression.CompressionType;
import de.marcely.sbenlib.compression.Compressor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

public class ZLibCompression
implements Compressor {
    public static ZLibCompression instance = new ZLibCompression();

    @Override
    public CompressionType getType() {
        return CompressionType.ZLib;
    }

    @Override
    public byte[] encode(byte[] arrby) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream);
        deflaterOutputStream.write(arrby);
        deflaterOutputStream.flush();
        deflaterOutputStream.close();
        return byteArrayOutputStream.toByteArray();
    }

    @Override
    public byte[] decode(byte[] arrby) throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        InflaterInputStream inflaterInputStream = new InflaterInputStream(new ByteArrayInputStream(arrby));
        int n2 = -1;
        while ((n2 = ((InputStream)inflaterInputStream).read()) != -1) {
            byteArrayOutputStream.write(n2);
        }
        ((InputStream)inflaterInputStream).close();
        return byteArrayOutputStream.toByteArray();
    }

    public static ZLibCompression getInstance() {
        return instance;
    }
}

