/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.compression;

import de.marcely.sbenlib.compression.CompressionType;

public interface Compressor {
    public CompressionType getType();

    public byte[] encode(byte[] var1) throws Exception;

    public byte[] decode(byte[] var1) throws Exception;
}

