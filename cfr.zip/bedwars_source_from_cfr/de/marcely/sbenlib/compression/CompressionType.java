/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.compression;

import de.marcely.sbenlib.compression.Compressor;
import de.marcely.sbenlib.compression.ZLibCompression;

public enum CompressionType {
    None(null),
    ZLib(new ZLibCompression());
    
    private final Compressor instance;

    private CompressionType(Compressor compressor) {
        this.instance = compressor;
    }

    public Compressor getInstance() {
        return this.instance;
    }
}

