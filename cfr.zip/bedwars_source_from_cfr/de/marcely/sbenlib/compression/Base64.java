/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.xml.bind.DatatypeConverter
 */
package de.marcely.sbenlib.compression;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.xml.bind.DatatypeConverter;

public class Base64 {
    public static byte[] encode(byte[] arrby) {
        return DatatypeConverter.printBase64Binary((byte[])arrby).getBytes(StandardCharsets.UTF_8);
    }

    public static byte[] decode(byte[] arrby) {
        return DatatypeConverter.parseBase64Binary((String)new String(arrby, StandardCharsets.UTF_8));
    }
}

