/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.compression;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import javax.annotation.Nullable;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class AES {
    @Nullable
    public static byte[] encrypt(byte[] arrby, SecretKeySpec secretKeySpec) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(1, secretKeySpec);
            return cipher.doFinal(arrby);
        }
        catch (InvalidKeyException | NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException generalSecurityException) {
            generalSecurityException.printStackTrace();
            return null;
        }
    }

    @Nullable
    public static byte[] decrypt(byte[] arrby, SecretKeySpec secretKeySpec) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(2, secretKeySpec);
            return cipher.doFinal(arrby);
        }
        catch (InvalidKeyException | NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException generalSecurityException) {
            generalSecurityException.printStackTrace();
            return null;
        }
    }
}

