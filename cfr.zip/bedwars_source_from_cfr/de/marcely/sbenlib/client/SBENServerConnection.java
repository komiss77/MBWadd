/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.client;

import de.marcely.sbenlib.client.NetworkScheduler;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionInfo;
import de.marcely.sbenlib.network.ConnectionState;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.util.SThread;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;

public abstract class SBENServerConnection {
    public boolean addShutdownHook = false;
    private final ConnectionInfo connectionInfo;
    private final SocketHandler socketHandler;
    public final NetworkScheduler networkScheduler;
    private ConnectionState connectionState = ConnectionState.NotStarted;
    private long ping = 0L;
    private PacketsData packetsData = new PacketsData();
    public SecretKeySpec key = null;
    private Thread shutdownHook = null;

    public SBENServerConnection(ConnectionInfo connectionInfo, int n2) {
        this.connectionInfo = connectionInfo;
        this.socketHandler = new SocketHandler(this);
        this.networkScheduler = new NetworkScheduler(this.socketHandler, n2);
    }

    public boolean isRunning() {
        return this.socketHandler.isRunning();
    }

    public boolean run() {
        boolean bl2 = this.socketHandler.run();
        if (bl2) {
            this.networkScheduler.run();
            if (this.addShutdownHook) {
                this.shutdownHook = new SThread(SThread.ThreadType.ShutdownHook_Client){

                    @Override
                    protected void _run() {
                        if (SBENServerConnection.this.isRunning()) {
                            SBENServerConnection.this.close("DISCONNECTED");
                            while (SBENServerConnection.this.socketHandler.isRunning()) {
                                try {
                                    Thread.sleep(5L);
                                }
                                catch (InterruptedException interruptedException) {
                                    interruptedException.printStackTrace();
                                }
                            }
                        }
                    }
                };
                Runtime.getRuntime().addShutdownHook(this.shutdownHook);
            }
        }
        return bl2;
    }

    public void close() {
        this.networkScheduler.close(null);
    }

    public void close(@Nullable String string) {
        this.networkScheduler.close(string);
    }

    public void setConnectionState(ConnectionState connectionState) {
        if (this.connectionState == connectionState) {
            return;
        }
        this.onStateChange(connectionState);
        this.connectionState = connectionState;
    }

    public void sendPacket(DataPacket dataPacket) {
        this.sendPacket(dataPacket, true);
    }

    public void sendPacket(DataPacket dataPacket, boolean bl2) {
        this.socketHandler.sendPacket(dataPacket, bl2);
    }

    public abstract void onStateChange(ConnectionState var1);

    public abstract void onPacketReceive(DataPacket var1);

    public abstract void onDisconnect(String var1);

    public ConnectionInfo getConnectionInfo() {
        return this.connectionInfo;
    }

    public ConnectionState getConnectionState() {
        return this.connectionState;
    }

    public long getPing() {
        return this.ping;
    }

    public void setPing(long l2) {
        this.ping = l2;
    }

    public PacketsData getPacketsData() {
        return this.packetsData;
    }

    public void setPacketsData(PacketsData packetsData) {
        this.packetsData = packetsData;
    }

    public SecretKeySpec getKey() {
        return this.key;
    }

}

