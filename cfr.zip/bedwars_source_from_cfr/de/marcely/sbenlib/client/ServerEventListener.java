/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.client;

public interface ServerEventListener {
    public void onPacketReceive(byte[] var1);

    public void onDisconnect();
}

