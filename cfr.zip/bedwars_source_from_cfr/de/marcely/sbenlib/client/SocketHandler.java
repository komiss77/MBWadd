/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.client;

import de.marcely.sbenlib.client.NetworkScheduler;
import de.marcely.sbenlib.client.SBENServerConnection;
import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.protocol.Protocol;
import de.marcely.sbenlib.compression.CompressionType;
import de.marcely.sbenlib.compression.Compressor;
import de.marcely.sbenlib.network.ConnectionInfo;
import de.marcely.sbenlib.network.ConnectionState;
import de.marcely.sbenlib.network.PacketTransmitter;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.PacketClose;
import de.marcely.sbenlib.network.packets.PacketData;
import de.marcely.sbenlib.network.packets.PacketLoginReply;
import de.marcely.sbenlib.network.packets.PacketNack;
import de.marcely.sbenlib.network.packets.PacketPong;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.network.packets.data.SecuredPacket;
import de.marcely.sbenlib.util.Util;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;

public class SocketHandler {
    private final SBENServerConnection server;
    private final Protocol protocol;
    public PacketTransmitter packetTransmitter;

    public SocketHandler(final SBENServerConnection sBENServerConnection) {
        this.server = sBENServerConnection;
        this.protocol = sBENServerConnection.getConnectionInfo().protocol.getClientInstance(sBENServerConnection.getConnectionInfo(), this, new ServerEventListener(){

            @Override
            public void onPacketReceive(byte[] arrby) {
                sBENServerConnection.networkScheduler.receivePacket(arrby);
            }

            @Override
            public void onDisconnect() {
                SocketHandler.this.close(null);
            }
        });
        this.packetTransmitter = new PacketTransmitter(sBENServerConnection.getPacketsData(), sBENServerConnection.getConnectionInfo().protocol.getMaxPacketSize(), sBENServerConnection.getConnectionInfo().compression.getInstance()){

            @Override
            protected void send(byte[] arrby) {
                SocketHandler.this.protocol.sendPacket(arrby);
            }

            @Override
            public void receive(Packet packet) {
                SocketHandler.this.handlePacket(packet);
            }
        };
    }

    public boolean isRunning() {
        return this.protocol.isRunning();
    }

    public boolean run() {
        if (!this.isRunning()) {
            boolean bl2 = this.protocol.run();
            if (bl2) {
                this.getServer().setConnectionState(ConnectionState.Connecting);
                this.server.key = new SecretKeySpec(Util.generateRandomSecurityID(), "AES");
                this.packetTransmitter.setKey(this.server.key);
                return true;
            }
            this.getServer().setConnectionState(ConnectionState.Disconnected);
            return false;
        }
        return false;
    }

    public boolean close(@Nullable String string) {
        if (string == null) {
            string = "SOCKET_CLIENT_CLOSE";
        }
        if (this.isRunning()) {
            PacketClose packetClose = new PacketClose();
            packetClose.reason = string;
            try {
                this.server.networkScheduler.sendPacketNow(packetClose, false);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            this.getServer().setConnectionState(ConnectionState.Disconnected);
            this.getServer().onDisconnect(string);
            return this.protocol.close();
        }
        return false;
    }

    public void sendPacket(DataPacket dataPacket, boolean bl2) {
        if (bl2 && this.getProtocol().getType() == ProtocolType.TCP) {
            bl2 = false;
        }
        if (dataPacket instanceof SecuredPacket) {
            ((SecuredPacket)dataPacket).set_key(this.server.key);
        }
        PacketData packetData = new PacketData();
        packetData.data = dataPacket;
        packetData.packetsData = this.getServer().getPacketsData();
        this.server.networkScheduler.sendPacket(packetData, bl2);
    }

    private void handlePacket(Packet packet) {
        switch (packet.getType()) {
            case 1: {
                this.handle((PacketLoginReply)packet);
                break;
            }
            case 4: {
                this.handle((PacketPong)packet);
                break;
            }
            case 7: {
                this.handle((PacketClose)packet);
                break;
            }
            case 2: {
                this.handle((PacketData)packet);
                break;
            }
            case 5: {
                this.handle((PacketAck)packet);
                break;
            }
            case 6: {
                this.handle((PacketNack)packet);
            }
        }
    }

    private void handle(PacketLoginReply packetLoginReply) {
        if (this.server.getConnectionState() != ConnectionState.Connecting) {
            return;
        }
        switch (packetLoginReply.reply) {
            case 0: {
                this.getServer().setConnectionState(ConnectionState.Connected);
                break;
            }
            case 1: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_PROTOCOL_OUTDATED_CLIENT");
                break;
            }
            case 2: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_PROTOCOL_OUTDATED_SERVER");
                break;
            }
            case 3: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_UNKOWN");
            }
        }
    }

    private void handle(PacketPong packetPong) {
        long l2 = System.currentTimeMillis() - packetPong.time;
        this.getServer().setPing(l2);
    }

    private void handle(PacketClose packetClose) {
        if (this.server.getConnectionState() != ConnectionState.Connected) {
            return;
        }
        this.close(packetClose.reason);
    }

    private void handle(PacketData packetData) {
        if (this.server.getConnectionState() != ConnectionState.Connected) {
            return;
        }
        DataPacket dataPacket = packetData.data;
        this.getServer().onPacketReceive(dataPacket);
    }

    private void handle(PacketAck packetAck) {
        Byte[] arrbyte = packetAck.windows;
        int n2 = arrbyte.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            byte by2 = arrbyte[i2];
            this.packetTransmitter.receiveAck(by2);
        }
    }

    private void handle(PacketNack packetNack) {
        Byte[] arrbyte = packetNack.windows;
        int n2 = arrbyte.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            byte by2 = arrbyte[i2];
            this.packetTransmitter.receiveNack(by2);
        }
    }

    public SBENServerConnection getServer() {
        return this.server;
    }

    public Protocol getProtocol() {
        return this.protocol;
    }

}

