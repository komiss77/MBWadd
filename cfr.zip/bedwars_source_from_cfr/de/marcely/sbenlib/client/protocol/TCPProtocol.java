/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.client.protocol;

import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.client.protocol.Protocol;
import de.marcely.sbenlib.network.ConnectionInfo;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.util.SThread;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class TCPProtocol
extends Protocol {
    private Socket socket;

    public TCPProtocol(ConnectionInfo connectionInfo, SocketHandler socketHandler, ServerEventListener serverEventListener) {
        super(connectionInfo, socketHandler, serverEventListener);
    }

    @Override
    public ProtocolType getType() {
        return ProtocolType.TCP;
    }

    @Override
    public boolean run() {
        if (!this.running) {
            try {
                this.socket = new Socket(this.connectionInfo.ip, this.connectionInfo.port);
                this.thread = new SThread(SThread.ThreadType.Protocol_TCP_Client){

                    @Override
                    protected void _run() {
                        try {
                            InputStream inputStream = TCPProtocol.this.socket.getInputStream();
                            while (TCPProtocol.this.running) {
                                if (inputStream.available() < 1) continue;
                                byte[] arrby = new byte[inputStream.available()];
                                inputStream.read(arrby);
                                TCPProtocol.this.listener.onPacketReceive(arrby);
                            }
                        }
                        catch (IOException iOException) {
                            String string = iOException.getMessage();
                            if (string != null && (string.equals("Stream closed.") || string.equals("Socket operation on nonsocket: socket available"))) {
                                return;
                            }
                            iOException.printStackTrace();
                        }
                    }
                };
                this.thread.start();
            }
            catch (IOException iOException) {
                String string = iOException.getMessage();
                if (string != null && string.equals("Connection refused: connect")) {
                    return false;
                }
                iOException.printStackTrace();
                return false;
            }
            this.running = true;
            return true;
        }
        return false;
    }

    @Override
    public boolean close() {
        if (this.running) {
            try {
                this.socket.close();
                this.running = false;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }

    @Override
    protected boolean _sendPacket(byte[] arrby) {
        if (this.running) {
            try {
                this.socket.getOutputStream().write(arrby);
                return true;
            }
            catch (IOException iOException) {
                String string = iOException.getMessage();
                if (string != null && string.equals("Connection reset by peer: socket write error")) {
                    this.close();
                } else {
                    iOException.printStackTrace();
                }
                return false;
            }
        }
        return false;
    }

}

