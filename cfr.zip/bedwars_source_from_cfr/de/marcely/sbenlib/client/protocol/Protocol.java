/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.client.protocol;

import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionInfo;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.SThread;

public abstract class Protocol {
    protected final ConnectionInfo connectionInfo;
    protected final SocketHandler socketHandler;
    protected final ServerEventListener listener;
    protected SThread thread = null;
    protected boolean running = false;

    public Protocol(ConnectionInfo connectionInfo, SocketHandler socketHandler, ServerEventListener serverEventListener) {
        this.connectionInfo = connectionInfo;
        this.socketHandler = socketHandler;
        this.listener = serverEventListener;
    }

    public boolean sendPacket(byte[] arrby) {
        return this._sendPacket(arrby);
    }

    public boolean sendPacket(Packet packet) {
        return this.sendPacket(packet.encode());
    }

    public abstract ProtocolType getType();

    public abstract boolean run();

    public abstract boolean close();

    protected abstract boolean _sendPacket(byte[] var1);

    public ConnectionInfo getConnectionInfo() {
        return this.connectionInfo;
    }

    public SocketHandler getSocketHandler() {
        return this.socketHandler;
    }

    public ServerEventListener getListener() {
        return this.listener;
    }

    public SThread getThread() {
        return this.thread;
    }

    public boolean isRunning() {
        return this.running;
    }
}

