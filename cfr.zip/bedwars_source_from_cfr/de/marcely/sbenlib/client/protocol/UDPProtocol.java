/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.sbenlib.client.protocol;

import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.client.protocol.Protocol;
import de.marcely.sbenlib.network.ConnectionInfo;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.util.SThread;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Arrays;

public class UDPProtocol
extends Protocol {
    private DatagramSocket socket;

    public UDPProtocol(ConnectionInfo connectionInfo, SocketHandler socketHandler, ServerEventListener serverEventListener) {
        super(connectionInfo, socketHandler, serverEventListener);
    }

    @Override
    public ProtocolType getType() {
        return ProtocolType.UDP;
    }

    @Override
    public boolean run() {
        if (!this.running) {
            this.running = true;
            try {
                this.socket = new DatagramSocket();
                this.thread = new SThread(SThread.ThreadType.Protocol_UDP_Client){

                    @Override
                    protected void _run() {
                        while (UDPProtocol.this.running) {
                            DatagramPacket datagramPacket = new DatagramPacket(new byte[512], 512);
                            try {
                                UDPProtocol.this.socket.receive(datagramPacket);
                                if (!datagramPacket.getAddress().equals(UDPProtocol.this.connectionInfo.ip) || datagramPacket.getPort() != UDPProtocol.this.connectionInfo.port) {
                                    return;
                                }
                                UDPProtocol.this.listener.onPacketReceive(Arrays.copyOfRange(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength()));
                            }
                            catch (IOException iOException) {
                                String string = iOException.getMessage();
                                if (string != null && (string.equals("socket closed") || string.equals("Socket closed"))) {
                                    UDPProtocol.this.socketHandler.close(null);
                                    return;
                                }
                                iOException.printStackTrace();
                            }
                        }
                    }
                };
                this.thread.start();
            }
            catch (SocketException socketException) {
                socketException.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean close() {
        if (this.running) {
            this.running = false;
            this.socket.close();
            return true;
        }
        return false;
    }

    @Override
    protected boolean _sendPacket(byte[] arrby) {
        if (this.running) {
            try {
                this.socket.send(new DatagramPacket(arrby, arrby.length, this.connectionInfo.ip, this.connectionInfo.port));
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }

}

