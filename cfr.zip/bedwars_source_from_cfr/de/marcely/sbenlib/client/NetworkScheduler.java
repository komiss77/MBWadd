/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.sbenlib.client;

import de.marcely.sbenlib.client.SBENServerConnection;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionState;
import de.marcely.sbenlib.network.PacketTransmitter;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.PacketLogin;
import de.marcely.sbenlib.network.packets.PacketPing;
import de.marcely.sbenlib.util.SThread;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;

public class NetworkScheduler {
    private final SocketHandler socket;
    private final int ups;
    private boolean isRunning = false;
    private Queue<byte[]> receivePackets = new ConcurrentLinkedQueue<byte[]>();
    private Queue<Packet> sendPackets = new ConcurrentLinkedQueue<Packet>();
    private boolean sendClose = false;
    private String closeMessage;
    private long lastPing;
    private long lastReceivedPacket = System.currentTimeMillis();

    public NetworkScheduler(SocketHandler socketHandler, int n2) {
        this.socket = socketHandler;
        this.ups = n2;
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    public boolean run() {
        if (this.isRunning()) {
            return false;
        }
        this.isRunning = true;
        new SThread(SThread.ThreadType.NetworkScheduler){

            @Override
            protected void _run() {
                double d2 = 250 / NetworkScheduler.this.ups;
                long l2 = System.nanoTime();
                double d3 = 0.0;
                while (NetworkScheduler.this.isRunning()) {
                    long l3 = System.nanoTime();
                    l2 = l3;
                    while ((d3 += (double)(l3 - l2) / d2) >= 1.0) {
                        NetworkScheduler.this.update();
                        d3 -= 1.0;
                    }
                }
            }
        }.start();
        return true;
    }

    public void close(@Nullable String string) {
        this.sendClose = true;
        this.closeMessage = string;
    }

    public void sendPacket(Packet packet, boolean bl2) {
        packet._needACK = bl2;
        this.sendPackets.add(packet);
    }

    public void sendPacketNow(Packet packet, boolean bl2) throws Exception {
        packet._needACK = bl2;
        this.socket.packetTransmitter.sendPacket(packet, packet._needACK);
    }

    public void receivePacket(byte[] arrby) {
        this.receivePackets.add(arrby);
    }

    public void update() {
        Object object;
        if (!this.isRunning) {
            return;
        }
        if (System.currentTimeMillis() - 6000L > this.lastReceivedPacket) {
            this.close("SERVER_TIMEOUT");
        }
        if (this.sendClose) {
            this.sendPackets.clear();
            this.sendClose = false;
            this.isRunning = false;
            this.socket.close(this.closeMessage);
            return;
        }
        if (this.receivePackets.size() >= 1) {
            this.lastReceivedPacket = System.currentTimeMillis();
            object = null;
            while ((object = this.receivePackets.poll()) != null) {
                try {
                    this.socket.packetTransmitter.handlePacket((byte[])object);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
            this.socket.packetTransmitter.sendNacks();
        }
        if (System.currentTimeMillis() - 1500L > this.lastPing) {
            this.lastPing = System.currentTimeMillis();
            if (this.socket.getServer().getConnectionState() == ConnectionState.Connecting) {
                object = new PacketLogin();
                object.security_id = this.socket.getServer().key.getEncoded();
                object.version_protocol = 3;
                this.sendPacket((Packet)object, false);
            } else {
                object = new PacketPing();
                object.time = System.currentTimeMillis();
                this.sendPacket((Packet)object, false);
            }
        }
        if (this.sendPackets.size() >= 1) {
            object = null;
            while ((object = this.sendPackets.poll()) != null) {
                try {
                    this.sendPacketNow((Packet)object, object._needACK);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

}

