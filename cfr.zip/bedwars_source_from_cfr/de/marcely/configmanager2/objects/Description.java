/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Tree;

public class Description
extends Config {
    private final boolean base;

    public Description(Tree tree, String string, String string2) {
        this(tree, string, string2, false);
    }

    public Description(Tree tree, String string, String string2, boolean bl2) {
        super(string, tree, string2);
        this.base = bl2;
    }

    @Override
    public byte getType() {
        return 4;
    }

    public boolean isBase() {
        return this.base;
    }
}

