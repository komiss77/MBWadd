/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Tree;
import java.util.ArrayList;
import java.util.List;

public class ListItem
extends Config {
    public ListItem(String string, Tree tree) {
        super(null, tree, string);
    }

    @Override
    public byte getType() {
        return 5;
    }

    public static List<String> valuesToString1(List<ListItem> list) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (ListItem listItem : list) {
            arrayList.add(listItem.value);
        }
        return arrayList;
    }
}

