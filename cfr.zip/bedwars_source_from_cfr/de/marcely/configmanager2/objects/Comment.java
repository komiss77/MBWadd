/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Tree;

public class Comment
extends Config {
    public Comment(Tree tree, String string) {
        super(null, tree, string);
    }

    @Override
    public byte getType() {
        return 2;
    }
}

