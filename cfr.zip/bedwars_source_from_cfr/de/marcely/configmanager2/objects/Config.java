/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.objects.Tree;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public class Config {
    public static final byte TYPE_TREE = 0;
    public static final byte TYPE_CONFIG = 1;
    public static final byte TYPE_COMMENT = 2;
    public static final byte TYPE_EMPTYLINE = 3;
    public static final byte TYPE_DESCRIPTION = 4;
    public static final byte TYPE_LISTITEM = 5;
    private final String name;
    private final Tree parent;
    String value;

    public Config(String string, Tree tree) {
        this(string, tree, null);
    }

    public Config(String string, Tree tree, String string2) {
        this.name = string;
        this.parent = tree;
        this.value = string2;
    }

    public byte getType() {
        return 1;
    }

    public String getAbsolutePath() {
        return this.parent != null ? String.valueOf(this.parent.getAbsolutePath()) + (!this.parent.getAbsolutePath().isEmpty() ? "." : "") + this.name : "";
    }

    @Nullable
    private static Boolean getBoolean(String string) {
        return Boolean.valueOf(string);
    }

    public static List<String> valuesToString(List<Config> list) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Config config : list) {
            arrayList.add(config.value);
        }
        return arrayList;
    }

    public String getName() {
        return this.name;
    }

    public Tree getParent() {
        return this.parent;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String string) {
        this.value = string;
    }
}

