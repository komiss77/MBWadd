/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.ConfigFile;
import de.marcely.configmanager2.ConfigPicker;
import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.ListItem;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public class Tree
extends Config {
    private final ConfigFile file;
    private final List<Config> childs = new ArrayList<Config>();
    private final List<String> rawChilds = new ArrayList<String>();

    public Tree(String string, Tree tree) {
        super(string, tree);
        this.file = null;
    }

    public Tree(ConfigFile configFile) {
        super("", null);
        this.file = configFile;
    }

    @Override
    public byte getType() {
        return 0;
    }

    public void addChild(Config config) {
        this.childs.add(config);
        if (config.getType() == 1 && this.isInsideRoot()) {
            this.getConfigFile().getPicker().getAllConfigs().add(config);
        }
    }

    public List<Tree> getTreeChilds() {
        ArrayList<Tree> arrayList = new ArrayList<Tree>();
        for (Config config : this.childs) {
            if (config.getType() != 0) continue;
            arrayList.add((Tree)config);
        }
        return arrayList;
    }

    @Nullable
    public Tree getTreeChild(String string) {
        for (Tree tree : this.getTreeChilds()) {
            if (!tree.getName().equals(string)) continue;
            return tree;
        }
        return null;
    }

    public List<Config> getConfigChilds() {
        ArrayList<Config> arrayList = new ArrayList<Config>();
        for (Config config : this.childs) {
            if (config.getType() != 1) continue;
            arrayList.add(config);
        }
        return arrayList;
    }

    @Nullable
    public Config getConfigChild(String string) {
        for (Config config : this.getConfigChilds()) {
            if (config.getType() != 1 || config.getName() == null || !config.getName().equals(string)) continue;
            return config;
        }
        return null;
    }

    public List<Config> getConfigChilds(String string) {
        ArrayList<Config> arrayList = new ArrayList<Config>();
        for (Config config : this.getConfigChilds()) {
            if (config.getType() != 1 || config.getName() == null || !config.getName().equals(string)) continue;
            arrayList.add(config);
        }
        return arrayList;
    }

    public Config addConfigChild(String string, String string2) {
        Config config = new Config(string, this, string2);
        this.addChild(config);
        return config;
    }

    @Deprecated
    public List<ListItem> getListItems() {
        ArrayList<ListItem> arrayList = new ArrayList<ListItem>();
        for (Config config : this.getConfigChilds()) {
            if (config.getType() != 5) continue;
            arrayList.add((ListItem)config);
        }
        return arrayList;
    }

    public void clear() {
        this.childs.clear();
    }

    public boolean isRoot() {
        return this.file != null;
    }

    public boolean isInsideRoot() {
        return this.isRoot() ? true : this.getParent().isInsideRoot();
    }

    @Nullable
    public ConfigFile getConfigFile() {
        if (this.isInsideRoot()) {
            return this.isRoot() ? this.file : this.getParent().getConfigFile();
        }
        return null;
    }

    public List<Config> getChilds() {
        return this.childs;
    }

    public List<String> getRawChilds() {
        return this.rawChilds;
    }
}

