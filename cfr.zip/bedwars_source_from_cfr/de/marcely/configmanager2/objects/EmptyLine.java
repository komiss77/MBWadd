/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2.objects;

import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Tree;

public class EmptyLine
extends Config {
    public EmptyLine(Tree tree) {
        super(null, tree, null);
    }

    @Override
    public byte getType() {
        return 3;
    }
}

