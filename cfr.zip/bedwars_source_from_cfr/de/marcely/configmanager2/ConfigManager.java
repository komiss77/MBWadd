/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  org.bukkit.plugin.Plugin
 */
package de.marcely.configmanager2;

import de.marcely.bedwars.util.s;
import de.marcely.configmanager2.ConfigFile;
import de.marcely.configmanager2.ConfigPicker;
import de.marcely.configmanager2.objects.Comment;
import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Description;
import de.marcely.configmanager2.objects.EmptyLine;
import de.marcely.configmanager2.objects.ListItem;
import de.marcely.configmanager2.objects.Tree;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.plugin.Plugin;

public class ConfigManager
extends ConfigFile {
    public ConfigManager(File file) {
        this(file, true);
    }

    public ConfigManager(File file, boolean bl2) {
        super(file);
        File file2 = this.getFile().getParentFile();
        if (!file2.exists()) {
            file2.mkdirs();
        }
        if (bl2 && !this.getFile().exists()) {
            try {
                this.getFile().createNewFile();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
    }

    public ConfigManager(Plugin plugin, String string) {
        this(plugin.getName(), string);
    }

    public ConfigManager(String string, String string2) {
        this(new File("plugins/" + string + "/" + string2));
    }

    public ConfigManager(Plugin plugin, String string, boolean bl2) {
        this(plugin.getName(), string, bl2);
    }

    public ConfigManager(String string, String string2, boolean bl2) {
        this(new File("plugins/" + string + "/" + string2));
    }

    public void addConfig(String string, Object object) {
        this.getPicker().addConfig(string, object);
    }

    public void addComment(String string) {
        this.getPicker().addComment(string);
    }

    public void addComment(String string, String string2) {
        this.getPicker().addComment(string2, string);
    }

    @Nullable
    public String getConfigString(String string) {
        Config config = this.getPicker().getConfig(string);
        if (config != null) {
            return config.getValue();
        }
        return null;
    }

    @Nullable
    public Boolean getConfigBoolean(String string) {
        String string2 = this.getConfigString(string);
        if (string2 != null && (string2.equalsIgnoreCase("true") || string2.equalsIgnoreCase("false"))) {
            return Boolean.valueOf(string2);
        }
        return null;
    }

    @Nullable
    public Double getConfigDouble(String string) {
        String string2 = this.getConfigString(string);
        if (string2 != null && s.isDouble(string2)) {
            return Double.valueOf(string2);
        }
        return null;
    }

    @Nullable
    public Integer getConfigInt(String string) {
        String string2 = this.getConfigString(string);
        if (string2 != null && s.isInteger(string2)) {
            return Integer.valueOf(string2);
        }
        return null;
    }

    @Nullable
    public Long getConfigLong(String string) {
        String string2 = this.getConfigString(string);
        if (string2 != null && s.isLong(string2)) {
            return Long.valueOf(string2);
        }
        return null;
    }

    public void addEmptyLine() {
        this.getPicker().addEmptyLine();
    }

    public void addEmptyLine(String string) {
        this.getPicker().addEmptyLine(string);
    }

    public List<Config> getConfigsWhichStartWith(String string) {
        return this.getPicker().getConfigsWhichStartWith(string);
    }

    public List<Config> getConfigsWhichEndWith(String string) {
        return this.getPicker().getConfigsWhichEndWith(string);
    }

    public List<Config> getConfigs(String string) {
        return this.getPicker().getConfigs(string);
    }

    @Nullable
    public List<String> getListItems(String string) {
        Tree tree = this.getPicker().getTree(string, false);
        if (tree != null) {
            return tree.getRawChilds();
        }
        return null;
    }

    public void addListItems(List<String> list, String string) {
        Tree tree = this.getPicker().getTree(string, true);
        for (String string2 : list) {
            tree.addChild(new ListItem(string2, tree));
            tree.getRawChilds().add(string2);
        }
    }

    @Nullable
    public String getDescription(String string) {
        Description description = this.getPicker().getDescription(string);
        return description != null ? description.getValue() : null;
    }

    public void addDescription(String string, String string2) {
        this.getPicker().setDescription(string, string2);
    }
}

