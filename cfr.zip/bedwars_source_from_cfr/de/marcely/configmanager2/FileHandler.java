/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2;

import de.marcely.configmanager2.ConfigFile;
import de.marcely.configmanager2.objects.Comment;
import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Description;
import de.marcely.configmanager2.objects.EmptyLine;
import de.marcely.configmanager2.objects.Tree;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class FileHandler {
    private final ConfigFile file;

    public FileHandler(ConfigFile configFile) {
        this.file = configFile;
    }

    /*
     * Enabled aggressive exception aggregation
     */
    public int load() {
        File file = this.file.getFile();
        if (!file.exists()) {
            return 2;
        }
        if (!file.canRead()) {
            return 3;
        }
        this.file.getRootTree().clear();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((InputStream)new FileInputStream(file), StandardCharsets.UTF_8));
            String string = null;
            Tree tree = this.file.getRootTree();
            while ((string = bufferedReader.readLine()) != null) {
                Object object;
                if ((string = this.replaceFirstSpaces(string)).length() == 0) {
                    tree.addChild(new EmptyLine(tree));
                    continue;
                }
                char c2 = string.charAt(0);
                char c3 = string.charAt(string.length() - 1);
                boolean bl2 = false;
                if (c2 == '#') {
                    tree.addChild(new Comment(tree, this.replaceFirstSpaces(string.substring(1))));
                } else if (string.contains(":")) {
                    object = string.split(":");
                    String string2 = "";
                    for (int i2 = 1; i2 < ((String[])object).length; ++i2) {
                        string2 = String.valueOf(string2) + object[i2];
                        if (i2 + 1 >= ((String[])object).length) continue;
                        string2 = String.valueOf(string2) + ":";
                    }
                    if (!string.startsWith("!")) {
                        tree.addChild(new Config(this.replaceLastSpaces(object[0]), tree, this.replaceFirstSpaces(string2)));
                    } else {
                        tree.addChild(new Description(tree, this.replaceLastSpaces(object[0]).substring(1), this.replaceFirstSpaces(string2)));
                    }
                } else if (c3 == '{') {
                    object = this.replaceLastSpaces(string.substring(0, string.length() - 1));
                    tree = new Tree((String)object, tree);
                    tree.getParent().addChild(tree);
                    bl2 = true;
                } else if (this.replaceLastSpaces(string).equals("}")) {
                    tree = tree.getParent();
                    bl2 = true;
                    if (tree == null) {
                        bufferedReader.close();
                        return 4;
                    }
                } else {
                    tree.addChild(new EmptyLine(tree));
                }
                if (bl2) continue;
                object = this.replaceLastSpaces(string);
                tree.getRawChilds().add((String)object);
            }
            bufferedReader.close();
            if (!tree.equals(this.file.getRootTree())) {
                return 4;
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return 1;
        }
        return 0;
    }

    public int save() {
        File file;
        block6 : {
            file = this.file.getFile();
            if (file.exists() && !file.canWrite()) {
                return 2;
            }
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            if (file.canWrite()) break block6;
            return 2;
        }
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter((OutputStream)new FileOutputStream(file), StandardCharsets.UTF_8));
            List<String> list = this.getLines(this.file.getRootTree(), "");
            for (String string : list) {
                bufferedWriter.write(string);
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return 1;
        }
        return 0;
    }

    private List<String> getLines(Tree tree, String string) {
        return this.getLines(tree, string, tree.equals(this.file.getRootTree()));
    }

    private List<String> getLines(Tree tree, String string, boolean bl2) {
        ArrayList<String> arrayList = new ArrayList<String>();
        for (Config config : tree.getChilds()) {
            if (config.getType() == 0) {
                arrayList.add(String.valueOf(string) + config.getName() + " {");
                arrayList.addAll(this.getLines((Tree)config, String.valueOf(string) + "\t", false));
                arrayList.add(String.valueOf(string) + "}");
                continue;
            }
            if (config.getType() == 2) {
                arrayList.add(String.valueOf(string) + "# " + config.getValue());
                continue;
            }
            if (config.getType() == 3) {
                arrayList.add("");
                continue;
            }
            if (config.getType() == 4) {
                arrayList.add(String.valueOf(string) + "!" + config.getName() + ": " + config.getValue());
                continue;
            }
            if (config.getType() == 5) {
                arrayList.add(String.valueOf(string) + config.getValue());
                continue;
            }
            arrayList.add(String.valueOf(string) + config.getName() + ": " + config.getValue());
        }
        return arrayList;
    }

    private String replaceFirstSpaces(String string) {
        while (string.startsWith(" ") || string.startsWith("\t")) {
            string = string.substring(1, string.length());
        }
        return string;
    }

    private String replaceLastSpaces(String string) {
        while (string.endsWith(" ") || string.endsWith("\t")) {
            string = string.substring(0, string.length() - 1);
        }
        return string;
    }

    public ConfigFile getFile() {
        return this.file;
    }
}

