/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class MultiKeyMap<obj1, obj2> {
    final List<obj1> l1;
    final List<obj2> l2;

    public MultiKeyMap() {
        this.l1 = new ArrayList<obj1>();
        this.l2 = new ArrayList<obj2>();
    }

    public MultiKeyMap(MultiKeyMap<obj1, obj2> multiKeyMap) {
        this.l1 = new ArrayList<obj1>(multiKeyMap.l1);
        this.l2 = new ArrayList<obj2>(multiKeyMap.l2);
    }

    public int size() {
        return this.l1.size();
    }

    public void put(obj1 obj1, obj2 obj2) {
        this.l1.add(obj1);
        this.l2.add(obj2);
    }

    public obj2 getFirst(obj1 obj1) {
        if (this.get(obj1).size() >= 1) {
            return this.get(obj1).get(0);
        }
        return null;
    }

    public List<obj2> get(obj1 obj1) {
        ArrayList<obj2> arrayList = new ArrayList<obj2>();
        int n2 = 0;
        for (obj1 obj12 : this.l1) {
            if (obj1.equals(obj12)) {
                arrayList.add(this.l2.get(n2));
            }
            ++n2;
        }
        return arrayList;
    }

    public List<Map.Entry<obj1, obj2>> entrySet() {
        ArrayList<Map.Entry<obj1, obj2>> arrayList = new ArrayList<Map.Entry<obj1, obj2>>();
        int n2 = 0;
        for (obj1 obj1 : new ArrayList<obj1>(this.l1)) {
            arrayList.add(new AbstractMap.SimpleEntry<obj1, obj2>(obj1, this.l2.get(n2)));
            ++n2;
        }
        return arrayList;
    }

    public void remove(obj1 obj1) {
        int n2 = 0;
        for (obj1 obj12 : this.l1) {
            if (obj12.equals(obj1)) {
                this.l1.remove(n2);
                this.l2.remove(n2);
            }
            ++n2;
        }
    }

    public void remove(obj1 obj1, obj2 obj2) {
        int n2 = 0;
        for (obj1 obj12 : new ArrayList<obj1>(this.l1)) {
            if (obj12.equals(obj1) && this.l2.get(n2).equals(obj2)) {
                this.l1.remove(n2);
                this.l2.remove(n2);
                --n2;
            }
            ++n2;
        }
    }

    public boolean containsKey(obj1 obj1) {
        return this.l1.contains(obj1);
    }

    public boolean containsValue(obj2 obj2) {
        return this.l2.contains(obj2);
    }

    public void replace(obj1 obj1, obj2 obj2) {
        this.remove(obj1);
        this.put(obj1, obj2);
    }

    public List<obj1> keySet() {
        return new ArrayList<obj1>(this.l1);
    }

    public List<obj2> values() {
        return new ArrayList<obj2>(this.l2);
    }

    public boolean removeFirst() {
        if (this.size() >= 1) {
            this.l1.remove(0);
            this.l2.remove(0);
            return true;
        }
        return false;
    }

    public boolean removeLast() {
        if (this.size() >= 1) {
            this.l1.remove(this.l1.size() - 1);
            this.l2.remove(this.l2.size() - 2);
            return true;
        }
        return false;
    }

    public void clear() {
        this.l1.clear();
        this.l2.clear();
    }
}

