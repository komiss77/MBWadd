/*
 * Decompiled with CFR 0.145.
 */
package de.marcely.configmanager2;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MultiKeyMapV2<T1, T2>
implements Map<T1, T2> {
    private final Set<Map.Entry<T1, T2>> entries = new HashSet<Map.Entry<T1, T2>>();

    @Override
    public int size() {
        return this.entries.size();
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object object) {
        return this.get(object) != null;
    }

    @Override
    public boolean containsValue(Object object) {
        for (Map.Entry<T1, T2> entry : this.entries) {
            if (!entry.getValue().equals(object)) continue;
            return true;
        }
        return false;
    }

    @Override
    public T2 get(Object object) {
        for (Map.Entry<T1, T2> entry : this.entries) {
            if (!entry.getKey().equals(object)) continue;
            return entry.getValue();
        }
        return null;
    }

    @Override
    public T2 put(T1 T1, T2 T2) {
        this.entries.add(new AbstractMap.SimpleEntry<T1, T2>(T1, T2));
        return null;
    }

    @Override
    public T2 remove(Object object) {
        Iterator<Map.Entry<T1, T2>> iterator = this.entries.iterator();
        Map.Entry<T1, T2> entry = null;
        while ((entry = iterator.next()) != null) {
            if (!entry.getKey().equals(object)) continue;
            iterator.remove();
            return entry.getValue();
        }
        return null;
    }

    @Override
    public void putAll(Map<? extends T1, ? extends T2> map) {
        this.entries.addAll(map.entrySet());
    }

    @Override
    public void clear() {
        this.entries.clear();
    }

    @Override
    public Set<T1> keySet() {
        new Exception("Unsupported as too slow").printStackTrace();
        return null;
    }

    @Override
    public Collection<T2> values() {
        new Exception("Unsupported as too slow").printStackTrace();
        return null;
    }

    @Override
    public Set<Map.Entry<T1, T2>> entrySet() {
        return this.entries;
    }
}

