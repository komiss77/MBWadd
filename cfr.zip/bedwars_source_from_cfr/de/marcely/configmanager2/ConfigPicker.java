/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package de.marcely.configmanager2;

import de.marcely.configmanager2.ConfigFile;
import de.marcely.configmanager2.objects.Comment;
import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.Description;
import de.marcely.configmanager2.objects.EmptyLine;
import de.marcely.configmanager2.objects.Tree;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public class ConfigPicker {
    private final ConfigFile file;
    private final List<Config> allConfigs = new ArrayList<Config>();

    public ConfigPicker(ConfigFile configFile) {
        this.file = configFile;
    }

    public Config addConfig(String string, Object object) {
        return this.addConfig(string, object.toString());
    }

    public Config addConfig(String string, String string2) {
        String[] arrstring = string.split("\\.");
        Tree tree = string.contains(".") ? this.getTree(string.substring(0, string.lastIndexOf(46)), true) : this.file.getRootTree();
        Config config = new Config(arrstring[arrstring.length - 1], tree, string2);
        tree.addChild(config);
        this.allConfigs.add(config);
        return config;
    }

    public Comment addComment(String string) {
        return this.addComment("", string);
    }

    public Comment addComment(String string, String string2) {
        Tree tree = this.getTree(string, true);
        Comment comment = new Comment(tree, string2);
        tree.addChild(comment);
        return comment;
    }

    public EmptyLine addEmptyLine() {
        return this.addEmptyLine("");
    }

    public EmptyLine addEmptyLine(String string) {
        Tree tree = this.getTree(string, true);
        EmptyLine emptyLine = new EmptyLine(tree);
        tree.addChild(emptyLine);
        return emptyLine;
    }

    @Nullable
    public Config getConfig(String string) {
        Tree tree = this.getTree(string.contains("\\.") ? string.substring(0, string.lastIndexOf(46)) : "", false);
        if (tree != null) {
            String[] arrstring = string.split("\\.");
            return tree.getConfigChild(arrstring[arrstring.length - 1]);
        }
        return !this.file.getConfigNeverNull ? null : new Config(null, null, null);
    }

    public List<Config> getConfigsWhichStartWith(String string) {
        ArrayList<Config> arrayList = new ArrayList<Config>();
        for (Config config : this.allConfigs) {
            if (!config.getAbsolutePath().startsWith(string)) continue;
            arrayList.add(config);
        }
        return arrayList;
    }

    public List<Config> getConfigsWhichEndWith(String string) {
        ArrayList<Config> arrayList = new ArrayList<Config>();
        for (Config config : this.allConfigs) {
            if (!config.getAbsolutePath().endsWith(string)) continue;
            arrayList.add(config);
        }
        return arrayList;
    }

    public List<Config> getConfigs(String string) {
        ArrayList<Config> arrayList = new ArrayList<Config>();
        for (Config config : this.allConfigs) {
            if (!config.getAbsolutePath().equals(string)) continue;
            arrayList.add(config);
        }
        return arrayList;
    }

    public Description setDescription(String string, String string2) {
        Description description;
        if (!this.containsBase()) {
            this.file.getRootTree().getChilds().add(0, new EmptyLine(this.file.getRootTree()));
        }
        if ((description = this.getDescription(string)) == null) {
            description = new Description(this.file.getRootTree(), string, string2);
        } else {
            description.setValue(string2);
        }
        this.file.getRootTree().getChilds().add(0, description);
        return description;
    }

    @Nullable
    public Description getDescription(String string) {
        for (Config config : this.file.getRootTree().getChilds()) {
            if (config.getName() == null || !config.getName().equals(string) || config.getType() != 4) continue;
            return (Description)config;
        }
        return null;
    }

    public boolean containsBase() {
        for (Config config : this.file.getRootTree().getChilds()) {
            if (config.getType() != 4 || !((Description)config).isBase()) continue;
            return true;
        }
        return false;
    }

    @Nullable
    public Tree getTree(String string, boolean bl2) {
        if (string.equals("")) {
            return this.file.getRootTree();
        }
        String[] arrstring = string.split("\\.");
        String string2 = "";
        Tree tree = this.file.getRootTree();
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            if (!string2.equals("")) {
                string2 = String.valueOf(string2) + ".";
            }
            string2 = String.valueOf(string2) + arrstring[i2];
            Tree tree2 = tree.getTreeChild(arrstring[i2]);
            if (tree2 == null) {
                if (bl2) {
                    tree2 = new Tree(arrstring[i2], tree);
                    tree.addChild(tree2);
                } else {
                    return null;
                }
            }
            tree = tree2;
        }
        return tree;
    }

    public ConfigFile getFile() {
        return this.file;
    }

    public List<Config> getAllConfigs() {
        return this.allConfigs;
    }
}

