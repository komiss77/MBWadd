// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.sql.SQLException;
import java.sql.ResultSet;

@Deprecated
public class an
{
    public static String a(final String str, final String str2) {
        return "CREATE TABLE IF NOT EXISTS " + str + " (" + str2 + ")";
    }
    
    public static String a(final String str, final String str2, final String str3, final String str4) {
        return "ALTER TABLE " + str + " ADD " + str2 + " " + str3 + " NOT NULL DEFAULT '" + str4 + "'";
    }
    
    public static String a(final String str, final String str2, final String str3) {
        return "INSERT INTO " + str + " (" + str2 + ") VALUES (" + str3 + ")";
    }
    
    public static String a(final String str, final String str2, final String str3, final String str4, final String str5) {
        return "UPDATE " + str + " SET " + str4 + " = '" + str5 + "' WHERE " + str2 + " = '" + str3 + "'";
    }
    
    public static String b(final String str, final String str2, final String str3) {
        return "SELECT COUNT(*) FROM " + str + " WHERE " + str2 + "='" + str3 + "'";
    }
    
    public static String b(final String str, final String str2) {
        return "SELECT " + str2 + " FROM " + str;
    }
    
    public static String c(final String str, final String str2, final String str3) {
        return "SELECT * FROM " + str + " WHERE " + str2 + " = '" + str3 + "'";
    }
    
    public static boolean a(final ResultSet set) {
        try {
            set.next();
            return set.getInt(1) >= 1;
        }
        catch (SQLException ex) {
            d.a(ex);
            return false;
        }
    }
}
