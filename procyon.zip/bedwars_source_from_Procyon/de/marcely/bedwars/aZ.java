// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.Location;
import org.bukkit.event.entity.EntityDamageEvent;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.game.location.XYZ;
import org.bukkit.entity.Player;
import java.util.Map;
import org.bukkit.Material;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.util.s;
import org.bukkit.Effect;
import org.bukkit.event.player.PlayerMoveEvent;

public class aZ
{
    public static void a(final PlayerMoveEvent playerMoveEvent) {
        final Player player = playerMoveEvent.getPlayer();
        if (cA.E.containsKey(player)) {
            final Location to = playerMoveEvent.getTo();
            final Arena arena = cA.E.get(player).getArena();
            if (!arena.isInside(to)) {
                player.playEffect(to, Effect.ENDER_SIGNAL, 5);
                player.setAllowFlight(true);
                if (arena.isInside(playerMoveEvent.getFrom())) {
                    s.a((Entity)player, player.getLocation().toVector().subtract(playerMoveEvent.getTo().toVector()).multiply(1.1));
                }
                Sound.SPECTATOR_BORDER.play(player);
                playerMoveEvent.setCancelled(true);
            }
        }
        final Arena a = s.a(player);
        if (a != null) {
            if (a.b() == ArenaStatus.f) {
                final Material type = player.getLocation().getBlock().getType();
                if (ConfigValue.diein_water && type != null && type == Material.STATIONARY_WATER) {
                    a.o(player);
                }
                final Location location = playerMoveEvent.getPlayer().getLocation().getBlock().getLocation();
                Material string;
                if ((string = type) == Material.TRIPWIRE) {
                    string = Material.STRING;
                }
                if (string != null && string == ConfigValue.trap_item.getType()) {
                    for (final Map.Entry<String, Player> entry : a.n.entrySet()) {
                        if (XYZ.ofString(entry.getKey()).equals(XYZ.valueOf(location)) && a.a(playerMoveEvent.getPlayer()) != a.a((Player)entry.getValue())) {
                            final Player player2 = playerMoveEvent.getPlayer();
                            final Player player3 = entry.getValue();
                            s.a(player2, Achievement.u);
                            Sound.TRAP_CAUSE.play(player2);
                            player2.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 160, 1));
                            player2.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0));
                            s.a((CommandSender)player3, b.a(Language.Trap));
                            Sound.TRAP_OWNER.play(player3);
                            playerMoveEvent.setCancelled(true);
                            VarParticle.PARTICLE_SMOKE.play(location.getWorld(), location, 1);
                            location.getBlock().setType(Material.AIR);
                            break;
                        }
                    }
                }
                if (ConfigValue.diein_border_bottom && !player.isDead() && a.a() == RegenerationType.c && player.getLocation().getY() < a.getPosMin().getY()) {
                    player.setLastDamageCause(new EntityDamageEvent((Entity)player, EntityDamageEvent.DamageCause.VOID, 4));
                    a.o(player);
                }
            }
            else if (a.b().F() && playerMoveEvent.getTo().getY() <= 0.0) {
                player.setFallDistance(0.0f);
                a.a(player, a.getLobby().clone().setDirection(player.getLocation().getDirection()));
                Sound.LOBBY_OUTOFMAP.play(player);
                player.playEffect(player.getLocation(), Effect.ENDER_SIGNAL, 0);
            }
        }
    }
}
