// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;

public class dz extends dy
{
    public dz(final Arena arena) {
        super(arena, "players");
    }
    
    @Override
    public String e(final Player player) {
        return new StringBuilder().append(this.arena.getPlayers().size()).toString();
    }
}
