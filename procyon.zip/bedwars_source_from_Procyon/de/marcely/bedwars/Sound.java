// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public enum Sound
{
    COUNTDOWN_COUNTING("COUNTDOWN_COUNTING", 0, "FIRE_IGNITE", "ITEM_FLINTANDSTEEL_USE", false), 
    COUNTDOWN_DONECOUNTING("COUNTDOWN_DONECOUNTING", 1, "LEVEL_UP", "ENTITY_PLAYER_LEVELUP", false), 
    BED_DESTROY("BED_DESTROY", 2, "WITHER_DEATH", "ENTITY_WITHER_DEATH", true), 
    BED_DESTROY_ENEMY("BED_DESTROY_ENEMY", 3, "WITHER_DEATH", "ENTITY_WITHER_DEATH", false), 
    TEAM_ELIMINATED("TEAM_ELIMINATED", 4, "ENDERDRAGON_HIT", "ENTITY_ENDERDRAGON_HURT", false), 
    ARENAGUI_ADDSLOTS("ARENAGUI_ADDSLOTS", 5, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false), 
    ARENAGUI_TAKESLOTS("ARENAGUI_TAKESLOTS", 6, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false), 
    ARENAGUI_TAKESLOTSFAIL("ARENAGUI_TAKESLOTSFAIL", 7, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", true), 
    ARENAGUI_ENABLETEAM("ARENAGUI_ENABLETEAM", 8, "CLICK", "UI_BUTTON_CLICK", false), 
    ARENAGUI_DISABLETEAM("ARENAGUI_DISABLETEAM", 9, "CLICK", "UI_BUTTON_CLICK", true), 
    ARENAGUI_DISABLETEAMFAIL("ARENAGUI_DISABLETEAMFAIL", 10, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    VILLAGERSHOP_OPEN("VILLAGERSHOP_OPEN", 11, "CLICK", "UI_BUTTON_CLICK", false), 
    VILLAGERSHOP_BUYFAIL_ONETIMEPURCHASE("VILLAGERSHOP_BUYFAIL_ONETIMEPURCHASE", 12, "NOTE_BASS_DRUM", "BLOCK_NOTE_BLOCK_BASEDRUM", false), 
    VILLAGERSHOP_BUYFAIL_TOOFEWMATERIALS("VILLAGERSHOP_BUYFAIL_TOOFEWMATERIALS", 13, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    VILLAGERSHOP_BUYFAIL_INSUFFICIENT_PERMISSIONS("VILLAGERSHOP_BUYFAIL_INSUFFICIENT_PERMISSIONS", 14, "NOTE_STICKS", "BLOCK_NOTE_HARP", false), 
    VILLAGERSHOP_BUYFAIL_BUYGROUP("VILLAGERSHOP_BUYFAIL_BUYGROUP", 15, "NOTE_BASS_DRUM", "BLOCK_NOTE_BLOCK_BASEDRUM", false), 
    VILLAGERSHOP_BUYSUCCESS("VILLAGERSHOP_BUYSUCCESS", 16, "ITEM_PICKUP", "ENTITY_ITEM_PICKUP", false), 
    UPGRADESHOP_OPEN("UPGRADESHOP_OPEN", 17, "CLICK", "UI_BUTTON_CLICK", true), 
    UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS("UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS", 18, "NOTE_BASS", "BLOCK_NOTE_BASS", true), 
    UPGRADESHOP_BUYSUCCESS("UPGRADESHOP_BUYSUCCESS", 19, "ITEM_PICKUP", "ENTITY_ITEM_PICKUP", true), 
    SPECTATOR_BORDER("SPECTATOR_BORDER", 20, "NOTE_BASS_DRUM", "BLOCK_NOTE_BASEDRUM", false), 
    EXTRAITEM_TELEPORTER_USE("EXTRAITEM_TELEPORTER_USE", 21, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false), 
    EXTRAITEM_TNTSHEEP_FUSE("EXTRAITEM_TNTSHEEP_FUSE", 22, "FUSE", "ENTITY_TNT_PRIMED", false), 
    EXTRAITEM_MINISHOP_USE("EXTRAITEM_MINISHOP_USE", 23, "ORB_PICKUP", "ENTITY_EXPERIENCE_ORB_PICKUP", false), 
    EXTRAITEM_RESCUEPLATFORM_USE("EXTRAITEM_RESCUEPLATFORM_USE", 24, "FIZZ", "BLOCK_LAVA_EXTINGUISH", false), 
    EXTRAITEM_RESCUEPLATFORM_AUTOBREAK("EXTRAITEM_RESCUEPLATFORM_AUTOBREAK", 25, "SLIME_ATTACK", "BLOCK_SLIME_BREAK", false), 
    LOBBY_LEAVE("LOBBY_LEAVE", 26, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", true), 
    LOBBY_ACHIEVEMENTS_OPEN("LOBBY_ACHIEVEMENTS_OPEN", 27, "CHICKEN_EGG_POP", "ENTITY_CHICKEN_EGG", false), 
    LOBBY_ACHIEVEMENTS_CLICK("LOBBY_ACHIEVEMENTS_CLICK", 28, "NOTE_BASS", "BLOCK_NOTE_BASS", true), 
    LOBBY_FORCESTART("LOBBY_FORCESTART", 29, "CAT_HISS", "ENTITY_CAT_HISS", false), 
    LOBBY_SELECTTEAM_OPEN("LOBBY_SELECTTEAM_OPEN", 30, "FIREWORK_BLAST", "ENTITY_FIREWORK_BLAST", true), 
    LOBBY_SELECTTEAM_SELECT("LOBBY_SELECTTEAM_SELECT", 31, "SHEEP_IDLE", "ENTITY_SHEEP_AMBIENT", true), 
    LOBBY_SELECTTEAM_ALREADYSELECTED("LOBBY_SELECTTEAM_ALREADYSELECTED", 32, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    LOBBY_SELECTTEAM_FULL("LOBBY_SELECTTEAM_FULL", 33, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    LOBBY_VOTEARENA_OPEN("LOBBY_VOTEARENA_OPEN", 34, "FIREWORK_BLAST", "ENTITY_FIREWORK_BLAST", false), 
    LOBBY_VOTEARENA_VOTE("LOBBY_VOTEARENA_VOTE", 35, "LEVEL_UP", "ENTITY_PLAYER_LEVELUP", true), 
    LOBBY_VOTEARENA_ALREADYVOTED("LOBBY_VOTEARENA_ALREADYVOTED", 36, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    LOBBY_VOTEARENA_NOTVOTEABLE("LOBBY_VOTEARENA_NOTVOTEABLE", 37, "NOTE_BASS", "BLOCK_NOTE_BASS", false), 
    LOBBY_OUTOFMAP("LOBBY_OUTOFMAP", 38, "CAT_HISS", "ENTITY_CAT_HISS", true), 
    ACHIEVEMENT_GET("ACHIEVEMENT_GET", 39, "LEVEL_UP", "ENTITY_PLAYER_LEVELUP", false), 
    PLAYERDEATH_EFFECT("PLAYERDEATH_EFFECT", 40, "FIZZ", "BLOCK_LAVA_EXTINGUISH", false), 
    CMD_RUNNINGGAME_FAILURE("CMD_RUNNINGGAME_FAILURE", 41, "NOTE_BASS_DRUM", "BLOCK_NOTE_BASEDRUM", false), 
    ENDERCHEST_OPEN("ENDERCHEST_OPEN", 42, "CHEST_OPEN", "BLOCK_CHEST_OPEN", false), 
    BREAK_TOPSTATUE("BREAK_TOPSTATUE", 43, "ITEM_BREAK", "ENTITY_ARMORSTAND_BREAK", false), 
    TRAP_CAUSE("TRAP_CAUSE", 44, "ITEM_BREAK", "ENTITY_ITEM_BREAK", false), 
    TRAP_OWNER("TRAP_OWNER", 45, "GHAST_MOAN", "ENTITY_GHAST_WARN", true), 
    BRIDGE_BUILD("BRIDGE_BUILD", 46, "DIG_STONE", "BLOCK_STONE_BREAK", false), 
    TELEPORTER_COUNTING("TELEPORTER_COUNTING", 47, "NOTE_PLING", "BLOCK_NOTE_BELL", true), 
    ENTITY_VILLAGER_HURT("ENTITY_VILLAGER_HURT", 48, "VILLAGER_HIT", "ENTITY_VILLAGER_HURT", false), 
    ENTITY_VILLAGER_DEATH("ENTITY_VILLAGER_DEATH", 49, "VILLAGER_DEATH", "ENTITY_VILLAGER_DEATH", false), 
    ENTITY_PLAYER_HURT("ENTITY_PLAYER_HURT", 50, "HURT_FLESH", "ENTITY_PLAYER_HURT", false), 
    ENTITY_PLAYER_DEATH("ENTITY_PLAYER_DEATH", 51, "HURT_FLESH", "ENTITY_PLAYER_DEATH", false), 
    ENTITY_ARMOR_STAND_HIT("ENTITY_ARMOR_STAND_HIT", 52, "/", "ENTITY_ARMOR_STAND_HIT", false), 
    ENTITY_ARMOR_STAND_BREAK("ENTITY_ARMOR_STAND_BREAK", 53, "/", "ENTITY_ARMOR_STAND_BREAK", false);
    
    private SoundData data;
    
    private Sound(final String name, final int ordinal, final String s, final String s2, final boolean b) {
        this.data = new SoundData(s, s2, b);
    }
    
    public void play(final Player player) {
        final org.bukkit.Sound a = this.data.a();
        if (a == null) {
            return;
        }
        if (this.data.e()) {
            player.playSound(player.getLocation(), a, 1.0f, 6.0f);
        }
        else {
            player.playSound(player.getLocation(), a, 1.0f, 1.0f);
        }
    }
    
    public void play(final Location location) {
        final org.bukkit.Sound a = this.data.a();
        if (a == null) {
            return;
        }
        if (this.data.e()) {
            location.getWorld().playSound(location, a, 1.0f, 6.0f);
        }
        else {
            location.getWorld().playSound(location, a, 1.0f, 1.0f);
        }
    }
    
    @Nullable
    public static Sound byName(final String anotherString) {
        Sound[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Sound sound = values[i];
            if (sound.name().equalsIgnoreCase(anotherString)) {
                return sound;
            }
        }
        return null;
    }
    
    public SoundData getData() {
        return this.data;
    }
    
    public void setData(final SoundData data) {
        this.data = data;
    }
    
    public static class SoundData
    {
        private String a;
        private String b;
        private boolean b;
        private org.bukkit.Sound a;
        
        public SoundData(final String s, final String s2, final boolean b) {
            if (s.equals("/")) {
                this.a = null;
            }
            else {
                this.a = s.toUpperCase();
            }
            if (s2.equals("/")) {
                this.b = null;
            }
            else {
                this.b = s2.toUpperCase();
            }
            this.b = b;
        }
        
        public org.bukkit.Sound a() {
            if (this.a != null) {
                return this.a;
            }
            org.bukkit.Sound a;
            if (Version.a().getVersionNumber() <= 8) {
                if (this.a == null) {
                    return null;
                }
                a = s.b(this.a);
            }
            else {
                if (this.b == null) {
                    return null;
                }
                String s = this.b.replace("_", "");
                if (Version.a().getVersionNumber() >= 13) {
                    if (s.startsWith("BLOCKNOTE")) {
                        s = s.replaceFirst("BLOCKNOTE", "BLOCKNOTEBLOCK");
                    }
                    else if (s.startsWith("ENTITYFIREWORKBLAST")) {
                        s = s.replaceFirst("ENTITYFIREWORKBLAST", "ENTITYFIREWORKROCKETBLAST");
                    }
                }
                a = de.marcely.bedwars.util.s.b(s);
            }
            if (a == null) {
                d.b("Unkown configured sound '" + ((Version.a().getVersionNumber() <= 8) ? this.a : this.b) + "'");
            }
            else {
                this.a = a;
            }
            return a;
        }
        
        public String a() {
            return this.a;
        }
        
        public String b() {
            return this.b;
        }
        
        public boolean e() {
            return this.b;
        }
    }
}
