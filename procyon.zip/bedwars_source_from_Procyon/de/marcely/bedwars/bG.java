// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.achievements.Achievement;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.Metadatable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;

public class bG extends by
{
    private static final String F = "MBW_EI_TRACK_LAST_USE_AS";
    private static final String G = "MBW_EI_TRACK_ANTI_SPAM_AS";
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        final Long value = s.a((Metadatable)player, "MBW_EI_TRACK_LAST_USE_AS", 0L);
        if (System.currentTimeMillis() - s.a((Metadatable)player, "MBW_EI_TRACK_ANTI_SPAM_AS", 0L) <= 1000L) {
            this.done();
            return;
        }
        player.setMetadata("MBW_EI_TRACK_ANTI_SPAM_AS", (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        if (System.currentTimeMillis() - value <= (int)(ConfigValue.tracker_delay * 1000.0)) {
            s.a((CommandSender)player, b.a(Language.Tracker_ReuseDelay).a("time", new StringBuilder().append((int)(ConfigValue.tracker_delay - (System.currentTimeMillis() - value) / 1000L)).toString()));
            this.done();
            return;
        }
        player.setMetadata("MBW_EI_TRACK_LAST_USE_AS", (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        s.a(player, Achievement.s);
        final Player a = s.a(arena, player);
        this.done();
        if (a != null) {
            player.setCompassTarget(a.getLocation());
            s.a((CommandSender)player, b.a(Language.Tracker_TrackedPlayer));
        }
        else {
            s.a((CommandSender)player, b.a(Language.Tracker_Failed_OnlyOne));
        }
    }
    
    @Override
    public void K() {
    }
}
