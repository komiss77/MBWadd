// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class q extends j
{
    private Arena arena;
    
    public q(final Arena arena) {
        this.arena = arena;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.f.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.arena.b().getID() + "/" + this.arena.getPlayers().size() + "/" + this.arena.getMaxPlayers() + "/" + this.arena.getIcon().getType().name() + ":" + this.arena.getIcon().getDurability() + "/" + this.arena.n().replace("/", "&sKEYslash;") + "/" + this.arena.a().r().size() + "/" + this.arena.getTeamPlayers();
    }
}
