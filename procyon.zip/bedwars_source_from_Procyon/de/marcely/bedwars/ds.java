// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import be.maximvdw.placeholderapi.PlaceholderReplaceEvent;
import be.maximvdw.placeholderapi.PlaceholderReplacer;
import org.bukkit.OfflinePlayer;
import be.maximvdw.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;

public class ds extends du
{
    @Override
    public cT a() {
        return cT.o;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String a(final Player player, final String s) {
        return PlaceholderAPI.replacePlaceholders((OfflinePlayer)player, s);
    }
    
    @Override
    public void a(final dD dd) {
        PlaceholderAPI.registerPlaceholder((Plugin)MBedwars.a, "mbedwars_" + dd.getIdentifier(), (PlaceholderReplacer)new PlaceholderReplacer() {
            public String onPlaceholderReplace(final PlaceholderReplaceEvent placeholderReplaceEvent) {
                return dd.e(placeholderReplaceEvent.getPlayer());
            }
        });
    }
    
    @Override
    public void b(final dD dd) {
    }
    
    @Override
    public void Z() {
    }
}
