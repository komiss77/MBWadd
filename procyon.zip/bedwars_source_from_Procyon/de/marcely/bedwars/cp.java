// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class cp extends ct
{
    public static cp a;
    
    static {
        cp.a = new cp();
    }
    
    public String b(final c c) {
        return new StringBuilder().append(c.getDeaths()).toString();
    }
}
