// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dJ extends dI
{
    public dJ() {
        super("players");
    }
    
    @Override
    protected String a(final Player player, final Arena arena) {
        return new StringBuilder().append(arena.getPlayers().size()).toString();
    }
}
