// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.m;

public class cl extends cm
{
    public static cl a;
    
    static {
        cl.a = new cl();
    }
    
    @Override
    public String a(final m m) {
        if (m.getTeam() == null) {
            return b.a(Language.Spectator).f((CommandSender)m.getPlayer());
        }
        return m.getTeam().getName();
    }
}
