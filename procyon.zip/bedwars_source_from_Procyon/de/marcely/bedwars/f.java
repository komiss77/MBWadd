// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import java.net.UnknownHostException;
import de.marcely.bedwars.util.s;
import java.net.InetAddress;

public class f
{
    private String name;
    private String e;
    private int port;
    private InetAddress address;
    
    public f(final String s) {
        this.port = -1;
        this.name = "";
        final String[] split = s.split(":");
        if (split.length == 2) {
            if (s.isInteger(split[1])) {
                this.e = split[0];
                this.port = Integer.valueOf(split[1]);
                try {
                    if (split[0].equals("localhost") || split[0].equals("127.0.0.1")) {
                        this.address = InetAddress.getLocalHost();
                    }
                    else {
                        this.address = InetAddress.getByName(split[0]);
                    }
                }
                catch (UnknownHostException ex) {
                    d.d("Failed to register channel InetAddress:");
                    ex.printStackTrace();
                    this.port = -1;
                }
            }
            else {
                d.d("WRONG bungeecord-hub-address CONSTRUCTION!! (port is numeric)");
                this.port = -1;
            }
        }
        else {
            d.d("WRONG bungeecord-hub-address CONSTRUCTION!!");
            this.port = -1;
        }
    }
    
    public f(final String s, final int n) {
        this("", s, n);
    }
    
    public f(final String name, final String s, final int port) {
        this.port = -1;
        this.name = name;
        this.e = s;
        this.port = port;
        try {
            this.address = InetAddress.getByName(s);
        }
        catch (UnknownHostException ex) {
            d.d("Failed to register channel InetAddress:");
            ex.printStackTrace();
        }
    }
    
    public boolean h() {
        return this.e != null;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getIP() {
        return this.e;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public InetAddress getInetAddress() {
        return this.address;
    }
    
    public void a(final j j) {
        h.b(new i(j, this));
    }
    
    public void c(final Player player) {
        m.a(player, this.getName());
    }
}
