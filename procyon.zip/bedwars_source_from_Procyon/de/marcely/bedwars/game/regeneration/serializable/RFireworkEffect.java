// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import java.util.Iterator;
import java.util.ArrayList;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import java.util.List;
import java.io.Serializable;

@Deprecated
public class RFireworkEffect implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private List<RColor> color;
    private List<RColor> color_fade;
    private FireworkEffect.Type type;
    private boolean flicker;
    private boolean trail;
    
    public RFireworkEffect(final FireworkEffect fireworkEffect) {
        this.color = this.b(fireworkEffect.getColors());
        this.color_fade = this.b(fireworkEffect.getFadeColors());
        this.type = fireworkEffect.getType();
        this.flicker = fireworkEffect.hasFlicker();
        this.trail = fireworkEffect.hasTrail();
    }
    
    public FireworkEffect a() {
        final FireworkEffect.Builder builder = FireworkEffect.builder();
        builder.withColor((Iterable)this.c(this.color));
        builder.withFade((Iterable)this.c(this.color_fade));
        builder.with(this.type);
        if (this.flicker) {
            builder.withFlicker();
        }
        if (this.trail) {
            builder.withTrail();
        }
        return builder.build();
    }
    
    private List<RColor> b(final List<Color> list) {
        final ArrayList<RColor> list2 = new ArrayList<RColor>();
        final Iterator<Color> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(new RColor(iterator.next()));
        }
        return list2;
    }
    
    private List<Color> c(final List<RColor> list) {
        final ArrayList<Color> list2 = new ArrayList<Color>();
        final Iterator<RColor> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(iterator.next().a());
        }
        return list2;
    }
}
