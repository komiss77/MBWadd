// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.entity.Rabbit;
import java.io.Serializable;

@Deprecated
public class RRabbitType implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private String type;
    
    public RRabbitType(final Rabbit.Type type) {
        this.type = type.name();
    }
    
    public Rabbit.Type a() {
        return Rabbit.Type.valueOf(this.type);
    }
}
