// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.Color;
import java.io.Serializable;

@Deprecated
public class RColor implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private int rgb;
    
    public RColor(final Color color) {
        this.rgb = color.asRGB();
    }
    
    public Color a() {
        return Color.fromRGB(this.rgb);
    }
}
