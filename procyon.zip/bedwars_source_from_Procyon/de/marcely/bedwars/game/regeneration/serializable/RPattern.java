// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.DyeColor;
import java.io.Serializable;

@Deprecated
public class RPattern implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private DyeColor color;
    private PatternType type;
    
    public RPattern(final Pattern pattern) {
        this.color = pattern.getColor();
        this.type = pattern.getPattern();
    }
    
    public Pattern a() {
        return new Pattern(this.color, this.type);
    }
}
