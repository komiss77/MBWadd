// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.material.MaterialData;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import java.io.Serializable;

@Deprecated
public class RItemStack implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private Material material;
    private int amount;
    private short durability;
    private RItemMeta itemmeta;
    
    public RItemStack(ItemStack itemStack) {
        this.itemmeta = null;
        if (itemStack == null) {
            itemStack = new ItemStack(Material.AIR);
        }
        this.material = itemStack.getType();
        this.amount = itemStack.getAmount();
        this.durability = itemStack.getDurability();
        if (itemStack.getItemMeta() != null) {
            this.itemmeta = new RItemMeta(itemStack.getItemMeta());
        }
    }
    
    public void c(final ItemStack itemStack) {
        itemStack.setType(this.material);
        itemStack.setAmount(this.amount);
        itemStack.setDurability(this.durability);
        if (this.itemmeta != null) {
            this.itemmeta.b(itemStack);
        }
    }
    
    public ItemStack d() {
        final ItemStack itemStack = new ItemStack(this.material, this.amount, this.durability);
        if (this.itemmeta != null) {
            this.itemmeta.b(itemStack);
        }
        return itemStack;
    }
    
    public MaterialData a() {
        return new MaterialData(this.material, (byte)this.durability);
    }
}
