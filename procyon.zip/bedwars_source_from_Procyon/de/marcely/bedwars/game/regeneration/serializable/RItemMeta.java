// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import java.util.HashMap;
import org.bukkit.inventory.ItemStack;
import java.util.Iterator;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.FireworkEffect;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.block.banner.Pattern;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.inventory.meta.SkullMeta;
import java.util.Collection;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemFlag;
import java.util.List;
import de.marcely.bedwars.game.e;
import java.util.Map;
import java.io.Serializable;

@Deprecated
public class RItemMeta implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private String displayName;
    private Map<e, Integer> enchantments;
    private List<String> lore;
    private List<ItemFlag> flags;
    private RItemMetaType type;
    private String skull_owner;
    private List<RPattern> banner_patterns;
    private List<RPotionEffect> potion_effects;
    private RColor leatherarmor_color;
    private int firework_power;
    private List<RFireworkEffect> firework_effects;
    private String book_title;
    private String book_author;
    private List<String> book_pages;
    private Map<e, Integer> enchantedstorage_enchantments;
    
    public RItemMeta(final ItemMeta itemMeta) {
        this.displayName = itemMeta.getDisplayName();
        this.enchantments = this.a(itemMeta.getEnchants());
        this.lore = ((itemMeta.getLore() != null) ? itemMeta.getLore() : new ArrayList<String>());
        if (s.a(ItemMeta.class, "getItemFlags", (Class<?>[])new Class[0])) {
            this.flags = new ArrayList<ItemFlag>(itemMeta.getItemFlags());
        }
        if (itemMeta instanceof SkullMeta) {
            this.type = RItemMetaType.Skull;
            this.skull_owner = ((SkullMeta)itemMeta).getOwner();
        }
        else if (itemMeta instanceof BannerMeta) {
            this.type = RItemMetaType.Banner;
            final BannerMeta bannerMeta = (BannerMeta)itemMeta;
            final ArrayList<RPattern> banner_patterns = new ArrayList<RPattern>();
            final Iterator iterator = bannerMeta.getPatterns().iterator();
            while (iterator.hasNext()) {
                banner_patterns.add(new RPattern(iterator.next()));
            }
            this.banner_patterns = banner_patterns;
        }
        else if (itemMeta instanceof PotionMeta) {
            this.type = RItemMetaType.Potion;
            final PotionMeta potionMeta = (PotionMeta)itemMeta;
            this.potion_effects = new ArrayList<RPotionEffect>();
            final Iterator iterator2 = potionMeta.getCustomEffects().iterator();
            while (iterator2.hasNext()) {
                this.potion_effects.add(new RPotionEffect(iterator2.next()));
            }
        }
        else if (itemMeta instanceof LeatherArmorMeta) {
            this.type = RItemMetaType.LeatherArmor;
            this.leatherarmor_color = new RColor(((LeatherArmorMeta)itemMeta).getColor());
        }
        else if (itemMeta instanceof FireworkMeta) {
            this.type = RItemMetaType.Firework;
            final FireworkMeta fireworkMeta = (FireworkMeta)itemMeta;
            final ArrayList<RFireworkEffect> firework_effects = new ArrayList<RFireworkEffect>();
            final Iterator iterator3 = fireworkMeta.getEffects().iterator();
            while (iterator3.hasNext()) {
                firework_effects.add(new RFireworkEffect(iterator3.next()));
            }
            this.firework_power = fireworkMeta.getPower();
            this.firework_effects = firework_effects;
        }
        else if (itemMeta instanceof BookMeta) {
            this.type = RItemMetaType.Book;
            final BookMeta bookMeta = (BookMeta)itemMeta;
            this.book_title = bookMeta.getTitle();
            this.book_author = bookMeta.getAuthor();
            this.book_pages = new ArrayList<String>(bookMeta.getPages());
        }
        else if (itemMeta instanceof EnchantmentStorageMeta) {
            this.type = RItemMetaType.EnchantmentStorage;
            this.enchantedstorage_enchantments = this.a(((EnchantmentStorageMeta)itemMeta).getStoredEnchants());
        }
        else {
            this.type = RItemMetaType.Normal;
        }
    }
    
    public void b(final ItemStack itemStack) {
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemMeta.setDisplayName(this.displayName);
        for (final Map.Entry<Enchantment, Integer> entry : this.b(this.enchantments).entrySet()) {
            itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), true);
        }
        itemMeta.setLore((List)this.lore);
        try {
            final Iterator<ItemFlag> iterator2 = this.flags.iterator();
            while (iterator2.hasNext()) {
                itemMeta.addItemFlags(new ItemFlag[] { iterator2.next() });
            }
        }
        catch (Exception ex) {}
        if (this.type == RItemMetaType.Skull) {
            ((SkullMeta)itemMeta).setOwner(this.skull_owner);
        }
        else if (this.type == RItemMetaType.Banner) {
            final BannerMeta bannerMeta = (BannerMeta)itemMeta;
            final Iterator<RPattern> iterator3 = this.banner_patterns.iterator();
            while (iterator3.hasNext()) {
                bannerMeta.addPattern(iterator3.next().a());
            }
        }
        else if (this.type == RItemMetaType.Potion) {
            final PotionMeta potionMeta = (PotionMeta)itemMeta;
            final Iterator<RPotionEffect> iterator4 = this.potion_effects.iterator();
            while (iterator4.hasNext()) {
                potionMeta.addCustomEffect(iterator4.next().a(), true);
            }
        }
        else if (this.type == RItemMetaType.LeatherArmor) {
            ((LeatherArmorMeta)itemMeta).setColor(this.leatherarmor_color.a());
        }
        else if (this.type == RItemMetaType.Firework) {
            final FireworkMeta fireworkMeta = (FireworkMeta)itemMeta;
            fireworkMeta.setPower(this.firework_power);
            final Iterator<RFireworkEffect> iterator5 = this.firework_effects.iterator();
            while (iterator5.hasNext()) {
                fireworkMeta.addEffect(iterator5.next().a());
            }
        }
        else if (this.type == RItemMetaType.Book) {
            final BookMeta bookMeta = (BookMeta)itemMeta;
            bookMeta.setTitle(this.book_title);
            bookMeta.setAuthor(this.book_author);
            bookMeta.setPages((List)this.book_pages);
        }
        else if (this.type == RItemMetaType.EnchantmentStorage) {
            final EnchantmentStorageMeta enchantmentStorageMeta = (EnchantmentStorageMeta)itemMeta;
            for (final Map.Entry<Enchantment, Integer> entry2 : this.b(this.enchantedstorage_enchantments).entrySet()) {
                enchantmentStorageMeta.addStoredEnchant((Enchantment)entry2.getKey(), (int)entry2.getValue(), true);
            }
        }
        itemStack.setItemMeta(itemMeta);
    }
    
    private Map<e, Integer> a(final Map<Enchantment, Integer> map) {
        final HashMap<e, Integer> hashMap = new HashMap<e, Integer>();
        for (final Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            hashMap.put(e.a(entry.getKey()), entry.getValue());
        }
        return hashMap;
    }
    
    private Map<Enchantment, Integer> b(final Map<e, Integer> map) {
        final HashMap<Enchantment, Integer> hashMap = new HashMap<Enchantment, Integer>();
        for (final Map.Entry<e, Integer> entry : map.entrySet()) {
            hashMap.put(entry.getKey().a(), entry.getValue());
        }
        return hashMap;
    }
    
    public enum RItemMetaType
    {
        Normal("Normal", 0), 
        Skull("Skull", 1), 
        Banner("Banner", 2), 
        Potion("Potion", 3), 
        LeatherArmor("LeatherArmor", 4), 
        Firework("Firework", 5), 
        Book("Book", 6), 
        EnchantmentStorage("EnchantmentStorage", 7);
        
        private RItemMetaType(final String name, final int ordinal) {
        }
    }
}
