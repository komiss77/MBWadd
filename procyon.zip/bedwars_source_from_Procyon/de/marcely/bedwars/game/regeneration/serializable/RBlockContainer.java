// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.Material;
import java.util.Arrays;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.block.Skull;
import org.bukkit.block.Sign;
import org.bukkit.block.ShulkerBox;
import org.bukkit.potion.PotionEffect;
import de.marcely.bedwars.util.s;
import org.bukkit.block.Beacon;
import org.bukkit.block.Hopper;
import org.bukkit.block.Dispenser;
import org.bukkit.block.Dropper;
import java.util.ArrayList;
import org.bukkit.block.Furnace;
import org.bukkit.block.Chest;
import org.bukkit.block.Block;
import org.bukkit.SkullType;
import org.bukkit.block.BlockFace;
import java.util.List;
import java.io.Serializable;

@Deprecated
public class RBlockContainer implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private RBlockContainerType type;
    private String title;
    private List<RItemStack> items;
    private short furnace_burnTime;
    private short furnace_cookTime;
    private RPotionEffectType beacon_primary;
    private RPotionEffectType beacon_secoundary;
    private String[] sign_lines;
    private String skull_owner;
    private BlockFace skull_rotation;
    private SkullType skull_type;
    
    public RBlockContainer(final Block block) {
        this.type = RBlockContainerType.a(block.getType());
        if (this.type == RBlockContainerType.Chest) {
            final Chest chest = (Chest)block.getState();
            this.title = chest.getBlockInventory().getTitle();
            this.items = this.a(chest.getBlockInventory().getContents());
        }
        else if (this.type == RBlockContainerType.Furnace) {
            final Furnace furnace = (Furnace)block.getState();
            this.title = furnace.getInventory().getTitle();
            this.furnace_burnTime = furnace.getBurnTime();
            this.furnace_cookTime = furnace.getCookTime();
            (this.items = new ArrayList<RItemStack>()).add(new RItemStack(furnace.getInventory().getSmelting()));
            this.items.add(new RItemStack(furnace.getInventory().getFuel()));
            this.items.add(new RItemStack(furnace.getInventory().getResult()));
        }
        else if (this.type == RBlockContainerType.Dropper) {
            final Dropper dropper = (Dropper)block.getState();
            this.title = dropper.getInventory().getTitle();
            this.items = this.a(dropper.getInventory().getContents());
        }
        else if (this.type == RBlockContainerType.Dispenser) {
            final Dispenser dispenser = (Dispenser)block.getState();
            this.title = dispenser.getInventory().getTitle();
            this.items = this.a(dispenser.getInventory().getContents());
        }
        else if (this.type == RBlockContainerType.Hopper) {
            final Hopper hopper = (Hopper)block.getState();
            this.title = hopper.getInventory().getTitle();
            this.items = this.a(hopper.getInventory().getContents());
        }
        else if (this.type == RBlockContainerType.Beacon) {
            final Beacon beacon = (Beacon)block.getState();
            this.title = beacon.getInventory().getTitle();
            final Object a = s.a(beacon, "getPrimaryEffect", new Class[0], new Object[0], false);
            final Object a2 = s.a(beacon, "getSecoundaryEffect", new Class[0], new Object[0], false);
            if (a != null) {
                this.beacon_primary = new RPotionEffectType(((PotionEffect)a).getType());
            }
            if (a2 != null) {
                this.beacon_secoundary = new RPotionEffectType(((PotionEffect)a2).getType());
            }
        }
        else if (this.type == RBlockContainerType.Shulker_Box) {
            final ShulkerBox shulkerBox = (ShulkerBox)block.getState();
            this.title = shulkerBox.getInventory().getTitle();
            this.items = this.a(shulkerBox.getInventory().getContents());
        }
        else if (this.type == RBlockContainerType.Sign) {
            this.sign_lines = ((Sign)block.getState()).getLines();
        }
        else {
            if (this.type != RBlockContainerType.Skull) {
                throw new NullPointerException("block is not a container!");
            }
            final Skull skull = (Skull)block.getState();
            this.skull_owner = skull.getOwner();
            this.skull_rotation = skull.getRotation();
            this.skull_type = skull.getSkullType();
        }
    }
    
    public void d(final Block block) {
        if (this.type == RBlockContainerType.Chest) {
            ((Chest)block.getState()).getBlockInventory().setContents(this.a(this.items));
        }
        else if (this.type == RBlockContainerType.Furnace) {
            final Furnace furnace = (Furnace)block.getState();
            furnace.setBurnTime(this.furnace_burnTime);
            furnace.setCookTime(this.furnace_cookTime);
            furnace.getInventory().setSmelting(this.items.get(0).d());
            furnace.getInventory().setFuel(this.items.get(1).d());
            furnace.getInventory().setResult(this.items.get(2).d());
        }
        else if (this.type == RBlockContainerType.Dropper) {
            ((Dropper)block.getState()).getInventory().setContents(this.a(this.items));
        }
        else if (this.type == RBlockContainerType.Dispenser) {
            ((Dispenser)block.getState()).getInventory().setContents(this.a(this.items));
        }
        else if (this.type == RBlockContainerType.Hopper) {
            ((Hopper)block.getState()).getInventory().setContents(this.a(this.items));
        }
        else if (this.type == RBlockContainerType.Beacon) {
            final Beacon beacon = (Beacon)block.getState();
            final Class[] array = { null };
            final Object[] array2 = { null };
            array[0] = PotionEffectType.class;
            if (this.beacon_primary != null) {
                array2[0] = this.beacon_primary.a();
                s.a(beacon, "setPrimaryEffect", array, array2);
            }
            else if (this.beacon_secoundary != null) {
                array2[0] = this.beacon_secoundary.a();
                s.a(beacon, "setSecoundaryEffect", array, array2);
            }
        }
        else if (this.type == RBlockContainerType.Shulker_Box) {
            ((ShulkerBox)block.getState()).getInventory().setContents(this.a(this.items));
        }
        else if (this.type == RBlockContainerType.Sign) {
            final Sign sign = (Sign)block.getState();
            for (int i = 0; i < 4; ++i) {
                sign.setLine(i, this.sign_lines[i]);
            }
            sign.update();
        }
        else if (this.type == RBlockContainerType.Skull) {
            final Skull skull = (Skull)block.getState();
            skull.setOwner(this.skull_owner);
            skull.setRotation(this.skull_rotation);
            skull.setSkullType(this.skull_type);
            skull.update();
        }
    }
    
    private List<RItemStack> a(final ItemStack[] array) {
        final ArrayList<RItemStack> list = new ArrayList<RItemStack>();
        for (int length = array.length, i = 0; i < length; ++i) {
            list.add(new RItemStack(array[i]));
        }
        return list;
    }
    
    private ItemStack[] a(final List<RItemStack> list) {
        final ItemStack[] array = new ItemStack[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            array[i] = list.get(i).d();
        }
        return array;
    }
    
    public enum RBlockContainerType
    {
        Chest("Chest", 0, new String[] { "CHEST", "TRAPPED_CHEST" }), 
        Furnace("Furnace", 1, new String[] { "FURNACE", "BURNING_FURNACE" }), 
        Dropper("Dropper", 2, new String[] { "DROPPER" }), 
        Dispenser("Dispenser", 3, new String[] { "DISPENSER" }), 
        Hopper("Hopper", 4, new String[] { "HOPPER" }), 
        Beacon("Beacon", 5, new String[] { "BEACON" }), 
        Shulker_Box("Shulker_Box", 6, new String[] { "BLACK_SHULKER_BOX", "BLUE_SHULKER_BOX", "BROWN_SHULKER_BOX", "CYAN_SHULKER_BOX", "GRAY_SHULKER_BOX", "GREEN_SHULKER_BOX", "LIGHT_BLUE_SHULKER_BOX", "LIME_SHULKER_BOX", "MAGENTA_SHULKER_BOX", "ORANGE_SHULKER_BOX", "PINK_SHULKER_BOX", "PURPLE_SHULKER_BOX", "RED_SHULKER_BOX", "SILVER_SHULKER_BOX", "WHITE_SHULKER_BOX", "YELLOW_SHULKER_BOX" }), 
        Sign("Sign", 7, new String[] { "SIGN_POST", "WALL_SIGN" }), 
        Skull("Skull", 8, new String[] { "SKULL" });
        
        private List<String> material;
        
        private RBlockContainerType(final String name, final int ordinal, final String... a) {
            this.material = Arrays.asList(a);
        }
        
        public static RBlockContainerType a(final Material material) {
            RBlockContainerType[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final RBlockContainerType rBlockContainerType = values[i];
                if (rBlockContainerType.material.contains(material.name())) {
                    return rBlockContainerType;
                }
            }
            return null;
        }
    }
}
