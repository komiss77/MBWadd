// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import java.util.Iterator;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Rabbit;
import org.bukkit.entity.PigZombie;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Painting;
import org.bukkit.entity.minecart.CommandMinecart;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.Guardian;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Arrow;
import de.marcely.bedwars.util.d;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Minecart;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Projectile;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.EntityType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.entity.LivingEntity;
import java.util.ArrayList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.DyeColor;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Skeleton;
import org.bukkit.Art;
import org.bukkit.entity.Ocelot;
import org.bukkit.Rotation;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Horse;
import java.util.List;
import de.marcely.bedwars.game.location.XYZ;
import java.io.Serializable;

@Deprecated
public class REntityContainer implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private XYZ velocity;
    private RItemStack helmet;
    private RItemStack chestplate;
    private RItemStack leggings;
    private RItemStack boots;
    private boolean canPickupItems;
    private boolean removeWhenFarAway;
    private List<RPotionEffect> activePotionEffects;
    private double maxHealth;
    private double health;
    private Integer leashEntityId;
    private boolean noAI;
    private boolean bounce;
    private boolean breed;
    private boolean adult;
    private boolean agelock;
    private int age;
    private RItemStack[] content;
    private double minecart_damage;
    private double minecart_maxSpeed;
    private XYZ minecart_derailedVector;
    private RItemStack minecart_block;
    private boolean minecart_slowWhenEmpty;
    private int slime_size;
    private XYZ armorstand_headpose;
    private XYZ armorstand_bodypose;
    private XYZ armorstand_leftarmpose;
    private XYZ armorstand_rightarmpose;
    private XYZ armorstand_leftlegpose;
    private XYZ armorstand_rightlegpose;
    private boolean armorstand_small;
    private boolean armorstand_visible;
    private boolean armorstand_gravity;
    private boolean armorstand_baseplate;
    private boolean arrow_critical;
    private int arrow_knockbackStrength;
    private boolean bat_awake;
    private double boat_maxSpeed;
    private double boat_occupiedDeceleration;
    private double boat_unoccupiedDeceleration;
    private boolean boat_workOnLand;
    private boolean creeper_powered;
    private RItemStack enderman_item;
    private boolean guardian_elder;
    private Horse.Color horse_color;
    private RItemStack horse_armor;
    private RItemStack horse_saddle;
    private boolean horse_chest;
    private Horse.Style horse_style;
    private boolean irongolem_playerCreated;
    public BlockFace itemframe_direction;
    private RItemStack itemframe_item;
    private Rotation itemframe_rotation;
    private String minecartcommand_command;
    private Ocelot.Type ocelot_type;
    private boolean ocelot_sitting;
    private Art painting_art;
    private boolean pig_saddle;
    private int pigzombie_anger;
    private boolean pigzombie_angry;
    private RRabbitType rabbit_type;
    private boolean sheep_sheared;
    private Skeleton.SkeletonType skeleton_type;
    private Villager.Profession villager_profession;
    private DyeColor wolf_color;
    private boolean wolf_angry;
    private boolean wolf_sitting;
    private boolean zombie_baby;
    
    public REntityContainer(final Entity entity) {
        this.helmet = new RItemStack(new ItemStack(Material.AIR));
        this.chestplate = new RItemStack(new ItemStack(Material.AIR));
        this.leggings = new RItemStack(new ItemStack(Material.AIR));
        this.boots = new RItemStack(new ItemStack(Material.AIR));
        this.activePotionEffects = new ArrayList<RPotionEffect>();
        this.leashEntityId = null;
        final EntityType type = entity.getType();
        if (entity instanceof LivingEntity) {
            final LivingEntity livingEntity = (LivingEntity)entity;
            this.velocity = XYZ.valueOf(livingEntity.getVelocity());
            this.canPickupItems = livingEntity.getCanPickupItems();
            final Iterator iterator = livingEntity.getActivePotionEffects().iterator();
            while (iterator.hasNext()) {
                this.activePotionEffects.add(new RPotionEffect(iterator.next()));
            }
            this.removeWhenFarAway = livingEntity.getRemoveWhenFarAway();
            this.maxHealth = livingEntity.getMaxHealth();
            this.health = livingEntity.getHealth();
            if (livingEntity.getEquipment() != null) {
                this.helmet = new RItemStack(livingEntity.getEquipment().getHelmet());
                this.chestplate = new RItemStack(livingEntity.getEquipment().getChestplate());
                this.leggings = new RItemStack(livingEntity.getEquipment().getLeggings());
                this.boots = new RItemStack(livingEntity.getEquipment().getBoots());
            }
            if (livingEntity.isLeashed() && livingEntity.getLeashHolder().getType() != EntityType.PLAYER && livingEntity.getLeashHolder().getType() != EntityType.DROPPED_ITEM) {
                this.leashEntityId = livingEntity.getLeashHolder().getEntityId();
            }
            if (Version.a().getVersionNumber() <= 8) {
                this.noAI = Version.a().b(entity);
            }
        }
        if (entity instanceof Projectile) {
            this.bounce = ((Projectile)entity).doesBounce();
        }
        if (entity instanceof Ageable) {
            final Ageable ageable = (Ageable)entity;
            this.breed = ageable.canBreed();
            this.adult = ageable.isAdult();
            this.agelock = ageable.getAgeLock();
            this.age = ageable.getAge();
        }
        if (entity instanceof InventoryHolder) {
            final InventoryHolder inventoryHolder = (InventoryHolder)entity;
            this.content = new RItemStack[inventoryHolder.getInventory().getSize()];
            for (int i = 0; i < inventoryHolder.getInventory().getSize(); ++i) {
                this.content[i] = new RItemStack(inventoryHolder.getInventory().getItem(i));
            }
        }
        if (entity instanceof Minecart) {
            final Minecart minecart = (Minecart)entity;
            this.minecart_damage = minecart.getDamage();
            this.minecart_maxSpeed = minecart.getMaxSpeed();
            this.minecart_derailedVector = XYZ.valueOf(minecart.getDerailedVelocityMod());
            this.minecart_block = new RItemStack(minecart.getDisplayBlock().toItemStack());
            this.minecart_slowWhenEmpty = minecart.isSlowWhenEmpty();
        }
        if (entity instanceof Slime) {
            this.slime_size = ((Slime)entity).getSize();
        }
        if (type == EntityType.ARMOR_STAND) {
            final ArmorStand armorStand = (ArmorStand)entity;
            this.armorstand_headpose = d.a(armorStand.getHeadPose());
            this.armorstand_bodypose = d.a(armorStand.getBodyPose());
            this.armorstand_leftarmpose = d.a(armorStand.getLeftArmPose());
            this.armorstand_rightarmpose = d.a(armorStand.getRightArmPose());
            this.armorstand_leftlegpose = d.a(armorStand.getLeftLegPose());
            this.armorstand_rightlegpose = d.a(armorStand.getRightLegPose());
            this.armorstand_small = armorStand.isSmall();
            this.armorstand_visible = armorStand.isVisible();
            this.armorstand_gravity = armorStand.hasGravity();
            this.armorstand_baseplate = armorStand.hasBasePlate();
        }
        else if (type == EntityType.ARROW) {
            final Arrow arrow = (Arrow)entity;
            this.arrow_critical = arrow.isCritical();
            this.arrow_knockbackStrength = arrow.getKnockbackStrength();
        }
        else if (type == EntityType.BAT) {
            this.bat_awake = ((Bat)entity).isAwake();
        }
        else if (type == EntityType.BOAT) {
            final Boat boat = (Boat)entity;
            this.boat_maxSpeed = boat.getMaxSpeed();
            this.boat_occupiedDeceleration = boat.getOccupiedDeceleration();
            this.boat_unoccupiedDeceleration = boat.getUnoccupiedDeceleration();
            this.boat_workOnLand = boat.getWorkOnLand();
        }
        else if (type == EntityType.CREEPER) {
            this.creeper_powered = ((Creeper)entity).isPowered();
        }
        else if (type == EntityType.ENDERMAN) {
            this.enderman_item = new RItemStack(((Enderman)entity).getCarriedMaterial().toItemStack());
        }
        else if (type == EntityType.GUARDIAN) {
            this.guardian_elder = ((Guardian)entity).isElder();
        }
        else if (type == EntityType.HORSE) {
            final Horse horse = (Horse)entity;
            this.horse_color = horse.getColor();
            this.horse_armor = new RItemStack(horse.getInventory().getArmor());
            this.horse_saddle = new RItemStack(horse.getInventory().getSaddle());
            this.horse_style = horse.getStyle();
        }
        else if (type == EntityType.IRON_GOLEM) {
            this.irongolem_playerCreated = ((IronGolem)entity).isPlayerCreated();
        }
        else if (type == EntityType.ITEM_FRAME) {
            final ItemFrame itemFrame = (ItemFrame)entity;
            this.itemframe_direction = itemFrame.getFacing();
            this.itemframe_item = new RItemStack(itemFrame.getItem());
            this.itemframe_rotation = itemFrame.getRotation();
        }
        else if (type == EntityType.MINECART_COMMAND) {
            this.minecartcommand_command = ((CommandMinecart)entity).getCommand();
        }
        else if (type == EntityType.OCELOT) {
            final Ocelot ocelot = (Ocelot)entity;
            this.ocelot_type = ocelot.getCatType();
            this.ocelot_sitting = ocelot.isSitting();
        }
        else if (type == EntityType.PAINTING) {
            this.painting_art = ((Painting)entity).getArt();
        }
        else if (type == EntityType.PIG) {
            this.pig_saddle = ((Pig)entity).hasSaddle();
        }
        else if (type == EntityType.PIG_ZOMBIE) {
            final PigZombie pigZombie = (PigZombie)entity;
            this.pigzombie_anger = pigZombie.getAnger();
            this.pigzombie_angry = pigZombie.isAngry();
        }
        else if (type == EntityType.RABBIT) {
            this.rabbit_type = new RRabbitType(((Rabbit)entity).getRabbitType());
        }
        else if (type == EntityType.SHEEP) {
            this.sheep_sheared = ((Sheep)entity).isSheared();
        }
        else if (type == EntityType.SKELETON) {
            this.skeleton_type = ((Skeleton)entity).getSkeletonType();
        }
        else if (type == EntityType.VILLAGER) {
            this.villager_profession = ((Villager)entity).getProfession();
        }
        else if (type == EntityType.WOLF) {
            final Wolf wolf = (Wolf)entity;
            this.wolf_color = wolf.getCollarColor();
            this.wolf_angry = wolf.isAngry();
            this.wolf_sitting = wolf.isSitting();
        }
        else if (type == EntityType.ZOMBIE) {
            this.zombie_baby = ((Zombie)entity).isBaby();
        }
    }
    
    public void a(final Entity entity) {
        final EntityType type = entity.getType();
        if (entity instanceof LivingEntity) {
            final LivingEntity livingEntity = (LivingEntity)entity;
            livingEntity.setVelocity(this.velocity.toVector());
            livingEntity.setCanPickupItems(this.canPickupItems);
            final Iterator<RPotionEffect> iterator = this.activePotionEffects.iterator();
            while (iterator.hasNext()) {
                livingEntity.addPotionEffect(iterator.next().a());
            }
            livingEntity.setRemoveWhenFarAway(this.removeWhenFarAway);
            livingEntity.setMaxHealth(this.maxHealth);
            livingEntity.setHealth(this.health);
            if (livingEntity.getEquipment() != null) {
                livingEntity.getEquipment().setHelmet(this.helmet.d());
                livingEntity.getEquipment().setChestplate(this.chestplate.d());
                livingEntity.getEquipment().setLeggings(this.leggings.d());
                livingEntity.getEquipment().setBoots(this.boots.d());
            }
            if (Version.a().getVersionNumber() <= 8) {
                Version.a().b(entity, this.noAI);
            }
        }
        if (entity instanceof Projectile) {
            ((Projectile)entity).setBounce(this.bounce);
        }
        if (entity instanceof Ageable) {
            final Ageable ageable = (Ageable)entity;
            ageable.setBreed(this.breed);
            if (this.adult) {
                ageable.setAdult();
            }
            else {
                ageable.setBaby();
            }
            ageable.setAgeLock(this.agelock);
            ageable.setAge(this.age);
        }
        if (entity instanceof InventoryHolder) {
            final InventoryHolder inventoryHolder = (InventoryHolder)entity;
            final ItemStack[] contents = new ItemStack[this.content.length];
            for (int i = 0; i < this.content.length; ++i) {
                contents[i] = this.content[i].d();
            }
            inventoryHolder.getInventory().setContents(contents);
        }
        if (entity instanceof Minecart) {
            final Minecart minecart = (Minecart)entity;
            minecart.setDamage(this.minecart_damage);
            minecart.setMaxSpeed(this.minecart_maxSpeed);
            minecart.setDerailedVelocityMod(this.minecart_derailedVector.toVector());
            minecart.setDisplayBlock(this.minecart_block.a());
            minecart.setSlowWhenEmpty(this.minecart_slowWhenEmpty);
        }
        if (type == EntityType.SLIME) {
            ((Slime)entity).setSize(this.slime_size);
        }
        else if (type == EntityType.ARMOR_STAND) {
            final ArmorStand armorStand = (ArmorStand)entity;
            armorStand.setHeadPose(d.a(this.armorstand_headpose));
            armorStand.setBodyPose(d.a(this.armorstand_bodypose));
            armorStand.setLeftArmPose(d.a(this.armorstand_leftarmpose));
            armorStand.setRightArmPose(d.a(this.armorstand_rightarmpose));
            armorStand.setLeftLegPose(d.a(this.armorstand_leftlegpose));
            armorStand.setRightLegPose(d.a(this.armorstand_rightlegpose));
            armorStand.setSmall(this.armorstand_small);
            armorStand.setVisible(this.armorstand_visible);
            armorStand.setGravity(this.armorstand_gravity);
            armorStand.setBasePlate(this.armorstand_baseplate);
        }
        else if (type == EntityType.ARROW) {
            final Arrow arrow = (Arrow)entity;
            arrow.setCritical(this.arrow_critical);
            arrow.setKnockbackStrength(this.arrow_knockbackStrength);
        }
        else if (type == EntityType.BAT) {
            ((Bat)entity).setAwake(this.bat_awake);
        }
        else if (type == EntityType.BOAT) {
            final Boat boat = (Boat)entity;
            boat.setMaxSpeed(this.boat_maxSpeed);
            boat.setOccupiedDeceleration(this.boat_occupiedDeceleration);
            boat.setUnoccupiedDeceleration(this.boat_unoccupiedDeceleration);
            boat.setWorkOnLand(this.boat_workOnLand);
        }
        else if (type == EntityType.CREEPER) {
            ((Creeper)entity).setPowered(this.creeper_powered);
        }
        else if (type == EntityType.ENDERMAN) {
            ((Enderman)entity).setCarriedMaterial(this.enderman_item.a());
        }
        else if (type == EntityType.GUARDIAN) {
            ((Guardian)entity).setElder(this.guardian_elder);
        }
        else if (type == EntityType.HORSE) {
            final Horse horse = (Horse)entity;
            horse.setColor(this.horse_color);
            horse.getInventory().setArmor(this.horse_armor.d());
            horse.getInventory().setSaddle(this.horse_saddle.d());
            horse.setCarryingChest(this.horse_chest);
            horse.setStyle(this.horse_style);
        }
        else if (type == EntityType.IRON_GOLEM) {
            ((IronGolem)entity).setPlayerCreated(this.irongolem_playerCreated);
        }
        else if (type == EntityType.ITEM_FRAME) {
            final ItemFrame itemFrame = (ItemFrame)entity;
            itemFrame.setItem(this.itemframe_item.d());
            itemFrame.setRotation(this.itemframe_rotation);
        }
        else if (type == EntityType.MINECART_COMMAND) {
            ((CommandMinecart)entity).setCommand(this.minecartcommand_command);
        }
        else if (type == EntityType.OCELOT) {
            final Ocelot ocelot = (Ocelot)entity;
            if (Version.a().getVersionNumber() <= 13) {
                ocelot.setCatType(this.ocelot_type);
            }
            ocelot.setSitting(this.ocelot_sitting);
        }
        else if (type == EntityType.PAINTING) {
            ((Painting)entity).setArt(this.painting_art, true);
        }
        else if (type == EntityType.PIG) {
            ((Pig)entity).setSaddle(this.pig_saddle);
        }
        else if (type == EntityType.PIG_ZOMBIE) {
            final PigZombie pigZombie = (PigZombie)entity;
            pigZombie.setAnger(this.pigzombie_anger);
            pigZombie.setAngry(this.pigzombie_angry);
        }
        else if (type == EntityType.RABBIT) {
            ((Rabbit)entity).setRabbitType(this.rabbit_type.a());
        }
        else if (type == EntityType.SHEEP) {
            ((Sheep)entity).setSheared(this.sheep_sheared);
        }
        else if (type == EntityType.SKELETON) {
            ((Skeleton)entity).setSkeletonType(this.skeleton_type);
        }
        else if (type == EntityType.VILLAGER) {
            ((Villager)entity).setProfession(this.villager_profession);
        }
        else if (type == EntityType.WOLF) {
            final Wolf wolf = (Wolf)entity;
            wolf.setCollarColor(this.wolf_color);
            wolf.setAngry(this.wolf_angry);
            wolf.setSitting(this.wolf_sitting);
        }
        else if (type == EntityType.ZOMBIE) {
            ((Zombie)entity).setBaby(this.zombie_baby);
        }
    }
}
