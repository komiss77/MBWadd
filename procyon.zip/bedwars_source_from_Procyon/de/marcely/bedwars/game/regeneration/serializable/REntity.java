// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import org.bukkit.block.BlockFace;
import de.marcely.bedwars.d;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.game.location.XYZYPW;
import de.marcely.bedwars.game.location.XYZW;
import java.io.Serializable;

@Deprecated
public class REntity implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private XYZW loc;
    private XYZYPW nLoc;
    private String type;
    private boolean customNameVisible;
    private String customName;
    private int entityId;
    private Integer passangerId;
    private REntityContainer container;
    private transient Entity latestSpawned;
    
    public REntity(final Entity entity) {
        this.latestSpawned = null;
        if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM) {
            this.nLoc = XYZYPW.valueOf(entity.getLocation());
            this.type = entity.getType().name();
            this.customNameVisible = entity.isCustomNameVisible();
            this.customName = entity.getCustomName();
            this.entityId = entity.getEntityId();
            this.container = new REntityContainer(entity);
            if (entity.getPassenger() != null && entity.getPassenger().getType() != EntityType.PLAYER && entity.getPassenger().getType() != EntityType.DROPPED_ITEM) {
                this.passangerId = entity.getPassenger().getEntityId();
            }
            return;
        }
        throw new NullPointerException("This doesn't support " + entity.getType().name());
    }
    
    public int p() {
        return this.entityId;
    }
    
    public Integer b() {
        return this.passangerId;
    }
    
    public Entity a() {
        return this.latestSpawned;
    }
    
    public Entity b() {
        final Entity entity = null;
        try {
            this.a(this.loc.getWorld());
        }
        catch (Exception ex) {
            this.a(this.nLoc.getWorld());
        }
        return entity;
    }
    
    public EntityType getType() {
        return EntityType.valueOf(this.type);
    }
    
    public Entity a(final World world) {
        Entity latestSpawned;
        try {
            latestSpawned = world.spawnEntity(new Location(world, this.loc.getX(), this.loc.getY(), this.loc.getZ()), this.getType());
            d.e("[Regeneration] We recommend you to use /bw arena regenerate <arena name> again!");
        }
        catch (Exception ex) {
            if (this.getType() == EntityType.ITEM_FRAME) {
                final XYZYPW clone = this.nLoc.clone();
                if (this.container.itemframe_direction == BlockFace.NORTH) {
                    clone.setZ((int)clone.getZ() - 1);
                }
                else if (this.container.itemframe_direction == BlockFace.SOUTH) {
                    clone.setZ((int)clone.getZ() - 1);
                }
                else if (this.container.itemframe_direction == BlockFace.EAST) {
                    clone.setZ((int)clone.getZ() - 1);
                }
                else if (this.container.itemframe_direction == BlockFace.WEST) {
                    clone.setZ((int)clone.getZ() - 1);
                }
                latestSpawned = world.spawnEntity(new Location(world, clone.getX(), clone.getY(), clone.getZ()), this.getType());
            }
            else {
                latestSpawned = world.spawnEntity(new Location(world, this.nLoc.getX(), this.nLoc.getY(), this.nLoc.getZ(), this.nLoc.getYaw(), this.nLoc.getPitch()), this.getType());
            }
        }
        latestSpawned.setCustomNameVisible(this.customNameVisible);
        latestSpawned.setCustomName(this.customName);
        this.container.a(latestSpawned);
        return this.latestSpawned = latestSpawned;
    }
}
