// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration.serializable;

import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.World;
import de.marcely.bedwars.d;
import org.bukkit.Material;
import de.marcely.bedwars.game.SimpleBlock;
import org.bukkit.block.Block;
import java.io.Serializable;

@Deprecated
public class RBlock implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private int x;
    private int y;
    private int z;
    private String type;
    private byte data;
    private RBlockContainer container;
    
    public RBlock(final Block block) {
        this.container = null;
        this.x = block.getX();
        this.y = block.getY();
        this.z = block.getZ();
        this.type = block.getType().name();
        this.data = block.getData();
        if (RBlockContainer.RBlockContainerType.a(block.getType()) != null) {
            this.container = new RBlockContainer(block);
        }
    }
    
    public RBlock(final SimpleBlock simpleBlock) {
        this.container = null;
        this.x = simpleBlock.x;
        this.y = simpleBlock.y;
        this.z = simpleBlock.z;
        this.type = simpleBlock.block;
        if (simpleBlock.data != null) {
            this.data = simpleBlock.data;
        }
    }
    
    public Material getType() {
        try {
            return Material.valueOf(this.type);
        }
        catch (Exception ex) {
            d.b("There was a issue getting the material of a block at x" + this.x + "y" + this.y + "z" + this.z + ". It has been replaced by air!");
            return Material.AIR;
        }
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public int getZ() {
        return this.z;
    }
    
    public void a(final World world, final Arena arena) {
        final Block block = world.getBlockAt(this.x, this.y, this.z);
        Version.a().a(block.getLocation(), this.getType(), this.data);
        if (this.container != null) {
            try {
                this.container.d(block);
            }
            catch (Exception ex) {
                if (Version.a().getVersionNumber() >= 13 && ex.getMessage() != null && ex.getMessage().contains("cannot be cast to org.bukkit.block.Furnace")) {
                    d.a("This blocks of this arena are still of 1.12 and older. Please resave them with /bw arena saveblocks " + arena.getDisplayName(), arena);
                }
            }
        }
    }
    
    public byte getData() {
        return this.data;
    }
    
    public RBlockContainer a() {
        return this.container;
    }
}
