// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

public interface c
{
    void a(final a p0);
    
    void a(final long p0);
    
    public enum a
    {
        a("SUCCESS", 0), 
        b("FAILED_WORLDPLAYERS", 1), 
        c("FAILED_NO_REGENERATOR", 2), 
        d("FAILED_ALREADY_RUNNING", 3), 
        e("FAILED_NOT_STOPPED", 4), 
        f("UNKOWN", 5);
        
        static {
            a = new a[] { de.marcely.bedwars.game.regeneration.c.a.a, de.marcely.bedwars.game.regeneration.c.a.b, de.marcely.bedwars.game.regeneration.c.a.c, de.marcely.bedwars.game.regeneration.c.a.d, de.marcely.bedwars.game.regeneration.c.a.e, de.marcely.bedwars.game.regeneration.c.a.f };
        }
        
        private a(final String name, final int ordinal) {
        }
    }
}
