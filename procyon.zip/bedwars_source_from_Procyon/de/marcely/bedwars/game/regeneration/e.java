// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

import org.bukkit.World;
import de.marcely.bedwars.util.Synchronizer;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.config.ConfigValue;
import java.io.File;
import de.marcely.bedwars.game.arena.RegenerationType;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.arena.Arena;

public class e extends a
{
    public e(final Arena arena, final CommandSender commandSender) {
        super(RegenerationType.d, arena, commandSender);
    }
    
    @Override
    protected void a(final File file) {
        if (ConfigValue.regeneration_threadsafe) {
            new MThread(MThread.ThreadType.m, this.arena.getName()) {
                @Override
                public void run() {
                    while (e.this.isRunning()) {
                        e.this.b(file);
                        s.sleep(1000L);
                    }
                }
            }.start();
        }
        else {
            new BukkitRunnable() {
                public void run() {
                    if (!e.this.isRunning()) {
                        this.cancel();
                        return;
                    }
                    e.this.b(file);
                }
            }.runTaskTimer((Plugin)MBedwars.a, 0L, 20L);
        }
    }
    
    private void b(final File file) {
        new Synchronizer(true) {
            final /* synthetic */ e a = d.a(e.this.arena.getWorld(), file);
            private final /* synthetic */ World a = d.a(e.this.arena.getWorld(), file);
            
            @Override
            public void run() {
                if (World.this != null) {
                    e.this.arena.setWorld(World.this);
                    e.this.g(true);
                }
                else {
                    e.this.b(false, "The file '/MBedwars/arenablocks/" + e.this.arena.getName() + ".yml' is probably corrupted!!");
                }
            }
        };
    }
    
    @Override
    protected void s() {
    }
    
    @Override
    protected void a(final File file, final c c) {
        c.a(d.a(this.arena.getWorld(), file));
    }
}
