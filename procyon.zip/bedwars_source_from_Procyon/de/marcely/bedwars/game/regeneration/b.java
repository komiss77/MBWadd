// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

import org.bukkit.entity.Player;
import java.util.List;
import de.marcely.bedwars.bq;
import org.bukkit.Material;
import de.marcely.bedwars.util.s;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Chunk;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.d;
import de.marcely.bedwars.al;
import de.marcely.bedwars.bN;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.bM;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.bO;
import java.io.File;
import de.marcely.bedwars.game.arena.RegenerationType;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.Location;
import java.util.Iterator;

public class b extends a
{
    private boolean running;
    private byte o;
    private int Z;
    private Iterator<Location> a;
    
    public b(final Arena arena, @Nullable final CommandSender commandSender) {
        super(RegenerationType.c, arena, commandSender);
        this.o = 0;
    }
    
    @Override
    protected void a(final File file, final c c) {
        final bO bo = new bO(file, (int)(this.arena.getPosMax().getX() - this.arena.getPosMin().getX()), (int)(this.arena.getPosMax().getY() - this.arena.getPosMin().getY()), (int)(this.arena.getPosMax().getZ() - this.arena.getPosMin().getZ()));
        for (final Entity entity : this.arena.getWorld().getEntities()) {
            if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM && this.arena.isInside(entity.getLocation())) {
                bo.entities.add(bM.a(entity));
            }
        }
        try {
            bo.a(this.arena.getPosMin().toBukkit(this.arena.getWorld()), () -> c.a(de.marcely.bedwars.game.regeneration.c.a.a), n -> c.a(n));
        }
        catch (Exception ex) {
            c.a(de.marcely.bedwars.game.regeneration.c.a.f);
        }
    }
    
    @Override
    protected void a(final File file) {
        new MThread(MThread.ThreadType.m, this.arena.getName()) {
            final /* synthetic */ b a;
            
            @Override
            public void run() {
                bN.b a;
                try {
                    a = bO.a(new File("plugins/MBedwars/data/arenablocks/" + b.this.arena.getName() + ".yml"), b.this.arena.getPosMin().toBukkit(b.this.arena.getWorld()), ConfigValue.regeneration_threadsafe);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    b.this.b(false, "A big error occured while loading the file");
                    return;
                }
                final bN.b b = a;
                if (a.a != bN.c.j) {
                    if (a.a == bN.c.b) {
                        new al(de.marcely.bedwars.game.regeneration.b.this.arena, de.marcely.bedwars.game.regeneration.b.this.getSender()) {
                            @Override
                            public void b(final boolean b, @Nullable final String s) {
                                if (!b) {
                                    ((b$1)b).a.b(false, "An error occured while loading the file (it's also not a v2 region regenerator file): " + b.a);
                                }
                                else {
                                    d.a("This arena is still using an old regenerator. Please write '/bw arena saveblocks " + this.arena.getName() + "' to save and use the newer v3 regenerator", this.arena);
                                    ((b$1)b).a.g(true);
                                }
                            }
                        }.run();
                    }
                    else if (a.a == bN.c.e) {
                        de.marcely.bedwars.game.regeneration.b.this.b(false, "An error occured while loading the file (MCVersion: " + a.H + "): " + a.a);
                    }
                    else {
                        de.marcely.bedwars.game.regeneration.b.this.b(false, "An error occured while loading the file: " + a.a);
                    }
                    return;
                }
                de.marcely.bedwars.game.regeneration.b.a(de.marcely.bedwars.game.regeneration.b.this, true);
                if (Version.a().getVersionNumber() >= 9) {
                    new Synchronizer(true) {
                        @Override
                        public void run() {
                            final Iterator<Chunk> iterator = b.this.arena.m().iterator();
                            while (iterator.hasNext()) {
                                iterator.next().load();
                            }
                        }
                    };
                }
                if (ConfigValue.regeneration_threadsafe) {
                    new MThread(ThreadType.m, de.marcely.bedwars.game.regeneration.b.this.arena.getName()) {
                        @Override
                        public void run() {
                            try {
                                while (((b$1)b).a.running) {
                                    b.this.a(b.c, b.a);
                                }
                            }
                            catch (Exception ex) {
                                ex.printStackTrace();
                                b.a(((b$1)b).a, false);
                                new Synchronizer() {
                                    @Override
                                    public void run() {
                                        ((b$1)b).a.g(false);
                                    }
                                };
                            }
                        }
                    }.start();
                }
                else {
                    new BukkitRunnable() {
                        public void run() {
                            if (!((b$1)b).a.running) {
                                this.cancel();
                                return;
                            }
                            try {
                                b.this.a(b.c, b.a);
                            }
                            catch (Exception ex) {
                                ex.printStackTrace();
                                b.a(((b$1)b).a, false);
                                ((b$1)b).a.g(false);
                            }
                        }
                    }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
                }
            }
        }.start();
    }
    
    private void a(final bN bn, final bN.a a) {
        if (this.o == 0) {
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    for (final Entity entity : b.this.arena.getWorld().getEntities()) {
                        if (entity.getType() != EntityType.PLAYER && b.this.arena.isInside(entity.getLocation())) {
                            Version.a().b(entity);
                        }
                    }
                    final b a = b.this;
                    b.a(a, (byte)(a.o + 1));
                    b.a(b.this, s.a(b.this.arena.getPosMin().toBukkit(b.this.arena.getWorld()), (int)(b.this.arena.getPosMax().getX() - b.this.arena.getPosMin().getX()), (int)(b.this.arena.getPosMax().getY() - b.this.arena.getPosMin().getY()), (int)(b.this.arena.getPosMax().getZ() - b.this.arena.getPosMin().getZ())));
                    Version.a().a(b.this.arena.getWorld(), true);
                }
            };
            if (Version.a().getVersionNumber() < 13) {
                runnable.run();
            }
            else {
                new Synchronizer(true) {
                    @Override
                    public void run() {
                        runnable.run();
                    }
                };
            }
        }
        else if (this.o == 1) {
            final long currentTimeMillis = System.currentTimeMillis();
            while (this.a.hasNext()) {
                Version.a().a(this.a.next(), Material.AIR, (byte)0);
                if (System.currentTimeMillis() - currentTimeMillis >= ConfigValue.regeneration_speed_ms) {
                    return;
                }
            }
            ++this.o;
        }
        else {
            if (this.o == 2) {
                final long currentTimeMillis2 = System.currentTimeMillis();
                try {
                    while (a.next()) {
                        if (System.currentTimeMillis() - currentTimeMillis2 >= ConfigValue.regeneration_speed_ms) {
                            return;
                        }
                    }
                    ++this.o;
                    Version.a().a(this.arena.getWorld(), false);
                    return;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    this.b(false, "A big error occured while loading the file");
                    this.running = false;
                    return;
                }
            }
            if (this.o == 3) {
                new Synchronizer(true) {
                    @Override
                    public void run() {
                        for (int i = 0; i < 10; ++i) {
                            final b a = (b)bn;
                            final int a2 = a.Z;
                            b.a(a, a2 + 1);
                            final int n = a2;
                            if (n >= bn.entities.size()) {
                                final b a3 = (b)bn;
                                b.a(a3, (byte)(a3.o + 1));
                                break;
                            }
                            final bM bm = bn.entities.get(n);
                            try {
                                if (bm.b(((b)bn).arena.getWorld()) == null) {
                                    throw new bq("Unkown entity type");
                                }
                            }
                            catch (Exception ex) {
                                d.b("[Regeneration] Skipped entity type " + bm.type + " in arena " + ((b)bn).arena.getName() + "(Error: " + ex.getClass().getSimpleName() + ", Message: " + ex.getMessage() + ")");
                            }
                        }
                    }
                };
            }
            else if (this.o == 4) {
                new Synchronizer(true) {
                    @Override
                    public void run() {
                        // 
                        // This method could not be decompiled.
                        // 
                        // Original Bytecode:
                        // 
                        //     1: getfield        de/marcely/bedwars/game/regeneration/b$5.a:Lde/marcely/bedwars/game/regeneration/b;
                        //     4: getfield        de/marcely/bedwars/game/regeneration/b.arena:Lde/marcely/bedwars/game/arena/Arena;
                        //     7: invokevirtual   de/marcely/bedwars/game/arena/Arena.m:()Ljava/util/List;
                        //    10: astore_1       
                        //    11: aload_0        
                        //    12: aload_1        
                        //    13: invokedynamic   BootstrapMethod #0, run:(Lde/marcely/bedwars/game/regeneration/b$5;Ljava/util/List;)Ljava/lang/Runnable;
                        //    18: astore_2       
                        //    19: invokestatic    de/marcely/bedwars/versions/Version.a:()Lde/marcely/bedwars/versions/v;
                        //    22: invokevirtual   de/marcely/bedwars/versions/v.a:()Lde/marcely/bedwars/versions/Version;
                        //    25: invokevirtual   de/marcely/bedwars/versions/Version.ordinal:()I
                        //    28: getstatic       de/marcely/bedwars/versions/Version.o:Lde/marcely/bedwars/versions/Version;
                        //    31: invokevirtual   de/marcely/bedwars/versions/Version.ordinal:()I
                        //    34: if_icmplt       65
                        //    37: new             Lde/marcely/bedwars/game/regeneration/b$5$1;
                        //    40: dup            
                        //    41: aload_0        
                        //    42: getstatic       de/marcely/bedwars/util/MThread$ThreadType.m:Lde/marcely/bedwars/util/MThread$ThreadType;
                        //    45: aload_0        
                        //    46: getfield        de/marcely/bedwars/game/regeneration/b$5.a:Lde/marcely/bedwars/game/regeneration/b;
                        //    49: getfield        de/marcely/bedwars/game/regeneration/b.arena:Lde/marcely/bedwars/game/arena/Arena;
                        //    52: invokevirtual   de/marcely/bedwars/game/arena/Arena.getName:()Ljava/lang/String;
                        //    55: aload_2        
                        //    56: invokespecial   de/marcely/bedwars/game/regeneration/b$5$1.<init>:(Lde/marcely/bedwars/game/regeneration/b$5;Lde/marcely/bedwars/util/MThread$ThreadType;Ljava/lang/String;Ljava/lang/Runnable;)V
                        //    59: invokevirtual   de/marcely/bedwars/game/regeneration/b$5$1.start:()V
                        //    62: goto            71
                        //    65: aload_2        
                        //    66: invokeinterface java/lang/Runnable.run:()V
                        //    71: return         
                        //    StackMapTable: 00 02 FF 00 41 00 03 00 00 07 00 0D 00 00 F8 00 05
                        // 
                        // The error that occurred was:
                        // 
                        // java.lang.IllegalStateException: Could not infer any expression.
                        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
                        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
                        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
                        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:715)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:440)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:441)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:441)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:441)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                        // 
                        throw new IllegalStateException("An error occurred while decompiling this method.");
                    }
                };
            }
            else if (this.o == 5) {
                this.running = false;
                new Synchronizer() {
                    @Override
                    public void run() {
                        b.this.g(true);
                    }
                };
            }
        }
    }
    
    @Override
    protected void s() {
        this.running = false;
    }
    
    public static boolean d(final String str) {
        final File file = new File("plugins/MBedwars/data/arenablocks/" + str + ".yml");
        if (file.exists()) {
            file.delete();
            return true;
        }
        return false;
    }
    
    static /* synthetic */ void a(final b b, final boolean running) {
        b.running = running;
    }
    
    static /* synthetic */ void a(final b b, final byte o) {
        b.o = o;
    }
    
    static /* synthetic */ void a(final b b, final Iterator a) {
        b.a = (Iterator<Location>)a;
    }
    
    static /* synthetic */ void a(final b b, final int z) {
        b.Z = z;
    }
}
