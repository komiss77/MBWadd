// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

import java.util.Random;
import java.util.Arrays;
import org.bukkit.generator.BlockPopulator;
import java.util.List;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.WorldType;
import javax.annotation.Nullable;
import java.io.InputStream;
import java.util.Enumeration;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.f;
import java.util.zip.ZipFile;
import java.util.Iterator;
import org.bukkit.WorldCreator;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import de.marcely.bedwars.util.s;
import java.io.File;
import org.bukkit.World;

public class d
{
    public static c.a a(final World world, final File file) {
        if (s.a() == null || s.a().getSpawnLocation() == null) {
            de.marcely.bedwars.d.a("Tried to teleport players to the main world to save world files. This failed as there is no main world or no spawn location in that world. Fix that!");
            return c.a.f;
        }
        if (s.a(world)) {
            return c.a.b;
        }
        final Iterator<Player> iterator = (Iterator<Player>)world.getPlayers().iterator();
        while (iterator.hasNext()) {
            iterator.next().teleport(s.a().getSpawnLocation());
        }
        if (world.getPlayers().size() >= 1) {
            return c.a.b;
        }
        Bukkit.unloadWorld(world, true);
        if (file.exists()) {
            file.delete();
        }
        final File file2 = new File(String.valueOf(world.getName()) + "/region/");
        try {
            final ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(file));
            File[] listFiles;
            for (int length = (listFiles = file2.listFiles()).length, i = 0; i < length; ++i) {
                final File file3 = listFiles[i];
                if (file3.getName().endsWith(".mca")) {
                    final FileInputStream fileInputStream = new FileInputStream(file3);
                    zipOutputStream.putNextEntry(new ZipEntry(file3.getName()));
                    final byte[] array = new byte[1024];
                    int read;
                    while ((read = fileInputStream.read(array)) > 0) {
                        zipOutputStream.write(array, 0, read);
                    }
                    fileInputStream.close();
                }
            }
            zipOutputStream.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        final WorldCreator worldCreator = new WorldCreator(world.getName());
        worldCreator.copy(world);
        Bukkit.createWorld(worldCreator);
        return c.a.a;
    }
    
    @Nullable
    public static World a(final World world, final File file) {
        try {
            final boolean b = s.a != Thread.currentThread();
            final String name = s.a().getName();
            if (name.equals(world.getName()) || (String.valueOf(name) + "_nether").equals(world.getName()) || (String.valueOf(name) + "_the_end").equals(world.getName())) {
                de.marcely.bedwars.d.b("WARNING: IT'S NOT POSSIBLE TO REGENERATE MAIN WORLDS!!!");
                return null;
            }
            final File file2 = new File(String.valueOf(world.getName()) + "/region/");
            if (!b) {
                final Iterator<Player> iterator = (Iterator<Player>)world.getPlayers().iterator();
                while (iterator.hasNext()) {
                    iterator.next().teleport(s.a().getSpawnLocation());
                }
                if (world.getPlayers().size() >= 1) {
                    de.marcely.bedwars.d.b("WARNING: FAILED TO UNLOAD THE WORLD AS (PROBABLY) A PLUGIN HAS BLOCKED THIS OPERATION. Enabling 'regeneration-threadsafe' in the config.cm2 file may fix that");
                    return null;
                }
                Bukkit.unloadWorld(world, false);
            }
            File[] listFiles;
            for (int length = (listFiles = file2.listFiles()).length, i = 0; i < length; ++i) {
                final File file3 = listFiles[i];
                if (file3 == null || file3.getName() == null) {
                    return null;
                }
                if (file3.getName().endsWith(".mca")) {
                    file3.delete();
                }
            }
            final ZipFile zipFile = new ZipFile(file);
            final Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry entry = (ZipEntry)entries.nextElement();
                final InputStream inputStream = zipFile.getInputStream(entry);
                final File file4 = new File(String.valueOf(world.getName()) + "/region/" + entry.getName());
                if (file4.exists()) {
                    file4.delete();
                }
                final FileOutputStream fileOutputStream = new FileOutputStream(file4);
                f.copy(inputStream, fileOutputStream);
                inputStream.close();
                fileOutputStream.close();
            }
            zipFile.close();
            if (b) {
                Version.a().c(world);
                Version.a().b(world);
                new BukkitRunnable() {
                    public void run() {
                        for (final Player player : world.getPlayers()) {
                            if (Version.a().getVersionNumber() <= 13) {
                                Version.a().J(player);
                            }
                            else {
                                player.teleport(s.a().getSpawnLocation());
                            }
                        }
                    }
                }.runTaskLater((Plugin)MBedwars.a, 20L);
                return world;
            }
            return Bukkit.createWorld(new WorldCreator(world.getName()).copy(world));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static WorldCreator a(final String s) {
        final WorldCreator worldCreator = new WorldCreator(s);
        if (Version.a().getVersionNumber() >= 13) {
            worldCreator.type(WorldType.CUSTOMIZED);
            worldCreator.generator((ChunkGenerator)new ChunkGenerator() {
                public List<BlockPopulator> getDefaultPopulators(final World world) {
                    return Arrays.asList(new BlockPopulator[0]);
                }
                
                public boolean canSpawn(final World world, final int n, final int n2) {
                    return true;
                }
                
                public ChunkGenerator.ChunkData generateChunkData(final World world, final Random random, final int n, final int n2, final ChunkGenerator.BiomeGrid biomeGrid) {
                    return this.createChunkData(world);
                }
            });
        }
        else if (Version.a().getVersionNumber() >= 8) {
            worldCreator.type(WorldType.CUSTOMIZED);
            worldCreator.generator((ChunkGenerator)new ChunkGenerator() {
                public List<BlockPopulator> getDefaultPopulators(final World world) {
                    return Arrays.asList(new BlockPopulator[0]);
                }
                
                public boolean canSpawn(final World world, final int n, final int n2) {
                    return true;
                }
                
                public byte[] generate(final World world, final Random random, final int n, final int n2) {
                    return new byte[32768];
                }
            });
        }
        else {
            worldCreator.type(WorldType.FLAT);
        }
        return worldCreator;
    }
}
