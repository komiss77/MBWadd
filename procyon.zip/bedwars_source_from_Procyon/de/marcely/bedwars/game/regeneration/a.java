// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

import java.util.Iterator;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import org.bukkit.event.Event;
import de.marcely.bedwars.api.event.ArenaRegenerationStopEvent;
import org.bukkit.Bukkit;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.d;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import java.io.File;
import java.util.ArrayList;
import javax.annotation.Nullable;
import java.util.List;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.RegenerationType;

public abstract class a
{
    protected final RegenerationType f;
    protected final Arena arena;
    private final CommandSender sender;
    private boolean running;
    private long startTime;
    private final List<Runnable> T;
    
    public a(final RegenerationType f, final Arena arena, @Nullable final CommandSender sender) {
        this.running = false;
        this.T = new ArrayList<Runnable>();
        this.f = f;
        this.arena = arena;
        this.sender = sender;
    }
    
    protected abstract void a(final File p0);
    
    protected abstract void s();
    
    protected abstract void a(final File p0, final c p1);
    
    protected void g(final boolean b) {
        this.b(b, null);
    }
    
    public void b(final boolean b, @Nullable final String s) {
        if (b && this.sender != null) {
            s.a(this.sender, b.a(Language.Regeneration_Done).a("arena", (this.arena != null) ? this.arena.getName() : "Unkown").a("time", new StringBuilder().append((System.currentTimeMillis() - this.startTime) / 1000.0).toString()));
        }
        else if (!b) {
            if (this.sender != null) {
                s.a(this.sender, b.a(Language.Regeneration_Stopped).a("arena", (this.arena != null) ? this.arena.getName() : "Unkown").a("time", new StringBuilder().append((System.currentTimeMillis() - this.startTime) / 1000.0).toString()));
            }
            if (s != null && !s.equals("Cancelled")) {
                d.a(s, this.arena);
            }
        }
        this.running = false;
        new Synchronizer() {
            @Override
            public void run() {
                Bukkit.getPluginManager().callEvent((Event)new ArenaRegenerationStopEvent(a.this.arena, a.this.sender));
                a.this.arena.a().reset();
                a.this.arena.a(ArenaStatus.e);
                de.marcely.bedwars.config.b.b(a.this.arena);
                if (ConfigValue.regeneration_threadsafe) {
                    final Iterator<Arena> iterator = s.af.iterator();
                    while (iterator.hasNext()) {
                        if (iterator.next().b() == ArenaStatus.g) {
                            return;
                        }
                    }
                    de.marcely.bedwars.versions.a.setEnabled(false);
                }
            }
        };
    }
    
    public void b(final Runnable runnable) {
        this.T.add(runnable);
    }
    
    public boolean run() {
        if (this.running) {
            return false;
        }
        if (ConfigValue.regeneration_threadsafe) {
            de.marcely.bedwars.versions.a.setEnabled(false);
        }
        this.running = true;
        this.a(this.a());
        this.startTime = System.currentTimeMillis();
        return true;
    }
    
    public boolean cancel() {
        if (!this.running) {
            return false;
        }
        this.running = false;
        this.s();
        this.b(false, "Cancelled");
        return true;
    }
    
    public void b(c c) {
        if (c == null) {
            c = new c() {
                @Override
                public void a(final c.a a) {
                }
                
                @Override
                public void a(final long n) {
                }
            };
        }
        this.a(this.a(), c);
    }
    
    public File a() {
        return new File("plugins/MBedwars/data/arenablocks/" + this.arena.getName() + ".yml");
    }
    
    public RegenerationType b() {
        return this.f;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public CommandSender getSender() {
        return this.sender;
    }
    
    public boolean isRunning() {
        return this.running;
    }
    
    public List<Runnable> t() {
        return this.T;
    }
}
