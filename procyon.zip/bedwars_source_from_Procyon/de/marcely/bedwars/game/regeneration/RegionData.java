// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.regeneration;

import java.util.Iterator;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import java.util.List;
import java.io.Serializable;

@Deprecated
public class RegionData implements Serializable
{
    private static final long serialVersionUID = 4508008698825268258L;
    private List<RBlock> blocks;
    private List<REntity> entities;
    
    public RegionData(final List<RBlock> blocks, final List<REntity> entities) {
        this.blocks = blocks;
        this.entities = entities;
    }
    
    public List<RBlock> getBlocks() {
        return this.blocks;
    }
    
    public List<REntity> getEntities() {
        return this.entities;
    }
    
    public RBlock a(final int n, final int n2, final int n3) {
        for (final RBlock rBlock : this.blocks) {
            if (rBlock.getX() == n && rBlock.getY() == n2 && rBlock.getZ() == n3) {
                return rBlock;
            }
        }
        return null;
    }
    
    public REntity a(final int n) {
        for (final REntity rEntity : this.entities) {
            if (rEntity.p() == n) {
                return rEntity;
            }
        }
        return null;
    }
}
