// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.gui.SimpleGUI;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.api.gui.GUI;

public class ShopGUIBuilder extends SimpleShopGUIBuilder
{
    private final ShopDesign.OpenEvent event;
    private final GUI gui;
    
    public ShopGUIBuilder(final ShopDesign.OpenEvent event) {
        this.event = event;
        this.gui = new GUI(b.a(ConfigValue.dealer_title_gui).c().f(null), 0) {
            @Override
            protected void onSetItem(final int n, final int n2, final GUIItem guiItem) {
            }
        };
        this.gui.autoRefresh = false;
    }
    
    public boolean addItem(final ShopItem shopItem) {
        return this.gui.addItem(this.getGUIItem(shopItem));
    }
    
    public boolean addItem(final ShopPage shopPage) {
        return this.gui.addItem(this.getGUIItem(shopPage));
    }
    
    public boolean addItem(final ShopPage shopPage, final int n) {
        return this.gui.addItem(this.getGUIItem(shopPage, n));
    }
    
    public boolean addItem(final ItemStack itemStack) {
        return this.gui.addItem(this.getGUIItem(itemStack));
    }
    
    public boolean addItem(final ShopItem shopItem, @Nullable final GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(shopItem), addItemFlag);
    }
    
    public boolean addItem(final ShopPage shopPage, @Nullable final GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(shopPage), addItemFlag);
    }
    
    public boolean addItemWithData(final ShopPage shopPage, @Nullable final GUI.AddItemFlag addItemFlag, final int n) {
        return this.gui.addItem(this.getGUIItem(shopPage, n), addItemFlag);
    }
    
    public boolean addItem(final ItemStack itemStack, @Nullable final GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(itemStack), addItemFlag);
    }
    
    public void setItemAt(final ShopItem shopItem, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(shopItem), n, n2);
    }
    
    public void setItemAt(final ShopItem shopItem, final int n) {
        this.gui.setItemAt(this.getGUIItem(shopItem), n);
    }
    
    public void setItemAt(final ShopPage shopPage, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(shopPage), n, n2);
    }
    
    public void setItemAt(final ShopPage shopPage, final int n) {
        this.gui.setItemAt(this.getGUIItem(shopPage), n);
    }
    
    public void setItemAtWithData(final ShopPage shopPage, final int n, final int n2, final int n3) {
        this.gui.setItemAt(this.getGUIItem(shopPage, n3), n, n2);
    }
    
    public void setItemAtWithData(final ShopPage shopPage, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(shopPage, n2), n);
    }
    
    public void setItemAt(final ItemStack itemStack, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n, n2);
    }
    
    public void setItemAtWithData(final ShopPage shopPage, final ItemStack itemStack, final int n, final int n2, final int n3) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopPage, n3), n, n2);
    }
    
    public void setItemAt(final ShopItem shopItem, final ItemStack itemStack, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopItem), n, n2);
    }
    
    public void setItemAt(final ItemStack itemStack, final int n) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n);
    }
    
    public void setItemAtWithData(final ShopPage shopPage, final ItemStack itemStack, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopPage, n2), n);
    }
    
    public void setItemAt(final ShopItem shopItem, final ItemStack itemStack, final int n) {
        this.gui.setItemAt(this.getGUIItem(itemStack, shopItem), n);
    }
    
    public void setItemAt(final GUIItem guiItem, final int n, final int n2) {
        this.gui.setItemAt(guiItem, n, n2);
    }
    
    public void setItemAt(final GUIItem guiItem, final int n) {
        this.gui.setItemAt(guiItem, n);
    }
    
    public void setHomeItemAt(final ItemStack itemStack, final int n, final int n2) {
        this.gui.setItemAt(this.getHomeGUIItem(itemStack), n, n2);
    }
    
    public void setHomeItemAt(final ItemStack itemStack, final int n) {
        this.gui.setItemAt(this.getHomeGUIItem(itemStack), n);
    }
    
    public void setHeight(final int height) {
        this.gui.setHeight(height);
    }
    
    public void setTitle(final String title) {
        this.gui.setTitle(title);
    }
    
    public int getHeight() {
        return this.gui.getHeight();
    }
    
    public String getTitle() {
        return this.gui.getTitle();
    }
    
    private GUIItem getGUIItem(final ShopItem shopItem) {
        return this.getGUIItem(shopItem.getIcon(), shopItem);
    }
    
    private GUIItem getGUIItem(final ItemStack itemStack, final ShopItem attachment) {
        final GUIItem guiItem = new GUIItem(itemStack) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                if (ShopGUIBuilder.this.event.getShopDesign().listener != null) {
                    ShopGUIBuilder.this.event.getShopDesign().listener.onClick(player, attachment, b, b2, 0);
                }
            }
        };
        guiItem.attachment = attachment;
        return guiItem;
    }
    
    private GUIItem getGUIItem(final ShopPage shopPage, final int n) {
        return this.getGUIItem(shopPage.getIcon(), shopPage, n);
    }
    
    public GUIItem getGUIItem(final ItemStack itemStack, final ShopPage attachment, final int n) {
        final GUIItem guiItem = new GUIItem(itemStack) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                if (ShopGUIBuilder.this.event.getShopDesign().listener != null) {
                    ShopGUIBuilder.this.event.getShopDesign().listener.onClick(player, attachment, b, b2, n);
                }
            }
        };
        guiItem.attachment = attachment;
        return guiItem;
    }
    
    private GUIItem getGUIItem(final ShopPage shopPage) {
        return this.getGUIItem(shopPage, 0);
    }
    
    private GUIItem getGUIItem(final ItemStack itemStack) {
        return new GUIItem(itemStack) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
            }
        };
    }
    
    private GUIItem getHomeGUIItem(final ItemStack itemStack) {
        return new GUIItem(itemStack) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                if (ShopGUIBuilder.this.event.getShopDesign().listener != null) {
                    ShopGUIBuilder.this.event.getShopDesign().listener.onClick(player, null, b, b2, 0);
                }
            }
        };
    }
    
    public void centerAtY(final int n, final GUI.CenterFormatType centerFormatType, final int n2, final int n3) {
        this.gui.centerAtY(n, centerFormatType, n2, n3);
    }
    
    public void centerAtY(final int n, final GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtY(n, centerFormatType);
    }
    
    public void centerYAll(final GUI.CenterFormatType centerFormatType, final int n, final int n2) {
        this.gui.centerAtYAll(centerFormatType, n, n2);
    }
    
    public void centerYAll(final GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtYAll(centerFormatType);
    }
    
    public void centerAtX(final int n, final GUI.CenterFormatType centerFormatType, final int n2, final int n3) {
        this.gui.centerAtX(n, centerFormatType, n2, n3);
    }
    
    public void centerAtX(final int n, final GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtX(n, centerFormatType);
    }
    
    public void centerXAll(final GUI.CenterFormatType centerFormatType, final int n, final int n2) {
        this.gui.centerAtXAll(centerFormatType, n, n2);
    }
    
    public void centerXAll(final GUI.CenterFormatType centerFormatType) {
        this.gui.centerAtXAll(centerFormatType);
    }
    
    @Override
    public SimpleGUI export() {
        final GUIItem[][] items = this.gui.getItems();
        final GUIItem[][] array = s.a(items);
        for (int i = 0; i < items.length; ++i) {
            for (int j = 0; j < items[i].length; ++j) {
                final GUIItem guiItem = array[i][j];
                if (guiItem != null) {
                    if (guiItem.attachment != null) {
                        if (guiItem.attachment instanceof ShopItem) {
                            final ShopItem shopItem = (ShopItem)guiItem.attachment;
                            if (shopItem.getForceSlot() != null) {
                                if (items[i][j] == guiItem) {
                                    items[i][j] = null;
                                }
                                final int height = (int)Math.ceil((shopItem.getForceSlot() + 1) / 9.0);
                                if (this.gui.getHeight() < height) {
                                    this.gui.setHeight(height);
                                }
                                this.gui.setItemAt(guiItem, shopItem.getForceSlot());
                            }
                        }
                        else if (guiItem.attachment instanceof ShopPage) {
                            final ShopPage shopPage = (ShopPage)guiItem.attachment;
                            if (shopPage.getForceSlot() != null) {
                                if (items[i][j] == guiItem) {
                                    items[i][j] = null;
                                }
                                final int height2 = (int)Math.ceil((shopPage.getForceSlot() + 1) / 9.0);
                                if (this.gui.getHeight() < height2) {
                                    this.gui.setHeight(height2);
                                }
                                this.gui.setItemAt(guiItem, shopPage.getForceSlot());
                            }
                        }
                    }
                }
            }
        }
        return this.gui;
    }
    
    public GUI getGui() {
        return this.gui;
    }
}
