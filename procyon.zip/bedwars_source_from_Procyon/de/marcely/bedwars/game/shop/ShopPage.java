// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import org.bukkit.Material;
import java.util.ArrayList;
import org.bukkit.inventory.ItemStack;
import java.util.List;

public class ShopPage implements Cloneable
{
    private final String name;
    private final String displayName;
    private List<ShopItem> items;
    private ItemStack icon;
    private Integer forceSlot;
    
    public ShopPage(final String name) {
        this.items = new ArrayList<ShopItem>();
        this.icon = new ItemStack(Material.STONE);
        this.name = name;
        this.displayName = b.a(name).c().b().f(null);
    }
    
    public ItemStack getIcon() {
        return this.icon.clone();
    }
    
    public ShopPage clone() {
        try {
            final ShopPage page = (ShopPage)super.clone();
            page.items = new ArrayList<ShopItem>(this.items.size());
            final Iterator<ShopItem> iterator = this.items.iterator();
            while (iterator.hasNext()) {
                final ShopItem clone = iterator.next().clone();
                clone.setPage(page);
                page.items.add(clone);
            }
            return page;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDisplayName() {
        return this.displayName;
    }
    
    public List<ShopItem> getItems() {
        return this.items;
    }
    
    public void setIcon(final ItemStack icon) {
        this.icon = icon;
    }
    
    public Integer getForceSlot() {
        return this.forceSlot;
    }
    
    public void setForceSlot(final Integer forceSlot) {
        this.forceSlot = forceSlot;
    }
}
