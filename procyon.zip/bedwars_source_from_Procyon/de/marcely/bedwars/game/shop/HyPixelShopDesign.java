// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.d;
import de.marcely.bedwars.api.gui.GUI;
import java.util.List;
import de.marcely.bedwars.util.i;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import java.util.ArrayList;

public class HyPixelShopDesign extends ShopDesign
{
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null) {
            for (final ShopPage shopPage : openEvent.getPages()) {
                final ArrayList<String> list = new ArrayList<String>();
                list.add(b.a(Language.Shop_D_HyPixel_Avaible).f((CommandSender)openEvent.getPlayer()));
                final Iterator<ShopItem> iterator2 = shopPage.getItems().iterator();
                while (iterator2.hasNext()) {
                    list.add(ChatColor.DARK_GRAY + " \u2022 " + ChatColor.GRAY + iterator2.next().getDisplayName());
                }
                list.add("");
                list.add(b.a(Language.Shop_D_HyPixel_ClickToBrowse).f((CommandSender)openEvent.getPlayer()));
                shopPage.setIcon(i.a(shopPage.getIcon(), list));
                shopGUIBuilder.addItem(shopPage, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        }
        else {
            for (final ShopItem shopItem : openEvent.getOpen().getItems()) {
                if (shopItem.getPrices().size() >= 2) {
                    d.d("The HyPixel shop design only displays 1 price per item!", "Shop");
                }
                final ArrayList<String> list2 = new ArrayList<String>();
                final ShopPrice shopPrice = shopItem.getPrices().get(0);
                list2.add(b.a(Language.Shop_D_HyPixel_Items).f((CommandSender)openEvent.getPlayer()));
                for (final ShopProduct shopProduct : shopItem.getProducts()) {
                    list2.add(ChatColor.DARK_GRAY + " \u2022 " + ChatColor.GRAY + shopProduct.getDisplayName() + ChatColor.DARK_GRAY + " x" + shopProduct.getAmount());
                }
                list2.add("");
                list2.add(b.a(Language.Shop_D_HyPixel_Cost).a("amount", new StringBuilder().append(shopPrice.getPrice(openEvent.getPlayer())).toString()).a("type", shopPrice.getSpawner().getName(true)).a("color", new StringBuilder().append((shopPrice.getSpawner().getChatColor() != null) ? shopPrice.getSpawner().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()));
                list2.add("");
                list2.add(b.a((shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) > 0) ? Language.Shop_D_HyPixel_ClickToPurchase : Language.Shop_D_HyPixel_TooExpensive).a("amount", new StringBuilder().append(shopPrice.getPrice(openEvent.getPlayer())).toString()).a("type", shopPrice.getSpawner().getName(true)).a("color", new StringBuilder().append((shopPrice.getSpawner().getChatColor() != null) ? shopPrice.getSpawner().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()));
                shopItem.setIcon(i.a(shopItem.getIcon(), list2));
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            shopGUIBuilder.setHomeItemAt(i.a(new ItemStack(Material.ARROW), b.a(Language.Shop_D_HyPixel_GoBack).f((CommandSender)openEvent.getPlayer())), 4, shopGUIBuilder.getHeight() - 1);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
        return shopGUIBuilder;
    }
}
