// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.List;
import org.bukkit.entity.Player;

public abstract class ShopDesign implements Cloneable
{
    public ClickListener listener;
    
    public abstract SimpleShopGUIBuilder open(final OpenEvent p0);
    
    public ShopDesign clone() {
        try {
            return (ShopDesign)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public abstract static class OpenEvent
    {
        private final ShopDesign shopDesign;
        private final Player player;
        private final List<ShopPage> pages;
        private final ShopPage open;
        private final int data;
        public SimpleShopGUIBuilder builder;
        private boolean openingPage;
        
        public OpenEvent(final ShopDesign shopDesign, final Player player, final List<ShopPage> pages, final ShopPage open, final int data) {
            this.openingPage = false;
            this.player = player;
            this.shopDesign = shopDesign;
            this.pages = pages;
            this.open = open;
            this.data = data;
        }
        
        public abstract void refresh();
        
        public ShopDesign getShopDesign() {
            return this.shopDesign;
        }
        
        public Player getPlayer() {
            return this.player;
        }
        
        public List<ShopPage> getPages() {
            return this.pages;
        }
        
        public ShopPage getOpen() {
            return this.open;
        }
        
        public int getData() {
            return this.data;
        }
        
        public boolean isOpeningPage() {
            return this.openingPage;
        }
    }
    
    public interface ClickListener
    {
        void onClick(final Player p0, final Object p1, final boolean p2, final boolean p3, final int p4);
    }
}
