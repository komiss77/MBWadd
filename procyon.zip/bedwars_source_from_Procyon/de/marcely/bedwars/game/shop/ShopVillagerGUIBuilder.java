// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Collection;
import de.marcely.bedwars.api.gui.SimpleGUI;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.config.ConfigValue;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.api.gui.VillagerGUI;

public class ShopVillagerGUIBuilder extends SimpleShopGUIBuilder
{
    private final VillagerGUI gui;
    private List<VillagerGUI.VillagerOffer> offers;
    
    public ShopVillagerGUIBuilder(final ShopDesign.OpenEvent openEvent) {
        this.offers = new ArrayList<VillagerGUI.VillagerOffer>();
        this.gui = new VillagerGUI(b.a(ConfigValue.dealer_title_gui).c().f(null));
    }
    
    public void addOffer(final VillagerGUI.VillagerOffer villagerOffer) {
        this.offers.add(villagerOffer);
    }
    
    public boolean removeOffer(final VillagerGUI.VillagerOffer villagerOffer) {
        return this.offers.remove(villagerOffer);
    }
    
    public List<VillagerGUI.VillagerOffer> getOffers() {
        return this.offers;
    }
    
    @Override
    public SimpleGUI export() {
        this.gui.getOffers().addAll(this.offers);
        return this.gui;
    }
}
