// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.util.i;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.versions.Version;

public class MinesuchtShopDesign extends ShopDesign
{
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
        }
        final ItemStack a = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)7), " ");
        for (int i = 0; i < 9; ++i) {
            shopGUIBuilder.addItem(a);
        }
        final Iterator<ShopPage> iterator = openEvent.getPages().iterator();
        while (iterator.hasNext()) {
            shopGUIBuilder.addItem(iterator.next());
        }
        for (int j = 1; j < shopGUIBuilder.getHeight(); ++j) {
            shopGUIBuilder.centerAtY(j, GUI.CenterFormatType.Normal);
        }
        shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        for (int k = 0; k < 9; ++k) {
            shopGUIBuilder.setItemAt(a, k, shopGUIBuilder.getHeight() - 1);
        }
        final int height = shopGUIBuilder.getHeight();
        if (openEvent.getOpen() != null) {
            shopGUIBuilder.setHeight(6);
            final int n = (int)((6 - height) / 1.5f);
            for (final ShopItem shopItem : openEvent.getOpen().getItems()) {
                final ArrayList list = new ArrayList<String>(shopItem.getPrices().size());
                list.add("");
                for (final ShopPrice shopPrice : shopItem.getPrices()) {
                    list.add(shopPrice.getSpawner().getChatColor() + " " + shopPrice.getPrice(openEvent.getPlayer()) + " " + shopPrice.getSpawner().getName());
                }
                shopItem.setIcon(i.a(shopItem.getIcon(), (List<String>)list));
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithinY(n, 6));
            }
            for (int l = n; l < 6; ++l) {
                shopGUIBuilder.centerAtY(l, GUI.CenterFormatType.Beautiful);
            }
            for (int n2 = 0; n2 < 9; ++n2) {
                shopGUIBuilder.centerAtX(n2, GUI.CenterFormatType.Beautiful, height, 6);
            }
        }
        return shopGUIBuilder;
    }
}
