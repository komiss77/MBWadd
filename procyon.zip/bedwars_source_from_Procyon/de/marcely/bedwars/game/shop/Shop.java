// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.api.event.ShopBuyEvent;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Iterator;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.api.event.ShopGUIBuildEvent;
import java.util.List;
import org.bukkit.enchantments.Enchantment;
import java.util.Map;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import de.marcely.bedwars.api.event.PlayerOpenShopEvent;
import de.marcely.bedwars.config.m;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class Shop
{
    public static void eOpen(final Player player, final Arena arena, final ShopOpenType shopOpenType) {
        if (arena == null) {
            new NullPointerException("arena is null").printStackTrace();
            return;
        }
        final PlayerOpenShopEvent playerOpenShopEvent = new PlayerOpenShopEvent(player, m.a);
        Bukkit.getPluginManager().callEvent((Event)playerOpenShopEvent);
        if (playerOpenShopEvent.isCancelled()) {
            return;
        }
        open(player, arena, null, playerOpenShopEvent.getDesign(), shopOpenType);
    }
    
    public static void open(final Player player, @Nullable final Arena arena, final ShopOpenType shopOpenType) {
        open(player, arena, null, shopOpenType);
    }
    
    public static void open(final Player player, final ShopOpenType shopOpenType) {
        open(player, null, null, shopOpenType);
    }
    
    public static void open(final Player player, @Nullable final Arena arena, @Nullable final ShopPage shopPage, final ShopOpenType shopOpenType) {
        open(player, null, shopPage, m.a, shopOpenType);
    }
    
    public static void open(final Player player, @Nullable final ShopPage shopPage, final ShopOpenType shopOpenType) {
        open(player, null, shopPage, m.a, shopOpenType);
    }
    
    public static void open(final Player player, final ShopDesignData shopDesignData, final ShopOpenType shopOpenType) {
        open(player, null, null, shopDesignData, shopOpenType);
    }
    
    public static void open(final Player player, @Nullable final Arena arena, @Nullable final ShopPage shopPage, final ShopDesignData shopDesignData, final ShopOpenType shopOpenType) {
        open(player, arena, shopPage, shopDesignData, shopOpenType, 0);
    }
    
    public static void open(final Player player, @Nullable final Arena arena, @Nullable final ShopPage shopPage, final ShopDesignData shopDesignData, final ShopOpenType shopOpenType, final int n) {
        s.a.start();
        Sound.VILLAGERSHOP_OPEN.play(player);
        final ShopDesign clone = shopDesignData.getDesign().clone();
        clone.listener = new ShopDesign.ClickListener() {
            @Override
            public void onClick(final Player player, final Object o, final boolean b, final boolean b2, final int n) {
                final Arena a = s.a(player);
                if (o == null) {
                    Shop.open(player, a, null, shopDesignData, shopOpenType);
                    return;
                }
                if (o instanceof ShopPage) {
                    final ShopPage shopPage = (ShopPage)o;
                    if (shopPage == null || !shopPage.getName().equals(shopPage.getName()) || n != n) {
                        Shop.open(player, a, shopPage, shopDesignData, shopOpenType, n);
                    }
                }
                else if (o instanceof ShopItem) {
                    final ShopItem shopItem = (ShopItem)o;
                    final ItemStack icon = shopItem.getIcon();
                    i.a(icon, new String[0]);
                    i.a(icon, ChatColor.WHITE + shopItem.getName());
                    buy(a, player, shopItem, b2, shopOpenType);
                }
            }
        };
        final ArrayList<ShopPage> list = new ArrayList<ShopPage>(s.ah.size());
        ShopPage shopPage2 = null;
        final Iterator<ShopPage> iterator = s.ah.iterator();
        while (iterator.hasNext()) {
            final ShopPage clone2 = iterator.next().clone();
            ItemStack itemStack = clone2.getIcon();
            if (!clone2.getDisplayName().isEmpty()) {
                itemStack = i.a(clone2.getIcon(), ChatColor.WHITE + clone2.getDisplayName());
            }
            clone2.setIcon(Version.a().removeAttributes(i.a(itemStack, new String[0])));
            if (shopPage != null && clone2.getName().equals(shopPage.getName())) {
                shopPage2 = clone2;
            }
            list.add(clone2);
            final Iterator<ShopItem> iterator2 = clone2.getItems().iterator();
            final Team team = (arena != null && arena.a(player) != null) ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
            while (iterator2.hasNext()) {
                final ShopItem shopItem = iterator2.next();
                if (shopItem.getBuyGroup() != null && shopItem.getBuyGroupLevel() == 0) {
                    iterator2.remove();
                }
                else {
                    ItemStack itemStack2 = shopItem.getIcon();
                    if (!shopItem.getDisplayName().isEmpty()) {
                        itemStack2 = i.a(shopItem.getIcon(), ChatColor.WHITE + shopItem.getDisplayName());
                    }
                    final ItemStack a = i.a(itemStack2, team);
                    final ItemMeta itemMeta = a.getItemMeta();
                    for (final Map.Entry<Enchantment, Integer> entry : shopItem.getIconEnchantments().entrySet()) {
                        itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), true);
                    }
                    a.setItemMeta(itemMeta);
                    shopItem.setIcon(a);
                }
            }
        }
        final SimpleShopGUIBuilder open = clone.open(new ShopDesign.OpenEvent(clone, player, list, shopPage2, n) {
            @Override
            public void refresh() {
                Shop.open(player, arena, shopPage, shopDesignData, shopOpenType);
            }
        });
        if (open.getOpenPage() == null) {
            final ShopGUIBuildEvent shopGUIBuildEvent = new ShopGUIBuildEvent(player, clone, open.export());
            Bukkit.getPluginManager().callEvent((Event)shopGUIBuildEvent);
            if (shopGUIBuildEvent.getGUI() != null) {
                shopGUIBuildEvent.getGUI().open(player);
            }
        }
        else {
            open(player, arena, open.getOpenPage(), shopDesignData, shopOpenType);
        }
        s.a.a(l.a.f);
    }
    
    private static void buy(@Nullable final Arena arena, final Player player, final ShopItem shopItem, final boolean b, final ShopOpenType shopOpenType) {
        final int amountPlayerCanBuy = shopItem.getAmountPlayerCanBuy(player, b);
        final Team team = (arena != null && arena.a(player) != null) ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
        final ShopBuyEvent shopBuyEvent = new ShopBuyEvent(arena, player, shopItem, amountPlayerCanBuy, shopOpenType, b, getProblems(arena, player, team, shopItem, amountPlayerCanBuy));
        Bukkit.getPluginManager().callEvent((Event)shopBuyEvent);
        final Iterator<ShopPrice> iterator = shopItem.getPrices().iterator();
        while (iterator.hasNext()) {
            final DropType spawner = iterator.next().getSpawner();
            if (spawner.getCustomSpawner() != null) {
                spawner.getCustomSpawner().onBuyEvent(shopBuyEvent);
            }
        }
        final int amount = shopBuyEvent.getAmount();
        if (shopBuyEvent.getProblems().size() >= 1) {
            try {
                shopBuyEvent.getProblems().get(0).handleFeedback(shopBuyEvent);
            }
            catch (Error error) {
                error.printStackTrace();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            return;
        }
        Sound.VILLAGERSHOP_BUYSUCCESS.play(player);
        if (arena != null && (shopItem.isOneTimePurchase() || shopItem.isKeepOnDeath())) {
            final List<ShopItem> list = arena.u.get(player);
            if (!list.contains(shopItem.getOriginal())) {
                list.add(shopItem.getOriginal());
            }
        }
        if (shopItem.getBuyGroup() != null) {
            arena.v.get(team).put(shopItem.getOriginal().getBuyGroup(), shopItem.getBuyGroupLevel());
        }
        if (shopBuyEvent.isTakingPayments()) {
            for (final ShopPrice shopPrice : shopItem.getPrices()) {
                s.a(player, shopPrice.getSpawner().getActualItemstack().getType(), amount * shopPrice.getPrice(player));
            }
        }
        if (shopBuyEvent.isGivingProducts()) {
            final Iterator<ShopProduct> iterator3 = shopItem.getProducts().iterator();
            while (iterator3.hasNext()) {
                iterator3.next().give(player, team, amount, arena);
            }
        }
    }
    
    private static List<ShopBuyEvent.ShopBuyProblem> getProblems(@Nullable final Arena arena, final Player player, final Team team, final ShopItem shopItem, final int n) {
        final ArrayList<ShopBuyEvent.ShopBuyProblem> list = new ArrayList<ShopBuyEvent.ShopBuyProblem>();
        if (!shopItem.hasPermission(player)) {
            list.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_INSUFFICIENT_PERMISSIONS);
        }
        if (shopItem.isOneTimePurchase() && arena != null && arena.u.get(player).contains(shopItem.getOriginal())) {
            list.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_ONETIMEPURCHASE);
        }
        if (shopItem.getBuyGroup() != null && shopItem.getBuyGroupLevel() <= arena.v.get(team).getOrDefault(shopItem.getOriginal().getBuyGroup(), 0)) {
            list.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_BUYGROUP);
        }
        if (n == 0) {
            list.add(ShopBuyEvent.ShopBuyProblem.DEFAULT_NOT_ENOUGH_ITEMS);
        }
        return list;
    }
}
