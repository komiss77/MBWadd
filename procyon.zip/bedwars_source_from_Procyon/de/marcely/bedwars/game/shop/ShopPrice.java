// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.util.i;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.Permission;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import de.marcely.bedwars.game.DropType;

public class ShopPrice implements Cloneable
{
    private ShopItem item;
    @Nullable
    private DropType spawner;
    private int amount;
    @Nullable
    private Integer amountPerm;
    
    public ShopPrice(final ShopItem item) {
        this.spawner = null;
        this.amount = 1;
        this.amountPerm = null;
        this.item = item;
    }
    
    public int getPrice(final Player player) {
        return (this.amountPerm != null && s.hasPermission((CommandSender)player, Permission.ShopCustomPrice)) ? this.amountPerm : this.amount;
    }
    
    public int getAmountPlayerCanBuy(final Player player, final boolean b) {
        if (this.getSpawner().getActualItemstack() == null || this.getSpawner().getActualItemstack().getType() == null || this.getSpawner().getActualItemstack().getType() == Material.AIR) {
            return 0;
        }
        final int a = s.a(player, i.a(this.getSpawner().getActualItemstack().clone(), this.getSpawner().getChatColor() + this.getSpawner().getName(true)));
        if (a >= this.getPrice(player)) {
            int capsMultiply = 1;
            if (b) {
                capsMultiply = a / this.amount;
            }
            if (capsMultiply > this.item.getCapsMultiply()) {
                capsMultiply = this.item.getCapsMultiply();
            }
            return capsMultiply;
        }
        return 0;
    }
    
    public ShopPrice clone() {
        try {
            final ShopPrice shopPrice = (ShopPrice)super.clone();
            shopPrice.spawner = this.spawner.b();
            return shopPrice;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public ShopItem getItem() {
        return this.item;
    }
    
    public void setItem(final ShopItem item) {
        this.item = item;
    }
    
    @Nullable
    public DropType getSpawner() {
        return this.spawner;
    }
    
    public void setSpawner(@Nullable final DropType spawner) {
        this.spawner = spawner;
    }
    
    public int getAmount() {
        return this.amount;
    }
    
    public void setAmount(final int amount) {
        this.amount = amount;
    }
    
    @Nullable
    public Integer getAmountPerm() {
        return this.amountPerm;
    }
    
    public void setAmountPerm(@Nullable final Integer amountPerm) {
        this.amountPerm = amountPerm;
    }
}
