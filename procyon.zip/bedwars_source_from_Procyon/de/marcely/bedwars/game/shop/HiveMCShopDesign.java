// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.util.s;
import org.bukkit.Material;
import java.util.List;
import org.bukkit.ChatColor;
import java.util.ArrayList;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;

public class HiveMCShopDesign extends ShopDesign
{
    private static final String ICON = "\u25b6";
    
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null) {
            for (final ShopPage shopPage : openEvent.getPages()) {
                shopPage.setIcon(i.a(shopPage.getIcon(), "", b.a(Language.Shop_D_HiveMC_ClickToView).a("icon", "\u25b6").a("item", shopPage.getDisplayName()).f((CommandSender)openEvent.getPlayer())));
                shopGUIBuilder.addItem(shopPage, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        }
        else {
            for (final ShopItem shopItem : openEvent.getOpen().getItems()) {
                final ArrayList<String> list = new ArrayList<String>();
                for (int i = 1; i < shopItem.getProducts().size(); ++i) {
                    final ShopProduct shopProduct = shopItem.getProducts().get(i);
                    list.add(new StringBuilder().append(ChatColor.WHITE).append(ChatColor.BOLD).append(shopProduct.getAmount()).append("x ").append(ChatColor.AQUA).append(ChatColor.BOLD).append(shopProduct.getDisplayName()).toString());
                }
                list.add("");
                list.add(b.a(Language.Shop_D_HiveMC_Cost).f((CommandSender)openEvent.getPlayer()));
                for (final ShopPrice shopPrice : shopItem.getPrices()) {
                    list.add("  " + ChatColor.AQUA + shopPrice.getPrice(openEvent.getPlayer()) + " " + shopPrice.getSpawner().getName(true));
                }
                list.add("");
                list.add(b.a(Language.Shop_D_HiveMC_ClickToBuy).a("icon", "\u25b6").f((CommandSender)openEvent.getPlayer()));
                shopItem.setIcon(i.a(i.a(shopItem.getIcon(), list), new StringBuilder().append(ChatColor.WHITE).append(ChatColor.BOLD).append(shopItem.getProducts().get(0).getAmount()).append("x ").append(ChatColor.AQUA).append(ChatColor.BOLD).append(shopItem.getProducts().get(0).getDisplayName()).toString()));
                shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithin(1, 7, 1, 5));
            }
            shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal, 1, 8);
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            final ItemStack a = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)s.RAND.nextInt(15)), " ");
            for (int j = 0; j < 9; ++j) {
                shopGUIBuilder.setItemAt(a, j, 0);
                shopGUIBuilder.setItemAt(a, j, shopGUIBuilder.getHeight() - 1);
            }
            for (int k = 0; k < shopGUIBuilder.getHeight(); ++k) {
                shopGUIBuilder.setItemAt(a, 0, k);
                shopGUIBuilder.setItemAt(a, 8, k);
            }
            shopGUIBuilder.setHomeItemAt(i.a(i.a(new ItemStack(s.e), "", b.a(Language.Shop_D_HiveMC_ReturnToMenu).f((CommandSender)openEvent.getPlayer()), "", b.a(Language.Shop_D_HiveMC_ClickToGoBack).a("icon", "\u25b6").f((CommandSender)openEvent.getPlayer())), b.a(Language.Shop_D_HiveMC_GoBack).f((CommandSender)openEvent.getPlayer())), 4, shopGUIBuilder.getHeight() - 1);
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
        }
        return shopGUIBuilder;
    }
}
