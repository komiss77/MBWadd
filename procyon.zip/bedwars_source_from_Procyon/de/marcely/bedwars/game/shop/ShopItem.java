// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.config.ConfigValue;
import java.util.Iterator;
import java.util.Collection;
import java.util.Collections;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import java.util.HashMap;
import org.bukkit.Material;
import java.util.ArrayList;
import org.bukkit.enchantments.Enchantment;
import java.util.Map;
import org.bukkit.inventory.ItemStack;
import java.util.List;

public class ShopItem implements Cloneable
{
    private ShopPage page;
    private final String name;
    private final String displayName;
    private List<ShopProduct> products;
    private List<ShopPrice> prices;
    private ItemStack icon;
    private final Map<Enchantment, Integer> iconEnchantments;
    private boolean keepOnDeath;
    private boolean oneTimePurchase;
    private int capsMultiply;
    private BuyGroup buyGroup;
    private int buyGroupLevel;
    private Integer forceSlot;
    private ShopItem original;
    
    public ShopItem(final ShopPage page, final String name) {
        this.products = new ArrayList<ShopProduct>();
        this.prices = new ArrayList<ShopPrice>();
        this.icon = new ItemStack(Material.STONE);
        this.iconEnchantments = new HashMap<Enchantment, Integer>();
        this.keepOnDeath = false;
        this.oneTimePurchase = false;
        this.capsMultiply = 1;
        this.original = null;
        this.page = page;
        this.name = name;
        this.displayName = b.a(name).b().c().f(null);
    }
    
    public ShopItem getOriginal() {
        return (this.original != null) ? this.original.getOriginal() : this;
    }
    
    public void setIcon(final ItemStack icon) {
        this.icon = icon;
    }
    
    public ItemStack getIcon() {
        if (this.getProducts().size() == 1) {
            this.icon.setAmount(this.getProducts().get(0).getAmount());
        }
        return this.icon;
    }
    
    public int getAmountPlayerCanBuy(final Player player, final boolean b) {
        final ArrayList<Integer> coll = new ArrayList<Integer>();
        final Iterator<ShopPrice> iterator = this.prices.iterator();
        while (iterator.hasNext()) {
            coll.add(iterator.next().getAmountPlayerCanBuy(player, b));
        }
        return (int)Collections.min((Collection<?>)coll);
    }
    
    public boolean hasPermission(final Player player) {
        if (ConfigValue.specialitem_requiredpermission) {
            for (final ShopProduct shopProduct : this.products) {
                if (shopProduct instanceof ShopSpecialProduct && !s.hasPermission((CommandSender)player, Permission.SpecialItem.replace("id", ((ShopSpecialProduct)shopProduct).getExtraItem().getName()))) {
                    return false;
                }
            }
        }
        return true;
    }
    
    public ShopItem clone() {
        try {
            final ShopItem shopItem = (ShopItem)super.clone();
            shopItem.products = new ArrayList<ShopProduct>(this.products.size());
            final Iterator<ShopProduct> iterator = this.products.iterator();
            while (iterator.hasNext()) {
                final ShopProduct clone = iterator.next().clone();
                clone.setItem(shopItem);
                shopItem.products.add(clone);
            }
            shopItem.prices = new ArrayList<ShopPrice>(this.prices.size());
            final Iterator<ShopPrice> iterator2 = this.prices.iterator();
            while (iterator2.hasNext()) {
                final ShopPrice clone2 = iterator2.next().clone();
                clone2.setItem(shopItem);
                shopItem.prices.add(clone2);
            }
            shopItem.icon = ((this.icon != null) ? this.icon.clone() : null);
            shopItem.iconEnchantments.putAll(this.iconEnchantments);
            shopItem.original = ((this.original != null) ? this.original : this);
            shopItem.buyGroup = ((this.buyGroup != null) ? this.buyGroup.clone() : null);
            return shopItem;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public ShopPage getPage() {
        return this.page;
    }
    
    public void setPage(final ShopPage page) {
        this.page = page;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getDisplayName() {
        return this.displayName;
    }
    
    public List<ShopProduct> getProducts() {
        return this.products;
    }
    
    public List<ShopPrice> getPrices() {
        return this.prices;
    }
    
    public Map<Enchantment, Integer> getIconEnchantments() {
        return this.iconEnchantments;
    }
    
    public boolean isKeepOnDeath() {
        return this.keepOnDeath;
    }
    
    public boolean isOneTimePurchase() {
        return this.oneTimePurchase;
    }
    
    public void setKeepOnDeath(final boolean keepOnDeath) {
        this.keepOnDeath = keepOnDeath;
    }
    
    public void setOneTimePurchase(final boolean oneTimePurchase) {
        this.oneTimePurchase = oneTimePurchase;
    }
    
    public int getCapsMultiply() {
        return this.capsMultiply;
    }
    
    public void setCapsMultiply(final int capsMultiply) {
        this.capsMultiply = capsMultiply;
    }
    
    public BuyGroup getBuyGroup() {
        return this.buyGroup;
    }
    
    public void setBuyGroup(final BuyGroup buyGroup) {
        this.buyGroup = buyGroup;
    }
    
    public int getBuyGroupLevel() {
        return this.buyGroupLevel;
    }
    
    public void setBuyGroupLevel(final int buyGroupLevel) {
        this.buyGroupLevel = buyGroupLevel;
    }
    
    public Integer getForceSlot() {
        return this.forceSlot;
    }
    
    public void setForceSlot(final Integer forceSlot) {
        this.forceSlot = forceSlot;
    }
}
