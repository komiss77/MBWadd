// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BuyGroup implements Cloneable
{
    private final String name;
    private Map<Integer, List<ShopItem>> items;
    
    public BuyGroup(final String name) {
        this.items = new LinkedHashMap<Integer, List<ShopItem>>();
        this.name = name;
    }
    
    public BuyGroup clone() {
        try {
            final BuyGroup buyGroup = (BuyGroup)super.clone();
            buyGroup.items = new LinkedHashMap<Integer, List<ShopItem>>();
            for (final Map.Entry<Integer, List<ShopItem>> entry : this.items.entrySet()) {
                buyGroup.items.put(entry.getKey(), new ArrayList<ShopItem>(entry.getValue()));
            }
            return buyGroup;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public Map<Integer, List<ShopItem>> getItems() {
        return this.items;
    }
}
