// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import de.marcely.bedwars.d;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.i;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

public class BergwerklabsShopDesign extends ShopDesign
{
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() == null && openEvent.getPages().size() >= 1) {
            shopGUIBuilder.setOpenPage(openEvent.getPages().get(0));
        }
        else if (openEvent.getOpen().getItems().size() >= 1) {
            final ItemStack a = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15), " ");
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
            for (final ShopPage shopPage : openEvent.getPages()) {
                shopPage.setIcon(i.a(shopPage.getIcon(), ChatColor.GOLD + ">> " + ChatColor.YELLOW + shopPage.getDisplayName()));
                shopGUIBuilder.addItem(shopPage);
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            for (int i = 0; i < 9; ++i) {
                shopGUIBuilder.setItemAt(a, i, shopGUIBuilder.getHeight() - 1);
            }
            if (openEvent.getOpen().getItems().size() == 0) {
                return shopGUIBuilder;
            }
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 4);
            final int data = openEvent.getData();
            final int n = data / 6 + 1;
            int n2 = openEvent.getOpen().getItems().size() - data;
            if (n2 > 6) {
                n2 = 6;
                shopGUIBuilder.setItemAtWithData(openEvent.getOpen(), i.a(new ItemStack(Material.PAPER), b.a(Language.Shop_D_BergwerkLABS_ChangePage).a("page", new StringBuilder().append(n + 1).toString()).f((CommandSender)openEvent.getPlayer())), 8, shopGUIBuilder.getHeight() - 3, data + n2);
            }
            else {
                shopGUIBuilder.setItemAt(i.a(new ItemStack(s.e), " "), 8, shopGUIBuilder.getHeight() - 3);
            }
            if (data >= 1) {
                shopGUIBuilder.setItemAtWithData(openEvent.getOpen(), i.a(new ItemStack(Material.PAPER), b.a(Language.Shop_D_BergwerkLABS_ChangePage).a("page", new StringBuilder().append(n - 1).toString()).f((CommandSender)openEvent.getPlayer())), 8, shopGUIBuilder.getHeight() - 4, data - 6);
            }
            else {
                shopGUIBuilder.setItemAt(Version.a().addGlow(i.a(new ItemStack(Material.BOOK), b.a(Language.Shop_D_BergwerkLABS_CurrentPage).f((CommandSender)openEvent.getPlayer()))), 8, shopGUIBuilder.getHeight() - 4);
            }
            for (int j = 0; j < n2; ++j) {
                final ShopItem shopItem = openEvent.getOpen().getItems().get(j + data);
                if (shopItem.getPrices().size() >= 2) {
                    d.d("The BergwerkLABS shop design only displays 1 price!", "Shop");
                }
                final ShopPrice shopPrice = shopItem.getPrices().get(0);
                final int n3 = j + 1;
                shopGUIBuilder.setItemAt(i.a(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()), shopPrice.getSpawner().getChatColor() + shopPrice.getSpawner().getName()), n3, shopGUIBuilder.getHeight() - 4);
                shopGUIBuilder.setItemAt(shopItem.getIcon(), n3, shopGUIBuilder.getHeight() - 3);
                ItemStack itemStack;
                if (shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) >= 1) {
                    itemStack = i.a(new ItemStack(Material.INK_SACK, 1, (short)10), b.a(Language.Shop_D_BergwerkLABS_Buy).f((CommandSender)openEvent.getPlayer()));
                }
                else {
                    itemStack = i.a(new ItemStack(Material.INK_SACK, 1, (short)8), b.a(Language.Shop_D_BergwerkLABS_Buy_TooExpensive).f((CommandSender)openEvent.getPlayer()));
                }
                shopGUIBuilder.setItemAt(shopItem, itemStack, n3, shopGUIBuilder.getHeight() - 1);
            }
            for (int k = 0; k < 9; ++k) {
                shopGUIBuilder.setItemAt(a, k, shopGUIBuilder.getHeight() - 2);
            }
        }
        return shopGUIBuilder;
    }
}
