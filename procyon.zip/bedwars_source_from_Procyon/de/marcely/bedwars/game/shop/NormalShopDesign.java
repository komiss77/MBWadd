// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.d;
import java.util.ArrayList;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.i;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class NormalShopDesign extends ShopDesign
{
    private final ItemStack GLASS_CENTER;
    
    public NormalShopDesign() {
        this.GLASS_CENTER = i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)11), " ");
    }
    
    @Override
    public ShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
            shopGUIBuilder.setTitle(openEvent.getOpen().getDisplayName());
        }
        final Iterator<ShopPage> iterator = openEvent.getPages().iterator();
        while (iterator.hasNext()) {
            shopGUIBuilder.addItem(iterator.next());
        }
        if (openEvent.getOpen() != null) {
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            for (int i = 0; i < 9; ++i) {
                shopGUIBuilder.setItemAt(this.GLASS_CENTER, i, shopGUIBuilder.getHeight() - 1);
            }
            int n = shopGUIBuilder.getHeight() - 2;
            for (int j = 0; j < (openEvent.getOpen().getItems().size() + 8) / 9; ++j) {
                final ArrayList<ShopItem> list = new ArrayList<ShopItem>();
                for (int n2 = (openEvent.getOpen().getItems().size() - j * 9 > 9) ? 9 : (openEvent.getOpen().getItems().size() - j * 9), k = 0; k < n2; ++k) {
                    list.add(openEvent.getOpen().getItems().get(k + j * 9));
                }
                shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 2);
                n += 2;
                int n3 = 0;
                for (final ShopItem shopItem : list) {
                    if (shopItem.getPrices().size() >= 2) {
                        d.d("The Normal shop design only displays 1 price!", "Shop");
                    }
                    final ShopPrice shopPrice = shopItem.getPrices().get(0);
                    shopGUIBuilder.setItemAt(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()), n3, n);
                    shopGUIBuilder.setItemAt(shopItem, n3, n + 1);
                    ++n3;
                }
            }
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Beautiful);
        return shopGUIBuilder;
    }
}
