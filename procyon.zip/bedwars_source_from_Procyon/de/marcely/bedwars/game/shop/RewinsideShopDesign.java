// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import org.bukkit.ChatColor;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.d;
import de.marcely.bedwars.api.gui.VillagerGUI;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.api.gui.DecGUIItem;
import org.bukkit.entity.Player;
import java.util.HashMap;

public class RewinsideShopDesign extends ShopDesign
{
    private HashMap<Player, Boolean> usingNewOne;
    
    public RewinsideShopDesign() {
        this.usingNewOne = new HashMap<Player, Boolean>();
    }
    
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        if (openEvent.getOpen() != null && !this.playerIsUsingNewOne(openEvent.getPlayer())) {
            final ShopVillagerGUIBuilder shopVillagerGUIBuilder = new ShopVillagerGUIBuilder(openEvent);
            for (final ShopItem shopItem : this.getShopItems(openEvent)) {
                final ShopPrice shopPrice = shopItem.getPrices().get(0);
                if (shopItem.getProducts().size() == 1) {
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()))));
                }
                else {
                    final ShopPrice shopPrice2 = shopItem.getPrices().get(1);
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount())), new DecGUIItem(i.a(shopPrice2.getSpawner().getActualItemstack(), shopPrice2.getAmount()))));
                }
                if (shopItem.getProducts().size() >= 2) {
                    d.d("The Rewinside old shop design only displays 1 product per item!", "Shop");
                }
                if (shopItem.getPrices().size() >= 3) {
                    d.d("The Rewinside old shop design only displays 1 or 2 prices per item!", "Shop");
                }
            }
            return shopVillagerGUIBuilder;
        }
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getOpen() != null) {
            openEvent.getOpen().setIcon(Version.a().addGlow(openEvent.getOpen().getIcon()));
        }
        final Iterator<ShopPage> iterator2 = openEvent.getPages().iterator();
        while (iterator2.hasNext()) {
            shopGUIBuilder.addItem(iterator2.next());
        }
        if (openEvent.getOpen() != null) {
            final int height = shopGUIBuilder.getHeight();
            final Iterator<ShopItem> iterator3 = this.getShopItems(openEvent).iterator();
            while (iterator3.hasNext()) {
                shopGUIBuilder.addItem(iterator3.next(), GUI.AddItemFlag.createWithinY(height, 6));
            }
        }
        else {
            shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
            shopGUIBuilder.setItemAt(new GUIItem(i.a(i.a(new ItemStack(Material.SLIME_BALL), this.playerIsUsingNewOne(openEvent.getPlayer()) ? b.a(Language.Shop_D_Rewinside_ShopType_New).f((CommandSender)openEvent.getPlayer()) : b.a(Language.Shop_D_Rewinside_ShopType_Old).f((CommandSender)openEvent.getPlayer())), new String[] { b.a(Language.Shop_D_Rewinside_ShopType_Switch).f((CommandSender)openEvent.getPlayer()) })) {
                @Override
                public void onClick(final Player key, final boolean b, final boolean b2) {
                    RewinsideShopDesign.this.usingNewOne.put(key, !RewinsideShopDesign.this.playerIsUsingNewOne(key));
                    openEvent.refresh();
                }
            }, 4, shopGUIBuilder.getHeight() - 1);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal);
        return shopGUIBuilder;
    }
    
    private List<ShopItem> getShopItems(final OpenEvent openEvent) {
        for (final ShopItem shopItem : openEvent.getOpen().getItems()) {
            final ArrayList<String> list = new ArrayList<String>();
            list.add("");
            for (final ShopPrice shopPrice : shopItem.getPrices()) {
                list.add(" " + ChatColor.GRAY + shopPrice.getPrice(openEvent.getPlayer()) + " " + shopPrice.getSpawner().getChatColor() + shopPrice.getSpawner().getName(true));
            }
            shopItem.setIcon(i.a(shopItem.getIcon(), list));
        }
        return openEvent.getOpen().getItems();
    }
    
    private boolean playerIsUsingNewOne(final Player player) {
        return !this.usingNewOne.containsKey(player) || this.usingNewOne.get(player);
    }
}
