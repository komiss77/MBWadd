// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import java.util.Iterator;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;

public class HyPixelUpgradeDesign extends UpgradeDesign
{
    @Override
    public SimpleUpgradeGUIBuilder open(final OpenEvent openEvent) {
        final UpgradeGUIBuilder upgradeGUIBuilder = new UpgradeGUIBuilder(openEvent);
        for (final UpgradeItem upgradeItem : openEvent.getItems()) {
            String s = "??";
            switch (upgradeItem.getState()) {
                case NOT_UPGRADEABLE: {
                    s = b.a(Language.TooFew_Materials).f((CommandSender)openEvent.getPlayer());
                    break;
                }
                case UPGRADEABLE: {
                    s = b.a(Language.Shop_D_HyPixel_ClickToPurchase).f((CommandSender)openEvent.getPlayer());
                    break;
                }
                case MAXIMUM: {
                    s = b.a(Language.Upgrade_Maximum).f((CommandSender)openEvent.getPlayer());
                    break;
                }
            }
            upgradeItem.setIcon(i.b(upgradeItem.getIcon(), "", b.a(Language.Shop_D_HyPixel_Cost).a("amount", new StringBuilder().append(upgradeItem.getUpgrade().getPriceAmount()).toString()).a("type", upgradeItem.getUpgrade().getPrice().getName(true)).a("color", new StringBuilder().append((upgradeItem.getUpgrade().getPrice().getChatColor() != null) ? upgradeItem.getUpgrade().getPrice().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()), "", s));
            upgradeGUIBuilder.addItem(upgradeItem, GUI.AddItemFlag.createWithin(2, 6, 1, 6));
        }
        upgradeGUIBuilder.setHeight(upgradeGUIBuilder.getHeight() + 1);
        return upgradeGUIBuilder;
    }
}
