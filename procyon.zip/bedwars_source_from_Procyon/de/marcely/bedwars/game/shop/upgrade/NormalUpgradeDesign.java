// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import java.util.Iterator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;

public class NormalUpgradeDesign extends UpgradeDesign
{
    @Override
    public SimpleUpgradeGUIBuilder open(final OpenEvent openEvent) {
        final UpgradeGUIBuilder upgradeGUIBuilder = new UpgradeGUIBuilder(openEvent);
        upgradeGUIBuilder.setHeight(1);
        int n = 0;
        for (final UpgradeItem upgradeItem : openEvent.getItems()) {
            if (n % 7 == 0) {
                upgradeGUIBuilder.setHeight(upgradeGUIBuilder.getHeight() + 2);
            }
            String s = "??";
            short n2 = 0;
            switch (upgradeItem.getState()) {
                case NOT_UPGRADEABLE: {
                    s = b.a(Language.TooFew_Materials).f((CommandSender)openEvent.getPlayer());
                    n2 = 1;
                    break;
                }
                case UPGRADEABLE: {
                    s = b.a(Language.Shop_D_HyPixel_ClickToPurchase).f((CommandSender)openEvent.getPlayer());
                    n2 = 14;
                    break;
                }
                case MAXIMUM: {
                    s = b.a(Language.Upgrade_Maximum).f((CommandSender)openEvent.getPlayer());
                    n2 = 10;
                    break;
                }
            }
            if (upgradeItem.getUpgrade().getPrice() != null) {
                upgradeItem.setIcon(i.b(upgradeItem.getIcon(), "", b.a(Language.Shop_D_HyPixel_Cost).a("amount", new StringBuilder().append(upgradeItem.getUpgrade().getPriceAmount()).toString()).a("type", upgradeItem.getUpgrade().getPrice().getName(true)).a("color", new StringBuilder().append((upgradeItem.getUpgrade().getPrice().getChatColor() != null) ? upgradeItem.getUpgrade().getPrice().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()), "", s));
            }
            upgradeItem.setIcon(i.b(upgradeItem.getIcon(), "  " + ChatColor.DARK_GRAY + "[" + upgradeItem.getUpgrade().getLvl() + "/" + upgradeItem.getUpgrade().getMaxLvl() + "]"));
            upgradeGUIBuilder.addItem(upgradeItem, GUI.AddItemFlag.createWithin(1, 8, 1, 6));
            upgradeGUIBuilder.setItemAt(i.a(new ItemStack(Material.INK_SACK, 1, n2), " "), n + 19);
            ++n;
        }
        upgradeGUIBuilder.setHeight(upgradeGUIBuilder.getHeight() + 1);
        return upgradeGUIBuilder;
    }
}
