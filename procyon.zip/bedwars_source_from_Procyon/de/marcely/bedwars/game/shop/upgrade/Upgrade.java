// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import java.util.ArrayList;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.i;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import java.util.List;
import de.marcely.bedwars.flag.Value;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.DropType;

public class Upgrade
{
    private final UpgradeType type;
    private final int lvl;
    private final DropType price;
    private final int priceAmount;
    private final ItemStack icon;
    private final Value<?> value;
    private List<UpgradeEnchantment> enchantments;
    private String name;
    private String lore;
    int maxLvl;
    
    public Upgrade(final UpgradeType type, final int lvl, final ItemStack icon, final DropType price, final int priceAmount, @Nullable final Value<?> value) {
        this.enchantments = null;
        this.name = null;
        this.lore = null;
        this.type = type;
        this.lvl = lvl;
        this.icon = icon;
        this.price = price;
        this.priceAmount = priceAmount;
        this.value = value;
    }
    
    public ItemStack getIcon() {
        return this.icon.clone();
    }
    
    public boolean canBuy(final Player player) {
        return this.price != null && s.a(player, i.a(this.price.getActualItemstack(), this.price.getChatColor() + this.price.getName(true))) >= this.priceAmount;
    }
    
    @Nullable
    public Upgrade getNextLevel() {
        return (this.lvl < this.maxLvl) ? s.a(this.type, this.lvl + 1) : null;
    }
    
    public UpgradeType getType() {
        return this.type;
    }
    
    public int getLvl() {
        return this.lvl;
    }
    
    public DropType getPrice() {
        return this.price;
    }
    
    public int getPriceAmount() {
        return this.priceAmount;
    }
    
    public Value<?> getValue() {
        return this.value;
    }
    
    public List<UpgradeEnchantment> getEnchantments() {
        return this.enchantments;
    }
    
    public void setEnchantments(final List<UpgradeEnchantment> enchantments) {
        this.enchantments = enchantments;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getLore() {
        return this.lore;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setLore(final String lore) {
        this.lore = lore;
    }
    
    public int getMaxLvl() {
        return this.maxLvl;
    }
    
    public void setMaxLvl(final int maxLvl) {
        this.maxLvl = maxLvl;
    }
    
    public static class UpgradeBuilder
    {
        public UpgradeType type;
        public int lvl;
        public ItemStack icon;
        public DropType price;
        public int priceAmount;
        public Value<?> value;
        public List<UpgradeEnchantment> enchantments;
        public String name;
        public String lore;
        
        public UpgradeBuilder() {
            this.enchantments = new ArrayList<UpgradeEnchantment>();
            this.name = null;
            this.lore = null;
        }
        
        public void setValue(final String s) throws Exception {
            (this.value = (Value<?>)this.type.getValueClass().newInstance()).t(s);
        }
        
        @Nullable
        public Upgrade build() {
            final Upgrade upgrade = new Upgrade(this.type, this.lvl, this.icon, this.price, this.priceAmount, this.value);
            upgrade.setEnchantments(this.enchantments);
            if (this.name != null) {
                upgrade.setName(this.name);
            }
            if (this.lore != null) {
                upgrade.setLore(this.lore);
            }
            return upgrade;
        }
    }
}
