// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import java.util.Iterator;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.bo;
import java.util.ArrayList;
import java.util.List;

public class UpgradeDesignData
{
    private final UpgradeDesign design;
    private final String name;
    private final int id;
    private final UpgradeDesignType type;
    private static final List<UpgradeDesignData> designs;
    
    static {
        designs = new ArrayList<UpgradeDesignData>();
    }
    
    public UpgradeDesignData(final UpgradeDesign upgradeDesign, final String s) {
        this(upgradeDesign, s, -1, UpgradeDesignType.Custom);
    }
    
    @Deprecated
    public UpgradeDesignData(final UpgradeDesign design, final String name, final int id, final UpgradeDesignType type) {
        this.design = design;
        this.name = name;
        this.id = id;
        this.type = type;
    }
    
    public boolean register() {
        return !UpgradeDesignData.designs.contains(this) && UpgradeDesignData.designs.add(this);
    }
    
    public boolean unregister() {
        if (!this.isCustom()) {
            new bo("Only works for custom designs!").printStackTrace();
            return false;
        }
        return UpgradeDesignData.designs.remove(this);
    }
    
    public boolean isCustom() {
        return this.type == UpgradeDesignType.Custom;
    }
    
    public static UpgradeDesignData getDesignByName(final String s) {
        if (s.isInteger(s)) {
            final UpgradeDesignData designByID = getDesignByID(Integer.valueOf(s));
            if (designByID != null) {
                return designByID;
            }
        }
        for (final UpgradeDesignData upgradeDesignData : UpgradeDesignData.designs) {
            if (upgradeDesignData.name.equalsIgnoreCase(s)) {
                return upgradeDesignData;
            }
        }
        return null;
    }
    
    public static UpgradeDesignData getDesignByID(final int n) {
        for (final UpgradeDesignData upgradeDesignData : UpgradeDesignData.designs) {
            if (upgradeDesignData.id == n) {
                return upgradeDesignData;
            }
        }
        return null;
    }
    
    public UpgradeDesign getDesign() {
        return this.design;
    }
    
    public String getName() {
        return this.name;
    }
    
    public int getId() {
        return this.id;
    }
    
    public UpgradeDesignType getType() {
        return this.type;
    }
    
    public static List<UpgradeDesignData> getDesigns() {
        return UpgradeDesignData.designs;
    }
}
