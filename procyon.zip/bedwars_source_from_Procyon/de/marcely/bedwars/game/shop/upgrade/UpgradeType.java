// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.flag.Value;

public class UpgradeType
{
    final String identifier;
    final boolean isBeta;
    Class<? extends Value<?>> valueClass;
    String defaultName;
    String defaultLore;
    
    public UpgradeType(final String identifier, final boolean isBeta) {
        this.defaultName = "Namless Upgrade";
        this.defaultLore = "/";
        this.identifier = identifier;
        this.isBeta = isBeta;
    }
    
    public String getIdentifier() {
        return this.identifier;
    }
    
    public boolean isBeta() {
        return this.isBeta;
    }
    
    public Class<? extends Value<?>> getValueClass() {
        return this.valueClass;
    }
    
    public void setValueClass(final Class<? extends Value<?>> valueClass) {
        this.valueClass = valueClass;
    }
    
    public String getDefaultName() {
        return this.defaultName;
    }
    
    public String getDefaultLore() {
        return this.defaultLore;
    }
    
    public void setDefaultName(final String defaultName) {
        this.defaultName = defaultName;
    }
    
    public void setDefaultLore(final String defaultLore) {
        this.defaultLore = defaultLore;
    }
}
