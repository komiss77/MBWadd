// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import java.util.List;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.shop.ShopDesign;

public abstract class UpgradeDesign
{
    public ShopDesign.ClickListener listener;
    
    public abstract SimpleUpgradeGUIBuilder open(final OpenEvent p0);
    
    public static class OpenEvent
    {
        private final UpgradeDesign design;
        private final Player player;
        private final List<UpgradeItem> items;
        
        public OpenEvent(final UpgradeDesign design, final Player player, final List<UpgradeItem> items) {
            this.design = design;
            this.player = player;
            this.items = items;
        }
        
        public UpgradeDesign getDesign() {
            return this.design;
        }
        
        public Player getPlayer() {
            return this.player;
        }
        
        public List<UpgradeItem> getItems() {
            return this.items;
        }
    }
}
