// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.api.gui.SimpleGUI;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.api.gui.GUI;

public class UpgradeGUIBuilder extends SimpleUpgradeGUIBuilder
{
    private final UpgradeDesign.OpenEvent event;
    private final GUI gui;
    
    public UpgradeGUIBuilder(final UpgradeDesign.OpenEvent event) {
        this.event = event;
        this.gui = new GUI(b.a(ConfigValue.upgradedealer_title_gui).c().f(null), 0) {
            @Override
            protected void onSetItem(final int n, final int n2, final GUIItem guiItem) {
            }
        };
        this.gui.autoRefresh = false;
    }
    
    public boolean addItem(final UpgradeItem upgradeItem) {
        return this.gui.addItem(this.getGUIItem(upgradeItem));
    }
    
    public boolean addItem(final ItemStack itemStack) {
        return this.gui.addItem(this.getGUIItem(itemStack));
    }
    
    public boolean addItem(final UpgradeItem upgradeItem, @Nullable final GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(upgradeItem), addItemFlag);
    }
    
    public boolean addItem(final ItemStack itemStack, @Nullable final GUI.AddItemFlag addItemFlag) {
        return this.gui.addItem(this.getGUIItem(itemStack), addItemFlag);
    }
    
    public void setItemAt(final UpgradeItem upgradeItem, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(upgradeItem), n, n2);
    }
    
    public void setItemAt(final UpgradeItem upgradeItem, final int n) {
        this.gui.setItemAt(this.getGUIItem(upgradeItem), n);
    }
    
    public void setItemAt(final ItemStack itemStack, final int n, final int n2) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n, n2);
    }
    
    public void setItemAt(final ItemStack itemStack, final int n) {
        this.gui.setItemAt(this.getGUIItem(itemStack), n);
    }
    
    public void setHeight(final int height) {
        this.gui.setHeight(height);
    }
    
    public int getHeight() {
        return this.gui.getHeight();
    }
    
    private GUIItem getGUIItem(final UpgradeItem upgradeItem) {
        return new GUIItem(upgradeItem.getIcon()) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                UpgradeGUIBuilder.this.event.getDesign().listener.onClick(player, upgradeItem, b, b2, 0);
            }
        };
    }
    
    private GUIItem getGUIItem(final ItemStack itemStack) {
        return new GUIItem(itemStack) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
            }
        };
    }
    
    @Override
    public SimpleGUI export() {
        return this.gui;
    }
}
