// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.Language;
import javax.annotation.Nullable;
import de.marcely.bedwars.flag.f;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.j;
import org.bukkit.ChatColor;

public enum DefaultUpgradeType
{
    TEAM_SWORD_DAMAGE("team_sword_damage", ChatColor.AQUA + "%UpgradeShop_Name_SwordDamage%", ChatColor.GRAY + "%UpgradeShop_Lore_SwordDamage%", (Class<? extends Value<?>>)j.class), 
    TEAM_ARMOR_RESISTANCE("team_armor_resistance", ChatColor.AQUA + "%UpgradeShop_Name_Resistence%", ChatColor.GRAY + "%UpgradeShop_Lore_Resistence%", (Class<? extends Value<?>>)j.class), 
    SPAWN_HEALRANGE("spawn_healrange", ChatColor.AQUA + "%UpgradeShop_Name_HealRange%", ChatColor.GRAY + "%UpgradeShop_Lore_HealRange%", (Class<? extends Value<?>>)j.class), 
    SPAWN_ITEMSPAWNER_MULTIPLIER("spawn_itemspawner_multiplier", ChatColor.AQUA + "%UpgradeShop_Name_SpawnerMultiplier%", ChatColor.GRAY + "%UpgradeShop_Lore_SpawnerMultiplier%", (Class<? extends Value<?>>)f.class), 
    SPAWN_ENEMY_MININGFATIQUE("spawn_enemy_miningfatique", ChatColor.AQUA + "%UpgradeShop_Name_EnemyMiningFatique%", ChatColor.GRAY + "%UpgradeShop_Lore_EnemyMiningFatique%", (Class<? extends Value<?>>)j.class), 
    SPAWN_ENEMY_TRAP("spawn_enemy_trap", ChatColor.AQUA + "%UpgradeShop_Name_EnemyTrap%", ChatColor.GRAY + "%UpgradeShop_Lore_EnemyTrap%", (Class<? extends Value<?>>)j.class), 
    SPY(true, "spy", "", "", (Class<? extends Value<?>>)null);
    
    private final UpgradeType obj;
    
    private DefaultUpgradeType(final String s2, final String s3, final String s4, @Nullable final Class<? extends Value<?>> clazz) {
        this(false, s2, s3, s4, clazz);
    }
    
    private DefaultUpgradeType(final boolean b, final String s, final String s2, final String s3, @Nullable final Class<? extends Value<?>> valueClass) {
        (this.obj = new UpgradeType(s, b)).setDefaultName(Language.chatColorToString(s2));
        this.obj.setDefaultLore(Language.chatColorToString(s3));
        this.obj.setValueClass(valueClass);
        s.b(this.obj);
    }
    
    public ItemStack getItemStack() {
        return null;
    }
    
    public static void init() {
    }
    
    @Nullable
    public static DefaultUpgradeType byName(final String anotherString) {
        DefaultUpgradeType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final DefaultUpgradeType defaultUpgradeType = values[i];
            if (defaultUpgradeType.name().equalsIgnoreCase(anotherString)) {
                return defaultUpgradeType;
            }
        }
        return null;
    }
    
    public UpgradeType getObj() {
        return this.obj;
    }
}
