// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.game.location.XYZD;
import java.util.Iterator;
import java.util.Collection;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.DropType;
import java.util.Map;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.l;
import java.util.List;
import java.util.ArrayList;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.game.arena.i;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import de.marcely.bedwars.config.r;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class UpgradeShop
{
    public static void eOpen(final Player player, final Arena arena) {
        if (arena == null) {
            new NullPointerException("arena is null").printStackTrace();
            return;
        }
        open(player, arena, r.a);
    }
    
    public static void open(final Player player, @Nullable final Arena arena, final UpgradeDesignData upgradeDesignData) {
        s.a.start();
        final Team team = (arena != null) ? arena.a(player) : Team.values()[s.RAND.nextInt(Team.values().length)];
        final UpgradeDesign design = upgradeDesignData.getDesign();
        i i = (arena != null) ? arena.r.get(team) : null;
        if (i == null) {
            i = new i(null, team);
        }
        Sound.UPGRADESHOP_OPEN.play(player);
        design.listener = new ShopDesign.ClickListener() {
            @Override
            public void onClick(final Player player, final Object o, final boolean b, final boolean b2, final int n) {
                final Arena a = s.a(player);
                if (a == null || o == null) {
                    return;
                }
                if (o instanceof UpgradeItem) {
                    buy((UpgradeItem)o, player, a, upgradeDesignData);
                }
            }
        };
        final ArrayList<UpgradeItem> list = new ArrayList<UpgradeItem>();
        DefaultUpgradeType[] values;
        for (int length = (values = DefaultUpgradeType.values()).length, j = 0; j < length; ++j) {
            final DefaultUpgradeType defaultUpgradeType = values[j];
            final int a = i.a(defaultUpgradeType.getObj());
            final Upgrade a2 = s.a(defaultUpgradeType.getObj(), a);
            if (a > 1 || a2 != null) {
                list.add(new UpgradeItem(a2, (a < s.a(defaultUpgradeType.getObj()).getLvl()) ? (a2.canBuy(player) ? UpgradeItem.UpgradeState.UPGRADEABLE : UpgradeItem.UpgradeState.NOT_UPGRADEABLE) : UpgradeItem.UpgradeState.MAXIMUM));
            }
        }
        design.open(new UpgradeDesign.OpenEvent(design, player, list)).export().open(player);
        s.a.a(l.a.g);
    }
    
    private static void buy(final UpgradeItem upgradeItem, final Player player, final Arena arena, final UpgradeDesignData upgradeDesignData) {
        if (arena == null || arena.b() != ArenaStatus.f) {
            return;
        }
        final UpgradeType type = upgradeItem.getUpgrade().getType();
        final Team a = arena.a(player);
        final i i = arena.r.get(a);
        if (i == null) {
            return;
        }
        final int a2 = i.a(type);
        if (a == null) {
            return;
        }
        if (!upgradeItem.getUpgrade().canBuy(player)) {
            s.a((CommandSender)player, b.a(Language.TooFew_Materials));
            Sound.UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS.play(player);
            return;
        }
        if (a2 >= s.a(type).getLvl()) {
            s.a((CommandSender)player, b.a(Language.Upgrade_Buy_Max));
            Sound.UPGRADESHOP_BUYFAIL_TOOFEWMATERIALS.play(player);
            return;
        }
        final DropType price = upgradeItem.getUpgrade().getPrice();
        if (price == null) {
            return;
        }
        s.a(player, price.getActualItemstack().getType(), upgradeItem.getUpgrade().getPriceAmount());
        i.a(type, a2 + 1);
        Sound.UPGRADESHOP_BUYSUCCESS.play(player);
        if (type.equals(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj())) {
            final Iterator<Player> iterator = arena.a(a).iterator();
            while (iterator.hasNext()) {
                s.b(iterator.next(), Enchantment.DAMAGE_ALL, arena.a(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj(), a));
            }
        }
        else if (type.equals(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj())) {
            final Iterator<Player> iterator2 = arena.a(a).iterator();
            while (iterator2.hasNext()) {
                s.a(iterator2.next(), Enchantment.PROTECTION_ENVIRONMENTAL, arena.a(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj(), a));
            }
        }
        else if (type.equals(DefaultUpgradeType.SPAWN_ITEMSPAWNER_MULTIPLIER.getObj())) {
            final XYZD a3 = arena.a().a(a);
            for (final Map.Entry<DropType, XYZ> entry : arena.a().entrySet()) {
                if (a3.distance(entry.getValue()) <= ConfigValue.upgrade_spawnsize) {
                    for (final Arena.b b : new ArrayList<Arena.b>(arena.t.get(entry.getKey()))) {
                        if (b.c.equals(entry.getValue())) {
                            arena.t.get(entry.getKey()).remove(b);
                            break;
                        }
                    }
                    arena.t.get(entry.getKey()).add(new Arena.b(entry.getKey(), entry.getValue(), arena.a(DefaultUpgradeType.SPAWN_ITEMSPAWNER_MULTIPLIER.getObj(), a)));
                }
            }
        }
        final Upgrade nextLevel = upgradeItem.getUpgrade().getNextLevel();
        if (nextLevel != null && nextLevel.getEnchantments() != null) {
            for (final UpgradeEnchantment upgradeEnchantment : nextLevel.getEnchantments()) {
                for (final Player player2 : arena.a(a)) {
                    if (upgradeEnchantment.getType() == UpgradeEnchantment.UpgradeEnchantmentType.SWORD) {
                        s.b(player2, upgradeEnchantment.getEnchantment(), upgradeEnchantment.getLevel());
                    }
                    else {
                        if (upgradeEnchantment.getType() != UpgradeEnchantment.UpgradeEnchantmentType.ARMOR) {
                            continue;
                        }
                        s.a(player2, upgradeEnchantment.getEnchantment(), upgradeEnchantment.getLevel());
                    }
                }
            }
        }
        open(player, arena, upgradeDesignData);
    }
}
