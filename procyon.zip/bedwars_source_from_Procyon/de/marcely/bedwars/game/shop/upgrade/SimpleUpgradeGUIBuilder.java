// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.api.gui.SimpleGUI;

public abstract class SimpleUpgradeGUIBuilder
{
    public abstract SimpleGUI export();
}
