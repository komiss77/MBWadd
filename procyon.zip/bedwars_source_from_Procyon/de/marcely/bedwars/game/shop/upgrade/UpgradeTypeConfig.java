// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

public class UpgradeTypeConfig
{
    private final DefaultUpgradeType type;
    private String name;
    private String lore;
    
    public UpgradeTypeConfig(final DefaultUpgradeType type) {
        this.name = "";
        this.lore = "";
        this.type = type;
    }
    
    public DefaultUpgradeType getType() {
        return this.type;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getLore() {
        return this.lore;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void setLore(final String lore) {
        this.lore = lore;
    }
}
