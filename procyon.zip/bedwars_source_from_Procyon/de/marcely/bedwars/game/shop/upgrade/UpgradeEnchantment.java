// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import javax.annotation.Nullable;
import org.bukkit.enchantments.Enchantment;

public class UpgradeEnchantment
{
    private final UpgradeEnchantmentType type;
    private final Enchantment enchantment;
    private final int level;
    
    public UpgradeEnchantment(final UpgradeEnchantmentType type, final Enchantment enchantment, final int level) {
        this.type = type;
        this.enchantment = enchantment;
        this.level = level;
    }
    
    public UpgradeEnchantmentType getType() {
        return this.type;
    }
    
    public Enchantment getEnchantment() {
        return this.enchantment;
    }
    
    public int getLevel() {
        return this.level;
    }
    
    public enum UpgradeEnchantmentType
    {
        SWORD("SWORD", 0), 
        ARMOR("ARMOR", 1);
        
        private UpgradeEnchantmentType(final String name, final int ordinal) {
        }
        
        @Nullable
        public static UpgradeEnchantmentType ofName(final String s) {
            UpgradeEnchantmentType[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final UpgradeEnchantmentType upgradeEnchantmentType = values[i];
                if (upgradeEnchantmentType.name().equalsIgnoreCase(upgradeEnchantmentType.name())) {
                    return upgradeEnchantmentType;
                }
            }
            return null;
        }
    }
}
