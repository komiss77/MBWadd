// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import org.bukkit.ChatColor;
import de.marcely.bedwars.versions.Version;
import org.bukkit.inventory.ItemStack;

public class UpgradeItem
{
    private final Upgrade upgrade;
    private ItemStack icon;
    private final UpgradeState state;
    
    public UpgradeItem(final Upgrade upgrade, final UpgradeState state) {
        final String s = (upgrade.getName() != null) ? upgrade.getName() : upgrade.getType().getDefaultName();
        final String str = (upgrade.getLore() != null) ? upgrade.getLore() : upgrade.getType().getDefaultLore();
        this.upgrade = upgrade;
        this.icon = Version.a().removeAttributes(i.a(i.a(upgrade.getIcon(), ChatColor.WHITE + b.a(s).c().b().f(null)), de.marcely.bedwars.util.s.d(b.a(ChatColor.WHITE + str).c().b().f(null))));
        this.state = state;
    }
    
    public Upgrade getUpgrade() {
        return this.upgrade;
    }
    
    public ItemStack getIcon() {
        return this.icon;
    }
    
    public void setIcon(final ItemStack icon) {
        this.icon = icon;
    }
    
    public UpgradeState getState() {
        return this.state;
    }
    
    public enum UpgradeState
    {
        NOT_UPGRADEABLE("NOT_UPGRADEABLE", 0), 
        UPGRADEABLE("UPGRADEABLE", 1), 
        MAXIMUM("MAXIMUM", 2);
        
        private UpgradeState(final String name, final int ordinal) {
        }
    }
}
