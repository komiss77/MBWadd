// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop.upgrade;

import de.marcely.bedwars.bq;
import javax.annotation.Nullable;

public enum UpgradeDesignType
{
    Normal("Normal", 0, (UpgradeDesign)new NormalUpgradeDesign(), 0, false), 
    HyPixel("HyPixel", 1, (UpgradeDesign)new HyPixelUpgradeDesign(), 1, false), 
    Custom("Custom", 2);
    
    @Nullable
    private final UpgradeDesignData data;
    private final boolean isBeta;
    
    private UpgradeDesignType(final String name, final int ordinal) {
        this.data = null;
        this.isBeta = false;
    }
    
    private UpgradeDesignType(final String name, final int ordinal, final UpgradeDesign upgradeDesign, final int n, final boolean isBeta) {
        this.data = new UpgradeDesignData(upgradeDesign, this.name(), n, this);
        this.isBeta = isBeta;
        if (!this.data.register()) {
            new bq().printStackTrace();
        }
    }
    
    public static UpgradeDesignType byName(final String anotherString) {
        UpgradeDesignType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final UpgradeDesignType upgradeDesignType = values[i];
            if (upgradeDesignType.name().equalsIgnoreCase(anotherString)) {
                return upgradeDesignType;
            }
        }
        return null;
    }
    
    @Nullable
    public UpgradeDesignData getData() {
        return this.data;
    }
    
    public boolean isBeta() {
        return this.isBeta;
    }
}
