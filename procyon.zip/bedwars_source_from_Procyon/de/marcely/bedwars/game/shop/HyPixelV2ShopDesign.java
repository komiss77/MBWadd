// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.GUIItem;
import java.util.Iterator;
import java.util.List;
import de.marcely.bedwars.message.b;
import java.util.ArrayList;
import de.marcely.bedwars.d;
import org.bukkit.Material;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.i;
import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.util.s;

public class HyPixelV2ShopDesign extends ShopDesign
{
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
        if (openEvent.getPages().size() == 0) {
            shopGUIBuilder.setHeight(3);
            shopGUIBuilder.setItemAt(i.a(new ItemStack(s.e), ChatColor.RED + "/"), 4, 1);
            return shopGUIBuilder;
        }
        final ShopPage shopPage = (openEvent.getOpen() != null) ? openEvent.getOpen() : openEvent.getPages().get(0);
        for (final ShopPage shopPage2 : openEvent.getPages()) {
            ItemStack icon = i.a(shopPage2.getIcon(), ChatColor.GREEN + shopPage2.getDisplayName());
            if (shopPage2 != shopPage) {
                icon = i.a(icon, new String[] { Language.Shop_D_HyPixelV2_ClickToView.getMessage((CommandSender)openEvent.getPlayer()) });
            }
            shopPage2.setIcon(icon);
            shopGUIBuilder.addItem(shopPage2);
        }
        shopGUIBuilder.centerYAll(GUI.CenterFormatType.Normal);
        shopGUIBuilder.setHeight(shopGUIBuilder.getHeight() + 1);
        for (int i = 0; i < 9; ++i) {
            boolean b = false;
            for (int j = 0; j < shopGUIBuilder.getHeight() - 1; ++j) {
                final GUIItem item = shopGUIBuilder.getGui().getItemAt(i, j);
                final List<String> list = (item != null) ? i.a(item.getItemStack()) : null;
                if (list != null && list.size() >= 1) {
                    b = true;
                    break;
                }
            }
            shopGUIBuilder.setItemAt(i.a(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)(byte)(b ? 7 : 13)), new String[] { Language.Shop_D_HyPixelV2_Seperator_Items.getMessage((CommandSender)openEvent.getPlayer()) }), Language.Shop_D_HyPixelV2_Seperator_Categories.getMessage((CommandSender)openEvent.getPlayer())), i, shopGUIBuilder.getHeight() - 1);
        }
        final int height = shopGUIBuilder.getHeight();
        shopGUIBuilder.setHeight(6);
        for (final ShopItem shopItem : shopPage.getItems()) {
            if (shopItem.getPrices().size() >= 2) {
                d.d("The HyPixelV2 shop design only displays 1 price per item!", "Shop");
            }
            final ArrayList<String> list2 = new ArrayList<String>();
            final ShopPrice shopPrice = shopItem.getPrices().get(0);
            list2.add(b.a(Language.Shop_D_HyPixel_Cost).a("amount", new StringBuilder().append(shopPrice.getPrice(openEvent.getPlayer())).toString()).a("type", shopPrice.getSpawner().getName(true)).a("color", new StringBuilder().append((shopPrice.getSpawner().getChatColor() != null) ? shopPrice.getSpawner().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()));
            list2.add("");
            list2.add(b.a((shopItem.getAmountPlayerCanBuy(openEvent.getPlayer(), false) > 0) ? Language.Shop_D_HyPixel_ClickToPurchase : Language.Shop_D_HyPixel_TooExpensive).a("amount", new StringBuilder().append(shopPrice.getPrice(openEvent.getPlayer())).toString()).a("type", shopPrice.getSpawner().getName(true)).a("color", new StringBuilder().append((shopPrice.getSpawner().getChatColor() != null) ? shopPrice.getSpawner().getChatColor() : "").toString()).f((CommandSender)openEvent.getPlayer()));
            shopItem.setIcon(i.a(shopItem.getIcon(), list2));
            shopGUIBuilder.addItem(shopItem, GUI.AddItemFlag.createWithin(1, 8, height, 6));
        }
        return shopGUIBuilder;
    }
}
