// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import org.bukkit.inventory.meta.ItemMeta;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.ChatColor;
import javax.annotation.Nullable;
import de.marcely.bedwars.util.s;
import org.bukkit.enchantments.Enchantment;
import java.util.Map;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.Team;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public abstract class ShopProduct implements Cloneable
{
    protected ShopItem item;
    private int amount;
    private boolean autoWear;
    
    public ShopProduct(final ShopItem item) {
        this.amount = 1;
        this.autoWear = false;
        this.item = item;
    }
    
    public abstract ItemStack getItemStack();
    
    public abstract String getDisplayName();
    
    public abstract String getIdentifier();
    
    protected abstract ItemStack postPrepareGive(final Player p0, final ItemStack p1);
    
    public void give(final Player player, final Team team, final int n, final Arena arena) {
        this.give(player, n, arena.a(player, team, this.getItemStack()), team);
    }
    
    public ItemStack getGiveItem(final Player player, final Team team, final int n, final Arena arena) {
        return this.getGiveItem(player, n, arena.a(player, team, this.getItemStack()), team);
    }
    
    public ItemStack getGiveItem(final ItemStack itemStack, final Player player, final Team team, final int n, final Arena arena) {
        return this.getGiveItem(itemStack, player, n, arena.a(player, team, this.getItemStack()), team);
    }
    
    public void give(final Player player, final int n, final Map<Enchantment, Integer> map, final Team team) {
        final ItemStack giveItem = this.getGiveItem(player, n * this.getAmount(), map, team);
        if (!this.autoWear || !s.a(player, giveItem, true)) {
            s.a(player, giveItem);
        }
    }
    
    public ItemStack getGiveItem(final Player player, final int n, final Map<Enchantment, Integer> map, final Team team) {
        return this.getGiveItem(null, player, n, map, team);
    }
    
    public ItemStack getGiveItem(@Nullable ItemStack itemStack, final Player player, final int amount, final Map<Enchantment, Integer> map, final Team team) {
        final boolean b = itemStack == null;
        if (itemStack == null) {
            itemStack = this.getItemStack();
        }
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemStack.setAmount(amount);
        if (!this.item.getDisplayName().isEmpty()) {
            itemMeta.setDisplayName(ChatColor.WHITE + this.item.getDisplayName());
        }
        for (final Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            if (b) {
                entry.setValue(entry.getValue() + itemStack.getEnchantmentLevel((Enchantment)entry.getKey()));
            }
            itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), true);
        }
        itemStack.setItemMeta(itemMeta);
        if (ConfigValue.dye_block) {
            itemStack = i.a(itemStack, team);
        }
        return this.postPrepareGive(player, itemStack);
    }
    
    @Nullable
    public static ShopProduct newInstance(final String s, final ShopItem shopItem) {
        switch (s) {
            case "special": {
                return new ShopSpecialProduct(shopItem);
            }
            case "item": {
                return new ShopItemProduct(shopItem);
            }
            default:
                break;
        }
        return null;
    }
    
    public ShopProduct clone() {
        try {
            return (ShopProduct)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public ShopItem getItem() {
        return this.item;
    }
    
    public void setItem(final ShopItem item) {
        this.item = item;
    }
    
    public int getAmount() {
        return this.amount;
    }
    
    public void setAmount(final int amount) {
        this.amount = amount;
    }
    
    public boolean isAutoWear() {
        return this.autoWear;
    }
    
    public void setAutoWear(final boolean autoWear) {
        this.autoWear = autoWear;
    }
}
