// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import java.util.Iterator;
import de.marcely.bedwars.d;
import de.marcely.bedwars.api.gui.VillagerGUI;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUI;

public class GommeHDShopDesign extends ShopDesign
{
    @Override
    public SimpleShopGUIBuilder open(final OpenEvent openEvent) {
        if (openEvent.getOpen() == null) {
            final ShopGUIBuilder shopGUIBuilder = new ShopGUIBuilder(openEvent);
            for (int i = 0; i < 9; ++i) {
                shopGUIBuilder.addItem(this.createGlassPane());
            }
            final Iterator<ShopPage> iterator = openEvent.getPages().iterator();
            while (iterator.hasNext()) {
                shopGUIBuilder.addItem(iterator.next());
            }
            final int height = shopGUIBuilder.getHeight();
            shopGUIBuilder.setHeight(height + 1);
            for (int j = 0; j < 9; ++j) {
                shopGUIBuilder.addItem(this.createGlassPane(), GUI.AddItemFlag.createWithinY(height, height + 1));
            }
            return shopGUIBuilder;
        }
        final ShopVillagerGUIBuilder shopVillagerGUIBuilder = new ShopVillagerGUIBuilder(openEvent);
        for (final ShopItem shopItem : openEvent.getOpen().getItems()) {
            if (shopItem.getProducts().size() >= 1 && shopItem.getPrices().size() >= 1) {
                final ShopPrice shopPrice = shopItem.getPrices().get(0);
                if (shopItem.getProducts().size() == 1) {
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount()))));
                }
                else {
                    final ShopPrice shopPrice2 = shopItem.getPrices().get(1);
                    shopVillagerGUIBuilder.addOffer(new VillagerGUI.VillagerOffer(new DecGUIItem(shopItem.getProducts().get(0).getItemStack()), new DecGUIItem(i.a(shopPrice.getSpawner().getActualItemstack(), shopPrice.getAmount())), new DecGUIItem(i.a(shopPrice2.getSpawner().getActualItemstack(), shopPrice2.getAmount()))));
                }
            }
            if (shopItem.getProducts().size() >= 2) {
                d.d("The GommeHD shop design only displays 1 product per item!", "Shop");
            }
            if (shopItem.getPrices().size() >= 3) {
                d.d("The GommeHD shop design only displays 1 or 2 prices per item!", "Shop");
            }
        }
        return shopVillagerGUIBuilder;
    }
    
    private ItemStack createGlassPane() {
        return i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15), " ");
    }
}
