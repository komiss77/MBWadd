// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.bq;
import javax.annotation.Nullable;

public enum ShopDesignType
{
    Normal("Normal", 0, (ShopDesign)new NormalShopDesign(), 0, false), 
    HyPixel("HyPixel", 1, (ShopDesign)new HyPixelShopDesign(), 1, false), 
    HiveMC("HiveMC", 2, (ShopDesign)new HiveMCShopDesign(), 2, false), 
    GommeHD("GommeHD", 3, (ShopDesign)new GommeHDShopDesign(), 3, false), 
    Rewinside("Rewinside", 4, (ShopDesign)new RewinsideShopDesign(), 4, false), 
    Minesucht("Minesucht", 5, (ShopDesign)new MinesuchtShopDesign(), 5, false), 
    BergwerkLABS("BergwerkLABS", 6, (ShopDesign)new BergwerklabsShopDesign(), 6, false), 
    HyPixelV2("HyPixelV2", 7, (ShopDesign)new HyPixelV2ShopDesign(), 7, false), 
    Custom("Custom", 8);
    
    @Nullable
    private final ShopDesignData data;
    private final boolean isBeta;
    
    private ShopDesignType(final String name, final int ordinal) {
        this.data = null;
        this.isBeta = false;
    }
    
    private ShopDesignType(final String name, final int ordinal, final ShopDesign shopDesign, final int n, final boolean isBeta) {
        this.data = new ShopDesignData(shopDesign, this.name(), n, this);
        this.isBeta = isBeta;
        if (!this.data.register()) {
            new bq().printStackTrace();
        }
    }
    
    @Deprecated
    public static ShopDesignType byName(final String s) {
        if (s.isInteger(s)) {
            return byId(Integer.valueOf(s));
        }
        ShopDesignType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ShopDesignType shopDesignType = values[i];
            if (shopDesignType.name().equalsIgnoreCase(s)) {
                return shopDesignType;
            }
        }
        return null;
    }
    
    @Deprecated
    public static ShopDesignType byId(final int n) {
        ShopDesignType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ShopDesignType shopDesignType = values[i];
            if (shopDesignType.data.getId() == n) {
                return shopDesignType;
            }
        }
        return null;
    }
    
    @Nullable
    public ShopDesignData getData() {
        return this.data;
    }
    
    public boolean isBeta() {
        return this.isBeta;
    }
}
