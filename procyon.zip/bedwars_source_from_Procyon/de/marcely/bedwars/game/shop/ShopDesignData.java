// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.bo;
import java.util.ArrayList;
import java.util.List;

public class ShopDesignData
{
    private final ShopDesign design;
    private final String name;
    private final int id;
    private final ShopDesignType type;
    private static final List<ShopDesignData> designs;
    
    static {
        designs = new ArrayList<ShopDesignData>();
    }
    
    public ShopDesignData(final ShopDesign shopDesign, final String s) {
        this(shopDesign, s, -1, ShopDesignType.Custom);
    }
    
    @Deprecated
    public ShopDesignData(final ShopDesign design, final String name, final int id, final ShopDesignType type) {
        this.design = design;
        this.name = name;
        this.id = id;
        this.type = type;
    }
    
    public boolean register() {
        return !ShopDesignData.designs.contains(this) && ShopDesignData.designs.add(this);
    }
    
    public boolean unregister() {
        if (!this.isCustom()) {
            new bo("Only works for custom designs!").printStackTrace();
            return false;
        }
        return ShopDesignData.designs.remove(this);
    }
    
    public boolean isCustom() {
        return this.type == ShopDesignType.Custom;
    }
    
    public static ShopDesignData getDesignByName(final String s) {
        if (s.isInteger(s)) {
            final ShopDesignData designByID = getDesignByID(Integer.valueOf(s));
            if (designByID != null) {
                return designByID;
            }
        }
        for (final ShopDesignData shopDesignData : ShopDesignData.designs) {
            if (shopDesignData.name.equalsIgnoreCase(s)) {
                return shopDesignData;
            }
        }
        return null;
    }
    
    public static ShopDesignData getDesignByID(final int n) {
        for (final ShopDesignData shopDesignData : ShopDesignData.designs) {
            if (shopDesignData.id == n) {
                return shopDesignData;
            }
        }
        return null;
    }
    
    public ShopDesign getDesign() {
        return this.design;
    }
    
    public String getName() {
        return this.name;
    }
    
    public int getId() {
        return this.id;
    }
    
    public ShopDesignType getType() {
        return this.type;
    }
    
    public static List<ShopDesignData> getDesigns() {
        return ShopDesignData.designs;
    }
}
