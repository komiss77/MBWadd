// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import de.marcely.bedwars.api.gui.SimpleGUI;

public abstract class SimpleShopGUIBuilder
{
    ShopPage openPage;
    
    public abstract SimpleGUI export();
    
    public ShopPage getOpenPage() {
        return this.openPage;
    }
    
    public void setOpenPage(final ShopPage openPage) {
        this.openPage = openPage;
    }
}
