// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.ExtraItem;

public class ShopSpecialProduct extends ShopProduct implements Cloneable
{
    public static final String IDENTIFIER = "special";
    private ExtraItem extraItem;
    
    public ShopSpecialProduct(final ShopItem shopItem) {
        super(shopItem);
        this.extraItem = null;
    }
    
    @Override
    public ItemStack getItemStack() {
        return this.extraItem.getItemStack();
    }
    
    @Override
    public String getDisplayName() {
        return this.extraItem.getName();
    }
    
    @Override
    public String getIdentifier() {
        return "special";
    }
    
    @Override
    protected ItemStack postPrepareGive(final Player player, final ItemStack itemStack) {
        return itemStack;
    }
    
    @Override
    public ShopSpecialProduct clone() {
        return (ShopSpecialProduct)super.clone();
    }
    
    public ExtraItem getExtraItem() {
        return this.extraItem;
    }
    
    public void setExtraItem(final ExtraItem extraItem) {
        this.extraItem = extraItem;
    }
}
