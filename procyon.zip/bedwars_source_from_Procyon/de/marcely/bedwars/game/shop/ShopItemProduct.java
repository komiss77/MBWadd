// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.shop;

import java.util.Iterator;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Player;
import java.util.HashMap;
import org.bukkit.enchantments.Enchantment;
import java.util.Map;
import javax.annotation.Nullable;
import org.bukkit.inventory.ItemStack;

public class ShopItemProduct extends ShopProduct implements Cloneable
{
    public static final String IDENTIFIER = "item";
    @Nullable
    private ItemStack itemStack;
    private final Map<Enchantment, Integer> enchantments;
    
    public ShopItemProduct(final ShopItem shopItem) {
        super(shopItem);
        this.itemStack = null;
        this.enchantments = new HashMap<Enchantment, Integer>();
    }
    
    @Override
    public ItemStack getItemStack() {
        return (this.itemStack != null) ? this.itemStack.clone() : null;
    }
    
    @Override
    public String getDisplayName() {
        return this.itemStack.getType().name().toLowerCase().replace("_", " ");
    }
    
    @Override
    public String getIdentifier() {
        return "item";
    }
    
    @Override
    protected ItemStack postPrepareGive(final Player player, final ItemStack itemStack) {
        final ItemMeta itemMeta = itemStack.getItemMeta();
        for (final Map.Entry<Enchantment, Integer> entry : this.enchantments.entrySet()) {
            itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), true);
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
    
    @Override
    public ShopItemProduct clone() {
        return (ShopItemProduct)super.clone();
    }
    
    public void setItemStack(@Nullable final ItemStack itemStack) {
        this.itemStack = itemStack;
    }
    
    public Map<Enchantment, Integer> getEnchantments() {
        return this.enchantments;
    }
}
