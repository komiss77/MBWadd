// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import java.util.Arrays;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.holographic.b;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.cL;
import java.util.UUID;
import de.marcely.bedwars.cG;
import de.marcely.bedwars.cK;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.cH;
import de.marcely.bedwars.cN;
import de.marcely.bedwars.holographic.NPCType;
import de.marcely.bedwars.bq;
import org.bukkit.Location;
import de.marcely.bedwars.holographic.c;
import de.marcely.bedwars.game.location.XYZYPW;
import java.io.Serializable;

public class IEntity implements Serializable
{
    private static final long serialVersionUID = 1L;
    private IEntityType type;
    private XYZYPW loc;
    private Object[] param;
    private transient c<?> hologram;
    
    public IEntity(final IEntityType entityType, final Location location, final Object[] array) {
        this(entityType, XYZYPW.valueOf(location), array);
    }
    
    public IEntity(final IEntityType type, final XYZYPW loc, final Object[] param) {
        this.type = type;
        this.loc = loc;
        this.param = param;
    }
    
    public void x() {
        if (!this.isSpawnable()) {
            new bq().printStackTrace();
            return;
        }
        final NPCType a = this.type.a();
        final NPCType.a a2 = a.a();
        if (a2 == NPCType.a.b) {
            this.hologram = c.a((Class<?>)cN.class, this.loc.toBukkit(), new cH().a(this.type.a(this)));
        }
        else if (a2 == NPCType.a.d) {
            this.hologram = c.a((Class<?>)cK.class, this.loc.toBukkit(), new cG().a(this.type.a(this)).a((UUID)a.getArguments()[0]));
        }
        else if (a2 == NPCType.a.e) {
            this.hologram = c.a((Class<?>)cL.class, this.loc.toBukkit(), new cG().a(this.type.a(this)));
        }
        else if (a2 == NPCType.a.c) {
            this.hologram = c.a((Class<?>)cI.class, this.loc.toBukkit(), ((cE)a.getArguments()[0]).a(this.type.a(this)));
        }
        this.hologram.Q();
        if (this.type == IEntityType.TeamSelect && this.hologram.a() instanceof b) {
            ((b)this.hologram.a()).a().a(e.a.a, new ItemStack(Material.STAINED_CLAY, 1, (short)((Team)this.param[0]).getDyeColor().getWoolData()));
        }
    }
    
    public void remove() {
        this.hologram.remove();
    }
    
    public static IEntity a(final Location location) {
        return new IEntity(IEntityType.Dealer, XYZYPW.valueOf(location), new Object[0]);
    }
    
    public static IEntity a(final Location location, final int i, final int j) {
        return new IEntity(IEntityType.Hub, XYZYPW.valueOf(location), Arrays.asList(0, i, j).toArray());
    }
    
    public static IEntity a(final Location location, final Arena arena) {
        return new IEntity(IEntityType.Hub, XYZYPW.valueOf(location), Arrays.asList(1, arena.getName()).toArray());
    }
    
    public static IEntity a(final Location location, final Team team) {
        return new IEntity(IEntityType.TeamSelect, XYZYPW.valueOf(location), Arrays.asList(team).toArray());
    }
    
    public static IEntity b(final Location location) {
        return new IEntity(IEntityType.UpgradeDealer, XYZYPW.valueOf(location), new Object[0]);
    }
    
    public boolean isSpawnable() {
        return this.loc.getWorld() != null;
    }
    
    public IEntityType a() {
        return this.type;
    }
    
    public XYZYPW a() {
        return this.loc;
    }
    
    public Object[] a() {
        return this.param;
    }
    
    public c<?> a() {
        return this.hologram;
    }
    
    public enum IEntityType
    {
        Dealer("Dealer", 0), 
        Hub("Hub", 1), 
        TeamSelect("TeamSelect", 2), 
        UpgradeDealer("UpgradeDealer", 3);
        
        private static /* synthetic */ int[] $SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType;
        
        private IEntityType(final String name, final int ordinal) {
        }
        
        public NPCType a() {
            switch (i()[this.ordinal()]) {
                case 1: {
                    return ConfigValue.entitytype_dealer;
                }
                case 2: {
                    return ConfigValue.entitytype_hub;
                }
                case 3: {
                    return ConfigValue.entitytype_teamselect;
                }
                case 4: {
                    return ConfigValue.entitytype_upgradedealer;
                }
                default: {
                    return null;
                }
            }
        }
        
        public String a(final IEntity entity) {
            switch (i()[this.ordinal()]) {
                case 1: {
                    return de.marcely.bedwars.message.b.a(ConfigValue.dealer_title).c().f(null);
                }
                case 2: {
                    if ((int)entity.param[0] == 0) {
                        return String.valueOf(ConfigValue.lobbyvillager_prefix) + entity.param[1] + "x" + entity.param[2];
                    }
                    if ((int)entity.param[0] == 1) {
                        final Arena b = s.b((String)entity.param[1]);
                        return String.valueOf(ConfigValue.lobbyvillager_prefix) + ((b != null) ? b.getDisplayName() : entity.param[1]);
                    }
                    return ((Team)entity.param[0]).a((CommandSender)null, true);
                }
                case 3: {
                    return ((Team)entity.param[0]).a((CommandSender)null, true);
                }
                case 4: {
                    return de.marcely.bedwars.message.b.a(ConfigValue.upgradedealer_title).c().f(null);
                }
                default: {
                    return null;
                }
            }
        }
        
        static /* synthetic */ int[] i() {
            final int[] $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType = IEntityType.$SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType;
            if ($switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType != null) {
                return $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType;
            }
            final int[] $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2 = new int[values().length];
            try {
                $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2[IEntityType.Dealer.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2[IEntityType.Hub.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2[IEntityType.TeamSelect.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2[IEntityType.UpgradeDealer.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            return IEntityType.$SWITCH_TABLE$de$marcely$bedwars$game$IEntity$IEntityType = $switch_TABLE$de$marcely$bedwars$game$IEntity$IEntityType2;
        }
    }
}
