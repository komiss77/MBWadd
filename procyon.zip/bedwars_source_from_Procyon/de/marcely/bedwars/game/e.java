// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import org.bukkit.enchantments.Enchantment;

public enum e
{
    a("Protection", 0, "PROTECTION_ENVIRONMENTAL"), 
    b("Fire_Protection", 1, "PROTECTION_FIRE"), 
    c("Feather_Falling", 2, "PROTECTION_FALL"), 
    d("Blast_Protection", 3, "PROTECTION_EXPLOSIONS"), 
    e("Projectile_Protection", 4, "PROTECTION_PROJECTILE"), 
    f("Respiration", 5, "OXYGEN"), 
    g("Aqua_Affinity", 6, "WATER_WORKER"), 
    h("Thorns", 7, "THORNS"), 
    i("Depth_Strider", 8, "DEPTH_STRIDER"), 
    j("Frost_Walker", 9, "FROST_WALKER"), 
    k("Curse_of_Binding", 10, "BINDING_CURSE"), 
    l("Sharpness", 11, "DAMAGE_ALL"), 
    m("Smite", 12, "DAMAGE_UNDEAD"), 
    n("Bane_of_Arthropods", 13, "DAMAGE_ARTHROPODS"), 
    o("Knockback", 14, "KNOCKBACK"), 
    p("Fire_Aspect", 15, "FIRE_ASPECT"), 
    q("Looting", 16, "LOOT_BONUS_MOBS"), 
    r("Efficiency", 17, "DIG_SPEED"), 
    s("Silk_Touch", 18, "SILK_TOUCH"), 
    t("Unbreaking", 19, "DURABILITY"), 
    u("Fortune", 20, "LOOT_BONUS_BLOCKS"), 
    v("Power", 21, "ARROW_DAMAGE"), 
    w("Punch", 22, "ARROW_KNOCKBACK"), 
    x("Flame", 23, "ARROW_FIRE"), 
    y("Infinity", 24, "ARROW_INFINITE"), 
    z("Luck_of_the_Sea", 25, "LUCK"), 
    A("Lure", 26, "LURE"), 
    B("Mending", 27, "MENDING"), 
    C("Curse_of_Vanishing", 28, "VANISHING_CURSE");
    
    private String B;
    
    static {
        a = new e[] { e.a, e.b, e.c, e.d, e.e, e.f, e.g, e.h, e.i, e.j, e.k, e.l, e.m, e.n, e.o, e.p, e.q, e.r, e.s, e.t, e.u, e.v, e.w, e.x, e.y, e.z, e.A, e.B, e.C };
    }
    
    private e(final String name, final int ordinal, final String b) {
        this.B = b;
    }
    
    public static e a(final Enchantment enchantment) {
        e[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final e e = values[i];
            if (e.B.equals(enchantment.getName())) {
                return e;
            }
        }
        return null;
    }
    
    public Enchantment a() {
        return Enchantment.getByName(this.B);
    }
    
    public static e a(final String s) {
        e[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final e e = values[i];
            if (e.name().equalsIgnoreCase(s) || e.name().replace("_", "").equalsIgnoreCase(s) || e.name().replace("_", " ").equalsIgnoreCase(s) || e.B.equalsIgnoreCase(s) || e.B.replace("_", "").equalsIgnoreCase(s) || e.B.replace("_", " ").equalsIgnoreCase(s)) {
                return e;
            }
        }
        return null;
    }
}
