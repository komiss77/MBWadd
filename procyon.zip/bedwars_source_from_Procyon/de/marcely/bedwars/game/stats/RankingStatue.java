// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.config.l;
import java.util.UUID;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.util.b;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.Material;
import java.util.Iterator;
import de.marcely.bedwars.holographic.h;
import java.util.List;
import de.marcely.bedwars.cF;
import java.util.ArrayList;
import de.marcely.bedwars.config.k;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.cJ;
import org.bukkit.entity.ArmorStand;
import org.bukkit.Location;
import de.marcely.bedwars.api.RankingStatueAPI;

public class RankingStatue implements RankingStatueAPI
{
    private a a;
    private Location location;
    private c a;
    private float i;
    private final String K = "MHF_Question";
    private ArmorStand c;
    private de.marcely.bedwars.holographic.c<cJ> hologram;
    
    public RankingStatue(final Object o) {
        this(null);
    }
    
    public RankingStatue(final a a) {
        this(a, new Location(s.a(), 0.0, 0.0, 0.0));
    }
    
    public RankingStatue(final a a, final Location location) {
        this(a, location, null);
    }
    
    public RankingStatue(final a a, final Location location, final c c) {
        this.a = null;
        this.a = null;
        this.i = 0.0f;
        this.c = null;
        this.hologram = null;
        this.a(a);
        this.setLocation(location.clone());
        this.a(location.getYaw());
        this.a(c);
    }
    
    @Override
    public void setLocation(final Location location) {
        this.N();
        if (location != null) {
            location.setPitch(0.0f);
        }
        this.location = location;
        this.a();
    }
    
    public ArmorStand a() {
        if (this.getLocation() != null && this.a != null && Version.a().getVersionNumber() >= 8) {
            this.N();
            final Location location = this.getLocation();
            final String replacement = (this.a() != null) ? this.a().getPlayerName() : null;
            location.setYaw(this.a());
            (this.c = (ArmorStand)this.location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND)).setGravity(false);
            this.c.setChestplate(new ItemStack(this.a.a()));
            this.c.setLeggings(new ItemStack(this.a.b()));
            this.c.setBoots(new ItemStack(this.a.c()));
            this.c.setHelmet((replacement == null) ? this.a("MHF_Question") : this.a(replacement));
            final ArrayList<String> list = new ArrayList<String>(k.m.size());
            if (replacement != null) {
                final Iterator<String> iterator = k.m.iterator();
                while (iterator.hasNext()) {
                    list.add(iterator.next().replace("{player}", replacement).replace("{rank}", new StringBuilder().append(this.a.getRank()).toString()).replace("{wl}", new StringBuilder().append(this.a.a()).toString()).replace("{kd}", new StringBuilder().append(this.a.b()).toString()).replace("{wins}", new StringBuilder().append(this.a.getWins()).toString()).replace("{loses}", new StringBuilder().append(this.a.getLoses()).toString()).replace("{kills}", new StringBuilder().append(this.a.getKills()).toString()).replace("{deaths}", new StringBuilder().append(this.a.getDeaths()).toString()).replace("{bedsdestroyed}", new StringBuilder().append(this.a.getBedsDestroyed()).toString()).replace("{roundsplayed}", new StringBuilder().append(this.a.getRoundsPlayed()).toString()).replace("{playtime}", new StringBuilder().append(s.a(this.a.getPlayTime())).toString()));
                }
            }
            else {
                final Iterator<String> iterator2 = k.m.iterator();
                while (iterator2.hasNext()) {
                    list.add(iterator2.next().replace("{player}", "/").replace("{rank}", new StringBuilder().append(this.a.getRank()).toString()).replace("{wl}", "/").replace("{kd}", "/").replace("{wins}", "/").replace("{loses}", "/").replace("{kills}", "/").replace("{deaths}", "/").replace("{bedsdestroyed}", "/").replace("{roundsplayed}", "/").replace("{playtime}", "/"));
                }
            }
            (this.hologram = de.marcely.bedwars.holographic.c.a(cJ.class, location.clone().add(location.getDirection()), new cF().a(list))).Q();
            return this.c;
        }
        return null;
    }
    
    public ItemStack a(final String owner) {
        final ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta itemMeta = (SkullMeta)itemStack.getItemMeta();
        itemMeta.setOwner(owner);
        itemStack.setItemMeta((ItemMeta)itemMeta);
        return itemStack;
    }
    
    public ArmorStand b() {
        return this.c;
    }
    
    @Deprecated
    public void M() {
        if (this.location != null) {
            for (final Entity entity : b.getNearbyEntities(this.location.clone().add(this.location.getDirection()), 1.0, 5.0, 1.0)) {
                if (entity.getType() == EntityType.ARMOR_STAND) {
                    final ArmorStand armorStand = (ArmorStand)entity;
                    if (armorStand.isVisible() || armorStand.hasGravity()) {
                        continue;
                    }
                    armorStand.remove();
                }
            }
            for (final Entity entity2 : b.getNearbyEntities(this.location, 0.2, 0.2, 0.2)) {
                if (entity2.getType() == EntityType.ARMOR_STAND && !((ArmorStand)entity2).hasGravity()) {
                    entity2.remove();
                    break;
                }
            }
        }
    }
    
    private void N() {
        if (this.c != null && !this.c.isDead()) {
            this.c.remove();
        }
        else if (this.location != null) {
            for (final Entity entity : b.getNearbyEntities(this.location, 0.1, 0.1, 0.1)) {
                if (entity.getType() == EntityType.ARMOR_STAND) {
                    final ArmorStand armorStand = (ArmorStand)entity;
                    if (armorStand.hasGravity()) {
                        continue;
                    }
                    armorStand.remove();
                }
            }
        }
        if (this.hologram != null) {
            this.hologram.remove();
            this.hologram = null;
        }
    }
    
    @Override
    public int getPlace() {
        return this.a().getRank();
    }
    
    @Override
    public UUID getCurrentHolderUUID() {
        return (this.a() != null) ? this.a().getUUID() : null;
    }
    
    @Override
    public String getCurrentHolderName() {
        return (this.a() != null) ? this.a().getPlayerName() : null;
    }
    
    @Override
    public boolean exists() {
        return s.ad.contains(this);
    }
    
    @Override
    public boolean remove() {
        return this.remove(true);
    }
    
    @Override
    public boolean remove(final boolean b) {
        if (!this.exists()) {
            return false;
        }
        s.ad.remove(this);
        if (b) {
            l.save();
        }
        this.N();
        return true;
    }
    
    public a a() {
        return this.a;
    }
    
    public void a(final a a) {
        this.a = a;
    }
    
    @Override
    public Location getLocation() {
        return this.location;
    }
    
    public c a() {
        return this.a;
    }
    
    public void a(final c a) {
        this.a = a;
    }
    
    public float a() {
        return this.i;
    }
    
    public void a(final float i) {
        this.i = i;
    }
    
    public enum a
    {
        b("T1", 0, 1, Material.GOLD_CHESTPLATE, Material.GOLD_LEGGINGS, Material.GOLD_BOOTS), 
        c("T2", 1, 2, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS), 
        d("T3", 2, 3, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS);
        
        private int af;
        private Material b;
        private Material c;
        private Material d;
        
        static {
            a = new a[] { RankingStatue.a.b, RankingStatue.a.c, RankingStatue.a.d };
        }
        
        private a(final String name, final int ordinal, final int af, final Material b, final Material c, final Material d) {
            this.af = af;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public int getRank() {
            return this.af;
        }
        
        public Material a() {
            return this.b;
        }
        
        public Material b() {
            return this.c;
        }
        
        public Material c() {
            return this.d;
        }
        
        public static a a(final int n) {
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                if (a.getRank() == n) {
                    return a;
                }
            }
            return null;
        }
    }
}
