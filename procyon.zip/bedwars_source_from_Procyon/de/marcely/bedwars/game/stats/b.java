// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.util.s;
import java.util.Iterator;
import java.util.Map;
import java.util.Comparator;
import de.marcely.bedwars.d;
import de.marcely.bedwars.config.ConfigValue;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;
import de.marcely.bedwars.util.FutureResult;
import java.util.concurrent.Future;

public class b
{
    public static c[] a;
    
    static {
        b.a = new c[10];
    }
    
    public b(final String s) {
    }
    
    public static Future<Void> a() {
        final Future<c[]> b = c.b();
        final FutureResult<Void> futureResult = new FutureResult<Void>();
        s.a((Future<Object>)b, new Runnable() {
            @Override
            public void run() {
                c[] array = null;
                try {
                    array = b.get();
                    if (array == null) {
                        return;
                    }
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
                Arrays.fill(b.a, null);
                final ArrayList<AbstractMap.SimpleEntry<Double, c>> list = new ArrayList<AbstractMap.SimpleEntry<Double, c>>();
                c[] array2;
                for (int length = (array2 = array).length, i = 0; i < length; ++i) {
                    final c value = array2[i];
                    if (value != null) {
                        double d = -1.0;
                        switch (ConfigValue.ranking_sortation) {
                            case 0: {
                                d = value.getWins();
                                break;
                            }
                            case 1: {
                                d = value.getLoses();
                                break;
                            }
                            case 2: {
                                d = value.getRoundsPlayed();
                                break;
                            }
                            case 3: {
                                d = value.a();
                                break;
                            }
                            case 4: {
                                d = value.getKills();
                                break;
                            }
                            case 5: {
                                d = value.getDeaths();
                                break;
                            }
                            case 6: {
                                d = value.b();
                                break;
                            }
                            case 7: {
                                d = value.getBedsDestroyed();
                                break;
                            }
                            case 8: {
                                d = value.getRoundsPlayed();
                                break;
                            }
                            default: {
                                de.marcely.bedwars.d.a("Unkown 'ranking-sortation' value '" + ConfigValue.ranking_sortation + "'");
                                futureResult.die();
                                break;
                            }
                        }
                        list.add(new AbstractMap.SimpleEntry<Double, c>(d, value));
                    }
                }
                list.sort(new Comparator<Map.Entry<Double, c>>() {
                    public int a(final Map.Entry<Double, c> entry, final Map.Entry<Double, c> entry2) {
                        return entry2.getKey().compareTo(entry.getKey());
                    }
                });
                int rank = 1;
                final Iterator<Object> iterator = list.iterator();
                while (iterator.hasNext()) {
                    final c c = iterator.next().getValue();
                    if (c.getRank() != rank) {
                        c.setRank(rank);
                        c.save();
                    }
                    b.a[rank - 1] = c;
                    if (rank++ == b.a.length - 1) {
                        break;
                    }
                }
                futureResult.a(null);
            }
        });
        return futureResult;
    }
}
