// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import java.util.UUID;

public class a
{
    public final a[] a;
    
    public a() {
        this.a = new a[10];
    }
    
    public void a(final int n, final a a) {
        this.a[n - 1] = a;
    }
    
    public a a(final int n) {
        return this.a[n - 1];
    }
    
    public static class a
    {
        public final UUID uuid;
        public final String name;
        
        public a(final UUID uuid, final String name) {
            this.uuid = uuid;
            this.name = name;
        }
    }
}
