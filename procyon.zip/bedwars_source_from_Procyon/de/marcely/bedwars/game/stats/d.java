// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import java.util.Iterator;
import java.util.Collection;
import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.cF;
import org.bukkit.Location;
import java.util.ArrayList;
import de.marcely.bedwars.cM;
import de.marcely.bedwars.holographic.c;
import java.util.List;

public class d
{
    private static List<c<cM>> W;
    
    static {
        d.W = new ArrayList<c<cM>>();
    }
    
    public static void e(final Location location) {
        final c<cM> a = c.a(cM.class, location, new cF());
        a.Q();
        d.W.add(a);
    }
    
    public static void a(final c<cM> c) {
        c.remove();
        d.W.remove(c);
    }
    
    public static void f(final Location location) {
        a(a(location));
    }
    
    public static void P() {
        final Iterator<c<cM>> iterator = new ArrayList<c<cM>>(d.W).iterator();
        while (iterator.hasNext()) {
            a(iterator.next());
        }
    }
    
    private static c<cM> a(final Location location) {
        for (final c<cM> c : d.W) {
            final Location location2 = c.getLocation();
            if (location2.getWorld().equals(location.getWorld()) && location2.getX() == location.getX() && location2.getY() == location.getY() && location2.getZ() == location.getZ()) {
                return c;
            }
        }
        return null;
    }
    
    public static List<c<cM>> u() {
        return d.W;
    }
}
