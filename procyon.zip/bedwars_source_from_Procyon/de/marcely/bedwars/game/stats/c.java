// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import javax.annotation.Nullable;
import java.util.Iterator;
import org.bukkit.Bukkit;
import java.util.concurrent.ExecutionException;
import de.marcely.bedwars.util.FutureResult;
import org.bukkit.entity.Player;
import java.util.concurrent.Future;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import de.marcely.bedwars.bo;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.util.t;
import de.marcely.bedwars.util.SoftHashMap;
import java.util.Map;
import java.util.UUID;
import de.marcely.bedwars.api.StatsAPI;

public class c implements StatsAPI
{
    private String name;
    private UUID uuid;
    private final boolean R;
    private c b;
    private int ag;
    private int ah;
    private int ai;
    private int aj;
    private int ak;
    private int al;
    private int am;
    private long k;
    private int an;
    private int ao;
    private static Map<UUID, c> F;
    public static final String L = "MBedwars_stats";
    
    static {
        c.F = new SoftHashMap<UUID, c>();
    }
    
    public c(final String name, final UUID uuid, final boolean r) {
        this.ag = -1;
        this.ah = 0;
        this.ai = 0;
        this.aj = 0;
        this.ak = 0;
        this.al = 0;
        this.am = 0;
        this.k = 0L;
        this.an = 0;
        this.ao = 0;
        t.c(uuid);
        this.name = name;
        this.uuid = uuid;
        if (!(this.R = r)) {
            this.O();
        }
    }
    
    @Override
    public void setRank(final int ag) {
        this.ag = ag;
        if (ag <= 3 && ag >= 1) {
            s.a(this.uuid, Achievement.v);
        }
    }
    
    @Override
    public void setWins(final int ah) {
        this.ah = ah;
    }
    
    @Override
    public void setLoses(final int ai) {
        this.ai = ai;
    }
    
    @Override
    public void setKills(final int aj) {
        if (this.b != null) {
            this.b.setKills(aj - this.aj + this.b.aj);
        }
        this.aj = aj;
        if (this.b() >= 5.0) {
            new Synchronizer() {
                @Override
                public void run() {
                    s.a(de.marcely.bedwars.game.stats.c.this.uuid, Achievement.w);
                }
            };
        }
    }
    
    @Override
    public void setDeaths(final int ak) {
        if (this.b != null) {
            this.b.setDeaths(ak - this.ak + this.b.ak);
        }
        this.ak = ak;
    }
    
    @Override
    public void setBedsDestroyed(final int al) {
        if (this.b != null) {
            this.b.setBedsDestroyed(al - this.al + this.b.al);
        }
        this.al = al;
    }
    
    @Override
    public void setRoundsPlayed(final int am) {
        this.am = am;
    }
    
    @Override
    public void setPlayTime(final long k) {
        this.k = k;
        if (s.a(k) >= 5L) {
            s.a(this.uuid, Achievement.x);
        }
    }
    
    @Override
    public String getPlayerName() {
        return this.name;
    }
    
    @Override
    public void setCoins(final int an) {
        this.an = an;
    }
    
    @Override
    public void setFinalKills(final int ao) {
        if (this.b != null) {
            this.b.setFinalKills(ao - this.ao + this.b.ao);
        }
        this.ao = ao;
    }
    
    @Override
    public UUID getUUID() {
        return this.uuid;
    }
    
    @Override
    public int getRank() {
        return this.ag;
    }
    
    @Override
    public int getWins() {
        return this.ah;
    }
    
    @Override
    public int getLoses() {
        return this.ai;
    }
    
    @Override
    public int getKills() {
        return this.aj;
    }
    
    @Override
    public int getDeaths() {
        return this.ak;
    }
    
    @Override
    public int getBedsDestroyed() {
        return this.al;
    }
    
    @Override
    public int getRoundsPlayed() {
        return this.am;
    }
    
    @Override
    public long getPlayTime() {
        return this.k;
    }
    
    @Override
    public int getCoins() {
        return this.an;
    }
    
    public int q() {
        return this.ao;
    }
    
    public void x(final String name) {
        this.name = name;
    }
    
    public void b(final UUID uuid) {
        this.uuid = uuid;
    }
    
    public void O() {
        if (this.R) {
            new bo().printStackTrace();
        }
        this.b = new c(this.name, this.uuid, true);
    }
    
    public Double a() {
        if (this.getLoses() == 0 && this.getWins() > 0) {
            return (double)this.getWins();
        }
        final DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.ENGLISH);
        symbols.setInfinity("Infinity");
        symbols.setNaN("?");
        String format = new DecimalFormat("#.##", symbols).format(this.getWins() / (double)this.getLoses());
        if (format.equals("Infinity") || format.equals("?")) {
            format = "0.0";
        }
        return Double.valueOf(format);
    }
    
    public Double b() {
        if (this.getDeaths() == 0 && this.getKills() > 0) {
            return (double)this.getKills();
        }
        final DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.ENGLISH);
        symbols.setInfinity("Infinity");
        symbols.setNaN("?");
        String format = new DecimalFormat("#.##", symbols).format(this.getKills() / (double)this.getDeaths());
        if (format.equals("Infinity") || format.equals("?")) {
            format = "0.0";
        }
        return Double.valueOf(format);
    }
    
    @Override
    public void save() {
        s.b.b(this);
    }
    
    @Deprecated
    public static Future<c> a(final UUID uuid) {
        return a(null, uuid);
    }
    
    public static Future<c> a(final Player player) {
        return a(s.f(player), player.getUniqueId());
    }
    
    public static synchronized Future<c> a(final String s, final UUID uuid) {
        final FutureResult<c> futureResult = new FutureResult<c>();
        c a;
        if (uuid != null) {
            a = c.F.get(uuid);
        }
        else {
            a = a(s);
        }
        if (a != null) {
            futureResult.a(a);
        }
        else {
            final Future<c> a2 = s.b.a(uuid, s);
            s.a((Future<Object>)a2, new Runnable() {
                @Override
                public void run() {
                    try {
                        c c = a2.get();
                        if (c == null) {
                            if (uuid == null) {
                                futureResult.a(null);
                                return;
                            }
                            c = new c(s, uuid, false);
                        }
                        c.O();
                        de.marcely.bedwars.game.stats.c.F.put(uuid, c);
                        futureResult.a(c);
                    }
                    catch (InterruptedException | ExecutionException ex) {
                        final Object o2;
                        final Object o = o2;
                        futureResult.die();
                        ((Throwable)o).printStackTrace();
                    }
                }
            });
        }
        return futureResult;
    }
    
    @Deprecated
    public static Future<c> b(final UUID uuid) {
        return b(Bukkit.getOfflinePlayer(uuid).getName(), uuid);
    }
    
    public static Future<c> b(final String s, final UUID uuid) {
        return s.b.a(uuid, s);
    }
    
    public static Future<Boolean> c(final UUID uuid) {
        return s.b.d(uuid);
    }
    
    public String r() {
        return "plugins/MBedwars/data/playerstats/" + this.getUUID().toString() + ".yml";
    }
    
    public static String a(final UUID uuid) {
        return "plugins/MBedwars/data/playerstats/" + uuid.toString() + ".yml";
    }
    
    public static Future<c[]> b() {
        final Future<UUID[]> c = s.b.c();
        final FutureResult<c[]> futureResult = new FutureResult<c[]>();
        s.a((Future<Object>)c, new Runnable() {
            @Override
            public void run() {
                try {
                    final UUID[] array = c.get();
                    final c[] array2 = new c[array.length];
                    final a a = new a(null);
                    c.a.a(a, array2.length);
                    for (int i = 0; i < array.length; ++i) {
                        final Future<c> a2 = s.b.a(array[i], null);
                        s.a((Future<Object>)a2, new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    array2[i] = a2.get();
                                    final a a = a;
                                    c.a.a(a, a.aq - 1);
                                    if (a.aq == 0) {
                                        futureResult.a(array2);
                                    }
                                }
                                catch (InterruptedException | ExecutionException ex) {
                                    final Throwable t;
                                    t.printStackTrace();
                                }
                            }
                        });
                    }
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        });
        return futureResult;
    }
    
    @Deprecated
    public static void onEnable() {
    }
    
    public static void a(final UUID uuid) {
        c.F.remove(uuid);
    }
    
    public static void e() {
        c.F.clear();
    }
    
    @Nullable
    public static c a(final String anotherString) {
        for (final c c : c.F.values()) {
            if (c.name != null && c.name.equalsIgnoreCase(anotherString)) {
                return c;
            }
        }
        return null;
    }
    
    public c b() {
        return this.b;
    }
    
    private static class a
    {
        private int aq;
        
        static /* synthetic */ void a(final a a, final int aq) {
            a.aq = aq;
        }
    }
}
