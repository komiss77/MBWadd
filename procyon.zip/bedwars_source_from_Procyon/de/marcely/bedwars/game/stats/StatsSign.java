// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.stats;

import de.marcely.bedwars.config.q;
import java.util.UUID;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.block.Sign;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.a;
import org.bukkit.Location;
import de.marcely.bedwars.api.StatsSignAPI;

public class StatsSign implements StatsSignAPI
{
    private final int place;
    private final Location location;
    private c a;
    
    public StatsSign(final int place, final Location location) {
        this.place = place;
        this.location = location;
    }
    
    public void update() {
        if (!de.marcely.bedwars.util.a.b(this.location.getBlock())) {
            new BukkitRunnable() {
                public void run() {
                    StatsSign.this.remove(true);
                }
            }.runTask((Plugin)MBedwars.a);
            return;
        }
        final Sign sign = (Sign)this.location.getBlock().getState();
        if (this.a != null) {
            for (int i = 1; i <= 4; ++i) {
                sign.setLine(i - 1, this.a(i).replace("{player}", this.a.getPlayerName()).replace("{rank}", new StringBuilder().append(this.place).toString()).replace("{wl}", new StringBuilder().append(this.a.a()).toString()).replace("{kd}", new StringBuilder().append(this.a.b()).toString()).replace("{wins}", new StringBuilder().append(this.a.getWins()).toString()).replace("{loses}", new StringBuilder().append(this.a.getLoses()).toString()).replace("{kills}", new StringBuilder().append(this.a.getKills()).toString()).replace("{deaths}", new StringBuilder().append(this.a.getDeaths()).toString()).replace("{bedsdestroyed}", new StringBuilder().append(this.a.getBedsDestroyed()).toString()).replace("{roundsplayed}", new StringBuilder().append(this.a.getRoundsPlayed()).toString()).replace("{playtime}", new StringBuilder().append(s.a(this.a.getPlayTime())).toString()));
            }
        }
        else {
            for (int j = 1; j <= 4; ++j) {
                sign.setLine(j - 1, this.a(j).replace("{player}", "/").replace("{rank}", new StringBuilder().append(this.place).toString()).replace("{wl}", "/").replace("{kd}", "/").replace("{wins}", "/").replace("{loses}", "/").replace("{kills}", "/").replace("{deaths}", "/").replace("{bedsdestroyed}", "/").replace("{roundsplayed}", "/").replace("{playtime}", "/"));
            }
        }
        sign.update();
    }
    
    private String a(final int n) {
        switch (n) {
            case 1: {
                return ConfigValue.statssign_line1;
            }
            case 2: {
                return ConfigValue.statssign_line2;
            }
            case 3: {
                return ConfigValue.statssign_line3;
            }
            case 4: {
                return ConfigValue.statssign_line4;
            }
            default: {
                return null;
            }
        }
    }
    
    @Override
    public UUID getCurrentHolderUUID() {
        return (this.a() != null) ? this.a().getUUID() : null;
    }
    
    @Override
    public String getCurrentHolderName() {
        return (this.a() != null) ? this.a().getPlayerName() : null;
    }
    
    @Override
    public boolean exists() {
        return s.T.containsValue(this);
    }
    
    @Override
    public boolean remove() {
        return this.remove(true);
    }
    
    @Override
    public boolean remove(final boolean b) {
        if (!this.exists()) {
            return false;
        }
        s.T.remove(this.toString());
        if (b) {
            q.save();
        }
        return true;
    }
    
    @Override
    public int getPlace() {
        return this.place;
    }
    
    @Override
    public Location getLocation() {
        return this.location;
    }
    
    public c a() {
        return this.a;
    }
    
    public void a(final c a) {
        this.a = a;
    }
}
