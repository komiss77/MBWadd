// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.bq;

public abstract class Flag implements Cloneable
{
    private final String name;
    private final VarType type;
    private Object value;
    
    public Flag(final String s, final VarType varType) {
        this(s, varType, null);
    }
    
    public Flag(final String name, final VarType type, final Object value) {
        this.name = name;
        this.type = type;
        this.setValue(value);
    }
    
    public void setValue(final Object o) {
        if (!this.type.isInstance(o)) {
            new bq("Value isn't instance of VarType").printStackTrace();
            return;
        }
        this.value = ((this.type != VarType.a) ? o : o.toString());
    }
    
    public String getName() {
        return this.name;
    }
    
    public VarType getType() {
        return this.type;
    }
    
    public Object getValue() {
        return this.value;
    }
    
    public enum VarType
    {
        a("String", 0), 
        b("Integer", 1), 
        c("Double", 2), 
        d("Boolean", 3);
        
        private static /* synthetic */ int[] m;
        
        static {
            a = new VarType[] { VarType.a, VarType.b, VarType.c, VarType.d };
        }
        
        private VarType(final String name, final int ordinal) {
        }
        
        public boolean isInstance(final Object o) {
            switch (n()[this.ordinal()]) {
                case 2: {
                    return o instanceof Integer;
                }
                case 3: {
                    return o instanceof Double;
                }
                case 4: {
                    return o instanceof Boolean;
                }
                case 1: {
                    return true;
                }
                default: {
                    return false;
                }
            }
        }
        
        static /* synthetic */ int[] n() {
            final int[] m = VarType.m;
            if (m != null) {
                return m;
            }
            final int[] i = new int[values().length];
            try {
                i[VarType.d.ordinal()] = 4;
            }
            catch (NoSuchFieldError noSuchFieldError) {}
            try {
                i[VarType.c.ordinal()] = 3;
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                i[VarType.b.ordinal()] = 2;
            }
            catch (NoSuchFieldError noSuchFieldError3) {}
            try {
                i[VarType.a.ordinal()] = 1;
            }
            catch (NoSuchFieldError noSuchFieldError4) {}
            return VarType.m = i;
        }
    }
}
