// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import org.bukkit.Location;
import java.util.Iterator;
import de.marcely.bedwars.util.l;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.command.t;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import de.marcely.bedwars.api.event.ArenaOutOfTimeEvent;
import de.marcely.bedwars.bq;
import java.util.Collection;
import de.marcely.bedwars.game.Team;
import java.util.ArrayList;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.Sound;
import org.bukkit.inventory.ItemStack;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.holographic.f;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.holographic.c;
import org.bukkit.entity.Player;
import de.marcely.bedwars.config.ConfigValue;
import java.util.List;
import de.marcely.bedwars.util.s;
import java.util.HashMap;
import de.marcely.bedwars.game.DropType;
import java.util.Map;

public class b
{
    private final Arena arena;
    private int O;
    private boolean L;
    private int P;
    private int Q;
    private Map<DropType, Integer> x;
    
    public b(final Arena arena) {
        this.O = 0;
        this.L = false;
        this.P = 0;
        this.Q = 0;
        this.x = new HashMap<DropType, Integer>();
        this.arena = arena;
    }
    
    public void D() {
        s.a.start();
        ++this.O;
        if (this.arena.b() == ArenaStatus.f) {
            if (!this.x.isEmpty()) {
                for (final Map.Entry<DropType, Integer> entry : this.x.entrySet()) {
                    final DropType dropType = entry.getKey();
                    final int intValue = entry.getValue();
                    if (intValue + 1 >= dropType.getSpawnDelay() * 20.0) {
                        this.arena.b(dropType);
                        this.x.put(dropType, 0);
                    }
                    else {
                        for (final Arena.b b : this.arena.t.get(dropType)) {
                            if (intValue == (int)(dropType.getSpawnDelay() * 20.0 / b.value)) {
                                this.arena.a(dropType, b.c);
                            }
                        }
                        this.x.put(dropType, intValue + 1);
                    }
                }
            }
            else {
                final Iterator<DropType> iterator3 = DropType.values().iterator();
                while (iterator3.hasNext()) {
                    this.x.put(iterator3.next(), 0);
                }
            }
            if (this.O % ConfigValue.performance.t == 0 && ConfigValue.border && this.arena.a() == RegenerationType.c) {
                final Iterator<Player> iterator4 = this.arena.getPlayers().iterator();
                while (iterator4.hasNext()) {
                    de.marcely.bedwars.game.b.a(iterator4.next(), this.arena.getPosMin(), this.arena.getPosMax());
                }
                final Iterator<Player> iterator5 = this.arena.getSpectators().iterator();
                while (iterator5.hasNext()) {
                    de.marcely.bedwars.game.b.a(iterator5.next(), this.arena.getPosMin(), this.arena.getPosMax());
                }
            }
            if (this.O % ConfigValue.performance.p == 0) {
                for (final Map.Entry<c<cJ>, DropType> entry2 : this.arena.k.entrySet()) {
                    final c<cJ> c = entry2.getKey();
                    final c<? extends de.marcely.bedwars.holographic.b> c2 = c.a().x().get(0);
                    final DropType dropType2 = entry2.getValue();
                    if (c.v().size() >= 1) {
                        final Location location = c.getLocation();
                        final double spawnDelay = dropType2.getSpawnDelay();
                        final double n = (spawnDelay * 20.0 - this.x.get(dropType2)) / 20.0;
                        location.setYaw(((location.getYaw() > 360.0f) ? (location.getYaw() - 360.0f) : location.getYaw()) + ConfigValue.spawnerhologram_speed / 4.0f * ConfigValue.performance.p);
                        location.setY(((spawnDelay - 0.4 <= n) ? (spawnDelay - n - 0.4) : 0.0) + c.a().a().getY());
                        ((f)c2.a()).teleport(location);
                        if (this.O % 20 != 0) {
                            continue;
                        }
                        c.a().a(de.marcely.bedwars.message.b.a(Language.ItemSpawner_Hologram_Title).a("spawnercolor", new StringBuilder().append(dropType2.getChatColor()).toString()).a("spawner", dropType2.getName(true)).a("time", new StringBuilder().append((int)n).toString()).f(null).split("\\\\n"));
                    }
                }
            }
        }
        if (this.O % (20 / ConfigValue.performance.s) == 0 && this.arena.b().F() && this.arena.a != null && !this.arena.a.isStopped()) {
            this.arena.a.H();
        }
        if (this.O == 20) {
            this.O = 0;
            if (this.arena.b() == ArenaStatus.e) {
                if (this.arena.j() >= this.arena.k()) {
                    if (this.arena.a == null) {
                        return;
                    }
                    final int value = this.arena.a.getValue();
                    for (final Player player : this.arena.getPlayers()) {
                        if (value <= 10) {
                            final Iterator<Player> iterator8 = this.arena.getPlayers().iterator();
                            while (iterator8.hasNext()) {
                                iterator8.next().getInventory().setItem(4, (ItemStack)null);
                            }
                        }
                        if ((value <= 30 && value % 30 == 0) || value == 20 || value == 10 || (value <= 5 && value >= 1)) {
                            s.a((CommandSender)player, (this.arena.a() != RegenerationType.e || !this.arena.D) ? de.marcely.bedwars.message.b.a(Language.Countdown_Counting).a("number", new StringBuilder().append(value).toString()) : de.marcely.bedwars.message.b.a(Language.Countdown_Voting_Counting).a("number", new StringBuilder().append(value).toString()));
                            Sound.COUNTDOWN_COUNTING.play(player);
                            if (Version.a().ag() && (this.arena.a() != RegenerationType.e || !this.arena.D)) {
                                switch (value) {
                                    case 5: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_5, player, 100);
                                        break;
                                    }
                                    case 4: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_4, player, 100, 0);
                                        break;
                                    }
                                    case 3: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_3, player, 100, 0);
                                        break;
                                    }
                                    case 2: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_2, player, 100, 0);
                                        break;
                                    }
                                    case 1: {
                                        Version.a().b(ConfigValue.lobby_countdowntitle_1, player, 100, 0);
                                        break;
                                    }
                                }
                            }
                        }
                        if (value == 0 && Version.a().ag() && (this.arena.a() != RegenerationType.e || !this.arena.D)) {
                            Sound.COUNTDOWN_DONECOUNTING.play(player);
                            Version.a().a(ConfigValue.lobby_countdowntitle_0, de.marcely.bedwars.message.b.a(Language.Lobby_CountdownTitle_GoodLuck).f((CommandSender)player), player, 100, 0, 40);
                        }
                    }
                    if (value == 9 && ConfigValue.lobby_printmapinfo_enabled) {
                        Arena arena;
                        if (this.arena.a() == RegenerationType.e) {
                            if (this.arena.I.size() != 1) {
                                return;
                            }
                            arena = this.arena.I.get(0).arena;
                        }
                        else {
                            arena = this.arena;
                        }
                        final ArrayList<String> list = new ArrayList<String>();
                        final Iterator<String> iterator9 = ConfigValue.lobby_printmapinfo_lines.iterator();
                        while (iterator9.hasNext()) {
                            list.add(de.marcely.bedwars.message.b.a(iterator9.next()).c().b().a("arena", arena.getDisplayName()).a("madeby", arena.n()).a("teams", new StringBuilder().append(arena.a().r().size()).toString()).a("players", new StringBuilder().append(arena.getPlayers().size()).toString()).a("maxplayers", new StringBuilder().append(arena.getMaxPlayers()).toString()).a("teamsize", new StringBuilder().append(arena.getTeamPlayers()).toString()).a("^#", " ").f(null));
                        }
                        for (final Player player2 : this.arena.getPlayers()) {
                            if (this.arena.a() != RegenerationType.e || !this.arena.D) {
                                final Iterator<Object> iterator11 = list.iterator();
                                while (iterator11.hasNext()) {
                                    player2.sendMessage((String)iterator11.next());
                                }
                                if (!Version.a().ag()) {
                                    continue;
                                }
                                Version.a().c(ConfigValue.lobby_countdowntitle_arena.replace("{arena}", arena.getDisplayName()).replace("{players}", new StringBuilder().append(this.arena.getPlayers().size()).toString()).replace("{maxplayers}", new StringBuilder().append(arena.getMaxPlayers()).toString()).replace("{author}", this.arena.getAuthor()), player2);
                            }
                        }
                    }
                    if (value == ConfigValue.forcestart_time) {
                        final Iterator<Player> iterator12 = this.arena.getPlayers().iterator();
                        while (iterator12.hasNext()) {
                            this.arena.p(iterator12.next());
                        }
                    }
                    if (value >= 15 && this.arena.j() / this.arena.getMaxPlayers() * 100 >= 70) {
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Lobby_Enough));
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", "15"));
                        this.arena.a.setValue(15);
                    }
                    if (this.arena.a != null && this.arena.a() == RegenerationType.e && !this.arena.D && this.arena.I.size() == 0 && this.arena.getPlayers().size() < this.arena.k()) {
                        this.arena.a.setValue(0);
                    }
                    if (value <= 0) {
                        if (this.arena.a() == RegenerationType.e) {
                            if (this.arena.D) {
                                if (this.arena.I.size() >= 1) {
                                    final int n2 = this.arena.m() / 2;
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n2);
                                    this.arena.D = false;
                                    final ArrayList<Arena.a> list2 = new ArrayList<Arena.a>();
                                    for (final Arena.a a : this.arena.I) {
                                        if (list2.size() == 0 || list2.get(0).P.size() <= a.P.size()) {
                                            if (list2.size() > 0 && list2.get(0).P.size() < a.P.size()) {
                                                list2.clear();
                                            }
                                            list2.add(a);
                                        }
                                    }
                                    if (list2.size() >= 2) {
                                        final Arena.a a2 = list2.get(s.RAND.nextInt(list2.size()));
                                        list2.clear();
                                        list2.add(a2);
                                    }
                                    this.arena.I.clear();
                                    this.arena.I.add((Arena.a)list2.get(0));
                                    final Arena arena2 = list2.get(0).arena;
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_End).a("arena", arena2.getDisplayName()));
                                    if (this.arena.getPlayers().size() >= arena2.k()) {
                                        final Iterator<Player> iterator14 = this.arena.getPlayers().iterator();
                                        while (iterator14.hasNext()) {
                                            iterator14.next().closeInventory();
                                        }
                                        final Iterator<Arena> iterator15 = s.af.iterator();
                                        while (iterator15.hasNext()) {
                                            iterator15.next().E();
                                        }
                                        this.arena.a().b(new ArrayList<Team>(arena2.a().r()));
                                        final Iterator<Player> iterator16 = this.arena.getPlayers().iterator();
                                        while (iterator16.hasNext()) {
                                            this.arena.p(iterator16.next());
                                        }
                                        this.arena.a.F();
                                    }
                                    else {
                                        this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_Recount_TooFewPlayers).a("number", new StringBuilder().append(arena2.k() - this.arena.getPlayers().size()).toString()));
                                        this.arena.D = true;
                                        final int m = this.arena.m();
                                        this.arena.a.stop();
                                        this.arena.a = this.arena.a(m);
                                        this.arena.I.clear();
                                        this.arena.E();
                                        final Iterator<Player> iterator17 = this.arena.getPlayers().iterator();
                                        while (iterator17.hasNext()) {
                                            this.arena.p(iterator17.next());
                                        }
                                    }
                                }
                                else {
                                    final int n3 = (int)(this.arena.m() * 1.5);
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n3);
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.ArenaVoting_Recount_NoArenaToVote));
                                    final Iterator<Player> iterator18 = this.arena.getPlayers().iterator();
                                    while (iterator18.hasNext()) {
                                        this.arena.p(iterator18.next());
                                    }
                                }
                            }
                            else if (this.arena.I.size() == 1 && this.arena.I.get(0).arena.b() == ArenaStatus.e) {
                                if (this.arena.getPlayers().size() >= this.arena.I.get(0).arena.getMinPlayers()) {
                                    this.arena.a.stop();
                                    this.arena.a = null;
                                    final Arena arena3 = this.arena.I.get(0).arena;
                                    for (final Player player3 : new ArrayList<Object>(this.arena.getPlayers())) {
                                        final Team a3 = this.arena.a(player3);
                                        this.arena.a(KickReason.h, player3);
                                        final Arena.AddPlayerFail a4 = arena3.a(player3, a3, true);
                                        if (a4 != null) {
                                            new bq("Error occured when adding player: " + a4.name()).printStackTrace();
                                        }
                                    }
                                }
                                else {
                                    this.arena.D = true;
                                    final int n4 = (int)(this.arena.m() * 1.5);
                                    this.arena.a.stop();
                                    this.arena.a = this.arena.a(n4);
                                    this.arena.a(de.marcely.bedwars.message.b.a(Language.TooLess_Players));
                                    if (value == ConfigValue.forcestart_time) {
                                        final Iterator<Player> iterator20 = this.arena.getPlayers().iterator();
                                        while (iterator20.hasNext()) {
                                            this.arena.p(iterator20.next());
                                        }
                                    }
                                }
                            }
                            else {
                                this.arena.I.clear();
                                this.arena.D = true;
                                this.arena.E();
                                if (value == ConfigValue.forcestart_time) {
                                    final Iterator<Player> iterator21 = this.arena.getPlayers().iterator();
                                    while (iterator21.hasNext()) {
                                        this.arena.p(iterator21.next());
                                    }
                                }
                            }
                        }
                        else {
                            this.arena.D();
                            this.arena.a.stop();
                            this.arena.a = null;
                        }
                    }
                }
                else {
                    ++this.P;
                    if (this.P >= 21) {
                        this.arena.a(de.marcely.bedwars.message.b.a(Language.Lobby_Waiting).a("amount", new StringBuilder().append(this.arena.k() - this.arena.j()).toString()));
                        this.P = 0;
                    }
                }
            }
            else if (this.arena.b() == ArenaStatus.f) {
                if (ConfigValue.timer_enabled) {
                    final Arena arena4 = this.arena;
                    --arena4.N;
                    if (this.arena.N >= 0) {
                        final Iterator<Player> iterator22 = this.arena.getPlayers().iterator();
                        while (iterator22.hasNext()) {
                            this.arena.a.r(iterator22.next());
                        }
                        final Iterator<Player> iterator23 = this.arena.getSpectators().iterator();
                        while (iterator23.hasNext()) {
                            this.arena.a.r(iterator23.next());
                        }
                    }
                    else {
                        final ArenaOutOfTimeEvent arenaOutOfTimeEvent = new ArenaOutOfTimeEvent(this.arena);
                        Bukkit.getPluginManager().callEvent((Event)arenaOutOfTimeEvent);
                        if (arenaOutOfTimeEvent.getNewTime() <= 0) {
                            this.arena.b((Team)null);
                        }
                        else {
                            this.arena.N = arenaOutOfTimeEvent.getNewTime();
                        }
                    }
                }
                ++this.Q;
                if (this.Q >= ConfigValue.performance.u) {
                    this.Q = 0;
                    for (final Map.Entry<Team, List<Player>> entry3 : this.arena.s.entrySet()) {
                        entry3.getValue().clear();
                        entry3.getValue().addAll(de.marcely.bedwars.util.b.a(this.arena.a().a((Team)entry3.getKey()).toBukkit(this.arena.getWorld()), ConfigValue.upgrade_spawnsize));
                        for (final Player player4 : de.marcely.bedwars.util.b.a(this.arena.a().a((Team)entry3.getKey()).toBukkit(this.arena.getWorld()), ConfigValue.upgrade_spawnsize)) {
                            if (!entry3.getValue().contains(player4)) {
                                entry3.getValue().add(player4);
                            }
                        }
                    }
                }
                for (final Map.Entry<Team, List<Player>> entry4 : this.arena.s.entrySet()) {
                    final Team team = entry4.getKey();
                    final int a5 = this.arena.a(DefaultUpgradeType.SPAWN_HEALRANGE.getObj(), team);
                    final int a6 = this.arena.a(DefaultUpgradeType.SPAWN_ENEMY_MININGFATIQUE.getObj(), team);
                    final int a7 = this.arena.a(DefaultUpgradeType.SPAWN_ENEMY_TRAP.getObj(), team);
                    for (final Player player5 : entry4.getValue()) {
                        final Team a8 = this.arena.a(player5);
                        if (a8 == null) {
                            continue;
                        }
                        if (team == a8) {
                            if (a5 < 1) {
                                continue;
                            }
                            player5.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 140, a5 - 1));
                        }
                        else {
                            if (a6 >= 1) {
                                player5.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 140, a6 - 1));
                            }
                            if (a7 < 1) {
                                continue;
                            }
                            player5.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, a7, 0));
                            player5.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, a7, 0));
                            this.arena.r.get(team).a(DefaultUpgradeType.SPAWN_ENEMY_TRAP.getObj(), 0);
                            Sound.TRAP_CAUSE.play(player5);
                            for (final Player player6 : this.arena.a(team)) {
                                s.a((CommandSender)player6, de.marcely.bedwars.message.b.a(Language.Trap));
                                Sound.TRAP_OWNER.play(player6);
                            }
                        }
                    }
                }
            }
            else if (this.arena.b() == ArenaStatus.h) {
                if (this.arena.a == null) {
                    this.arena.a = this.arena.a(ConfigValue.endlobby_countdown_time);
                    this.L = false;
                }
                else {
                    final int value2 = this.arena.a.getValue();
                    if (ConfigValue.endlobby_show_kick_time) {
                        for (final Player player7 : this.arena.getPlayers()) {
                            if ((value2 <= 30 && value2 % 30 == 0) || value2 == 20 || value2 == 10 || (value2 <= 5 && value2 >= 1)) {
                                s.a((CommandSender)player7, de.marcely.bedwars.message.b.a(Language.EndLobby_Counting).a("number", new StringBuilder().append(value2).toString()));
                                Sound.COUNTDOWN_COUNTING.play(player7);
                            }
                            else {
                                if (value2 != 0) {
                                    continue;
                                }
                                Sound.COUNTDOWN_DONECOUNTING.play(player7);
                            }
                        }
                    }
                    if (value2 <= 0) {
                        this.arena.a(KickReason.e);
                    }
                    else if (this.arena.getPlayers().size() == 0) {
                        this.arena.a(ArenaStatus.g);
                        this.arena.a.stop();
                        this.arena.a = null;
                    }
                    else if (value2 <= ConfigValue.endlobby_countdown_time / 100.0 * 70.0 && !this.L) {
                        this.L = true;
                        if (ConfigValue.lobby_endstats_enabled) {
                            final t t = (t)MBedwars.a.a("stats").a();
                            final Iterator<Player> iterator30 = this.arena.getPlayers().iterator();
                            while (iterator30.hasNext()) {
                                t.a((CommandSender)iterator30.next(), null, null, new String[0]);
                            }
                        }
                    }
                }
            }
        }
        s.a.a(l.a.b, this.arena.getName());
    }
    
    public Arena getArena() {
        return this.arena;
    }
}
