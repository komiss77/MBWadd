// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.game.regeneration.e;
import de.marcely.bedwars.game.regeneration.b;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.regeneration.a;

public enum RegenerationType
{
    c("Region", 0, true), 
    d("World", 1, true), 
    e("MapVote", 2, false);
    
    private boolean N;
    private static /* synthetic */ int[] j;
    
    static {
        a = new RegenerationType[] { RegenerationType.c, RegenerationType.d, RegenerationType.e };
    }
    
    private RegenerationType(final String name, final int ordinal, final boolean n) {
        this.N = n;
    }
    
    public boolean J() {
        return this.N;
    }
    
    @Nullable
    public a a(final Arena arena) {
        return this.a(arena, null);
    }
    
    @Nullable
    public a a(final Arena arena, @Nullable final CommandSender commandSender) {
        switch (k()[this.ordinal()]) {
            case 1: {
                return new b(arena, commandSender);
            }
            case 2: {
                return new e(arena, commandSender);
            }
            default: {
                return null;
            }
        }
    }
    
    public static RegenerationType a(final String anotherString) {
        RegenerationType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final RegenerationType regenerationType = values[i];
            if (regenerationType.name().equalsIgnoreCase(anotherString)) {
                return regenerationType;
            }
        }
        return null;
    }
    
    static /* synthetic */ int[] k() {
        final int[] j = RegenerationType.j;
        if (j != null) {
            return j;
        }
        final int[] i = new int[values().length];
        try {
            i[RegenerationType.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[RegenerationType.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[RegenerationType.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        return RegenerationType.j = i;
    }
}
