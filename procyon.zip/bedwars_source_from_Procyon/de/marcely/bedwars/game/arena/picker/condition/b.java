// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;

public class b extends a
{
    private final ArenaConditionVariable<?> a;
    private final ArenaConditionComparisonOperator a;
    private final ArenaConditionVariableType<?> a;
    
    public b(final ArenaConditionVariable<?> a, final ArenaConditionComparisonOperator a2, final ArenaConditionVariableType<?> a3) {
        this.a = a;
        this.a = a2;
        this.a = a3;
    }
    
    @Override
    public boolean a(final Arena arena) {
        return ((ArenaConditionVariableType)this.a.getValue(arena)).check(this.a, this.a);
    }
    
    @Override
    public String toString() {
        return "Child{variable=" + this.a.getType().getSimpleName() + ", operator=\"" + this.a.getUsage() + "\", comparison object=\"" + this.a.getEntry() + "\"}";
    }
    
    public ArenaConditionVariable<?> a() {
        return this.a;
    }
    
    public ArenaConditionComparisonOperator a() {
        return this.a;
    }
    
    public ArenaConditionVariableType<?> a() {
        return this.a;
    }
}
