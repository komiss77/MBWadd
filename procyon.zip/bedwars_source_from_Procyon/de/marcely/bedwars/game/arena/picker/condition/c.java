// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import java.util.Iterator;
import de.marcely.bedwars.api.Arena;
import java.util.ArrayList;
import java.util.Collection;

public class c extends a
{
    public Collection<a> b;
    private final Collection<a> c;
    
    public c() {
        this(new ArrayList<a>());
    }
    
    public c(final Collection<a> c) {
        this.b = null;
        this.c = c;
    }
    
    public c b() {
        this.b = new ArrayList<a>();
        return this;
    }
    
    @Override
    public boolean a(final Arena arena) {
        final boolean b = !(this.c.iterator().next() instanceof c);
        final Iterator<a> iterator = this.c.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().a(arena)) {
                if (!b) {
                    return true;
                }
                continue;
            }
            else {
                if (b) {
                    return false;
                }
                continue;
            }
        }
        return b;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Group{");
        final String[] elements = new String[this.c.size()];
        int n = 0;
        final Iterator<a> iterator = this.c.iterator();
        while (iterator.hasNext()) {
            elements[n++] = iterator.next().toString();
        }
        sb.append("childrens=[" + String.join(", ", (CharSequence[])elements) + "]");
        sb.append("}");
        return sb.toString();
    }
    
    public Collection<a> b() {
        return this.c;
    }
}
