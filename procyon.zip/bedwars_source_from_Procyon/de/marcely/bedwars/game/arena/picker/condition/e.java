// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeString;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeNumber;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;

public enum e
{
    a((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeNumber.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeNumber((float)arena.getTeamPlayers());
        }
    }), 
    b((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeNumber.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeNumber((float)arena.GetTeamColors().GetEnabledTeams().size());
        }
    }), 
    c((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeNumber.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeNumber((float)arena.getMaxPlayers());
        }
    }), 
    d((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeNumber.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeNumber((float)arena.getPlayers().size());
        }
    }), 
    e((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeNumber.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeNumber((float)arena.GetStatus().getNms().getID());
        }
    }), 
    f((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeString.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeString(arena.getName());
        }
    }), 
    g((ArenaConditionVariable<?>)new ArenaConditionVariable((Class)ArenaConditionVariableTypeString.class) {
        @Override
        public ArenaConditionVariableType getValue(final Arena arena) {
            return new ArenaConditionVariableTypeString(arena.getDisplayName());
        }
    });
    
    private final ArenaConditionVariable a;
    
    static {
        a = new e[] { e.a, e.b, e.c, e.d, e.e, e.f, e.g };
    }
    
    private e(final ArenaConditionVariable<?> a) {
        this.a = a;
    }
    
    public static void init() {
        if (s.aa.size() >= 1) {
            return;
        }
        e[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final e e = values[i];
            s.aa.put(e.toString().toLowerCase(), e.a);
        }
    }
    
    public ArenaConditionVariable a() {
        return this.a;
    }
}
