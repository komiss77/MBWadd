// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import javax.annotation.Nullable;

public enum ArenaConditionComparisonOperator
{
    b("EQUAL", 0, "="), 
    c("NOT_EQUAL", 1, "!="), 
    d("GREATER_THAN", 2, ">"), 
    e("LESS_THAN", 3, "<"), 
    f("GREATER_THAN_OR_EQUAL", 4, ">="), 
    g("LESS_THAN_OR_EQUAL", 5, "<=");
    
    private final String usage;
    
    static {
        a = new ArenaConditionComparisonOperator[] { ArenaConditionComparisonOperator.b, ArenaConditionComparisonOperator.c, ArenaConditionComparisonOperator.d, ArenaConditionComparisonOperator.e, ArenaConditionComparisonOperator.f, ArenaConditionComparisonOperator.g };
    }
    
    private ArenaConditionComparisonOperator(final String name, final int ordinal, final String usage) {
        this.usage = usage;
    }
    
    @Nullable
    public static ArenaConditionComparisonOperator a(final String anObject) {
        ArenaConditionComparisonOperator[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ArenaConditionComparisonOperator arenaConditionComparisonOperator = values[i];
            if (arenaConditionComparisonOperator.usage.equals(anObject)) {
                return arenaConditionComparisonOperator;
            }
        }
        return null;
    }
    
    public String getUsage() {
        return this.usage;
    }
}
