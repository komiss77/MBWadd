// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import java.lang.constant.Constable;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeString;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariableTypeNumber;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;
import javax.annotation.Nullable;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Stack;
import java.io.ByteArrayOutputStream;
import de.marcely.bedwars.bl;
import java.nio.charset.StandardCharsets;

public class d
{
    private int offset;
    
    public d() {
        this.offset = 0;
    }
    
    public d(final int offset) {
        this.offset = 0;
        this.offset = offset;
    }
    
    public c a(final String s) throws bl {
        return this.a(s.getBytes(StandardCharsets.UTF_8));
    }
    
    public c a(final byte[] array) throws bl {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int n = 0;
        int n2 = 0;
        final Stack<c> stack = new Stack<c>();
        byte[] byteArray = null;
        byte[] array2 = null;
        byte[] array3 = null;
        stack.push(new c(new ArrayList<a>()).b());
        while (this.offset < array.length) {
            final byte b = array[this.offset];
            if (n == 0) {
                if (b != 91) {
                    throw new bl("Missing first enclosing (Must start with a [)");
                }
                n = 1;
            }
            else if (b == 93) {
                n = 2;
                if (n2 >= 10 && n2 <= 19) {
                    array3 = byteArrayOutputStream.toByteArray();
                    break;
                }
                break;
            }
            Label_0900: {
                if (n2 == 11) {
                    if (b == 34) {
                        array3 = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                        n2 = 2;
                        break Label_0900;
                    }
                    byteArrayOutputStream.write(b);
                }
                if (b == 38 || b == 124) {
                    if (n2 != 10 && n2 != 2) {
                        throw new bl("Found a truth condition (& or |) at the wrong position");
                    }
                    if (byteArray == null && array2 == null && array3 == null) {
                        n2 = 0;
                        break Label_0900;
                    }
                    if (array3 == null && byteArrayOutputStream.size() >= 1 && n2 >= 10 && n2 <= 19) {
                        array3 = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                    }
                    final c c = stack.peek();
                    c.b.add(a(byteArray, array2, array3));
                    if (b == 124) {
                        c.b().add(new c(new ArrayList<a>(c.b)).b());
                        c.b.clear();
                    }
                    byteArray = null;
                    array2 = null;
                    array3 = null;
                    n2 = 0;
                }
                if (b == 40) {
                    final c c2 = stack.peek();
                    final c b2 = new c().b();
                    c2.b().addAll(c2.b);
                    c2.b().add(b2);
                    c2.b.clear();
                    stack.push(b2);
                }
                else if (b == 41) {
                    if (stack.size() <= 1) {
                        throw new bl("Can't go any deeper (Too many ) )");
                    }
                    if (n2 >= 10 && n2 <= 19) {
                        array3 = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                        n2 = 2;
                    }
                    if (n2 != 2) {
                        throw new bl("Found a ) at the wrong position");
                    }
                    final c c3 = stack.pop();
                    if (byteArray != null) {
                        c3.b.add(a(byteArray, array2, array3));
                        c3.b().add(new c(new ArrayList<a>(c3.b)).b());
                        c3.b.clear();
                        byteArray = null;
                        array2 = null;
                        array3 = null;
                        n2 = 2;
                    }
                }
                if (n2 == 0) {
                    if ((b >= 48 && b <= 58) || (b >= 97 && b <= 122) || (b >= 65 && b <= 90) || b == 95 || b == 64) {
                        byteArrayOutputStream.write(b);
                    }
                    else if (b == 62 || b == 60 || b == 61 || b == 33) {
                        byteArray = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                        byteArrayOutputStream.write(b);
                        n2 = 1;
                    }
                }
                else if (n2 == 1) {
                    if (b == 62 || b == 60 || b == 61 || b == 33) {
                        byteArrayOutputStream.write(b);
                    }
                    else if ((b >= 48 && b <= 57) || b == 46) {
                        array2 = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                        byteArrayOutputStream.write(b);
                        n2 = 10;
                    }
                    else if (b == 34) {
                        array2 = byteArrayOutputStream.toByteArray();
                        byteArrayOutputStream.reset();
                        n2 = 11;
                    }
                }
                else if (n2 == 10 && (b >= 48 || b <= 57 || b == 46)) {
                    byteArrayOutputStream.write(b);
                }
            }
            ++this.offset;
        }
        if (n == 1) {
            throw new bl("Missing last enclosing (Must end with a ])");
        }
        if (stack.size() >= 2) {
            throw new bl("Too many broken brackets (" + (stack.size() - 1) + " need to be closed with a ) )");
        }
        final c c4 = stack.peek();
        if (byteArray != null) {
            c4.b.add(a(byteArray, array2, array3));
            c4.b().add(new c(new ArrayList<a>(c4.b)));
        }
        return c4;
    }
    
    private static b a(@Nullable final byte[] bytes, @Nullable final byte[] bytes2, @Nullable final byte[] array) throws bl {
        final ArrayList<String> elements = new ArrayList<String>();
        if (bytes == null) {
            elements.add("Variable");
        }
        if (bytes2 == null) {
            elements.add("Comparison Operator");
        }
        if (array == null) {
            elements.add("Compare Object");
        }
        if (elements.size() >= 1) {
            throw new bl("Failed to add a child: Missing " + String.join(",", elements));
        }
        final String lowerCase = new String(bytes).toLowerCase();
        final ArenaConditionVariable<?> arenaConditionVariable = s.aa.get(lowerCase);
        if (arenaConditionVariable == null) {
            throw new bl("Unkown variable '" + lowerCase + "'");
        }
        final String str = new String(bytes2);
        final ArenaConditionComparisonOperator a = ArenaConditionComparisonOperator.a(str);
        if (a == null) {
            throw new bl("Unkown comparison operator '" + str + "'");
        }
        Label_0326: {
            if (arenaConditionVariable.getType() == ArenaConditionVariableTypeNumber.class) {
                final String s = new String(array);
                try {
                    final Constable value = Float.parseFloat(s);
                    break Label_0326;
                }
                catch (NumberFormatException ex) {
                    throw new bl("Failed to parse number '" + s + "'");
                }
            }
            if (arenaConditionVariable.getType() != ArenaConditionVariableTypeString.class) {
                throw new bl("Error: Unkown variable type" + arenaConditionVariable.getType().getSimpleName());
            }
            final Constable value = new String(array, StandardCharsets.UTF_8);
            try {
                return new b(arenaConditionVariable, a, (ArenaConditionVariableType<?>)arenaConditionVariable.getType().getConstructors()[0].newInstance(value));
            }
            catch (Exception ex2) {
                throw new bl("Comparison object type mismatch: Variable expects an other type");
            }
        }
    }
    
    public int getOffset() {
        return this.offset;
    }
    
    public void setOffset(final int offset) {
        this.offset = offset;
    }
}
