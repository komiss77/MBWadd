// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

import de.marcely.bedwars.api.Arena;

public abstract class a
{
    public abstract boolean a(final Arena p0);
}
