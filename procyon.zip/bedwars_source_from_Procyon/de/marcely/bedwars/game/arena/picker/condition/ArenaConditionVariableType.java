// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena.picker.condition;

public abstract class ArenaConditionVariableType<T>
{
    public static final byte NUMBER = 0;
    public static final byte STRING = 1;
    protected final T entry;
    
    public ArenaConditionVariableType(final T entry) {
        this.entry = entry;
    }
    
    public abstract byte getType();
    
    public abstract boolean equal(final T p0);
    
    public abstract boolean notEqual(final T p0);
    
    public abstract boolean greaterThan(final T p0);
    
    public abstract boolean lessThan(final T p0);
    
    public abstract boolean greaterThanOrEqual(final T p0);
    
    public abstract boolean lessThanOrEqual(final T p0);
    
    public boolean check(final ArenaConditionComparisonOperator obj, final ArenaConditionVariableType<?> arenaConditionVariableType) {
        switch (obj) {
            case b: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case c: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case d: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case e: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case f: {
                return this.equal(arenaConditionVariableType.entry);
            }
            case g: {
                return this.equal(arenaConditionVariableType.entry);
            }
            default: {
                throw new IllegalStateException("Operator " + obj + " not supported");
            }
        }
    }
    
    public T getEntry() {
        return this.entry;
    }
}
