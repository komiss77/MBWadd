// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;

public enum ArenaStatus
{
    d("Stopped", 0), 
    e("Lobby", 1), 
    f("Running", 2), 
    g("Reseting", 3), 
    h("EndLobby", 4);
    
    private static /* synthetic */ int[] l;
    
    static {
        a = new ArenaStatus[] { ArenaStatus.d, ArenaStatus.e, ArenaStatus.f, ArenaStatus.g, ArenaStatus.h };
    }
    
    private ArenaStatus(final String name, final int ordinal) {
    }
    
    public int getID() {
        return this.ordinal() + 1;
    }
    
    public static ArenaStatus a(final int n) {
        ArenaStatus[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ArenaStatus arenaStatus = values[i];
            if (arenaStatus.getID() == n) {
                return arenaStatus;
            }
        }
        return null;
    }
    
    public String o() {
        return this.b(null);
    }
    
    public String b(final Arena arena) {
        switch (m()[this.ordinal()]) {
            case 1: {
                return b.a(Language.Sign_Stopped).f(null);
            }
            case 2: {
                if (arena != null) {
                    return b.a(Language.Sign_Lobby).a("ingame", new StringBuilder().append(arena.j()).toString()).a("max", new StringBuilder().append(arena.getMaxPlayers()).toString()).f(null);
                }
                return b.a(Language.Sign_Lobby).f(null);
            }
            case 3: {
                return b.a(Language.Sign_Running).f(null);
            }
            case 4:
            case 5: {
                return b.a(Language.Sign_Reseting).f(null);
            }
            default: {
                return null;
            }
        }
    }
    
    public String[] a(final Arena arena) {
        final String[] array = { ConfigValue.sign_line1, ConfigValue.sign_line2, ConfigValue.sign_line3, ConfigValue.sign_line4 };
        for (int i = 0; i <= 3; ++i) {
            array[i] = array[i].replace("{arena}", arena.getDisplayName()).replace("{players}", new StringBuilder().append(arena.getPlayers().size()).toString()).replace("{maxplayers}", new StringBuilder().append(arena.getMaxPlayers()).toString()).replace("{status}", this.b(arena)).replace("{teams}", new StringBuilder().append(arena.a().r().size()).toString()).replace("{teamsize}", new StringBuilder().append(arena.getTeamPlayers()).toString());
        }
        return array;
    }
    
    public boolean F() {
        return this == ArenaStatus.e || this == ArenaStatus.h;
    }
    
    public boolean G() {
        return this == ArenaStatus.e || this == ArenaStatus.f || this == ArenaStatus.h;
    }
    
    public boolean H() {
        return this == ArenaStatus.e || this == ArenaStatus.f || this == ArenaStatus.h;
    }
    
    static /* synthetic */ int[] m() {
        final int[] l = ArenaStatus.l;
        if (l != null) {
            return l;
        }
        final int[] i = new int[values().length];
        try {
            i[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            i[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            i[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return ArenaStatus.l = i;
    }
}
