// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import de.marcely.bedwars.game.Team;
import java.util.Map;
import org.bukkit.entity.Player;
import java.util.HashMap;
import de.marcely.bedwars.bq;

public class g
{
    private static Arena arena;
    
    public static void c(final Arena arena) {
        g.arena = arena;
        I();
    }
    
    private static void I() {
        if (g.arena.a().r().size() < 2) {
            new bq("Less then 2 enabled teams?!").printStackTrace();
        }
        final HashMap<Player, Object> hashMap = new HashMap<Player, Object>(g.arena.b());
        for (final Player player : hashMap.keySet()) {
            final Team team = hashMap.get(player);
            if (a((Map<Player, Team>)hashMap) == null) {
                new NullPointerException("t1").printStackTrace();
            }
            hashMap.put(player, (team == null) ? a((Map<Player, Team>)hashMap) : team);
        }
        final ArrayList<Team> list = new ArrayList<Team>();
        for (final Team team2 : hashMap.values()) {
            if (!list.contains(team2)) {
                list.add(team2);
            }
        }
        final Team a = a((Map<Player, Team>)hashMap, false);
        final Team d = d((Map<Player, Team>)hashMap);
        final int size = a((Map<Player, Team>)hashMap, a).size();
        final double n = (a((Map<Player, Team>)hashMap, d).size() - size) / 2.0 + size;
        final HashMap<Team, List<Player>> hashMap2 = (HashMap<Team, List<Player>>)new HashMap<Object, List<Player>>();
        for (final Team team3 : g.arena.a().r()) {
            hashMap2.put(team3, a((Map<Player, Team>)hashMap, team3));
        }
        for (final Map.Entry<Player, Team> entry : hashMap.entrySet()) {
            final Player player2 = entry.getKey();
            final Team team4 = entry.getValue();
            final int size2 = hashMap2.get(team4).size();
            if (size2 != n && size2 != n && size2 > (int)n + 0.5 && size2 - 1 == n) {
                final List<Player> list2 = hashMap2.get(team4);
                final Team b = b(hashMap2);
                final List<Player> list3 = hashMap2.get(b);
                list2.remove(player2);
                list3.add(player2);
                hashMap2.put(team4, list2);
                hashMap2.put(b, list3);
            }
        }
        for (final Map.Entry<Team, List<Player>> entry2 : hashMap2.entrySet()) {
            final Iterator<Player> iterator6 = entry2.getValue().iterator();
            while (iterator6.hasNext()) {
                hashMap.put(iterator6.next(), entry2.getKey());
            }
        }
        for (final Player player3 : g.arena.getPlayers()) {
            final Team a2 = g.arena.a(player3);
            if (hashMap.get(player3) == null) {
                new bq("Teamsortation failed: Player '" + player3.getName() + "' isn't in a team").printStackTrace();
            }
            else {
                if (a2 != null && hashMap.get(player3) == a2) {
                    continue;
                }
                g.arena.b(player3, hashMap.get(player3));
            }
        }
    }
    
    private static Team a(final Map<Player, Team> map) {
        return c(map);
    }
    
    private static Team b(final Map<Team, List<Player>> map) {
        final HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        for (final Team team : g.arena.a().r()) {
            hashMap.put(team, map.containsKey(team) ? map.get(team).size() : 0);
        }
        int intValue = Integer.MAX_VALUE;
        Team team2 = null;
        for (final Map.Entry<Team, Integer> entry : hashMap.entrySet()) {
            if (entry.getValue() < intValue) {
                intValue = entry.getValue();
                team2 = entry.getKey();
            }
        }
        return team2;
    }
    
    private static Team c(final Map<Player, Team> map) {
        return a(map, true);
    }
    
    private static Team a(final Map<Player, Team> map, final boolean b) {
        final HashMap<Object, Integer> hashMap = new HashMap<Object, Integer>();
        final Iterator<Team> iterator = g.arena.a().r().iterator();
        while (iterator.hasNext()) {
            hashMap.put(iterator.next(), 0);
        }
        final Iterator<Map.Entry<Player, Team>> iterator2 = map.entrySet().iterator();
        while (iterator2.hasNext()) {
            final Team team = iterator2.next().getValue();
            if (team != null) {
                hashMap.put(team, hashMap.get(team) + 1);
            }
        }
        int intValue = Integer.MAX_VALUE;
        Team team2 = null;
        for (final Map.Entry<Team, Integer> entry : hashMap.entrySet()) {
            if (entry.getValue() < intValue) {
                intValue = entry.getValue();
                team2 = entry.getKey();
            }
        }
        return team2;
    }
    
    private static Team d(final Map<Player, Team> map) {
        final HashMap<Object, Integer> hashMap = new HashMap<Object, Integer>();
        final Iterator<Team> iterator = g.arena.a().r().iterator();
        while (iterator.hasNext()) {
            hashMap.put(iterator.next(), 0);
        }
        final Iterator<Map.Entry<Player, Team>> iterator2 = map.entrySet().iterator();
        while (iterator2.hasNext()) {
            final Team team = iterator2.next().getValue();
            hashMap.put(team, hashMap.get(team) + 1);
        }
        int intValue = Integer.MIN_VALUE;
        Team team2 = null;
        for (final Map.Entry<Team, Integer> entry : hashMap.entrySet()) {
            if (entry.getValue() > intValue) {
                intValue = entry.getValue();
                team2 = entry.getKey();
            }
        }
        return team2;
    }
    
    private static List<Player> a(final Map<Player, Team> map, final Team team) {
        final ArrayList<Player> list = new ArrayList<Player>();
        for (final Map.Entry<Player, Team> entry : map.entrySet()) {
            if (entry.getValue() == team) {
                list.add(entry.getKey());
            }
        }
        return list;
    }
}
