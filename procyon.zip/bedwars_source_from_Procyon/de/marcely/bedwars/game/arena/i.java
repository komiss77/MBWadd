// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.util.s;
import java.util.HashMap;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import java.util.Map;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.api.UpgradeStateAPI;

public class i implements UpgradeStateAPI
{
    private final Arena arena;
    private final Team team;
    private Map<UpgradeType, Integer> D;
    
    public i(final Arena arena, final Team team) {
        this.D = new HashMap<UpgradeType, Integer>();
        this.arena = arena;
        this.team = team;
    }
    
    public void a(final UpgradeType upgradeType, final int i) {
        this.D.put(upgradeType, i);
    }
    
    public int a(final UpgradeType upgradeType) {
        if (this.D.containsKey(upgradeType)) {
            return this.D.get(upgradeType);
        }
        return 0;
    }
    
    public boolean a(final UpgradeType upgradeType) {
        return s.a(upgradeType, this.a(upgradeType) + 1) != null;
    }
    
    public void clear() {
        this.D.clear();
    }
    
    public Team getTeam() {
        return this.team;
    }
    
    @Override
    public de.marcely.bedwars.api.Team GetTeam() {
        return de.marcely.bedwars.api.Team.fromInternal(this.team);
    }
    
    @Override
    public Arena getArena() {
        return this.arena;
    }
}
