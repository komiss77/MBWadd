// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;

public class CrashMessage
{
    private CrashMessageType type;
    private String information;
    private String custom_message;
    
    public CrashMessage(final CrashMessageType crashMessageType) {
        this(crashMessageType, null);
    }
    
    public CrashMessage(final CrashMessageType type, final String information) {
        this.type = type;
        this.information = information;
    }
    
    public CrashMessageType getType() {
        return this.type;
    }
    
    public String getInformation() {
        return this.information;
    }
    
    public String getMessage() {
        switch (this.type) {
            case missingBed: {
                return b.a(Language.CrashMessage_MissingBed).f(null);
            }
            case missingGameDoneLocation: {
                return b.a(Language.CrashMessage_MissingGameDoneLocation).f(null);
            }
            case missingLobbyLocation: {
                return b.a(Language.CrashMessage_MissingLobbyLocation).f(null);
            }
            case missingTeamSpawn: {
                return b.a(Language.CrashMessage_MissingTeamSpawn).f(null);
            }
            case tooFewItemSpawners: {
                return b.a(Language.CrashMessage_TooFewItemSpawners).f(null);
            }
            case custom: {
                return this.custom_message;
            }
            default: {
                return null;
            }
        }
    }
    
    public static CrashMessage createCustomCrashMessage(final String s) {
        return createCustomCrashMessage(s, null);
    }
    
    public static CrashMessage createCustomCrashMessage(final String custom_message, final String s) {
        final CrashMessage crashMessage = new CrashMessage(CrashMessageType.custom, s);
        crashMessage.custom_message = custom_message;
        return crashMessage;
    }
    
    public enum CrashMessageType
    {
        missingBed("missingBed", 0), 
        missingTeamSpawn("missingTeamSpawn", 1), 
        missingLobbyLocation("missingLobbyLocation", 2), 
        missingGameDoneLocation("missingGameDoneLocation", 3), 
        tooFewItemSpawners("tooFewItemSpawners", 4), 
        custom("custom", 5);
        
        private CrashMessageType(final String name, final int ordinal) {
        }
    }
}
