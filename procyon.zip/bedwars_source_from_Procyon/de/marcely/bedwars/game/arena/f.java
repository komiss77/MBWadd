// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import java.util.ArrayList;
import java.util.List;

public class f extends Flag
{
    private final a a;
    
    private f(final String s, final Object o, final VarType varType, final a a) {
        super(s, varType, o);
        this.a = a;
    }
    
    public a a() {
        return this.a;
    }
    
    public enum a
    {
        b("Author", 0, (Object)"", VarType.a), 
        c("MinPlayers", 1, (Object)2, VarType.b), 
        d("HasCustomName", 2, (Object)false, VarType.d), 
        e("CustomName", 3, (Object)"Default Custom Name", VarType.a);
        
        private final Object f;
        private final VarType type;
        
        static {
            a = new a[] { f.a.b, f.a.c, f.a.d, f.a.e };
        }
        
        private a(final String name, final int ordinal, final Object f, final VarType type) {
            this.f = f;
            this.type = type;
        }
        
        public String getName() {
            return this.name().replace("_", "");
        }
        
        public static List<Flag> p() {
            final ArrayList<Flag> list = new ArrayList<Flag>();
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                list.add(new f(a.getName(), a.f, a.type, a, null));
            }
            return list;
        }
        
        public static a a(final String anotherString) {
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                if (a.getName().equalsIgnoreCase(anotherString)) {
                    return a;
                }
            }
            return null;
        }
        
        public Object getDefaultValue() {
            return this.f;
        }
        
        public VarType getType() {
            return this.type;
        }
    }
}
