// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

public enum KickReason
{
    @Deprecated
    a("Custom", 0), 
    b("Leave", 1), 
    c("Kick", 2), 
    d("Loose", 3), 
    e("End", 4), 
    f("FullEnd", 5), 
    g("Draw", 6), 
    h("MapVote_SwitchArena", 7);
    
    static {
        a = new KickReason[] { KickReason.a, KickReason.b, KickReason.c, KickReason.d, KickReason.e, KickReason.f, KickReason.g, KickReason.h };
    }
    
    private KickReason(final String name, final int ordinal) {
    }
}
