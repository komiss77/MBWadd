// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Player;
import java.util.List;

public class e
{
    private int O;
    private int R;
    private double value;
    private List<Player> players;
    private BukkitTask c;
    private int S;
    private boolean M;
    
    public e(final int o, final int n, final int r, final List<Player> players) {
        this.M = false;
        this.O = o;
        this.value = n;
        this.R = r;
        this.players = players;
    }
    
    public int n() {
        return this.O;
    }
    
    public int getValue() {
        return (int)this.value;
    }
    
    public int o() {
        return this.R;
    }
    
    public List<Player> getPlayers() {
        return this.players;
    }
    
    public void H() {
        if (this.M) {
            new SecurityException("Already stopped").printStackTrace();
        }
        if (this.c != null) {
            return;
        }
        this.value -= 1.0 / this.O;
        this.update();
    }
    
    public void setValue(final int n) {
        this.b(n, true);
    }
    
    public void b(final int s, final boolean b) {
        if (this.M) {
            new SecurityException("Already stopped").printStackTrace();
        }
        if (!b) {
            if (this.c != null) {
                this.c.cancel();
                this.value = this.S;
            }
            final double n = (s - this.value) / 20.0;
            this.S = s;
            this.c = new BukkitRunnable() {
                private int r = 0;
                
                public void run() {
                    ++this.r;
                    final e c = (e)n;
                    e.a(c, c.value + n);
                    e.this.update();
                    if (this.r >= 20) {
                        e.a(n, null);
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
        }
        else {
            this.value = s;
        }
    }
    
    public boolean stop() {
        if (!this.M && this.c != null) {
            this.c.cancel();
            return this.M = true;
        }
        return false;
    }
    
    private boolean update() {
        final float exp = (float)(this.value / this.R);
        if (exp < 0.0f || exp > 1.0f) {
            this.stop();
            return false;
        }
        for (final Player player : this.players) {
            player.setLevel((int)this.value);
            player.setExp(exp);
        }
        return true;
    }
    
    public boolean I() {
        return this.c != null;
    }
    
    public boolean isStopped() {
        return this.M;
    }
    
    static /* synthetic */ void a(final e e, final double value) {
        e.value = value;
    }
    
    static /* synthetic */ void a(final e e, final BukkitTask c) {
        e.c = c;
    }
}
