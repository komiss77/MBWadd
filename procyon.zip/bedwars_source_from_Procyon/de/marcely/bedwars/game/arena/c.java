// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.f;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import de.marcely.bedwars.d;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.du;
import de.marcely.bedwars.util.s;
import org.bukkit.scoreboard.DisplaySlot;
import de.marcely.bedwars.config.j;
import org.bukkit.Bukkit;
import java.util.concurrent.Future;
import de.marcely.bedwars.config.ConfigValue;
import java.util.Iterator;
import org.bukkit.entity.Player;

public class c
{
    private final Arena arena;
    private boolean enabled;
    
    public c(final Arena arena) {
        this.enabled = true;
        this.arena = arena;
    }
    
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    public void E() {
        if (this.arena.b() == ArenaStatus.e) {
            this.F();
        }
        else {
            this.G();
        }
    }
    
    public void F() {
        if (!this.enabled) {
            return;
        }
        final Iterator<Player> iterator = this.arena.getPlayers().iterator();
        while (iterator.hasNext()) {
            this.q(iterator.next());
        }
    }
    
    public void q(final Player player) {
        if (!this.enabled || !ConfigValue.scoreboard_enabled) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> a = de.marcely.bedwars.game.stats.c.a(player);
        s.a((Future<Object>)a, new Runnable() {
            @Override
            public void run() {
                try {
                    final de.marcely.bedwars.game.stats.c c = a.get();
                    final Scoreboard newScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
                    final Objective registerNewObjective = newScoreboard.registerNewObjective("MBWLobby", "MBWLobby");
                    String s = "";
                    registerNewObjective.setDisplayName(de.marcely.bedwars.game.arena.c.this.a(j.title, player, c));
                    registerNewObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
                    int score = de.marcely.bedwars.game.arena.c.this.arena.l() + j.o.size();
                    for (String a : j.o) {
                        Score score2;
                        if (!a.replace(" ", "").isEmpty()) {
                            if (ConfigValue.placeholderapi_enabled) {
                                final Iterator<du> iterator2 = de.marcely.bedwars.util.s.b.a(du.class).iterator();
                                while (iterator2.hasNext()) {
                                    a = iterator2.next().a(player, a);
                                }
                            }
                            score2 = registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.a(a.replace("&", ""), player, c));
                        }
                        else {
                            score2 = registerNewObjective.getScore(s = String.valueOf(s) + " ");
                        }
                        score2.setScore(score);
                        --score;
                    }
                    int n = -1;
                    for (String a2 : j.p) {
                        Score score3;
                        if (!a2.replace(" ", "").isEmpty()) {
                            if (ConfigValue.placeholderapi_enabled) {
                                final Iterator<du> iterator4 = de.marcely.bedwars.util.s.b.a(du.class).iterator();
                                while (iterator4.hasNext()) {
                                    a2 = iterator4.next().a(player, a2);
                                }
                            }
                            score3 = registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.a(a2.replace("&", ""), player, c));
                        }
                        else {
                            score3 = registerNewObjective.getScore(s = String.valueOf(s) + " ");
                        }
                        score3.setScore(n--);
                    }
                    if (!j.t.isEmpty()) {
                        for (final Team team : de.marcely.bedwars.game.arena.c.this.arena.a().r()) {
                            registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.a(j.t.replace("{color}", new StringBuilder().append(team.getChatColor()).toString()).replace("{name}", team.getName(true)).replace("{playersinteam}", new StringBuilder().append(de.marcely.bedwars.game.arena.c.this.arena.a(team).size()).toString()), player, c)).setScore(de.marcely.bedwars.game.arena.c.this.arena.a(team).size());
                        }
                    }
                    player.setScoreboard(newScoreboard);
                    de.marcely.bedwars.game.arena.c.this.r(player);
                }
                catch (Exception ex) {
                    de.marcely.bedwars.d.b("Scoreboard 'Lobby' issue:");
                    ex.printStackTrace();
                }
            }
        });
    }
    
    private String a(final String s, final Player player, final de.marcely.bedwars.game.stats.c c) {
        if (!this.enabled) {
            return s;
        }
        return this.a((this.arena.a() == RegenerationType.e && !this.arena.D) ? this.arena.I.get(0).arena : this.arena, s, player, c);
    }
    
    public void r(final Player player) {
        if (!this.enabled) {
            return;
        }
        final Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard.getObjective("MBWIngame") != null) {
            final int i = this.arena.N / 60;
            String s = String.valueOf(this.arena.N - i * 60);
            if (s.length() == 1) {
                s = "0" + s;
            }
            scoreboard.getObjective("MBWIngame").setDisplayName(f.title.replace("{countdown}", String.valueOf(i) + ":" + s));
        }
    }
    
    public void s(final Player player) {
        if (!this.enabled || !ConfigValue.scoreboard_enabled) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> a = de.marcely.bedwars.game.stats.c.a(player);
        s.a((Future<Object>)a, new Runnable() {
            @Override
            public void run() {
                try {
                    final de.marcely.bedwars.game.stats.c c = a.get();
                    final Scoreboard newScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
                    final Objective registerNewObjective = newScoreboard.registerNewObjective("MBWIngame", "MBWIngame");
                    String s = "";
                    registerNewObjective.setDisplayName(de.marcely.bedwars.game.arena.c.this.b(f.title, player, c));
                    registerNewObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
                    int n = de.marcely.bedwars.game.arena.c.this.arena.l() + f.o.size();
                    for (String a : f.o) {
                        Score score;
                        if (!a.replace(" ", "").isEmpty()) {
                            if (ConfigValue.placeholderapi_enabled) {
                                final Iterator<du> iterator2 = de.marcely.bedwars.util.s.b.a(du.class).iterator();
                                while (iterator2.hasNext()) {
                                    a = iterator2.next().a(player, a);
                                }
                            }
                            score = registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.b(a.replace("&", ""), player, c));
                        }
                        else {
                            score = registerNewObjective.getScore(s = String.valueOf(s) + " ");
                        }
                        score.setScore(n--);
                    }
                    int n2 = -1;
                    for (String a2 : f.p) {
                        Score score2;
                        if (!a2.replace(" ", "").isEmpty()) {
                            if (ConfigValue.placeholderapi_enabled) {
                                final Iterator<du> iterator4 = de.marcely.bedwars.util.s.b.a(du.class).iterator();
                                while (iterator4.hasNext()) {
                                    a2 = iterator4.next().a(player, a2);
                                }
                            }
                            score2 = registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.b(a2.replace("&", ""), player, c));
                        }
                        else {
                            score2 = registerNewObjective.getScore(s = String.valueOf(s) + " ");
                        }
                        score2.setScore(n2--);
                    }
                    if (!f.t.isEmpty()) {
                        for (final Team team : de.marcely.bedwars.game.arena.c.this.arena.a().r()) {
                            final int size = de.marcely.bedwars.game.arena.c.this.arena.a(team).size();
                            if (!ConfigValue.scoreboard_ingame_display_emptyteams && size == 0) {
                                continue;
                            }
                            registerNewObjective.getScore(de.marcely.bedwars.game.arena.c.this.b(f.t.replace("{color}", new StringBuilder().append(team.getChatColor()).toString()).replace("{name}", team.getName(true)).replace("{playersinteam}", new StringBuilder().append(size).toString()).replace("{heart}", a(!de.marcely.bedwars.game.arena.c.this.arena.a().d(team))).replace("{firstletter}", team.m()), player, c)).setScore(de.marcely.bedwars.game.arena.c.this.arena.a(team).size());
                        }
                    }
                    player.setScoreboard(newScoreboard);
                    de.marcely.bedwars.game.arena.c.this.arena.a.r(player);
                }
                catch (Exception ex) {
                    de.marcely.bedwars.d.b("Scoreboard 'Ingame' issue:");
                    ex.printStackTrace();
                }
            }
        });
    }
    
    private static String a(final boolean b) {
        return b ? ConfigValue.scoreboard_heart_alive : ConfigValue.scoreboard_heart_dead;
    }
    
    private String b(final String s, final Player player, final de.marcely.bedwars.game.stats.c c) {
        if (!this.enabled) {
            return s;
        }
        String replacement = "";
        for (final Team team : this.arena.a().r()) {
            if (!this.arena.a().a().contains(team) && this.arena.a(team).size() >= 1) {
                replacement = String.valueOf(replacement) + ConfigValue.scoreboard_ingame_teamsleft.replace("{team}", team.getName()).replace("{teamcolor}", new StringBuilder().append(team.getChatColor()).toString());
            }
            else {
                replacement = String.valueOf(replacement) + ConfigValue.scoreboard_ingame_teamsleft_dead.replace("{team}", team.getName()).replace("{teamcolor}", new StringBuilder().append(team.getChatColor()).toString());
            }
        }
        final Team a = this.arena.a(player);
        final de.marcely.bedwars.game.stats.c b = c.b();
        String replacement2 = de.marcely.bedwars.message.b.a(Language.Spectator).f((CommandSender)player);
        ChatColor obj = ChatColor.BOLD;
        String replacement3 = "?";
        if (a != null) {
            replacement2 = a.getName();
            obj = a.getChatColor();
            replacement3 = (this.arena.a().a().contains(a) ? de.marcely.bedwars.message.b.a(Language.Scoreboard_BedState_Destroyed).f((CommandSender)player) : de.marcely.bedwars.message.b.a(Language.Scoreboard_BedState_Alive).f((CommandSender)player));
        }
        return this.a(this.arena, s, player, c).replace("{teamsleft}", replacement).replace("{team}", replacement2).replace("{teamcolor}", new StringBuilder().append(obj).toString()).replace("{bedstate}", replacement3).replace("{gstats:kills}", new StringBuilder().append(b.getKills()).toString()).replace("{gstats:deaths}", new StringBuilder().append(b.getDeaths()).toString()).replace("{gstats:bedsdestroyed}", new StringBuilder().append(b.getBedsDestroyed()).toString()).replace("{gstats:kd}", new StringBuilder().append(b.b()).toString());
    }
    
    private String a(final Arena arena, final String s, final Player player, final de.marcely.bedwars.game.stats.c c) {
        if (!this.enabled) {
            return s;
        }
        return s.replace("{arena}", arena.getDisplayName()).replace("{players}", new StringBuilder().append(arena.j()).toString()).replace("{maxplayers}", new StringBuilder().append(arena.getMaxPlayers()).toString()).replace("{teams}", new StringBuilder().append(arena.a().r().size()).toString()).replace("{maxplayersinteam}", new StringBuilder().append(arena.getTeamPlayers()).toString()).replace("{date}", s.u()).replace("{ip}", ConfigValue.ip_display).replace("{stats:rank}", new StringBuilder().append((c.getRank() >= 1) ? new StringBuilder().append(c.getRank()).toString() : b.a(Language.Ranking_Unranked)).toString()).replace("{stats:wins}", new StringBuilder().append(c.getWins()).toString()).replace("{stats:loses}", new StringBuilder().append(c.getLoses()).toString()).replace("{stats:kills}", new StringBuilder().append(c.getKills()).toString()).replace("{stats:deaths}", new StringBuilder().append(c.getDeaths()).toString()).replace("{stats:bedsdestroyed}", new StringBuilder().append(c.getBedsDestroyed()).toString()).replace("{stats:roundsplayed}", new StringBuilder().append(c.getRoundsPlayed()).toString()).replace("{stats:playtime}", s.a(c.getPlayTime())).replace("{stats:kd}", new StringBuilder().append(c.b()).toString()).replace("{stats:wl}", new StringBuilder().append(c.a()).toString()).replace("{server:onlineplayers}", new StringBuilder().append(de.marcely.bedwars.util.b.getOnlinePlayers().size()).toString());
    }
    
    public void G() {
        if (!this.enabled) {
            return;
        }
        final Iterator<Player> iterator = this.arena.getPlayers().iterator();
        while (iterator.hasNext()) {
            this.s(iterator.next());
        }
        final Iterator<Player> iterator2 = this.arena.getSpectators().iterator();
        while (iterator2.hasNext()) {
            this.s(iterator2.next());
        }
    }
    
    public static void t(final Player player) {
        if (!ConfigValue.scoreboard_enabled || (ConfigValue.scoreboard_enabled && g(player))) {
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
        }
    }
    
    public static boolean g(final Player player) {
        if (player.getScoreboard() == null) {
            return false;
        }
        for (final Objective objective : player.getScoreboard().getObjectives()) {
            if (objective.getName().equals("MBWLobby") || objective.getName().equals("MBWIngame")) {
                return true;
            }
        }
        return false;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
}
