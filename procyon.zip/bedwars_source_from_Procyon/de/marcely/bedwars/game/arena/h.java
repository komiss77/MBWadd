// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import javax.annotation.Nullable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.location.XYZ;
import java.util.Set;
import org.bukkit.Location;
import de.marcely.bedwars.versions.w;
import org.bukkit.DyeColor;
import org.bukkit.block.Bed;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.versions.Version;
import org.bukkit.block.Block;
import java.util.Iterator;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.Material;
import de.marcely.bedwars.d;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.Bukkit;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.ArrayList;
import org.bukkit.inventory.Inventory;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.game.location.XYZD;
import java.util.Map;
import de.marcely.bedwars.game.Team;
import java.util.List;
import de.marcely.bedwars.api.TeamColors;

public class h implements TeamColors
{
    private final Arena arena;
    private List<Team> i;
    public Map<Team, XYZD> y;
    private Map<Team, XYZYP> z;
    private Map<Team, i> A;
    private Map<Team, Long> B;
    public Map<Team, Inventory> C;
    
    public h(final Arena arena) {
        this.i = new ArrayList<Team>();
        this.y = new HashMap<Team, XYZD>();
        this.z = new HashMap<Team, XYZYP>();
        this.A = new HashMap<Team, i>();
        this.B = new HashMap<Team, Long>();
        this.C = new HashMap<Team, Inventory>();
        this.arena = arena;
    }
    
    public Inventory a(final Player player, final Team team) {
        if (!this.C.containsKey(team)) {
            this.C.put(team, Bukkit.createInventory((InventoryHolder)player, InventoryType.CHEST));
        }
        return this.C.get(team);
    }
    
    public void reset() {
        this.reset(false);
    }
    
    public void reset(final boolean b) {
        this.B.clear();
        this.C.clear();
        this.A.clear();
        if (!b) {
            for (final Team team : this.i) {
                if (this.arena.a(team).size() == 0) {
                    this.B.put(team, System.currentTimeMillis());
                }
            }
        }
        for (final Map.Entry<Team, XYZD> entry : this.e().entrySet()) {
            final Team team2 = entry.getKey();
            final XYZD xyzd = entry.getValue();
            if (xyzd == null) {
                continue;
            }
            if (this.arena.getWorld() == null) {
                d.b("World is null in TeamColors (1)", this.arena);
            }
            else {
                final Block block = this.arena.getWorld().getBlockAt((int)xyzd.getX(), (int)xyzd.getY(), (int)xyzd.getZ());
                if (!b && this.B.containsKey(team2)) {
                    block.setType(Material.AIR);
                }
                else if (ConfigValue.bed_block == Material.BED_BLOCK) {
                    this.a(block, team2, xyzd, false);
                    this.a(block.getRelative(xyzd.getDAsBlockFace()), team2, xyzd, true);
                }
                else {
                    block.setType(ConfigValue.bed_block);
                    if (!ConfigValue.bed_block_dye) {
                        continue;
                    }
                    a.a(block, team2.getDyeColor());
                }
            }
        }
    }
    
    private void a(final Block block, final Team team, final XYZD xyzd, final boolean b) {
        if (Version.a().getVersionNumber() <= 12) {
            b.a(block, Material.BED_BLOCK, false);
            block.setData((byte)(xyzd.getD() + (b ? 8 : 0)), false);
            if (ConfigValue.bed_block_dye && Version.a().getVersionNumber() == 12) {
                final Bed bed = (Bed)block.getState();
                bed.setColor(team.getDyeColor());
                bed.update();
            }
        }
        else {
            String name = "RED_BED";
            if (ConfigValue.bed_block_dye) {
                if (team.getDyeColor() == DyeColor.SILVER) {
                    name = "LIGHT_GRAY";
                }
                else {
                    name = team.getDyeColor().name();
                }
            }
            ((w)Version.a().a()).b(block.getWorld(), block.getX(), block.getY(), block.getZ(), String.valueOf(name.toLowerCase()) + "_bed");
            ((w)Version.a().a()).a(block, xyzd.getDAsBlockFace(), b);
        }
    }
    
    public void J() {
        this.i.clear();
    }
    
    public boolean c(final Team team) {
        if (!this.r().contains(team)) {
            this.i.add(team);
            return true;
        }
        return false;
    }
    
    public void b(final List<Team> i) {
        this.i = i;
    }
    
    public boolean a(final Team team, final boolean b) {
        if (b && !this.B.containsKey(team)) {
            this.B.put(team, System.currentTimeMillis());
        }
        else {
            if (b || !this.B.containsKey(team)) {
                return false;
            }
            this.B.remove(team);
        }
        this.arena.a.G();
        return true;
    }
    
    public void a(final Location location, final Team team) {
        this.a(XYZYP.valueOf(location), team);
    }
    
    public void a(final XYZYP xyzyp, final Team team) {
        this.z.put(team, xyzyp);
    }
    
    public void a(final XYZD xyzd, final Team team) {
        this.y.put(team, xyzd);
    }
    
    public XYZD a(final Team team) {
        if (this.arena.b() == ArenaStatus.f && this.i.contains(team) && this.y.get(team) == null) {
            d.b("Bed of '" + team.name() + "' in the arena '" + this.arena.getName() + "' is broken! Make sure to place it again.");
        }
        return this.y.get(team);
    }
    
    public XYZYP a(final Team team) {
        return this.z.get(team);
    }
    
    public List<Team> r() {
        return this.i;
    }
    
    public Map<Team, XYZYP> d() {
        return this.z;
    }
    
    public Map<Team, XYZD> e() {
        return this.y;
    }
    
    public boolean d(final Team team) {
        return this.B.containsKey(team);
    }
    
    public Set<Team> a() {
        return this.B.keySet();
    }
    
    @Override
    public Arena getArena() {
        return this.arena;
    }
    
    public long a(final Team team) {
        return this.B.get(team);
    }
    
    public Block[] a(final Team team) {
        if (ConfigValue.bed_block == Material.BED_BLOCK) {
            final Block[] array = new Block[2];
            final XYZD a = this.a(team);
            array[0] = a.toBlock(this.arena.getWorld());
            array[1] = array[0].getRelative(a.getDAsBlockFace());
            return array;
        }
        return new Block[] { this.a(team).toBlock(this.arena.getWorld()) };
    }
    
    public Block[] a() {
        final Block[] array = new Block[this.i.size() * ((ConfigValue.bed_block == Material.BED_BLOCK) ? 2 : 1)];
        for (int i = 0; i < this.i.size(); ++i) {
            final Block[] a = this.a((Team)this.i.get(i));
            for (int j = 0; j < a.length; ++j) {
                array[i * a.length + j] = a[j];
            }
        }
        return array;
    }
    
    @Nullable
    public Team a(final Location location) {
        for (final Team team : this.r()) {
            if (this.a(team) != null && s.a(XYZ.valueOf(location), this.a(team))) {
                return team;
            }
        }
        return null;
    }
    
    @Override
    public void setTeamEnabled(final de.marcely.bedwars.api.Team team, final boolean b) {
        if (b) {
            if (!this.i.contains(team.getInternal())) {
                this.i.remove(team.getInternal());
            }
        }
        else if (this.i.contains(team.getInternal())) {
            this.i.add(team.getInternal());
        }
    }
    
    @Override
    public boolean isTeamEnabled(final de.marcely.bedwars.api.Team team) {
        return this.i.contains(team.getInternal());
    }
    
    @Override
    public void setBedLocation(final de.marcely.bedwars.api.Team team, final XYZD xyzd) {
        this.a(xyzd, team.getInternal());
    }
    
    @Override
    public XYZYP getSpawnLocation(final de.marcely.bedwars.api.Team team) {
        return this.z.containsKey(team.getInternal()) ? this.z.get(team.getInternal()) : null;
    }
    
    @Override
    public void setSpawnLocation(final de.marcely.bedwars.api.Team team, final XYZYP xyzyp) {
        this.a(xyzyp, team.getInternal());
    }
    
    @Override
    public boolean isBedDestroyed(final de.marcely.bedwars.api.Team team) {
        return this.B.containsKey(team.getInternal());
    }
    
    @Override
    public void _0setBedDestroyed(final de.marcely.bedwars.api.Team team, final boolean b) {
        if (b) {
            if (!this.B.containsKey(team.getInternal())) {
                this.B.put(team.getInternal(), System.currentTimeMillis());
            }
        }
        else if (this.B.containsKey(team.getInternal())) {
            this.B.remove(team.getInternal());
        }
    }
    
    @Override
    public void _0reset() {
        this.reset();
    }
    
    @Override
    public XYZD getBedLocation(final de.marcely.bedwars.api.Team team) {
        return this.y.containsKey(team.getInternal()) ? this.y.get(team.getInternal()) : null;
    }
    
    @Override
    public List<de.marcely.bedwars.api.Team> GetEnabledTeams() {
        final ArrayList<de.marcely.bedwars.api.Team> list = new ArrayList<de.marcely.bedwars.api.Team>();
        final Iterator<Team> iterator = this.i.iterator();
        while (iterator.hasNext()) {
            list.add(de.marcely.bedwars.api.Team.fromInternal(iterator.next()));
        }
        return list;
    }
    
    public Map<Team, i> f() {
        return this.A;
    }
}
