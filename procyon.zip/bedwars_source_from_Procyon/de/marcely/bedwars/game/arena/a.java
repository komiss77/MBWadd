// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import javax.annotation.Nullable;
import org.bukkit.Location;
import java.util.HashMap;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.game.Team;
import java.util.Map;

public class a
{
    private final Arena arena;
    private boolean enabled;
    private final Map<Team, XYZYP> w;
    
    public a(final Arena arena) {
        this.enabled = false;
        this.w = new HashMap<Team, XYZYP>();
        this.arena = arena;
    }
    
    @Nullable
    public Location a(final Team team) {
        return this.w.get(team).toBukkit(this.arena.getWorld());
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    public Map<Team, XYZYP> c() {
        return this.w;
    }
}
