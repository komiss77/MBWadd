// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

import de.marcely.bedwars.api.TeamColors;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import org.bukkit.enchantments.Enchantment;
import de.marcely.bedwars.game.LobbyItem;
import de.marcely.bedwars.be;
import de.marcely.bedwars.game.shop.upgrade.Upgrade;
import de.marcely.bedwars.game.shop.upgrade.UpgradeType;
import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.dw;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.CopyOption;
import java.io.File;
import de.marcely.bedwars.util.r;
import org.bukkit.block.Block;
import de.marcely.bedwars.dD;
import de.marcely.bedwars.api.event.ArenaDeleteEvent;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.entity.Firework;
import org.bukkit.OfflinePlayer;
import de.marcely.bedwars.cW;
import de.marcely.bedwars.cT;
import de.marcely.bedwars.api.event.RoundEndEvent;
import de.marcely.bedwars.cz;
import de.marcely.bedwars.df;
import de.marcely.bedwars.dg;
import de.marcely.bedwars.api.event.BedBreakEvent;
import de.marcely.bedwars.api.event.PlayerRoundDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import de.marcely.bedwars.api.event.PlayerRoundRespawnEvent;
import de.marcely.bedwars.game.shop.ShopProduct;
import org.bukkit.Chunk;
import de.marcely.bedwars.api.event.RoundStartEvent;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.bq;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Item;
import de.marcely.bedwars.api.event.DropEvent;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;
import de.marcely.bedwars.api.event.ArenaRegenerationStartEvent;
import de.marcely.bedwars.api.event.PlayerQuitArenaEvent;
import de.marcely.bedwars.api.event.TeamEliminateEvent;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.aD;
import de.marcely.bedwars.aV;
import java.util.Collections;
import de.marcely.bedwars.ae;
import de.marcely.bedwars.x;
import java.util.Arrays;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.Language;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.GameMode;
import de.marcely.bedwars.Permission;
import de.marcely.bedwars.api.event.PlayerJoinArenaEvent;
import de.marcely.bedwars.api.AddPlayerFail;
import de.marcely.bedwars.cA;
import javax.annotation.Nullable;
import de.marcely.bedwars.y;
import de.marcely.bedwars.aX;
import org.bukkit.event.Event;
import de.marcely.bedwars.api.event.ArenaStatusUpdateEvent;
import org.bukkit.command.CommandSender;
import org.bukkit.Bukkit;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.u;
import de.marcely.bedwars.t;
import de.marcely.bedwars.z;
import de.marcely.bedwars.v;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.j;
import de.marcely.bedwars.w;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.config.ConfigValue;
import java.util.Collection;
import org.bukkit.ChatColor;
import java.util.Iterator;
import java.util.ArrayList;
import org.bukkit.Material;
import java.util.HashMap;
import de.marcely.bedwars.by;
import de.marcely.bedwars.game.shop.BuyGroup;
import de.marcely.bedwars.game.shop.ShopItem;
import de.marcely.bedwars.dy;
import de.marcely.bedwars.game.Team;
import org.bukkit.entity.Player;
import de.marcely.bedwars.cJ;
import java.util.Map;
import java.util.List;
import de.marcely.bedwars.game.DropType;
import de.marcely.configmanager2.MultiKeyMap;
import de.marcely.bedwars.game.location.XYZYP;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Location;
import org.bukkit.World;
import de.marcely.bedwars.game.location.XYZ;

public class Arena implements de.marcely.bedwars.api.Arena
{
    public XYZ a;
    public XYZ b;
    private String name;
    private de.marcely.bedwars.game.arena.b a;
    private h b;
    private int e;
    private World world;
    public String C;
    private Location b;
    public String D;
    private ItemStack icon;
    private ArenaStatus b;
    private XYZYP a;
    private final de.marcely.bedwars.game.arena.a a;
    private boolean B;
    private RegenerationType b;
    public de.marcely.bedwars.game.regeneration.a a;
    public e a;
    public int N;
    public boolean C;
    public c a;
    private MultiKeyMap<DropType, XYZ> a;
    public List<Location> H;
    public Map<de.marcely.bedwars.holographic.c<cJ>, DropType> k;
    public Map<Player, Team> l;
    public Map<Player, Long> m;
    private List<Flag> flags;
    private long f;
    public Map<String, Player> n;
    public Map<String, Player> o;
    public boolean D;
    public List<a> I;
    private List<d> J;
    public Map<Player, de.marcely.bedwars.game.a> p;
    public Map<Team, de.marcely.bedwars.holographic.c<cJ>> q;
    public Map<Team, i> r;
    public Map<Team, List<Player>> s;
    public Map<DropType, List<b>> t;
    private List<String> K;
    public List<String> L;
    private List<dy> M;
    public Map<Player, List<ShopItem>> u;
    public Map<Team, Map<BuyGroup, Integer>> v;
    public List<by> N;
    public boolean E;
    private HashMap<Player, List<Player>> e;
    private static /* synthetic */ int[] j;
    
    public Arena() {
        this.a = new XYZ();
        this.b = new XYZ();
        this.a = new de.marcely.bedwars.game.arena.b(this);
        this.b = new h(this);
        this.C = null;
        this.b = new Location((World)null, 0.0, 0.0, 0.0);
        this.D = null;
        this.icon = new ItemStack(Material.CLAY_BALL, 1);
        this.b = ArenaStatus.d;
        this.a = null;
        this.a = new de.marcely.bedwars.game.arena.a(this);
        this.B = true;
        this.b = RegenerationType.c;
        this.a = null;
        this.N = 0;
        this.C = false;
        this.a = new MultiKeyMap<DropType, XYZ>();
        this.H = new ArrayList<Location>();
        this.k = new HashMap<de.marcely.bedwars.holographic.c<cJ>, DropType>();
        this.l = new HashMap<Player, Team>();
        this.m = new HashMap<Player, Long>();
        this.flags = de.marcely.bedwars.game.arena.f.a.p();
        this.f = 0L;
        this.n = new HashMap<String, Player>();
        this.o = new HashMap<String, Player>();
        this.D = true;
        this.I = new ArrayList<a>();
        this.J = new ArrayList<d>();
        this.p = new HashMap<Player, de.marcely.bedwars.game.a>();
        this.q = new HashMap<Team, de.marcely.bedwars.holographic.c<cJ>>();
        this.r = new HashMap<Team, i>();
        this.s = new HashMap<Team, List<Player>>();
        this.t = new HashMap<DropType, List<b>>();
        this.K = new ArrayList<String>();
        this.L = new ArrayList<String>();
        this.M = new ArrayList<dy>();
        this.u = new HashMap<Player, List<ShopItem>>();
        this.v = new HashMap<Team, Map<BuyGroup, Integer>>();
        this.N = new ArrayList<by>();
        this.E = false;
        this.e = new HashMap<Player, List<Player>>();
        (this.a = new c(this)).setEnabled(true);
    }
    
    public int j() {
        return this.l.size();
    }
    
    @Override
    public int getTeamPlayers() {
        return this.e;
    }
    
    public ArenaStatus b() {
        return this.b;
    }
    
    public h a() {
        return this.b;
    }
    
    public MultiKeyMap<DropType, XYZ> a() {
        return this.a;
    }
    
    public List<XYZ> a(final DropType obj) {
        final ArrayList<XYZ> list = new ArrayList<XYZ>();
        for (final Map.Entry<DropType, XYZ> entry : this.a.entrySet()) {
            if (entry.getKey().equals(obj)) {
                list.add(entry.getValue());
            }
        }
        return list;
    }
    
    @Override
    public ItemStack getIcon() {
        final ItemStack itemStack = (this.icon != null) ? this.icon.clone() : new ItemStack(Material.CLAY_BALL);
        de.marcely.bedwars.util.i.a(itemStack, ChatColor.WHITE + this.getDisplayName());
        return itemStack;
    }
    
    public String n() {
        return (String)this.a(de.marcely.bedwars.game.arena.f.a.b).getValue();
    }
    
    public String[] b() {
        return this.n().split(", ");
    }
    
    public Map<Player, Team> b() {
        return this.l;
    }
    
    @Override
    public List<Player> getPlayers() {
        return new ArrayList<Player>(this.l.keySet());
    }
    
    @Override
    public int getMinPlayers() {
        return (int)this.a(de.marcely.bedwars.game.arena.f.a.c).getValue();
    }
    
    public int k() {
        if (this.a() == RegenerationType.e && !this.D && this.I.size() == 1) {
            return this.I.get(0).arena.getMinPlayers();
        }
        return this.getMinPlayers();
    }
    
    public int l() {
        if (this.a() == RegenerationType.e && !this.D && this.I.size() == 1) {
            return this.I.get(0).arena.getTeamPlayers();
        }
        return this.getTeamPlayers();
    }
    
    @Override
    public int getMaxPlayers() {
        return (this.a() != RegenerationType.e) ? (this.getTeamPlayers() * this.a().r().size()) : this.getTeamPlayers();
    }
    
    public RegenerationType a() {
        return this.b;
    }
    
    public double a() {
        if (this.b == RegenerationType.c) {
            return (this.getPosMax().getX() - this.getPosMin().getX()) * (this.getPosMax().getY() - this.getPosMin().getY()) * (this.getPosMax().getZ() - this.getPosMin().getZ()) / (1000 * ConfigValue.regeneration_speed_ms);
        }
        if (this.b == RegenerationType.d) {
            return (this.world != null) ? (this.world.getLoadedChunks().length / 250) : Double.NaN;
        }
        return Double.NaN;
    }
    
    public void a(final XYZ a) {
        this.a = a;
    }
    
    public void b(final XYZ b) {
        this.b = b;
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
        if (MBedwars.d()) {
            this.a(new w(this, name));
        }
        de.marcely.bedwars.util.s.c(this, d.a.g);
    }
    
    public void a(final RegenerationType b) {
        this.b = b;
    }
    
    @Override
    public void setTeamPlayers(final int e) {
        this.e = e;
        if (MBedwars.d()) {
            this.a(new v(this, e * this.a().r().size()));
            this.a(new z(this, this.a().r().size(), e));
        }
    }
    
    @Override
    public void setWorld(final World world) {
        this.world = world;
        this.C = world.getName();
    }
    
    @Override
    public void setLobby(final Location b) {
        this.b = b;
        this.D = ((b != null && b.getWorld() != null) ? b.getWorld().getName() : null);
    }
    
    public void setIcon(final ItemStack icon) {
        this.icon = icon;
        de.marcely.bedwars.util.s.c(this, d.a.f);
        if (MBedwars.d()) {
            this.a(new t(this, icon));
        }
    }
    
    public void v(final String value) {
        this.a(de.marcely.bedwars.game.arena.f.a.b).setValue(value);
        if (MBedwars.d()) {
            this.a(new u(this, value));
        }
    }
    
    public boolean A() {
        return this.f + 180000L > System.currentTimeMillis();
    }
    
    public void a(final ArenaStatus arenaStatus) {
        this.a(arenaStatus, false);
    }
    
    public void a(final ArenaStatus b, final boolean b2) {
        if (Thread.currentThread() != de.marcely.bedwars.util.s.a) {
            new Synchronizer(true) {
                @Override
                public void run() {
                    ((Arena)b).a(b, b2);
                }
            };
            return;
        }
        if (!b2) {
            if (this.b == ArenaStatus.f && b != ArenaStatus.f) {
                final Iterator<de.marcely.bedwars.holographic.c<cJ>> iterator = this.k.keySet().iterator();
                while (iterator.hasNext()) {
                    iterator.next().remove();
                }
                final Iterator<de.marcely.bedwars.holographic.c<cJ>> iterator2 = this.q.values().iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().remove();
                }
                this.k.clear();
                this.q.clear();
                this.K.clear();
                this.u.clear();
            }
            if (b == ArenaStatus.f) {
                for (final de.marcely.bedwars.game.a a : this.p.values()) {
                    a.setAnimated(false);
                    a.refresh();
                }
            }
            if (b == ArenaStatus.g && MBedwars.a().isTaskable()) {
                if (ConfigValue.restart_oncearenaend && (this.b == ArenaStatus.f || this.b == ArenaStatus.h)) {
                    Bukkit.shutdown();
                }
                else {
                    this.b((CommandSender)null);
                }
            }
            else if (this.B()) {
                this.a.cancel();
            }
            if (b == ArenaStatus.d) {
                this.n.clear();
            }
        }
        if (this.b != b) {
            Bukkit.getPluginManager().callEvent((Event)new ArenaStatusUpdateEvent(this, de.marcely.bedwars.api.ArenaStatus.fromNMS(this.b), de.marcely.bedwars.api.ArenaStatus.fromNMS(b)));
        }
        this.b = b;
        de.marcely.bedwars.util.s.c(this, d.a.e);
        de.marcely.bedwars.util.s.aj();
        de.marcely.bedwars.util.s.g(this);
        aX.t();
        if (MBedwars.d()) {
            this.a(new y(this, b));
        }
    }
    
    @Override
    public void setMinPlayers(final int i) {
        this.a(de.marcely.bedwars.game.arena.f.a.c).setValue(i);
    }
    
    @Nullable
    public AddPlayerFail a(final Player player, final Team team) {
        return this.a(player, team, false);
    }
    
    @Nullable
    public AddPlayerFail a(final Player player, final Team team, final boolean b) {
        if (de.marcely.bedwars.util.s.a(player) != null || cA.E.containsKey(player)) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.b)));
            return AddPlayerFail.b;
        }
        if (this.j() >= this.getMaxPlayers()) {
            if (!de.marcely.bedwars.util.s.hasPermission((CommandSender)player, Permission.JoinFull) || this.a(Permission.JoinFull) == null) {
                Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.a)));
                return AddPlayerFail.a;
            }
            this.a(KickReason.c, this.a(Permission.JoinFull));
        }
        if (this.a() == RegenerationType.e && !ConfigValue.arenavoting_enabled && !b) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.d)));
            return AddPlayerFail.d;
        }
        if (this.a() != RegenerationType.e && ConfigValue.arenavoting_enabled && !b) {
            Bukkit.getPluginManager().callEvent((Event)new PlayerJoinArenaEvent(player, this, de.marcely.bedwars.api.AddPlayerFail.fromInternal(AddPlayerFail.c)));
            return AddPlayerFail.c;
        }
        final PlayerJoinArenaEvent playerJoinArenaEvent = new PlayerJoinArenaEvent(player, this, null);
        Bukkit.getPluginManager().callEvent((Event)playerJoinArenaEvent);
        if (playerJoinArenaEvent.isCancelled()) {
            return AddPlayerFail.e;
        }
        player.closeInventory();
        de.marcely.bedwars.util.s.b.A(player);
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
        player.setGameMode(GameMode.ADVENTURE);
        player.getInventory().setHeldItemSlot(4);
        new BukkitRunnable() {
            public void run() {
                Arena.this.a(de.marcely.bedwars.message.b.a(Language.JoinMessage).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("players", new StringBuilder().append(Arena.this.getPlayers().size() + 1).toString()).a("maxplayers", new StringBuilder().append(Arena.this.getMaxPlayers()).toString()).a("arena", Arena.this.getDisplayName()));
                if (ConfigValue.player_color) {
                    for (final Team team : Arena.this.a().r()) {
                        Version.a().a(Arena.this.a(team), Arena.this.getPlayers(), team.getChatColor());
                    }
                }
            }
        }.runTaskLater((Plugin)MBedwars.a, 10L);
        if (ConfigValue.tab_removenonplayers) {
            this.k(player);
        }
        this.l.put(player, team);
        this.m.put(player, System.currentTimeMillis());
        de.marcely.bedwars.util.s.l.put(player, this);
        if (this.a != null) {
            this.a.getPlayers().add(player);
        }
        this.d(player, team);
        this.a(player, this.getLobby().clone());
        this.c(player, true);
        this.C();
        if (ConfigValue.tab_removenonplayers) {
            final Iterator<Player> iterator = this.getPlayers().iterator();
            while (iterator.hasNext()) {
                this.l(iterator.next());
            }
        }
        final de.marcely.bedwars.game.a a = new de.marcely.bedwars.game.a(Arrays.asList(player));
        a.setAnimated(true);
        if (ConfigValue.actionbar_enabled) {
            a.run();
        }
        this.p.put(player, a);
        aX.t();
        if (MBedwars.d()) {
            this.a(new x(this, this.getPlayers().size()));
        }
        if (this.j() == this.k()) {
            this.a = this.a(this.m());
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Start));
            this.w("");
            final Iterator<Player> iterator2 = this.getPlayers().iterator();
            while (iterator2.hasNext()) {
                this.p(iterator2.next());
            }
        }
        else {
            this.p(player);
            if (this.j() < this.k()) {
                this.c(de.marcely.bedwars.message.b.a(Language.Lobby_Waiting).a("amount", new StringBuilder().append(this.k() - this.getPlayers().size()).toString()).f((CommandSender)player), 300);
            }
        }
        if (this.j() == 1 && this.a() == RegenerationType.e) {
            this.D = true;
            this.E();
            if (this.D && this.a().r().size() >= 1) {
                this.a().r().clear();
            }
        }
        de.marcely.bedwars.util.s.c(this, d.a.c);
        this.a.E();
        new BukkitRunnable() {
            double y = 0.1;
            boolean K = true;
            
            public void run() {
                if (this.K) {
                    if (this.y < 1.7) {
                        this.y += Math.sin(this.y / 1.7);
                    }
                    else {
                        this.K = false;
                    }
                }
                else if (this.y > 0.1) {
                    this.y -= this.y / 5.0;
                }
                else {
                    this.cancel();
                }
                for (final Location location : de.marcely.bedwars.util.s.b(player.getLocation().add(0.0, this.y, 0.0), 0.6, 5)) {
                    ae.b.a(location.getWorld(), location, 1, 1, 0.0f, 1.0f, 1.0f, 1.0f, 0, 10);
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 2L, 3L);
        de.marcely.bedwars.util.s.g(this);
        return null;
    }
    
    public Player a(final Permission permission) {
        final ArrayList<Player> list = new ArrayList<Player>();
        list.addAll((Collection<?>)this.getPlayers());
        Collections.rotate(list, list.size());
        for (final Player player : list) {
            if (!de.marcely.bedwars.util.s.hasPermission((CommandSender)player, permission)) {
                return player;
            }
        }
        return null;
    }
    
    public boolean a(final KickReason kickReason, final Player player) {
        if (!this.l.containsKey(player)) {
            return false;
        }
        final Team a = this.a(player);
        if (this.a() == RegenerationType.e) {
            final a a2 = this.a(player);
            if (a2 != null) {
                a2.P.remove(player);
                final Iterator<Player> iterator = new ArrayList<Player>(aV.h.get(this)).iterator();
                while (iterator.hasNext()) {
                    aV.b(this, iterator.next());
                }
            }
        }
        if (this.b() == ArenaStatus.f) {
            aD.f.remove(player);
        }
        if (cA.E.containsKey(player)) {
            cA.a(player, cD.e);
        }
        for (final Player player2 : this.getPlayers()) {
            player2.showPlayer(player);
            player.showPlayer(player2);
        }
        final List<Player> spectators = this.getSpectators();
        final Iterator<Player> iterator3 = spectators.iterator();
        while (iterator3.hasNext()) {
            Version.a().a(iterator3.next(), Arrays.asList(player), player.getGameMode());
        }
        if (MBedwars.a().isTaskable()) {
            new BukkitRunnable() {
                public void run() {
                    final Iterator<Player> iterator = spectators.iterator();
                    while (iterator.hasNext()) {
                        Version.a().a(iterator.next(), Arrays.asList(player), player.getGameMode());
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 20L);
        }
        final List<Team> a3 = this.a(new Player[] { player });
        if (this.b() == ArenaStatus.f) {
            if (this.b.a().contains(a) && System.currentTimeMillis() <= this.b.a(a) + 10000L) {
                de.marcely.bedwars.util.s.a(player, Achievement.A);
            }
            if (kickReason == KickReason.d) {
                if (ConfigValue.spectator_autojoin && a3.size() > 1) {
                    cA.a(player, this, SpectateReason.LOOSE);
                    if (ConfigValue.spectator_joinmessage) {
                        de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Spectator_HowToQuit));
                    }
                }
            }
            else {
                this.a(player, kickReason);
                this.b(player, true);
            }
            if (this.a(a).size() == 0) {
                this.b.a(a, true);
                this.b.a(a).toBukkit(this.getWorld()).getBlock().setType(Material.AIR);
                if (this.q.containsKey(a)) {
                    this.q.get(a).remove();
                    this.q.remove(a);
                }
                this.a(Sound.TEAM_ELIMINATED);
                Bukkit.getPluginManager().callEvent((Event)new TeamEliminateEvent(this, de.marcely.bedwars.api.Team.fromInternal(a), player, a3.size() <= 1));
            }
            if (a3.size() == 1) {
                this.b((Team)a3.get(0));
            }
            else if (a3.size() == 0) {
                this.b((Team)null);
            }
        }
        else if (this.b() == ArenaStatus.e) {
            if (this.a != null && this.l.size() <= this.k()) {
                this.a.stop();
                this.a = null;
                for (final Player player3 : this.getPlayers()) {
                    player3.setLevel(0);
                    player3.setExp(0.0f);
                }
                this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Stop));
            }
            this.a(player, kickReason);
            final Iterator<Player> iterator5 = this.getPlayers().iterator();
            while (iterator5.hasNext()) {
                this.p(iterator5.next());
            }
        }
        else if (this.b() == ArenaStatus.h) {
            this.a(player, kickReason);
            if (this.getPlayers().size() == 0) {
                if (this.a != null) {
                    this.a.stop();
                    this.a = null;
                }
                this.a(ArenaStatus.g);
            }
        }
        if (kickReason != KickReason.h) {
            for (int i = 0; i < 6; ++i) {
                ae.c.a(player.getWorld(), player.getLocation().add(de.marcely.bedwars.util.s.RAND.nextInt(6) / 10.0, de.marcely.bedwars.util.s.RAND.nextInt(8) / 10.0 * (de.marcely.bedwars.util.s.RAND.nextInt(2) + 1), de.marcely.bedwars.util.s.RAND.nextInt(6) / 10.0), de.marcely.bedwars.util.s.RAND.nextInt(10));
            }
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 1.4, 0.4), 0);
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 0.6, 0.4), 0);
            ae.a.a(player.getWorld(), player.getLocation().add(0.4, 0.1, 0.4), 0);
            Bukkit.getPluginManager().callEvent((Event)new PlayerQuitArenaEvent(player, this, de.marcely.bedwars.api.KickReason.fromInternal(kickReason), de.marcely.bedwars.api.Team.fromInternal(a)));
        }
        return true;
    }
    
    private void a(final Player player, final KickReason kickReason) {
        if (ConfigValue.player_color && this.l.get(player) != null) {
            Version.a().a(player, this.getPlayers(), this.l.get(player).getChatColor());
            Version.a().a(player, this.getSpectators(), this.l.get(player).getChatColor());
        }
        player.setFireTicks(0);
        player.setFallDistance(0.0f);
        this.c(player, false);
        this.a(player, (Team)null, false);
        this.l.remove(player);
        if (this.b() == ArenaStatus.e) {
            this.m.remove(player);
        }
        de.marcely.bedwars.util.s.l.remove(player);
        this.C();
        this.p.get(player).stop();
        this.p.remove(player);
        this.a(de.marcely.bedwars.message.b.a(Language.LeaveMessage).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("players", new StringBuilder().append(this.getPlayers().size()).toString()).a("maxplayers", new StringBuilder().append(this.getMaxPlayers()).toString()).a("arena", this.getDisplayName()));
        if (this.a != null) {
            this.a.getPlayers().remove(player);
        }
        c.t(player);
        aX.t();
        de.marcely.bedwars.util.s.g(this);
        if (MBedwars.d()) {
            this.a(new x(this, this.getPlayers().size()));
        }
        if (ConfigValue.player_color) {
            for (final Map.Entry<Player, Team> entry : this.l.entrySet()) {
                if (entry.getValue() != null) {
                    Version.a().a(entry.getKey(), Arrays.asList(player), entry.getValue().getChatColor());
                }
            }
        }
        if (ConfigValue.tab_removenonplayers) {
            this.m(player);
            final Iterator<Player> iterator2 = this.getPlayers().iterator();
            while (iterator2.hasNext()) {
                this.l(iterator2.next());
            }
        }
        de.marcely.bedwars.util.s.c(this, d.a.d);
        this.a.E();
        if (kickReason != KickReason.h) {
            de.marcely.bedwars.util.s.b(player, this);
            de.marcely.bedwars.util.s.b.z(player);
        }
    }
    
    @Override
    public void broadcast(final String s) {
        final Iterator<Player> iterator = this.getPlayers().iterator();
        while (iterator.hasNext()) {
            iterator.next().sendMessage(s);
        }
        final Iterator<Player> iterator2 = this.getSpectators().iterator();
        while (iterator2.hasNext()) {
            iterator2.next().sendMessage(s);
        }
    }
    
    public void a(final Language language) {
        this.a(de.marcely.bedwars.message.b.a(language));
    }
    
    public void a(final de.marcely.bedwars.message.b b) {
        de.marcely.bedwars.util.t.c(b);
        final Iterator<Player> iterator = this.getPlayers().iterator();
        while (iterator.hasNext()) {
            de.marcely.bedwars.util.s.a((CommandSender)iterator.next(), b, false);
        }
        final Iterator<Player> iterator2 = this.getSpectators().iterator();
        while (iterator2.hasNext()) {
            de.marcely.bedwars.util.s.a((CommandSender)iterator2.next(), b, false);
        }
        b.X();
    }
    
    public void a(final String s, final Player player) {
        player.sendMessage(s);
        this.broadcast(s);
    }
    
    @Deprecated
    @Override
    public void kickAllPlayers() {
        this.a(KickReason.c);
    }
    
    @Deprecated
    public void a(final KickReason kickReason) {
        final Iterator<Player> iterator = this.getPlayers().iterator();
        while (iterator.hasNext()) {
            this.a(kickReason, iterator.next());
        }
    }
    
    public boolean b(@Nullable final CommandSender commandSender) {
        if (this.getWorld() == null) {
            if (commandSender != null) {
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Problem_Arena_World).a("arena", commandSender.getName()));
                commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.FixProblemWith).f(commandSender)) + "/bw arena setworld " + this.getName());
            }
            return false;
        }
        final ArenaRegenerationStartEvent arenaRegenerationStartEvent = new ArenaRegenerationStartEvent(this, commandSender, ConfigValue.regeneration_speed_ms, ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.REGENERATE);
        Bukkit.getPluginManager().callEvent((Event)arenaRegenerationStartEvent);
        if (arenaRegenerationStartEvent.getResult() != ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.REGENERATE) {
            return arenaRegenerationStartEvent.getResult() == ArenaRegenerationStartEvent.ArenaRegenerationStartEventResult.DO_NOT_REGENERATE;
        }
        if (!this.B()) {
            this.a(ArenaStatus.g, true);
            this.a = this.a().a(this, commandSender);
            return this.a.run();
        }
        this.C();
        this.b(commandSender);
        return false;
    }
    
    public boolean B() {
        return this.a != null && this.a.isRunning();
    }
    
    private boolean C() {
        if (this.B()) {
            final boolean cancel = this.a.cancel();
            if (cancel) {
                this.a(ArenaStatus.d, true);
            }
            return cancel;
        }
        return false;
    }
    
    public void a(final DropType dropType, final XYZ xyz) {
        if (dropType.isDisabledForRound()) {
            return;
        }
        if (ConfigValue.itemspawner_effect && dropType.getEffect() != null) {
            for (int i = 0; i < de.marcely.bedwars.util.s.RAND.nextInt(2) + 2; ++i) {
                this.getWorld().playEffect(xyz.toBukkit(this.getWorld()).add(de.marcely.bedwars.util.s.RAND.nextDouble(), de.marcely.bedwars.util.s.RAND.nextDouble(), de.marcely.bedwars.util.s.RAND.nextDouble()), dropType.getEffect(), 0);
            }
        }
        if (ConfigValue.itemspawner_sound && dropType.getSound() != null) {
            this.getWorld().playSound(xyz.toBukkit(this.getWorld()), dropType.getSound(), 1.0f, 1.0f);
        }
        if (dropType.getActualItemstack() != null && dropType.getActualItemstack().getType() != null && dropType.getActualItemstack().getType() != Material.AIR) {
            final Location add = xyz.toBukkit(this.getWorld()).add(0.5, 0.0, 0.5);
            if (dropType.getSpawnRadius() > 0) {
                add.add((double)(de.marcely.bedwars.util.s.RAND.nextInt(dropType.getSpawnRadius() + 1) * 2 - dropType.getSpawnRadius()), 0.0, (double)(de.marcely.bedwars.util.s.RAND.nextInt(dropType.getSpawnRadius() + 1) * 2 - dropType.getSpawnRadius()));
            }
            final Item dropItem = this.getWorld().dropItem(add, dropType.getActualItemstack());
            if (dropType.isTranquil()) {
                de.marcely.bedwars.util.s.a((Entity)dropItem, new Vector(0.0, 0.3, 0.0));
            }
            final ItemStack a = de.marcely.bedwars.util.i.a(dropItem.getItemStack(), dropType.getChatColor() + dropType.getName());
            final Location a2 = this.a(add);
            final boolean b = a2 != null;
            int q = (int)((60.0 - dropType.getSpawnDelay() * 20.0) / 2.0);
            if (q < 1) {
                q = 1;
            }
            else if (q >= ConfigValue.performance.q) {
                q = ConfigValue.performance.q;
            }
            if (de.marcely.bedwars.util.s.RAND.nextInt(q) == 0) {
                int n = 0;
                final Iterator<Entity> iterator = de.marcely.bedwars.util.b.getNearbyEntities(add, 8.0, 8.0, 8.0).iterator();
                while (iterator.hasNext()) {
                    if (iterator.next().getType() == EntityType.DROPPED_ITEM) {
                        ++n;
                    }
                }
                if (n < 64 && b) {
                    this.H.remove(a2);
                }
                else if (n > 64 && !b) {
                    this.H.add(add);
                }
            }
            if (!dropType.isMerging() && !b) {
                final ItemMeta itemMeta = a.getItemMeta();
                itemMeta.setLore((List)Arrays.asList(new StringBuilder().append(de.marcely.bedwars.util.s.RAND.nextInt()).toString()));
                a.setItemMeta(itemMeta);
            }
            dropItem.setItemStack(a);
        }
        if (dropType.getCustomSpawner() != null) {
            dropType.getCustomSpawner().onDropEvent(new DropEvent(dropType, xyz.toBukkit(this.getWorld())));
        }
    }
    
    public void b(final DropType dropType) {
        final Iterator<XYZ> iterator = this.a(dropType).iterator();
        while (iterator.hasNext()) {
            this.a(dropType, iterator.next());
        }
    }
    
    public Location a(final Location location) {
        for (final Location location2 : this.H) {
            if (location2.distance(location) <= 8.0) {
                return location2;
            }
        }
        return null;
    }
    
    public int a(final Location location) {
        int n = 0;
        for (final Map.Entry<DropType, XYZ> entry : this.a.entrySet()) {
            if (entry.getValue().equals(XYZ.valueOf(location))) {
                this.a.remove(entry.getKey(), entry.getValue());
                ++n;
            }
        }
        return n;
    }
    
    public boolean D() {
        if (this.b() == ArenaStatus.e && this.j() >= this.k()) {
            this.H.clear();
            if (ConfigValue.teambalance) {
                g.c(this);
            }
            this.a(de.marcely.bedwars.message.b.a(Language.Start_Round));
            final Iterator<Player> iterator = this.getPlayers().iterator();
            while (iterator.hasNext()) {
                final Future<de.marcely.bedwars.game.stats.c> a = de.marcely.bedwars.game.stats.c.a(iterator.next());
                de.marcely.bedwars.util.s.a((Future<Object>)a, new Runnable() {
                    @Override
                    public void run() {
                        try {
                            final de.marcely.bedwars.game.stats.c c = a.get();
                            c.setRoundsPlayed(c.getRoundsPlayed() + 1);
                            c.save();
                            c.O();
                        }
                        catch (InterruptedException | ExecutionException ex) {
                            final Throwable t;
                            t.printStackTrace();
                        }
                    }
                });
            }
            this.r.clear();
            this.s.clear();
            this.t.clear();
            final Iterator<DropType> iterator2 = DropType.values().iterator();
            while (iterator2.hasNext()) {
                this.t.put(iterator2.next(), new ArrayList<b>());
            }
            for (final Team team : this.a().r()) {
                this.r.put(team, new i(this, team));
                this.s.put(team, new ArrayList<Player>());
                if (de.marcely.bedwars.util.s.X.size() >= 1) {
                    this.v.put(team, new HashMap<BuyGroup, Integer>());
                }
            }
            this.L.clear();
            Chunk[] loadedChunks;
            for (int length = (loadedChunks = this.getWorld().getLoadedChunks()).length, i = 0; i < length; ++i) {
                final Chunk chunk = loadedChunks[i];
                Entity[] entities;
                for (int length2 = (entities = chunk.getEntities()).length, j = 0; j < length2; ++j) {
                    final Entity entity = entities[j];
                    if (entity.getType() == EntityType.DROPPED_ITEM && this.isInside(entity.getLocation())) {
                        entity.remove();
                    }
                }
                this.L.add(String.valueOf(chunk.getX()) + "." + chunk.getZ());
            }
            this.u.clear();
            if (ConfigValue.timer_enabled) {
                this.N = ConfigValue.timer;
            }
            for (final Player player : this.getPlayers()) {
                this.u.put(player, new ArrayList<ShopItem>());
                if (this.a(player) == null) {
                    this.b(player, this.a().r().get(de.marcely.bedwars.util.s.RAND.nextInt(this.a().r().size())));
                    new bq("Player '" + player.getName() + "' isn't in a team?!").printStackTrace();
                }
                this.a(player, this.a().a(this.a(player)).toBukkit(this.getWorld()));
                de.marcely.bedwars.util.s.M(player);
                if (ConfigValue.giveitems_on_enabled) {
                    final Team a2 = this.a(player);
                    final Iterator<ItemStack> iterator5 = ConfigValue.giveitems_on_roundstart.iterator();
                    while (iterator5.hasNext()) {
                        player.getInventory().addItem(new ItemStack[] { de.marcely.bedwars.util.i.a(iterator5.next(), a2) });
                    }
                    for (final ItemStack itemStack : ConfigValue.giveitems_on_roundstart_armor) {
                        if (!de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(itemStack, a2), true)) {
                            de.marcely.bedwars.d.b("'" + itemStack.getType() + " isn't a valid armor (Config: giveitems-on-roundstart-armor)");
                        }
                    }
                }
            }
            for (final Map.Entry<DropType, XYZ> entry : this.a.entrySet()) {
                entry.getKey().setDisabledForRound(false);
                if (entry.getKey().getHologram() != null) {
                    final Location clone = entry.getValue().toBukkit(this.getWorld()).clone();
                    final Location add = clone.add(0.5, (double)((clone.clone().add(0.5, 1.0, 0.5).getBlock().getType() != Material.AIR) ? -1.0f : ConfigValue.spawnerhologram_height), 0.5);
                    final String[] split = de.marcely.bedwars.message.b.a(Language.ItemSpawner_Hologram_Title).f(null).split("\\\\n");
                    Arrays.fill(split, " ");
                    final de.marcely.bedwars.holographic.c<cJ> a3 = de.marcely.bedwars.holographic.c.a(cJ.class, add, new cF().c(false).b(false).a(split));
                    ((de.marcely.bedwars.holographic.b)a3.a().x().get(0).a()).a().a(de.marcely.bedwars.holographic.e.a.a, new ItemStack(entry.getKey().getHologram()));
                    a3.Q();
                    this.k.put(a3, entry.getKey());
                }
            }
            this.a().reset();
            final Iterator<Player> iterator8 = this.getPlayers().iterator();
            while (iterator8.hasNext()) {
                this.a.s(iterator8.next());
            }
            if (ConfigValue.bed_hologram_enabled) {
                for (final Team team2 : this.a().r()) {
                    if (ConfigValue.bed_hologram_message_alive.isEmpty()) {
                        break;
                    }
                    if (this.a().a(team2) == null || this.a(team2).size() < 1) {
                        continue;
                    }
                    final de.marcely.bedwars.holographic.c<cJ> a4 = de.marcely.bedwars.holographic.c.a(cJ.class, this.a().a(team2).toBukkit(this.getWorld()).clone().add(0.5, -0.5, 0.5), new cF().b(false).a(ConfigValue.bed_hologram_message_alive.replace("{teamcolor}", new StringBuilder().append(team2.getChatColor()).toString()).replace("{team}", team2.a((CommandSender)null, true)).replace("{heart}", ConfigValue.scoreboard_heart_alive).split("\\\\n")));
                    a4.a((byte)6);
                    a4.Q();
                    this.q.put(team2, a4);
                }
            }
            this.a(ArenaStatus.f);
            Bukkit.getPluginManager().callEvent((Event)new RoundStartEvent(this));
            de.marcely.bedwars.config.b.b(this);
            this.f = System.currentTimeMillis();
            if (ConfigValue.lobbybreak_enabled) {
                for (int k = -ConfigValue.lobbybreak_radius; k < ConfigValue.lobbybreak_radius; ++k) {
                    for (int l = -ConfigValue.lobbybreak_radius; l < ConfigValue.lobbybreak_radius; ++l) {
                        for (int n = -ConfigValue.lobbybreak_radius; n < ConfigValue.lobbybreak_radius; ++n) {
                            this.getLobby().clone().add((double)k, (double)l, (double)n).getBlock().setType(Material.AIR);
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    public boolean isColor(final String anotherString) {
        Language[] values;
        for (int length = (values = Language.values()).length, i = 0; i < length; ++i) {
            final Language language = values[i];
            if (language.name().startsWith("Color_") && language.getMessage(null).equalsIgnoreCase(anotherString)) {
                return true;
            }
        }
        return false;
    }
    
    private void j(final Player player) {
        new BukkitRunnable() {
            public void run() {
                if (Arena.this.b() != ArenaStatus.f || !Arena.this.getPlayers().contains(player)) {
                    return;
                }
                final Team a = Arena.this.a(player);
                if (ConfigValue.giveitems_on_enabled) {
                    for (final ItemStack itemStack : ConfigValue.giveitems_on_respawn) {
                        player.getInventory().addItem(new ItemStack[] { de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(itemStack, a), Arena.this.a(player, a, itemStack)) });
                    }
                    for (final ItemStack itemStack2 : ConfigValue.giveitems_on_respawn_armor) {
                        if (!de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(itemStack2, a), Arena.this.a(player, a, itemStack2)), true)) {
                            de.marcely.bedwars.d.b("'" + itemStack2.getType() + "' isn't a valid armor (Config: giveitems-on-respawn-armor)");
                        }
                    }
                }
                for (final ShopItem shopItem : Arena.this.u.get(player)) {
                    if (shopItem.isKeepOnDeath()) {
                        final Iterator<ShopProduct> iterator4 = shopItem.getProducts().iterator();
                        while (iterator4.hasNext()) {
                            iterator4.next().give(player, a, 1, Arena.this);
                        }
                    }
                }
                Bukkit.getPluginManager().callEvent((Event)new PlayerRoundRespawnEvent(player, Arena.this));
            }
        }.runTaskLater((Plugin)MBedwars.a, 20L);
    }
    
    public void a(final Player player, final PlayerRespawnEvent playerRespawnEvent) {
        if (this.b().F()) {
            playerRespawnEvent.setRespawnLocation(this.getLobby());
        }
        else if (this.b() == ArenaStatus.f) {
            player.setGameMode(GameMode.SURVIVAL);
            final Team a = this.a(player);
            if (a != null) {
                final PlayerRoundDeathEvent playerRoundDeathEvent = new PlayerRoundDeathEvent(playerRespawnEvent, this, this.b.d(a));
                Bukkit.getPluginManager().callEvent((Event)playerRoundDeathEvent);
                if (!playerRoundDeathEvent.willKick()) {
                    if (ConfigValue.death_spectate_enabled) {
                        if (!this.isInside(player.getLocation())) {
                            playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.b(this.a().a(a).toBukkit(this.world)));
                        }
                        else {
                            playerRespawnEvent.setRespawnLocation(player.getLocation());
                        }
                        this.a(player, a);
                        return;
                    }
                    playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.b(this.a().a(a).toBukkit(this.world)));
                    this.j(player);
                }
                else {
                    playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.k);
                    new BukkitRunnable() {
                        public void run() {
                            Arena.this.a(KickReason.d, player);
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 1L);
                }
            }
            else if (cA.E.containsKey(player)) {
                playerRespawnEvent.setRespawnLocation(this.a().a((Team)this.a().r().get(0)).toBukkit(this.getWorld()));
            }
            else {
                de.marcely.bedwars.util.s.b(player, this);
            }
        }
        else {
            playerRespawnEvent.setRespawnLocation(de.marcely.bedwars.util.s.k);
        }
    }
    
    private void a(final Player player, final Team team) {
        cA.a(player, this, SpectateReason.DEATH);
        final de.marcely.bedwars.game.a a = this.p.get(player);
        if (!a.isRunning()) {
            a.run();
        }
        a.setAnimated(false);
        new BukkitRunnable() {
            int time = ConfigValue.death_spectate_time;
            
            public void run() {
                if (!Arena.this.getPlayers().contains(player) || Arena.this.b() != ArenaStatus.f) {
                    this.cancel();
                }
                if (this.time > 0) {
                    a.setMessage(de.marcely.bedwars.message.b.a(Language.Death_Spectate_RespawnIn).a("time", new StringBuilder().append(this.time).toString()).f((CommandSender)player));
                    --this.time;
                }
                else {
                    Arena.this.z();
                    Arena.this.a(player, de.marcely.bedwars.util.s.b(Arena.this.a().a(team).toBukkit(Arena.this.world).clone().add(0.0, 0.1, 0.0)));
                    cA.a(player, cD.g);
                    de.marcely.bedwars.util.s.M(player);
                    Arena.this.j(player);
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 20L);
    }
    
    @Deprecated
    public boolean stop() {
        if (this.b() == ArenaStatus.f) {
            this.a(KickReason.c);
            this.a(ArenaStatus.e);
            return true;
        }
        return false;
    }
    
    public void b(final Player player, final Team team) {
        if (this.a(player) == team) {
            return;
        }
        this.d(player, team);
        this.p(player);
        de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_Changed).a("color", team.a((CommandSender)player)).a("colorcode", new StringBuilder().append(team.getChatColor()).toString()));
    }
    
    public void c(final Player player, final Team team) {
        if (this.b() != ArenaStatus.e || !this.a().r().contains(team)) {
            return;
        }
        final Team a = this.a(player);
        if (a != null && a == team) {
            Sound.LOBBY_SELECTTEAM_ALREADYSELECTED.play(player);
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_AlreadyInside).a("color", team.getName()).a("colorcode", new StringBuilder().append(team.getChatColor()).toString()));
            return;
        }
        if (this.a(team).size() >= this.l()) {
            Sound.LOBBY_SELECTTEAM_FULL.play(player);
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.ChangeTeam_Full).a("color", team.getName()).a("colorcode", new StringBuilder().append(team.getChatColor()).toString()));
            return;
        }
        this.b(player, team);
        Sound.LOBBY_SELECTTEAM_SELECT.play(player);
    }
    
    public void a(final Player player, final Location location, final Team team) {
        final BedBreakEvent bedBreakEvent = new BedBreakEvent(player, this, de.marcely.bedwars.api.Team.fromInternal(team), location);
        Bukkit.getPluginManager().callEvent((Event)bedBreakEvent);
        if (bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.Normally) {
            this.a().a(team, true);
        }
        if (bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.Normally || bedBreakEvent.getSolution() == BedBreakEvent.BedBreakEventSolution.BreakButDontChangeInTeamColors) {
            final de.marcely.bedwars.holographic.c<cJ> c = this.q.get(team);
            if (c != null) {
                c.remove();
                this.q.remove(team);
            }
            if (ConfigValue.bed_drops_amount >= 1) {
                final DropType a = DropType.a(Language.replaceLanguageTranslations(null, ConfigValue.bed_drops_type));
                if (a != null) {
                    de.marcely.bedwars.util.s.a(player, de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(new ItemStack(a.getActualItemstack().clone()), a.getChatColor() + a.a((CommandSender)null, true)), ConfigValue.bed_drops_amount));
                }
            }
            final Future<de.marcely.bedwars.game.stats.c> a2 = de.marcely.bedwars.game.stats.c.a(player);
            de.marcely.bedwars.util.s.a((Future<Object>)a2, new Runnable() {
                @Override
                public void run() {
                    try {
                        final de.marcely.bedwars.game.stats.c c = a2.get();
                        c.setBedsDestroyed(c.getBedsDestroyed() + 1);
                        c.save();
                        Arena.this.a.G();
                    }
                    catch (InterruptedException | ExecutionException ex) {
                        final Throwable t;
                        t.printStackTrace();
                    }
                }
            });
            for (final Player player2 : this.getPlayers()) {
                if (this.a(player2) != null && this.a(player2) == team) {
                    Sound.BED_DESTROY.play(player2);
                }
                else {
                    Sound.BED_DESTROY_ENEMY.play(player2);
                }
            }
            final String f = de.marcely.bedwars.message.b.a(Language.Destroyed_Bed).a("team", team.getName()).a("teamcolor", new StringBuilder().append(team.getChatColor()).toString()).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).f(null);
            final Iterator<Player> iterator2 = this.getPlayers().iterator();
            while (iterator2.hasNext()) {
                Version.a().b(f, iterator2.next());
            }
            final Iterator<Player> iterator3 = this.getSpectators().iterator();
            while (iterator3.hasNext()) {
                Version.a().b(f, iterator3.next());
            }
            final Iterator<dg> iterator4 = de.marcely.bedwars.util.s.b.a(dg.class).iterator();
            while (iterator4.hasNext()) {
                iterator4.next().a(player, df.c);
            }
            if (ConfigValue.beddestroy_message_enabled) {
                final Team a3 = this.a(player);
                this.a(de.marcely.bedwars.message.b.a(ConfigValue.beddestroy_message).b().c().a("team", team.getName()).a("teamcolor", new StringBuilder().append(team.getChatColor()).toString()).a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("playerteam", a3.getName()).a("playerteamcolor", new StringBuilder().append(a3.getChatColor()).toString()));
            }
        }
    }
    
    public void a(final Sound sound) {
        final Iterator<Player> iterator = this.getPlayers().iterator();
        while (iterator.hasNext()) {
            sound.play(iterator.next());
        }
        final Iterator<Player> iterator2 = this.getSpectators().iterator();
        while (iterator2.hasNext()) {
            sound.play(iterator2.next());
        }
    }
    
    public List<Team> a(final Player... a) {
        final ArrayList<Team> list = new ArrayList<Team>();
        final List<Player> list2 = Arrays.asList(a);
        for (final Player player : this.getPlayers()) {
            if (list2.contains(player)) {
                continue;
            }
            final Team a2 = this.a(player);
            if (list.contains(a2)) {
                continue;
            }
            list.add(a2);
        }
        return list;
    }
    
    public List<Player> a(final Team team) {
        final ArrayList<Player> list = new ArrayList<Player>();
        for (final Player player : this.getPlayers()) {
            if (this.a(player) != null && this.a(player) == team) {
                list.add(player);
            }
        }
        return list;
    }
    
    public boolean a(final Team team) {
        return this.a(team).size() == this.getPlayers().size();
    }
    
    public boolean a(final XYZ xyz, final Material type) {
        final Location bukkit = xyz.toBukkit(this.getWorld());
        if (this.isInside(bukkit)) {
            this.world.getBlockAt(bukkit).setType(type);
            return true;
        }
        return false;
    }
    
    public List<CrashMessage> getProblems() {
        final ArrayList<CrashMessage> list = new ArrayList<CrashMessage>();
        if (de.marcely.bedwars.util.s.k == null) {
            list.add(new CrashMessage(CrashMessage.CrashMessageType.missingGameDoneLocation));
        }
        if (!this.hasLobby()) {
            list.add(new CrashMessage(CrashMessage.CrashMessageType.missingLobbyLocation));
        }
        if (this.a() != RegenerationType.e) {
            for (final Team team : this.a().r()) {
                if (!this.a().d().containsKey(team) && !list.contains(new CrashMessage(CrashMessage.CrashMessageType.missingTeamSpawn))) {
                    list.add(new CrashMessage(CrashMessage.CrashMessageType.missingTeamSpawn, team.getName()));
                }
                if (!this.a().e().containsKey(team)) {
                    list.add(new CrashMessage(CrashMessage.CrashMessageType.missingBed, team.getName()));
                }
            }
        }
        return list;
    }
    
    public Team a(final Player player) {
        return this.l.get(player);
    }
    
    @Override
    public List<Player> getSpectators() {
        final ArrayList<Player> list = new ArrayList<Player>();
        for (final Map.Entry<Player, cz> entry : cA.E.entrySet()) {
            if (entry.getValue().getArena().equals(this)) {
                list.add(entry.getKey());
            }
        }
        return list;
    }
    
    public void d(final Player player, final Team team) {
        this.a(player, team, true);
    }
    
    public void a(final Player player, final Team team, final boolean b) {
        final Team a = this.a(player);
        this.l.put(player, team);
        if (ConfigValue.player_color) {
            if (team != null) {
                Version.a().a(this.a(team), this.getPlayers(), team.getChatColor());
            }
            else {
                Version.a().d(player, this.getPlayers());
            }
        }
        if (a != null) {
            this.a(a);
        }
        if (team != null) {
            this.a(team);
        }
        if (b) {
            this.a.E();
        }
    }
    
    private boolean a(final j j) {
        if (de.marcely.bedwars.util.s.af.contains(this)) {
            MBedwars.a.a(j);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean isInside(final Location location) {
        if (this.b == RegenerationType.c) {
            return location.getWorld().equals(this.getWorld()) && this.getPosMin().getX() < location.getX() && this.getPosMax().getX() > location.getX() && this.getPosMin().getY() < location.getY() && this.getPosMax().getY() > location.getY() && this.getPosMin().getZ() < location.getZ() && this.getPosMax().getZ() > location.getZ();
        }
        return location.getWorld().equals(this.getWorld());
    }
    
    public boolean a(final Chunk chunk) {
        return this.C.equals(chunk.getWorld().getName()) && (chunk.getX() >= (int)this.getPosMin().getX() >> 4 && chunk.getZ() >= (int)this.getPosMin().getZ() >> 4 && chunk.getX() <= (int)this.getPosMax().getX() >> 4 && chunk.getZ() <= (int)this.getPosMax().getZ() >> 4);
    }
    
    public void a(final de.marcely.bedwars.game.regeneration.c c) {
        if (this.b() != ArenaStatus.d) {
            c.a(de.marcely.bedwars.game.regeneration.c.a.e);
            return;
        }
        if (this.E) {
            c.a(de.marcely.bedwars.game.regeneration.c.a.d);
            return;
        }
        this.E = true;
        final de.marcely.bedwars.game.regeneration.a a = this.a().a(this);
        Label_0095: {
            if (a != null) {
                try {
                    a.b(new de.marcely.bedwars.game.regeneration.c() {
                        @Override
                        public void a(final c.a a) {
                            Arena.this.E = false;
                            c.a(a);
                        }
                        
                        @Override
                        public void a(final long n) {
                            c.a(n);
                        }
                    });
                    return;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    c.a(de.marcely.bedwars.game.regeneration.c.a.f);
                    break Label_0095;
                }
            }
            c.a(de.marcely.bedwars.game.regeneration.c.a.c);
        }
        this.E = false;
    }
    
    public void c(final CommandSender commandSender) {
        this.a(commandSender, true, false);
    }
    
    public void a(final CommandSender commandSender, final boolean b) {
        this.a(commandSender, b, false);
    }
    
    public void a(final CommandSender commandSender, final boolean b, final boolean b2) {
        this.a(new de.marcely.bedwars.game.regeneration.c() {
            boolean G = false;
            private static /* synthetic */ int[] k;
            
            @Override
            public void a(final c.a a) {
                switch (l()[a.ordinal()]) {
                    case 1: {
                        if (!b) {
                            break;
                        }
                        if (!b2) {
                            de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", Arena.this.getName()));
                            break;
                        }
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Arena_AutoSavedBlocks).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 2: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_Players).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 4: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_AlreadyRunning).a("arena", Arena.this.getName()));
                        break;
                    }
                    case 5: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_NotStopped).a("arena", Arena.this.getName()));
                        break;
                    }
                    default: {
                        de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Fail_Unkown).a("arena", Arena.this.getName()).a("type", a.name()));
                        break;
                    }
                }
            }
            
            @Override
            public void a(final long n) {
                if (n < 2000L || this.G) {
                    return;
                }
                this.G = true;
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.SaveBlocks_Start).a("arena", Arena.this.getName()).a("time", "~" + n / 1000L + "s"));
            }
            
            static /* synthetic */ int[] l() {
                final int[] k = Arena$3.k;
                if (k != null) {
                    return k;
                }
                final int[] i = new int[c.a.values().length];
                try {
                    i[c.a.d.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    i[c.a.e.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError2) {}
                try {
                    i[c.a.c.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError3) {}
                try {
                    i[c.a.b.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
                try {
                    i[c.a.a.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError5) {}
                try {
                    i[c.a.f.ordinal()] = 6;
                }
                catch (NoSuchFieldError noSuchFieldError6) {}
                return Arena$3.k = i;
            }
        });
    }
    
    @Override
    public void teleportHere(final Player player) {
        this.a(player, false);
    }
    
    public void a(final Player player, final boolean b) {
        if (this.a() != null) {
            player.teleport(this.a().toBukkit(this.getWorld()));
            return;
        }
        if (this.a().d().size() >= 1) {
            this.a(player, this.a().d().get(this.a().r().get(0)).toBukkit(this.getWorld()));
        }
        else if (this.hasLobby()) {
            this.a(player, this.getLobby());
        }
        else if (this.a() == RegenerationType.c) {
            final double n = this.getPosMax().getX() - this.getPosMin().getX();
            final double n2 = this.getPosMax().getZ() - this.getPosMin().getZ();
            final double n3 = this.getPosMin().getX() + n / 2.0;
            final double n4 = this.getPosMin().getZ() + n2 / 2.0;
            final Location location = new Location(this.getWorld(), n3, (double)(this.getWorld().getHighestBlockAt((int)n3, (int)n4).getY() + 2), n4);
            this.a(player, location);
            new BukkitRunnable() {
                public void run() {
                    if (location.getY() == 0.0) {
                        player.setAllowFlight(true);
                        player.setFlying(true);
                        Arena.this.a(player, location.add(0.0, (double)(Arena.this.getWorld().getMaxHeight() / 2), 0.0));
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 20L);
        }
        else if (this.a() == RegenerationType.d) {
            final Location clone = this.getWorld().getSpawnLocation().clone();
            this.a(player, clone);
            new BukkitRunnable() {
                public void run() {
                    if (clone.getY() == 0.0) {
                        player.setAllowFlight(true);
                        player.setFlying(true);
                    }
                }
            }.runTaskLater((Plugin)MBedwars.a, 10L);
        }
        if (b) {
            de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Teleport_Success).a("arena", this.getName()));
        }
    }
    
    public boolean b(@Nullable final Team team) {
        if (this.b() != ArenaStatus.f) {
            return false;
        }
        Bukkit.getPluginManager().callEvent((Event)new RoundEndEvent(this, de.marcely.bedwars.api.Team.fromInternal(team)));
        if (team != null) {
            this.a(de.marcely.bedwars.message.b.a(Language.Team_Won).a("color", team.getName()).a("colorcode", new StringBuilder().append(team.getChatColor()).toString()));
            for (final Player player : this.getPlayers()) {
                if (this.a(player) == team) {
                    this.b(player, false);
                    if (ConfigValue.prize_enabled) {
                        final double n = (de.marcely.bedwars.util.s.b.a(cT.v) && de.marcely.bedwars.util.s.b.get(cW.class).a != null) ? de.marcely.bedwars.util.s.b.get(cW.class).a.getBalance((OfflinePlayer)player) : 0.0;
                        final Iterator<String> iterator2 = ConfigValue.prize_commands.iterator();
                        while (iterator2.hasNext()) {
                            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), iterator2.next().replace("{name}", player.getName()));
                        }
                        if (de.marcely.bedwars.util.s.b.a(cT.v) && de.marcely.bedwars.util.s.b.get(cW.class).a != null) {
                            final double balance = de.marcely.bedwars.util.s.b.get(cW.class).a.getBalance((OfflinePlayer)player);
                            if (balance > n) {
                                de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Win_Money).a("number", new StringBuilder().append(balance - n).toString()));
                            }
                        }
                    }
                    if (this.A()) {
                        de.marcely.bedwars.util.s.a(player, Achievement.k);
                    }
                    if (this.b.a().contains(team)) {
                        de.marcely.bedwars.util.s.a(player, Achievement.z);
                    }
                    final Iterator<dg> iterator3 = de.marcely.bedwars.util.s.b.a(dg.class).iterator();
                    while (iterator3.hasNext()) {
                        iterator3.next().a(player, df.a);
                    }
                }
                else {
                    this.b(player, true);
                    final Iterator<dg> iterator4 = de.marcely.bedwars.util.s.b.a(dg.class).iterator();
                    while (iterator4.hasNext()) {
                        iterator4.next().a(player, df.b);
                    }
                }
            }
        }
        this.H.clear();
        aV.g.remove(this);
        aV.h.remove(this);
        this.B();
        if (this.getPlayers().size() >= 1) {
            this.a(ArenaStatus.h);
            for (final Player player2 : this.getPlayers()) {
                this.a(player2, this.getLobby());
                de.marcely.bedwars.util.s.M(player2);
            }
            for (final Player player3 : this.getSpectators()) {
                player3.setFallDistance(0.0f);
                de.marcely.bedwars.util.s.b(player3, this);
                c.t(player3);
            }
            for (final Player player4 : this.getPlayers()) {
                if (team != null) {
                    Version.a().a(de.marcely.bedwars.message.b.a(Language.EndLobby_Title).a("teamcolor", new StringBuilder().append(team.getChatColor()).toString()).a("team", team.getName(true)).f((CommandSender)player4), player4, ConfigValue.endlobby_countdown_time / 2 * 20);
                }
                else {
                    Version.a().a(de.marcely.bedwars.message.b.a(Language.EndLobby_Title_Nobody).f((CommandSender)player4), player4, ConfigValue.endlobby_countdown_time / 2 * 20);
                }
            }
            if (team != null) {
                Location[] array;
                for (int length = (array = new Location[] { this.getLobby().clone().add(1.0, 0.0, 0.0), this.getLobby().clone().add(-1.0, 0.0, 0.0), this.getLobby().clone().add(0.0, 0.0, 1.0), this.getLobby().clone().add(0.0, 0.0, -1.0) }).length, i = 0; i < length; ++i) {
                    final Firework firework = (Firework)this.getLobby().getWorld().spawnEntity(array[i], EntityType.FIREWORK);
                    final FireworkMeta fireworkMeta = firework.getFireworkMeta();
                    fireworkMeta.addEffect(de.marcely.bedwars.util.s.b());
                    firework.setFireworkMeta(fireworkMeta);
                }
            }
        }
        else {
            this.a(ArenaStatus.g);
        }
        return true;
    }
    
    public boolean c(@Nullable final CommandSender commandSender) {
        if (!de.marcely.bedwars.util.s.af.contains(this)) {
            return false;
        }
        final ArenaDeleteEvent arenaDeleteEvent = new ArenaDeleteEvent(this, commandSender);
        Bukkit.getPluginManager().callEvent((Event)arenaDeleteEvent);
        if (arenaDeleteEvent.isCancelled()) {
            return false;
        }
        if (MBedwars.d()) {
            MBedwars.a.a(new de.marcely.bedwars.s(this));
        }
        if (this.a != null && this.a.isRunning()) {
            this.a.cancel();
            this.a = null;
        }
        aV.g.remove(this);
        aV.h.remove(this);
        final Iterator<dy> iterator = this.M.iterator();
        while (iterator.hasNext()) {
            MBedwars.a.b(iterator.next());
        }
        this.M.clear();
        de.marcely.bedwars.util.s.c(this, d.a.b);
        de.marcely.bedwars.util.s.ag.remove(this);
        de.marcely.bedwars.util.s.af.remove(this);
        return true;
    }
    
    public List<Block> a(final Location location, final Material type, final int n) {
        final ArrayList<Block> list = new ArrayList<Block>();
        final int blockX = location.getBlockX();
        final int blockY = location.getBlockY();
        final int blockZ = location.getBlockZ();
        final int n2 = n * n;
        for (int i = blockX - n; i <= blockX + n; ++i) {
            for (int j = blockZ - n; j <= blockZ + n; ++j) {
                if ((blockX - i) * (blockX - i) + (blockZ - j) * (blockZ - j) <= n2) {
                    final Location location2 = new Location(location.getWorld(), (double)i, (double)blockY, (double)j);
                    final Block block = location2.getBlock();
                    if (block.getType() == Material.AIR && this.isInside(location2)) {
                        block.setType(type);
                        list.add(block);
                    }
                }
            }
        }
        return list;
    }
    
    public XYZ a() {
        return this.a.add((this.b.getX() - this.a.getX()) / 2.0, (this.b.getY() - this.a.getY()) / 2.0, (this.b.getZ() - this.a.getZ()) / 2.0);
    }
    
    public List<Chunk> m() {
        final int n = (int)this.a.getX() >> 4;
        final int n2 = (int)this.a.getZ() >> 4;
        final int n3 = (int)this.b.getX() >> 4;
        final int n4 = (int)this.b.getZ() >> 4;
        final ArrayList list = new ArrayList<Chunk>((n3 - n) * (n4 - n2));
        for (int i = n; i <= n3; ++i) {
            for (int j = n2; j <= n4; ++j) {
                list.add(this.world.getChunkAt(i, j));
            }
        }
        return (List<Chunk>)list;
    }
    
    public a a(final Player player) {
        for (final a a : this.I) {
            if (a.P.contains(player)) {
                return a;
            }
        }
        return null;
    }
    
    public boolean E() {
        if (!this.D || this.a() != RegenerationType.e) {
            return false;
        }
        boolean b = false;
        this.I.clear();
        final List<Arena> b2 = de.marcely.bedwars.util.s.b(this.getMaxPlayers());
        int size = this.I.size();
        for (final Arena arena : b2) {
            if (size == ConfigValue.arenavoting_maxarenas) {
                break;
            }
            boolean b3 = false;
            final Iterator<a> iterator2 = this.I.iterator();
            while (iterator2.hasNext()) {
                if (iterator2.next().arena.getDisplayName().equals(arena.getDisplayName())) {
                    b3 = true;
                    break;
                }
            }
            if (b3) {
                continue;
            }
            this.I.add(new a(arena));
            ++size;
            b = true;
        }
        return b;
    }
    
    public boolean f(final Player player) {
        if (this.getPlayers().size() >= this.k()) {
            Sound.LOBBY_FORCESTART.play(player);
            this.a.b(ConfigValue.forcestart_time, false);
            final Iterator<Player> iterator = this.getPlayers().iterator();
            while (iterator.hasNext()) {
                this.p(iterator.next());
            }
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", new StringBuilder().append(ConfigValue.forcestart_time).toString()));
            return true;
        }
        if (ConfigValue.forcestart_ignoreminplayers) {
            Sound.LOBBY_FORCESTART.play(player);
            this.a(de.marcely.bedwars.message.b.a(Language.Countdown_Changed).a("number", "0"));
            this.D();
            return true;
        }
        return false;
    }
    
    public Flag a(final String anObject) {
        for (final Flag flag : this.flags) {
            if (flag.getName().equals(anObject)) {
                return flag;
            }
            final f.a a = de.marcely.bedwars.game.arena.f.a.a(anObject);
            if (a != null) {
                return this.a(a);
            }
        }
        return null;
    }
    
    public Flag a(final f.a a) {
        for (final Flag flag : this.flags) {
            if (flag instanceof f && ((f)flag).a() == a) {
                return flag;
            }
        }
        return null;
    }
    
    public void a(final d d) {
        this.J.add(d);
    }
    
    public boolean a(final d d) {
        return this.J.remove(d);
    }
    
    public int m() {
        final Double a = de.marcely.bedwars.util.r.a(ConfigValue.lobby_countdownstart_calculation.replace("{teams}", new StringBuilder().append(this.a().r().size()).toString()).replace("{teamplayers}", new StringBuilder().append(this.getTeamPlayers()).toString()));
        if (a != null) {
            return (int)(double)a;
        }
        de.marcely.bedwars.d.b("Something in the config 'lobby-countdownstart-calculation' seems to be wrong! (Error)");
        return (this.getTeamPlayers() + this.a().r().size()) * 10 + 1;
    }
    
    public boolean a(final Location location) {
        if (!ConfigValue.notbuildableradius_enabled) {
            return false;
        }
        if (ConfigValue.notbuildableradius_teamspawn > 0) {
            final Iterator<Team> iterator = this.a().r().iterator();
            while (iterator.hasNext()) {
                final XYZYP a = this.a().a((Team)iterator.next());
                if (a != null && a.toBukkit(this.getWorld()).distance(location) <= ConfigValue.notbuildableradius_teamspawn) {
                    return true;
                }
            }
        }
        if (ConfigValue.notbuildableradius_itemspawner > 0) {
            final Iterator<XYZ> iterator2 = this.a.values().iterator();
            while (iterator2.hasNext()) {
                if (iterator2.next().toBukkit(this.getWorld()).distance(location) <= ConfigValue.notbuildableradius_itemspawner) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean f(final String name) {
        if (de.marcely.bedwars.util.s.a(name, this) != null) {
            return false;
        }
        final String name2 = this.getName();
        de.marcely.bedwars.config.b.b(this);
        try {
            if (new File("plugins/MBedwars/data/arenablocks/" + name2 + ".yml").exists()) {
                Files.move(new File("plugins/MBedwars/data/arenablocks/" + name2 + ".yml").toPath(), new File("plugins/MBedwars/data/arenablocks/" + name + ".yml").toPath(), new CopyOption[0]);
            }
            Files.move(new File("plugins/MBedwars/data/arenadata/" + name2 + ".cfg").toPath(), new File("plugins/MBedwars/data/arenadata/" + name + ".cfg").toPath(), new CopyOption[0]);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        this.setName(name);
        de.marcely.bedwars.config.b.b(this);
        return true;
    }
    
    @Deprecated
    public Arena a() {
        try {
            return (Arena)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public e a(final int n) {
        return new e(ConfigValue.performance.s, n, n, this.getPlayers());
    }
    
    public void w(final String message) {
        final Iterator<de.marcely.bedwars.game.a> iterator = this.p.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().setMessage(message);
        }
    }
    
    public void c(final String s, final int n) {
        final Iterator<de.marcely.bedwars.game.a> iterator = this.p.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().b(s, n);
        }
    }
    
    public List<de.marcely.bedwars.game.a> b(final Team team) {
        final ArrayList<de.marcely.bedwars.game.a> list = new ArrayList<de.marcely.bedwars.game.a>();
        for (final Map.Entry<Player, de.marcely.bedwars.game.a> entry : this.p.entrySet()) {
            final Team a = this.a((Player)entry.getKey());
            if (a != null && a == team) {
                list.add(entry.getValue());
            }
        }
        return list;
    }
    
    public void z() {
        final Iterator<Team> iterator = this.a().r().iterator();
        while (iterator.hasNext()) {
            this.a((Team)iterator.next());
        }
    }
    
    public void a(final Team team) {
        final List<de.marcely.bedwars.game.a> b = this.b(team);
        final String string = team.getChatColor() + team.getName(true) + " " + ChatColor.DARK_GRAY + "[" + ChatColor.GRAY + this.a(team).size() + "/" + this.getTeamPlayers() + ChatColor.DARK_GRAY + "]";
        final Iterator<de.marcely.bedwars.game.a> iterator = b.iterator();
        while (iterator.hasNext()) {
            iterator.next().setMessage(string);
        }
    }
    
    public List<Player> n() {
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<Player>();
        list.addAll(Version.a().getOnlinePlayers());
        list.removeAll(this.getPlayers());
        return (List<Player>)list;
    }
    
    public void b(final Block block) {
        this.K.add(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }
    
    public void c(final Block block) {
        this.K.remove(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }
    
    public boolean a(final Block block) {
        return this.K.contains(String.valueOf(block.getX()) + "." + block.getY() + "." + block.getZ());
    }
    
    public void A() {
        dw[] values;
        for (int length = (values = dw.values()).length, i = 0; i < length; ++i) {
            final dw dw = values[i];
            if (dw.R()) {
                try {
                    final dy dy = (dy)dw.getClazz().getDeclaredConstructor(Arena.class).newInstance(this);
                    this.M.add(dy);
                    MBedwars.a.a(dy);
                }
                catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        }
    }
    
    public int a(final UpgradeType upgradeType, final Team team) {
        final int a = this.r.get(team).a(upgradeType);
        if (a <= 0) {
            return 0;
        }
        final Upgrade a2 = de.marcely.bedwars.util.s.a(upgradeType, a);
        if (a2 != null) {
            return ((de.marcely.bedwars.flag.j)a2.getValue()).getValue();
        }
        return 0;
    }
    
    public double a(final UpgradeType upgradeType, final Team team) {
        final int a = this.r.get(team).a(upgradeType);
        if (a <= 0) {
            return 0.0;
        }
        final Upgrade a2 = de.marcely.bedwars.util.s.a(upgradeType, a);
        if (a2 != null) {
            return ((de.marcely.bedwars.flag.f)a2.getValue()).getValue();
        }
        return 0.0;
    }
    
    private void k(final Player key) {
        final ArrayList<Player> value = new ArrayList<Player>();
        for (final Player player : Version.a().getOnlinePlayers()) {
            if (player == key) {
                continue;
            }
            if (key.canSee(player)) {
                continue;
            }
            value.add(player);
        }
        this.e.put(key, value);
        this.l(key);
    }
    
    private void l(final Player player) {
        for (final Player player2 : Version.a().getOnlinePlayers()) {
            if (player2 == player) {
                continue;
            }
            if (player.canSee(player2) && !this.getPlayers().contains(player2)) {
                player.hidePlayer(player2);
                this.e.get(player).add(player2);
            }
            else {
                if (player.canSee(player2) || !this.getPlayers().contains(player2)) {
                    continue;
                }
                player.showPlayer(player2);
                this.e.get(player).remove(player2);
            }
        }
    }
    
    private void m(final Player player) {
        final Iterator<Player> iterator = this.e.get(player).iterator();
        while (iterator.hasNext()) {
            player.showPlayer((Player)iterator.next());
        }
        this.e.remove(player);
    }
    
    public List<String> o() {
        final ArrayList<String> list = new ArrayList<String>();
        final String[] b = this.b();
        String string = "";
        int n = 1;
        int n2 = 0;
        int n3 = 1;
        String[] array;
        for (int length = (array = b).length, i = 0; i < length; ++i) {
            final String str = array[i];
            if (n == 3) {
                list.add(String.valueOf((n2 == 0) ? new StringBuilder().append(ChatColor.DARK_AQUA).append(de.marcely.bedwars.message.b.a(Language.Info_MadeBy).f(null)).append(": ").toString() : " ") + ChatColor.AQUA + string);
                string = "";
                n = 0;
                ++n2;
            }
            string = String.valueOf(string) + str + ((n3 < b.length) ? ", " : "");
            ++n;
            ++n3;
        }
        list.add(String.valueOf((n2 == 0) ? new StringBuilder().append(ChatColor.DARK_AQUA).append(de.marcely.bedwars.message.b.a(Language.Info_MadeBy).f(null)).append(": ").toString() : " ") + ChatColor.AQUA + string);
        if (this.a() != RegenerationType.e) {
            list.add(new StringBuilder().append(ChatColor.AQUA).append(this.a().r().size()).append(ChatColor.DARK_AQUA).append("x").append(ChatColor.AQUA).append(this.getTeamPlayers()).toString());
        }
        list.add(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.STRIKETHROUGH).append("===================").toString());
        list.add(this.b().b(this));
        if (this.b() != ArenaStatus.g && this.b() != ArenaStatus.d) {
            list.add(new StringBuilder().append(ChatColor.YELLOW).append(this.getPlayers().size()).append(ChatColor.GOLD).append(" / ").append(ChatColor.YELLOW).append(this.getMaxPlayers()).toString());
        }
        return list;
    }
    
    public boolean a(final Arena arena) {
        if (this.a() == RegenerationType.d || arena.a() == RegenerationType.d) {
            return this.C.equals(arena.C);
        }
        if (this.a() == RegenerationType.c && arena.a() == RegenerationType.c) {
            final double n = this.getPosMax().getX() - this.getPosMin().getX();
            final double n2 = this.getPosMax().getY() - this.getPosMin().getY();
            final double n3 = this.getPosMax().getZ() - this.getPosMin().getZ();
            final double n4 = arena.getPosMax().getX() - arena.getPosMin().getX();
            final double n5 = arena.getPosMax().getY() - arena.getPosMin().getY();
            final double n6 = arena.getPosMax().getZ() - arena.getPosMin().getZ();
            return Math.abs(this.getPosMin().getX() - arena.getPosMin().getX()) < n + n4 && Math.abs(this.getPosMin().getY() - arena.getPosMin().getY()) < n2 + n5 && Math.abs(this.getPosMin().getZ() - arena.getPosMin().getZ()) < n3 + n6 && this.C.equals(arena.C);
        }
        return false;
    }
    
    public void n(final Player player) {
        for (final Arena arena : de.marcely.bedwars.util.s.af) {
            if (arena == this) {
                continue;
            }
            if (this.a(arena)) {
                player.sendMessage(" ");
                de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena1));
                de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena2).a("arena", arena.getName()));
                String s = null;
                switch (k()[this.a().ordinal()]) {
                    case 1: {
                        s = "/bw arena setposition " + this.getName();
                        break;
                    }
                    case 2: {
                        s = "/bw arena setworld " + this.getName();
                        break;
                    }
                    default: {
                        return;
                    }
                }
                de.marcely.bedwars.util.s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Arena_CollidingArena3).a("command", s));
            }
        }
    }
    
    public void a(final Player player, Location add) {
        add = add.clone().add(0.0, 0.1, 0.0);
        be.D.add(player);
        player.teleport(add);
    }
    
    private void b(final Player player, final boolean b) {
        if (!this.m.containsKey(player)) {
            return;
        }
        final Future<de.marcely.bedwars.game.stats.c> a = de.marcely.bedwars.game.stats.c.a(player);
        de.marcely.bedwars.util.s.a((Future<Object>)a, new Runnable() {
            @Override
            public void run() {
                try {
                    final de.marcely.bedwars.game.stats.c c = a.get();
                    c.setPlayTime(c.getPlayTime() + (System.currentTimeMillis() - Arena.this.m.get(player)));
                    if (b) {
                        c.setLoses(c.getLoses() + 1);
                    }
                    else {
                        c.setWins(c.getWins() + 1);
                    }
                    de.marcely.bedwars.util.s.a(player, b ? Achievement.d : Achievement.c);
                    if (c.getWins() >= 100) {
                        de.marcely.bedwars.util.s.a(player, Achievement.m);
                    }
                    c.save();
                    Arena.this.m.remove(player);
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        });
    }
    
    public void B() {
        for (int i = this.N.size() - 1; i >= 0; --i) {
            this.N.get(i).stop();
        }
    }
    
    public void c(final Player player, final boolean b) {
        if (ConfigValue.no_rain) {
            if (b) {
                Version.a().d(player, false);
            }
            else {
                Version.a().d(player, player.getWorld().getWeatherDuration() >= 1);
            }
        }
        if (ConfigValue.always_day && b) {
            Version.a().a(player, 5000L);
        }
    }
    
    public void C() {
        if (this.B) {
            if (this.getPlayers().size() >= 1) {
                this.B = false;
                de.marcely.bedwars.util.s.ag.add(this);
            }
        }
        else if (this.getPlayers().size() == 0) {
            this.B = true;
            de.marcely.bedwars.util.s.ag.remove(this);
            this.a.D();
        }
    }
    
    public void o(final Player player) {
        final Team a = this.a(player);
        if (a == null) {
            return;
        }
        if (player.getLocation().getY() <= 0.0) {
            this.a(player, this.a().a(a).toBukkit(this.world));
        }
        player.setHealth(0.0);
    }
    
    public void p(final Player player) {
        if (this.b() != ArenaStatus.e) {
            return;
        }
        de.marcely.bedwars.util.s.M(player);
        final Team a = this.a(player);
        for (final LobbyItem lobbyItem : de.marcely.bedwars.util.s.ai) {
            if (lobbyItem.a() == null) {
                player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), a));
            }
            else if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.d) {
                if (this.j() < this.k() || this.a == null || this.a.getValue() <= ConfigValue.forcestart_time || this.a.I()) {
                    continue;
                }
                for (final Player player2 : this.getPlayers()) {
                    if (de.marcely.bedwars.util.s.hasPermission((CommandSender)player2, Permission.Command_Forcestart)) {
                        player2.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), a));
                    }
                }
            }
            else {
                if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.e && !de.marcely.bedwars.util.s.al) {
                    continue;
                }
                if (this.a() == RegenerationType.e) {
                    if ((lobbyItem.a().getType() != LobbyItem.LobbySpecialType.b || this.D) && (lobbyItem.a().getType() != LobbyItem.LobbySpecialType.c || !this.D) && (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.b || lobbyItem.a().getType() == LobbyItem.LobbySpecialType.c)) {
                        continue;
                    }
                    player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), a));
                }
                else {
                    if (lobbyItem.a().getType() == LobbyItem.LobbySpecialType.c) {
                        continue;
                    }
                    player.getInventory().setItem(lobbyItem.getSlot(), de.marcely.bedwars.util.i.a(lobbyItem.getItemStack().clone(), a));
                }
            }
        }
        if (ConfigValue.lobby_team_onchange_wearcloth_enabled && a != null) {
            final Iterator<ItemStack> iterator3 = ConfigValue.lobby_team_onchange_wearcloth_materials.iterator();
            while (iterator3.hasNext()) {
                de.marcely.bedwars.util.s.b(player, de.marcely.bedwars.util.i.a(iterator3.next(), a));
            }
        }
    }
    
    public Map<Enchantment, Integer> a(final Player player, final Team team, final ItemStack itemStack) {
        final HashMap<Enchantment, Integer> hashMap = new HashMap<Enchantment, Integer>();
        final int a = this.a(DefaultUpgradeType.TEAM_SWORD_DAMAGE.getObj(), team);
        final int a2 = this.a(DefaultUpgradeType.TEAM_ARMOR_RESISTANCE.getObj(), team);
        if (a >= 1 && de.marcely.bedwars.util.k.b(itemStack.getType())) {
            hashMap.put(Enchantment.DAMAGE_ALL, a);
        }
        if (a2 >= 1 && de.marcely.bedwars.util.k.a(itemStack.getType())) {
            hashMap.put(Enchantment.PROTECTION_ENVIRONMENTAL, a2);
        }
        return hashMap;
    }
    
    @Override
    public boolean hasLobby() {
        return this.getLobby().getWorld() != null;
    }
    
    @Override
    public void setStatus(final de.marcely.bedwars.api.ArenaStatus arenaStatus) {
        this.a(arenaStatus.getNms());
    }
    
    @Override
    public void setStatus(final de.marcely.bedwars.api.ArenaStatus arenaStatus, final boolean b) {
        this.a(arenaStatus.getNms(), b);
    }
    
    @Override
    public int getPerTeamPlayers() {
        return this.getTeamPlayers();
    }
    
    @Override
    public TeamColors GetTeamColors() {
        return this.a();
    }
    
    @Nullable
    @Override
    public de.marcely.bedwars.api.Team GetPlayerTeam(final Player player) {
        return de.marcely.bedwars.api.Team.fromInternal(this.a(player));
    }
    
    @Override
    public de.marcely.bedwars.api.ArenaStatus GetStatus() {
        return de.marcely.bedwars.api.ArenaStatus.fromNMS(this.b());
    }
    
    @Override
    public de.marcely.bedwars.api.RegenerationType GetRegenerationType() {
        return de.marcely.bedwars.api.RegenerationType.fromNMS(this.a());
    }
    
    @Override
    public HashMap<XYZ, de.marcely.bedwars.api.DropType> getItemSpawners() {
        final HashMap<XYZ, DropType> hashMap = (HashMap<XYZ, DropType>)new HashMap<XYZ, de.marcely.bedwars.api.DropType>();
        for (final Map.Entry<DropType, XYZ> entry : this.a.entrySet()) {
            hashMap.put(entry.getValue(), entry.getKey());
        }
        return (HashMap<XYZ, de.marcely.bedwars.api.DropType>)hashMap;
    }
    
    @Override
    public boolean isCurrentlyRegenerating() {
        return this.B();
    }
    
    @Override
    public de.marcely.bedwars.api.AddPlayerFail addPlayer(final Player player) {
        final AddPlayerFail a = this.a(player, (Team)null);
        return (a != null) ? de.marcely.bedwars.api.AddPlayerFail.fromInternal(a) : null;
    }
    
    @Override
    public de.marcely.bedwars.api.AddPlayerFail addPlayer(final Player player, final de.marcely.bedwars.api.Team team) {
        final AddPlayerFail a = this.a(player, team.getInternal());
        return (a != null) ? de.marcely.bedwars.api.AddPlayerFail.fromInternal(a) : null;
    }
    
    @Override
    public boolean kickPlayer(final Player player) {
        return this.a(KickReason.c, player);
    }
    
    @Override
    public boolean kickPlayer(final Player player, final de.marcely.bedwars.api.KickReason kickReason) {
        return this.a(kickReason.getInternal(), player);
    }
    
    @Override
    public void kickAllPlayers(final de.marcely.bedwars.api.KickReason kickReason) {
        this.a(kickReason.getInternal());
    }
    
    @Override
    public void _0destroyBed(final Player player, final Location location, final de.marcely.bedwars.api.Team team) {
        this.a(player, location, team.getInternal());
    }
    
    @Override
    public void _0end(final de.marcely.bedwars.api.Team team) {
        this.b(team.getInternal());
    }
    
    @Override
    public void broadcast(final Sound sound) {
        this.a(sound);
    }
    
    @Override
    public void _0setIngameScoreboard(final Player player) {
        this.a.s(player);
    }
    
    @Override
    public void _0setLobbyScoreboard(final Player player) {
        this.a.q(player);
    }
    
    @Override
    public void addItemSpawner(final de.marcely.bedwars.api.DropType dropType, final XYZ xyz) {
        this.a.put((DropType)dropType, xyz);
    }
    
    @Override
    public void setAuthor(final String s) {
        this.v(s);
    }
    
    @Override
    public String getAuthor() {
        return this.n();
    }
    
    @Override
    public boolean _0remove() {
        return this.c((CommandSender)null);
    }
    
    @Override
    public void save() {
        de.marcely.bedwars.config.b.b(this);
    }
    
    @Override
    public void saveBlocks() {
        this.a((de.marcely.bedwars.game.regeneration.c)null);
    }
    
    @Override
    public long getRunningTime() {
        return 0L;
    }
    
    @Override
    public boolean hasCustomName() {
        return (boolean)this.a(de.marcely.bedwars.game.arena.f.a.d).getValue();
    }
    
    @Override
    public String getCustomName() {
        return (String)this.a(de.marcely.bedwars.game.arena.f.a.e).getValue();
    }
    
    @Override
    public String getDisplayName() {
        return this.hasCustomName() ? this.getCustomName() : this.getName();
    }
    
    @Override
    public void setHasCustomName(final boolean b) {
        this.a(de.marcely.bedwars.game.arena.f.a.d).setValue(b);
    }
    
    @Override
    public void setCustomName(final String value) {
        this.a(de.marcely.bedwars.game.arena.f.a.e).setValue(value);
    }
    
    @Override
    public long getGameStartTime() {
        return this.f;
    }
    
    @Override
    public List<Player> getPlayersInTeam(final de.marcely.bedwars.api.Team team) {
        return this.a(team.getInternal());
    }
    
    @Override
    public List<de.marcely.bedwars.api.Team> getRemainingTeams() {
        final List<Team> a = this.a(new Player[0]);
        final ArrayList list = new ArrayList<de.marcely.bedwars.api.Team>(a.size());
        final Iterator<Team> iterator = a.iterator();
        while (iterator.hasNext()) {
            list.add(de.marcely.bedwars.api.Team.fromInternal(iterator.next()));
        }
        return (List<de.marcely.bedwars.api.Team>)list;
    }
    
    @Override
    public XYZ getPosMin() {
        return this.a;
    }
    
    @Override
    public XYZ getPosMax() {
        return this.b;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    public de.marcely.bedwars.game.arena.b a() {
        return this.a;
    }
    
    @Override
    public World getWorld() {
        return this.world;
    }
    
    @Override
    public Location getLobby() {
        return this.b;
    }
    
    public XYZYP a() {
        return this.a;
    }
    
    public void a(final XYZYP a) {
        this.a = a;
    }
    
    public de.marcely.bedwars.game.arena.a a() {
        return this.a;
    }
    
    @Override
    public boolean isSleeping() {
        return this.B;
    }
    
    public List<Flag> p() {
        return this.flags;
    }
    
    public List<d> q() {
        return this.J;
    }
    
    static /* synthetic */ int[] k() {
        final int[] j = Arena.j;
        if (j != null) {
            return j;
        }
        final int[] i = new int[RegenerationType.values().length];
        try {
            i[RegenerationType.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[RegenerationType.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[RegenerationType.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        return Arena.j = i;
    }
    
    public enum AddPlayerFail
    {
        a("Full", 0), 
        b("AlreadyInside", 1), 
        c("OnlyVoteArenas", 2), 
        d("OnlyNormalArenas", 3), 
        e("Plugin", 4);
        
        static {
            a = new AddPlayerFail[] { AddPlayerFail.a, AddPlayerFail.b, AddPlayerFail.c, AddPlayerFail.d, AddPlayerFail.e };
        }
        
        private AddPlayerFail(final String name, final int ordinal) {
        }
    }
    
    public static class a
    {
        public final Arena arena;
        public List<Player> P;
        
        public a(final Arena arena) {
            this.P = new ArrayList<Player>();
            this.arena = arena;
        }
    }
    
    public static class b
    {
        public final DropType d;
        public final XYZ c;
        public final double value;
        
        public b(final DropType d, final XYZ c, final double value) {
            this.d = d;
            this.c = c;
            this.value = value;
        }
    }
}
