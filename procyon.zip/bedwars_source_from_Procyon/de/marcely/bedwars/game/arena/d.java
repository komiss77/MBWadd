// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.arena;

public interface d
{
    void a(final Arena p0, final a p1);
    
    public enum a
    {
        a("ADD", 0), 
        b("REMOVE", 1), 
        c("PLAYER_ADD", 2), 
        d("PLAYER_REMOVE", 3), 
        e("STATUS", 4), 
        f("ICON", 5), 
        g("RENAME", 6);
        
        static {
            a = new a[] { de.marcely.bedwars.game.arena.d.a.a, de.marcely.bedwars.game.arena.d.a.b, de.marcely.bedwars.game.arena.d.a.c, de.marcely.bedwars.game.arena.d.a.d, de.marcely.bedwars.game.arena.d.a.e, de.marcely.bedwars.game.arena.d.a.f, de.marcely.bedwars.game.arena.d.a.g };
        }
        
        private a(final String name, final int ordinal) {
        }
    }
}
