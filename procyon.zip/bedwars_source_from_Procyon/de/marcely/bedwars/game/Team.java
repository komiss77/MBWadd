// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.ChatColor;

public enum Team
{
    c("Yellow", 0, ChatColor.YELLOW, DyeColor.YELLOW, Color.YELLOW), 
    d("Orange", 1, ChatColor.GOLD, DyeColor.ORANGE, Color.ORANGE), 
    e("Red", 2, ChatColor.RED, DyeColor.RED, Color.RED), 
    f("Blue", 3, ChatColor.DARK_BLUE, DyeColor.BLUE, Color.BLUE), 
    g("Light_Blue", 4, ChatColor.BLUE, DyeColor.LIGHT_BLUE, Color.NAVY), 
    h("Cyan", 5, ChatColor.AQUA, DyeColor.CYAN, Color.fromRGB(0, 255, 255)), 
    i("Light_Green", 6, ChatColor.GREEN, DyeColor.LIME, Color.LIME), 
    j("Green", 7, ChatColor.DARK_GREEN, DyeColor.GREEN, Color.GREEN), 
    k("Purple", 8, ChatColor.DARK_PURPLE, DyeColor.PURPLE, Color.PURPLE), 
    l("Pink", 9, ChatColor.LIGHT_PURPLE, DyeColor.PINK, Color.FUCHSIA), 
    m("White", 10, ChatColor.WHITE, DyeColor.WHITE, Color.WHITE), 
    n("Light_Gray", 11, ChatColor.GRAY, DyeColor.SILVER, Color.SILVER), 
    o("Gray", 12, ChatColor.DARK_GRAY, DyeColor.GRAY, Color.GRAY), 
    p("Brown", 13, ChatColor.DARK_RED, DyeColor.BROWN, Color.fromRGB(139, 69, 19)), 
    q("Black", 14, ChatColor.BLACK, DyeColor.BLACK, Color.BLACK);
    
    private ChatColor b;
    private DyeColor a;
    private Color a;
    private static Map<Team, String> j;
    private static /* synthetic */ int[] i;
    
    static {
        a = new Team[] { Team.c, Team.d, Team.e, Team.f, Team.g, Team.h, Team.i, Team.j, Team.k, Team.l, Team.m, Team.n, Team.o, Team.p, Team.q };
        Team.j = new HashMap<Team, String>();
    }
    
    private Team(final String name, final int ordinal, final ChatColor b, final DyeColor a, final Color a2) {
        this.b = b;
        this.a = a;
        this.a = a2;
    }
    
    public String getName() {
        return this.a((CommandSender)null);
    }
    
    public String getName(final boolean b) {
        return this.a((CommandSender)null, b);
    }
    
    public String a(@Nullable final CommandSender commandSender) {
        return this.a(commandSender, true);
    }
    
    public String a(@Nullable final CommandSender commandSender, final boolean b) {
        String s = this.a(commandSender, this);
        if (s == null || s.isEmpty()) {
            s = this.name();
        }
        if (b) {
            return String.valueOf(s.substring(0, 1).toUpperCase()) + s.substring(1, s.length());
        }
        return s;
    }
    
    public String m() {
        return this.d(null);
    }
    
    public String d(@Nullable final CommandSender commandSender) {
        final String a = this.a(commandSender, true);
        String string = "";
        int n = 0;
        for (int i = 0; i < a.length(); ++i) {
            final char char1 = a.charAt(i);
            if (Character.isUpperCase(char1) || n != 0) {
                string = String.valueOf(string) + Character.toUpperCase(char1);
                n = 0;
            }
            else if (char1 == ' ') {
                n = 1;
            }
        }
        return string;
    }
    
    private String a(@Nullable final CommandSender commandSender, final Team team) {
        switch (j()[team.ordinal()]) {
            case 1: {
                return de.marcely.bedwars.message.b.a(Language.Color_Yellow).f(commandSender);
            }
            case 2: {
                return de.marcely.bedwars.message.b.a(Language.Color_Orange).f(commandSender);
            }
            case 3: {
                return de.marcely.bedwars.message.b.a(Language.Color_Red).f(commandSender);
            }
            case 4: {
                return de.marcely.bedwars.message.b.a(Language.Color_Blue).f(commandSender);
            }
            case 5: {
                return de.marcely.bedwars.message.b.a(Language.Color_LightBlue).f(commandSender);
            }
            case 6: {
                return de.marcely.bedwars.message.b.a(Language.Color_Cyan).f(commandSender);
            }
            case 7: {
                return de.marcely.bedwars.message.b.a(Language.Color_LightGreen).f(commandSender);
            }
            case 8: {
                return de.marcely.bedwars.message.b.a(Language.Color_Green).f(commandSender);
            }
            case 9: {
                return de.marcely.bedwars.message.b.a(Language.Color_Purple).f(commandSender);
            }
            case 10: {
                return de.marcely.bedwars.message.b.a(Language.Color_Pink).f(commandSender);
            }
            case 11: {
                return de.marcely.bedwars.message.b.a(Language.Color_White).f(commandSender);
            }
            case 12: {
                return de.marcely.bedwars.message.b.a(Language.Color_LightGray).f(commandSender);
            }
            case 13: {
                return de.marcely.bedwars.message.b.a(Language.Color_Gray).f(commandSender);
            }
            case 14: {
                return de.marcely.bedwars.message.b.a(Language.Color_Brown).f(commandSender);
            }
            case 15: {
                return de.marcely.bedwars.message.b.a(Language.Color_Black).f(commandSender);
            }
            default: {
                return null;
            }
        }
    }
    
    public ChatColor getChatColor() {
        return this.b;
    }
    
    public DyeColor getDyeColor() {
        return this.a;
    }
    
    public Color getColor() {
        return this.a;
    }
    
    public static Team a(final String s) {
        return a((CommandSender)null, s);
    }
    
    public static Team a(final String s, final boolean b) {
        return a(null, s, b);
    }
    
    public static Team a(@Nullable final CommandSender commandSender, final String s) {
        return a(commandSender, s, false);
    }
    
    public static Team a(@Nullable final CommandSender commandSender, final String s, final boolean b) {
        if (s == null) {
            return null;
        }
        Team[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Team team = values[i];
            if (s.equalsIgnoreCase(team.toString()) || s.equalsIgnoreCase(team.toString().replace("_", "")) || s.equalsIgnoreCase(team.toString().replace("_", "").replace(" ", "")) || s.equalsIgnoreCase(team.a(commandSender)) || s.equalsIgnoreCase(team.a(commandSender).replace(" ", ""))) {
                return team;
            }
        }
        if (b) {
            for (final Map.Entry<Team, String> entry : Team.j.entrySet()) {
                final Team team2 = entry.getKey();
                final String anotherString = entry.getValue();
                if (s.equalsIgnoreCase(anotherString)) {
                    return team2;
                }
                if (s.equalsIgnoreCase(anotherString.replace(" ", ""))) {
                    return team2;
                }
            }
        }
        return null;
    }
    
    public static List<String> l() {
        return c(null);
    }
    
    public static List<String> b(final boolean b) {
        return b(null, b);
    }
    
    public static List<String> a(final boolean b, final boolean b2) {
        return a(null, b, b2);
    }
    
    public static List<String> c(@Nullable final CommandSender commandSender) {
        return a(commandSender, true, false);
    }
    
    public static List<String> b(@Nullable final CommandSender commandSender, final boolean b) {
        return a(commandSender, b, false);
    }
    
    public static List<String> a(@Nullable final CommandSender commandSender, final boolean b, final boolean b2) {
        final ArrayList<String> list = new ArrayList<String>();
        Team[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Team team = values[i];
            list.add(b2 ? team.a(commandSender, b).replace(" ", "") : team.a(commandSender, b));
        }
        return list;
    }
    
    public static Team a(final ChatColor chatColor) {
        Team[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Team team = values[i];
            if (team.getChatColor() == chatColor) {
                return team;
            }
        }
        return null;
    }
    
    public static Team a(final DyeColor dyeColor) {
        Team[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Team team = values[i];
            if (team.getDyeColor() == dyeColor) {
                return team;
            }
        }
        return null;
    }
    
    public static void a(final Team team, final String s) {
        Team.j.put(team, s);
    }
    
    public static void y() {
        Team.j.clear();
    }
    
    static /* synthetic */ int[] j() {
        final int[] i = Team.i;
        if (i != null) {
            return i;
        }
        final int[] j = new int[values().length];
        try {
            j[Team.q.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            j[Team.f.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            j[Team.p.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            j[Team.h.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            j[Team.o.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            j[Team.j.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            j[Team.g.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            j[Team.n.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            j[Team.i.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            j[Team.d.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            j[Team.l.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            j[Team.k.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            j[Team.e.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            j[Team.m.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        try {
            j[Team.c.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError15) {}
        return Team.i = j;
    }
}
