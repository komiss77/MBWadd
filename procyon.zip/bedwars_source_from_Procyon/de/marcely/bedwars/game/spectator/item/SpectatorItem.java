// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.cC;
import org.bukkit.inventory.ItemStack;

public class SpectatorItem
{
    private final int slot;
    private final ItemStack item;
    private final String name;
    private final String J;
    private final cC a;
    
    public SpectatorItem(final int n, final ItemStack itemStack, final String s, final cC cc) {
        this(n, itemStack, s, cc, true);
    }
    
    public SpectatorItem(final int slot, final ItemStack item, final String name, final cC a, final boolean b) {
        this.slot = slot;
        this.item = item;
        this.name = name;
        this.J = b.a(name).b().c().f(null);
        this.a = a;
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public ItemStack getItem() {
        return this.item;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String q() {
        return this.J;
    }
    
    public cC a() {
        return this.a;
    }
}
