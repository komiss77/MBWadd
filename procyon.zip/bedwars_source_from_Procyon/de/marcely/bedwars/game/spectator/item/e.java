// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

import java.util.Iterator;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.be;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class e extends a
{
    public e() {
        super(b.b);
    }
    
    @Override
    protected void a(final Player player, final SpectatorItem spectatorItem, final Arena arena) {
        final GUI gui = new GUI(de.marcely.bedwars.message.b.a(Language.GUI_Spectator_Teleporter).f((CommandSender)player), 1);
        for (final Player player2 : arena.getPlayers()) {
            gui.addItem(new GUIItem(i.a(i.a(player2.getName(), 1), arena.a(player2).getChatColor() + s.getPlayerDisplayName(player2))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    if (player2.isOnline()) {
                        final Arena a = s.a(player2);
                        if (a != null && a.equals(arena)) {
                            be.D.add(player);
                            player.teleport(player2.getLocation());
                        }
                    }
                }
            });
        }
        if (ConfigValue.gui_spectatortp_centered) {
            gui.centerAtYAll(GUI.CenterFormatType.Normal);
        }
        gui.setBackground(new DecGUIItem(i.a(ConfigValue.gui_spectatortp_backgroundmaterial, " ")));
        gui.open(player);
    }
}
