// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import de.marcely.bedwars.cC;

public abstract class a extends cC
{
    private final b a;
    
    public a(final b a) {
        super(a.getIdentifier());
        this.a = a;
    }
    
    protected abstract void a(final Player p0, final SpectatorItem p1, final Arena p2);
    
    @Override
    public void onUse(final Player player, final SpectatorItem spectatorItem, final de.marcely.bedwars.api.Arena arena) {
        this.a(player, spectatorItem, (Arena)arena);
    }
    
    @Override
    public boolean a(final Player player, final SpectateReason spectateReason) {
        return this.a.K();
    }
    
    public b a() {
        return this.a;
    }
}
