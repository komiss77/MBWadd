// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

public enum b
{
    b("TPTO_PLAYER", 0, "tpto-player", true), 
    c("CHANGE_SPEED", 1, "change-speed", true), 
    d("LEAVE", 2, "leave", false), 
    e("LEAVE_NEXTROUND", 3, "leave-nextround", false);
    
    private final String identifier;
    private final boolean Q;
    private static /* synthetic */ int[] o;
    
    static {
        a = new b[] { b.b, b.c, b.d, b.e };
    }
    
    private b(final String name, final int ordinal, final String identifier, final boolean q) {
        this.identifier = identifier;
        this.Q = q;
    }
    
    public a a() {
        switch (p()[this.ordinal()]) {
            case 1: {
                return new e();
            }
            case 2: {
                return new ChangeSpeedItemHandler();
            }
            case 3: {
                return new c();
            }
            case 4: {
                return new d();
            }
            default: {
                return null;
            }
        }
    }
    
    public String getIdentifier() {
        return this.identifier;
    }
    
    public boolean K() {
        return this.Q;
    }
    
    static /* synthetic */ int[] p() {
        final int[] o = b.o;
        if (o != null) {
            return o;
        }
        final int[] o2 = new int[values().length];
        try {
            o2[b.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            o2[b.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            o2[b.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            o2[b.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        return b.o = o2;
    }
}
