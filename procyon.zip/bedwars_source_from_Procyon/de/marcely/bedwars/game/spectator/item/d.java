// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.api.KickReason;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class d extends a
{
    public d() {
        super(b.e);
    }
    
    @Override
    protected void a(final Player player, final SpectatorItem spectatorItem, final Arena arena) {
        final Arena c = s.c();
        if (c != null) {
            if (arena.getPlayers().contains(player)) {
                arena.kickPlayer(player, KickReason.Leave);
            }
            else {
                cA.a(player, cD.f);
            }
            final String b = s.b(player, c);
            if (b != null) {
                player.sendMessage(b);
            }
        }
        else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Spectator_ChangeArena_NoneAvailable));
        }
    }
}
