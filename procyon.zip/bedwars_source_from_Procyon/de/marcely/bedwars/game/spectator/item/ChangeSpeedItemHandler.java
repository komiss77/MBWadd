// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.spectator.item;

import javax.annotation.Nullable;
import java.util.Iterator;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.r;
import org.bukkit.ChatColor;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class ChangeSpeedItemHandler extends a
{
    public ChangeSpeedItemHandler() {
        super(b.c);
    }
    
    @Override
    protected void a(final Player player, final SpectatorItem spectatorItem, final Arena arena) {
        if (ConfigValue.spectator_changespeed_types.size() == 0) {
            return;
        }
        SpeedType obj = a(player.getFlySpeed());
        if (obj != null) {
            obj = a(obj);
        }
        else {
            ConfigValue.spectator_changespeed_types.get(0);
        }
        String obj2 = "";
        for (int i = 0; i < ConfigValue.spectator_changespeed_types.size(); ++i) {
            final SpeedType speedType = ConfigValue.spectator_changespeed_types.get(i);
            if (speedType.equals(obj)) {
                obj2 = String.valueOf(obj2) + speedType.name;
            }
            else {
                obj2 = String.valueOf(obj2) + ChatColor.GRAY + r.removeChatColor(speedType.name);
            }
            if (i + 1 < ConfigValue.spectator_changespeed_types.size()) {
                obj2 = String.valueOf(obj2) + ChatColor.BLACK + " | ";
            }
        }
        player.setFlySpeed(s.a(obj.h));
        Version.a().b(player, obj2);
    }
    
    @Nullable
    private static SpeedType a(final float n) {
        for (final SpeedType speedType : ConfigValue.spectator_changespeed_types) {
            if (s.a(speedType.h) == n) {
                return speedType;
            }
        }
        return null;
    }
    
    private static SpeedType a(final SpeedType speedType) {
        int n = ConfigValue.spectator_changespeed_types.indexOf(speedType) + 1;
        if (n >= ConfigValue.spectator_changespeed_types.size()) {
            n = 0;
        }
        return ConfigValue.spectator_changespeed_types.get(n);
    }
    
    public static class SpeedType
    {
        public final String name;
        public final float h;
        
        public SpeedType(final String name, final float h) {
            this.name = name;
            this.h = h;
        }
    }
}
