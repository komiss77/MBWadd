// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import de.marcely.bedwars.api.LobbyItemType;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.inventory.ItemStack;

public class LobbyItem implements de.marcely.bedwars.api.LobbyItem
{
    private int slot;
    private ItemStack is;
    private a a;
    private List<String> commands;
    
    public LobbyItem(final int n, final ItemStack itemStack) {
        this(n, itemStack, null);
    }
    
    public LobbyItem(final int slot, final ItemStack is, final a a) {
        this.a = null;
        this.commands = new ArrayList<String>();
        this.slot = slot;
        this.is = is;
        this.a = a;
    }
    
    @Override
    public void addCommand(final String s) {
        this.commands.add(s);
    }
    
    @Override
    public int getSlot() {
        return this.slot;
    }
    
    @Override
    public ItemStack getItemStack() {
        return this.is;
    }
    
    public a a() {
        return this.a;
    }
    
    @Override
    public List<String> getCommands() {
        return this.commands;
    }
    
    @Override
    public void setSlot(final int slot) {
        this.slot = slot;
    }
    
    @Override
    public void setItemStack(final ItemStack is) {
        this.is = is;
    }
    
    public void a(final a a) {
        this.a = a;
    }
    
    @Override
    public LobbyItemType getType() {
        return (this.a() != null) ? LobbyItemType.fromNMS(this.a().getType()) : null;
    }
    
    public enum LobbySpecialType
    {
        a("Leave", 0), 
        b("SelectTeam", 1), 
        c("VoteArena", 2), 
        d("ForceStart", 3), 
        e("Achievements", 4), 
        f("Custom", 5);
        
        static {
            a = new LobbySpecialType[] { LobbySpecialType.a, LobbySpecialType.b, LobbySpecialType.c, LobbySpecialType.d, LobbySpecialType.e, LobbySpecialType.f };
        }
        
        private LobbySpecialType(final String name, final int ordinal) {
        }
        
        public static LobbySpecialType a(final String anotherString) {
            LobbySpecialType[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final LobbySpecialType lobbySpecialType = values[i];
                if (lobbySpecialType.name().equalsIgnoreCase(anotherString)) {
                    return lobbySpecialType;
                }
            }
            return null;
        }
    }
    
    public static class a
    {
        private final LobbySpecialType type;
        private final String name;
        
        public a(final LobbySpecialType lobbySpecialType) {
            this(lobbySpecialType, lobbySpecialType.name());
        }
        
        public a(final LobbySpecialType type, final String name) {
            this.type = type;
            this.name = name;
        }
        
        public LobbySpecialType getType() {
            return this.type;
        }
        
        public String getName() {
            return this.name;
        }
    }
}
