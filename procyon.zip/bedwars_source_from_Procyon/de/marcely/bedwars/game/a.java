// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import java.util.Iterator;
import de.marcely.bedwars.versions.Version;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.ArrayList;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Player;
import java.util.List;

public class a
{
    private List<Player> players;
    private boolean x;
    private String x;
    private String y;
    private BukkitTask a;
    private BukkitTask b;
    
    public a() {
        this(new ArrayList<Player>());
    }
    
    public a(final List<Player> players) {
        this.x = false;
        this.x = "";
        this.players = players;
    }
    
    public boolean d(final Player player) {
        return this.players.add(player);
    }
    
    public boolean e(final Player player) {
        return this.players.remove(player);
    }
    
    public void setMessage(final String x) {
        this.v();
        this.x = x;
        this.w();
    }
    
    public void b(final String x, final int n) {
        this.v();
        this.y = this.x;
        this.x = x;
        this.w();
        this.b = new BukkitRunnable() {
            public void run() {
                de.marcely.bedwars.game.a.this.v();
            }
        }.runTaskLater((Plugin)MBedwars.a, (long)n);
    }
    
    public void v() {
        if (this.b != null) {
            this.x = this.y;
            this.b.cancel();
            this.b = null;
        }
    }
    
    public void run() {
        if (this.a == null) {
            this.a = new BukkitRunnable() {
                public void run() {
                    de.marcely.bedwars.game.a.this.w();
                }
            }.runTaskTimer((Plugin)MBedwars.a, 0L, (long)(this.x ? 58 : 30));
        }
    }
    
    public void stop() {
        if (this.a != null) {
            this.a.cancel();
            this.a = null;
            if (this.b != null) {
                this.v();
            }
        }
    }
    
    public void refresh() {
        this.stop();
        this.run();
    }
    
    public boolean isRunning() {
        return this.a != null;
    }
    
    private void w() {
        if (!this.isRunning()) {
            return;
        }
        final Iterator<Player> iterator = this.players.iterator();
        while (iterator.hasNext()) {
            Version.a().b(iterator.next(), this.x);
        }
    }
    
    public List<Player> getPlayers() {
        return this.players;
    }
    
    public void a(final List<Player> players) {
        this.players = players;
    }
    
    public boolean z() {
        return this.x;
    }
    
    public void setAnimated(final boolean x) {
        this.x = x;
    }
    
    public String h() {
        return this.x;
    }
    
    public String i() {
        return this.y;
    }
}
