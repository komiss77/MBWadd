// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import org.bukkit.Effect;
import de.marcely.bedwars.Language;
import java.util.Iterator;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import org.bukkit.command.CommandSender;
import javax.annotation.Nullable;
import de.marcely.bedwars.api.Spawner;
import java.util.ArrayList;
import org.bukkit.Material;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.inventory.ItemStack;
import java.util.List;

public class DropType implements de.marcely.bedwars.api.DropType, Cloneable
{
    private static List<DropType> G;
    private String id;
    private ItemStack d;
    private String A;
    private double b;
    private VarParticle a;
    private Sound b;
    private ChatColor a;
    private String name;
    private int M;
    private boolean y;
    private boolean z;
    private Material a;
    private boolean A;
    public ItemStack icon;
    
    static {
        DropType.G = new ArrayList<DropType>();
    }
    
    public DropType() {
        this.id = null;
        this.d = new ItemStack(Material.STONE);
        this.A = null;
        this.b = 10.0;
        this.a = null;
        this.b = null;
        this.a = ChatColor.WHITE;
        this.name = "";
        this.M = 0;
        this.y = false;
        this.z = false;
        this.a = null;
        this.A = false;
        this.icon = null;
    }
    
    public DropType(final String id, final ItemStack d, final String name, final double b, final VarParticle a, final Sound b2, final ChatColor a2) {
        this.id = null;
        this.d = new ItemStack(Material.STONE);
        this.A = null;
        this.b = 10.0;
        this.a = null;
        this.b = null;
        this.a = ChatColor.WHITE;
        this.name = "";
        this.M = 0;
        this.y = false;
        this.z = false;
        this.a = null;
        this.A = false;
        this.icon = null;
        this.id = id;
        this.d = d;
        this.name = name;
        this.b = b;
        this.a = a;
        this.b = b2;
        this.a = a2;
    }
    
    public DropType(final String id, final Spawner spawner, final String name, final double b, final VarParticle a, final Sound b2, final ChatColor a2) {
        this.id = null;
        this.d = new ItemStack(Material.STONE);
        this.A = null;
        this.b = 10.0;
        this.a = null;
        this.b = null;
        this.a = ChatColor.WHITE;
        this.name = "";
        this.M = 0;
        this.y = false;
        this.z = false;
        this.a = null;
        this.A = false;
        this.icon = null;
        this.id = id;
        this.A = spawner.getName();
        this.name = name;
        this.b = b;
        this.a = a;
        this.b = b2;
        this.a = a2;
    }
    
    @Nullable
    public String k() {
        return this.id;
    }
    
    public String getId() {
        if (this.id != null) {
            return this.id;
        }
        return this.name;
    }
    
    @Override
    public String getName() {
        return this.a((CommandSender)null);
    }
    
    public String getName(final boolean b) {
        return this.a((CommandSender)null, b);
    }
    
    public String a(@Nullable final CommandSender commandSender) {
        return this.a(commandSender, true);
    }
    
    public String a(@Nullable final CommandSender commandSender, final boolean b) {
        if (this.name == null) {
            return "";
        }
        String f = b.a(this.name).c().f(commandSender);
        if (f == null) {
            f = "Error";
        }
        if (b && f.length() >= 1) {
            return String.valueOf(f.substring(0, 1).toUpperCase()) + f.substring(1, f.length());
        }
        return f;
    }
    
    public String getRealName() {
        return this.name;
    }
    
    @Nullable
    @Override
    public Spawner getCustomSpawner() {
        return (this.A != null) ? s.a(this.A) : null;
    }
    
    @Override
    public ItemStack getActualItemstack() {
        final Spawner customSpawner = this.getCustomSpawner();
        if (customSpawner != null) {
            return customSpawner.getShopIcon();
        }
        return this.c();
    }
    
    public static DropType a(final ItemStack itemStack) {
        for (final DropType dropType : values()) {
            if (dropType.c().getType() == itemStack.getType() && dropType.c().getDurability() == itemStack.getDurability()) {
                return dropType;
            }
        }
        return null;
    }
    
    public static DropType a(final String s) {
        for (final DropType dropType : values()) {
            if (dropType.getName().equalsIgnoreCase(s) || dropType.getRealName().equalsIgnoreCase(s) || (dropType.id != null && dropType.id.equalsIgnoreCase(s))) {
                return dropType;
            }
            final Language language = Language.getLanguage(dropType.getRealName().replace("%", ""));
            if (language != null && language.getDefaultEnglish().equalsIgnoreCase(s)) {
                return dropType;
            }
        }
        return null;
    }
    
    public static List<DropType> values() {
        return DropType.G;
    }
    
    public static List<String> k() {
        return b(null);
    }
    
    public static List<String> a(final boolean b) {
        return a((CommandSender)null, b);
    }
    
    public static List<String> b(@Nullable final CommandSender commandSender) {
        return a(commandSender, true);
    }
    
    public static List<String> a(@Nullable final CommandSender commandSender, final boolean b) {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator<DropType> iterator = DropType.G.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().a(commandSender, b));
        }
        return list;
    }
    
    public static boolean a(final DropType dropType) {
        return DropType.G.add(dropType);
    }
    
    public static void clear() {
        DropType.G.clear();
    }
    
    public static boolean a(final String s, final boolean b) {
        if (b) {
            final Iterator<DropType> iterator = values().iterator();
            while (iterator.hasNext()) {
                if (iterator.next().getName().equalsIgnoreCase(s)) {
                    return true;
                }
            }
        }
        else {
            final Iterator<DropType> iterator2 = values().iterator();
            while (iterator2.hasNext()) {
                if (iterator2.next().getName().equals(s)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public DropType b() {
        try {
            final DropType dropType = (DropType)super.clone();
            dropType.d = this.d.clone();
            return dropType;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    @Override
    public void setName(final String name) {
        this.name = name;
    }
    
    @Override
    public void setConfigItemstack(final ItemStack d) {
        this.d = d;
    }
    
    @Override
    public void setCustomSpawner(final Spawner spawner) {
        this.A = ((spawner != null) ? spawner.getName() : null);
    }
    
    @Override
    public void setSpawnRadius(final int m) {
        this.M = m;
    }
    
    @Override
    public void setSound(final Sound b) {
        this.b = b;
    }
    
    @Override
    public ItemStack getConfigItemstack() {
        return this.d;
    }
    
    @Override
    public int getSpawnRadius() {
        return this.M;
    }
    
    @Override
    public Sound getSound() {
        return this.b;
    }
    
    @Override
    public boolean isDisabledForRound() {
        return this.A;
    }
    
    @Override
    public void setDisabledForRound(final boolean a) {
        this.A = a;
    }
    
    @Deprecated
    @Override
    public void setEffect(final Effect effect) {
        if (effect == null) {
            this.a = null;
            return;
        }
        this.a = new VarParticle(effect);
    }
    
    @Deprecated
    @Override
    public Effect getEffect() {
        if (this.a == null || this.a.getKeepType() != VarParticle.ParticleKeepType.EFFECT) {
            return null;
        }
        return this.a.getEffect();
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public void a(final ItemStack d) {
        this.d = d;
    }
    
    public ItemStack c() {
        return this.d;
    }
    
    public void u(final String a) {
        this.A = a;
    }
    
    public String l() {
        return this.A;
    }
    
    @Override
    public void setSpawnDelay(final double b) {
        this.b = b;
    }
    
    @Override
    public double getSpawnDelay() {
        return this.b;
    }
    
    @Override
    public void setVarParticle(final VarParticle a) {
        this.a = a;
    }
    
    @Override
    public VarParticle getVarParticle() {
        return this.a;
    }
    
    @Override
    public void setChatColor(final ChatColor a) {
        this.a = a;
    }
    
    @Override
    public ChatColor getChatColor() {
        return this.a;
    }
    
    @Override
    public void setTranquil(final boolean y) {
        this.y = y;
    }
    
    @Override
    public void setMerging(final boolean z) {
        this.z = z;
    }
    
    @Override
    public boolean isTranquil() {
        return this.y;
    }
    
    @Override
    public boolean isMerging() {
        return this.z;
    }
    
    @Override
    public void setHologram(final Material a) {
        this.a = a;
    }
    
    @Override
    public Material getHologram() {
        return this.a;
    }
}
