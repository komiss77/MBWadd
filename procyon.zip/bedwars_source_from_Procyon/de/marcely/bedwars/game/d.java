// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import java.util.Iterator;
import java.util.HashMap;
import org.bukkit.block.Block;
import org.bukkit.Material;
import org.bukkit.Location;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class d implements Serializable
{
    private static final long serialVersionUID = -176089766393982401L;
    public List<SimpleBlock> s;
    
    public d() {
        this.s = new ArrayList<SimpleBlock>();
    }
    
    public d(final List<SimpleBlock> s) {
        this.s = new ArrayList<SimpleBlock>();
        this.s = s;
    }
    
    public void a(final SimpleBlock simpleBlock) {
        this.s.add(simpleBlock);
    }
    
    public void a(final Location location, final Material material) {
        this.s.add(new SimpleBlock(location, material));
    }
    
    public void a(final int n, final int n2, final int n3, final Material material) {
        this.s.add(new SimpleBlock(n, n2, n3, material));
    }
    
    public void a(final Block block) {
        this.s.add(new SimpleBlock(block));
    }
    
    public HashMap<String, SimpleBlock> b() {
        final HashMap<String, SimpleBlock> hashMap = new HashMap<String, SimpleBlock>();
        for (final SimpleBlock value : this.s) {
            hashMap.put(String.valueOf(value.x) + "," + value.y + "," + value.z, value);
        }
        return hashMap;
    }
}
