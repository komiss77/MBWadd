// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import org.bukkit.Color;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.Location;
import de.marcely.bedwars.game.location.XYZ;
import org.bukkit.entity.Player;

public class b
{
    private static final int SIZE = 10;
    private static final int K = 35;
    
    public static void a(final Player player, final XYZ xyz, final XYZ xyz2) {
        final double x = xyz.getX();
        final double y = xyz.getY();
        final double z = xyz.getZ();
        final double x2 = xyz2.getX();
        final double y2 = xyz2.getY();
        final double z2 = xyz2.getZ();
        final double x3 = player.getLocation().getX();
        final double y3 = player.getLocation().getY();
        final double z3 = player.getLocation().getZ();
        if (x3 - x <= 35.0) {
            for (int i = -10; i < 10; ++i) {
                for (int j = -10; j < 10; ++j) {
                    if (y3 + j >= xyz.getY() && y3 + j <= xyz2.getY() && z3 + i >= xyz.getZ() && z3 + i <= xyz2.getZ()) {
                        a(player, x, y3 + j, z3 + i);
                    }
                }
            }
        }
        if (y3 - y <= 35.0) {
            for (int k = -10; k < 10; ++k) {
                for (int l = -10; l < 10; ++l) {
                    if (x3 + k >= xyz.getX() && x3 + k <= xyz2.getX() && z3 + l >= xyz.getZ() && z3 + l <= xyz2.getZ()) {
                        a(player, x3 + k, y, z3 + l);
                    }
                }
            }
        }
        if (z3 - z <= 35.0) {
            for (int n = -10; n < 10; ++n) {
                for (int n2 = -10; n2 < 10; ++n2) {
                    if (x3 + n >= xyz.getX() && x3 + n <= xyz2.getX() && y3 + n2 >= xyz.getY() && y3 + n2 <= xyz2.getY()) {
                        a(player, x3 + n, y3 + n2, z);
                    }
                }
            }
        }
        if (x2 - x3 <= 35.0) {
            for (int n3 = -10; n3 < 10; ++n3) {
                for (int n4 = -10; n4 < 10; ++n4) {
                    if (y3 + n4 >= xyz.getY() && y3 + n4 <= xyz2.getY() && z3 + n3 >= xyz.getZ() && z3 + n3 <= xyz2.getZ()) {
                        a(player, x2, y3 + n4, z3 + n3);
                    }
                }
            }
        }
        if (y2 - y3 <= 35.0) {
            for (int n5 = -10; n5 < 10; ++n5) {
                for (int n6 = -10; n6 < 10; ++n6) {
                    if (x3 + n5 >= xyz.getX() && x3 + n5 <= xyz2.getX() && z3 + n6 >= xyz.getZ() && z3 + n6 <= xyz2.getZ()) {
                        a(player, x3 + n5, y2, z3 + n6);
                    }
                }
            }
        }
        if (z2 - z3 <= 35.0) {
            for (int n7 = -10; n7 < 10; ++n7) {
                for (int n8 = -10; n8 < 10; ++n8) {
                    if (x3 + n7 >= xyz.getX() && x3 + n7 <= xyz2.getX() && y3 + n8 >= xyz.getY() && y3 + n8 <= xyz2.getY()) {
                        a(player, x3 + n7, y3 + n8, z2);
                    }
                }
            }
        }
    }
    
    private static void a(final Player player, final double n, final double n2, final double n3) {
        final Location location = new Location(player.getWorld(), n, n2, n3);
        final float n4 = (float)location.distance(player.getLocation());
        if (n4 < 0.0f || n4 >= 35.0f) {
            return;
        }
        float n7;
        float n6;
        float n5;
        if (n4 < 6.0f) {
            n5 = (n6 = (n7 = n4 / 6.0f));
        }
        else {
            n7 = (n6 = (n5 = (35.0f - n4) / 35.0f));
        }
        VarParticle.PARTICLE_COLOURED.play(player, location, Color.fromRGB((int)(n6 * 255.0f), (int)(n5 * 255.0f), (int)(n7 * 255.0f)));
    }
}
