// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import org.bukkit.scoreboard.Team;
import org.bukkit.ChatColor;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

public class c
{
    private final String name;
    private final String z;
    private final Scoreboard a;
    private final Objective a;
    String title;
    private a[] a;
    private List<a> F;
    private boolean finished;
    
    public c(final String name, final String z, final String s) {
        this.a = new a[0];
        this.F = new ArrayList<a>();
        this.finished = false;
        this.name = name;
        this.z = z;
        this.title = s;
        this.a = Bukkit.getScoreboardManager().getNewScoreboard();
        (this.a = this.a.registerNewObjective(name, z)).setDisplaySlot(DisplaySlot.SIDEBAR);
        this.a.setDisplayName(s);
    }
    
    public void setTitle(final String s) {
        this.title = s;
        this.a.setDisplayName(s);
    }
    
    public void i(final Player player) {
        player.setScoreboard(this.a);
    }
    
    @Nullable
    public a a(final String s) {
        if (this.finished) {
            new NullPointerException("Can not add rows if scoreboard is already finished").printStackTrace();
            return null;
        }
        try {
            final a a = new a(this, s, this.a.length);
            this.F.add(a);
            return a;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public void finish() {
        if (this.finished) {
            new NullPointerException("Can not finish if scoreboard is already finished").printStackTrace();
            return;
        }
        this.finished = true;
        for (int i = this.F.size() - 1; i >= 0; --i) {
            final a a = this.F.get(i);
            final Team registerNewTeam = this.a.registerNewTeam(String.valueOf(this.name) + "." + this.z + "." + (i + 1));
            registerNewTeam.addEntry(new StringBuilder().append(ChatColor.values()[i]).toString());
            this.a.getScore(new StringBuilder().append(ChatColor.values()[i]).toString()).setScore(this.F.size() - i);
            c.a.a(a, registerNewTeam);
            a.setMessage(a.message);
        }
        this.a = this.F.toArray(new a[this.F.size()]);
    }
    
    public String getName() {
        return this.name;
    }
    
    public String j() {
        return this.z;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public a[] a() {
        return this.a;
    }
    
    public static class a
    {
        private final c a;
        private Team a;
        private final int L;
        private String message;
        
        public a(final c a, final String message, final int l) {
            this.a = a;
            this.L = l;
            this.message = message;
        }
        
        public void setMessage(final String message) {
            this.message = message;
            if (this.a.finished) {
                final String[] b = b(message);
                this.a.setPrefix(b[0]);
                this.a.setSuffix(b[1]);
            }
        }
        
        private static String[] b(final String s) {
            final String[] array = new String[2];
            ChatColor white = ChatColor.WHITE;
            Object o = null;
            Character value = null;
            array[0] = "";
            for (int i = 0; i < s.length() / 2; ++i) {
                final char char1 = s.charAt(i);
                if (value != null) {
                    final ChatColor a = a(new char[] { value, char1 });
                    if (a != null) {
                        if (a.isFormat()) {
                            o = a;
                        }
                        else {
                            white = a;
                            o = null;
                        }
                    }
                }
                final String[] array2 = array;
                final int n = 0;
                array2[n] = String.valueOf(array2[n]) + char1;
                value = char1;
            }
            array[1] = new StringBuilder().append((white != null) ? white : "").append((o != null) ? o : "").append(s.substring(s.length() / 2)).toString();
            return array;
        }
        
        @Nullable
        private static ChatColor a(final char[] array) {
            ChatColor[] values;
            for (int length = (values = ChatColor.values()).length, i = 0; i < length; ++i) {
                final ChatColor chatColor = values[i];
                final char[] charArray = chatColor.toString().toCharArray();
                int n = 0;
                for (int j = 0; j < 2; ++j) {
                    if (charArray[j] == array[j]) {
                        ++n;
                    }
                }
                if (n == 2) {
                    return chatColor;
                }
            }
            return null;
        }
        
        public c a() {
            return this.a;
        }
        
        public int i() {
            return this.L;
        }
        
        public String getMessage() {
            return this.message;
        }
        
        static /* synthetic */ void a(final a a, final Team a2) {
            a.a = a2;
        }
    }
}
