// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.location;

import org.bukkit.block.Block;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import java.io.Serializable;

public class XYZW extends XYZ implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String world;
    
    public XYZW(final World world, final double n, final double n2, final double n3) {
        this(world.getName(), n, n2, n3);
    }
    
    public XYZW(final String world, final double n, final double n2, final double n3) {
        super(n, n2, n3);
        this.world = world;
    }
    
    public XYZW(final Location location) {
        this(location.getWorld(), location.getX(), location.getY(), location.getZ());
    }
    
    public World getWorld() {
        return (this.world != null) ? Bukkit.getWorld(this.world) : null;
    }
    
    public String getWorldString() {
        return this.world;
    }
    
    public void setWorld(final World world) {
        this.world = world.getName();
    }
    
    public void setWorldString(final String world) {
        this.world = world;
    }
    
    public boolean equals(final XYZW xyzw) {
        return xyzw.getWorldString() == this.world && xyzw.getX() == this.getX() && xyzw.getY() == this.getY() && xyzw.getZ() == this.getZ();
    }
    
    public Location toBukkit() {
        return new Location(this.getWorld(), this.getX(), this.getY(), this.getZ());
    }
    
    public Block toBlock() {
        return this.getWorld().getBlockAt((int)this.x, (int)this.y, (int)this.z);
    }
    
    public static XYZW valueOf(final Location location) {
        if (location == null) {
            return new XYZW(Bukkit.getWorlds().get(0), 0.0, 0.0, 0.0);
        }
        return new XYZW(location.getWorld(), location.getX(), location.getY(), location.getZ());
    }
}
