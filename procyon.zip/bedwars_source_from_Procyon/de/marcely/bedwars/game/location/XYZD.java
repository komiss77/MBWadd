// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.location;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.w;
import de.marcely.bedwars.versions.Version;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.Location;
import javax.annotation.Nullable;
import org.bukkit.block.BlockFace;
import java.io.Serializable;

public class XYZD extends XYZ implements Serializable
{
    private static final long serialVersionUID = 1054369555018442319L;
    private int d;
    
    public XYZD() {
        this.d = 0;
    }
    
    public XYZD(final double n, final double n2, final double n3, final int d) {
        super(n, n2, n3);
        this.d = 0;
        this.d = d;
    }
    
    public int getD() {
        return this.d;
    }
    
    public void setD(final int d) {
        this.d = d;
    }
    
    @Nullable
    public BlockFace getDAsBlockFace() {
        switch (this.d) {
            case 0: {
                return BlockFace.SOUTH;
            }
            case 1: {
                return BlockFace.WEST;
            }
            case 2: {
                return BlockFace.NORTH;
            }
            case 3: {
                return BlockFace.EAST;
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean equals(final XYZD xyzd) {
        return xyzd.getX() == this.getX() && xyzd.getY() == this.getY() && xyzd.getZ() == this.getZ() && xyzd.getD() == this.d;
    }
    
    public static XYZD valueOf(final Location location) {
        return new XYZD(location.getX(), location.getY(), location.getZ(), 0);
    }
    
    public static XYZD valueOf(final Block block) {
        return valueOf(block, block.getType() == Material.BED_BLOCK);
    }
    
    public static XYZD valueOf(final Block block, final boolean b) {
        final Location location = block.getLocation();
        int data = 0;
        if (b && Version.a().getVersionNumber() >= 13) {
            switch (((w)Version.a().a()).a(block)) {
                case SOUTH: {
                    data = 0;
                    break;
                }
                case WEST: {
                    data = 1;
                    break;
                }
                case NORTH: {
                    data = 2;
                    break;
                }
                case EAST: {
                    data = 3;
                    break;
                }
            }
        }
        else {
            data = block.getData();
        }
        return new XYZD(location.getX(), location.getY(), location.getZ(), data);
    }
    
    @Nullable
    public static XYZD ofString(final String s) {
        final String[] split = s.split(",");
        if (split.length != 4) {
            return null;
        }
        for (int i = 0; i < 3; ++i) {
            if (!s.isDouble(split[i])) {
                return null;
            }
        }
        if (!s.isInteger(split[3])) {
            return null;
        }
        return new XYZD(Double.valueOf(split[0]), Double.valueOf(split[1]), Double.valueOf(split[2]), Integer.valueOf(split[3]));
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z + "," + this.d;
    }
}
