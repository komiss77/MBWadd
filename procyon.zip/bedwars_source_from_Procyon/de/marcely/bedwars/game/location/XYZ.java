// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.location;

import javax.annotation.Nullable;
import org.bukkit.block.Block;
import de.marcely.bedwars.util.s;
import org.bukkit.util.Vector;
import org.bukkit.Location;
import org.bukkit.World;
import java.io.Serializable;

public class XYZ implements Serializable, Cloneable
{
    private static final long serialVersionUID = 1054369555018442319L;
    protected double x;
    protected double y;
    protected double z;
    
    public XYZ() {
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
    }
    
    public XYZ(final double x, final double y, final double z) {
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public double getX() {
        return this.x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public void setZ(final double z) {
        this.z = z;
    }
    
    public void setXYZ(final double x, final double y, final double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public boolean somethingNull() {
        return this.x == 0.0 && this.y == 0.0 && this.z == 0.0;
    }
    
    public boolean equals(final XYZ xyz) {
        return xyz.getX() == this.x && xyz.getY() == this.y && xyz.getZ() == this.z;
    }
    
    public Location toBukkit(final World world) {
        return new Location(world, this.x, this.y, this.z);
    }
    
    public Vector toVector() {
        return new Vector(this.x, this.y, this.z);
    }
    
    public XYZ add(final double n, final double n2, final double n3) {
        final XYZ clone;
        final XYZ xyz = clone = this.clone();
        clone.x += n;
        final XYZ xyz2 = xyz;
        xyz2.y += n2;
        final XYZ xyz3 = xyz;
        xyz3.z += n3;
        return xyz;
    }
    
    public double distance(final XYZ xyz) {
        return s.distance(this.x, xyz.x) + s.distance(this.y, xyz.y) + s.distance(this.z, xyz.z);
    }
    
    public Block toBlock(final World world) {
        return world.getBlockAt((int)this.x, (int)this.y, (int)this.z);
    }
    
    public void floor() {
        this.x = (int)this.x;
        this.y = (int)this.y;
        this.z = (int)this.z;
    }
    
    public static XYZ valueOf(final Location location) {
        return new XYZ(location.getX(), location.getY(), location.getZ());
    }
    
    public static XYZ valueOf(final Vector vector) {
        return new XYZ(vector.getX(), vector.getY(), vector.getZ());
    }
    
    @Nullable
    public static XYZ ofString(final String s) {
        final String[] split = s.split(",");
        if (split.length == 3) {
            String[] array;
            for (int length = (array = split).length, i = 0; i < length; ++i) {
                if (!s.isDouble(array[i])) {
                    return null;
                }
            }
            return new XYZ(Double.valueOf(split[0]), Double.valueOf(split[1]), Double.valueOf(split[2]));
        }
        return null;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z;
    }
    
    public XYZ clone() {
        try {
            return (XYZ)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
