// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.location;

import javax.annotation.Nullable;
import de.marcely.bedwars.util.s;
import org.bukkit.Location;
import org.bukkit.World;
import java.io.Serializable;

public class XYZYP extends XYZ implements Serializable
{
    private static final long serialVersionUID = 1054369555018442319L;
    private float yaw;
    private float pitch;
    
    public XYZYP() {
        this.yaw = 0.0f;
        this.pitch = 0.0f;
    }
    
    public XYZYP(final double n, final double n2, final double n3, final float yaw, final float pitch) {
        super(n, n2, n3);
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void setYaw(final float yaw) {
        this.yaw = yaw;
    }
    
    public void setPitch(final float pitch) {
        this.pitch = pitch;
    }
    
    public boolean equals(final XYZYP xyzyp) {
        return xyzyp.getX() == this.getX() && xyzyp.getY() == this.getY() && xyzyp.getZ() == this.getZ() && xyzyp.getYaw() == this.yaw && xyzyp.getPitch() == this.pitch;
    }
    
    @Override
    public Location toBukkit(final World world) {
        return new Location(world, this.getX(), this.getY(), this.getZ(), this.getYaw(), this.getPitch());
    }
    
    public static XYZYP valueOf(final Location location) {
        return new XYZYP(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
    }
    
    @Nullable
    public static XYZYP ofString(final String s) {
        final String[] split = s.split(",");
        if (split.length == 5) {
            String[] array;
            for (int length = (array = split).length, i = 0; i < length; ++i) {
                if (!s.isDouble(array[i])) {
                    return null;
                }
            }
            return new XYZYP(Double.valueOf(split[0]), Double.valueOf(split[1]), Double.valueOf(split[2]), (float)(double)Double.valueOf(split[3]), (float)(double)Double.valueOf(split[4]));
        }
        return null;
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.x) + "," + this.y + "," + this.z + "," + this.yaw + "," + this.pitch;
    }
}
