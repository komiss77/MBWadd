// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.location;

import org.bukkit.Location;
import org.bukkit.World;
import java.io.Serializable;

public class XYZYPW extends XYZW implements Serializable, Cloneable
{
    private static final long serialVersionUID = 1L;
    private float yaw;
    private float pitch;
    
    public XYZYPW(final World world, final double n, final double n2, final double n3, final float n4, final float n5) {
        this(world.getName(), n, n2, n3, n4, n5);
    }
    
    public XYZYPW(final String s, final double n, final double n2, final double n3, final float yaw, final float pitch) {
        super(s, n, n2, n3);
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    public XYZYPW(final Location location) {
        this(location.getWorld(), location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void setYaw(final float yaw) {
        this.yaw = yaw;
    }
    
    public void setPitch(final float pitch) {
        this.pitch = pitch;
    }
    
    public boolean equals(final XYZYPW xyzypw) {
        return xyzypw.getWorldString().equals(xyzypw.getWorldString()) && xyzypw.getX() == this.getX() && xyzypw.getY() == this.getY() && xyzypw.getZ() == this.getZ() && xyzypw.getYaw() == this.getYaw() && xyzypw.getPitch() == this.getPitch();
    }
    
    @Override
    public Location toBukkit() {
        return new Location(this.getWorld(), this.getX(), this.getY(), this.getZ(), this.getYaw(), this.getPitch());
    }
    
    public XYZ toXYZ() {
        return new XYZ(this.getX(), this.getY(), this.getZ());
    }
    
    public static XYZYPW valueOf(final Location location) {
        return new XYZYPW(location);
    }
    
    @Override
    public XYZYPW clone() {
        return (XYZYPW)super.clone();
    }
}
