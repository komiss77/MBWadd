// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game;

import org.bukkit.block.Block;
import org.bukkit.Material;
import org.bukkit.Location;
import java.io.Serializable;

public class SimpleBlock implements Serializable
{
    private static final long serialVersionUID = 1280731586616867212L;
    public int x;
    public int y;
    public int z;
    public String block;
    public Byte data;
    
    public SimpleBlock() {
    }
    
    public SimpleBlock(final Location location, final Material material) {
        this.x = location.getBlockX();
        this.y = location.getBlockY();
        this.z = location.getBlockZ();
        this.block = material.toString();
    }
    
    public SimpleBlock(final Block block) {
        this.x = block.getLocation().getBlockX();
        this.y = block.getLocation().getBlockY();
        this.z = block.getLocation().getBlockZ();
        this.block = block.getType().toString();
        this.data = block.getData();
    }
    
    public SimpleBlock(final int x, final int y, final int z, final Material material) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.block = material.toString();
    }
    
    public SimpleBlock(final int x, final int y, final int z, final Material material, final Byte data) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.data = data;
        this.block = material.toString();
    }
    
    public Material getMaterial() {
        return Material.getMaterial(this.block);
    }
}
