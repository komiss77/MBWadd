// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.inventory;

import org.bukkit.potion.PotionEffectType;
import org.apache.commons.codec.binary.Base64;
import de.marcely.bedwars.versions.Version;
import org.bukkit.potion.PotionEffect;
import java.io.InputStream;
import org.bukkit.util.io.BukkitObjectInputStream;
import java.io.ByteArrayInputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import java.io.OutputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import java.io.ByteArrayOutputStream;
import org.bukkit.inventory.ItemStack;

@Deprecated
public class a
{
    public static String a(final ItemStack[] array) {
        try {
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            final BukkitObjectOutputStream bukkitObjectOutputStream = new BukkitObjectOutputStream((OutputStream)byteArrayOutputStream);
            bukkitObjectOutputStream.writeInt(array.length);
            for (int length = array.length, i = 0; i < length; ++i) {
                bukkitObjectOutputStream.writeObject((Object)array[i]);
            }
            bukkitObjectOutputStream.close();
            return Base64Coder.encodeLines(byteArrayOutputStream.toByteArray());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static ItemStack[] a(final String s) {
        try {
            final BukkitObjectInputStream bukkitObjectInputStream = new BukkitObjectInputStream((InputStream)new ByteArrayInputStream(Base64Coder.decodeLines(s)));
            final int int1 = bukkitObjectInputStream.readInt();
            final ItemStack[] array = new ItemStack[int1];
            for (int i = 0; i < int1; ++i) {
                array[i] = (ItemStack)bukkitObjectInputStream.readObject();
            }
            bukkitObjectInputStream.close();
            return array;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static String a(final PotionEffect potionEffect) {
        final String string = String.valueOf(potionEffect.getType().getId()) + "." + potionEffect.getDuration() + "." + potionEffect.getAmplifier();
        if (Version.a().getVersionNumber() >= 8) {
            return Base64.encodeBase64String(string.getBytes());
        }
        return net.minecraft.util.org.apache.commons.codec.binary.Base64.encodeBase64String(string.getBytes());
    }
    
    public static PotionEffect a(final String s) {
        try {
            String s2;
            if (Version.a().getVersionNumber() >= 8) {
                s2 = new String(Base64.decodeBase64(s));
            }
            else {
                s2 = new String(net.minecraft.util.org.apache.commons.codec.binary.Base64.decodeBase64(s));
            }
            final String[] split = s2.split("\\.");
            return new PotionEffect(PotionEffectType.getById((int)Integer.valueOf(split[0])), (int)Integer.valueOf(split[1]), (int)Integer.valueOf(split[2]));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
