// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.inventory;

import java.util.Arrays;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.versions.Version;
import java.util.Iterator;
import org.bukkit.potion.PotionEffect;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.location.XYZW;
import java.util.List;
import org.bukkit.GameMode;
import java.util.UUID;
import java.io.Serializable;

@Deprecated
public class PlayerData implements Serializable
{
    private static final long serialVersionUID = -6702784113641141250L;
    private UUID uuid;
    private String inventory;
    private String inventory_armor;
    private boolean flying;
    private boolean ingame;
    private GameMode gamemode;
    private int level;
    private int food;
    private float exp;
    private double health;
    private List<String> activePotions;
    private XYZW compassTarget;
    
    public PlayerData(final Player player) {
        this.flying = false;
        this.ingame = false;
        this.gamemode = GameMode.ADVENTURE;
        this.level = 0;
        this.food = 20;
        this.exp = 0.0f;
        this.health = 20.0;
        this.activePotions = new ArrayList<String>();
        this.compassTarget = new XYZW(s.a(), 0.0, 0.0, 0.0);
        this.uuid = player.getUniqueId();
        this.inventory = a.a(player.getInventory().getContents());
        this.inventory_armor = a.a(player.getInventory().getArmorContents());
        this.flying = player.getAllowFlight();
        this.gamemode = player.getGameMode();
        this.level = player.getLevel();
        this.food = player.getFoodLevel();
        this.exp = player.getExp();
        this.health = b.a(player);
        this.compassTarget = XYZW.valueOf(player.getCompassTarget());
        final Iterator<PotionEffect> iterator = player.getActivePotionEffects().iterator();
        while (iterator.hasNext()) {
            this.activePotions.add(a.a(iterator.next()));
        }
    }
    
    public void u(final Player player) {
        ItemStack[] a = de.marcely.bedwars.game.inventory.a.a(this.inventory);
        if (a.length > Version.a().u()) {
            a = Arrays.copyOfRange(a, 0, Version.a().u());
        }
        player.getInventory().setContents(a);
        player.getInventory().setArmorContents(de.marcely.bedwars.game.inventory.a.a(this.inventory_armor));
        player.updateInventory();
        player.setAllowFlight(this.flying);
        player.setGameMode(this.gamemode);
        player.setLevel(this.level);
        player.setFoodLevel(this.food);
        player.setExp(this.exp);
        player.setHealth((this.health <= player.getHealth()) ? this.health : player.getMaxHealth());
        player.setCompassTarget(this.compassTarget.toBukkit());
        if (this.activePotions.size() != 0) {
            final Iterator<String> iterator = this.activePotions.iterator();
            while (iterator.hasNext()) {
                player.addPotionEffect(de.marcely.bedwars.game.inventory.a.a((String)iterator.next()));
            }
        }
    }
    
    public void a(final ItemStack[] array) {
        this.inventory = a.a(array);
    }
    
    public void b(final ItemStack[] array) {
        this.inventory_armor = a.a(array);
    }
    
    public void setFlying(final boolean flying) {
        this.flying = flying;
    }
    
    public void setGameMode(final GameMode gamemode) {
        this.gamemode = gamemode;
    }
    
    public void setLevel(final int level) {
        this.level = level;
    }
    
    public void setFoodLevel(final int food) {
        this.food = food;
    }
    
    public void setExp(final float exp) {
        this.exp = exp;
    }
    
    public void setHealth(final double health) {
        this.health = health;
    }
    
    public void d(final List<String> activePotions) {
        this.activePotions = activePotions;
    }
    
    public void f(final boolean ingame) {
        this.ingame = ingame;
    }
    
    public UUID getUniqueId() {
        return this.uuid;
    }
    
    public ItemStack[] a() {
        return a.a(this.inventory);
    }
    
    public ItemStack[] b() {
        return a.a(this.inventory_armor);
    }
    
    public boolean isFlying() {
        return this.flying;
    }
    
    public GameMode getGameMode() {
        return this.gamemode;
    }
    
    public int getLevel() {
        return this.level;
    }
    
    public int getFoodLevel() {
        return this.food;
    }
    
    public float getExp() {
        return this.exp;
    }
    
    public double getHealth() {
        return this.health;
    }
    
    public List<String> s() {
        return this.activePotions;
    }
    
    public boolean isIngame() {
        return this.ingame;
    }
    
    public void save() {
        de.marcely.bedwars.game.inventory.b.a(this);
    }
}
