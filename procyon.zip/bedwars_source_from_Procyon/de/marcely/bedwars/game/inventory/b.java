// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.game.inventory;

import java.io.File;
import java.util.UUID;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import de.marcely.bedwars.util.s;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.Player;

@Deprecated
public class b
{
    public static PlayerData a(final Player player) throws Exception {
        if (ConfigValue.inventory_backup) {
            final ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(a(player.getUniqueId())));
            final PlayerData playerData = (PlayerData)objectInputStream.readObject();
            objectInputStream.close();
            return playerData;
        }
        if (ConfigValue.inventory_clear) {
            s.M(player);
        }
        return new PlayerData(player);
    }
    
    public static void a(final PlayerData obj) {
        try {
            if (ConfigValue.inventory_backup) {
                final ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(a(obj.getUniqueId())));
                objectOutputStream.writeObject(obj);
                objectOutputStream.close();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static File a(final UUID obj) {
        return new File("plugins/MBedwars/data/playerinvs/" + obj + ".yml");
    }
}
