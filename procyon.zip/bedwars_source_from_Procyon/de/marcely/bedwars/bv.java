// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.ExtraItemListener;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.ExtraItem;

public class bv extends ExtraItem
{
    private final bx a;
    
    public bv(final bx a, final ItemStack itemStack) {
        super(a.name().toLowerCase().replace("_", " "), itemStack);
        this.a = a;
        this.registerListener(bw.a);
    }
    
    public bx a() {
        return this.a;
    }
}
