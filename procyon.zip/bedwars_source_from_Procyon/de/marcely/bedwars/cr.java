// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class cr extends ct
{
    public static cr a;
    
    static {
        cr.a = new cr();
    }
    
    public String b(final c c) {
        return new StringBuilder().append(c.getKills()).toString();
    }
}
