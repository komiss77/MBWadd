// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;

public enum ey
{
    a("LOGIN", 0, 0), 
    b("LOGIN_REPLY", 1, 1), 
    c("LOGIN_USER_INFO", 2, 2), 
    d("LOGIN_USER_INFO_REPLY", 3, 3), 
    e("GET_AVAILABLE_LIBRARIES", 4, 16), 
    f("GET_AVAILABLE_LIBRARIES_REPLY", 5, 17), 
    g("DOWNLOAD_LIBRARY", 6, 32), 
    h("DOWNLOAD_LIBRARY_REPLY", 7, 33), 
    i("AVAILABLE_UPDATE_ANNOUNCEMENT", 8, 48), 
    j("MESSAGE", 9, 49);
    
    private final byte id;
    private static /* synthetic */ int[] t;
    
    static {
        a = new ey[] { ey.a, ey.b, ey.c, ey.d, ey.e, ey.f, ey.g, ey.h, ey.i, ey.j };
    }
    
    private ey(final String name, final int ordinal, final int n) {
        this.id = (byte)n;
    }
    
    public ex a() {
        switch (u()[this.ordinal()]) {
            case 1: {
                return new es();
            }
            case 2: {
                return new et();
            }
            case 3: {
                return new eu();
            }
            case 4: {
                return new ev();
            }
            case 5: {
                return new eq();
            }
            case 6: {
                return new er();
            }
            case 7: {
                return new eo();
            }
            case 8: {
                return new ep();
            }
            case 9: {
                return new en();
            }
            case 10: {
                return new ew();
            }
            default: {
                return null;
            }
        }
    }
    
    @Nullable
    public static ey a(final byte b) {
        ey[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ey ey = values[i];
            if (ey.getId() == b) {
                return ey;
            }
        }
        return null;
    }
    
    public byte getId() {
        return this.id;
    }
    
    static /* synthetic */ int[] u() {
        final int[] t = ey.t;
        if (t != null) {
            return t;
        }
        final int[] t2 = new int[values().length];
        try {
            t2[ey.i.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            t2[ey.g.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            t2[ey.h.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            t2[ey.e.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            t2[ey.f.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            t2[ey.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            t2[ey.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            t2[ey.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            t2[ey.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            t2[ey.j.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        return ey.t = t2;
    }
}
