// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.Map;
import de.marcely.bedwars.game.Team;
import java.util.TreeMap;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import de.simonsator.partyandfriends.spigot.api.party.PlayerParty;
import de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayer;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import de.simonsator.partyandfriends.spigot.api.party.PartyManager;
import de.simonsator.partyandfriends.spigot.api.pafplayers.PAFPlayerManager;
import de.marcely.bedwars.util.s;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.api.event.PlayerJoinArenaEvent;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

public class cU extends cR implements Listener
{
    @Override
    public cT a() {
        return cT.w;
    }
    
    @Override
    public void onEnable() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }
    
    @Override
    public void onDisable() {
        HandlerList.unregisterAll((Listener)this);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void a(final PlayerJoinArenaEvent playerJoinArenaEvent) {
        if (playerJoinArenaEvent.getFailReason() != null) {
            return;
        }
        new BukkitRunnable() {
            public void run() {
                final Player player = playerJoinArenaEvent.getPlayer();
                final Arena a = s.a(player);
                if (a == null || a.getTeamPlayers() <= 1) {
                    return;
                }
                final PAFPlayer player2 = PAFPlayerManager.getInstance().getPlayer(player.getUniqueId());
                if (player2 == null) {
                    return;
                }
                final PlayerParty party = PartyManager.getInstance().getParty(player2);
                if (party == null) {
                    return;
                }
                cU.this.a(a, player, player2, party);
            }
        }.runTaskLater((Plugin)MBedwars.a, 1L);
    }
    
    private void a(final Arena arena, final Player player, final PAFPlayer pafPlayer, final PlayerParty playerParty) {
        final TreeMap<Integer, Team> treeMap = new TreeMap<Integer, Team>();
        final Iterator<PAFPlayer> iterator = playerParty.getAllPlayers().iterator();
        while (iterator.hasNext()) {
            if (iterator.next() == pafPlayer) {
                continue;
            }
            final Team a = arena.a(player);
            treeMap.put(arena.a(a).size(), a);
        }
        for (final Map.Entry<Integer, Team> entry : treeMap.entrySet()) {
            if (entry.getKey() < arena.getPerTeamPlayers()) {
                arena.b(player, entry.getValue());
                return;
            }
        }
        final TreeMap<Integer, Team> treeMap2 = (TreeMap<Integer, Team>)new TreeMap<Object, Object>();
        for (final Team team : arena.a().r()) {
            treeMap2.put(arena.a(team).size(), team);
        }
        arena.b(player, (Team)treeMap2.get(0));
    }
}
