// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class eo extends ex
{
    public short a;
    public int version;
    public long e;
    public byte z;
    
    @Override
    public ey a() {
        return ey.g;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedShort(this.a);
        bufferedWriteStream.writeUnsignedShort(this.version);
        bufferedWriteStream.writeSignedLong(this.e);
        bufferedWriteStream.writeByte(this.z);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
    }
}
