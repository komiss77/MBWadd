// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class Q extends R
{
    @Override
    public S a() {
        return S.a;
    }
    
    @Override
    public void write(final BufferedWriteStream bufferedWriteStream) {
    }
    
    @Override
    public void read(final BufferedReadStream bufferedReadStream) {
    }
}
