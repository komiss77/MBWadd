// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.Arrays;
import java.util.List;
import java.util.Iterator;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Map;
import org.bukkit.Material;
import de.marcely.bedwars.api.ExtraItem;
import org.bukkit.enchantments.Enchantment;
import java.util.HashMap;
import de.marcely.bedwars.game.DropType;
import org.bukkit.inventory.ItemStack;

@Deprecated
public class ap implements Cloneable
{
    public ap a;
    private String name;
    private String v;
    private ItemStack icon;
    private aq a;
    private DropType c;
    private int priceAmount;
    private int capsMultiply;
    private HashMap<Enchantment, Integer> d;
    private ExtraItem extraItem;
    private Integer a;
    public boolean keepOnDeath;
    public boolean oneTimePurchase;
    public ItemStack c;
    
    public ap(final String name) {
        this.name = "NO NAME";
        this.v = "NO NAME";
        this.icon = new ItemStack(Material.STONE);
        this.a = null;
        this.c = DropType.values().get(0);
        this.priceAmount = 1;
        this.capsMultiply = 1;
        this.d = new HashMap<Enchantment, Integer>();
        this.extraItem = null;
        this.a = null;
        this.keepOnDeath = false;
        this.oneTimePurchase = false;
        this.c = null;
        this.setName(name);
        this.s(name);
    }
    
    public ap(final String s, final aq aq, final DropType dropType, final int n) {
        this(s, new ItemStack(Material.STONE, 1), aq, dropType, n, 1);
    }
    
    public ap(final String s, final Material material, final int n, final aq aq, final DropType dropType, final int n2) {
        this(s, new ItemStack(material, n), aq, dropType, n2, n);
    }
    
    public ap(final String s, final Material material, final short n, final int n2, final aq aq, final DropType dropType, final int n3) {
        this(s, new ItemStack(material, n2, n), aq, dropType, n3, n2);
    }
    
    public ap(final String s, final aq aq, final DropType dropType, final int n, final int n2) {
        this(s, new ItemStack(Material.STONE), aq, dropType, n, n2);
    }
    
    public ap(final String s, final Material material, final int n, final aq aq, final DropType dropType, final int n2, final int n3) {
        this(s, new ItemStack(material, n), aq, dropType, n2, n3);
    }
    
    public ap(final String s, final Material material, final short n, final int n2, final aq aq, final DropType dropType, final int n3, final int n4) {
        this(s, new ItemStack(material, n2, n), aq, dropType, n3, n4);
    }
    
    public ap(final String s, final ExtraItem extraItem, final int n, final aq aq, final DropType dropType, final int n2) {
        this(s, extraItem, extraItem.getItemStack().getAmount(), aq, dropType, n2, 1);
    }
    
    public ap(final String s, final bx bx, final int n, final aq aq, final DropType dropType, final int n2) {
        this(s, bx.getExtraItem(), bx.getItemStack().getAmount(), aq, dropType, n2, 1);
    }
    
    public ap(final String name, final ExtraItem extraItem, final int n, final aq aq, final DropType dropType, final int n2, final int capsMultiply) {
        this.name = "NO NAME";
        this.v = "NO NAME";
        this.icon = new ItemStack(Material.STONE);
        this.a = null;
        this.c = DropType.values().get(0);
        this.priceAmount = 1;
        this.capsMultiply = 1;
        this.d = new HashMap<Enchantment, Integer>();
        this.extraItem = null;
        this.a = null;
        this.keepOnDeath = false;
        this.oneTimePurchase = false;
        this.c = null;
        this.setName(name);
        this.s(name);
        this.setExtraItem(extraItem);
        this.setIcon(extraItem.getItemStack());
        this.a(aq);
        this.a(dropType);
        this.c(n2);
        this.setCapsMultiply(capsMultiply);
    }
    
    public ap(final String s, final ItemStack itemStack, final aq aq, final DropType dropType, final int n) {
        this(s, itemStack, aq, dropType, n, itemStack.getAmount());
    }
    
    public ap(final String name, final ItemStack icon, final aq aq, final DropType dropType, final int n, final int capsMultiply) {
        this.name = "NO NAME";
        this.v = "NO NAME";
        this.icon = new ItemStack(Material.STONE);
        this.a = null;
        this.c = DropType.values().get(0);
        this.priceAmount = 1;
        this.capsMultiply = 1;
        this.d = new HashMap<Enchantment, Integer>();
        this.extraItem = null;
        this.a = null;
        this.keepOnDeath = false;
        this.oneTimePurchase = false;
        this.c = null;
        this.setName(name);
        this.s(name);
        this.setIcon(icon);
        this.a(aq);
        this.a(dropType);
        this.c(n);
        this.setCapsMultiply(capsMultiply);
    }
    
    public void a(final Enchantment enchantment) {
        this.addEnchantment(enchantment, 1);
    }
    
    public void addEnchantment(final Enchantment key, final int i) {
        this.d.put(key, i);
    }
    
    public void setIcon(final ItemStack icon) {
        if (icon.getEnchantments().size() >= 1) {
            this.d.putAll(icon.getEnchantments());
        }
        this.icon = icon;
    }
    
    public void a(final DropType dropType, final int n) {
        this.a(dropType);
        this.c(n);
    }
    
    public void a(final aq a) {
        this.a = a;
    }
    
    public void setAmount(final int amount) {
        this.icon.setAmount(amount);
    }
    
    public ItemStack getIcon() {
        final int amount = this.icon.getAmount();
        if (this.extraItem != null) {
            this.icon = this.extraItem.getItemStack(this.icon.getAmount());
        }
        this.icon.setAmount(amount);
        if (this.a().size() >= 1 && this.icon.getEnchantments().size() == 0) {
            final ItemMeta itemMeta = this.icon.getItemMeta();
            for (final Map.Entry<Enchantment, Integer> entry : this.a().entrySet()) {
                itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), false);
            }
            this.icon.setItemMeta(itemMeta);
        }
        return this.icon;
    }
    
    public List<ap> getItems() {
        return Arrays.asList(this);
    }
    
    public boolean v() {
        return this.extraItem != null;
    }
    
    public int getAmountPlayerCanBuy(final Player player, final boolean b) {
        int a = 999;
        if (this.a().getActualItemstack() != null && this.a().getActualItemstack().getType() != null && this.a().getActualItemstack().getType() != Material.AIR) {
            a = s.a(player, i.a(this.a().getActualItemstack().clone(), this.a().getChatColor() + this.a().a((CommandSender)null, true)));
        }
        if (a >= this.getPriceAmount()) {
            int capsMultiply = 1;
            if (b) {
                capsMultiply = a;
            }
            if (capsMultiply > this.getCapsMultiply()) {
                capsMultiply = this.getCapsMultiply();
            }
            return capsMultiply;
        }
        return 0;
    }
    
    public HashMap<Enchantment, Integer> a() {
        return this.d;
    }
    
    public int getAmount() {
        return this.icon.getAmount();
    }
    
    public void a(final Player player, final Team team, final int amount, final Map<Enchantment, Integer> map) {
        final ItemStack itemStack = (this.getExtraItem() == null) ? ((this.getIcon() != null) ? this.getIcon().clone() : null) : this.getExtraItem().getItemStack().clone();
        itemStack.setAmount(amount);
        final ItemStack a = i.a(itemStack, team);
        final ItemMeta itemMeta = a.getItemMeta();
        for (final Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            itemMeta.addEnchant((Enchantment)entry.getKey(), (int)entry.getValue(), true);
        }
        a.setItemMeta(itemMeta);
        s.a(player, a);
    }
    
    public int getPrice(final Player player) {
        return (this.a != null && s.hasPermission((CommandSender)player, Permission.ShopCustomPrice)) ? this.a : this.priceAmount;
    }
    
    public ap a() {
        try {
            final ap ap = (ap)super.clone();
            ap.c = ((this.c != null) ? this.c.b() : null);
            ap.icon = ((this.icon != null) ? this.icon.clone() : null);
            ap.a = ((this.a != null) ? this.a : this);
            return ap;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void s(final String v) {
        this.v = v;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getRealName() {
        return this.v;
    }
    
    public aq a() {
        return this.a;
    }
    
    public void a(final DropType c) {
        this.c = c;
    }
    
    public DropType a() {
        return this.c;
    }
    
    public int getPriceAmount() {
        return this.priceAmount;
    }
    
    public void c(final int priceAmount) {
        this.priceAmount = priceAmount;
    }
    
    public int getCapsMultiply() {
        return this.capsMultiply;
    }
    
    public void setCapsMultiply(final int capsMultiply) {
        this.capsMultiply = capsMultiply;
    }
    
    public ExtraItem getExtraItem() {
        return this.extraItem;
    }
    
    public void setExtraItem(final ExtraItem extraItem) {
        this.extraItem = extraItem;
    }
    
    public Integer a() {
        return this.a;
    }
    
    public void a(final Integer a) {
        this.a = a;
    }
}
