// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.block.Block;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.regeneration.c;
import java.util.Iterator;
import org.bukkit.Chunk;
import de.marcely.bedwars.util.b;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import java.util.List;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.regeneration.RegionData;
import java.io.File;
import de.marcely.bedwars.game.arena.RegenerationType;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.regeneration.a;

@Deprecated
public class al extends de.marcely.bedwars.game.regeneration.a
{
    private boolean running;
    private int regenerationSpeed;
    
    public al(final Arena arena, @Nullable final CommandSender commandSender) {
        super(RegenerationType.c, arena, commandSender);
    }
    
    @Override
    protected void a(final File file) {
        ak.a(new ak.a() {
            final /* synthetic */ al a;
            
            @Override
            public void a(final RegionData regionData) {
                if (regionData == null) {
                    al.this.b(false, "The file '/MBedwars/arenablocks/" + al.this.arena.getName() + ".yml' is corrupted!!");
                    return;
                }
                if (regionData.getBlocks().size() == 0) {
                    al.this.b(false, "The file '/MBedwars/arenablocks/" + al.this.arena.getName() + ".yml' is empty!!");
                    return;
                }
                final List<b> a = b.a(regionData.getBlocks());
                al.a(al.this, true);
                if (Version.a().getVersionNumber() >= 9) {
                    new Synchronizer(true) {
                        @Override
                        public void run() {
                            for (int i = (int)al.this.arena.getPosMin().getX() >> 4; i <= (int)al.this.arena.getPosMax().getX() >> 4; ++i) {
                                for (int j = (int)al.this.arena.getPosMin().getZ() >> 4; j <= (int)al.this.arena.getPosMax().getZ() >> 4; ++j) {
                                    al.this.arena.getWorld().getChunkAt(i, j).load();
                                }
                            }
                        }
                    };
                }
                final al.a a2 = new al.a(ConfigValue.regeneration_threadsafe, a, regionData, 0, 0, -1, 0, (int)al.this.arena.getPosMin().getX(), (int)al.this.arena.getPosMin().getY(), (int)al.this.arena.getPosMin().getZ());
                if (ConfigValue.regeneration_threadsafe) {
                    new MThread(MThread.ThreadType.m, al.this.arena.getName()) {
                        @Override
                        public void run() {
                            try {
                                while (((al$1)a2).a.running) {
                                    al.this.a(a2);
                                }
                            }
                            catch (Exception ex) {
                                ex.printStackTrace();
                                al.a(((al$1)a2).a, false);
                                new Synchronizer() {
                                    @Override
                                    public void run() {
                                        de.marcely.bedwars.game.regeneration.a.this.g(false);
                                    }
                                };
                            }
                        }
                    }.start();
                }
                else {
                    new BukkitRunnable() {
                        public void run() {
                            if (!((al$1)a2).a.running) {
                                this.cancel();
                                return;
                            }
                            try {
                                al.this.a(a2);
                            }
                            catch (Exception ex) {
                                ex.printStackTrace();
                                al.a(((al$1)a2).a, false);
                                de.marcely.bedwars.game.regeneration.a.this.g(false);
                            }
                        }
                    }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
                }
            }
        }, file, this.arena);
    }
    
    private void a(final a a) {
        if (a.C == 0) {
            for (final Entity entity : this.arena.getWorld().getEntities()) {
                if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM && this.arena.isInside(entity.getLocation())) {
                    entity.remove();
                }
            }
            ++a.C;
            Version.a().a(this.arena.getWorld(), true);
        }
        else if (a.C == 1) {
            for (int i = 0; i < 20000; ++i) {
                ++a.D;
                if (a.D > this.arena.getPosMax().getX()) {
                    a.D = (int)this.arena.getPosMin().getX();
                    ++a.E;
                }
                if (a.E > this.arena.getPosMax().getY()) {
                    a.E = (int)this.arena.getPosMin().getY();
                    ++a.F;
                }
                if (a.F > this.arena.getPosMax().getZ()) {
                    ++a.C;
                    break;
                }
                Version.a().a(new Location(this.arena.getWorld(), (double)a.D, (double)a.E, (double)a.F), Material.AIR, (byte)0);
            }
        }
        else if (a.C == 2) {
            if (a.G < a.b.getBlocks().size()) {
                int size = a.G + 20000;
                if (size > a.b.getBlocks().size()) {
                    size = a.b.getBlocks().size();
                }
                for (int j = a.G; j < size; ++j) {
                    if (j % 50000 == 0) {
                        ++a.H;
                    }
                    final RBlock rBlock = a.z.get(a.H).blocks.get(j - a.H * 50000);
                    try {
                        if (a.q) {
                            Version.a().a(new Location(this.arena.getWorld(), (double)rBlock.getX(), (double)rBlock.getY(), (double)rBlock.getZ()), rBlock.getType(), rBlock.getData());
                        }
                        else {
                            rBlock.a(this.arena.getWorld(), this.arena);
                        }
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                a.G = size;
            }
            else {
                ++a.C;
                a.G = 0;
                a.H = -1;
                Version.a().a(this.arena.getWorld(), false);
            }
        }
        else if (a.C == 3) {
            if (a.G < a.b.getBlocks().size()) {
                new Synchronizer(true) {
                    @Override
                    public void run() {
                        int size = a.G + 20000;
                        if (size > a.b.getBlocks().size()) {
                            size = a.b.getBlocks().size();
                        }
                        for (int i = a.G; i < size; ++i) {
                            if (i % 50000 == 0) {
                                final a b = a;
                                ++b.H;
                            }
                            final RBlock rBlock = a.z.get(a.H).blocks.get(i - a.H * 50000);
                            try {
                                if (rBlock.a() != null) {
                                    rBlock.a(al.this.arena.getWorld(), al.this.arena);
                                }
                            }
                            catch (Exception ex) {
                                d.b("[Regeneration] Skipped block data placement at X" + rBlock.getX() + " Y" + rBlock.getY() + " Z" + rBlock.getZ() + " in arena " + al.this.arena.getName());
                            }
                        }
                        a.G = size;
                    }
                };
            }
            else {
                ++a.C;
            }
        }
        else if (a.C == 4) {
            int n = this.regenerationSpeed / 25000;
            if (n <= 0) {
                n = 1;
            }
            for (int k = 0; k < n; ++k) {
                final int n2 = a.I + k;
                if (n2 >= a.b.getEntities().size()) {
                    break;
                }
                new Synchronizer() {
                    final /* synthetic */ al a = a.b.getEntities().get(n2);
                    private final /* synthetic */ REntity a = a.b.getEntities().get(n2);
                    
                    @Override
                    public void run() {
                        try {
                            REntity.this.a(al.this.arena.getWorld());
                        }
                        catch (Exception ex) {
                            d.b("[Regeneration] Skipped entity type " + REntity.this.getType().name() + " in arena " + al.this.arena.getName());
                        }
                    }
                };
            }
            a.I += n;
            ++a.C;
        }
        else if (a.C == 5) {
            if (Version.a().getVersionNumber() >= 8) {
                ++a.C;
            }
            else {
                new Synchronizer(true) {
                    @Override
                    public void run() {
                        new MThread(MThread.ThreadType.m, al.this.arena.getName()) {
                            private final /* synthetic */ List x = al.this.arena.m();
                            
                            @Override
                            public void run() {
                                final ArrayList<Player> list = new ArrayList<Player>();
                                for (final Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(al.this.arena.a().toBukkit(al.this.arena.getWorld()), Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16)) {
                                    if (entity.getType() == EntityType.PLAYER) {
                                        list.add((Player)entity);
                                    }
                                }
                                new Synchronizer() {
                                    private final /* synthetic */ List x = al$4$1.this.x;
                                    
                                    @Override
                                    public void run() {
                                        final Iterator<Chunk> iterator = this.x.iterator();
                                        while (iterator.hasNext()) {
                                            Version.a().a(iterator.next(), (Player[])list.toArray(new Player[list.size()]));
                                        }
                                    }
                                };
                                final a b = a;
                                ++b.C;
                            }
                        }.start();
                    }
                };
            }
        }
        else if (a.C == 6) {
            this.running = false;
            new Synchronizer() {
                @Override
                public void run() {
                    de.marcely.bedwars.game.regeneration.a.this.g(true);
                }
            };
        }
    }
    
    @Override
    protected void s() {
        this.running = false;
    }
    
    @Override
    protected void a(final File file, final c c) {
        ak.a(file, this.a());
        c.a(de.marcely.bedwars.game.regeneration.c.a.a);
    }
    
    private RegionData a() {
        final ArrayList<RBlock> list = new ArrayList<RBlock>();
        final ArrayList<REntity> list2 = new ArrayList<REntity>();
        final XYZ posMin = this.arena.getPosMin();
        final XYZ posMax = this.arena.getPosMax();
        for (int n = (int)posMin.getX(); n < posMax.getX(); ++n) {
            for (int n2 = (int)posMin.getY(); n2 < posMax.getY(); ++n2) {
                for (int n3 = (int)posMin.getZ(); n3 < posMax.getZ(); ++n3) {
                    final Block block = this.arena.getWorld().getBlockAt(n, n2, n3);
                    if (block.getType() != Material.AIR) {
                        list.add(new RBlock(block));
                    }
                }
            }
        }
        for (final Entity entity : this.arena.getWorld().getEntities()) {
            if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM && this.arena.isInside(entity.getLocation())) {
                list2.add(new REntity(entity));
            }
        }
        return new RegionData(list, list2);
    }
    
    static /* synthetic */ void a(final al al, final boolean running) {
        al.running = running;
    }
    
    public static class b
    {
        public static final int J = 50000;
        public final List<RBlock> blocks;
        
        public b(final List<RBlock> blocks) {
            this.blocks = blocks;
        }
        
        public static List<b> a(final List<RBlock> list) {
            final ArrayList<b> list2 = new ArrayList<b>();
            for (int i = 0; i <= list.size() / 50000; ++i) {
                final ArrayList<RBlock> list3 = new ArrayList<RBlock>();
                for (int n = (list.size() - i * 50000 > 50000) ? 50000 : (list.size() - i * 50000), j = 0; j < n; ++j) {
                    list3.add(list.get(i * 50000 + j));
                }
                list2.add(new b(list3));
            }
            return list2;
        }
    }
    
    private static class a
    {
        public final boolean q;
        public final List<b> z;
        public final RegionData b;
        public int C;
        public int G;
        public int H;
        public int I;
        public int D;
        public int E;
        public int F;
        
        public a(final boolean q, final List<b> z, final RegionData b, final int c, final int g, final int h, final int i, final int d, final int e, final int f) {
            this.q = q;
            this.z = z;
            this.b = b;
            this.C = c;
            this.G = g;
            this.H = h;
            this.I = i;
            this.D = d;
            this.E = e;
            this.F = f;
        }
    }
}
