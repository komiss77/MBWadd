// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;

public class dB extends dy
{
    public dB(final Arena arena) {
        super(arena, "teamsize");
    }
    
    @Override
    public String e(final Player player) {
        return new StringBuilder().append(this.arena.getPerTeamPlayers()).toString();
    }
}
