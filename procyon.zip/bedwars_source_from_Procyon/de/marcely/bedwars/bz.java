// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import org.bukkit.GameMode;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Entity;
import org.bukkit.block.Block;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.util.Vector;
import org.bukkit.Location;
import de.marcely.bedwars.game.Team;
import org.bukkit.entity.Player;
import de.marcely.bedwars.achievements.Achievement;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.scheduler.BukkitTask;

public class bz extends by
{
    private BukkitTask d;
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        final int a = s.a(player, ConfigValue.bridge_material);
        if (a == 0) {
            s.a((CommandSender)player, b.a(Language.Bridge_NotEnoughMaterials).a("material", ConfigValue.bridge_material.name().replace("_", "").toLowerCase()));
            this.done();
            return;
        }
        final Team a2 = arena.a(player);
        final Location add = player.getLocation().add(0.0, -1.0, 0.0);
        final Vector vector = add.toVector();
        final int n = (a > ConfigValue.bridge_maxlength) ? ConfigValue.bridge_maxlength : a;
        add.setPitch(0.0f);
        if (n > 0) {
            s.a(player, Achievement.n);
            this.L();
            this.a(arena, player, a2, add, vector, n);
        }
    }
    
    @Override
    public void K() {
        if (this.d != null) {
            this.d.cancel();
        }
    }
    
    private void a(final Arena arena, final Player player, final Team team, final Location location, final Vector vector, final int n) {
        final Location location2 = vector.toLocation(arena.getWorld());
        final Block block = location2.getBlock();
        if (arena.isInside(location2) && s.a(player, ConfigValue.bridge_material) >= 1 && !block.getType().isSolid() && a(location2, arena)) {
            Sound.BRIDGE_BUILD.play(location2);
            for (int i = 0; i < 3; ++i) {
                VarParticle.PARTICLE_CLOUD.play(location2.getWorld(), location2, 1);
            }
            block.setType(ConfigValue.bridge_material);
            de.marcely.bedwars.util.a.a(block, team.getDyeColor());
            s.a(player, ConfigValue.bridge_material);
            if (ConfigValue.destroyblock_builtbyplayers || ConfigValue.tnt_canbreakblocks_breakby_player) {
                arena.b(block);
            }
        }
        if (n > 0) {
            this.d = new BukkitRunnable() {
                public void run() {
                    bz.this.a(arena, player, team, location, ((Vector)team).add(location.getDirection()), n - 1);
                }
            }.runTaskLater((Plugin)MBedwars.a, 2L);
        }
        else {
            this.done();
        }
    }
    
    private static boolean a(final Location location, final Arena arena) {
        if (arena.a(location)) {
            return false;
        }
        for (final Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(location.add(0.5, 0.5, 0.5), 0.5, 0.5, 0.5)) {
            if (!(entity instanceof LivingEntity)) {
                continue;
            }
            if (Version.a().getVersionNumber() >= 8 && entity.getType() == EntityType.PLAYER && ((Player)entity).getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            return false;
        }
        return true;
    }
}
