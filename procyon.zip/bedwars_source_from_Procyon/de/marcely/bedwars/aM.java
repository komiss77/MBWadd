// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.gui.SimpleGUI;
import org.bukkit.event.inventory.InventoryType;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryDragEvent;

public class aM
{
    public static void a(final InventoryDragEvent inventoryDragEvent) {
        final Player player = (Player)inventoryDragEvent.getWhoClicked();
        if (GUI.openInventories.containsKey(player) && inventoryDragEvent.getInventory().getType() != InventoryType.PLAYER && GUI.openInventories.get(player).isCancellable()) {
            inventoryDragEvent.setCancelled(true);
        }
    }
}
