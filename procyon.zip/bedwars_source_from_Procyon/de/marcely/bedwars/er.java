// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.extlibrary.d;

public class er extends ex
{
    public d[] a;
    
    @Override
    public ey a() {
        return ey.f;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.a = new d[bufferedReadStream.readUnsignedByte()];
        for (int i = 0; i < this.a.length; ++i) {
            final d d = new d();
            d.read(bufferedReadStream);
            this.a[i] = d;
        }
    }
}
