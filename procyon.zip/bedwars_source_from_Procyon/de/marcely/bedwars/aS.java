// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.util.s;
import org.bukkit.event.player.PlayerDropItemEvent;

public class aS
{
    public static void a(final PlayerDropItemEvent playerDropItemEvent) {
        final Player player = playerDropItemEvent.getPlayer();
        final Arena a = s.a(player);
        if ((a != null && a.b().F()) || cA.E.containsKey(player)) {
            playerDropItemEvent.setCancelled(true);
        }
        else if (!GUI.openInventories.containsKey(player) && GUI.openInventoriesDelayed.containsKey(player) && GUI.openInventoriesDelayed.get(player).hasAntiDrop()) {
            playerDropItemEvent.getItemDrop().remove();
        }
    }
}
