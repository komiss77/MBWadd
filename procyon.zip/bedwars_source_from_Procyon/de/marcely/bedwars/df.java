// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public enum df
{
    a("WIN", 0), 
    b("LOSE", 1), 
    c("BED_DESTROY", 2), 
    d("KILL_PLAYER", 3);
    
    static {
        a = new df[] { df.a, df.b, df.c, df.d };
    }
    
    private df(final String name, final int ordinal) {
    }
}
