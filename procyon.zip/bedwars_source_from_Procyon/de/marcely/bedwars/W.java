// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.Arrays;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;

@Deprecated
public class W
{
    private static Arena a;
    
    public static List<Arena> b(final String anotherString) {
        final ArrayList<Object> list = new ArrayList<Object>();
        int n2 = 0;
        switch (anotherString) {
            case "%best_lobby%": {
                n2 |= 0x3;
                break;
            }
            case "%random_lobby_joinable%": {
                n2 |= 0x15;
                break;
            }
            case "%random_lobby_running%": {
                n2 |= 0xD;
                break;
            }
            case "%random_lobby%": {
                n2 |= 0x5;
                break;
            }
            case "%random%": {
                n2 |= 0x1;
                break;
            }
            case "%random_ingame%": {
                n2 |= 0x9;
                break;
            }
            default:
                break;
        }
        if ((n2 & 0x1) != 0x1) {
            for (final Arena arena2 : s.af) {
                if (arena2.getName().equalsIgnoreCase(anotherString)) {
                    list.add(arena2);
                }
            }
            return (List<Arena>)list;
        }
        for (final Arena arena3 : s.af) {
            if ((n2 & 0x10) == 0x10 && arena3.getPlayers().size() >= arena3.getMaxPlayers()) {
                continue;
            }
            if ((n2 & 0x4) == 0x4 && arena3.b() != ArenaStatus.e) {
                continue;
            }
            if ((n2 & 0x8) == 0x8 && arena3.b() != ArenaStatus.f) {
                continue;
            }
            list.add(arena3);
        }
        if (list.size() < 2) {
            return (List<Arena>)list;
        }
        if ((n2 & 0x2) == 0x0) {
            return Arrays.asList((Arena)list.get(s.RAND.nextInt(list.size())));
        }
        final int orElse = list.stream().map(arena -> arena.getPlayers().size()).mapToInt(n -> n).max().orElse(-1);
        final Iterator<Arena> iterator3 = list.iterator();
        while (iterator3.hasNext()) {
            if (iterator3.next().getPlayers().size() != orElse) {
                iterator3.remove();
            }
        }
        if (W.a == null || !list.contains(W.a)) {
            W.a = (Arena)list.get(s.RAND.nextInt(list.size()));
        }
        return Arrays.asList(W.a);
    }
}
