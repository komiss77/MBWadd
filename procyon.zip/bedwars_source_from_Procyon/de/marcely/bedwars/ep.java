// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;
import de.marcely.bedwars.extlibrary.d;

public class ep extends ex
{
    public d b;
    public byte z;
    @Nullable
    public byte[] data;
    
    @Override
    public ey a() {
        return ey.h;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        (this.b = new d()).read(bufferedReadStream);
        this.z = bufferedReadStream.readByte();
        this.data = bufferedReadStream.readByteArray();
    }
}
