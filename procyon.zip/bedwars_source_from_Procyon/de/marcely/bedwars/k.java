// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.net.DatagramPacket;

public interface k
{
    void b(final DatagramPacket p0);
}
