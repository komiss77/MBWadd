// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class bT extends bS<Void>
{
    private final String I;
    
    public bT(final String i) {
        this.I = i;
    }
    
    @Override
    public bP.c a() {
        return bP.c.a;
    }
    
    @Override
    public String a(final Void void1) {
        return this.I;
    }
    
    @Override
    public String c(final Arena arena) {
        return this.I;
    }
    
    public String p() {
        return this.I;
    }
}
