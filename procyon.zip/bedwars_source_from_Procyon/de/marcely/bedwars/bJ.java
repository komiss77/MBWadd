// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.d;
import de.marcely.bedwars.util.f;
import java.util.zip.InflaterInputStream;
import java.io.IOException;
import java.io.InputStream;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.io.FileInputStream;
import javax.annotation.Nullable;
import java.util.UUID;
import de.marcely.bedwars.versions.Version;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Deflater;
import java.io.FileOutputStream;
import java.io.File;
import de.marcely.bedwars.util.s;

public class bJ
{
    private static final byte VERSION = 0;
    private static final byte m = 0;
    private static final byte n = 5;
    private static final byte[] a;
    
    static {
        a = new byte[] { 77, 97, 114, 99, 101, 108, 121, 115, 73, 110, 118, 83, 121, 115, 116, 101, 109 };
    }
    
    public static void a(final bI bi) throws Exception {
        a(bi, new File(s.l, String.valueOf(bi.getId().toString()) + ".mlyinv"));
    }
    
    public static void a(final bI bi, final File file) throws Exception {
        final FileOutputStream out = new FileOutputStream(file);
        out.write(bJ.a);
        out.write(0);
        final BufferedWriteStream bufferedWriteStream = new BufferedWriteStream(new DeflaterOutputStream(out, new Deflater(5)));
        try {
            a(bi, bufferedWriteStream);
        }
        catch (Exception ex) {
            bufferedWriteStream.close();
            throw ex;
        }
        bufferedWriteStream.close();
    }
    
    private static void a(final bI bi, final BufferedWriteStream bufferedWriteStream) throws Exception {
        bufferedWriteStream.writeByte((byte)0);
        bufferedWriteStream.writeString(Version.a().a().name());
        bufferedWriteStream.writeString(bi.getId().toString());
        bufferedWriteStream.writeBoolean(bi.isIngame());
        bi.a().write(bufferedWriteStream);
    }
    
    @Nullable
    public static bI a(final bK bk, final UUID uuid) throws Exception {
        final File file = new File(s.l, String.valueOf(uuid.toString()) + ".mlyinv");
        if (!file.exists()) {
            return null;
        }
        return a(bk, file);
    }
    
    public static bI a(final bK bk, final File file) throws Exception {
        if (!file.exists()) {
            throw new IllegalStateException("File does not exist");
        }
        final FileInputStream in = new FileInputStream(file);
        final BufferedReadStream bufferedReadStream = new BufferedReadStream(in);
        if (!bufferedReadStream.readAndCheckMagic(bJ.a)) {
            bufferedReadStream.close();
            throw new IOException("Invalid magic");
        }
        final byte byte1 = bufferedReadStream.readByte();
        if (byte1 < 0 || byte1 > 0) {
            bufferedReadStream.close();
            throw new IOException("Unsupported file version (" + byte1 + ")");
        }
        final byte[] fully = f.readFully(new InflaterInputStream(in), -1, true);
        bufferedReadStream.close();
        return a(bk, new BufferedReadStream(fully));
    }
    
    private static bI a(final bK bk, final BufferedReadStream bufferedReadStream) throws Exception {
        final byte byte1 = bufferedReadStream.readByte();
        if (byte1 < 0 || byte1 > 0) {
            throw new IOException("Unsupported version (" + byte1 + ")");
        }
        bufferedReadStream.readString();
        final UUID fromString = UUID.fromString(bufferedReadStream.readString());
        final boolean boolean1 = bufferedReadStream.readBoolean();
        final d d = (d)Value.a(bufferedReadStream);
        final bI bi = new bI(bk, fromString);
        bi.f(boolean1);
        bi.a(d);
        return bi;
    }
}
