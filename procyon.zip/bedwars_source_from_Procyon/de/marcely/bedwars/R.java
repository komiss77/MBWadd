// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class R
{
    public abstract S a();
    
    public abstract void write(final BufferedWriteStream p0);
    
    public abstract void read(final BufferedReadStream p0);
}
