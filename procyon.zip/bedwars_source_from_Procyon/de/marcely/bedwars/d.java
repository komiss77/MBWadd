// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.sql.SQLException;
import de.marcely.bedwars.game.DropType;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.Bukkit;

public class d
{
    public static void a(final String s) {
        b("");
        b("#########################");
        String[] split;
        for (int length = (split = s.split("\n")).length, i = 0; i < length; ++i) {
            b("# " + split[i]);
        }
        b("#########################");
        b("");
    }
    
    public static void a(final String s, final String s2) {
        c(s, "");
        c(s, "#########################");
        String[] split;
        for (int length = (split = s2.split("\n")).length, i = 0; i < length; ++i) {
            c(s, "# " + split[i]);
        }
        c(s, "#########################");
        c(s, "");
    }
    
    public static void b(final String str) {
        Bukkit.getLogger().warning("[MBedwars] " + str);
    }
    
    public static void c(final String str) {
        Bukkit.getLogger().info("[MBedwars] " + str);
    }
    
    private static void b(final String str, final String str2) {
        Bukkit.getLogger().info("[MBedwars-" + str + "] " + str2);
    }
    
    private static void c(final String str, final String str2) {
        Bukkit.getLogger().warning("[MBedwars-" + str + "] " + str2);
    }
    
    public static void a(final String s, final Arena arena) {
        f(s, arena.getName());
    }
    
    public static void b(final String s, final Arena arena) {
        g(s, arena.getName());
    }
    
    public static void d(final String s, final String str) {
        c("Config-" + str, s);
    }
    
    public static void e(final String s, final String str) {
        b("Config-" + str, s);
    }
    
    public static void f(final String s, final String str) {
        c("Arena-" + str, s);
    }
    
    public static void g(final String s, final String str) {
        b("Arena-" + str, s);
    }
    
    public static void a(final String s, final DropType dropType) {
        c("Itemspawner-" + dropType.getName(), s);
    }
    
    public static void d(final String s) {
        c("BungeeCord", s);
    }
    
    public static void e(final String s) {
        b("BungeeCord", s);
    }
    
    public static void f(final String s) {
        b("SQL", s);
    }
    
    public static void g(final String s) {
        c("SQL", s);
    }
    
    public static void a(final SQLException ex) {
        g("");
        g("An error occured with SQL: ");
        ex.printStackTrace();
        g("");
    }
    
    public static void h(final String s) {
        c("CloudSystem", s);
    }
    
    public static void i(final String s) {
        b("Library", s);
    }
    
    public static void j(final String s) {
        b("Backup", s);
    }
    
    public static void k(final String s) {
        c("InventoryData", s);
    }
    
    public static void l(final String s) {
        b("InventoryData", s);
    }
    
    public static void m(final String s) {
        b("WebService", s);
    }
    
    public static void n(final String s) {
        c("WebService", s);
    }
    
    public static void o(final String s) {
        a("WebService", s);
    }
}
