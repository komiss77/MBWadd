// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;

public class dY
{
    public static final String P = "MBedwars_NI";
    private final Player player;
    private final dZ a;
    private List<eb> listeners;
    private long l;
    
    public dY(final Player player) {
        this.listeners = new ArrayList<eb>();
        this.l = 0L;
        this.player = player;
        if (s.b.a((Class<? extends cR>)cV.class)) {
            this.a = new ec(this);
        }
        else if (Version.a().getVersionNumber() >= 8) {
            this.a = new dX(this);
        }
        else {
            this.a = new dW(this);
        }
    }
    
    public boolean a(final eb eb) {
        return eb != null && this.listeners.add(eb);
    }
    
    public boolean b(final eb eb) {
        return eb != null && this.listeners.remove(eb);
    }
    
    public boolean isInjected() {
        return this.player.isOnline() && this.a.isInjected();
    }
    
    public boolean inject() {
        return this.player.isOnline() && this.a.inject();
    }
    
    public boolean Y() {
        if (!this.player.isOnline()) {
            return false;
        }
        new MThread(MThread.ThreadType.g, this.player.getName()) {
            @Override
            public void run() {
                dY.this.a.Y();
            }
        }.start();
        return true;
    }
    
    public void d(final int n) {
        if (System.currentTimeMillis() - this.l < 200L) {
            return;
        }
        this.l = System.currentTimeMillis();
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            this.listeners.get(i).a(this.player, n);
        }
    }
    
    public void e(final int n) {
        if (System.currentTimeMillis() - this.l < 200L) {
            return;
        }
        this.l = System.currentTimeMillis();
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            this.listeners.get(i).b(this.player, n);
        }
    }
    
    public String[] c(final String s) {
        List<String> a = null;
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            a = this.listeners.get(i).a(this.player, s);
        }
        return (String[])((a != null) ? ((String[])a.toArray(new String[a.size()])) : null);
    }
    
    public boolean a(final float n, final int n2, final float n3) {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            if (this.listeners.get(i).a(this.player, n, n2, n3)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean b(final float n) {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            if (this.listeners.get(i).a(this.player, n)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean a(final long n, final long n2) {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            if (this.listeners.get(i).a(this.player, n, n2)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean a(final int n, final Object o, final Object o2) {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            if (this.listeners.get(i).a(this.player, n, o, o2)) {
                return true;
            }
        }
        return false;
    }
    
    public void a(final int n, final int n2, final boolean b) {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            this.listeners.get(i).a(this.player, n, n2, b);
        }
    }
    
    public boolean Z() {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            if (this.listeners.get(i).a(this.player)) {
                return true;
            }
        }
        return false;
    }
    
    public void ad() {
        for (int i = this.listeners.size() - 1; i >= 0; --i) {
            this.listeners.get(i).b(this.player);
        }
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public dZ a() {
        return this.a;
    }
}
