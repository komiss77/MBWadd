// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;
import org.bukkit.entity.Player;

public abstract class dp extends cR
{
    @Nullable
    public abstract String c(final Player p0);
    
    @Nullable
    public abstract String d(final Player p0);
}
