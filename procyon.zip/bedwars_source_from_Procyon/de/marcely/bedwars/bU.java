// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.r;
import de.marcely.bedwars.game.arena.Arena;

public class bU extends bS<Arena>
{
    public static bU a;
    
    static {
        bU.a = new bU();
    }
    
    @Override
    public bP.c a() {
        return bP.c.e;
    }
    
    @Override
    public String c(final Arena arena) {
        return String.valueOf(r.a(new StringBuilder().append((int)Math.floor(arena.N / 60)).toString(), '0', 2)) + ":" + r.a(new StringBuilder().append(arena.N % 60).toString(), '0', 2);
    }
}
