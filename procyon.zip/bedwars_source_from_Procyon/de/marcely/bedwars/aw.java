// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.server.PluginDisableEvent;

public class aw
{
    public static void a(final PluginDisableEvent pluginDisableEvent) {
        MBedwars.b.remove(pluginDisableEvent.getPlugin());
    }
}
