// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.potion.PotionEffectType;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.util.ArrayList;
import org.bukkit.GameMode;
import java.util.Collection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import java.util.Iterator;
import org.bukkit.Material;
import de.marcely.bedwars.versions.w;
import de.marcely.bedwars.flag.c;
import de.marcely.bedwars.flag.a;
import org.bukkit.potion.PotionEffect;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.flag.e;
import de.marcely.bedwars.flag.j;
import de.marcely.bedwars.flag.h;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.flag.l;
import de.marcely.bedwars.flag.Value;
import de.marcely.bedwars.flag.g;
import de.marcely.bedwars.flag.n;
import org.bukkit.entity.Player;
import de.marcely.bedwars.flag.d;
import java.util.UUID;

public class bI
{
    private final bK a;
    private final UUID b;
    private boolean O;
    private d b;
    
    public bI(final bK bk, final UUID uuid) {
        this(bk, uuid, new d());
    }
    
    public bI(final bK a, final UUID b, final d b2) {
        this.O = false;
        this.a = a;
        this.b = b;
        this.b = b2;
    }
    
    public void save() {
        this.a.b(this);
    }
    
    public void v(final Player player) {
        try {
            this.w(player);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void w(final Player player) throws Exception {
        this.b.clear();
        this.b.a(new g("Username", new n(player.getName())));
        this.b.a(new g("FetchTime", new l(System.currentTimeMillis())));
        final d d = new d();
        d.a(new g("GameMode", new n(player.getGameMode().name())));
        d.a(new g("Health", new h((float)de.marcely.bedwars.util.b.a(player))));
        d.a(new g("Hunger", new j(player.getFoodLevel())));
        d.a(new g("Exhaustion", new h(player.getExhaustion())));
        d.a(new g("Saturation", new h(player.getSaturation())));
        d.a(new g("Level", new j(player.getLevel())));
        d.a(new g("LevelEXP", new h(player.getExp())));
        d.a(new g("FallDistance", new h(player.getFallDistance())));
        d.a(new g("FireTicks", new j(player.getFireTicks())));
        final e e = new e();
        final Iterator<de.marcely.bedwars.versions.b> iterator = Version.a().a(player).iterator();
        while (iterator.hasNext()) {
            e.a(iterator.next().b());
        }
        d.a(new g("Attributes", e));
        d.a(new g("Abilities", Version.a().a(player)));
        final e e2 = new e();
        for (final PotionEffect obj : player.getActivePotionEffects()) {
            final d d2 = new d();
            d2.a(new g("Type", new n(obj.getType().getName())));
            d2.a(new g("Duration", new j(obj.getDuration())));
            d2.a(new g("Amplifier", new j(obj.getAmplifier())));
            d2.a(new g("IsAmbient", new a(obj.isAmbient())));
            if (Version.a().getVersionNumber() >= 8) {
                d2.a(new g("HasParticles", new a(obj.hasParticles())));
            }
            if (Version.a().getVersionNumber() >= 13) {
                d2.a(new g("HasIcon", new a((boolean)PotionEffect.class.getMethod("hasIcon", (Class<?>[])new Class[0]).invoke(obj, new Object[0]))));
            }
            e2.a(d2);
        }
        d.a(new g("ActiveEffects", e2));
        final d d3 = new d();
        final PlayerInventory inventory = player.getInventory();
        final e e3 = new e();
        final e e4 = new e();
        d3.a(new g("Size", new c((byte)(inventory.getSize() & 0xFF))));
        for (int i = 0; i < inventory.getSize(); ++i) {
            final ItemStack item = inventory.getItem(i);
            if (item != null) {
                if (Version.a().a() instanceof w) {
                    if (((w)Version.a().a()).c(item).equals("air")) {
                        continue;
                    }
                }
                else if (item.getType() == Material.AIR) {
                    continue;
                }
                final d d4 = new d();
                d4.a(new g("Slot", new c((byte)(i & 0xFF))));
                d4.a(new g("Data", Version.a().a(item)));
                e3.a(d4);
            }
        }
        for (int j = 0; j < inventory.getArmorContents().length; ++j) {
            final ItemStack itemStack = inventory.getArmorContents()[j];
            if (itemStack != null) {
                if (itemStack.getType() != Material.AIR) {
                    final d d5 = new d();
                    d5.a(new g("Slot", new c((byte)(j & 0xFF))));
                    d5.a(new g("Data", Version.a().a(itemStack)));
                    e4.a(d5);
                }
            }
        }
        d3.a(new g("Content", e3));
        d3.a(new g("ArmorContent", e4));
        d.a(new g("Inventory", d3));
        this.b.a(new g("WorldData", d));
    }
    
    public void x(final Player player) {
        try {
            this.y(player);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void y(final Player player) throws Exception {
        for (final g g : this.b.getValue()) {
            final String key;
            switch ((key = g.getKey()).hashCode()) {
                case -1168669124: {
                    if (!key.equals("WorldData")) {
                        continue;
                    }
                    this.a(player, g.a(d.class));
                    continue;
                }
                default: {
                    continue;
                }
            }
        }
    }
    
    private void a(final Player player, final d d) throws Exception {
        for (final g g : d.getValue()) {
            final String key;
            switch ((key = g.getKey()).hashCode()) {
                case -2137395588: {
                    if (!key.equals("Health")) {
                        continue;
                    }
                    player.setHealth((double)g.a(h.class).getValue());
                    continue;
                }
                case -2122237229: {
                    if (!key.equals("Hunger")) {
                        continue;
                    }
                    player.setFoodLevel((int)g.a(j.class).getValue());
                    continue;
                }
                case -2067007463: {
                    if (!key.equals("LevelEXP")) {
                        continue;
                    }
                    player.setExp((float)g.a(h.class).getValue());
                    continue;
                }
                case -1895856777: {
                    if (!key.equals("Attributes")) {
                        continue;
                    }
                    this.a(player, g.a(e.class));
                    continue;
                }
                case -1704717099: {
                    if (!key.equals("GameMode")) {
                        continue;
                    }
                    final GameMode a = de.marcely.bedwars.util.b.a((String)g.a(n.class).getValue());
                    if (a != null) {
                        player.setGameMode(a);
                        continue;
                    }
                    player.setGameMode(GameMode.ADVENTURE);
                    continue;
                }
                case -632618200: {
                    if (!key.equals("Abilities")) {
                        continue;
                    }
                    Version.a().c(player, g.a(d.class));
                    continue;
                }
                case -16631492: {
                    if (!key.equals("Inventory")) {
                        continue;
                    }
                    this.b(player, g.a(d.class));
                    continue;
                }
                case 73313124: {
                    if (!key.equals("Level")) {
                        continue;
                    }
                    player.setLevel((int)g.a(j.class).getValue());
                    continue;
                }
                case 908161200: {
                    if (!key.equals("FallDistance")) {
                        continue;
                    }
                    player.setFallDistance((float)g.a(h.class).getValue());
                    continue;
                }
                case 1690834622: {
                    if (!key.equals("Exhaustion")) {
                        continue;
                    }
                    player.setExhaustion((float)g.a(h.class).getValue());
                    continue;
                }
                case 1707249088: {
                    if (!key.equals("FireTicks")) {
                        continue;
                    }
                    player.setFireTicks((int)g.a(j.class).getValue());
                    continue;
                }
                case 1762973682: {
                    if (!key.equals("Saturation")) {
                        continue;
                    }
                    player.setSaturation((float)g.a(h.class).getValue());
                    continue;
                }
                case 2080567036: {
                    if (!key.equals("ActiveEffects")) {
                        continue;
                    }
                    this.b(player, g.a(e.class));
                    continue;
                }
                default: {
                    continue;
                }
            }
        }
    }
    
    private void a(final Player player, final e e) {
        final ArrayList<de.marcely.bedwars.versions.b> list = new ArrayList<de.marcely.bedwars.versions.b>(((Value<Collection>)e).getValue().size());
        final Iterator<Value> iterator = ((Value<Collection<Value>>)e).getValue().iterator();
        while (iterator.hasNext()) {
            list.add(de.marcely.bedwars.versions.b.a((d)iterator.next()));
        }
        Version.a().c(player, list);
    }
    
    private void b(final Player player, final e e) throws Exception {
        final Iterator<PotionEffect> iterator = player.getActivePotionEffects().iterator();
        while (iterator.hasNext()) {
            player.removePotionEffect(iterator.next().getType());
        }
        for (final d d : ((Value<Collection<Value>>)e).getValue()) {
            PotionEffectType a = null;
            int intValue = 0;
            int intValue2 = 0;
            boolean booleanValue = false;
            boolean booleanValue2 = false;
            boolean booleanValue3 = false;
            for (final g g : d.getValue()) {
                final String key;
                switch ((key = g.getKey()).hashCode()) {
                    case -1933705709: {
                        if (!key.equals("HasIcon")) {
                            continue;
                        }
                        booleanValue3 = g.a(a.class).getValue();
                        continue;
                    }
                    case -1927368268: {
                        if (!key.equals("Duration")) {
                            continue;
                        }
                        intValue = g.a(j.class).getValue();
                        continue;
                    }
                    case -1019399599: {
                        if (!key.equals("Amplifier")) {
                            continue;
                        }
                        intValue2 = g.a(j.class).getValue();
                        continue;
                    }
                    case 2622298: {
                        if (!key.equals("Type")) {
                            continue;
                        }
                        a = de.marcely.bedwars.util.b.a((String)g.a(n.class).getValue());
                        continue;
                    }
                    case 532044270: {
                        if (!key.equals("IsAmbient")) {
                            continue;
                        }
                        booleanValue = g.a(a.class).getValue();
                        continue;
                    }
                    case 1572835667: {
                        if (!key.equals("HasParticles")) {
                            continue;
                        }
                        booleanValue2 = g.a(a.class).getValue();
                        continue;
                    }
                    default: {
                        continue;
                    }
                }
            }
            if (a == null) {
                continue;
            }
            final PotionEffect potionEffect = new PotionEffect(a, intValue, intValue2, booleanValue);
            if (Version.a().getVersionNumber() >= 8 && booleanValue2) {
                s.a(potionEffect.getClass(), "particles").set(potionEffect, booleanValue2);
            }
            if (Version.a().getVersionNumber() >= 13 && booleanValue3) {
                s.a(potionEffect.getClass(), "icon").set(potionEffect, booleanValue3);
            }
            player.addPotionEffect(potionEffect, true);
        }
    }
    
    private void b(final Player player, final d d) {
        final PlayerInventory inventory = player.getInventory();
        final e e = d.a("Content").a(e.class);
        final e e2 = d.a("ArmorContent").a(e.class);
        final ItemStack[] armorContents = new ItemStack[inventory.getArmorContents().length];
        inventory.clear();
        for (final d d2 : ((Value<Collection<Value>>)e).getValue()) {
            final int n = d2.a("Slot").a(c.class).getValue() & 0xFF;
            if (n < inventory.getSize()) {
                if (n < 0) {
                    continue;
                }
                inventory.setItem(n, Version.a().a(d2.a("Data").a(d.class)));
            }
        }
        for (final d d3 : ((Value<Collection<Value>>)e2).getValue()) {
            final int n2 = d3.a("Slot").a(c.class).getValue() & 0xFF;
            if (n2 < armorContents.length) {
                if (n2 < 0) {
                    continue;
                }
                armorContents[n2] = Version.a().a(d3.a("Data").a(d.class));
            }
        }
        inventory.setArmorContents(armorContents);
    }
    
    public UUID getId() {
        return this.b;
    }
    
    public boolean isIngame() {
        return this.O;
    }
    
    public void f(final boolean o) {
        this.O = o;
    }
    
    public d a() {
        return this.b;
    }
    
    public void a(final d b) {
        this.b = b;
    }
}
