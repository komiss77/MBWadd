// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketException;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFrame;
import java.util.List;
import java.util.Map;
import de.marcely.bedwars.extlibrary.d;
import java.io.IOException;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketListener;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketFactory;
import java.net.URI;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocket;
import de.marcely.bedwars.com.neovisionaries.ws.client.WebSocketAdapter;

public abstract class ei extends WebSocketAdapter
{
    private final WebSocket a;
    private final el a;
    private boolean aq;
    
    public ei(final URI uri) throws IOException {
        this.aq = false;
        this.a = new WebSocketFactory().createSocket(uri);
        ((WebSocket)(this.a = new el(this))).addListener((WebSocketListener)this);
    }
    
    public abstract void onConnect();
    
    public abstract void b(final a p0);
    
    public abstract void a(final d[] p0);
    
    public abstract void a(final boolean p0, final String p1);
    
    public void onConnected(final WebSocket webSocket, final Map<String, List<String>> map) {
        this.a.run();
    }
    
    public void onDisconnected(final WebSocket webSocket, final WebSocketFrame webSocketFrame, final WebSocketFrame webSocketFrame2, final boolean b) {
        if (this.aq) {
            return;
        }
        try {
            if (b) {
                this.b(ei.a.g);
            }
            else {
                this.b(ei.a.f);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.aq = true;
    }
    
    public void onConnectError(final WebSocket webSocket, final WebSocketException ex) throws Exception {
        ex.printStackTrace();
    }
    
    public void onError(final WebSocket webSocket, final WebSocketException ex) throws Exception {
        ex.printStackTrace();
    }
    
    public void onBinaryMessage(final WebSocket webSocket, final byte[] array) throws Exception {
        this.a.a(array);
    }
    
    public boolean isConnected() {
        return this.a.isOpen();
    }
    
    public void connect() {
        this.aq = false;
        try {
            this.a.connect();
        }
        catch (WebSocketException ex) {
            this.b(ei.a.h);
        }
    }
    
    public void a(final a a) {
        if (!this.aq) {
            try {
                this.b(a);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        this.aq = true;
        this.a.a((a)null);
        this.a.disconnect();
    }
    
    public WebSocket a() {
        return this.a;
    }
    
    public el a() {
        return this.a;
    }
    
    public enum a
    {
        a("LOGIN_FAIL_TIME_OUT", 0), 
        b("LOGIN_FAIL_BANNED", 1), 
        c("LOGIN_FAIL_ERROR", 2), 
        d("LOGIN_FAIL_UNSUPPORTED_PROTOCOL", 3), 
        e("LOGIN_FAIL_UNSUPPORTED_BEDWARS", 4), 
        f("SELF_DISCONNECT", 5), 
        g("REMOTE_DISCONNECT", 6), 
        h("CONNECT_ERROR", 7), 
        i("UNKOWN", 8);
        
        static {
            a = new a[] { ei.a.a, ei.a.b, ei.a.c, ei.a.d, ei.a.e, ei.a.f, ei.a.g, ei.a.h, ei.a.i };
        }
        
        private a(final String name, final int ordinal) {
        }
    }
}
