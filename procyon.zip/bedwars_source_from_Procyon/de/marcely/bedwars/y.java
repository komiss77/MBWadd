// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.Arena;

public class y extends j
{
    private Arena arena;
    private ArenaStatus a;
    
    public y(final Arena arena, final ArenaStatus a) {
        this.arena = arena;
        this.a = a;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public ArenaStatus a() {
        return this.a;
    }
    
    @Override
    public String d() {
        return String.valueOf(j.a.j.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.a.getID();
    }
}
