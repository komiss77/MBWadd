// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class bW extends bZ
{
    public static bW a;
    
    static {
        bW.a = new bW();
    }
    
    @Override
    public bP.c a() {
        return bP.c.a;
    }
    
    @Override
    public String c(final Arena arena) {
        return new StringBuilder().append(arena.getMaxPlayers()).toString();
    }
}
