// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class es extends ex
{
    public static final byte A = 0;
    public byte k;
    public byte B;
    public String aa;
    public String ab;
    
    @Override
    public ey a() {
        return ey.a;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.k);
        bufferedWriteStream.writeByte(this.B);
        bufferedWriteStream.writeString(this.aa);
        bufferedWriteStream.writeString(this.ab);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
    }
}
