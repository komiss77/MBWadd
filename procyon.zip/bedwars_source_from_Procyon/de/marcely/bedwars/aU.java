// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.GameMode;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

public class aU
{
    public static void a(final PlayerGameModeChangeEvent playerGameModeChangeEvent) {
        final GameMode newGameMode = playerGameModeChangeEvent.getNewGameMode();
        if (ConfigValue.anticheat_enabled && s.a(playerGameModeChangeEvent.getPlayer()) != null && (newGameMode == GameMode.CREATIVE || newGameMode == GameMode.SPECTATOR)) {
            playerGameModeChangeEvent.setCancelled(true);
        }
    }
}
