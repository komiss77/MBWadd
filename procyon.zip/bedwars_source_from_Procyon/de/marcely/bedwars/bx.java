// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.i;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.message.b;
import org.bukkit.command.CommandSender;
import javax.annotation.Nullable;
import org.bukkit.Material;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.inventory.ItemStack;

public enum bx
{
    b("TELEPORTER", 0), 
    c("MINI_SHOP", 1), 
    d("RESCUE_PLATFORM", 2), 
    e("TNT_SHEEP", 3), 
    f("MAGNET_SHOES", 4), 
    g("TRAP", 5), 
    h("BRIDGE", 6), 
    i("GUARD_DOG", 7), 
    j("TRACKER", 8);
    
    private final bv a;
    private static /* synthetic */ int[] n;
    
    static {
        a = new bx[] { bx.b, bx.c, bx.d, bx.e, bx.f, bx.g, bx.h, bx.i, bx.j };
    }
    
    private bx(final String name, final int ordinal) {
        this.a = new bv(this, null);
    }
    
    public ItemStack getItemStack() {
        switch (o()[this.ordinal()]) {
            case 1: {
                return ConfigValue.teleporter_item.clone();
            }
            case 2: {
                return ConfigValue.minishop_item.clone();
            }
            case 3: {
                return ConfigValue.rescueplatform_item.clone();
            }
            case 4: {
                return ConfigValue.tntsheep_item.clone();
            }
            case 5: {
                return ConfigValue.magneticshoes_item.clone();
            }
            case 6: {
                return ConfigValue.trap_item.clone();
            }
            case 7: {
                return ConfigValue.bridge_item.clone();
            }
            case 8: {
                return ConfigValue.guarddog_item.clone();
            }
            case 9: {
                return new ItemStack(Material.COMPASS);
            }
            default: {
                return null;
            }
        }
    }
    
    @Nullable
    public by a() {
        switch (o()[this.ordinal()]) {
            case 1: {
                return new bF();
            }
            case 2: {
                return new bB();
            }
            case 3: {
                return new bD();
            }
            case 4: {
                return new bE();
            }
            case 6: {
                return new bH();
            }
            case 7: {
                return new bz();
            }
            case 8: {
                return new bA();
            }
            case 9: {
                return new bG();
            }
            default: {
                return null;
            }
        }
    }
    
    public String e(@Nullable final CommandSender commandSender) {
        final Language language = Language.getLanguage("Shop_Item_" + this.name().replace("_", ""));
        if (language == null) {
            throw new IllegalStateException("Message entry of item " + this.name().replace("_", "") + " doesn't exist");
        }
        return de.marcely.bedwars.message.b.a(language).f(commandSender);
    }
    
    public ExtraItem getExtraItem() {
        this.a.setItemStack(this.getItemStack());
        return this.a;
    }
    
    public static bx a(final ItemStack itemStack) {
        bx[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final bx bx = values[i];
            if (de.marcely.bedwars.util.i.a(bx.getItemStack(), itemStack)) {
                return bx;
            }
        }
        return null;
    }
    
    static /* synthetic */ int[] o() {
        final int[] n = bx.n;
        if (n != null) {
            return n;
        }
        final int[] n2 = new int[values().length];
        try {
            n2[bx.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            n2[bx.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            n2[bx.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            n2[bx.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            n2[bx.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            n2[bx.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            n2[bx.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            n2[bx.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            n2[bx.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        return bx.n = n2;
    }
}
