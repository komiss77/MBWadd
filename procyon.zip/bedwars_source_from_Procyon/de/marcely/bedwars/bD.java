// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Color;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import java.util.List;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.scheduler.BukkitTask;

public class bD extends by
{
    private BukkitTask d;
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        final Location clone = player.getLocation().clone();
        if (clone.getY() < 0.0 || clone.getY() >= arena.getWorld().getMaxHeight()) {
            this.done();
            return;
        }
        final List<Block> a = arena.a(clone.add(0.0, -2.0, 0.0), ConfigValue.rescueplatform_material, ConfigValue.rescueplatform_width);
        if (a.size() == 0) {
            this.done();
            return;
        }
        s.a(player, Achievement.g);
        Sound.EXTRAITEM_RESCUEPLATFORM_USE.play(player);
        this.L();
        if (ConfigValue.rescueplatform_autobreak_enabled) {
            this.d = new BukkitRunnable() {
                public void run() {
                    bD.this.c(a);
                }
            }.runTaskLater((Plugin)MBedwars.a, (long)(ConfigValue.rescueplatform_autobreak_time * 20));
        }
        else {
            this.done();
        }
    }
    
    @Override
    public void K() {
        if (this.d != null) {
            this.d.cancel();
        }
    }
    
    private void c(final List<Block> list) {
        this.d = new BukkitRunnable() {
            public void run() {
                if (list.size() == 0) {
                    by.this.done();
                    return;
                }
                final Block block = list.remove(s.RAND.nextInt(list.size()));
                if (block.getType() == ConfigValue.rescueplatform_material) {
                    block.setType(Material.AIR);
                    VarParticle.PARTICLE_COLOURED.play(block.getWorld(), block.getLocation().add(0.5, 0.5, 0.5), Color.GREEN);
                    Sound.EXTRAITEM_RESCUEPLATFORM_AUTOBREAK.play(block.getLocation());
                }
            }
        }.runTaskTimer((Plugin)MBedwars.a, 5L, 5L);
    }
}
