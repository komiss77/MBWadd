// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.inventory.meta.ItemMeta;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.shop.ShopProduct;
import java.util.List;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.event.player.PlayerPickupItemEvent;

public class ba
{
    public static void b(final PlayerPickupItemEvent playerPickupItemEvent) {
        final Player player = playerPickupItemEvent.getPlayer();
        final ItemStack itemStack = playerPickupItemEvent.getItem().getItemStack();
        final Arena a = s.a(player);
        if (cA.E.containsKey(player)) {
            playerPickupItemEvent.setCancelled(true);
        }
        else if (a != null) {
            if (a.b().F()) {
                playerPickupItemEvent.setCancelled(true);
            }
            else if (a.b() == ArenaStatus.f) {
                final List<ShopProduct> list = s.W.get(playerPickupItemEvent.getItem().getItemStack().getType());
                if (list != null && list.size() == 1) {
                    playerPickupItemEvent.getItem().setItemStack(list.get(0).getGiveItem(itemStack, player, a.a(player), itemStack.getAmount(), a));
                }
            }
        }
        final List lore = playerPickupItemEvent.getItem().getItemStack().getItemMeta().getLore();
        if (lore != null && lore.size() == 1 && s.isInteger(lore.get(0))) {
            final ItemMeta itemMeta = itemStack.getItemMeta();
            itemMeta.setLore((List)null);
            itemStack.setItemMeta(itemMeta);
        }
    }
}
