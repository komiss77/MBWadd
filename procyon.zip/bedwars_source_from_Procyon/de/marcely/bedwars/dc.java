// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import com.google.gson.JsonObject;
import de.devcubehd.cloudsystem.api.Ping;
import de.devcubehd.cloudsystem.api.CloudSystemAPI;

public class dc extends cZ
{
    @Override
    public cT a() {
        return cT.d;
    }
    
    @Override
    public void onEnable() {
        CloudSystemAPI.getPingAPI().setPing((Ping)new Ping() {
            public JsonObject ping() {
                final JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("packet", "PING");
                final Arena b = s.b(ConfigValue.cloudsystem_arena);
                if (b == null) {
                    d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
                }
                if (b != null) {
                    jsonObject.addProperty("players", (Number)b.getPlayers().size());
                    jsonObject.addProperty("maxplayers", (Number)b.getMaxPlayers());
                    jsonObject.addProperty("status", b.b().name());
                    jsonObject.addProperty("extra", ConfigValue.cloudsystem_extra.a(b));
                }
                else {
                    jsonObject.addProperty("players", (Number)(-1));
                    jsonObject.addProperty("maxplayers", (Number)(-1));
                    jsonObject.addProperty("status", "MBW: WARNING");
                    jsonObject.addProperty("extra", "Only 1 Arena!");
                }
                return jsonObject;
            }
        });
    }
    
    @Override
    public void onDisable() {
    }
}
