// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.m;

public abstract class cm extends bS<m>
{
    @Override
    public bP.c a() {
        return bP.c.b;
    }
    
    @Override
    public String c(final Arena arena) {
        return null;
    }
}
