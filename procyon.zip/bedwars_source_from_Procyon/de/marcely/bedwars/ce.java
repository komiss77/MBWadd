// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class ce extends ch
{
    public static ce a;
    
    static {
        ce.a = new ce();
    }
    
    @Override
    protected String a(final c c) {
        return new StringBuilder().append(c.getDeaths()).toString();
    }
}
