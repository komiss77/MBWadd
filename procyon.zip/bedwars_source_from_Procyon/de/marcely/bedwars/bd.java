// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Location;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import org.bukkit.event.player.PlayerRespawnEvent;

public class bd
{
    public static void a(final PlayerRespawnEvent playerRespawnEvent) {
        final Player player = playerRespawnEvent.getPlayer();
        if (cA.E.containsKey(player)) {
            final Arena arena = cA.E.get(player).getArena();
            if (arena.isInside(player.getLocation())) {
                playerRespawnEvent.setRespawnLocation(player.getLocation());
            }
            else {
                final Location a = cA.a(arena);
                if (a != null) {
                    playerRespawnEvent.setRespawnLocation(a);
                }
                else {
                    s.a((CommandSender)player, b.a(Language.SpectatorAdd_Failed_MissingLocation));
                }
            }
        }
        else {
            final Arena a2 = s.a(player);
            if (a2 != null) {
                a2.a(player, playerRespawnEvent);
            }
        }
    }
}
