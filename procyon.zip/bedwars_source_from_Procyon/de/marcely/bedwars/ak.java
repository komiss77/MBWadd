// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.MThread;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import de.marcely.bedwars.game.arena.Arena;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import de.marcely.bedwars.game.regeneration.RegionData;
import java.io.File;

@Deprecated
public class ak
{
    public static void onEnable() {
    }
    
    public static void a(final File file, final RegionData obj) {
        try {
            final ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(file));
            objectOutputStream.writeObject(obj);
            objectOutputStream.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static RegionData a(final File file, final Arena arena) {
        try {
            final ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file));
            final RegionData regionData = (RegionData)objectInputStream.readObject();
            objectInputStream.close();
            return regionData;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static boolean d(final String str) {
        final File file = new File("plugins/MBedwars/data/arenablocks/" + str + ".yml");
        if (file.exists()) {
            file.delete();
            return true;
        }
        return false;
    }
    
    public static boolean exists(final String str) {
        return new File("plugins/MBedwars/data/arenablocks/" + str + ".yml").exists();
    }
    
    public static void a(final a a, final File file, final Arena arena) {
        new MThread(MThread.ThreadType.m, arena.getName()) {
            @Override
            public void run() {
                a.a(ak.a(file, arena));
            }
        }.start();
    }
    
    @Deprecated
    public abstract static class a
    {
        public abstract void a(final RegionData p0);
    }
}
