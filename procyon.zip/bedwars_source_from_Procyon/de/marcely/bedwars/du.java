// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;

public abstract class du extends cR
{
    public abstract String a(final Player p0, final String p1);
    
    public abstract void a(final dD p0);
    
    public abstract void b(final dD p0);
    
    public abstract void Z();
}
