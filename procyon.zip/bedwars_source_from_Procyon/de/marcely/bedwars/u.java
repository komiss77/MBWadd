// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class u extends j
{
    private Arena arena;
    private String i;
    
    public u(final Arena arena, final String i) {
        this.arena = arena;
        this.i = i;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public String getTo() {
        return this.i;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.n.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.i.replace("/", "&sKEYslash;");
    }
}
