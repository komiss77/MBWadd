// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import java.util.Iterator;
import de.marcely.bedwars.game.location.XYZYP;
import java.util.Map;
import java.util.ArrayList;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Slime;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ArmorStand;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Ageable;
import java.util.UUID;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.Tameable;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.event.HandlerList;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Creature;
import org.bukkit.scheduler.BukkitTask;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.event.Listener;

public class bA extends by implements Listener
{
    private Arena arena;
    private Team team;
    private BukkitTask d;
    private Creature a;
    private LivingEntity a;
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Block clickedBlock = playerUseExtraItemEvent.getClickedBlock();
        final BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (clickedBlock == null) {
            this.done();
            return;
        }
        this.arena = (Arena)playerUseExtraItemEvent.getArena();
        this.team = this.arena.a(player);
        s.a(player, Achievement.o);
        final Location location = clickedBlock.getLocation();
        final Location location2 = new Location(location.getWorld(), location.getX() + blockFace.getModX(), location.getY() + blockFace.getModY(), location.getZ() + blockFace.getModZ());
        this.L();
        this.a(location2);
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }
    
    @Override
    public void K() {
        HandlerList.unregisterAll((Listener)this);
        if (this.a != null) {
            this.a.remove();
            this.d.cancel();
        }
    }
    
    private void a(final Location location) {
        final Entity spawnEntity = location.getWorld().spawnEntity(location, ConfigValue.guarddog_type);
        if (spawnEntity instanceof Creature) {
            final Creature a = (Creature)spawnEntity;
            a.setMaxHealth(20.0);
            a.setHealth(20.0);
            a.setRemoveWhenFarAway(false);
            this.a = a;
            if (spawnEntity instanceof Tameable) {
                final Tameable tameable = (Tameable)spawnEntity;
                tameable.setTamed(true);
                tameable.setOwner((AnimalTamer)new AnimalTamer() {
                    public String getName() {
                        return "_I HAVE NO OWNER RIP 2k18_";
                    }
                    
                    public UUID getUniqueId() {
                        return UUID.randomUUID();
                    }
                });
            }
            if (spawnEntity instanceof Ageable) {
                ((Ageable)spawnEntity).setAdult();
            }
            if (spawnEntity instanceof Wolf) {
                ((Wolf)spawnEntity).setCollarColor(this.team.getDyeColor());
            }
            if (s.a(spawnEntity)) {
                Version.a().c(spawnEntity);
            }
            this.d = new BukkitRunnable() {
                public void run() {
                    bA.this.tick();
                }
            }.runTaskTimer((Plugin)MBedwars.a, 0L, 30L);
            if (Version.a().getVersionNumber() >= 8) {
                final ArmorStand a2 = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
                a2.setSmall(true);
                a2.setMarker(true);
                a2.setVisible(false);
                this.a = (LivingEntity)a2;
            }
            else {
                final Slime a3 = (Slime)location.getWorld().spawnEntity(location, EntityType.SLIME);
                a3.setSize(0);
                Version.a().b((Entity)a3, true);
                a3.setHealth(Double.MAX_VALUE);
                this.a = (LivingEntity)a3;
            }
            return;
        }
        de.marcely.bedwars.d.d("guarddog-type: " + ConfigValue.guarddog_type + " isn't a creature! Guarddogs don't spawn because of that.", "Main");
        this.done();
    }
    
    private void tick() {
        if (this.a.isDead() || this.a.getWorld() != this.arena.getWorld()) {
            this.done();
            return;
        }
        final ArrayList<LivingEntity> list = new ArrayList<LivingEntity>(this.arena.getPlayers().size());
        for (final Map.Entry<Player, Team> entry : this.arena.l.entrySet()) {
            final Player player3 = entry.getKey();
            if (this.team != entry.getValue() && player3.getWorld() == this.a.getWorld() && player3.getLocation().distance(this.a.getLocation()) <= 12.0 && !cA.E.containsKey(player3)) {
                list.add((LivingEntity)player3);
            }
        }
        if (list.size() >= 1) {
            if (list.size() >= 2) {
                list.sort((player, player2) -> Double.compare(player.getLocation().distance(this.a.getLocation()), player2.getLocation().distance(this.a.getLocation())));
            }
            this.a.setTarget((LivingEntity)list.get(0));
            return;
        }
        final Location bukkit = this.arena.a().d().get(this.team).toBukkit(this.arena.getWorld());
        if (bukkit != null) {
            if (this.a.getLocation().distance(bukkit) >= 32.0) {
                this.a.teleport(s.b(bukkit.clone().add(0.0, 1.0, 0.0)));
                return;
            }
            if (this.a.getLocation().distance(bukkit) >= 8.0) {
                this.b(bukkit);
                return;
            }
        }
        this.a.setTarget((LivingEntity)null);
    }
    
    private void b(final Location location) {
        this.a.teleport(location);
        this.a.setTarget(this.a);
    }
    
    @EventHandler
    public void a(final EntityDamageEvent entityDamageEvent) {
        if (entityDamageEvent.getEntity() == this.a) {
            final EntityDamageEvent.DamageCause cause = entityDamageEvent.getCause();
            if (cause == EntityDamageEvent.DamageCause.VOID || cause == EntityDamageEvent.DamageCause.FALL) {
                entityDamageEvent.setCancelled(true);
            }
        }
    }
    
    @EventHandler
    public void a(final EntityTargetEvent entityTargetEvent) {
        if (entityTargetEvent.getEntity() == this.a && entityTargetEvent.getTarget() instanceof Player) {
            final Team a = this.arena.a((Player)entityTargetEvent.getTarget());
            if (a != null && a == this.team) {
                entityTargetEvent.setCancelled(true);
            }
        }
    }
}
