// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.shop.ShopDesignType;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.configmanager2.ConfigManager;

@Deprecated
public class ao
{
    public static ConfigManager a;
    public static ShopDesignData a;
    
    static {
        ao.a = new ConfigManager(s.A);
        ao.a = ShopDesignType.Normal.getData();
    }
}
