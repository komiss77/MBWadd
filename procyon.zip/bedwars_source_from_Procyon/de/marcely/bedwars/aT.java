// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.player.PlayerExpChangeEvent;

public class aT
{
    public static void a(final PlayerExpChangeEvent playerExpChangeEvent) {
        if (cA.E.containsKey(playerExpChangeEvent.getPlayer())) {
            playerExpChangeEvent.setAmount(0);
        }
    }
}
