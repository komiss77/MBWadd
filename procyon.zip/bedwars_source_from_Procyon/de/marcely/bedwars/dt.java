// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;

public class dt extends du
{
    private a a;
    
    @Override
    public cT a() {
        return cT.n;
    }
    
    @Override
    public void onEnable() {
        this.a = new a(null);
        if (this.a.register()) {
            d.c("Successfully hooked to PlaceholderAPI");
        }
        else {
            d.c("Failed to hook into PlaceholderAPI");
        }
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String a(final Player player, final String s) {
        return PlaceholderAPI.setPlaceholders(player, s);
    }
    
    @Override
    public void a(final dD dd) {
        this.a.c(dd);
    }
    
    @Override
    public void b(final dD dd) {
        this.a.d(dd);
    }
    
    @Override
    public void Z() {
        PlaceholderAPI.unregisterExpansion((PlaceholderExpansion)this.a);
        this.a.aa();
    }
    
    private static class a extends PlaceholderExpansion
    {
        private final List<dD> ab;
        
        private a() {
            this.ab = new ArrayList<dD>();
        }
        
        public boolean Q() {
            return true;
        }
        
        public boolean canRegister() {
            return true;
        }
        
        public String getAuthor() {
            return "Marcely's Bedwars Team";
        }
        
        public String getIdentifier() {
            return "mbedwars";
        }
        
        public String getVersion() {
            return MBedwars.getVersion();
        }
        
        public String onPlaceholderRequest(final Player player, final String anObject) {
            for (final dD dd : this.ab) {
                if (dd.getIdentifier().equals(anObject)) {
                    return dd.e(player);
                }
            }
            return null;
        }
        
        public void c(final dD dd) {
            this.ab.add(dd);
        }
        
        public void d(final dD dd) {
            this.ab.remove(dd);
        }
        
        public void aa() {
            this.ab.clear();
        }
    }
}
