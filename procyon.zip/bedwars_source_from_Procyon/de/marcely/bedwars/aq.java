// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.ArrayList;
import org.bukkit.Material;
import java.util.List;
import org.bukkit.inventory.ItemStack;

@Deprecated
public class aq implements Cloneable
{
    private String name;
    private String v;
    private ItemStack icon;
    private List<ItemStack> prices;
    private List<ap> products;
    
    public aq(final String name) {
        this.icon = new ItemStack(Material.STONE);
        this.prices = new ArrayList<ItemStack>();
        this.products = new ArrayList<ap>();
        this.setName(name);
        this.s(name);
    }
    
    public aq(final String s, final Material material) {
        this.icon = new ItemStack(Material.STONE);
        this.prices = new ArrayList<ItemStack>();
        this.products = new ArrayList<ap>();
        this.name = s;
        this.v = s;
        this.icon = new ItemStack(material);
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public void s(final String v) {
        this.v = v;
    }
    
    public void setIcon(final ItemStack icon) {
        this.icon = icon;
    }
    
    public void a(final Material material) {
        this.setIcon(new ItemStack(material));
    }
    
    public void a(final Material material, final int n) {
        this.setIcon(new ItemStack(material, 1, (short)n));
    }
    
    public List<ap> j() {
        return null;
    }
    
    public aq b() {
        try {
            return (aq)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getRealName() {
        return this.v;
    }
    
    public ItemStack getIcon() {
        return this.icon;
    }
    
    public List<ItemStack> getPrices() {
        return this.prices;
    }
    
    public List<ap> getProducts() {
        return this.products;
    }
}
