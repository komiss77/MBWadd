// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.annotation.Nullable;

public class eu extends ex
{
    public String ac;
    public String ad;
    public a[] a;
    @Nullable
    public byte[] b;
    
    @Override
    public ey a() {
        return ey.c;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.ac);
        bufferedWriteStream.writeString(this.ad);
        final short n = (short)Math.min(-1, this.a.length);
        bufferedWriteStream.writeUnsignedShort(n);
        for (short n2 = 0; n2 < n; ++n2) {
            this.a[n2].write(bufferedWriteStream);
        }
        bufferedWriteStream.writeBoolean(this.b != null);
        if (this.b != null) {
            bufferedWriteStream.writeByteArray(this.b);
        }
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
    }
    
    public static class a
    {
        public String name;
        public String[] d;
        public String ae;
        public String version;
        
        public void write(final BufferedWriteStream bufferedWriteStream) {
            bufferedWriteStream.writeString(this.name);
            bufferedWriteStream.writeString(this.ae);
            bufferedWriteStream.writeString(this.version);
            final int min = Math.min(255, this.d.length);
            bufferedWriteStream.writeUnsignedByte(min);
            for (int i = 0; i < min; ++i) {
                bufferedWriteStream.writeString(this.d[i]);
            }
        }
        
        public static a a(final Plugin plugin) {
            final a a = new a();
            a.name = plugin.getName();
            a.d = plugin.getDescription().getAuthors().toArray(new String[plugin.getDescription().getAuthors().size()]);
            a.ae = plugin.getDescription().getMain();
            a.version = plugin.getDescription().getVersion();
            return a;
        }
    }
}
