// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import net.dev.nickplugin.api.NickManager;
import org.bukkit.entity.Player;

public class dm extends dp
{
    @Override
    public cT a() {
        return cT.k;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String c(final Player player) {
        final NickManager nickManager = new NickManager(player);
        return nickManager.isNicked() ? nickManager.getNickName() : null;
    }
    
    @Override
    public String d(final Player player) {
        final NickManager nickManager = new NickManager(player);
        return nickManager.isNicked() ? nickManager.getRealName() : null;
    }
}
