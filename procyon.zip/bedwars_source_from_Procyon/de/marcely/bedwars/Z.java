// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import org.bukkit.World;
import java.util.ArrayList;
import de.marcely.bedwars.versions.Version;
import org.bukkit.Bukkit;
import java.lang.reflect.Constructor;
import org.bukkit.Location;
import java.util.HashMap;
import org.bukkit.entity.Player;
import java.util.List;

@Deprecated
public class Z
{
    private List<Player> players;
    private HashMap<Player, List<Object>> a;
    private HashMap<Player, List<Object>> b;
    public Location loc;
    private static final double a = 0.23;
    private static String path;
    private static String version;
    private static Class<?> a;
    private static Class<?> b;
    private static Class<?> c;
    private static Class<?> d;
    private static Class<?> e;
    private static Class<?> f;
    private static Constructor<?> a;
    private static Class<?> g;
    private static Constructor<?> b;
    private static Class<?> h;
    
    static {
        Z.path = Bukkit.getServer().getClass().getPackage().getName();
        Z.version = Z.path.substring(Z.path.lastIndexOf(".") + 1, Z.path.length());
        try {
            Z.a = Class.forName("net.minecraft.server." + Z.version + ".EntityArmorStand");
            Z.b = Class.forName("net.minecraft.server." + Z.version + ".World");
            Z.c = Class.forName("net.minecraft.server." + Z.version + ".Entity");
            Z.d = Class.forName("org.bukkit.craftbukkit." + Z.version + ".CraftWorld");
            Z.e = Class.forName("net.minecraft.server." + Z.version + ".PacketPlayOutSpawnEntityLiving");
            Z.f = Class.forName("net.minecraft.server." + Z.version + ".EntityLiving");
            Z.a = Z.a.getConstructor(Z.b);
            Z.g = Class.forName("net.minecraft.server." + Z.version + ".PacketPlayOutEntityDestroy");
            Z.b = Z.g.getConstructor(int[].class);
            Z.h = Class.forName("net.minecraft.server." + Z.version + ".Packet");
        }
        catch (ClassNotFoundException | NoSuchMethodException | SecurityException ex) {
            final Object o2;
            final Object o = o2;
            System.err.println("Error - Classes not initialized!");
            ((Throwable)o).printStackTrace();
        }
    }
    
    public Z(final Location loc) {
        if (Version.a().getVersionNumber() <= 7) {
            new SecurityException("Outdated spigot version").printStackTrace();
        }
        this.loc = loc;
        this.players = new ArrayList<Player>();
        this.b = new HashMap<Player, List<Object>>();
        this.a = new HashMap<Player, List<Object>>();
    }
    
    public boolean b(final Player key) {
        if (!this.players.contains(key)) {
            final List<Object> list = this.b.get(key);
            for (int i = 0; i < list.size(); ++i) {
                this.sendPacket(key, list.get(i));
            }
            this.players.add(key);
            return true;
        }
        return false;
    }
    
    public boolean c(final Player key) {
        if (this.players.contains(key)) {
            final List<Object> list = this.a.get(key);
            for (int i = 0; i < list.size(); ++i) {
                this.sendPacket(key, list.get(i));
            }
            this.players.remove(key);
            return true;
        }
        return false;
    }
    
    private Object a(final World obj, final double d, final double d2, final double d3, final String s) {
        try {
            final Object cast = Z.d.cast(obj);
            final Object instance = Z.a.newInstance(cast.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(cast, new Object[0]));
            instance.getClass().getMethod("setCustomName", String.class).invoke(instance, s);
            Z.c.getMethod("setCustomNameVisible", Boolean.TYPE).invoke(instance, true);
            if (Version.a().getVersionNumber() <= 9) {
                instance.getClass().getMethod("setGravity", Boolean.TYPE).invoke(instance, false);
            }
            else {
                instance.getClass().getMethod("setNoGravity", Boolean.TYPE).invoke(instance, true);
            }
            instance.getClass().getMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE).invoke(instance, d, d2, d3, 0.0f, 0.0f);
            instance.getClass().getMethod("setInvisible", Boolean.TYPE).invoke(instance, true);
            return Z.e.getConstructor(Z.f).newInstance(instance);
        }
        catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    private Object a(final int... array) {
        try {
            return Z.b.newInstance(array);
        }
        catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    private void sendPacket(final Player obj, final Object o) {
        try {
            final Object invoke = obj.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(obj, new Object[0]);
            final Object value = invoke.getClass().getField("playerConnection").get(invoke);
            value.getClass().getMethod("sendPacket", Z.h).invoke(value, o);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final Player player, final List<String> list) {
        this.b.remove(player);
        this.a.remove(player);
        final ArrayList<Object> value = new ArrayList<Object>();
        final ArrayList<Object> value2 = new ArrayList<Object>();
        final Location add = this.loc.clone().add(0.0, 0.23 * list.size() - 1.97, 0.0);
        for (int i = 0; i < list.size(); ++i) {
            final Object a = this.a(this.loc.getWorld(), add.getX(), add.getY(), add.getZ(), list.get(i));
            value.add(a);
            try {
                final Field declaredField = Z.e.getDeclaredField("a");
                declaredField.setAccessible(true);
                value2.add(this.a((int)declaredField.get(a)));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            add.add(0.0, -0.23, 0.0);
        }
        this.b.put(player, value);
        this.a.put(player, value2);
    }
    
    public List<Player> getPlayers() {
        return this.players;
    }
}
