// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import java.util.ArrayList;
import java.util.List;

public class dv
{
    private List<dD> ab;
    
    public dv() {
        this.ab = new ArrayList<dD>();
    }
    
    public void ab() {
        dw[] values;
        for (int length = (values = dw.values()).length, i = 0; i < length; ++i) {
            final dw dw = values[i];
            if (!dw.R()) {
                try {
                    this.a((dD)dw.getClazz().newInstance());
                }
                catch (InstantiationException | IllegalAccessException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        }
    }
    
    public boolean a(final dD dd) {
        if (this.ab.contains(dd)) {
            return false;
        }
        if (ConfigValue.placeholderapi_enabled && ConfigValue.placeholderapi_registercustom) {
            final Iterator<du> iterator = s.b.a(du.class).iterator();
            while (iterator.hasNext()) {
                iterator.next().a(dd);
            }
        }
        this.ab.add(dd);
        return true;
    }
    
    public boolean b(final dD dd) {
        if (this.ab.contains(dd)) {
            this.ab.remove(dd);
            return true;
        }
        return false;
    }
}
