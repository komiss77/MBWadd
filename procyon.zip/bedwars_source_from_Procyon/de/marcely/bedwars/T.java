// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.InputStream;

public class T
{
    public static InputStream getResourceAsStream(final String str) {
        return MBedwars.a.getResource("de/marcely/bedwars/config/language/" + str);
    }
}
