// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.List;
import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import java.util.Arrays;
import org.bukkit.ChatColor;
import de.marcely.bedwars.api.BedwarsAddon;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.MBedwars;
import org.bukkit.command.CommandSender;

public class a implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] original) {
        final de.marcely.bedwars.a a = MBedwars.a;
        if (original.length >= 3) {
            if (original[1].equalsIgnoreCase("setenabled")) {
                final Plugin addonByName = a.getAddonByName(original[2]);
                if (addonByName != null) {
                    a.setAddonState(addonByName, true);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Enabled).a("name", addonByName.getName()));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Unkown).a("id", original[2]));
                }
            }
            else if (original[1].equalsIgnoreCase("setdisabled")) {
                final Plugin addonByName2 = a.getAddonByName(original[2]);
                if (addonByName2 != null) {
                    a.setAddonState(addonByName2, false);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Disabled).a("name", addonByName2.getName()));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Unkown).a("id", original[2]));
                }
            }
            else if (original[1].equalsIgnoreCase("command")) {
                final Plugin addonByName3 = a.getAddonByName(original[2]);
                if (addonByName3 != null) {
                    final BedwarsAddon bedwarsAddon = MBedwars.b.get(addonByName3);
                    if (original.length == 3) {
                        commandSender.sendMessage(ChatColor.GRAY + "==== " + de.marcely.bedwars.message.b.a(Language.Addon_Command_List).a("addon", addonByName3.getName()).f(commandSender) + ChatColor.GRAY + " ====");
                        commandSender.sendMessage("");
                        if (bedwarsAddon != null && bedwarsAddon.getCommands().size() >= 1) {
                            for (final BedwarsAddon.BedwarsAddonCommand bedwarsAddonCommand : bedwarsAddon.getCommands()) {
                                commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + original[0] + " " + original[1] + " " + original[2] + " " + bedwarsAddonCommand.getCommand() + " " + bedwarsAddonCommand.getUsage());
                            }
                        }
                        else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Command_None));
                        }
                    }
                    else if (bedwarsAddon != null) {
                        final BedwarsAddon.BedwarsAddonCommand command = bedwarsAddon.getCommand(original[3]);
                        if (command != null) {
                            command.onWrite(commandSender, Arrays.copyOfRange(original, 4, original.length), "/" + s + " " + original[0] + " " + original[1] + " " + original[2] + " " + command.getCommand() + " " + command.getUsage());
                        }
                        else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Command_Unkown).a("command", original[3]));
                        }
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Command_None));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Unkown).a("id", original[2]));
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", original[1]));
            }
        }
        else if (original.length == 2) {
            if (original[1].equalsIgnoreCase("research")) {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Addon_Research).a("number", new StringBuilder().append(a.research()).toString()));
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", original[1]));
            }
        }
        else {
            commandSender.sendMessage("");
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Addons_Enabled).f(commandSender)).toString());
            if (a.getEnabledAddons().size() > 0) {
                for (final Plugin plugin : a.getEnabledAddons()) {
                    commandSender.sendMessage(" " + ChatColor.GOLD + a.getAddonID(plugin) + " " + ChatColor.YELLOW + plugin.getName());
                }
            }
            else {
                commandSender.sendMessage(ChatColor.RED + " " + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Addons_Disabled).f(commandSender)).toString());
            if (a.getDisabledAddons().size() > 0) {
                for (final Plugin plugin2 : a.getDisabledAddons()) {
                    commandSender.sendMessage(" " + ChatColor.GOLD + a.getAddonID(plugin2) + " " + ChatColor.YELLOW + plugin2.getName());
                }
            }
            else {
                commandSender.sendMessage(ChatColor.RED + " " + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Commands_List).f(commandSender)).toString());
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + original[0].toLowerCase() + " setenabled " + ChatColor.AQUA + "<addon id>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + original[0].toLowerCase() + " setdisabled " + ChatColor.AQUA + "<addon id>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + original[0].toLowerCase() + " command " + ChatColor.AQUA + "<addon id> [command] [args...]");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + original[0].toLowerCase() + " research");
            commandSender.sendMessage("");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        final de.marcely.bedwars.a a = MBedwars.a;
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        final String s2 = array[0];
        if (array.length == 2 && (s2.equalsIgnoreCase("setenabled") || s2.equalsIgnoreCase("setdisabled") || s2.equalsIgnoreCase("command"))) {
            return Arrays.asList((String[])a.getEnabledAddons().stream().map((Function<? super Object, ?>)Plugin::getName).toArray(String[]::new));
        }
        if (array.length == 3 && s2.equalsIgnoreCase("command")) {
            final Plugin addonByName = a.getAddonByName(array[1]);
            if (addonByName != null) {
                final BedwarsAddon bedwarsAddon = MBedwars.b.get(addonByName);
                if (bedwarsAddon != null) {
                    final ArrayList<String> list = new ArrayList<String>();
                    final Iterator<BedwarsAddon.BedwarsAddonCommand> iterator = bedwarsAddon.getCommands().iterator();
                    while (iterator.hasNext()) {
                        list.add(iterator.next().getCommand());
                    }
                    return s.a(list, array[2]);
                }
            }
        }
        return new ArrayList<String>();
    }
    
    private List<String> b() {
        return Arrays.asList("setenabled", "setdisabled", "command", "research");
    }
}
