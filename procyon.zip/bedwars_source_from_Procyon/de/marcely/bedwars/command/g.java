// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.e;
import de.marcely.bedwars.MBedwars;
import org.bukkit.command.CommandSender;

public class g implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (!MBedwars.a.isRunning()) {
            MBedwars.a.a(e.a.e, commandSender);
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Search_Update));
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.InWork_Job));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
