// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Iterator;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import de.marcely.bedwars.api.event.CommandFireEvent;
import de.marcely.bedwars.Language;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Permission;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandExecutor;

public class CommandHandler implements CommandExecutor
{
    private List<Command> f;
    
    public CommandHandler() {
        this.f = new ArrayList<Command>();
        this.refresh();
    }
    
    public void refresh() {
        this.f.clear();
        this.f.add(new Command(this, new j(), null, false, false, "[page]", new String[] { "help" }));
        this.f.add(new Command(this, new d(), Permission.Command_Arena, false, "[args...]", new String[] { "arena", "arenas" }));
        this.f.add(new Command(this, new u(), Permission.Command_Summon, true, "[args...]", new String[] { "summon", "spawn", "summonentity", "spawnentity" }));
        this.f.add(new Command(this, new b(), Permission.Command_AddSign, true, "<arena name>", new String[] { "addsign", "signadd", "sign", "signsadd", "addsigns" }));
        this.f.add(new Command(this, new c(), Permission.Command_AddStatsSign, true, "<place>", new String[] { "addstatssign", "signstatsadd", "statssign", "signsaddstats", "addsignsstats" }));
        this.f.add(new Command(this, new s(), Permission.Command_SetGameDoneLocation, true, "", new String[] { "setgamedonelocation", "sgdl", "gamedonelocation", "gamedonelocationset" }));
        this.f.add(new Command(this, new k(), Permission.Command_Hologram, true, "[args...]", new String[] { "hologram", "holograms" }));
        this.f.add(new Command(this, new m(), Permission.Command_Join, true, "<arena name>", new String[] { "join", "enter" }));
        this.f.add(new Command(this, new o(), Permission.Command_Leave, true, "", new String[] { "leave", "quit" }));
        this.f.add(new Command(this, new n(), Permission.Command_Kick, true, "<player name>", new String[] { "kick", "kickplayer" }));
        this.f.add(new Command(this, new t(), Permission.Command_Stats, true, "[player]", new String[] { "stats" }));
        this.f.add(new Command(this, new i(), Permission.Command_Forcestart, true, "", new String[] { "forcestart", "fs", "forcestartround", "forcestartgame", "forcestartarena" }));
        this.f.add(new Command(this, new a(), Permission.Command_Addon, false, "[args...]", new String[] { "addon", "add-on", "addons", "add-ons" }));
        this.f.add(new Command(this, new g(), Permission.Command_CheckUpdate, false, "", new String[] { "checkupdate" }));
        this.f.add(new Command(this, new q(), Permission.Command_Reload, false, "", new String[] { "reload", "rl" }));
        this.f.add(new Command(this, new p(), Permission.Command_RecalculateStats, false, false, "", new String[] { "calulatestats", "recalculatestats", "rlstats", "reloadstats" }));
        this.f.add(new Command(this, new e(), Permission.Command_ArenasGUI, false, "", new String[] { "arenasgui" }));
        this.f.add(new Command(this, new r(), Permission.Command_RunningGames, true, "", new String[] { "runninggames" }));
        this.f.add(new Command(this, new f(), Permission.Command_Backup, false, "", new String[] { "backup" }));
        this.f.add(new Command(this, new h(), Permission.Command_Debug, true, false, "", new String[] { "debug" }));
        this.f.add(new Command(this, new l(), Permission.Command_Info, false, "", new String[] { "info", "infos", "information", "informations", "about" }));
    }
    
    public boolean onCommand(final CommandSender commandSender, final org.bukkit.command.Command command, final String str, final String[] array) {
        if (array.length >= 1) {
            final Command a = this.a(array[0]);
            if (a != null) {
                if (!a.f || (a.f && commandSender instanceof Player)) {
                    if (a.a[0].equals("info") || (a.a[0].equals("debug") && commandSender instanceof Player && ((Player)commandSender).getName().equals("Marcely1199")) || a.a == null || (a.a != null && de.marcely.bedwars.util.s.hasPermission(commandSender, a.a))) {
                        this.a(a, commandSender, str, "/" + str + " " + array[0].toLowerCase() + " " + a.usage, array);
                    }
                    else {
                        this.a(this.f.get(0), commandSender, str, null, array);
                    }
                }
                else {
                    de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                }
            }
            else if (!de.marcely.bedwars.util.s.isInteger(array[0])) {
                de.marcely.bedwars.util.s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", array[0]));
            }
            else {
                this.a(this.f.get(0), commandSender, str, null, array);
            }
        }
        else {
            this.a(this.f.get(0), commandSender, str, null, array);
        }
        return true;
    }
    
    private void a(final Command command, final CommandSender commandSender, final String s, final String s2, final String... array) {
        final CommandFireEvent commandFireEvent = new CommandFireEvent(commandSender, command);
        Bukkit.getPluginManager().callEvent((Event)commandFireEvent);
        if (!commandFireEvent.isCancelled()) {
            command.a.a(commandSender, s, s2, array);
        }
    }
    
    public List<Command> getCommands() {
        return this.f;
    }
    
    public List<String> c() {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator<Command> iterator = this.f.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().a()[0]);
        }
        return list;
    }
    
    public Command a(final String s) {
        final String lowerCase = s.toLowerCase();
        for (final Command command : this.f) {
            String[] a;
            for (int length = (a = command.a).length, i = 0; i < length; ++i) {
                if (lowerCase.equals(a[i])) {
                    return command;
                }
            }
        }
        return null;
    }
    
    public List<String> a(final String s, final CommandSender commandSender) {
        final String[] a = a(s);
        if (a.length < 2) {
            return this.c();
        }
        final Command a2 = this.a(a[1]);
        if (a2 == null || a.length < 3) {
            return de.marcely.bedwars.util.s.a(this.c(), a[1]);
        }
        final List<String> a3 = a2.a().a(Arrays.copyOfRange(a, 2, a.length), s, commandSender);
        if (a3 != null) {
            return a3;
        }
        return de.marcely.bedwars.util.s.z();
    }
    
    private static String[] a(final String s) {
        final String[] split = s.split(" ");
        if (!s.endsWith(" ")) {
            return split;
        }
        final ArrayList<String> list = new ArrayList<String>();
        String[] array;
        for (int length = (array = split).length, i = 0; i < length; ++i) {
            list.add(array[i]);
        }
        list.add("");
        return list.toArray(new String[list.size()]);
    }
    
    public static class Command
    {
        protected CommandHandler b;
        protected a a;
        protected Permission a;
        protected boolean f;
        protected boolean visible;
        protected String usage;
        protected String[] a;
        
        public Command(final CommandHandler commandHandler, final a a, final Permission permission, final boolean b, final String s, final String... array) {
            this(commandHandler, a, permission, b, true, s, array);
        }
        
        public Command(final CommandHandler b, final a a, final Permission a2, final boolean f, final boolean visible, final String usage, final String... a3) {
            this.b = b;
            this.a = a;
            this.a = a2;
            this.f = f;
            this.visible = visible;
            this.usage = usage;
            this.a = a3;
            a.a(this);
        }
        
        public CommandHandler getCommandHandler() {
            return this.b;
        }
        
        public a a() {
            return this.a;
        }
        
        public Permission a() {
            return this.a;
        }
        
        public boolean n() {
            return this.f;
        }
        
        public boolean isVisible() {
            return this.f;
        }
        
        public String getUsage() {
            return this.usage;
        }
        
        public String[] a() {
            return this.a;
        }
        
        public interface a
        {
            void a(final Command p0);
            
            void a(final CommandSender p0, final String p1, final String p2, final String[] p3);
            
            @Nullable
            List<String> a(final String[] p0, final String p1, final CommandSender p2);
        }
    }
}
