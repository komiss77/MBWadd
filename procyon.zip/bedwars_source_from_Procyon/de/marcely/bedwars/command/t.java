// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import org.bukkit.ChatColor;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import de.marcely.bedwars.game.stats.c;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.OfflinePlayer;
import java.util.Iterator;
import java.util.UUID;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.Bukkit;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class t implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length <= 1) {
            a((CommandSender)player, player.getUniqueId(), s.f(player));
        }
        else if (!ConfigValue.sql_enabled) {
            for (final Player player2 : Bukkit.getServer().getOnlinePlayers()) {
                if (player2.getName().equalsIgnoreCase(array[1])) {
                    a((CommandSender)player, player2.getUniqueId(), player2.getName());
                    return;
                }
            }
            final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(array[1]);
            if (offlinePlayer != null) {
                a((CommandSender)player, offlinePlayer.getUniqueId(), offlinePlayer.getName());
                return;
            }
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotFound_Player).a("player", array[1]));
        }
        else {
            a((CommandSender)player, null, array[1]);
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.z();
        }
        if (array.length == 1) {
            return s.a(s.z(), array[0]);
        }
        return new ArrayList<String>();
    }
    
    public static void a(final CommandSender commandSender, UUID uniqueId, final String s) {
        if (uniqueId == null && commandSender instanceof Player && s.equalsIgnoreCase(commandSender.getName())) {
            uniqueId = ((Player)commandSender).getUniqueId();
        }
        final Future<c> a = c.a(s, uniqueId);
        s.a((Future<Object>)a, new Runnable() {
            @Override
            public void run() {
                try {
                    final c c = a.get();
                    if (c == null) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotFound_Player).a("player", s));
                        return;
                    }
                    t.a(commandSender, c);
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        });
    }
    
    public static void a(final CommandSender commandSender, final c c) {
        de.marcely.bedwars.util.t.c(c);
        commandSender.sendMessage(ChatColor.DARK_AQUA + b.a(Language.Stats_By).a().a("player", c.getPlayerName()).f(commandSender) + ": ");
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Rank).a().f(commandSender)) + ((c.getRank() != -1) ? Integer.valueOf(c.getRank()) : b.a(Language.Ranking_Unranked).f(commandSender)));
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Won).a().f(commandSender)) + c.getWins());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Lost).a().f(commandSender)) + c.getLoses());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_RoundsPlayed).a().f(commandSender)) + c.getRoundsPlayed());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_WL).a().f(commandSender)) + c.a());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Kills).a().f(commandSender)) + c.getKills());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_Deaths).a().f(commandSender)) + c.getDeaths());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_KD).a().f(commandSender)) + c.b());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_BedsDestroyed).a().f(commandSender)) + c.getBedsDestroyed());
        commandSender.sendMessage(String.valueOf(b.a(Language.Stats_PlayTime).a().f(commandSender)) + s.a(c.getPlayTime()));
    }
}
