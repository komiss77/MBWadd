// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.util.s;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public class n implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (array.length >= 2) {
            final Player player = Bukkit.getPlayer(array[1]);
            if (player != null) {
                final Arena a = s.a(player);
                if (a != null) {
                    a.a(KickReason.c, player);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Kicked_Player).a("player", player.getName()).a("arena", a.getName()));
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Kicked_Player_ToPlayer));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Not_Ingame_Player).a("player", player.getName()));
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotFound_Player).a("player", array[1]));
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.z();
        }
        if (array.length == 1) {
            return s.a(s.z(), array[0]);
        }
        return new ArrayList<String>();
    }
}
