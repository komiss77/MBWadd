// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import java.util.ArrayList;
import org.bukkit.command.CommandSender;
import java.util.List;

public class p implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    private List<CommandSender> g;
    
    public p() {
        this.g = new ArrayList<CommandSender>();
    }
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (!this.g.contains(commandSender)) {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.RecalculateStats_Sure1));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.RecalculateStats_Sure2));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.RecalculateStats_Sure3));
            this.g.add(commandSender);
            new BukkitRunnable() {
                public void run() {
                    ((p)commandSender).g.remove(commandSender);
                }
            }.runTaskLater((Plugin)MBedwars.a, 200L);
        }
        else {
            this.g.remove(commandSender);
            s.c(new Runnable() {
                private final /* synthetic */ long b = System.currentTimeMillis();
                
                @Override
                public void run() {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.RecalculateStats_Done).a("time", new StringBuilder().append((System.currentTimeMillis() - this.b) / 1000.0).toString()));
                }
            });
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
