// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class l implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        commandSender.sendMessage("");
        commandSender.sendMessage(ChatColor.DARK_AQUA + "- " + ChatColor.AQUA + de.marcely.bedwars.message.b.a(Language.Info_MadeBy).f(commandSender) + ": Marcely1199");
        commandSender.sendMessage(ChatColor.DARK_AQUA + "- " + ChatColor.AQUA + de.marcely.bedwars.message.b.a(Language.Info_Website).f(commandSender) + ": http://Marcely.de/");
        commandSender.sendMessage(ChatColor.DARK_AQUA + "- " + ChatColor.AQUA + de.marcely.bedwars.message.b.a(Language.Info_Version).f(commandSender) + ": " + MBedwars.getVersion());
        commandSender.sendMessage(ChatColor.DARK_AQUA + "- " + ChatColor.AQUA + de.marcely.bedwars.message.b.a(Language.Info_NewestVersion).f(commandSender) + ": " + MBedwars.a.c());
        commandSender.sendMessage(ChatColor.DARK_AQUA + "--------------------");
        commandSender.sendMessage("");
        commandSender.sendMessage(ChatColor.YELLOW + "NOTE: " + ChatColor.GRAY + "First of all thanks for using this plugin. It took me multiple thousands of hours to create and modify this plugin to its best. If you didn't bought that yet, please take the time as I did and give me the money to pay my server-costs for one month.");
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
