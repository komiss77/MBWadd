// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.Sound;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.util.i;
import org.bukkit.ChatColor;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class r implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        final ArrayList<Arena> list = new ArrayList<Arena>();
        for (final Arena arena : s.af) {
            if (arena.b() == ArenaStatus.f) {
                list.add(arena);
            }
        }
        final GUI gui = new GUI(de.marcely.bedwars.message.b.a(Language.GUI_RunningGames_Title).f(commandSender), 1);
        if (list.size() >= 1) {
            for (final Arena arena2 : list) {
                gui.addItem(new GUIItem(i.a(i.a(arena2.getIcon(), ChatColor.WHITE + arena2.getDisplayName()), new String[] { String.valueOf(new StringBuilder().append(ChatColor.YELLOW).append(arena2.j()).append(ChatColor.GOLD).append("/").append(ChatColor.YELLOW).append(arena2.getMaxPlayers()).toString()) })) {
                    @Override
                    public void onClick(final Player player, final boolean b, final boolean b2) {
                        if (arena2.b() == ArenaStatus.f) {
                            final String b3 = s.b(player, arena2);
                            if (b3 != null) {
                                player.sendMessage(b3);
                            }
                        }
                        else {
                            Sound.CMD_RUNNINGGAME_FAILURE.play(player);
                        }
                    }
                });
            }
            gui.centerAtYAll(GUI.CenterFormatType.Beautiful);
        }
        else {
            gui.setItemAt(new GUIItem(i.a(new ItemStack(s.e), de.marcely.bedwars.message.b.a(Language.RunningGames_NoOne).f(commandSender))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                }
            }, 4, 0);
        }
        gui.open(player);
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
