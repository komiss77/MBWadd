// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class o implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        final Arena a = s.a(player);
        if (a != null) {
            a.a(KickReason.b, (Player)commandSender);
        }
        else if (cA.E.containsKey(player)) {
            cA.a(player, cD.b);
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Not_Ingame));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
