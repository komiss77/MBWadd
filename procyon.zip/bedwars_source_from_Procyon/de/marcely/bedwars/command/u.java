// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import de.marcely.bedwars.config.l;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.IEntity;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.b;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class u implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (de.marcely.bedwars.config.b.o()) {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Wait_AllArenasLoaded));
            return;
        }
        if (array.length >= 3 && array[1].equalsIgnoreCase("hubvillager")) {
            if (array.length == 3) {
                final Arena b = s.b(array[2]);
                if (b != null) {
                    s.a(IEntity.a(player.getLocation(), b));
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_LobbyVillager));
                }
                else {
                    Language.sendNotFoundArenaMessage(commandSender, array[2]);
                }
            }
            else if (s.isInteger(array[2]) && s.isInteger(array[3])) {
                try {
                    s.a(IEntity.a(player.getLocation(), Integer.valueOf(array[2]), Integer.valueOf(array[3])));
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_LobbyVillager));
                }
                catch (Exception ex) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Error_Occured));
                    ex.printStackTrace();
                }
            }
            else if (!s.isInteger(array[2])) {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[2]));
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[3]));
            }
        }
        else if (array.length >= 3 && array[1].equalsIgnoreCase("teamselectvillager")) {
            final Team a = Team.a(commandSender, array[2]);
            if (a != null) {
                s.a(IEntity.a(player.getLocation(), a));
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_TeamSelectVillager));
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", array[2]));
            }
        }
        else if (array.length >= 3 && array[1].equalsIgnoreCase("ranking")) {
            if (Version.a().getVersionNumber() >= 8) {
                if (s.isInteger(array[2])) {
                    final int intValue = Integer.valueOf(array[2]);
                    final Location clone = player.getLocation().clone();
                    if (intValue >= 1 && intValue <= 3) {
                        if (Version.a().getVersionNumber() >= 9) {
                            s.aj.add(player);
                        }
                        final RankingStatue rankingStatue = new RankingStatue(RankingStatue.a.a(intValue), clone, de.marcely.bedwars.game.stats.b.a[intValue - 1]);
                        s.ad.add(rankingStatue);
                        rankingStatue.a();
                        l.save();
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawn_Ranking).a("place", array[2]));
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Place).a("place", array[2]));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[2]));
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Not_Supported).a("version", "8"));
            }
        }
        else if (array.length >= 2 && array[1].equalsIgnoreCase("dealer")) {
            s.a(IEntity.a(player.getLocation()));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_Dealer));
        }
        else if (array.length >= 2 && array[1].equalsIgnoreCase("upgradedealer")) {
            s.a(IEntity.b(player.getLocation()));
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Spawned_UpgradeDealer));
        }
        else {
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender)).toString());
            for (int i = 0; i < 3; ++i) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " hubvillager" + ChatColor.AQUA + " <teams> <players in each team>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " hubvillager" + ChatColor.AQUA + " <arena name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " teamselectvillager" + ChatColor.AQUA + " <team color>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " ranking" + ChatColor.AQUA + " <place>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " dealer");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " upgradedealer");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        final String s2 = array[0];
        if (array.length == 2) {
            if (s2.equalsIgnoreCase("hubvillager")) {
                return s.a(s.A(), array[1]);
            }
            if (s2.equalsIgnoreCase("teamselectvillager")) {
                return s.a(Team.a(commandSender, true, true), array[1]);
            }
        }
        return new ArrayList<String>();
    }
    
    private List<String> b() {
        return Arrays.asList("hubvillager", "teamselectvillager", "ranking", "dealer", "upgradedealer");
    }
}
