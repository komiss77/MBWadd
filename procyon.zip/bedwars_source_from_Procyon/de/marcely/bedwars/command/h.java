// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import de.marcely.bedwars.holographic.f;
import java.util.Collection;
import java.util.List;
import java.lang.reflect.Field;
import org.bukkit.block.Block;
import java.util.Iterator;
import de.marcely.bedwars.bs;
import java.lang.reflect.Modifier;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.ec;
import de.marcely.bedwars.dY;
import de.marcely.bedwars.achievements.Achievement;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.block.Skull;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.shop.upgrade.UpgradeShop;
import de.marcely.bedwars.game.shop.upgrade.UpgradeDesignData;
import de.marcely.bedwars.util.a;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import de.marcely.bedwars.holographic.e;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.cI;
import de.marcely.bedwars.util.j;
import de.marcely.bedwars.util.MThread;
import java.util.Map;
import de.marcely.bedwars.game.arena.ArenaStatus;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.bC;
import de.marcely.bedwars.game.arena.KickReason;
import org.bukkit.Bukkit;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import java.util.ArrayList;
import de.marcely.bedwars.bl;
import de.marcely.bedwars.bm;
import java.util.Arrays;
import de.marcely.bedwars.bt;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.game.shop.Shop;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.game.shop.ShopDesignData;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class h implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] original) {
        commandSender.sendMessage(ChatColor.RED + "This command is ONLY for debug purposes!");
        commandSender.sendMessage(ChatColor.RED + "Use it at your own risk.");
        commandSender.sendMessage(ChatColor.GOLD + "============");
        final Player player = (Player)commandSender;
        if (original.length >= 2) {
            final String s3 = original[1];
            if (s3.equals("0")) {
                Shop.open((Player)commandSender, ShopDesignData.getDesignByName(original[2]), ShopOpenType.DEBUG);
            }
            else if (s3.equals("1")) {
                final Sound byName = Sound.byName(original[2]);
                if (byName == null) {
                    player.sendMessage(ChatColor.RED + "Unkown sound");
                }
                else {
                    byName.play(player);
                }
            }
            else if (s3.equals("2")) {
                bs a2;
                try {
                    a2 = new bt().a(String.join(" ", (CharSequence[])Arrays.copyOfRange(original, 2, original.length)));
                }
                catch (bm | bl bm) {
                    final Throwable t;
                    player.sendMessage(ChatColor.RED + "A syntax error occured: " + ChatColor.GOLD + t.getMessage());
                    return;
                }
                Object arenas;
                if (a2.a() != null) {
                    arenas = new ArrayList<Arena>();
                    for (final Arena arena2 : s.af) {
                        if (a2.a().a(arena2)) {
                            ((List<Arena>)arenas).add(arena2);
                        }
                    }
                }
                else {
                    arenas = BedwarsAPI.getArenas();
                }
                if (((List)arenas).size() == 0) {
                    player.sendMessage(ChatColor.GREEN + "Success! But no arenas were found.");
                    return;
                }
                player.sendMessage(ChatColor.GREEN + "Success! Arenas: " + String.join(", ", (CharSequence[])((Collection<Object>)arenas).stream().map(arena -> arena.getName()).toArray(String[]::new)));
            }
            else if (s3.equals("3")) {
                commandSender.sendMessage(String.valueOf(de.marcely.bedwars.config.b.o()) + " " + (de.marcely.bedwars.config.b.b() != null && de.marcely.bedwars.config.b.b().isAlive()));
            }
            else if (s3.equals("4")) {
                commandSender.sendMessage(new StringBuilder().append(s.b(original[2]).B()).toString());
            }
            else if (s3.equals("5")) {
                s.a(player).b((Team)null);
            }
            else if (s3.equals("6")) {
                commandSender.sendMessage(String.valueOf(s.b(original[2]).a.isEnabled()) + " " + ConfigValue.scoreboard_enabled);
                if (original[3].equals("1")) {
                    s.b(original[2]).a.s(player);
                }
                else {
                    s.b(original[2]).a.q(player);
                }
            }
            else if (s3.equals("7")) {
                final Arena a3 = s.a(player);
                final Team a4 = Team.a(commandSender, original[2]);
                a3.a(player, a3.a().a(a4).toBukkit(a3.getWorld()), a4);
            }
            else if (s3.equals("8")) {
                final Player player2 = Bukkit.getPlayer(original[2]);
                s.a(player2).a(KickReason.b, player2);
            }
            else if (s3.equals("9")) {
                bC.e(player, Team.values()[s.RAND.nextInt(Team.values().length)]);
            }
            else if (s3.equals("10")) {
                final Location clone = player.getLocation().clone();
                clone.setYaw(0.0f);
                clone.setPitch(0.0f);
                bC.a(clone, Float.valueOf(original[2]), Float.valueOf(original[3]), Float.valueOf(original[4]), Team.values()[s.RAND.nextInt(Team.values().length)]);
            }
            else if (s3.equals("11")) {
                final AnvilGUI anvilGUI = new AnvilGUI("Cool name xD");
                anvilGUI.setTitle("The title is also working on never versions :)");
                anvilGUI.setWroteListener(new AnvilGUI.WroteListener() {
                    @Override
                    public void run(final String str) {
                        commandSender.sendMessage("Your message: " + str);
                    }
                });
                anvilGUI.open(player);
            }
            else if (s3.equals("12")) {
                final Future<c> a5 = c.a(player.getName(), player.getUniqueId());
                s.a((Future<Object>)a5, new Runnable() {
                    @Override
                    public void run() {
                        try {
                            final c c = a5.get();
                            c.setPlayTime(Long.valueOf(original[2]));
                            c.save();
                            System.out.println(c.getPlayTime());
                        }
                        catch (InterruptedException | ExecutionException ex) {
                            final Throwable t;
                            t.printStackTrace();
                        }
                    }
                });
            }
            else if (s3.equals("13")) {
                final Arena b = s.b(original[2]);
                b.a(ArenaStatus.e);
                final int minPlayers = b.getMinPlayers();
                b.setMinPlayers(0);
                b.D();
                b.setMinPlayers(minPlayers);
            }
            else if (s3.equals("14")) {
                int int1 = 3;
                if (original.length >= 3) {
                    if (!s.isInteger(original[2])) {
                        player.sendMessage(ChatColor.RED + "Argument isn't an integer");
                        return;
                    }
                    int1 = Integer.parseInt(original[2]);
                }
                player.sendMessage(new StringBuilder().append(ChatColor.GOLD).append(ChatColor.BOLD).append("Measuring...").toString());
                boolean b2 = false;
                final Player player3;
                final Iterator<Map.Entry<Thread, Double>> iterator2;
                Map.Entry<Thread, Double> entry;
                Thread thread;
                boolean b3 = false;
                new j(int1, a -> {
                    while ((b2 ? 1 : 0) < 3) {
                        player3.sendMessage("");
                        ++b2;
                    }
                    player3.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(" Process load: ").append(ChatColor.GRAY).append(Math.round(a.e * 100.0) / 100.0).append("%").toString());
                    player3.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(" System load: ").append(ChatColor.GRAY).append(Math.round(a.f * 100.0) / 100.0).append("%").toString());
                    player3.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(" TPS: ").append(ChatColor.GRAY).append(Math.round(a.g * 100.0) / 100.0).toString());
                    player3.sendMessage("");
                    a.P.entrySet().iterator();
                    while (iterator2.hasNext()) {
                        entry = iterator2.next();
                        thread = entry.getKey();
                        if (!(thread instanceof MThread) && thread != s.a) {
                            continue;
                        }
                        else {
                            commandSender.sendMessage(String.valueOf(new StringBuilder().append(ChatColor.GOLD).append(thread.getId()).append(ChatColor.YELLOW).append(" ").append(thread.getState().name()).append("(").append(Math.round(entry.getValue() * 100.0) / 100.0).append("%)").toString()) + MThread.getDisplayInfo(thread));
                        }
                    }
                    while ((b3 ? 1 : 0) < 3) {
                        player3.sendMessage("");
                        ++b3;
                    }
                }).run();
            }
            else if (s3.equals("15")) {
                final Arena b4 = s.b(original[2]);
                commandSender.sendMessage("Config World: " + b4.C + " | Actual world: " + ((b4.getWorld() != null) ? b4.getWorld().getName() : null) + " | Config Lobbyworld: " + b4.D + " | Actual Lobbyworld: " + ((b4.getLobby() != null && b4.getLobby().getWorld() != null) ? b4.getLobby().getWorld().getName() : "null"));
            }
            else if (s3.equals("16")) {
                final de.marcely.bedwars.holographic.c<cI> a6 = de.marcely.bedwars.holographic.c.a(cI.class, player.getLocation(), new cE());
                final cI ci = a6.a();
                a6.Q();
                new BukkitRunnable() {
                    int i = 0;
                    
                    public void run() {
                        final Location location = ((f)a6).getLocation();
                        location.setYaw((location.getYaw() < 360.0f) ? (location.getYaw() + 2.0f) : 0.0f);
                        ((f)a6).teleport(location);
                        ((cI)a6).setCustomName("DEBUG ENTITY | " + this.i);
                        if (s.RAND.nextInt(10) >= 9) {
                            ((cI)a6).a().a(e.a.a, new ItemStack(Material.values()[s.RAND.nextInt(Material.values().length)]));
                        }
                        ((f)a6).T();
                        if (this.i >= 500) {
                            a6.remove();
                            this.cancel();
                        }
                        ++this.i;
                    }
                }.runTaskTimer((Plugin)MBedwars.a, 0L, 0L);
            }
            else if (s3.equals("17")) {
                final Block lookingBlock = de.marcely.bedwars.util.b.getLookingBlock(player);
                final Block a7 = de.marcely.bedwars.util.a.a(lookingBlock);
                a7.setType(Material.WOOL);
                a7.setData((byte)s.RAND.nextInt(15));
                commandSender.sendMessage("Data of block: " + lookingBlock.getData());
            }
            else if (s3.equals("18")) {
                UpgradeShop.open(player, null, UpgradeDesignData.getDesignByID(Integer.valueOf(original[2])));
            }
            else if (s3.equals("19")) {
                final Block lookingBlock2 = de.marcely.bedwars.util.b.getLookingBlock(player);
                final ItemStack itemInHand = player.getItemInHand();
                if (original[2].equals("1")) {
                    Version.a().a((Skull)lookingBlock2.getState(), "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2RjZDdkZjUyNjQ1YzY4Y2RhZDg1NDhlNjFiM2Y3NjU5NjQwNzcyMjZiYTg3MmI5ZDJiZDQ1YzQzOWQifX19");
                }
                else if (original[2].equals("2")) {
                    commandSender.sendMessage(Version.a().a((Skull)lookingBlock2.getState()));
                }
                else if (original[2].equals("3")) {
                    final SkullMeta itemMeta = (SkullMeta)itemInHand.getItemMeta();
                    Version.a().a(itemMeta, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2RjZDdkZjUyNjQ1YzY4Y2RhZDg1NDhlNjFiM2Y3NjU5NjQwNzcyMjZiYTg3MmI5ZDJiZDQ1YzQzOWQifX19");
                    itemInHand.setItemMeta((ItemMeta)itemMeta);
                }
                else if (original[2].equals("4")) {
                    commandSender.sendMessage(Version.a().a((SkullMeta)itemInHand.getItemMeta()));
                }
            }
            else if (s3.equals("20")) {
                final Achievement a8 = Achievement.a(original[2]);
                if (a8 == null) {
                    player.sendMessage(ChatColor.RED + "Unkown achievement :/");
                    return;
                }
                s.a(player, a8, true);
            }
            else if (s3.equals("21")) {
                s.a(player).a().reset(true);
            }
            else if (s3.equals("22")) {
                commandSender.sendMessage(new StringBuilder().append(s.Z.containsKey(player)).toString());
                final dY dy = s.Z.get(player);
                if (dy != null && dy.a() instanceof ec) {
                    commandSender.sendMessage(new StringBuilder().append(((ec)dy.a()).isInjected()).toString());
                }
            }
            else if (s3.equals("23")) {
                final Block lookingBlock3 = de.marcely.bedwars.util.b.getLookingBlock(player);
                player.sendMessage(lookingBlock3.getType() + ":" + lookingBlock3.getData());
            }
            else if (s3.equals("24")) {
                player.sendMessage(String.valueOf(ConfigValue.tab_removenonplayers) + " | " + ConfigValue.player_color);
            }
            else if (s3.equals("25")) {
                s.b.U();
            }
            else if (s3.equals("26")) {
                int n2 = 0;
                for (final Map.Entry<String, Long> entry2 : s.c(s.a.getData()).entrySet()) {
                    if (entry2.getValue() == 0L) {
                        continue;
                    }
                    ++n2;
                    ChatColor obj = ChatColor.WHITE;
                    if (entry2.getValue() >= 20L) {
                        obj = ChatColor.DARK_RED;
                    }
                    else if (entry2.getValue() >= 10L) {
                        obj = ChatColor.RED;
                    }
                    else if (entry2.getValue() >= 2L) {
                        obj = ChatColor.YELLOW;
                    }
                    player.sendMessage(obj + entry2.getKey() + " - " + entry2.getValue() + "ms");
                }
                if (n2 == 0) {
                    player.sendMessage(ChatColor.RED + "No lag has been logged yet. Yay!");
                }
            }
            else if (s3.equals("27")) {
                final ItemStack b5 = i.b(original[2]);
                if (b5 == null) {
                    player.sendMessage("invalid");
                }
                else {
                    player.getInventory().addItem(new ItemStack[] { b5 });
                }
            }
            else if (s3.equals("28")) {
                try {
                    final Field field = ConfigValue.class.getField(original[2].replace("-", "_"));
                    if (!Modifier.isStatic(field.getModifiers())) {
                        player.sendMessage(ChatColor.RED + "Config does not exist");
                        return;
                    }
                    player.sendMessage("Value: " + field.get(null).toString());
                }
                catch (NoSuchFieldException ex2) {
                    player.sendMessage(ChatColor.RED + "Config does not exist");
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        else {
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 0 <id> = Open Shop with ID");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 1 <name> = Play the sound");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 2 <arena picker> = Test arena picker");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 3 = Returns if ArenaData is loading");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 4 <arena> = Returns if arena is regenerating");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 5 = Ends your current arena");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 6 <arena> <1/2> = Changes your scoreboard to the arena one");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 7 <team> = Fake bed break");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 8 <player> = Kick the player");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 9 = Spawns a parachute");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 10 <yaw> <pitch> <roll> = Spawn a parachute part");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 11 = Open a test anvil gui");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 12 <number in milis> = Change your playtime to the number");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 13 <arena> = Force start an arena");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 14 [calc time (default = 3)] = Returns system usage");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 15 <arena name> = Returns world info of arena");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 16 = Spawns a holographic armorstand at your location");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 17 = Changes the block behind the sign");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 18 <id> = Open Upgrade Shop with ID");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 19 <1/2> = Set/Get a skull texture of a block");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 19 <3/4> = Set/Get a skull texture of a block");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 20 <achievement> = (Forcefully) gives you this achievement");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 21 = Spawn every bed in your arena");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 22 = Returns if you are injected to netty");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 23 = Returns the data of the look at which you are looking at");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 24 = Returns if config is enabled: tab-removenonplayers | player-color");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 25 = Remove all holographic watchers and by that cause them to resend");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 26 = Show timings");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 27 <item> = Parse&get item");
            commandSender.sendMessage(ChatColor.YELLOW + "/" + s + " debug 28 <name> = Get value of a config of config.cm2");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
