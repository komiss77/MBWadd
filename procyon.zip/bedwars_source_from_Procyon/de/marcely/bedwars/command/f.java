// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.Iterator;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import de.marcely.bedwars.MBedwars;
import java.io.IOException;
import java.util.Date;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributes;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.b;
import java.util.ArrayList;
import org.bukkit.command.CommandSender;
import java.util.List;

public class f implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    private List<CommandSender> e;
    
    public f() {
        this.e = new ArrayList<CommandSender>();
    }
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String str, final String s, final String[] array) {
        final b[] a = de.marcely.bedwars.b.a();
        if (array.length >= 2) {
            final String lowerCase;
            switch (lowerCase = array[1].toLowerCase()) {
                case "create": {
                    if (array.length < 3) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + str + " backup create <name>"));
                        break;
                    }
                    final b b = new b(array[2]);
                    if (!b.getFile().exists()) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Create_Success).a("name", b.getName()).a("time", new StringBuilder().append(b.a() / 1000.0).toString()));
                        break;
                    }
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Create_Exists).a("name", b.getName()));
                    break;
                }
                case "delete": {
                    if (array.length < 3) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + str + " backup delete <name>"));
                        break;
                    }
                    final b b2 = new b(array[2]);
                    if (b2.getFile().exists()) {
                        b2.getFile().delete();
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Delete_Success).a("name", b2.getName()));
                        break;
                    }
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Unkown).a("name", b2.getName()));
                    break;
                }
                case "list": {
                    commandSender.sendMessage("");
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_List));
                    b[] array2;
                    for (int length = (array2 = a).length, i = 0; i < length; ++i) {
                        final b b3 = array2[i];
                        try {
                            commandSender.sendMessage(ChatColor.AQUA + b3.getName() + " " + ChatColor.DARK_AQUA + " " + s.b(b3.getFile().length()) + " " + ChatColor.GRAY + s.a(new Date(Files.readAttributes(b3.getFile().toPath(), BasicFileAttributes.class, new LinkOption[0]).creationTime().toMillis())));
                        }
                        catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                    commandSender.sendMessage("");
                    break;
                }
                case "restore": {
                    if (array.length < 3) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + str + " backup restore <name>"));
                        break;
                    }
                    final b b4 = new b(array[2]);
                    if (!b4.getFile().exists()) {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Unkown).a("name", b4.getName()));
                        break;
                    }
                    if (this.e.contains(commandSender)) {
                        final long currentTimeMillis = System.currentTimeMillis();
                        final List<Plugin> enabledAddons = MBedwars.a.getEnabledAddons();
                        final Iterator<Plugin> iterator = enabledAddons.iterator();
                        while (iterator.hasNext()) {
                            Bukkit.getPluginManager().disablePlugin((Plugin)iterator.next());
                        }
                        Bukkit.getPluginManager().disablePlugin((Plugin)MBedwars.a);
                        b4.b();
                        Bukkit.getPluginManager().enablePlugin((Plugin)MBedwars.a);
                        final Iterator<Plugin> iterator2 = enabledAddons.iterator();
                        while (iterator2.hasNext()) {
                            Bukkit.getPluginManager().enablePlugin((Plugin)iterator2.next());
                        }
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Success).a("name", b4.getName()).a("time", new StringBuilder().append((System.currentTimeMillis() - currentTimeMillis) / 1000.0).toString()));
                        break;
                    }
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Ask1).a("name", b4.getName()));
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Backup_Restore_Ask2));
                    this.e.add(commandSender);
                    new BukkitRunnable() {
                        public void run() {
                            ((f)commandSender).e.remove(commandSender);
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 200L);
                    break;
                }
                default:
                    break;
            }
        }
        else {
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender)).toString());
            for (int j = 0; j < 6; ++j) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " list" + ChatColor.DARK_GRAY + " (" + a.length + ")");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " create" + ChatColor.AQUA + " <name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " delete" + ChatColor.AQUA + " <name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " restore" + ChatColor.AQUA + " <name>");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return null;
    }
}
