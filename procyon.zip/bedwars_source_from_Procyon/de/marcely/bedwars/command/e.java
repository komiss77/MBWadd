// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import javax.annotation.Nullable;
import de.marcely.bedwars.game.arena.picker.condition.c;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import java.util.Comparator;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.bl;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import java.util.Arrays;
import org.bukkit.command.CommandSender;
import java.util.Iterator;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.d;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.Synchronizer;
import java.util.HashMap;
import java.util.Map;

public class e implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    private Map<String, a> d;
    
    public e() {
        this.d = new HashMap<String, a>();
    }
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
        new Synchronizer() {
            @Override
            public void run() {
                s.updateListeners.add(new d() {
                    @Override
                    public void a(final Arena arena, final d.a a) {
                        for (final e.a a2 : e.this.d.values()) {
                            if (a2.d.contains(arena)) {
                                a2.update();
                                a(a2.gui, a2.d);
                            }
                        }
                    }
                });
            }
        };
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] original) {
        String join = "";
        if (original.length >= 1) {
            join = String.join(" ", (CharSequence[])Arrays.copyOfRange(original, 1, original.length));
        }
        a a = this.d.get(join);
        if (a == null) {
            a = new a(null);
            if (!join.isEmpty()) {
                try {
                    a.a = new de.marcely.bedwars.game.arena.picker.condition.d().a(join);
                }
                catch (bl bl) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Error_Occured_Syntax).a("message", bl.getMessage()));
                    return;
                }
            }
            a.update();
            a(a.gui = new GUI(de.marcely.bedwars.message.b.a(Language.ArenasGUI_Title).f(null), 0) {
                @Override
                public void onClose(final Player player) {
                    if (this.getPlayersWhoUseThisGUI().size() == 0) {
                        e.this.d.remove(join);
                    }
                }
            }, a.d);
            this.d.put(join, a);
        }
        a.gui.open((Player)commandSender);
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
    
    private static void a(final GUI gui, final List<Arena> list) {
        gui.clear();
        gui.setHeight(0);
        list.sort(new Comparator<Arena>() {
            public int a(final Arena arena, final Arena arena2) {
                if (arena.b() == ArenaStatus.e) {
                    return (arena.getPlayers().size() >= arena2.getPlayers().size()) ? -1 : 1;
                }
                if (arena2.b() == ArenaStatus.e) {
                    return -this.a(arena2, arena);
                }
                return 0;
            }
        });
        for (final Arena arena : list) {
            gui.addItem(new GUIItem(i.a(i.b((arena.b() == ArenaStatus.e) ? ConfigValue.gui_arenasgui_joinable_item.clone() : ConfigValue.gui_arenasgui_not_joinable_item.clone(), arena.o()), ChatColor.WHITE + arena.getDisplayName())) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    s.b(player, arena);
                }
            });
        }
        gui.centerAtYAll(GUI.CenterFormatType.Normal);
        gui.update();
    }
    
    private static class a
    {
        public List<Arena> d;
        public GUI gui;
        @Nullable
        public c a;
        
        private a() {
            this.d = new ArrayList<Arena>();
        }
        
        public void update() {
            if (this.a != null) {
                this.d = new ArrayList<Arena>();
                for (final Arena arena : s.af) {
                    if (this.a.a(arena)) {
                        this.d.add(arena);
                    }
                }
            }
            else {
                this.d = s.af;
            }
        }
    }
}
