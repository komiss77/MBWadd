// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class d implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    public de.marcely.bedwars.command.arena.CommandHandler a;
    
    public d() {
        this.a = new de.marcely.bedwars.command.arena.CommandHandler();
    }
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        this.a.onCommand(commandSender, null, s, array);
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return this.a.b(array, s, commandSender);
    }
}
