// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class j implements CommandHandler.Command.a
{
    public static final int f = 7;
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final List<CommandHandler.Command> a = this.a(commandSender);
        final int i = (int)Math.ceil(this.a(commandSender).size() / 7.0);
        int j = 1;
        if (array.length >= 1 && s.isInteger(array[0])) {
            j = Integer.valueOf(array[0]);
        }
        else if (array.length >= 2 && s.isInteger(array[1])) {
            j = Integer.valueOf(array[1]);
        }
        final int n = (j >= 1) ? Math.max(0, Math.min(7, a.size() - (j - 1) * 7)) : 0;
        commandSender.sendMessage(ChatColor.YELLOW + " ---- " + ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Help).f(commandSender) + ChatColor.YELLOW + " -- " + ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Page).f(commandSender) + " " + j + ChatColor.RED + "/" + ChatColor.GOLD + i + ChatColor.YELLOW + " ----");
        commandSender.sendMessage(ChatColor.GRAY + "/" + s + " " + this.cmd.a[0] + " " + ChatColor.DARK_GRAY + "[" + de.marcely.bedwars.message.b.a(Language.Page).f(commandSender) + "]");
        for (int k = 0; k <= 7 - n; ++k) {
            commandSender.sendMessage("");
        }
        for (int l = 0; l < n; ++l) {
            final CommandHandler.Command command = a.get((j - 1) * 7 + l);
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + command.a[0] + " " + ChatColor.AQUA + command.usage);
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        final ArrayList<String> list = new ArrayList<String>();
        for (int i = 1; i <= Math.ceil(this.a(commandSender).size() / 7.0); ++i) {
            list.add(new StringBuilder().append(i).toString());
        }
        return list;
    }
    
    private List<CommandHandler.Command> a(final CommandSender commandSender) {
        final ArrayList<CommandHandler.Command> list = new ArrayList<CommandHandler.Command>(this.cmd.b.getCommands().size());
        for (final CommandHandler.Command command : this.cmd.b.getCommands()) {
            if (command.isVisible() && s.hasPermission(commandSender, command.a())) {
                list.add(command);
            }
        }
        return list;
    }
}
