// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import org.bukkit.ChatColor;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.stats.d;
import de.marcely.bedwars.game.location.XYZW;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import de.marcely.bedwars.versions.Version;
import org.bukkit.command.CommandSender;

public class k implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String str, final String s, final String[] array) {
        if (Version.a().getVersionNumber() >= 8) {
            final Player player = (Player)commandSender;
            if (array.length >= 2) {
                if (array[1].equalsIgnoreCase("add")) {
                    s.ae.add(new XYZW(player.getLocation()));
                    s.ah();
                    d.e(player.getLocation());
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Hologram_Add).a("id", new StringBuilder().append(s.ae.size() - 1).toString()));
                }
                else if (array[1].equalsIgnoreCase("remove")) {
                    if (array.length >= 3) {
                        if (s.isInteger(array[2])) {
                            final int intValue = Integer.valueOf(array[2]);
                            if (intValue >= 0 && intValue < s.ae.size()) {
                                d.f(s.ae.get(intValue).toBukkit());
                                s.ae.remove(intValue);
                                s.ah();
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Hologram_Remove).a("id", new StringBuilder().append(intValue).toString()));
                            }
                            else {
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Hologram_Remove_IDNotExists).a("id", array[2]));
                            }
                        }
                        else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[2]));
                        }
                    }
                    else {
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", "/" + str + " hologram remove <id>"));
                    }
                }
                else {
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", array[1]));
                }
            }
            else {
                player.sendMessage("");
                player.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Hologram_List).f(commandSender)).toString());
                int i = 0;
                if (s.ae.size() >= 1) {
                    for (final XYZW xyzw : s.ae) {
                        player.sendMessage(" " + ChatColor.GOLD + i + ChatColor.YELLOW + " W:" + xyzw.getWorld().getName() + " X:" + (int)xyzw.getX() + " Y:" + (int)xyzw.getY() + " Z:" + (int)xyzw.getZ());
                        ++i;
                    }
                }
                else {
                    player.sendMessage(ChatColor.RED + " " + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
                }
                player.sendMessage("");
                player.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Commands_List).f(commandSender)).toString());
                player.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " add");
                player.sendMessage(ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " remove " + ChatColor.AQUA + "<id>");
                player.sendMessage("");
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Not_Supported).a("version", "8"));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        if (array[0].equalsIgnoreCase("remove") && array.length == 2) {
            final ArrayList<String> list = new ArrayList<String>();
            for (int i = 0; i < s.ae.size(); ++i) {
                list.add(new StringBuilder().append(i).toString());
            }
            return s.a(list, array[1]);
        }
        return new ArrayList<String>();
    }
    
    private List<String> b() {
        return Arrays.asList("add", "remove");
    }
}
