// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import javax.annotation.Nullable;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.game.arena.Flag;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.versions.Version;
import java.util.LinkedHashMap;
import de.marcely.bedwars.game.DropType;
import java.util.Arrays;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.ChatColor;
import de.marcely.bedwars.api.gui.GUI;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.util.s;
import java.util.Iterator;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.SoftHashMap;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import java.util.Map;
import org.bukkit.inventory.ItemStack;

public class f implements CommandHandler.Command.a
{
    public static f a;
    protected CommandHandler.Command cmd;
    private static final ItemStack b;
    private static final int k = 10;
    public final Map<Player, c> e;
    
    static {
        b = i.a(new ItemStack(Material.ARROW), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Back).f(null));
    }
    
    public f() {
        this.e = new SoftHashMap<Player, c>();
    }
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
        f.a = this;
        de.marcely.bedwars.config.b.k.add(new de.marcely.bedwars.config.b.a() {
            @Override
            public void a(final Arena arena) {
                new Synchronizer() {
                    @Override
                    public void run() {
                        for (final Map.Entry<Player, c> entry : f.this.e.entrySet()) {
                            if (entry.getValue().i) {
                                f.this.d(entry.getKey());
                            }
                        }
                    }
                };
            }
            
            @Override
            public void g() {
            }
        });
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        final c a = this.a(player);
        if (array.length <= 2) {
            if (a.b == null) {
                this.d(player);
            }
            else {
                a.i = true;
                a.b.open(player);
            }
        }
        else {
            final Arena b = s.b(array[2]);
            if (b != null) {
                this.a(player, b);
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[2]);
            }
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
    
    private c a(final Player player) {
        c c = this.e.get(player);
        if (c == null) {
            c = new c(null);
            this.e.put(player, c);
        }
        return c;
    }
    
    private void d(final Player player) {
        final GUI gui = new GUI("", 0) {
            @Override
            public void onClose(final Player player) {
                final c c = f.this.e.get(player);
                if (c != null) {
                    c.i = false;
                }
            }
        };
        for (final Arena arena : s.af) {
            gui.addItem(new GUIItem(i.a(arena.getIcon(), ChatColor.WHITE + arena.getName())) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.a(player, arena);
                }
            });
        }
        if (de.marcely.bedwars.config.b.d().size() >= 1) {
            for (int i = 0; i < de.marcely.bedwars.config.b.d().size() - s.af.size(); ++i) {
                gui.addItem(new DecGUIItem(i.a(new ItemStack(Material.COAL, 0), ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.NotFound_Arena_Loading).f((CommandSender)player))));
            }
        }
        gui.centerAtYAll(GUI.CenterFormatType.Normal);
        gui.open(player);
        final c a = this.a(player);
        a.i = true;
        a.b = null;
    }
    
    private void a(final Player player, final Arena arena) {
        final Map.Entry entry = this.a(arena, player, new b() {
            @Override
            public void a(final SimpleGUI simpleGUI, final String s) {
                f.this.a(simpleGUI, s, arena.getName(), player);
            }
        }).entrySet().stream().toArray(Map.Entry[]::new)[0];
        this.a(entry.getKey(), (String)entry.getValue(), arena.getName(), player);
    }
    
    private void a(final SimpleGUI b, final String s, final String s2, final Player player) {
        (this.a(player).b = b).setTitle(this.a(s2, s));
        b.open(player);
    }
    
    private String a(final String str, final String... array) {
        String obj = ChatColor.GOLD + str;
        for (int length = array.length, i = 0; i < length; ++i) {
            obj = String.valueOf(obj) + ChatColor.YELLOW + " > " + ChatColor.GOLD + array[i];
        }
        return obj;
    }
    
    private void a(final Arena arena, final Team team, final Player player) {
        final GUI a = this.a(player, arena, i.a(new ItemStack(Material.WOOL, 1, (short)team.getDyeColor().getWoolData()), team.getChatColor() + team.a((CommandSender)player, true)), "Teams", team.a((CommandSender)player, true));
        a.setHeight(3);
        a.setItemAt(new GUIItem(i.a(new ItemStack(Material.STONE_PLATE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Teams_SetSpawn).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("team").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "setspawn", arena.getName(), team.name()).toArray(new String[5]));
            }
        }, 3, 2);
        a.setItemAt(new GUIItem(i.a(new ItemStack(Material.BED), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Teams_GetBed).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("team").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "getbed", team.name()).toArray(new String[4]));
            }
        }, 5, 2);
        a.open(player);
    }
    
    private void a(final Arena arena, final DropType dropType, final Player player) {
        final GUI a = this.a(player, arena, i.a(dropType.getActualItemstack(), ((dropType.getChatColor() != null) ? dropType.getChatColor() : ChatColor.ITALIC) + dropType.a((CommandSender)player, true)), "Itemspawners", dropType.a((CommandSender)player, true));
        a.setHeight(3);
        a.setItemAt(new GUIItem(i.a(new ItemStack(Material.STONE_PLATE), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners_Add).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                ((f)dropType).cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "add", arena.getName(), dropType.getName()).toArray(new String[5]));
            }
        }, 3, 2);
        a.setItemAt(new GUIItem(i.a(new ItemStack(Material.DROPPER), de.marcely.bedwars.message.b.a(Language.ArenaGUI_Page_Itemspawners_Get).a("amount", "10").f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                ((f)dropType).cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "get", dropType.getName(), "10").toArray(new String[5]));
            }
        }, 5, 2);
        a.open(player);
    }
    
    private GUI a(final Player player, final Arena arena, final ItemStack itemStack, final String s, final String s2) {
        final GUI gui = new GUI(this.a(arena.getName(), s, s2), 2);
        gui.setItemAt(new DecGUIItem(arena.getIcon()), 3, 0);
        gui.setItemAt(new DecGUIItem(itemStack), 5, 0);
        gui.setItemAt(new GUIItem(f.b) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.a(player, arena);
            }
        }, 0, 0);
        for (int i = 0; i < 9; ++i) {
            gui.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15), " ")), i, 1);
        }
        return gui;
    }
    
    private LinkedHashMap<SimpleGUI, String> a(final Arena arena, final Player player, final b b) {
        final LinkedHashMap<SimpleGUI, String> linkedHashMap = new LinkedHashMap<SimpleGUI, String>();
        final ItemStack a = i.a(i.a("MHF_ArrowLeft", 1), ChatColor.DARK_AQUA + "< " + ChatColor.AQUA);
        final ItemStack a2 = i.a(i.a("MHF_ArrowRight", 1), ChatColor.DARK_AQUA + "> " + ChatColor.AQUA);
        final a a3 = new a(arena, "");
        final String f = b.a(Language.ArenaGUI_Page_Main).f((CommandSender)player);
        final a a4 = new a(arena, "");
        final String f2 = b.a(Language.ArenaGUI_Page_Teams).f((CommandSender)player);
        final a a5 = new a(arena, "");
        final String f3 = b.a(Language.ArenaGUI_Page_Itemspawners).f((CommandSender)player);
        final a a6 = new a(arena, "");
        final String f4 = b.a(Language.ArenaGUI_Page_Flags).f((CommandSender)player);
        a3.a(new GUIItem(i.a(new ItemStack(Material.WORKBENCH), b.a(Language.ArenaGUI_Page_Main_Configure).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("configure").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack((Version.a().getVersionNumber() >= 8) ? Material.BIRCH_DOOR_ITEM : Material.BEACON), b.a(Language.ArenaGUI_Page_Main_SetLobby).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("setlobby").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack(Material.NAME_TAG), b.a(Language.ArenaGUI_Page_Main_Rename).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                final AnvilGUI anvilGUI = new AnvilGUI(arena.getName());
                anvilGUI.setTitle(b.a(Language.ArenaGUI_Page_Main_Rename).f((CommandSender)player));
                anvilGUI.setWroteListener(new AnvilGUI.WroteListener() {
                    @Override
                    public void run(final String s) {
                        f.this.cmd.a().a("flag").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "setname", arena.getName(), s).toArray(new String[5]));
                    }
                });
                anvilGUI.open(player);
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack(Material.STAINED_CLAY, 1, (short)5), b.a(Language.ArenaGUI_Page_Main_Enable).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("setenabled").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName(), "true").toArray(new String[4]));
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack(Material.STAINED_CLAY, 1, (short)14), b.a(Language.ArenaGUI_Page_Main_Disable).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("setenabled").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName(), "false").toArray(new String[4]));
            }
        });
        if (arena.a().J()) {
            a3.a(new GUIItem(i.a(new ItemStack(Material.FURNACE), b.a(Language.ArenaGUI_Page_Main_Regenerate).f((CommandSender)player))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.cmd.a().a("regenerate").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
            a3.a(new GUIItem(i.a(new ItemStack(Material.HOPPER), b.a(Language.ArenaGUI_Page_Main_SaveBlocks).f((CommandSender)player))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.cmd.a().a("saveblocks").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
        }
        a3.a(new GUIItem(i.a(new ItemStack(Material.GRASS), b.a(Language.ArenaGUI_Page_Main_SetWorld).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("setworld").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        if (arena.a() == RegenerationType.c) {
            a3.a(new GUIItem(i.a(new ItemStack(Material.WOOD_AXE), b.a(Language.ArenaGUI_Page_Main_SetPosition).f((CommandSender)player))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.cmd.a().a("setposition").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
                }
            });
        }
        a3.a(new GUIItem(i.a(new ItemStack(Material.EYE_OF_ENDER), b.a(Language.ArenaGUI_Page_Main_SetSpectatorSpawn).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("setspectatorspawn").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack(Material.ENDER_PEARL), b.a(Language.ArenaGUI_Page_Main_Teleport).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("teleport").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        a3.a(new GUIItem(i.a(new ItemStack(Material.GLOWSTONE_DUST), b.a(Language.ArenaGUI_Page_Main_Enter).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                final String b3 = s.b(player, arena);
                if (b3 != null) {
                    player.sendMessage(b3);
                }
            }
        });
        if (arena.a().J()) {
            a3.a(new GUIItem(i.a(new ItemStack(Material.SULPHUR), b.a(Language.ArenaGUI_Page_Main_EnterSpectator).f((CommandSender)player))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    cA.a(player, arena, SpectateReason.ENTER);
                }
            });
        }
        a3.a(new GUIItem(i.a(new ItemStack(Material.SIGN), b.a(Language.ArenaGUI_Page_Main_Info).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("info").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", arena.getName()).toArray(new String[3]));
            }
        });
        for (final Team team : arena.a().r()) {
            a4.a(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)team.getDyeColor().getWoolData()), team.getChatColor() + team.a((CommandSender)player, true))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.a(arena, team, player);
                }
            });
        }
        a5.a(new GUIItem(i.a(new ItemStack(s.e), b.a(Language.ArenaGUI_Page_Itemspawners_Remove).f((CommandSender)player))) {
            @Override
            public void onClick(final Player player, final boolean b, final boolean b2) {
                f.this.cmd.a().a("itemspawner").a().a((CommandSender)player, "bw", "", Arrays.asList("", "", "remove", arena.getName()).toArray(new String[4]));
            }
        });
        a5.a(new DecGUIItem(new ItemStack(Material.PORTAL)));
        for (final DropType dropType : DropType.values()) {
            a5.a(new GUIItem(i.a(dropType.getActualItemstack(), ((dropType.getChatColor() != null) ? dropType.getChatColor() : ChatColor.ITALIC) + dropType.a((CommandSender)player, true))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.a(arena, dropType, player);
                }
            });
        }
        for (final Flag flag : arena.p()) {
            a6.a(new GUIItem(i.a(new ItemStack(Material.SIGN), b.a(Language.ArenaGUI_Page_Flags_Modify).a("name", flag.getName()).a("type", flag.getType().name()).f((CommandSender)player))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    final AnvilGUI anvilGUI = new AnvilGUI(String.valueOf(flag.getValue()));
                    anvilGUI.setTitle(b.a(Language.ArenaGUI_Page_Flags_Modify).a("name", flag.getName()).a("type", flag.getType().name()).f((CommandSender)player));
                    anvilGUI.setWroteListener(new AnvilGUI.WroteListener() {
                        @Override
                        public void run(final String s) {
                            if (((Flag)player).getType().isInstance(r.b(s))) {
                                ((Flag)player).setValue(r.b(s));
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Flag_Modfiy_Success).a("name", ((Flag)player).getName()).a("to", s));
                            }
                            else {
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Flag_Modfiy_WrongType).a("value", s).a("type", ((Flag)player).getType().name()));
                            }
                            f.this.a(player, arena);
                        }
                    });
                    anvilGUI.open(player);
                }
            });
        }
        linkedHashMap.put(a3.a(), f);
        if (arena.a().J()) {
            linkedHashMap.put(a4.a(), f2);
            linkedHashMap.put(a5.a(), f3);
        }
        linkedHashMap.put(a6.a(), f4);
        final Iterator<SimpleGUI> iterator4 = linkedHashMap.keySet().iterator();
        SimpleGUI key = null;
        for (SimpleGUI simpleGUI = iterator4.next(), key2 = iterator4.hasNext() ? iterator4.next() : null; simpleGUI != null; simpleGUI = key2, key2 = (iterator4.hasNext() ? iterator4.next() : null)) {
            final GUI gui = (GUI)simpleGUI;
            if (key != null) {
                final String s = linkedHashMap.get(key);
                gui.setItemAt(new GUIItem(i.b(a.clone(), s)) {
                    @Override
                    public void onClick(final Player player, final boolean b, final boolean b2) {
                        ((b)key).a(key, s);
                    }
                }, 0, 1);
            }
            if (key2 != null) {
                final String s2 = linkedHashMap.get(key2);
                gui.setItemAt(new GUIItem(i.b(a2.clone(), s2)) {
                    @Override
                    public void onClick(final Player player, final boolean b, final boolean b2) {
                        ((b)key2).a(key2, s2);
                    }
                }, 8, 1);
            }
            key = simpleGUI;
        }
        return linkedHashMap;
    }
    
    private class a
    {
        private final Arena arena;
        private final String title;
        private List<GUIItem> items;
        private GUIItem b;
        private GUIItem c;
        private boolean h;
        private GUI gui;
        
        public a(final Arena arena, final String title) {
            this.items = new ArrayList<GUIItem>();
            this.b = null;
            this.c = null;
            this.h = true;
            this.gui = null;
            this.arena = arena;
            this.title = title;
        }
        
        public void a(final GUIItem guiItem) {
            this.items.add(guiItem);
            this.h = true;
        }
        
        public SimpleGUI a() {
            if (!this.h) {
                return this.gui;
            }
            (this.gui = new GUI(this.title, 2)).setItemAt(new DecGUIItem(this.arena.getIcon()), 4, 0);
            this.gui.setItemAt(new GUIItem(f.b) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    f.this.d(player);
                }
            }, 0, 0);
            for (int i = 0; i < 9; ++i) {
                this.gui.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)15), " ")), i, 1);
            }
            if (this.b != null) {
                this.gui.setItemAt(this.b, 0, 1);
            }
            if (this.c != null) {
                this.gui.setItemAt(this.c, 8, 1);
            }
            final Iterator<GUIItem> iterator = this.items.iterator();
            while (iterator.hasNext()) {
                this.gui.addItem(iterator.next(), GUI.AddItemFlag.createWithinY(2, 6));
            }
            for (int j = 2; j < this.gui.getHeight(); ++j) {
                this.gui.centerAtY(j, GUI.CenterFormatType.Normal);
            }
            this.h = false;
            return this.gui;
        }
    }
    
    private static class c
    {
        public boolean i;
        @Nullable
        public SimpleGUI b;
        
        private c() {
            this.i = false;
            this.b = null;
        }
    }
    
    private interface b
    {
        void a(final SimpleGUI p0, final String p1);
    }
}
