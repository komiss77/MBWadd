// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.Arrays;
import de.marcely.bedwars.util.k;
import java.util.List;
import java.util.Iterator;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import java.util.ArrayList;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class e implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String str, final String s, final String[] array) {
        if (array.length >= 5 && array[2].equalsIgnoreCase("setname")) {
            final Arena b = s.b(array[3]);
            if (b != null) {
                if (b.f(array[4])) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b.getName()));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", array[4]));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("seticon")) {
            final Arena b2 = s.b(array[3]);
            if (b2 != null) {
                final ItemStack b3 = i.b(array[4]);
                if (b3 != null) {
                    b2.setIcon(b3);
                    de.marcely.bedwars.config.b.b(b2);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b2.getName()));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Block).a("block", array[4]));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("addauthor")) {
            final Arena b4 = s.b(array[3]);
            if (b4 != null) {
                final String n = b4.n();
                String s2;
                if (n == "") {
                    s2 = array[4].replace("\\,", "");
                }
                else {
                    s2 = String.valueOf(n) + ", " + array[4].replace("\\,", "");
                }
                b4.v(s2);
                de.marcely.bedwars.config.b.b(b4);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b4.getName()));
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("delauthor")) {
            final Arena b5 = s.b(array[3]);
            if (b5 != null) {
                final String[] split = b5.n().split("\\,");
                final ArrayList<String> list = new ArrayList<String>();
                boolean b6 = false;
                String[] array2;
                for (int length = (array2 = split).length, i = 0; i < length; ++i) {
                    final String e = array2[i];
                    if (!e.equalsIgnoreCase(array[4])) {
                        list.add(e);
                    }
                    else {
                        b6 = true;
                    }
                }
                if (!b6) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotFound_Author).a("author", array[4]));
                    return;
                }
                if (list.size() != 0) {
                    int n2 = 0;
                    String s3 = "";
                    for (final String s4 : list) {
                        if (list.size() == n2 + 1) {
                            s3 = String.valueOf(s3) + s4;
                        }
                        else {
                            s3 = String.valueOf(s3) + s4 + ",";
                        }
                        ++n2;
                    }
                    b5.v(s3);
                }
                de.marcely.bedwars.config.b.b(b5);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b5.getName()));
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("setminplayers")) {
            final Arena b7 = s.b(array[3]);
            if (b7 != null) {
                if (s.isInteger(array[4])) {
                    final int intValue = Integer.valueOf(array[4]);
                    if (intValue >= 2) {
                        b7.setMinPlayers(intValue);
                        de.marcely.bedwars.config.b.b(b7);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b7.getName()));
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NeedMore_Players_Than).a("amount", array[4]));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[4]));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("sethascustomname")) {
            final Arena b8 = s.b(array[3]);
            if (b8 != null) {
                if (s.isBoolean(array[4])) {
                    b8.setHasCustomName(Boolean.parseBoolean(array[4]));
                    de.marcely.bedwars.config.b.b(b8);
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b8.getName()));
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("setcustomname")) {
            final Arena b9 = s.b(array[3]);
            if (b9 != null) {
                String string = array[4];
                for (int j = 5; j < array.length; ++j) {
                    string = String.valueOf(string) + " " + array[j];
                }
                b9.setCustomName(string);
                de.marcely.bedwars.config.b.b(b9);
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b9.getName()));
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else {
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender)).toString());
            for (int k = 0; k < 2; ++k) {
                commandSender.sendMessage("");
            }
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " setname" + ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " seticon" + ChatColor.AQUA + " <arena name> <block>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " addauthor" + ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " delauthor" + ChatColor.AQUA + " <arena name> <name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " setminplayers" + ChatColor.AQUA + " <arena name> <amount>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " sethascustomname" + ChatColor.AQUA + " <arena name> <true/false>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + str + array[0].toLowerCase() + " " + array[1].toLowerCase() + " setcustomname" + ChatColor.AQUA + " <arena name> <name (can contain space)>");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        final String s2 = array[0];
        if (array.length == 2) {
            return s.a(s.A(), array[1]);
        }
        if (array.length == 3) {
            if (s2.equalsIgnoreCase("seticon")) {
                return s.a(k.y(), array[2]);
            }
            if (s2.equalsIgnoreCase("addauthor")) {
                return null;
            }
            if (s2.equalsIgnoreCase("delauthor")) {
                final Arena b = s.b(array[1]);
                if (b != null) {
                    return s.a(Arrays.asList(b.b()), array[2]);
                }
                return null;
            }
        }
        return new ArrayList<String>();
    }
    
    private List<String> b() {
        return Arrays.asList("setname", "seticon", "addauthor", "delauthor", "setminplayers", "sethascustomname", "setcustomname");
    }
}
