// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import de.marcely.bedwars.game.arena.KickReason;
import org.bukkit.ChatColor;
import de.marcely.bedwars.game.arena.CrashMessage;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.ArenaStatus;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.event.EnableArenaEvent;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class o implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (array.length >= 4) {
            final de.marcely.bedwars.game.arena.Arena b = s.b(array[2]);
            if (b != null) {
                if (s.isBoolean(array[3])) {
                    if (Boolean.valueOf(array[3])) {
                        final EnableArenaEvent enableArenaEvent = new EnableArenaEvent(b, b.getProblems());
                        Bukkit.getPluginManager().callEvent((Event)enableArenaEvent);
                        final List<CrashMessage> crashMessages = enableArenaEvent.getCrashMessages();
                        if (crashMessages.size() == 0) {
                            b.a(ArenaStatus.e);
                            de.marcely.bedwars.config.b.b(b);
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Enabled_Arena).a("arena", b.getName()));
                        }
                        else {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.FixProblemsBeforeEnabled));
                            for (final CrashMessage crashMessage : crashMessages) {
                                if (crashMessage.getInformation() == null) {
                                    commandSender.sendMessage(ChatColor.GRAY + "- " + ChatColor.RED + crashMessage.getMessage());
                                }
                                else {
                                    commandSender.sendMessage(ChatColor.GRAY + "- " + ChatColor.RED + crashMessage.getMessage() + ChatColor.DARK_RED + " (" + crashMessage.getInformation() + ")");
                                }
                            }
                        }
                    }
                    else {
                        b.a(KickReason.c);
                        b.a(ArenaStatus.d);
                        de.marcely.bedwars.config.b.b(b);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Disabled_Arena).a("arena", b.getName()));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[2]);
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        if (array.length == 2) {
            return s.a(Arrays.asList("true", "false"), array[1]);
        }
        return new ArrayList<String>();
    }
}
