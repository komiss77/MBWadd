// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Iterator;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import de.marcely.bedwars.api.event.CommandArenaFireEvent;
import de.marcely.bedwars.Language;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.api.BedwarsAPI;
import de.marcely.bedwars.library.worldedit.a;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandExecutor;

public class CommandHandler implements CommandExecutor
{
    private List<Command> f;
    
    public CommandHandler() {
        this.f = new ArrayList<Command>();
        this.refresh();
    }
    
    public void refresh() {
        this.f.clear();
        this.f.add(new Command(this, new h(), false, false, "", new String[] { "help" }));
        this.f.add(new Command(this, new k(), false, "", new String[] { "list", "arenas", "all" }));
        this.f.add(new Command(this, new f(), true, "[arena name]", new String[] { "gui", "easy", "createeasy", "setupeasy", "easily", "fast", "quick" }));
        this.f.add(new Command(this, new t(), true, "", new String[] { "setupitem", "item", "guiitem", "quickitem", "fastitem", "createitem" }));
        this.f.add(new Command(this, new d(), true, "<arena name> [made by...]", new String[] { "create", "createarena", "createnewarena", "newarena" }));
        if (s.b == null || !s.b.get(a.class).isInjected()) {
            this.f.add(new Command(this, new g(), true, "", new String[] { "getpositionaxe", "getaxe", "positionaxe", "axe" }));
        }
        this.f.add(new Command(this, new m(), false, "<arena name>", new String[] { "remove", "rm", "delete", "del", "removearena", "delarena", "deletearena" }));
        this.f.add(new Command(this, new c(), true, "<arena name>", new String[] { "configure", "conf", "configurate", "setup" }));
        if (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
            this.f.add(new Command(this, new u(), true, "[args...]", new String[] { "team" }));
        }
        if (BedwarsAPI.getOpenAPIConfiguration().itemspawnersEnabled) {
            this.f.add(new Command(this, new j(), true, "[args...]", new String[] { "itemspawner", "is" }));
        }
        this.f.add(new Command(this, new p(), true, "<arena name>", new String[] { "setlobby" }));
        this.f.add(new Command(this, new e(), false, "[args...]", new String[] { "flag", "modify" }));
        this.f.add(new Command(this, new o(), false, "<arena name> <bool (true/false)>", new String[] { "setenabled", "enabled", "setenable", "enable" }));
        this.f.add(new Command(this, new l(), false, "<arena name>", new String[] { "regenerate", "regen", "updateblocks" }));
        this.f.add(new Command(this, new n(), false, "<arena name>", new String[] { "saveblocks", "updateblocks" }));
        this.f.add(new Command(this, new q(), true, "<arena name>", new String[] { "setposition", "updatelocation", "changeposition", "changelocation", "setcorner", "setcorners" }));
        this.f.add(new Command(this, new de.marcely.bedwars.command.arena.s(), true, "<arena name>", new String[] { "setworld", "updateworld", "changeworld" }));
        this.f.add(new Command(this, new r(), true, "<arena name>", new String[] { "setspectatorspawn", "setspectatorpoint", "setspectator" }));
        this.f.add(new Command(this, new v(), true, "<arena name>", new String[] { "teleport", "tp" }));
        this.f.add(new Command(this, new b(), false, "<arena name> <new arena name>", new String[] { "clone", "copy", "duplicate" }));
        this.f.add(new Command(this, new i(), false, "<arena name>", new String[] { "info", "information", "informations" }));
    }
    
    public boolean onCommand(final CommandSender commandSender, final org.bukkit.command.Command command, final String str, final String[] array) {
        if (array.length >= 2) {
            final Command a = this.a(array[1]);
            if (a != null) {
                if (!a.f || (a.f && commandSender instanceof Player)) {
                    this.a(a, commandSender, str, "/" + str + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " " + a.usage, array);
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                }
            }
            else if (!s.isInteger(array[1])) {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Argument).a("arg", array[1]));
            }
            else {
                this.a(this.f.get(0), commandSender, str, null, array);
            }
        }
        else {
            this.a(this.f.get(0), commandSender, str, null, array);
        }
        return true;
    }
    
    private void a(final Command command, final CommandSender commandSender, final String s, final String s2, final String... array) {
        final CommandArenaFireEvent commandArenaFireEvent = new CommandArenaFireEvent(commandSender, command);
        Bukkit.getPluginManager().callEvent((Event)commandArenaFireEvent);
        if (!commandArenaFireEvent.isCancelled()) {
            command.a.a(commandSender, s, s2, array);
        }
    }
    
    public List<Command> getCommands() {
        return this.f;
    }
    
    public List<String> c() {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator<Command> iterator = this.f.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().a()[0]);
        }
        return list;
    }
    
    public Command a(final String s) {
        final String lowerCase = s.toLowerCase();
        for (final Command command : this.f) {
            String[] a;
            for (int length = (a = command.a).length, i = 0; i < length; ++i) {
                if (lowerCase.equals(a[i])) {
                    return command;
                }
            }
        }
        return null;
    }
    
    public List<String> b(final String[] original, final String s, final CommandSender commandSender) {
        if (original.length == 0) {
            return this.c();
        }
        if (original.length == 1) {
            return s.a(this.c(), original[0]);
        }
        final Command a = this.a(original[0]);
        if (a != null) {
            return a.a().a(Arrays.copyOfRange(original, 1, original.length), s, commandSender);
        }
        return new ArrayList<String>();
    }
    
    public static class Command
    {
        protected CommandHandler b;
        protected a a;
        protected boolean f;
        protected boolean visible;
        protected String usage;
        protected String[] a;
        
        public Command(final CommandHandler commandHandler, final a a, final boolean b, final String s, final String... array) {
            this(commandHandler, a, b, true, s, array);
        }
        
        public Command(final CommandHandler b, final a a, final boolean f, final boolean visible, final String usage, final String... a2) {
            this.b = b;
            this.a = a;
            this.f = f;
            this.visible = visible;
            this.usage = usage;
            this.a = a2;
            a.a(this);
        }
        
        public CommandHandler a() {
            return this.b;
        }
        
        public a a() {
            return this.a;
        }
        
        public boolean n() {
            return this.f;
        }
        
        public boolean isVisible() {
            return this.f;
        }
        
        public String getUsage() {
            return this.usage;
        }
        
        public String[] a() {
            return this.a;
        }
        
        public interface a
        {
            void a(final Command p0);
            
            void a(final CommandSender p0, final String p1, final String p2, final String[] p3);
            
            @Nullable
            List<String> a(final String[] p0, final String p1, final CommandSender p2);
        }
    }
}
