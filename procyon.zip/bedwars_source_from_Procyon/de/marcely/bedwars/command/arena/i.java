// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import de.marcely.bedwars.game.arena.RegenerationType;
import org.bukkit.entity.Player;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class i implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (array.length >= 3) {
            final Arena b = s.b(array[2]);
            if (b != null) {
                if (commandSender instanceof Player) {
                    if (b.a() == RegenerationType.c) {
                        for (int i = 0; i < 2; ++i) {
                            commandSender.sendMessage("");
                        }
                    }
                    else {
                        for (int j = 0; j < 4; ++j) {
                            commandSender.sendMessage("");
                        }
                    }
                }
                commandSender.sendMessage(ChatColor.DARK_AQUA + "======== " + ChatColor.AQUA + b.getName() + ChatColor.DARK_AQUA + " ========");
                String name = "null";
                if (b.getWorld() != null) {
                    name = b.getWorld().getName();
                }
                commandSender.sendMessage(ChatColor.DARK_GREEN + "World " + ChatColor.GREEN + name);
                commandSender.sendMessage(ChatColor.DARK_GREEN + "Status " + ChatColor.GREEN + b.b().name());
                commandSender.sendMessage(ChatColor.DARK_GREEN + "Players " + ChatColor.GREEN + b.getPlayers().size() + "/" + b.getMaxPlayers());
                commandSender.sendMessage(ChatColor.DARK_GREEN + "Regeneration type " + ChatColor.GREEN + b.a().name());
                commandSender.sendMessage(ChatColor.DARK_GREEN + "Is Sleeping " + ChatColor.GREEN + b.isSleeping());
                if (b.a().J()) {
                    commandSender.sendMessage(ChatColor.DARK_GREEN + "Regeneration time " + ChatColor.GREEN + "~" + (int)b.a() + "s");
                }
                if (b.a() == RegenerationType.c) {
                    commandSender.sendMessage(ChatColor.DARK_GREEN + "PosMin " + ChatColor.GREEN + "X" + b.getPosMin().getX() + " Y" + b.getPosMin().getY() + " Z" + b.getPosMin().getZ());
                    commandSender.sendMessage(ChatColor.DARK_GREEN + "PosMax " + ChatColor.GREEN + "X" + b.getPosMax().getX() + " Y" + b.getPosMax().getY() + " Z" + b.getPosMax().getZ());
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[2]);
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
}
