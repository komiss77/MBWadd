// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class h implements CommandHandler.Command.a
{
    public static final int f = 7;
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        int i = 1;
        final int e = this.e();
        if (array.length >= 2 && s.isInteger(array[1])) {
            i = Integer.valueOf(array[1]);
        }
        else if (array.length >= 3 && s.isInteger(array[2])) {
            i = Integer.valueOf(array[2]);
        }
        final List<CommandHandler.Command> a = this.a(i);
        commandSender.sendMessage(ChatColor.YELLOW + " ---- " + ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Help).f(commandSender) + ChatColor.YELLOW + " -- " + ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Page).f(commandSender) + " " + i + ChatColor.RED + "/" + ChatColor.GOLD + e + ChatColor.YELLOW + " ----");
        commandSender.sendMessage(ChatColor.GRAY + "/" + s + " " + array[0] + " " + this.cmd.a[0] + " " + ChatColor.DARK_GRAY + "[" + de.marcely.bedwars.message.b.a(Language.Page).f(commandSender) + "]");
        for (int j = 0; j < 7 - a.size() + 1; ++j) {
            commandSender.sendMessage("");
        }
        for (final CommandHandler.Command command : a) {
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0] + " " + command.a[0] + " " + ChatColor.AQUA + command.usage);
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        final ArrayList<String> list = new ArrayList<String>();
        for (int i = 1; i <= this.e(); ++i) {
            list.add(new StringBuilder().append(i).toString());
        }
        return list;
    }
    
    public List<CommandHandler.Command> a(final int n) {
        final ArrayList<CommandHandler.Command> list = new ArrayList<CommandHandler.Command>();
        int n2 = 1;
        int n3 = 0;
        for (final CommandHandler.Command command : this.cmd.b.getCommands()) {
            if (n3 >= 7) {
                ++n2;
                n3 = 0;
            }
            ++n3;
            if (!command.visible) {
                --n3;
            }
            if (command.visible && n2 == n) {
                list.add(command);
            }
        }
        return list;
    }
    
    public int e() {
        return (this.cmd.b.getCommands().size() + 7 - 1 - this.f()) / 7;
    }
    
    public int f() {
        int n = 0;
        final Iterator<CommandHandler.Command> iterator = this.cmd.b.getCommands().iterator();
        while (iterator.hasNext()) {
            if (!iterator.next().visible) {
                ++n;
            }
        }
        return n;
    }
}
