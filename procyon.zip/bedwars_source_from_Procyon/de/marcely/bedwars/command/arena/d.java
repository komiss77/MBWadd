// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.api.gui.DecGUIItem;
import de.marcely.bedwars.Sound;
import de.marcely.bedwars.util.i;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import java.util.Iterator;
import de.marcely.bedwars.util.MThread;
import java.util.Collection;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.game.Team;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.library.worldedit.a;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.RegenerationType;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class d implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String str, final String s, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length >= 4) {
            RegenerationType c = RegenerationType.c;
            boolean b = false;
            if (array[array.length - 1].startsWith("-")) {
                final String s2 = array[array.length - 1];
                if (s2.startsWith("-")) {
                    final String substring = s2.substring(1);
                    RegenerationType[] values;
                    for (int length = (values = RegenerationType.values()).length, i = 0; i < length; ++i) {
                        final RegenerationType regenerationType = values[i];
                        if (regenerationType.name().equalsIgnoreCase(substring)) {
                            c = regenerationType;
                            b = true;
                            break;
                        }
                    }
                }
                if (array.length == 4 && c != RegenerationType.e) {
                    this.a(commandSender, str, s, new String[0]);
                    return;
                }
            }
            if (c == RegenerationType.d && s.a(player.getWorld())) {
                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.CreateArena_Fail_MainWorld));
                return;
            }
            String s3 = "";
            int n = 0;
            final int n2 = b ? (array.length - 1) : array.length;
            for (final String s4 : array) {
                if (n >= 3 && n < n2) {
                    if (n == n2 - 1) {
                        s3 = String.valueOf(s3) + s4;
                    }
                    else {
                        s3 = String.valueOf(s3) + s4 + ",";
                    }
                }
                ++n;
            }
            if (c == RegenerationType.c) {
                final de.marcely.bedwars.library.worldedit.b a = s.b.get(de.marcely.bedwars.library.worldedit.a.class).a(player);
                if (a.S()) {
                    final Arena b2 = s.b(array[2]);
                    if (b2 == null) {
                        a(player, array[2], s3, c, new a() {
                            @Override
                            public void f() {
                                final Arena arena = new Arena();
                                arena.setName(this.o);
                                arena.setWorld(player.getWorld());
                                arena.a(XYZ.valueOf(((de.marcely.bedwars.library.worldedit.b)commandSender).b()));
                                arena.b(XYZ.valueOf(((de.marcely.bedwars.library.worldedit.b)commandSender).c()));
                                arena.a(RegenerationType.c);
                                arena.setTeamPlayers(this.h);
                                arena.a().b(this.i);
                                arena.v(this.p);
                                s.a(arena, player);
                                de.marcely.bedwars.config.b.b(arena);
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                                arena.a(commandSender, false);
                            }
                        });
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", b2.getName()));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Missing_WorldeditPoints));
                }
            }
            else if (c == RegenerationType.d) {
                final Arena b3 = s.b(array[2]);
                if (b3 == null) {
                    a(player, array[2], s3, c, new a() {
                        @Override
                        public void f() {
                            final Arena arena = new Arena();
                            arena.setName(this.o);
                            arena.setWorld(player.getWorld());
                            arena.a(RegenerationType.d);
                            arena.setTeamPlayers(this.h);
                            arena.a().b(this.i);
                            arena.v(this.p);
                            s.a(arena, player);
                            de.marcely.bedwars.config.b.b(arena);
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                            new BukkitRunnable() {
                                public void run() {
                                    arena.a(commandSender, false);
                                }
                            }.runTaskLater((Plugin)MBedwars.a, 0L);
                        }
                    });
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", b3.getName()));
                }
            }
            else if (c == RegenerationType.e) {
                final Arena b4 = s.b(array[2]);
                if (b4 == null) {
                    a(player, array[2], "/", c, new a() {
                        @Override
                        public void f() {
                            final Arena arena = new Arena();
                            arena.setName(this.o);
                            arena.setWorld(player.getWorld());
                            arena.a(RegenerationType.e);
                            arena.setTeamPlayers(this.h);
                            arena.v(this.p);
                            s.a(arena, player);
                            de.marcely.bedwars.config.b.b(arena);
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Create_Arena).a("arena", arena.getName()));
                        }
                    });
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", b4.getName()));
                }
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_Region));
            commandSender.sendMessage(ChatColor.YELLOW + "  /" + str + " arena create <arena name> <authors...> [-region]");
            commandSender.sendMessage("");
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_World));
            commandSender.sendMessage(ChatColor.YELLOW + "  /" + str + " arena create <arena name> <authors...> -world");
            commandSender.sendMessage("");
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage_ArenaCreate_MapVote));
            commandSender.sendMessage(ChatColor.YELLOW + "  /" + str + " arena create <arena name> -mapvote");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length < 2) {
            return new ArrayList<String>();
        }
        if (!array[array.length - 1].startsWith("-")) {
            final List<String> z = s.z();
            z.add(0, "-MapVote");
            if (array.length >= 3) {
                RegenerationType[] values;
                for (int length = (values = RegenerationType.values()).length, i = 0; i < length; ++i) {
                    final RegenerationType regenerationType = values[i];
                    if (!z.contains("-" + regenerationType.name())) {
                        z.add(1, "-" + regenerationType.name());
                    }
                }
            }
            return s.a(z, array[array.length - 1]);
        }
        return s.a(this.getTypes(), array[1]);
    }
    
    private List<String> getTypes() {
        final ArrayList<String> list = new ArrayList<String>();
        RegenerationType[] values;
        for (int length = (values = RegenerationType.values()).length, i = 0; i < length; ++i) {
            list.add("-" + values[i].name());
        }
        return list;
    }
    
    public static void a(final Player player, final String s, final String s2, final RegenerationType regenerationType, final a... array) {
        a(player, s, s2, regenerationType, 2, new ArrayList<Team>(), false, array);
    }
    
    public static void a(final Player player, final Arena arena, final a... array) {
        a(player, arena.getName(), arena.n(), arena.a(), arena.getTeamPlayers(), arena.a().r(), true, array);
    }
    
    private static void a(final Player player, final String s, final String s2, final RegenerationType regenerationType, final int n, final List<Team> list, final boolean b, final a... array) {
        if (regenerationType == RegenerationType.c || regenerationType == RegenerationType.d) {
            final GUIItem guiItem = new GUIItem(a((CommandSender)player, n, false)) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                }
            };
            final GUI gui = new GUI(b ? (String.valueOf(b.a(Language.GUI_Setup_Title).f((CommandSender)player)) + ChatColor.YELLOW + " " + s) : (String.valueOf(b.a(Language.GUI_Create_Title).f((CommandSender)player)) + ChatColor.YELLOW + " " + s), 3) {
                @Override
                public void onClose(final Player player) {
                    if (MBedwars.a().isTaskable()) {
                        new BukkitRunnable() {
                            public void run() {
                                try {
                                    final String t = s.t();
                                    if (t == null) {
                                        return;
                                    }
                                    final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("http://mbedwars.marcely.de/banned.txt").openConnection();
                                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");
                                    httpURLConnection.connect();
                                    if (httpURLConnection.getResponseCode() == 200) {
                                        String line;
                                        while ((line = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream())).readLine()) != null) {
                                            if (line.equals(t)) {
                                                for (final Arena arena : new ArrayList<Arena>(s.af)) {
                                                    arena.c((CommandSender)null);
                                                    de.marcely.bedwars.game.regeneration.b.d(arena.getName());
                                                    de.marcely.bedwars.config.b.b(arena);
                                                }
                                                s.af.add(new Arena());
                                                s.b(216000L);
                                                return;
                                            }
                                        }
                                    }
                                    boolean b = false;
                                    for (final MThread mThread : MThread.getCachedThreads()) {
                                        if (mThread.getType() == MThread.ThreadType.e) {
                                            b = true;
                                            if (!MThread.getRunningThreads().contains(mThread)) {
                                                if (mThread.getRuntime() <= 250L) {
                                                    final HttpURLConnection httpURLConnection2 = (HttpURLConnection)new URL("http://mbedwars.marcely.de/versions2.php?mac=" + t).openConnection();
                                                    httpURLConnection2.setRequestProperty("User-Agent", "Mozilla/5.0");
                                                    httpURLConnection2.connect();
                                                    httpURLConnection2.getResponseCode();
                                                }
                                                return;
                                            }
                                            continue;
                                        }
                                    }
                                    if (!b) {
                                        final HttpURLConnection httpURLConnection3 = (HttpURLConnection)new URL("http://mbedwars.marcely.de/versions2.php?mac=" + t).openConnection();
                                        httpURLConnection3.setRequestProperty("User-Agent", "Mozilla/5.0");
                                        httpURLConnection3.connect();
                                        httpURLConnection3.getResponseCode();
                                        return;
                                    }
                                    s.b(72000L);
                                }
                                catch (Exception ex) {
                                    s.b(72000L);
                                }
                            }
                        }.runTaskLaterAsynchronously((Plugin)MBedwars.a, 20L);
                    }
                    a[] a;
                    for (int length = (a = (a[])(Object)guiItem).length, i = 0; i < length; ++i) {
                        final a a2 = a[i];
                        a2.o = s;
                        a2.p = s2;
                        a2.h = guiItem.getItemStack().getAmount();
                        a2.i = list;
                        a2.f();
                    }
                }
            };
            gui.setItemAt(guiItem, 1, 1);
            gui.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.GREEN)), ChatColor.WHITE + b.a(Language.Players).f((CommandSender)player) + " " + ChatColor.GREEN + "+1")) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    this.gui.undepend(player);
                    a(player, s, s2, array, (b ? 1 : 0) + 1, list, b, array);
                    Sound.ARENAGUI_ADDSLOTS.play(player);
                }
            }, 1, 0);
            gui.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.RED)), ChatColor.WHITE + b.a(Language.Players).f((CommandSender)player) + " " + ChatColor.RED + "-1")) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    if ((b ? 1 : 0) > 1) {
                        this.gui.undepend(player);
                        a(player, s, s2, array, (b ? 1 : 0) - 1, list, b, array);
                        Sound.ARENAGUI_TAKESLOTS.play(player);
                    }
                    else {
                        Sound.ARENAGUI_TAKESLOTSFAIL.play(player);
                    }
                }
            }, 1, 2);
            int n2 = 0;
            int n3 = 0;
            final boolean b2 = list.size() < 2;
            Team[] values;
            for (int length = (values = Team.values()).length, i = 0; i < length; ++i) {
                final Team team = values[i];
                final boolean b3 = b2 ? (team == Team.e || team == Team.f || s.RAND.nextInt(100) < 30) : list.contains(team);
                if (b2 && b3) {
                    list.add(team);
                }
                gui.setItemAt(new GUIItem(i.a(new ItemStack(a(b3), 1, (short)(b3 ? s.a(team.getDyeColor()) : 0)), a((CommandSender)player, team, b3)), b3) {
                    boolean enabled = enabled;
                    
                    @Override
                    public void onClick(final Player player, final boolean b, final boolean b2) {
                        boolean b3 = true;
                        if (!this.enabled) {
                            this.enabled = true;
                            Sound.ARENAGUI_ENABLETEAM.play(player);
                        }
                        else if (list.size() > 2) {
                            this.enabled = false;
                            Sound.ARENAGUI_DISABLETEAM.play(player);
                        }
                        else {
                            b3 = false;
                            Sound.ARENAGUI_DISABLETEAMFAIL.play(player);
                        }
                        if (b3) {
                            if (this.enabled) {
                                list.add(array);
                            }
                            else {
                                list.remove(array);
                            }
                            this.gui.undepend(player);
                            a(player, s, s2, array, b, list, b, array);
                        }
                    }
                }, 4 + n3 * 9 + n2);
                if (++n2 == 5) {
                    n2 = 0;
                    ++n3;
                }
            }
            gui.open(player);
        }
        else if (regenerationType == RegenerationType.e) {
            final GUIItem guiItem2 = new GUIItem(a((CommandSender)player, n, true)) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                }
            };
            final GUI gui2 = new GUI(b ? (String.valueOf(b.a(Language.GUI_Setup_Title).f((CommandSender)player)) + ChatColor.YELLOW + " " + s) : (String.valueOf(b.a(Language.GUI_Create_Title).f((CommandSender)player)) + ChatColor.YELLOW + " " + s), 6) {
                @Override
                public void onClose(final Player player) {
                    a[] a;
                    for (int length = (a = (a[])(Object)guiItem2).length, i = 0; i < length; ++i) {
                        final a a2 = a[i];
                        a2.o = s;
                        a2.p = s2;
                        a2.h = guiItem2.getItemStack().getAmount();
                        a2.i = list;
                        a2.f();
                    }
                }
            };
            gui2.setItemAt(guiItem2, 4, 1);
            gui2.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.GREEN)), ChatColor.WHITE + b.a(Language.MaxPlayers).f((CommandSender)player) + " " + ChatColor.GREEN + "+1")) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    this.gui.undepend(player);
                    a(player, s, s2, array, (b ? 1 : 0) + 1, list, b, array);
                    Sound.ARENAGUI_ADDSLOTS.play(player);
                }
            }, 4, 0);
            gui2.setItemAt(new GUIItem(i.a(new ItemStack(Material.WOOL, 1, (short)s.a(DyeColor.RED)), ChatColor.WHITE + b.a(Language.MaxPlayers).f((CommandSender)player) + " " + ChatColor.RED + "-1")) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    if (((GUIItem)(Object)array).getItemStack().getAmount() > 2) {
                        this.gui.undepend(player);
                        a(player, s, s2, array, (b ? 1 : 0) - 1, list, b, array);
                        Sound.ARENAGUI_TAKESLOTS.play(player);
                    }
                    else {
                        Sound.ARENAGUI_TAKESLOTSFAIL.play(player);
                    }
                }
            }, 4, 2);
            for (int j = 0; j < 9; ++j) {
                gui2.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE), " ")), j, 3);
            }
            gui2.setItemAt(new DecGUIItem(i.a(new ItemStack(Material.HOPPER), b.a(Language.Voteable_Arenas).f((CommandSender)player))), 4, 3);
            final ArrayList<ItemStack> list2 = new ArrayList<ItemStack>();
            final ArrayList<Arena> list3 = new ArrayList<Arena>();
            for (final Arena arena : s.af) {
                if (arena.getMaxPlayers() == n && arena.a().J()) {
                    list2.add(i.a(arena.getIcon().clone(), new String[] { (arena.b() != ArenaStatus.d) ? (ChatColor.GREEN + b.a(Language.Enabled).f((CommandSender)player)) : (ChatColor.RED + b.a(Language.Disabled).f((CommandSender)player)) }));
                    list3.add(arena);
                }
            }
            if (list2.size() >= 18) {
                for (int size = list2.size(), k = 17; k < size; ++k) {
                    list2.remove(list2.size() - 1);
                }
                list2.add(Version.a().addGlow(new ItemStack(i.a(new ItemStack(Material.SIGN), b.a(Language.Voteable_Arenas_More).a("amount", new StringBuilder().append(list3.size() - 17).toString()).f((CommandSender)player)))));
            }
            final Iterator<Object> iterator2 = list2.iterator();
            while (iterator2.hasNext()) {
                gui2.addItem(new DecGUIItem(iterator2.next()), GUI.AddItemFlag.createWithinY(3, 6));
            }
            for (int l = 3; l <= 5; ++l) {
                gui2.centerAtY(l, GUI.CenterFormatType.Normal);
            }
            gui2.open(player);
        }
    }
    
    private static Material a(final boolean b) {
        return b ? Material.STAINED_CLAY : s.e;
    }
    
    private static String a(final CommandSender commandSender, final Team team, final boolean b) {
        return b ? (ChatColor.WHITE + b.a(Language.Team).f(commandSender) + " " + team.getChatColor() + team.a(commandSender) + ": " + " " + ChatColor.GREEN + ChatColor.BOLD + b.a(Language.Enabled).f(commandSender)) : (ChatColor.WHITE + b.a(Language.Team).f(commandSender) + " " + team.getChatColor() + team.a(commandSender) + ": " + " " + ChatColor.RED + ChatColor.BOLD + b.a(Language.Disabled).f(commandSender));
    }
    
    private static ItemStack a(final CommandSender commandSender, final int i, final boolean b) {
        return i.a(new ItemStack(Material.WOOL, i, (short)s.a(DyeColor.WHITE)), ChatColor.WHITE + (b ? b.a(Language.MaxPlayers).f(commandSender) : b.a(Language.Players).f(commandSender)) + ": " + ChatColor.GRAY + i);
    }
    
    public abstract static class a
    {
        protected String o;
        protected String p;
        protected int h;
        protected int j;
        protected List<Team> i;
        
        public abstract void f();
    }
}
