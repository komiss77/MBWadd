// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.location.XYZYP;
import org.bukkit.entity.Player;
import java.util.Arrays;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import org.bukkit.ChatColor;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class a implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (array.length >= 3) {
            final String lowerCase = array[2].toLowerCase();
            if (lowerCase.equals("info") && array.length >= 4) {
                final Arena b = s.b(array[3]);
                if (b != null) {
                    final List<Team> a = this.a(b);
                    final String[] a2 = new String[a.size()];
                    for (int i = 0; i < a.size(); ++i) {
                        a2[i] = a.get(i).a(commandSender, true);
                    }
                    final List<Team> b2 = this.b(b);
                    final String[] a3 = new String[b2.size()];
                    for (int j = 0; j < b2.size(); ++j) {
                        a3[j] = b2.get(j).a(commandSender, true);
                    }
                    commandSender.sendMessage(ChatColor.GRAY + "======= " + ChatColor.GOLD + de.marcely.bedwars.message.b.a(Language.Cages_Info_Title).f(commandSender) + ChatColor.GRAY + " =======");
                    commandSender.sendMessage(ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_Arena).f(commandSender) + ": " + ChatColor.AQUA + b.getName());
                    commandSender.sendMessage(ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_IsEnabled).f(commandSender) + ": " + ChatColor.AQUA + b.a().isEnabled());
                    commandSender.sendMessage(ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_Arena).f(commandSender) + ": " + ChatColor.AQUA + b.getName());
                    commandSender.sendMessage(ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_TeamsLeft).f(commandSender) + ": " + ChatColor.RED + Arrays.toString(a3));
                    commandSender.sendMessage(ChatColor.DARK_AQUA + de.marcely.bedwars.message.b.a(Language.Cages_Info_TeamsSet).f(commandSender) + ": " + ChatColor.GREEN + Arrays.toString(a2));
                }
                else {
                    Language.sendNotFoundArenaMessage(commandSender, array[2]);
                }
            }
            else if (lowerCase.equals("setenabled") && array.length >= 5) {
                final Arena b3 = s.b(array[3]);
                if (b3 != null) {
                    if (s.isBoolean(array[4])) {
                        final boolean booleanValue = Boolean.valueOf(array[4]);
                        b3.a().setEnabled(booleanValue);
                        de.marcely.bedwars.config.b.b(b3);
                        s.a(commandSender, booleanValue ? de.marcely.bedwars.message.b.a(Language.Cages_Enable) : de.marcely.bedwars.message.b.a(Language.Cages_Disable).a("arena", b3.getName()));
                        if (booleanValue && this.b(b3).size() >= 1) {
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Cages_Warning_Missing));
                        }
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Use_TrueOrFalse));
                    }
                }
                else {
                    Language.sendNotFoundArenaMessage(commandSender, array[3]);
                }
            }
            else if (lowerCase.equals("set") && array.length >= 5) {
                if (!(commandSender instanceof Player)) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.OnlyAs_Player));
                    return;
                }
                final Arena b4 = s.b(array[3]);
                if (b4 != null) {
                    final Team a4 = Team.a(commandSender, array[4]);
                    if (a4 != null) {
                        b4.a().c().put(a4, XYZYP.valueOf(((Player)commandSender).getLocation()));
                        de.marcely.bedwars.config.b.b(b4);
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Cages_Set).a("arena", b4.getName()).a("team", a4.a(commandSender, true)));
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", array[4]));
                    }
                }
                else {
                    Language.sendNotFoundArenaMessage(commandSender, array[3]);
                }
            }
            else {
                this.a(commandSender, s, array);
            }
        }
        else {
            this.a(commandSender, s, array);
        }
    }
    
    private List<Team> a(final Arena arena) {
        final ArrayList<Team> list = new ArrayList<Team>(arena.a().c().keySet());
        Team[] values;
        for (int length = (values = Team.values()).length, i = 0; i < length; ++i) {
            final Team team = values[i];
            if (!arena.a().r().contains(team)) {
                list.remove(team);
            }
        }
        return list;
    }
    
    private List<Team> b(final Arena arena) {
        final ArrayList<Team> list = new ArrayList<Team>();
        final Iterator<Team> iterator = arena.a().r().iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }
        list.removeAll(this.a(arena));
        return list;
    }
    
    private void a(final CommandSender commandSender, final String str, final String[] array) {
        commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender)).toString());
        for (int i = 0; i < 6; ++i) {
            commandSender.sendMessage("");
        }
        final String string = ChatColor.DARK_AQUA + "/" + str + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " ";
        commandSender.sendMessage(String.valueOf(string) + "info " + ChatColor.AQUA + "<arena name>");
        commandSender.sendMessage(String.valueOf(string) + "setenabled " + ChatColor.AQUA + "<arena name> <true/false>");
        commandSender.sendMessage(String.valueOf(string) + "set " + ChatColor.AQUA + "<arena name> <team color>");
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return null;
    }
}
