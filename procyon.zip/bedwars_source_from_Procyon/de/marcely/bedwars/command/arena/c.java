// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.z;
import de.marcely.bedwars.j;
import de.marcely.bedwars.v;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import java.util.Arrays;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class c implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] original) {
        if (original.length >= 3) {
            final Player player = (Player)commandSender;
            final Arena b = s.b(String.join(" ", (CharSequence[])Arrays.copyOfRange(original, 2, original.length)));
            if (b != null) {
                if (b.b() == ArenaStatus.d) {
                    d.a(player, b, new d.a() {
                        @Override
                        public void f() {
                            if (b.a() == RegenerationType.c || b.a() == RegenerationType.d) {
                                b.setTeamPlayers(this.h);
                                b.a().b(this.i);
                                de.marcely.bedwars.config.b.b(b);
                                if (MBedwars.d()) {
                                    MBedwars.a.a(new v(b, this.h * this.i.size()));
                                    MBedwars.a.a(new z(b, this.i.size(), b.getTeamPlayers()));
                                }
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b.getName()));
                            }
                            else if (b.a() == RegenerationType.e) {
                                b.setTeamPlayers(this.h);
                                de.marcely.bedwars.config.b.b(b);
                                if (MBedwars.d()) {
                                    MBedwars.a.a(new v(b, this.h));
                                }
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Saved_Arena).a("arena", b.getName()));
                            }
                        }
                    });
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Arena_HasToBeStopped).a("arena", b.getName()));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, original[2]);
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
}
