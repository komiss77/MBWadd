// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.DropType;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class j implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length >= 5 && array[2].equalsIgnoreCase("add")) {
            final DropType a = DropType.a(array[4]);
            final Arena b = s.b(array[3]);
            if (b != null) {
                if (a != null) {
                    if (b.a().J()) {
                        if (b.getWorld() == null) {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Problem_Arena_World).a("arena", b.getName()));
                            commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.FixProblemWith).f(commandSender)) + "/" + s + " arena setworld " + b.getName());
                            return;
                        }
                        if (player.getWorld().equals(b.getWorld())) {
                            b.addItemSpawner(a, XYZ.valueOf(player.getLocation().getBlock().getLocation()));
                            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Added_Itemspawner).a("spawnertype", a.getName()));
                            de.marcely.bedwars.config.b.b(b);
                        }
                        else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotSameWorld_Arena).a("arena", b.getName()).a("world", b.getWorld().getName()));
                        }
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", b.a().name()).a("name", b.getName()));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Itemspawner).a("itemspawner", array[4]));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 4 && array[2].equalsIgnoreCase("remove")) {
            final Arena b2 = s.b(array[3]);
            if (b2 != null) {
                if (b2.a().J()) {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Removed_Itemspawners).a("number", new StringBuilder().append(b2.a(player.getLocation().getBlock().getLocation())).toString()));
                    de.marcely.bedwars.config.b.b(b2);
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", b2.a().name()).a("name", b2.getName()));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else if (array.length >= 4 && array[2].equalsIgnoreCase("get")) {
            final DropType a2 = DropType.a(array[3]);
            if (a2 != null) {
                if (a2.getActualItemstack() != null && a2.getActualItemstack().getItemMeta() != null && a2.getName() != null && a2.getChatColor() != null) {
                    int intValue = 1;
                    if (array.length >= 5 && s.isInteger(array[4])) {
                        intValue = Integer.valueOf(array[4]);
                    }
                    final ItemStack a3 = i.a(a2.getActualItemstack().clone(), a2.getChatColor() + a2.getName());
                    a3.setAmount(intValue);
                    ((Player)commandSender).getInventory().addItem(new ItemStack[] { a3 });
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Give_Itemspawner).a("amount", new StringBuilder().append(intValue).toString()).a("itemspawner", a2.getName()));
                }
                else {
                    commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.Error_Occured).f(commandSender)) + " (" + a2.getName() + ")");
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Itemspawner).a("itemspawner", array[3]));
            }
        }
        else {
            commandSender.sendMessage("");
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.ItemSpawner_List).f(commandSender)).toString());
            if (DropType.values().size() >= 1) {
                final Iterator<DropType> iterator = DropType.values().iterator();
                while (iterator.hasNext()) {
                    commandSender.sendMessage(" " + ChatColor.GOLD + iterator.next().a(commandSender, true));
                }
            }
            else {
                commandSender.sendMessage(ChatColor.RED + " " + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
            }
            commandSender.sendMessage("");
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.Commands_List).f(commandSender)).toString());
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " add " + ChatColor.AQUA + "<arena name> <itemspawner>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " remove " + ChatColor.AQUA + "<arena name>");
            commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " get " + ChatColor.AQUA + "<itemspawner> [amount]");
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        final String s2 = array[0];
        if (array.length == 2) {
            if (s2.equalsIgnoreCase("add") || s2.equalsIgnoreCase("remove")) {
                return s.a(s.A(), array[1]);
            }
            if (s2.equalsIgnoreCase("get")) {
                return s.a(DropType.a(commandSender, true), array[1]);
            }
        }
        else if (array.length == 3 && s2.equalsIgnoreCase("add")) {
            return s.a(DropType.a(commandSender, true), array[2]);
        }
        return new ArrayList<String>();
    }
    
    private List<String> b() {
        return Arrays.asList("add", "remove", "get");
    }
}
