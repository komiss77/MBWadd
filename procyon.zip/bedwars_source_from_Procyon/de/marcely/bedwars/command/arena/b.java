// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.Language;
import com.google.common.io.Files;
import java.io.File;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class b implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        if (array.length >= 4) {
            final Arena b = s.b(array[2]);
            if (b != null) {
                if (s.b(array[3]) == null) {
                    if (b.b() == ArenaStatus.d) {
                        new MThread(MThread.ThreadType.p, array[3]) {
                            @Override
                            public void run() {
                                try {
                                    Files.copy(new File("plugins/MBedwars/data/arenadata/" + b.getName() + ".cfg"), new File("plugins/MBedwars/data/arenadata/" + array[3] + ".cfg"));
                                    if (new File("plugins/MBedwars/data/arenablocks/" + b.getName() + ".yml").exists()) {
                                        Files.copy(new File("plugins/MBedwars/data/arenablocks/" + b.getName() + ".yml"), new File("plugins/MBedwars/data/arenablocks/" + array[3] + ".yml"));
                                    }
                                    de.marcely.bedwars.config.b.a(array[3]);
                                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Clone_Arena).a("arena1", b.getName()).a("arena2", array[3]));
                                }
                                catch (Exception ex) {
                                    ex.printStackTrace();
                                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Error_Occured));
                                }
                            }
                        }.start();
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Arena_HasToBeStopped).a("arena", b.getName()));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Exists_Arena).a("arena", array[3]));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[2]);
            }
        }
        else {
            s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
}
