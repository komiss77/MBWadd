// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import de.marcely.bedwars.game.location.XYZYP;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.api.BedwarsAPI;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class u implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length >= 4 && array[2].equalsIgnoreCase("getbed") && BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
            final String s3 = (array.length >= 5) ? (String.valueOf(array[3]) + " " + array[4]) : array[3];
            final Team a = Team.a(commandSender, s3);
            if (a != null) {
                player.getInventory().addItem(new ItemStack[] { i.a(i.a(new ItemStack(k.a(ConfigValue.bed_block)), String.format(s.W, a.getChatColor() + a.getName(true))), a) });
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Get_Bed).a("color", a.a(commandSender)).a("colorcode", new StringBuilder().append(a.getChatColor()).toString()));
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", s3));
            }
        }
        else if (array.length >= 5 && array[2].equalsIgnoreCase("setspawn") && (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled)) {
            final String s4 = (array.length >= 6) ? (String.valueOf(array[4]) + " " + array[5]) : array[4];
            final Arena b = s.b(array[3]);
            final Team a2 = Team.a(commandSender, s4);
            if (b != null) {
                if (b.a().J()) {
                    if (a2 != null) {
                        if (b.a().r().contains(a2)) {
                            if (player.getWorld().equals(b.getWorld())) {
                                b.a().a(XYZYP.valueOf(player.getLocation()), a2);
                                de.marcely.bedwars.config.b.b(b);
                                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Changed_TeamSpawn).a("color", a2.a(commandSender)).a("colorcode", new StringBuilder().append(a2.getChatColor()).toString()));
                            }
                            else {
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotSameWorld_Arena).a("arena", b.getName()).a("world", b.getWorld().getName()));
                            }
                        }
                        else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Team_NotAddedYet).a("team", a2.a(commandSender, true)).a("teamcolor", new StringBuilder().append(a2.getChatColor()).toString()).a("arena", b.getName()));
                        }
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotAvaible_Color).a("color", s4));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.ArenaType_NotSupported).a("type", b.a().name()).a("name", b.getName()));
                }
            }
            else {
                Language.sendNotFoundArenaMessage(commandSender, array[3]);
            }
        }
        else {
            commandSender.sendMessage(new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(de.marcely.bedwars.message.b.a(Language.All_Commands).f(commandSender)).toString());
            for (int i = 0; i < 7; ++i) {
                commandSender.sendMessage("");
            }
            if (BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
                commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " getbed" + ChatColor.AQUA + " <team color>");
            }
            if (BedwarsAPI.getOpenAPIConfiguration().teamsEnabled || BedwarsAPI.getOpenAPIConfiguration().bedsEnabled) {
                commandSender.sendMessage(ChatColor.DARK_AQUA + "/" + s + " " + array[0].toLowerCase() + " " + array[1].toLowerCase() + " setspawn" + ChatColor.AQUA + " <arena name> <team color>");
            }
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return this.b();
        }
        if (array.length == 1) {
            return s.a(this.b(), array[0]);
        }
        final String s2 = array[0];
        if (array.length == 2) {
            if (s2.equalsIgnoreCase("getbed")) {
                return s.a(Team.a(commandSender, true, true), array[1]);
            }
            return s.a(s.A(), array[1]);
        }
        else {
            if (array.length == 3 && s2.equalsIgnoreCase("setspawn")) {
                return s.a(Team.a(commandSender, true, true), array[1]);
            }
            return new ArrayList<String>();
        }
    }
    
    private List<String> b() {
        return Arrays.asList("getbed", "setspawn");
    }
}
