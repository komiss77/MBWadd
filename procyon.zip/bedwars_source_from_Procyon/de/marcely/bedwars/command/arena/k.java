// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command.arena;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;

public class k implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        String str = "";
        int n = 1;
        for (final Arena arena : s.af) {
            if (n != s.af.size()) {
                str = String.valueOf(str) + arena.getName() + ", ";
            }
            else {
                str = String.valueOf(str) + arena.getName();
            }
            ++n;
        }
        if (str.isEmpty()) {
            commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.List_Arenas).f(commandSender)) + de.marcely.bedwars.message.b.a(Language.None).f(commandSender));
        }
        else {
            commandSender.sendMessage(String.valueOf(de.marcely.bedwars.message.b.a(Language.List_Arenas).f(commandSender)) + "(" + s.af.size() + "); " + str);
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
