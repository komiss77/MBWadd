// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.c;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class s implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        (s.k = player.getLocation()).setWorld(player.getWorld());
        c.save();
        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Changed_GameDoneLocation));
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
