// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.block.Block;
import de.marcely.bedwars.Language;
import java.util.Map;
import de.marcely.bedwars.game.location.XYZW;
import java.util.HashMap;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.a;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class b implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length >= 2) {
            final Block lookingBlock = de.marcely.bedwars.util.b.getLookingBlock(player, 10);
            if (lookingBlock != null && lookingBlock.getType() != null && de.marcely.bedwars.util.a.b(lookingBlock)) {
                final Arena b = s.b(array[1]);
                if (b != null) {
                    final HashMap<XYZW, Object> hashMap = new HashMap<XYZW, Object>();
                    hashMap.putAll((Map<?, ?>)s.S);
                    final Iterator<Map.Entry<XYZW, V>> iterator = hashMap.entrySet().iterator();
                    while (iterator.hasNext()) {
                        final XYZW xyzw = iterator.next().getKey();
                        if (xyzw.getWorld() == null && !de.marcely.bedwars.config.b.o() && !s.g(xyzw.getWorldString())) {
                            s.S.remove(xyzw);
                        }
                        if (lookingBlock.getWorld().equals(xyzw.getWorld()) && xyzw.getX() == lookingBlock.getX() && xyzw.getY() == lookingBlock.getY() && xyzw.getZ() == lookingBlock.getZ()) {
                            s.S.remove(xyzw);
                        }
                    }
                    s.S.put(XYZW.valueOf(lookingBlock.getLocation()), b.getName());
                    s.a(lookingBlock.getLocation(), b);
                    s.ai();
                    s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Added_Sign));
                }
                else {
                    Language.sendNotFoundArenaMessage((CommandSender)player, array[1]);
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotLooking_AtSign));
            }
        }
        else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
}
