// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import java.util.Arrays;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class m implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] original) {
        final Player player = (Player)commandSender;
        if (original.length >= 2) {
            if (s.a(player) != null) {
                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.AlreadyInside_Arena));
                return;
            }
            final Arena b = s.b(String.join(" ", (CharSequence[])Arrays.copyOfRange(original, 1, original.length)));
            if (b != null) {
                final String b2 = s.b(player, b);
                if (b2 != null) {
                    player.sendMessage(b2);
                }
            }
            else {
                Language.sendNotFoundArenaMessage((CommandSender)player, original[1]);
            }
        }
        else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        if (array.length == 0) {
            return s.A();
        }
        if (array.length == 1) {
            return s.a(s.A(), array[0]);
        }
        return new ArrayList<String>();
    }
}
