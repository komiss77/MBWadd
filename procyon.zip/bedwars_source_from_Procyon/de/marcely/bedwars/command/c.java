// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.command;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.block.Block;
import de.marcely.bedwars.Language;
import de.marcely.bedwars.config.q;
import de.marcely.bedwars.game.stats.StatsSign;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.a;
import de.marcely.bedwars.util.b;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class c implements CommandHandler.Command.a
{
    protected CommandHandler.Command cmd;
    
    @Override
    public void a(final CommandHandler.Command cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void a(final CommandSender commandSender, final String s, final String s2, final String[] array) {
        final Player player = (Player)commandSender;
        if (array.length >= 2) {
            final Block lookingBlock = de.marcely.bedwars.util.b.getLookingBlock(player, 10);
            if (lookingBlock != null && lookingBlock.getType() != null && de.marcely.bedwars.util.a.b(lookingBlock)) {
                if (s.isInteger(array[1])) {
                    final int intValue = Integer.valueOf(array[1]);
                    if (intValue >= 1 && intValue <= 10) {
                        final StatsSign statsSign = new StatsSign(intValue, lookingBlock.getLocation());
                        statsSign.a(de.marcely.bedwars.game.stats.b.a[intValue - 1]);
                        statsSign.update();
                        s.T.put(lookingBlock.getLocation().toString(), statsSign);
                        q.save();
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Added_Sign));
                    }
                    else {
                        s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Unkown_Place).a("place", array[1]));
                    }
                }
                else {
                    s.a(commandSender, de.marcely.bedwars.message.b.a(Language.Number_NotOne).a("number", array[1]));
                }
            }
            else {
                s.a(commandSender, de.marcely.bedwars.message.b.a(Language.NotLooking_AtSign));
            }
        }
        else {
            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Usage).a("usage", s2));
        }
    }
    
    @Override
    public List<String> a(final String[] array, final String s, final CommandSender commandSender) {
        return new ArrayList<String>();
    }
}
