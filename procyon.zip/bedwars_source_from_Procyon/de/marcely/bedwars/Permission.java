// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.ArrayList;
import java.util.List;

public enum Permission
{
    Command_Stats("Command_Stats", 0, "mbedwars.cmd.stats", true), 
    Command_Leave("Command_Leave", 1, "mbedwars.cmd.leave", true), 
    Command_Forcestart("Command_Forcestart", 2, "mbedwars.cmd.forcestart"), 
    Command_Reload("Command_Reload", 3, "mbedwars.cmd.reload"), 
    Command_List("Command_List", 4, "mbedwars.cmd.list"), 
    Command_Arena("Command_Arena", 5, "mbedwars.cmd.arena"), 
    Command_Kick("Command_Kick", 6, "mbedwars.cmd.kick"), 
    Command_Summon("Command_Summon", 7, "mbedwars.cmd.summon"), 
    Command_SetGameDoneLocation("Command_SetGameDoneLocation", 8, "mbedwars.cmd.setgamedonelocation"), 
    Command_CheckUpdate("Command_CheckUpdate", 9, "mbedwars.cmd.checkupdate"), 
    Command_Info("Command_Info", 10, "mbedwars.cmd.info"), 
    Command_AddSign("Command_AddSign", 11, "mbedwars.cmd.addsign"), 
    Command_Hologram("Command_Hologram", 12, "mbedwars.cmd.hologram"), 
    Command_RunningGames("Command_RunningGames", 13, "mbedwars.cmd.runninggames"), 
    Command_Join("Command_Join", 14, "mbedwars.cmd.join"), 
    Command_Addon("Command_Addon", 15, "mbedwars.cmd.addon"), 
    Command_RecalculateStats("Command_RecalculateStats", 16, "mbedwars.cmd.recalculatestats"), 
    Command_Debug("Command_Debug", 17, "mbedwars.cmd.debug"), 
    Command_ArenasGUI("Command_ArenasGUI", 18, "mbedwars.cmd.arenasgui"), 
    Command_Backup("Command_Backup", 19, "mbedwars.cmd.backup"), 
    Command_AddStatsSign("Command_AddStatsSign", 20, "mbedwars.cmd.addstatssign"), 
    ArenaTP("ArenaTP", 21, "mbedwars.arenatp"), 
    ArenaBuild("ArenaBuild", 22, "mbedwars.arenabuild"), 
    BetaUser("BetaUser", 23, "mbedwars.betauser"), 
    UpdateMessage("UpdateMessage", 24, "mbedwars.updatemessage"), 
    GetArena("GetArena", 25, "mbedwars.getarena"), 
    JoinFull("JoinFull", 26, "mbedwars.joinfull"), 
    SpecialItem("SpecialItem", 27, "mbedwars.specialitem.{id"), 
    Break_RankStatue("Break_RankStatue", 28, "mbedwars.breakrankstatue"), 
    Damage_Entity("Damage_Entity", 29, "mbedwars.damageentity"), 
    ShopCustomPrice("ShopCustomPrice", 30, "mbedwars.shopcustomprice");
    
    private String selected_permission;
    private String selected_prm;
    private boolean selected_basic;
    
    private Permission(final String s, final int n, final String s2) {
        this(s, n, s2, false);
    }
    
    private Permission(final String name, final int ordinal, final String s, final boolean selected_basic) {
        this.selected_permission = s;
        this.selected_prm = s;
        this.selected_basic = selected_basic;
    }
    
    public String getPermission() {
        return this.selected_permission;
    }
    
    public boolean isBasic() {
        return this.selected_basic;
    }
    
    public Permission replace(final String target, final String replacement) {
        this.selected_permission = this.selected_prm.replace(target, replacement);
        return this;
    }
    
    public static List<Permission> valuesCMD() {
        final ArrayList<Permission> list = new ArrayList<Permission>();
        Permission[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Permission permission = values[i];
            if (permission.name().startsWith("Command_")) {
                list.add(permission);
            }
        }
        return list;
    }
}
