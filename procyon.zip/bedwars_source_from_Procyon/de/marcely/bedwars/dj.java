// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.Player;
import me.MathiasMC.PvPLevels.PvPLevelsAPI;

public class dj extends dg
{
    private PvPLevelsAPI a;
    private static /* synthetic */ int[] q;
    
    @Override
    public cT a() {
        return cT.p;
    }
    
    @Override
    public void onEnable() {
        this.a = new PvPLevelsAPI();
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public void a(final Player player, final df df) {
        switch (r()[df.ordinal()]) {
            case 1: {
                this.d(player, ConfigValue.pvplevels_exp_win);
                break;
            }
            case 2: {
                this.d(player, ConfigValue.pvplevels_exp_lose);
                break;
            }
            case 3: {
                this.d(player, ConfigValue.pvplevels_exp_beddestroy);
                break;
            }
            case 4: {
                this.d(player, ConfigValue.pvplevels_exp_killplayer);
                break;
            }
        }
    }
    
    private void d(final Player player, final int i) {
        this.a.AddXP(player, Integer.valueOf(i));
        while (this.a.CurrentXP(player) >= this.a.CurrentXPRequired(player)) {
            this.a.RemoveXP(player, Integer.valueOf(this.a.CurrentXPRequired(player)));
            this.a.AddLevel(player, Integer.valueOf(1));
        }
    }
    
    static /* synthetic */ int[] r() {
        final int[] q = dj.q;
        if (q != null) {
            return q;
        }
        final int[] q2 = new int[df.values().length];
        try {
            q2[df.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            q2[df.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            q2[df.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            q2[df.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        return dj.q = q2;
    }
}
