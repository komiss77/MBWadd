// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;

public class dA extends dy
{
    public dA(final Arena arena) {
        super(arena, "status");
    }
    
    @Override
    public String e(final Player player) {
        return this.arena.b().o();
    }
}
