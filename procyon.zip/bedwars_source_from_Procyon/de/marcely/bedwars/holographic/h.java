// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

public class h
{
}
