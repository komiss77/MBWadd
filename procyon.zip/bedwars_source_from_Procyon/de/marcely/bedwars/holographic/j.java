// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import org.bukkit.Location;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import java.util.Iterator;
import org.bukkit.entity.Player;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.HashMap;
import java.util.concurrent.BlockingQueue;
import org.bukkit.World;
import java.util.Map;

public class j
{
    private final short c = 5;
    private final Map<World, f> G;
    private final BlockingQueue<e> a;
    private boolean isRunning;
    
    public j() {
        this.G = new HashMap<World, f>();
        this.a = new ArrayBlockingQueue<e>(32);
        this.isRunning = false;
    }
    
    public void b(final de.marcely.bedwars.holographic.c<?> c) {
        this.a(new b((byte)0, c));
    }
    
    public void c(final de.marcely.bedwars.holographic.c<?> c) {
        this.a(new b((byte)1, c));
    }
    
    public void a(final Player player, final World world, final int n, final int n2) {
        final f f = this.G.get(world);
        if (f == null) {
            return;
        }
        if (f.a(n, n2) == null) {
            return;
        }
        this.a(new c((byte)2, player, world, n, n2));
    }
    
    public void U() {
        this.a(new e((byte)4));
    }
    
    public void a(final World world) {
        if (!this.G.containsKey(world)) {
            return;
        }
        this.a(new g((byte)5, world));
    }
    
    public void J(final Player player) {
        this.a(new d((byte)3, player));
    }
    
    @Nullable
    public de.marcely.bedwars.holographic.c<?> a(final World world, final int n) {
        final f f = this.G.get(world);
        if (f == null) {
            return null;
        }
        final Iterator<a> iterator = f.H.values().iterator();
        while (iterator.hasNext()) {
            for (final de.marcely.bedwars.holographic.c<?> c : iterator.next().Y) {
                if (c.getEntityId() == n) {
                    return c;
                }
            }
        }
        return null;
    }
    
    private void a(final e e) {
        if (!this.isRunning()) {
            return;
        }
        while (this.a.remainingCapacity() == 0) {
            s.sleep(10L);
        }
        this.a.add(e);
    }
    
    public synchronized boolean run() {
        if (this.isRunning()) {
            return false;
        }
        this.isRunning = true;
        new MThread(MThread.ThreadType.t) {
            @Override
            public void run() {
                while (j.this.isRunning()) {
                    s.sleep(200L);
                    try {
                        j.this.tick();
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }.start();
        return true;
    }
    
    public synchronized boolean stop() {
        if (!this.isRunning()) {
            return false;
        }
        this.isRunning = false;
        final Iterator<Map.Entry<World, f>> iterator = this.G.entrySet().iterator();
        while (iterator.hasNext()) {
            final Iterator<Map.Entry<Long, a>> iterator2 = iterator.next().getValue().H.entrySet().iterator();
            while (iterator2.hasNext()) {
                final a a = iterator2.next().getValue();
                for (final de.marcely.bedwars.holographic.c<?> c : a.Y) {
                    final Iterator<Player> iterator4 = a.Z.iterator();
                    while (iterator4.hasNext()) {
                        ((de.marcely.bedwars.holographic.f)c.a()).H(iterator4.next());
                    }
                }
            }
        }
        this.G.clear();
        return true;
    }
    
    private void tick() {
        for (final Map.Entry<World, f> entry : this.G.entrySet()) {
            final World world = entry.getKey();
            final Iterator<Map.Entry<Long, a>> iterator2 = entry.getValue().H.entrySet().iterator();
            while (iterator2.hasNext()) {
                final Map.Entry<Long, a> entry2 = iterator2.next();
                final a a = entry2.getValue();
                if (a.L()) {
                    iterator2.remove();
                }
                else {
                    final long longValue = entry2.getKey();
                    final int a2 = de.marcely.bedwars.util.c.a(longValue);
                    final int b = de.marcely.bedwars.util.c.b(longValue);
                    final Iterator<de.marcely.bedwars.holographic.c<?>> iterator3 = a.Y.iterator();
                    final List<Player> b2 = Version.a().b(world, a2, b);
                    ArrayList list = null;
                    ArrayList list2 = null;
                    if (b2 == null || b2.size() == 0) {
                        if (a.Z.size() >= 1) {
                            list2 = new ArrayList<Object>(a.Z);
                            a.Z.clear();
                        }
                    }
                    else if (a.Z.size() == 0) {
                        list = (ArrayList)b2;
                        a.Z.addAll(b2);
                    }
                    else {
                        list = new ArrayList<Player>(b2);
                        list2 = new ArrayList<Object>(a.Z);
                        list.removeAll(a.Z);
                        list2.removeAll(b2);
                        a.Z = b2;
                    }
                    while (iterator3.hasNext()) {
                        final de.marcely.bedwars.holographic.c<?> c = iterator3.next();
                        if (c.getWorld() != world) {
                            iterator3.remove();
                        }
                        else {
                            if (c.a() >= 1 && b2 != null) {
                                for (final Player player : b2) {
                                    if (c.getLocation().distance(player.getLocation()) < c.a()) {
                                        if (c.w().contains(player)) {
                                            continue;
                                        }
                                        ((de.marcely.bedwars.holographic.f)c.a()).H(player);
                                        c.w().add(player);
                                    }
                                    else {
                                        if (!c.w().remove(player)) {
                                            continue;
                                        }
                                        ((de.marcely.bedwars.holographic.f)c.a()).G(player);
                                    }
                                }
                            }
                            if (list2 != null) {
                                final Iterator<Player> iterator5 = (Iterator<Player>)list2.iterator();
                                while (iterator5.hasNext()) {
                                    ((de.marcely.bedwars.holographic.f)c.a()).H(iterator5.next());
                                }
                            }
                            if (list != null) {
                                for (final Player player2 : list) {
                                    if (!c.w().contains(player2)) {
                                        ((de.marcely.bedwars.holographic.f)c.a()).G(player2);
                                    }
                                }
                            }
                            final Location location = c.getLocation();
                            final long b3 = de.marcely.bedwars.util.c.b(location.getBlockX() >> 4, location.getBlockZ() >> 4);
                            if (b3 == longValue) {
                                continue;
                            }
                            final a a3 = s.a(entry.getValue().H, b3, new a());
                            iterator3.remove();
                            a3.Y.add(c);
                            c.a(a3);
                        }
                    }
                }
            }
        }
        e e;
        while ((e = this.a.poll()) != null) {
            switch (e.x) {
                case 1: {
                    final b b4 = (b)e;
                    final Location location2 = ((de.marcely.bedwars.holographic.f)b4.hologram.a()).getLocation();
                    final f f = this.G.get(location2.getWorld());
                    b4.hologram.a((a)null);
                    if (f == null) {
                        continue;
                    }
                    final a a4 = f.H.get(f.a(location2.getBlockX() >> 4, location2.getBlockZ() >> 4));
                    if (a4 == null) {
                        continue;
                    }
                    a4.Y.remove(b4.hologram);
                    final Iterator<Player> iterator7 = a4.Z.iterator();
                    while (iterator7.hasNext()) {
                        ((de.marcely.bedwars.holographic.f)b4.hologram.a()).H(iterator7.next());
                    }
                    continue;
                }
                case 2: {
                    final c c2 = (c)e;
                    final f f2 = this.G.get(c2.world);
                    if (f2 == null) {
                        continue;
                    }
                    final a a5 = f2.a(c2.x, c2.z);
                    if (a5 == null) {
                        continue;
                    }
                    final Iterator<de.marcely.bedwars.holographic.c<?>> iterator8 = a5.Y.iterator();
                    while (iterator8.hasNext()) {
                        iterator8.next().a().H(c2.player);
                    }
                    a5.Z.remove(c2.player);
                    continue;
                }
                case 3: {
                    final Player player3 = ((c)e).player;
                    final f f3 = this.G.get(player3.getWorld());
                    if (f3 == null) {
                        continue;
                    }
                    for (final a a6 : f3.H.values()) {
                        if (a6.Z.remove(player3)) {
                            final Iterator<de.marcely.bedwars.holographic.c<?>> iterator10 = a6.Y.iterator();
                            while (iterator10.hasNext()) {
                                iterator10.next().a().H(player3);
                            }
                        }
                    }
                    continue;
                }
                case 5: {
                    final f f4 = this.G.remove(((g)e).world);
                    if (f4 == null) {
                        continue;
                    }
                    f4.U();
                    continue;
                }
                default: {
                    continue;
                }
                case 0: {
                    final b b5 = (b)e;
                    final Location location3 = ((de.marcely.bedwars.holographic.f)b5.hologram.a()).getLocation();
                    final a a7 = s.a(s.a(this.G, location3.getWorld(), new f()).H, de.marcely.bedwars.util.c.b(location3.getBlockX() >> 4, location3.getBlockZ() >> 4), new a());
                    b5.hologram.a(a7);
                    a7.Y.add(b5.hologram);
                    final Iterator<Player> iterator11 = a7.Z.iterator();
                    while (iterator11.hasNext()) {
                        ((de.marcely.bedwars.holographic.f)b5.hologram.a()).G(iterator11.next());
                    }
                    continue;
                }
                case 4: {
                    final Iterator<f> iterator12 = this.G.values().iterator();
                    while (iterator12.hasNext()) {
                        iterator12.next().U();
                    }
                    continue;
                }
            }
        }
    }
    
    public boolean isRunning() {
        return this.isRunning;
    }
    
    private static class e
    {
        public static final byte r = 0;
        public static final byte s = 1;
        public static final byte t = 2;
        public static final byte u = 3;
        public static final byte v = 4;
        public static final byte w = 5;
        public final byte x;
        
        public e(final byte x) {
            this.x = x;
        }
    }
    
    private static class b extends e
    {
        public final de.marcely.bedwars.holographic.c<?> hologram;
        
        public b(final byte b, final de.marcely.bedwars.holographic.c<?> hologram) {
            super(b);
            this.hologram = hologram;
        }
    }
    
    private static class d extends e
    {
        public final Player player;
        
        public d(final byte b, final Player player) {
            super(b);
            this.player = player;
        }
    }
    
    private static class c extends d
    {
        public final World world;
        public final int x;
        public final int z;
        
        public c(final byte b, final Player player, final World world, final int x, final int z) {
            super(b, player);
            this.world = world;
            this.x = x;
            this.z = z;
        }
    }
    
    private static class g extends e
    {
        public final World world;
        
        public g(final byte b, final World world) {
            super(b);
            this.world = world;
        }
    }
    
    public class a
    {
        public List<de.marcely.bedwars.holographic.c<?>> Y;
        public List<Player> Z;
        
        public a() {
            this.Y = new ArrayList<de.marcely.bedwars.holographic.c<?>>(4);
            this.Z = new ArrayList<Player>();
        }
        
        public j a() {
            return j.this;
        }
        
        public void U() {
            for (final Player player : this.Z) {
                final Iterator<de.marcely.bedwars.holographic.c<de.marcely.bedwars.holographic.f>> iterator2 = (Iterator<de.marcely.bedwars.holographic.c<de.marcely.bedwars.holographic.f>>)this.Y.iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().a().H(player);
                }
            }
            this.Z.clear();
        }
        
        public boolean L() {
            return this.Y.size() == 0;
        }
    }
    
    public class f
    {
        public Map<Long, a> H;
        
        public f() {
            this.H = new HashMap<Long, a>(4);
        }
        
        private long a(final int n, final int n2) {
            return de.marcely.bedwars.util.c.b(n, n2);
        }
        
        @Nullable
        public a a(final int n, final int n2) {
            return this.H.get(this.a(n, n2));
        }
        
        public void U() {
            final Iterator<a> iterator = this.H.values().iterator();
            while (iterator.hasNext()) {
                iterator.next().U();
            }
        }
    }
}
