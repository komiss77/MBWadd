// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import java.lang.reflect.Field;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.cF;
import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.versions.NMSClass;
import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.Player;
import de.marcely.bedwars.cJ;
import org.bukkit.Location;

public abstract class f<T extends h>
{
    protected g a;
    protected Location location;
    protected Location f;
    protected int entityId;
    protected Object g;
    private c<cJ> b;
    
    public f(final g a, final Location location) {
        this.a = a;
        this.location = location;
        this.f = location.clone();
    }
    
    public abstract i a();
    
    public abstract float getHeight();
    
    public abstract void a(final T p0);
    
    protected abstract void D(final Player p0);
    
    protected abstract void E(final Player p0);
    
    public abstract void F(final Player p0);
    
    public void G(final Player player) {
        this.D(player);
        if (this.b != null) {
            this.b.a().G(player);
        }
    }
    
    public void H(final Player player) {
        this.E(player);
        if (this.b != null) {
            this.b.a().H(player);
        }
    }
    
    protected List<Player> v() {
        return this.a.v();
    }
    
    protected void S() {
        for (final Player player : this.v()) {
            this.H(player);
            this.G(player);
        }
    }
    
    public void teleport(final Location location) {
        this.setLocation(location);
        final Iterator<Player> iterator = this.v().iterator();
        while (iterator.hasNext()) {
            this.F(iterator.next());
        }
    }
    
    protected void setLocation(final Location location) {
        this.location = location;
        try {
            NMSClass.q.getMethod("setLocation", Double.TYPE, Double.TYPE, Double.TYPE, Float.TYPE, Float.TYPE).invoke(this.g, location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        }
        catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
            final Throwable t;
            t.printStackTrace();
        }
        NMSClass.a(this.g, location.getYaw());
    }
    
    public void setCustomName(@Nullable final String s) {
        if (this.b != null) {
            this.b.remove();
            this.b = null;
        }
        if (s != null) {
            final cF cf = new cF();
            cf.a(s.split("\\\\n"));
            this.b = c.a(cJ.class, this.location.clone().add(0.0, (double)(this.getHeight() - 0.18f), 0.0), cf);
        }
    }
    
    protected void y(@Nullable final String s) {
        try {
            if (s != null) {
                if (Version.a().getVersionNumber() >= 13) {
                    NMSClass.q.getMethod("setCustomName", NMSClass.W).invoke(this.g, s.c(s));
                }
                else {
                    NMSClass.q.getMethod("setCustomName", String.class).invoke(this.g, s);
                }
            }
            NMSClass.q.getMethod("setCustomNameVisible", Boolean.TYPE).invoke(this.g, s != null);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    protected void a(final int i, final Object o) throws Exception {
        final Object invoke = NMSClass.q.getMethod("getDataWatcher", (Class<?>[])new Class[0]).invoke(this.g, new Object[0]);
        invoke.getClass().getMethod("watch", Integer.TYPE, Object.class).invoke(invoke, i, o);
    }
    
    public void I(final Player player) {
        try {
            if (Version.a().getVersionNumber() <= 7) {
                Version.a().b((Entity)NMSClass.q.getMethod("getBukkitEntity", (Class<?>[])new Class[0]).invoke(this.g, new Object[0]), true);
            }
            final Field declaredField = NMSClass.q.getDeclaredField("datawatcher");
            declaredField.setAccessible(true);
            Version.a().sendPacket(player, NMSClass.L.getDeclaredConstructor(Integer.TYPE, NMSClass.N, Boolean.TYPE).newInstance(this.entityId, declaredField.get(this.g), true));
        }
        catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException | InstantiationException | InvocationTargetException | NoSuchMethodException ex) {
            final Throwable t;
            t.printStackTrace();
        }
    }
    
    public void T() {
        final Iterator<Player> iterator = this.v().iterator();
        while (iterator.hasNext()) {
            this.I(iterator.next());
        }
    }
    
    public g a() {
        return this.a;
    }
    
    public void b(final g a) {
        this.a = a;
    }
    
    public Location getLocation() {
        return this.location;
    }
    
    public Location a() {
        return this.f;
    }
    
    public int getEntityId() {
        return this.entityId;
    }
}
