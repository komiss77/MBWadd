// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import org.bukkit.entity.Player;
import java.util.List;

public interface g
{
    List<Player> v();
    
    void R();
    
    void B(final Player p0);
    
    void C(final Player p0);
}
