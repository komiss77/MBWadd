// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import javax.annotation.Nullable;
import de.marcely.bedwars.cH;
import de.marcely.bedwars.cN;
import de.marcely.bedwars.cL;
import de.marcely.bedwars.cG;
import de.marcely.bedwars.cK;
import de.marcely.bedwars.cM;
import de.marcely.bedwars.cF;
import de.marcely.bedwars.cJ;
import de.marcely.bedwars.cE;
import de.marcely.bedwars.cI;

public enum i
{
    a((Class<? extends f<?>>)cI.class, (Class<? extends h>)cE.class), 
    b((Class<? extends f<?>>)cJ.class, (Class<? extends h>)cF.class), 
    c((Class<? extends f<?>>)cM.class, (Class<? extends h>)cF.class), 
    d((Class<? extends f<?>>)cK.class, (Class<? extends h>)cG.class), 
    e((Class<? extends f<?>>)cL.class, (Class<? extends h>)cG.class), 
    f((Class<? extends f<?>>)cN.class, (Class<? extends h>)cH.class);
    
    public final Class<? extends f<?>> i;
    public final Class<? extends h> j;
    
    static {
        a = new i[] { i.a, i.b, i.c, i.d, i.e, i.f };
    }
    
    private i(final Class<? extends f<?>> i, final Class<? extends h> j) {
        this.i = i;
        this.j = j;
    }
    
    @Nullable
    public static i a(final Class<? extends f<?>> clazz) {
        i[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final i j = values[i];
            if (j.i == clazz) {
                return j;
            }
        }
        return null;
    }
}
