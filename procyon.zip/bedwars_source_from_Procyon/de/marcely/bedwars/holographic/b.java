// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

public interface b
{
    e a();
}
