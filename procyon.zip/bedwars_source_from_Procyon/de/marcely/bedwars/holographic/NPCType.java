// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.d;
import de.marcely.bedwars.cE;
import java.util.UUID;
import de.marcely.bedwars.bq;

public class NPCType
{
    private a a;
    private Object[] args;
    
    public NPCType(final a a) {
        if (a == NPCType.a.d) {
            new bq("Please use the getNPC method!").printStackTrace();
            return;
        }
        this.a = a;
    }
    
    private NPCType(final a a, final Object[] args) {
        this.a = a;
        this.args = args;
    }
    
    public a a() {
        return this.a;
    }
    
    public Object[] getArguments() {
        return this.args;
    }
    
    public static NPCType a(final UUID uuid) {
        return new NPCType(a.d, new Object[] { uuid });
    }
    
    public static NPCType a(final String s) {
        return new NPCType(a.c, new Object[] { cE.b(s) });
    }
    
    public static NPCType b(String substring) {
        String substring2 = null;
        for (int i = 0; i < substring.length(); ++i) {
            final char char1 = substring.charAt(i);
            if (char1 == '[' || char1 == '{') {
                substring2 = substring.substring(0, i);
                substring = substring.substring(i + 1, substring.length() - 1);
                break;
            }
        }
        final a a = NPCType.a.a(substring2);
        if (a == null) {
            return null;
        }
        if (a == NPCType.a.d) {
            final String[] split = substring.split(",");
            if (split.length != 1) {
                d.b("Config: ENTITY TYPE - NPC: Max. args only 1!");
                return null;
            }
            if (split[0].equalsIgnoreCase("self")) {
                return new NPCType(NPCType.a.e);
            }
            if (!s.i(split[0])) {
                d.b("Config: ENTITY TYPE - NPC: UUID argument is not valid!");
                return null;
            }
            return a(UUID.fromString(split[0]));
        }
        else {
            if (a != NPCType.a.c) {
                return new NPCType(a);
            }
            if (Version.a().getVersionNumber() <= 7) {
                d.b("Config: ENTITY TYPE - ARMOR STAND: Armor Stands aren't supported for your version");
                return null;
            }
            return a("{" + substring + "}");
        }
    }
    
    @Override
    public String toString() {
        if (this.a == NPCType.a.c) {
            return String.valueOf(this.a.name()) + this.args[0].toString();
        }
        if (this.a == NPCType.a.e) {
            return "NPC[self]";
        }
        if (this.a == NPCType.a.b) {
            return this.a.name();
        }
        String str = "";
        int n = 1;
        if (this.args != null) {
            Object[] args;
            for (int length = (args = this.args).length, i = 0; i < length; ++i) {
                str = String.valueOf(str) + args[i].toString();
                if (n != this.args.length) {
                    str = String.valueOf(str) + ",";
                }
                ++n;
            }
        }
        return str.equals("") ? this.a.name() : (String.valueOf(this.a.name()) + "[" + str + "]");
    }
    
    public enum a
    {
        b("Villager", 0), 
        c("ArmorStand", 1), 
        d("NPC", 2), 
        e("NPC_Self", 3);
        
        static {
            a = new a[] { NPCType.a.b, NPCType.a.c, NPCType.a.d, NPCType.a.e };
        }
        
        private a(final String name, final int ordinal) {
        }
        
        public static a a(final String anotherString) {
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                if (a.name().equalsIgnoreCase(anotherString)) {
                    return a;
                }
            }
            return null;
        }
    }
}
