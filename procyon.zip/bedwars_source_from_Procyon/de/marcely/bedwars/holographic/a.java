// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import org.bukkit.entity.Player;

public interface a
{
    boolean a(final float p0);
    
    float getHealth();
    
    void a(final Player p0, final float p1);
}
