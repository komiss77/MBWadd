// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import java.util.Iterator;
import java.util.Arrays;
import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.util.s;
import org.bukkit.Location;
import org.bukkit.World;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import java.util.List;

public class c<T extends f<?>>
{
    private final T a;
    private byte q;
    private List<Player> X;
    private final List<g> listeners;
    private j.a a;
    
    public c(final T a) {
        this.q = -1;
        this.X = new ArrayList<Player>(4);
        this.listeners = new ArrayList<g>(4);
        this.a = a;
    }
    
    public World getWorld() {
        return this.getLocation().getWorld();
    }
    
    public Location getLocation() {
        return this.a.getLocation();
    }
    
    public int getEntityId() {
        return this.a.getEntityId();
    }
    
    public List<Player> v() {
        return this.a.v();
    }
    
    public void Q() {
        s.b.b(this);
    }
    
    public void remove() {
        s.b.c(this);
    }
    
    public void a(final g g) {
        this.listeners.add(g);
    }
    
    public boolean a(final g g) {
        return this.listeners.remove(g);
    }
    
    @Nullable
    public static <T extends f<?>> c<T> a(final Class<T> clazz, final Location location, final h h) {
        try {
            final i a = i.a(clazz);
            if (a.j != h.getClass()) {
                throw new IllegalStateException(String.valueOf(clazz.getName()) + " expects " + a.j.getName() + " as parameter");
            }
            final a a2 = new a();
            final f<?> f = (T)clazz.getConstructor(g.class, Location.class).newInstance(a2, location);
            final c hologram = new c<Object>(f);
            a2.hologram = hologram;
            a(f, h);
            return (c<T>)hologram;
        }
        catch (InvocationTargetException ex) {
            ex.getTargetException().printStackTrace();
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
        }
        return null;
    }
    
    private static <T extends h> void a(final f<T> f, final Object o) {
        f.a((T)o);
    }
    
    public T a() {
        return this.a;
    }
    
    public byte a() {
        return this.q;
    }
    
    public void a(final byte q) {
        this.q = q;
    }
    
    public List<Player> w() {
        return this.X;
    }
    
    public List<g> getListeners() {
        return this.listeners;
    }
    
    public j.a a() {
        return this.a;
    }
    
    public void a(final j.a a) {
        this.a = a;
    }
    
    private static class a extends d
    {
        public c<?> hologram;
        
        public a() {
        }
        
        @Override
        public List<Player> v() {
            return (((c<f>)this.hologram).a != null) ? ((c<f>)this.hologram).a.Z : Arrays.asList(new Player[0]);
        }
        
        @Override
        public void R() {
            final Iterator<g> iterator = ((c<f>)this.hologram).listeners.iterator();
            while (iterator.hasNext()) {
                iterator.next().R();
            }
        }
    }
}
