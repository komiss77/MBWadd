// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.versions.NMSClass;
import javax.annotation.Nullable;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class e
{
    private final f<?> a;
    private final Object[] a;
    
    public e(final f<?> a) {
        this.a = a;
        this.a = new Object[e.a.size()];
    }
    
    public void a(final a a, final ItemStack itemStack) {
        try {
            this.a[a.ordinal()] = a(this.a.getEntityId(), a, itemStack);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void send(final Player player) {
        Object[] a;
        for (int length = (a = this.a).length, i = 0; i < length; ++i) {
            final Object o = a[i];
            if (o != null) {
                Version.a().sendPacket(player, o);
            }
        }
    }
    
    @Nullable
    private static Object a(final int n, final a a, @Nullable final ItemStack itemStack) {
        if (itemStack == null) {
            return null;
        }
        try {
            final Object invoke = NMSClass.D.getMethod("asNMSCopy", ItemStack.class).invoke(null, itemStack);
            if (Version.a().getVersionNumber() < 9) {
                return NMSClass.E.getDeclaredConstructor(Integer.TYPE, Integer.TYPE, NMSClass.F).newInstance(n, a.ar, invoke);
            }
            try {
                return NMSClass.E.getDeclaredConstructor(Integer.TYPE, NMSClass.G, NMSClass.F).newInstance(n, NMSClass.G.getMethod("valueOf", String.class).invoke(null, a.b), invoke);
            }
            catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException ex) {
                final Throwable t;
                t.printStackTrace();
                return null;
            }
        }
        catch (InstantiationException ex2) {}
        catch (IllegalAccessException ex3) {}
        catch (IllegalArgumentException ex4) {}
        catch (InvocationTargetException ex5) {}
        catch (NoSuchMethodException ex6) {}
        catch (SecurityException ex7) {}
    }
    
    public enum a
    {
        a("HELMET", 0, 4, "HEAD"), 
        b("CHESTPLATE", 1, 3, "CHEST"), 
        c("LEGGINGS", 2, 2, "LEGS"), 
        d("BOOTS", 3, 1, "FEET"), 
        e("MAIN_HAND", 4, 0, "MAINHAND"), 
        f("OFF_HAND", 5, 5, "OFFHAND");
        
        public final int ar;
        public final String b;
        
        static {
            a = new a[] { de.marcely.bedwars.holographic.e.a.a, de.marcely.bedwars.holographic.e.a.b, de.marcely.bedwars.holographic.e.a.c, de.marcely.bedwars.holographic.e.a.d, de.marcely.bedwars.holographic.e.a.e, de.marcely.bedwars.holographic.e.a.f };
        }
        
        private a(final String name, final int ordinal, final int ar, final String b) {
            this.ar = ar;
            this.b = b;
        }
        
        public static int size() {
            return (Version.a().getVersionNumber() >= 9) ? 6 : 5;
        }
    }
}
