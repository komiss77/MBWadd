// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.holographic;

import org.bukkit.entity.Player;
import java.util.List;

public class d implements g
{
    @Override
    public List<Player> v() {
        return null;
    }
    
    @Override
    public void R() {
    }
    
    @Override
    public void B(final Player player) {
    }
    
    @Override
    public void C(final Player player) {
    }
}
