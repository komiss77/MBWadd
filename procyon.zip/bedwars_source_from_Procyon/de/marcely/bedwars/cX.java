// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.EventHandler;
import de.marcely.bedwars.api.event.RoundEndEvent;
import de.marcely.bedwars.game.arena.Arena;
import de.musterbukkit.replaysystem.main.ReplayAPI;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.event.Listener;

public class cX extends cR implements Listener
{
    @Override
    public cT a() {
        return cT.y;
    }
    
    @Override
    public void onEnable() {
        if (!ConfigValue.autojoin_enabled) {
            return;
        }
        final Arena b = s.b(ConfigValue.autojoin_arena);
        if (b == null) {
            return;
        }
        ReplayAPI.setSpectatorLocation(cA.a(b));
        ReplayAPI.setMapName(b.getName());
    }
    
    @Override
    public void onDisable() {
    }
    
    @EventHandler
    public void a(final RoundEndEvent roundEndEvent) {
        ReplayAPI.createSnapshot(Integer.valueOf((int)(roundEndEvent.getArena().getRunningTime() / 1000L)));
    }
}
