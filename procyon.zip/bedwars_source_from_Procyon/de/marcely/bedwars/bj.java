// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.holographic.c;
import java.util.Iterator;
import org.bukkit.World;
import de.marcely.bedwars.game.IEntity;
import java.util.List;
import org.bukkit.Bukkit;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.event.world.WorldLoadEvent;

public class bj
{
    public static void a(final WorldLoadEvent worldLoadEvent) {
        final World world = worldLoadEvent.getWorld();
        for (final Arena arena : s.af) {
            if ((arena.getWorld() == null || !arena.getWorld().getName().equals(arena.C) || !Bukkit.getWorld(world.getName()).equals(arena.getWorld())) && arena.C.equals(world.getName())) {
                arena.setWorld(world);
            }
            if (arena.D != null && world.getName().equals(arena.D)) {
                arena.getLobby().setWorld(world);
            }
        }
        final Iterator<List<IEntity>> iterator2 = s.U.values().iterator();
        while (iterator2.hasNext()) {
            for (final IEntity entity : iterator2.next()) {
                final c<?> a = entity.a();
                if (a != null && entity.a().getWorldString().equals(world.getName())) {
                    a.getLocation().setWorld(world);
                    entity.a().setWorld(world);
                    a.Q();
                }
            }
        }
        if (s.V.containsKey(world.getName())) {
            final List<IEntity> list = s.V.get(world.getName());
            s.V.remove(world.getName());
            final Iterator<IEntity> iterator4 = list.iterator();
            while (iterator4.hasNext()) {
                s.a(iterator4.next());
            }
        }
    }
}
