// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;

public enum S
{
    a("NONE", 0), 
    b("KEY", 1);
    
    private static /* synthetic */ int[] b;
    
    static {
        a = new S[] { S.a, S.b };
    }
    
    private S(final String name, final int ordinal) {
    }
    
    public R a() {
        switch (b()[this.ordinal()]) {
            case 1: {
                return new Q();
            }
            case 2: {
                return new P();
            }
            default: {
                return null;
            }
        }
    }
    
    @Nullable
    public static S a(final String anObject) {
        S[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final S s = values[i];
            if (s.name().equals(anObject)) {
                return s;
            }
        }
        return null;
    }
    
    static /* synthetic */ int[] b() {
        final int[] b = S.b;
        if (b != null) {
            return b;
        }
        final int[] b2 = new int[values().length];
        try {
            b2[S.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            b2[S.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        return S.b = b2;
    }
}
