// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Collection;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.api.CustomLobbyItem;
import de.marcely.bedwars.api.ExtraItem;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import de.marcely.bedwars.game.arena.KickReason;
import java.util.Iterator;
import java.util.concurrent.ExecutionException;
import de.marcely.bedwars.api.gui.DecGUIItem;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import org.bukkit.ChatColor;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.message.b;
import java.util.concurrent.Future;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.game.LobbyItem;
import de.marcely.bedwars.api.ExtraItemListener;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerEvent;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.command.arena.f;
import org.bukkit.Material;
import de.marcely.bedwars.util.i;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.command.t;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.api.SpectateReason;
import org.bukkit.event.block.Action;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.library.worldedit.a;
import org.bukkit.event.player.PlayerInteractEvent;
import java.util.ArrayList;
import java.util.HashMap;
import org.bukkit.entity.Player;
import java.util.List;
import de.marcely.bedwars.game.arena.Arena;
import java.util.Map;

public class aV
{
    public static Map<Arena, List<Player>> g;
    public static Map<Arena, List<Player>> h;
    private static List<Player> C;
    
    static {
        aV.g = new HashMap<Arena, List<Player>>();
        aV.h = new HashMap<Arena, List<Player>>();
        aV.C = new ArrayList<Player>();
    }
    
    public static void a(final PlayerInteractEvent playerInteractEvent) {
        s.b.get(a.class).a(playerInteractEvent);
        final Player player = playerInteractEvent.getPlayer();
        final Action action = playerInteractEvent.getAction();
        if (player == null || action == null) {
            return;
        }
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            final cz cz = cA.E.get(player);
            final Arena arena = (cz != null) ? cz.getArena() : null;
            if (arena != null) {
                playerInteractEvent.setCancelled(true);
                final SpectatorItem a = cB.a(player.getInventory().getHeldItemSlot());
                if (a != null) {
                    if (cz.a() == SpectateReason.DEATH && !a.a().a(player, cz.a())) {
                        return;
                    }
                    a.a().onUse(player, a, arena);
                }
                return;
            }
        }
        final Arena a2 = s.a(player);
        if (a2 == null) {
            if (action == Action.RIGHT_CLICK_BLOCK) {
                final Arena a3 = s.a(playerInteractEvent.getClickedBlock());
                if (a3 != null) {
                    s.g(a3);
                    if (!aV.C.contains(player)) {
                        final String b = s.b(player, a3);
                        if (b != null) {
                            player.sendMessage(b);
                        }
                        aV.C.add(player);
                        new BukkitRunnable() {
                            public void run() {
                                aV.C.remove(player);
                            }
                        }.runTaskLater((Plugin)MBedwars.a, 20L);
                    }
                    return;
                }
                final c a4 = s.a(playerInteractEvent.getClickedBlock());
                if (a4 != null) {
                    if (!aV.C.contains(player)) {
                        t.a((CommandSender)player, a4);
                        aV.C.add(player);
                        new BukkitRunnable() {
                            public void run() {
                                aV.C.remove(player);
                            }
                        }.runTaskLater((Plugin)MBedwars.a, 40L);
                    }
                    return;
                }
            }
            final ItemStack item = playerInteractEvent.getItem();
            if (item != null) {
                final String b2 = i.b(item);
                if (b2 != null && item.getType() == Material.CHEST && b2.equals(s.X)) {
                    f.a.a((CommandSender)player, "bw", "", new String[0]);
                    playerInteractEvent.setCancelled(true);
                    return;
                }
            }
        }
        if (a2 != null) {
            if (playerInteractEvent.getAction() == Action.PHYSICAL && playerInteractEvent.getClickedBlock() != null && playerInteractEvent.getClickedBlock().getType() == Material.SOIL && !ConfigValue.destroyable_farmland) {
                playerInteractEvent.setCancelled(true);
                return;
            }
            if (a2.b() == ArenaStatus.f) {
                if (player.getItemInHand() == null || player.getItemInHand().getType() == null || player.getItemInHand().getType() == Material.AIR) {
                    if (!ConfigValue.interacting && playerInteractEvent.getClickedBlock() != null && k.c(playerInteractEvent.getClickedBlock().getType())) {
                        playerInteractEvent.setCancelled(true);
                    }
                    return;
                }
                if (!ConfigValue.bed_interactable && playerInteractEvent.getClickedBlock() != null && a2.a().a(playerInteractEvent.getClickedBlock().getLocation()) != null) {
                    playerInteractEvent.setCancelled(true);
                    return;
                }
                if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                    final ItemStack item2 = playerInteractEvent.getItem();
                    if (item2 == null || item2.getType() == null) {
                        return;
                    }
                    if (item2.getType() == Material.ENDER_PEARL) {
                        s.a(player, Achievement.h);
                    }
                    final ExtraItem a5 = s.a(player, item2);
                    if (a5 == null) {
                        if (!ConfigValue.interacting && playerInteractEvent.getClickedBlock() != null && (k.c(playerInteractEvent.getClickedBlock().getType()) || (a2.a().a(playerInteractEvent.getClickedBlock().getLocation()) != null && playerInteractEvent.getClickedBlock().getType() == Material.CAKE_BLOCK))) {
                            playerInteractEvent.setCancelled(true);
                        }
                        return;
                    }
                    final PlayerUseExtraItemEvent playerUseExtraItemEvent = new PlayerUseExtraItemEvent(a5, a2, (PlayerEvent)playerInteractEvent, item2);
                    Bukkit.getPluginManager().callEvent((Event)playerUseExtraItemEvent);
                    if (playerUseExtraItemEvent.isCancelled()) {
                        return;
                    }
                    playerInteractEvent.setCancelled(true);
                    for (final ExtraItemListener extraItemListener : a5.getListeners()) {
                        try {
                            extraItemListener.onUse(playerUseExtraItemEvent);
                            if (!playerUseExtraItemEvent.isCancelled()) {
                                continue;
                            }
                            playerInteractEvent.setCancelled(false);
                        }
                        catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
            else if (a2.b() == ArenaStatus.e) {
                playerInteractEvent.setCancelled(true);
                if ((action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) || playerInteractEvent.getItem() == null || playerInteractEvent.getItem().getType() == null) {
                    return;
                }
                player.updateInventory();
                final LobbyItem a6 = s.a(playerInteractEvent.getPlayer().getInventory().getHeldItemSlot(), a2);
                if (a6 != null) {
                    if (a6.getCommands().size() >= 1) {
                        final Iterator<String> iterator2 = a6.getCommands().iterator();
                        while (iterator2.hasNext()) {
                            player.performCommand((String)iterator2.next());
                        }
                    }
                    if (a6.a().getType() == LobbyItem.LobbySpecialType.e) {
                        Sound.LOBBY_ACHIEVEMENTS_OPEN.play(player);
                        final Future<UserAchievements> a7 = UserAchievements.a(player.getUniqueId());
                        s.a((Future<Object>)a7, new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    final UserAchievements userAchievements = a7.get();
                                    final GUI gui = new GUI(b.a(Language.GUI_Achievements_Title).f((CommandSender)player), 0);
                                    for (final Achievement achievement : s.ac) {
                                        gui.addItem(new GUIItem(userAchievements.has(achievement) ? i.a(i.a(ConfigValue.gui_achievements_material_earned.clone(), ChatColor.GREEN + achievement.a((CommandSender)player)), new String[] { ChatColor.DARK_PURPLE + " " + achievement.c((CommandSender)player) }) : i.a(i.a(ConfigValue.gui_achievements_material_unearned.clone(), ChatColor.RED + achievement.a((CommandSender)player)), new String[] { new StringBuilder().append(ChatColor.GRAY).append(ChatColor.BOLD).append(" ????").toString() })) {
                                            @Override
                                            public void onClick(final Player player, final boolean b, final boolean b2) {
                                                Sound.LOBBY_ACHIEVEMENTS_CLICK.play(player);
                                            }
                                        });
                                        if (ConfigValue.gui_achievements_centered) {
                                            gui.centerAtYAll(GUI.CenterFormatType.Normal);
                                        }
                                        gui.setBackground(new DecGUIItem(i.a(ConfigValue.gui_achievements_backgroundmaterial, " ")));
                                    }
                                    gui.open(player);
                                }
                                catch (InterruptedException | ExecutionException ex) {
                                    final Throwable t;
                                    t.printStackTrace();
                                }
                            }
                        });
                    }
                    else if (a6.a().getType() == LobbyItem.LobbySpecialType.d && s.hasPermission((CommandSender)player, Permission.Command_Forcestart) && a2.a != null && !a2.a.I()) {
                        if (!a2.f(player)) {
                            s.a((CommandSender)player, b.a(Language.TooLess_Players).a("arena", a2.getDisplayName()));
                        }
                    }
                    else if (a6.a().getType() == LobbyItem.LobbySpecialType.a) {
                        Sound.LOBBY_LEAVE.play(player);
                        a2.a(KickReason.b, player);
                    }
                    else if (a6.a().getType() == LobbyItem.LobbySpecialType.b) {
                        Sound.LOBBY_SELECTTEAM_OPEN.play(player);
                        a(a2, player);
                    }
                    else if (a6.a().getType() == LobbyItem.LobbySpecialType.c) {
                        Sound.LOBBY_VOTEARENA_OPEN.play(player);
                        b(a2, player);
                    }
                    else if (a6.a().getType() == LobbyItem.LobbySpecialType.f) {
                        final CustomLobbyItem a8 = s.a(a6.a().getName());
                        if (a8 != null) {
                            a8.onUse(player);
                        }
                        else {
                            player.sendMessage(ChatColor.DARK_RED + "WARNING (Please send this error message to an administrator): " + ChatColor.RED + "The special-item '" + a6.a().getName() + "' doesn't exist!");
                        }
                    }
                }
            }
            else if (a2.b() == ArenaStatus.h) {
                playerInteractEvent.setCancelled(true);
            }
        }
    }
    
    public static void a(final Arena arena, final Player player) {
        if (player.getItemInHand() == null || !player.getItemInHand().hasItemMeta()) {
            return;
        }
        final List<Team> r = arena.a().r();
        final GUI gui = new GUI(b.a(Language.GUI_SelectTeam_Title).f((CommandSender)player), 0) {
            @Override
            public void onClose(final Player player) {
                aV.g.get(arena).remove(player);
            }
        };
        for (final Team team : r) {
            final ItemStack a = i.a(Version.a().removeAttributes(i.a(ConfigValue.gui_selectteam_teammaterial, team)), team.getChatColor() + team.a((CommandSender)player, true));
            final ArrayList<String> list = new ArrayList<String>();
            String string = "";
            final Iterator<Player> iterator2 = arena.a(team).iterator();
            while (iterator2.hasNext()) {
                string = String.valueOf(string) + ConfigValue.gui_selectteam_teammaterial_lore_eachplayer.replace("{name}", s.getPlayerDisplayName(iterator2.next())) + "\\n";
            }
            final Iterator<String> iterator3 = ConfigValue.gui_selectteam_teammaterial_lore.iterator();
            while (iterator3.hasNext()) {
                list.add(Language.stringToChatColor(iterator3.next()).replace("{eachplayer}", string).replace("{players}", new StringBuilder().append(arena.a(team).size()).toString()).replace("{allplayers}", new StringBuilder().append(arena.getPlayers().size()).toString()).replace("{maxplayers}", new StringBuilder().append(arena.getMaxPlayers()).toString()).replace("{maxplayersperteam}", new StringBuilder().append(arena.getPerTeamPlayers()).toString()).replace("{teams}", new StringBuilder().append(arena.a().r().size()).toString()));
            }
            ItemStack itemStack = i.a(a, list);
            if (arena.a(player) != null && arena.a(player) == team) {
                itemStack = Version.a().addGlow(itemStack);
            }
            gui.addItem(new GUIItem(itemStack) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    if (arena.getPlayers().contains(player)) {
                        arena.c(player, team);
                    }
                    final Iterator<Player> iterator = new ArrayList<Player>(aV.g.get(arena)).iterator();
                    while (iterator.hasNext()) {
                        aV.a(arena, iterator.next());
                    }
                }
            });
        }
        if (ConfigValue.gui_selectteam_centered) {
            gui.centerAtYAll(GUI.CenterFormatType.Normal);
        }
        gui.setBackground(new DecGUIItem(i.a(ConfigValue.gui_selectteam_backgroundmaterial, " ")));
        List<Player> list2 = aV.g.get(arena);
        if (list2 == null) {
            list2 = new ArrayList<Player>();
            aV.g.put(arena, list2);
        }
        list2.add(player);
        gui.open(player);
    }
    
    public static void b(final Arena arena, final Player player) {
        final GUI gui = new GUI(b.a(Language.GUI_VoteArena_Title).f((CommandSender)player), 1) {
            @Override
            public void onClose(final Player player) {
                aV.h.get(arena).remove(player);
            }
        };
        final Arena.a a = arena.a(player);
        for (final Arena.a obj : arena.I) {
            ItemStack itemStack = i.a(obj.arena.getIcon(), new StringBuilder().append(ChatColor.YELLOW).append(obj.arena.a().r().size()).append(ChatColor.GOLD).append("x").append(ChatColor.YELLOW).append(obj.arena.getTeamPlayers()).toString(), ChatColor.GOLD + b.a(Language.ArenaVoting_MinPlayers).f((CommandSender)player) + " " + ChatColor.YELLOW + obj.arena.k(), "", b.a(Language.GUI_VoteArena_Votes).a("number", new StringBuilder().append(obj.P.size()).toString()).f((CommandSender)player));
            if (a != null && a.equals(obj)) {
                itemStack = Version.a().addGlow(itemStack);
            }
            gui.addItem(new GUIItem(itemStack) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    boolean b3 = false;
                    if (a != null) {
                        if (a.arena.equals(obj.arena)) {
                            b3 = true;
                            Sound.LOBBY_VOTEARENA_ALREADYVOTED.play(player);
                        }
                        a.P.remove(player);
                    }
                    obj.P.add(player);
                    if (!b3) {
                        Sound.LOBBY_VOTEARENA_VOTE.play(player);
                    }
                    final Iterator<Player> iterator = new ArrayList<Player>(aV.h.get(arena)).iterator();
                    while (iterator.hasNext()) {
                        aV.b(arena, iterator.next());
                    }
                }
            });
        }
        for (int i = 0; i < ConfigValue.arenavoting_maxarenas - arena.I.size(); ++i) {
            gui.addItem(new GUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)14), ChatColor.RED + "\u4e42")) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    Sound.LOBBY_VOTEARENA_NOTVOTEABLE.play(player);
                }
            });
        }
        gui.centerAtYAll(GUI.CenterFormatType.Beautiful);
        gui.setBackground(new DecGUIItem(i.a(new ItemStack(Material.STAINED_GLASS_PANE), " ")));
        List<Player> list = aV.h.get(arena);
        if (list == null) {
            list = new ArrayList<Player>();
            aV.h.put(arena, list);
        }
        list.add(player);
        gui.open(player);
    }
}
