// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import com.google.common.io.ByteArrayDataOutput;
import org.bukkit.plugin.Plugin;
import com.google.common.io.ByteStreams;
import org.bukkit.entity.Player;

public class m
{
    @Deprecated
    public static void a(final Player player, final f f) {
    }
    
    public static void a(final Player player, final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("Connect");
        dataOutput.writeUTF(s);
        player.sendPluginMessage((Plugin)MBedwars.a, "BungeeCord", dataOutput.toByteArray());
    }
}
