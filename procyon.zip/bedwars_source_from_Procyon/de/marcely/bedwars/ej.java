// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public enum ej
{
    a("CONNECTED", 0), 
    b("DISCONNECED", 1), 
    c("LOGIN_1", 2), 
    d("LOGIN_2", 3);
    
    static {
        a = new ej[] { ej.a, ej.b, ej.c, ej.d };
    }
    
    private ej(final String name, final int ordinal) {
    }
}
