// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class x extends j
{
    private Arena arena;
    private int to;
    
    public x(final Arena arena, final int to) {
        this.arena = arena;
        this.to = to;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public int b() {
        return this.to;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.h.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.to;
    }
}
