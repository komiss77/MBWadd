// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import org.bukkit.entity.Player;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.event.weather.WeatherChangeEvent;

public class bi
{
    public static void a(final WeatherChangeEvent weatherChangeEvent) {
        if (weatherChangeEvent.toWeatherState() && ConfigValue.no_rain) {
            final Iterator<Player> iterator = s.a(weatherChangeEvent.getWorld(), true).iterator();
            while (iterator.hasNext()) {
                Version.a().d(iterator.next(), false);
            }
        }
    }
}
