// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dH extends dI
{
    public dH() {
        super("name");
    }
    
    @Override
    protected String a(final Player player, final Arena arena) {
        return arena.getName();
    }
}
