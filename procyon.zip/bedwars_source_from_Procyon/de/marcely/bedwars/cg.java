// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class cg extends ch
{
    public static cg a;
    
    static {
        cg.a = new cg();
    }
    
    @Override
    protected String a(final c c) {
        return new StringBuilder().append(c.getKills()).toString();
    }
}
