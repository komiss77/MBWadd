// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import java.util.Iterator;
import java.util.Collection;
import de.marcely.bedwars.util.s;
import java.net.DatagramPacket;
import java.util.ArrayList;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.List;

public class h
{
    public static final int a = 8;
    private static List<i> c;
    private static BukkitRunnable a;
    private static l a;
    
    static {
        h.c = new ArrayList<i>();
        h.a = null;
        h.a = null;
    }
    
    public static void onEnable() {
        (h.a = new l() {
            @Override
            public void b(final DatagramPacket datagramPacket) {
                MBedwars.a.a(datagramPacket);
            }
        }).inject();
        h.a.k();
        (h.a = new BukkitRunnable() {
            public void run() {
                s.a.start();
                if (h.c.size() >= 1) {
                    int n = 0;
                    for (final i i : new ArrayList<i>(h.c)) {
                        if (n > 8) {
                            break;
                        }
                        if (i.a().d().length() >= 1) {
                            h.a.a(i.a().getInetAddress(), i.a().getPort(), i.a().d().getBytes());
                        }
                        else {
                            d.d("Wrong packet format (packetString smaller than 1)");
                        }
                        i.done();
                        h.c.remove(i);
                        ++n;
                    }
                }
                s.a.a(de.marcely.bedwars.util.l.a.d);
            }
        }).runTaskTimer((Plugin)MBedwars.a, 0L, 10L);
    }
    
    public static void onDisable() {
        h.a.close();
    }
    
    public static void b(final i i) {
        h.c.add(i);
    }
    
    public static void close() {
        if (h.a != null) {
            h.a.cancel();
        }
        h.a.close();
    }
}
