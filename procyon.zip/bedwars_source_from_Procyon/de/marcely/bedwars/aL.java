// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class aL
{
    public static void a(final InventoryCloseEvent inventoryCloseEvent) {
        final Player player = (Player)inventoryCloseEvent.getPlayer();
        if (GUI.openInventories.containsKey(player)) {
            if (GUI.cachePlayers.contains(player)) {
                GUI.cachePlayers.remove(player);
            }
            else {
                GUI.openInventories.remove(player).onClose(player);
            }
            if (GUI.openInventoriesDelayed.containsKey(player)) {
                new BukkitRunnable() {
                    public void run() {
                        GUI.openInventoriesDelayed.remove(player);
                    }
                }.runTaskLater((Plugin)MBedwars.a, 1L);
            }
        }
    }
}
