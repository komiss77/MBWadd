// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import org.bukkit.ChatColor;
import de.marcely.bedwars.message.MessagesPack;

public enum Language
{
    Prefix("Prefix", 0, ChatColor.DARK_AQUA + "[Bedwars]"), 
    All_Commands("All_Commands", 1, "All commands:"), 
    Configurations_Reload_Start("Configurations_Reload_Start", 2, ChatColor.GREEN + "Configurations are now reloading!"), 
    Configurations_Reload_End("Configurations_Reload_End", 3, ChatColor.GREEN + "Configurations were reloaded after " + ChatColor.DARK_GREEN + "{time} seconds"), 
    Configurations_Reload_AlreadyLoading("Configurations_Reload_AlreadyLoading", 4, ChatColor.RED + "Configurations are currently already reloading!"), 
    Info_MadeBy("Info_MadeBy", 5, "Made by"), 
    Info_Website("Info_Website", 6, "Website"), 
    Info_Version("Info_Version", 7, "Version"), 
    Info_NewestVersion("Info_NewestVersion", 8, "Newest version"), 
    Page("Page", 9, "Page"), 
    Help("Help", 10, "Help"), 
    Team("Team", 11, "Team"), 
    None("None", 12, "none"), 
    Unkown_Page("Unkown_Page", 13, ChatColor.RED + "Unkown page " + ChatColor.DARK_RED + "{page}"), 
    Unkown_Argument("Unkown_Argument", 14, ChatColor.RED + "Unkown argument " + ChatColor.DARK_RED + "{arg}"), 
    Unkown_Block("Unkown_Block", 15, ChatColor.RED + "Unkown block " + ChatColor.DARK_RED + "{block}"), 
    Unkown_Place("Unkown_Place", 16, ChatColor.RED + "Unkown place " + ChatColor.DARK_RED + "{place}"), 
    Unkown_Itemspawner("Unkown_Itemspawner", 17, ChatColor.RED + "Unkown itemspawner " + ChatColor.DARK_RED + "{itemspawner}"), 
    Version_New("Version_New", 18, ChatColor.GREEN + "A new version has been found! " + ChatColor.DARK_GREEN + "{version}"), 
    Version_NoNew("Version_NoNew", 19, ChatColor.RED + "No new version has been found!"), 
    Error_Occured("Error_Occured", 20, ChatColor.RED + "An error occured!"), 
    Error_Occured_Syntax("Error_Occured_Syntax", 21, ChatColor.RED + "A syntax error occured: " + ChatColor.GOLD + "{message}"), 
    No_Permissions("No_Permissions", 22, ChatColor.RED + "You've got no permissions!"), 
    OnlyAs_Player("OnlyAs_Player", 23, ChatColor.RED + "This works only as a player!"), 
    Not_Ingame("Not_Ingame", 24, ChatColor.RED + "You're not in a round!"), 
    Not_Ingame_Player("Not_Ingame_Player", 25, ChatColor.DARK_RED + "{player} " + ChatColor.RED + "is not in an round!"), 
    Not_Supported("Not_Supported", 26, ChatColor.RED + "This is not supported for your Version! Please update to version " + ChatColor.DARK_RED + "{version} " + ChatColor.RED + "or higher"), 
    Missing_ArenanameOrMadeby("Missing_ArenanameOrMadeby", 27, ChatColor.RED + "Missing arena-name or made-by"), 
    Color_Yellow("Color_Yellow", 28, "yellow"), 
    Color_Orange("Color_Orange", 29, "orange"), 
    Color_Red("Color_Red", 30, "red"), 
    Color_Blue("Color_Blue", 31, "blue"), 
    Color_LightBlue("Color_LightBlue", 32, "light blue"), 
    Color_Cyan("Color_Cyan", 33, "cyan"), 
    Color_LightGreen("Color_LightGreen", 34, "light green"), 
    Color_Green("Color_Green", 35, "green"), 
    Color_Purple("Color_Purple", 36, "purple"), 
    Color_Pink("Color_Pink", 37, "pink"), 
    Color_White("Color_White", 38, "white"), 
    Color_LightGray("Color_LightGray", 39, "light gray"), 
    Color_Gray("Color_Gray", 40, "gray"), 
    Color_Brown("Color_Brown", 41, "brown"), 
    Color_Black("Color_Black", 42, "black"), 
    Missing_WorldeditPoints("Missing_WorldeditPoints", 43, ChatColor.RED + "Missing worldedit points!"), 
    Saved_Arena("Saved_Arena", 44, ChatColor.GREEN + "Arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been saved!"), 
    Saved_Bed("Saved_Bed", 45, ChatColor.GREEN + "Saved bed for the team {colorcode}{color} " + ChatColor.GREEN + "in the arena " + ChatColor.DARK_GREEN + "{arena}"), 
    DontForget_WorldeditPoints("DontForget_WorldeditPoints", 46, ChatColor.AQUA + "Don't forged to mark the points with worldedit!"), 
    Exists_Arena("Exists_Arena", 47, ChatColor.RED + "The arena " + ChatColor.DARK_RED + "{arena} " + ChatColor.RED + "already exists!"), 
    KickEveryoneWith("KickEveryoneWith", 48, ChatColor.GRAY + "Kick everyone with the command " + ChatColor.DARK_GRAY + "{command}"), 
    SavedChanged_Arena("SavedChanged_Arena", 49, ChatColor.GREEN + "The arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been changed and saved!"), 
    SavedChanged_Points("SavedChanged_Points", 50, ChatColor.GREEN + "The points by the arena have been successfully changed!"), 
    Spawner_Bronze("Spawner_Bronze", 51, "bronze"), 
    Spawner_Iron("Spawner_Iron", 52, "iron"), 
    Spawner_Gold("Spawner_Gold", 53, "gold"), 
    Added_Itemspawner("Added_Itemspawner", 54, ChatColor.GREEN + "Itemspawner " + ChatColor.DARK_GREEN + "{spawnertype} " + ChatColor.GREEN + "has been successfully added!"), 
    Added_Sign("Added_Sign", 55, ChatColor.DARK_GREEN + "Sign " + ChatColor.GREEN + "has been successfully added!"), 
    Removed_Sign("Removed_Sign", 56, ChatColor.GOLD + "Removed sign"), 
    Removed_Itemspawners("Removed_Itemspawners", 57, ChatColor.DARK_GREEN + "{number} " + ChatColor.GREEN + "Itemspawners have been removed!"), 
    Start_Round("Start_Round", 58, ChatColor.GREEN + "Round is starting now."), 
    Stop_Round("Stop_Round", 59, ChatColor.GREEN + "Round has been stopped."), 
    Kicked_Player("Kicked_Player", 60, ChatColor.GREEN + "Successfully kicked " + ChatColor.DARK_GREEN + "{player}" + ChatColor.GREEN + " from " + ChatColor.DARK_GREEN + "{arena}"), 
    Kicked_Player_ToPlayer("Kicked_Player_ToPlayer", 61, ChatColor.RED + "You were kicked from this round!"), 
    List_Arenas("List_Arenas", 62, ChatColor.YELLOW + "All arenas: " + ChatColor.GOLD), 
    Only_BetaMember("Only_BetaMember", 63, ChatColor.RED + "You are now allowed to join while bedwars is in the beta!"), 
    NotAvaible_Color("NotAvaible_Color", 64, ChatColor.RED + "Unkown color " + ChatColor.DARK_RED + "{color}"), 
    JoinMessage_stopped("JoinMessage_stopped", 65, ChatColor.RED + "This arena is currently stopped!"), 
    JoinMessage_reseting("JoinMessage_reseting", 66, ChatColor.RED + "This arena is currently reseting itself!"), 
    JoinMessage_full("JoinMessage_full", 67, ChatColor.RED + "This arena is currently full!"), 
    JoinMessage_running("JoinMessage_running", 68, ChatColor.RED + "This arena is already running!"), 
    JoinMessage_alreadyInside("JoinMessage_alreadyInside", 69, ChatColor.RED + "You are already inside the arena!"), 
    JoinMessage("JoinMessage", 70, ChatColor.GOLD + "{player} " + ChatColor.YELLOW + "has joined this round."), 
    LeaveMessage("LeaveMessage", 71, ChatColor.GOLD + "{player} " + ChatColor.YELLOW + "left this round."), 
    NotFound_Player("NotFound_Player", 72, ChatColor.DARK_RED + "{player} " + ChatColor.RED + "has not been found!"), 
    @Deprecated
    NotFound_Arena("NotFound_Arena", 73, ChatColor.RED + "There's no arena with the name " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + "!"), 
    @Deprecated
    NotFound_Arena_Loading("NotFound_Arena_Loading", 74, ChatColor.GOLD + "(Arena is currently loading)"), 
    NotFound_Author("NotFound_Author", 75, ChatColor.RED + "There's no author named " + ChatColor.DARK_RED + "{author}" + ChatColor.RED + "!"), 
    Get_Bed("Get_Bed", 76, ChatColor.GREEN + "You've got the bed of {colorcode}{color}"), 
    Countdown_Start("Countdown_Start", 77, ChatColor.GOLD + "The countdown is starting now!"), 
    Countdown_Stop("Countdown_Stop", 78, ChatColor.GOLD + "The countdown has been stopped!"), 
    Countdown_Counting("Countdown_Counting", 79, ChatColor.GOLD + "This round is starting in " + ChatColor.YELLOW + "{number} " + ChatColor.GOLD + "seconds!"), 
    Countdown_Changed("Countdown_Changed", 80, ChatColor.GOLD + "The countdown has been changed to " + ChatColor.YELLOW + "{number} " + ChatColor.GOLD + "seconds!"), 
    Countdown_Voting_Counting("Countdown_Voting_Counting", 81, ChatColor.GOLD + "The arena voting ends in " + ChatColor.YELLOW + "{number} " + ChatColor.GOLD + "seconds!"), 
    TooFew_Materials("TooFew_Materials", 82, ChatColor.RED + "You've got too few materials to buy this!"), 
    TooLess_Players("TooLess_Players", 83, ChatColor.RED + "There're too less players in this round!"), 
    NeedMore_Players_Than("NeedMore_Players_Than", 84, ChatColor.RED + "You need more players than " + ChatColor.DARK_RED + "{amount}" + ChatColor.RED + "!"), 
    Win_Money("Win_Money", 85, ChatColor.GOLD + "You've won " + ChatColor.YELLOW + "{number}" + ChatColor.GOLD + "$!"), 
    Player_NotIngameAnymore("Player_NotIngameAnymore", 86, ChatColor.DARK_RED + "{player} " + ChatColor.RED + "is not ingame anymore!"), 
    Player_NotFound("Player_NotFound", 87, ChatColor.DARK_RED + "{player} " + ChatColor.RED + "has not been found!"), 
    Player_Cheating("Player_Cheating", 88, ChatColor.GOLD + "{player} " + ChatColor.YELLOW + "has been kicked because he was cheating!"), 
    Player_Loosing("Player_Loosing", 89, ChatColor.GOLD + "{player} " + ChatColor.YELLOW + "has lost this round!"), 
    Players("Players", 90, "Players"), 
    Team_Won("Team_Won", 91, ChatColor.YELLOW + "The {colorcode}{color} " + ChatColor.YELLOW + "team has won this round!"), 
    Team_NotAddedYet("Team_NotAddedYet", 92, ChatColor.RED + "The {teamcolor}{team} " + ChatColor.RED + "team has not been added yet to the arena " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + "!"), 
    ChangeTeam_Full("ChangeTeam_Full", 93, ChatColor.GRAY + "The {colorcode}{color} " + ChatColor.GRAY + "team is already full!"), 
    ChangeTeam_AlreadyInside("ChangeTeam_AlreadyInside", 94, ChatColor.GRAY + "You are already a member of the {colorcode}{color}" + ChatColor.GRAY + " team!"), 
    ChangeTeam_Changed("ChangeTeam_Changed", 95, ChatColor.GRAY + "You are now playing in the {colorcode}{color} " + ChatColor.GRAY + "team"), 
    Changed_Postitions("Changed_Postitions", 96, ChatColor.GREEN + "The positions have been successfully changed!"), 
    Changed_LobbyLocation("Changed_LobbyLocation", 97, ChatColor.GREEN + "The lobby position of the arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been successfully changed!"), 
    Changed_TeamSpawn("Changed_TeamSpawn", 98, ChatColor.GREEN + "The spawn position of the team {colorcode}{color} " + ChatColor.GREEN + "has been successfully changed!"), 
    Changed_ArenaWorld("Changed_ArenaWorld", 99, ChatColor.GREEN + "The world of the arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been changed to " + ChatColor.DARK_GREEN + "{world}"), 
    @Deprecated
    Changed_TopStatue_Location("Changed_TopStatue_Location", 100, ChatColor.GREEN + "The coordinates by the topstatue " + ChatColor.DARK_GREEN + "{place} " + ChatColor.GREEN + "has been successfully changed!"), 
    Spawn_Ranking("Spawn_Ranking", 101, ChatColor.GREEN + "A ranking statue at place " + ChatColor.DARK_GREEN + "{place}" + ChatColor.GREEN + " has been successfully spawned!"), 
    Changed_GameDoneLocation("Changed_GameDoneLocation", 102, ChatColor.GREEN + "The " + ChatColor.DARK_GREEN + "gamedonelocation " + ChatColor.GREEN + "has been successfully changed!"), 
    Hologram_Remove("Hologram_Remove", 103, ChatColor.GREEN + "The hologram with the ID " + ChatColor.DARK_GREEN + "{id} " + ChatColor.GREEN + "has been successfully removed!"), 
    Hologram_Remove_IDNotExists("Hologram_Remove_IDNotExists", 104, ChatColor.RED + "There's no hologram with the ID " + ChatColor.DARK_RED + "{id}" + ChatColor.RED + "!"), 
    Hologram_Add("Hologram_Add", 105, ChatColor.GREEN + "A new hologram with the ID " + ChatColor.DARK_GREEN + "{id}" + ChatColor.GREEN + " has been successfully added!"), 
    Hologram_List("Hologram_List", 106, "Holograms"), 
    Stats_Rank("Stats_Rank", 107, "Rank: " + ChatColor.YELLOW), 
    Stats_Won("Stats_Won", 108, "Won: " + ChatColor.YELLOW), 
    Stats_Lost("Stats_Lost", 109, "Lost: " + ChatColor.YELLOW), 
    Stats_WL("Stats_WL", 110, "W/L: " + ChatColor.YELLOW), 
    Stats_RoundsPlayed("Stats_RoundsPlayed", 111, "Rounds played: " + ChatColor.YELLOW), 
    Stats_Kills("Stats_Kills", 112, "Kills: " + ChatColor.YELLOW), 
    Stats_Deaths("Stats_Deaths", 113, "Deaths: " + ChatColor.YELLOW), 
    Stats_KD("Stats_KD", 114, "K/D: " + ChatColor.YELLOW), 
    Stats_BedsDestroyed("Stats_BedsDestroyed", 115, "Beds destroyed: " + ChatColor.YELLOW), 
    Stats_PlayTime("Stats_PlayTime", 116, "Time played: " + ChatColor.YELLOW), 
    Destroyed_Bed("Destroyed_Bed", 117, ChatColor.WHITE + "The bed of team {teamcolor}{team} " + ChatColor.WHITE + "has been destroyed by " + ChatColor.GRAY + "{player}" + ChatColor.WHITE + "!"), 
    Number_NotOne("Number_NotOne", 118, ChatColor.DARK_RED + "{number} " + ChatColor.RED + "is not a number!"), 
    Stats_By("Stats_By", 119, "Stats by {player}"), 
    NotWorking("NotWorking", 120, ChatColor.RED + "This won't work!"), 
    Kicked_Everyone("Kicked_Everyone", 121, ChatColor.GREEN + "Everyone has been successfully kicked!"), 
    Currently_NotWorking("Currently_NotWorking", 122, ChatColor.RED + "This is currently not working!"), 
    GUI_Create_Title("GUI_Create_Title", 123, ChatColor.GOLD + "Create"), 
    GUI_Setup_Title("GUI_Setup_Title", 124, ChatColor.GOLD + "Setup"), 
    GUI_Achievements_Title("GUI_Achievements_Title", 125, ChatColor.GOLD + "Achievements"), 
    GUI_SelectTeam_Title("GUI_SelectTeam_Title", 126, ChatColor.GOLD + "Select team"), 
    GUI_RunningGames_Title("GUI_RunningGames_Title", 127, ChatColor.GOLD + "Running games"), 
    GUI_Spectator_Teleporter("GUI_Spectator_Teleporter", 128, ChatColor.YELLOW + "Teleport"), 
    GUI_VoteArena_Title("GUI_VoteArena_Title", 129, ChatColor.GOLD + "Vote for an arena"), 
    GUI_VoteArena_Votes("GUI_VoteArena_Votes", 130, ChatColor.AQUA + "{number} " + ChatColor.DARK_AQUA + "votes"), 
    RunningGames_NoOne("RunningGames_NoOne", 131, ChatColor.RED + "No arena is currently running!"), 
    Enabled_Arena("Enabled_Arena", 132, ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "is now " + ChatColor.DARK_GREEN + "enabled!"), 
    Disabled_Arena("Disabled_Arena", 133, ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "is now " + ChatColor.DARK_RED + "disabled!"), 
    Create_Arena("Create_Arena", 134, ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been successfully created!"), 
    Remove_Arena("Remove_Arena", 135, ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "has been sucessfully removed!"), 
    Usage("Usage", 136, ChatColor.GOLD + "Usage: " + ChatColor.YELLOW + "{usage}"), 
    Usage_ArenaCreate_Region("Usage_ArenaCreate_Region", 137, ChatColor.GOLD + "Usage (Region):"), 
    Usage_ArenaCreate_World("Usage_ArenaCreate_World", 138, ChatColor.GOLD + "Usage (World):"), 
    Usage_ArenaCreate_MapVote("Usage_ArenaCreate_MapVote", 139, ChatColor.GOLD + "Usage (Arena Voting):"), 
    Updated_Sign("Updated_Sign", 140, "Sign has been successfully updated!"), 
    Search_Update("Search_Update", 141, "Searching for an update..."), 
    Offline_UpdateService("Offline_UpdateService", 142, "The update-service is probably offline!"), 
    InWork_Job("InWork_Job", 143, "This job is already in work!"), 
    newUpdate("newUpdate", 144, "A new update has been found"), 
    noNewUpdate("noNewUpdate", 145, "There is currently no update for this resource!"), 
    Arena_HasToBeStopped("Arena_HasToBeStopped", 146, ChatColor.RED + "The arena " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + " has to be stopped!"), 
    Arena_JoinIssue_WorldDoesntExists("Arena_JoinIssue_WorldDoesntExists", 147, ChatColor.RED + "The arena " + ChatColor.DARK_RED + "{arena" + ChatColor.RED + " has an issue: The world doesn't exists!"), 
    Arena_JoinIssue_VotingEnabled("Arena_JoinIssue_VotingEnabled", 148, ChatColor.RED + "Ooops: " + ChatColor.RED + "This is a normal arena but voting is enabled!"), 
    Arena_JoinIssue_VotingDisabled("Arena_JoinIssue_VotingDisabled", 149, ChatColor.RED + "Ooops: " + ChatColor.RED + "This is a voting arena but voting is disabled!"), 
    FixProblemsBeforeEnabled("FixProblemsBeforeEnabled", 150, ChatColor.RED + "Please fix these problems before enabling:"), 
    Use_TrueOrFalse("Use_TrueOrFalse", 151, ChatColor.RED + "Use <true/false>!"), 
    Reseting_Now("Reseting_Now", 152, ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "is now getting regenerated!"), 
    Reseting_Start_Failed("Reseting_Start_Failed", 153, ChatColor.RED + "Failed to start regeneration of the arena " + ChatColor.DARK_RED + "{arena}"), 
    Reseting_Start_Failed_AlreadyRunning("Reseting_Start_Failed_AlreadyRunning", 154, ChatColor.RED + "Failed to start the regeneration proccess of the arena " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + " as already an other one is running"), 
    NotSameWorld_Arena("NotSameWorld_Arena", 155, ChatColor.RED + "You are not in the world of " + ChatColor.DARK_RED + "{arena} " + ChatColor.RED + "(" + ChatColor.DARK_RED + "{world}" + ChatColor.RED + ")!"), 
    Problem_Arena_World("Problem_Arena_World", 156, ChatColor.RED + "There is a problem with the world of the arena " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + "!"), 
    FixProblemWith("FixProblemWith", 157, ChatColor.YELLOW + "Fix this problem with: " + ChatColor.GOLD), 
    Spawned_LobbyVillager("Spawned_LobbyVillager", 158, ChatColor.DARK_GREEN + "lobbyvillager " + ChatColor.GREEN + "has been successfully spawned!"), 
    Spawned_TeamSelectVillager("Spawned_TeamSelectVillager", 159, ChatColor.DARK_GREEN + "teamselectvillager " + ChatColor.GREEN + "has been successfully spawned!"), 
    Spawned_Dealer("Spawned_Dealer", 160, ChatColor.DARK_GREEN + "Dealer " + ChatColor.GREEN + "has been successfully spawned!"), 
    Spawned_UpgradeDealer("Spawned_UpgradeDealer", 161, ChatColor.DARK_GREEN + "Upgrade Dealer " + ChatColor.GREEN + "has been successfully spawned!"), 
    NotLooking_AtSign("NotLooking_AtSign", 162, ChatColor.RED + "You're not looking at a sign!"), 
    Sign_Lobby("Sign_Lobby", 163, ChatColor.YELLOW + "Lobby"), 
    Sign_Running("Sign_Running", 164, ChatColor.GOLD + "Running"), 
    Sign_Stopped("Sign_Stopped", 165, ChatColor.RED + "Stopped"), 
    Sign_Reseting("Sign_Reseting", 166, ChatColor.GREEN + "Reseting"), 
    Enabled("Enabled", 167, "Enabled"), 
    Disabled("Disabled", 168, "Disabled"), 
    NotAllowed_BedDestroy("NotAllowed_BedDestroy", 169, ChatColor.RED + "You're not allowed to destroy your own bed!"), 
    NotAllowed_SelectColor("NotAllowed_SelectColor", 170, ChatColor.RED + "You're not allowed to select the color {colorcode}{color}" + ChatColor.RED + "!"), 
    Lobby_Item_Achievements("Lobby_Item_Achievements", 171, ChatColor.GOLD + "Achievements"), 
    Lobby_Item_ForceStart("Lobby_Item_ForceStart", 172, ChatColor.YELLOW + "Force start"), 
    Lobby_Item_Leave("Lobby_Item_Leave", 173, ChatColor.RED + "Leave"), 
    Lobby_Item_SelectTeam("Lobby_Item_SelectTeam", 174, ChatColor.YELLOW + "Select team"), 
    Lobby_Item_VoteArena("Lobby_Item_VoteArena", 175, ChatColor.YELLOW + "Vote for an arena"), 
    Lobby_PrintMapInfo_ArenaName("Lobby_PrintMapInfo_ArenaName", 176, "Arena Name"), 
    Lobby_PrintMapInfo_BuildBy("Lobby_PrintMapInfo_BuildBy", 177, "Build by"), 
    Spectator_Item_Teleporter("Spectator_Item_Teleporter", 178, ChatColor.YELLOW + "Teleport"), 
    Spectator_Item_ChangeSpeed("Spectator_Item_ChangeSpeed", 179, ChatColor.YELLOW + "Change Speed"), 
    Spectator_Item_Leave("Spectator_Item_Leave", 180, ChatColor.RED + "Leave"), 
    Spectator_Item_NextRound("Spectator_Item_NextRound", 181, ChatColor.GOLD + "Change Arena"), 
    Trap("Trap", 182, ChatColor.YELLOW + "Someone walked over your trap!"), 
    Teleporter("Teleporter", 183, ChatColor.YELLOW + "Teleporting you in a few seconds..."), 
    Teleporter_Failed("Teleporter_Failed", 184, ChatColor.RED + "Teleportation has been stopped!"), 
    Bridge_NotEnoughMaterials("Bridge_NotEnoughMaterials", 185, ChatColor.RED + "You need more materials of " + ChatColor.DARK_RED + "{material}" + ChatColor.RED + "!"), 
    Give_Itemspawner("Give_Itemspawner", 186, ChatColor.GREEN + "Gave you " + ChatColor.DARK_GREEN + "{amount}" + ChatColor.GREEN + " of " + ChatColor.DARK_GREEN + "{itemspawner}"), 
    Teleport_Success("Teleport_Success", 187, ChatColor.GREEN + "You were successfully teleported to the arena " + ChatColor.DARK_GREEN + "{arena}"), 
    Lobby_Waiting("Lobby_Waiting", 188, ChatColor.GOLD + "Waiting for " + ChatColor.YELLOW + "{amount}" + ChatColor.GOLD + "..."), 
    Lobby_Enough("Lobby_Enough", 189, ChatColor.GOLD + "There're enough players in this round!"), 
    Addons_Enabled("Addons_Enabled", 190, "Enabled addons:"), 
    Addons_Disabled("Addons_Disabled", 191, "Disabled addons:"), 
    Addon_Unkown("Addon_Unkown", 192, ChatColor.RED + "Unkown addon " + ChatColor.DARK_RED + "{id}"), 
    Addon_Enabled("Addon_Enabled", 193, ChatColor.GREEN + "The addon " + ChatColor.DARK_GREEN + "{name}" + ChatColor.GREEN + " is now " + ChatColor.DARK_GREEN + "enabled" + ChatColor.GREEN + "!"), 
    Addon_Disabled("Addon_Disabled", 194, ChatColor.GREEN + "The addon " + ChatColor.DARK_GREEN + "{name}" + ChatColor.GREEN + " is now " + ChatColor.DARK_RED + "disabled" + ChatColor.GREEN + "!"), 
    Addon_Research("Addon_Research", 195, ChatColor.GREEN + "Found " + ChatColor.DARK_GREEN + "{number}" + ChatColor.GREEN + " new addons!"), 
    Addon_Command_None("Addon_Command_None", 196, ChatColor.RED + "This Add-On doesn't have any commands!"), 
    Addon_Command_Unkown("Addon_Command_Unkown", 197, ChatColor.RED + "Unkown command " + ChatColor.DARK_RED + "{command}"), 
    Addon_Command_List("Addon_Command_List", 198, ChatColor.GOLD + "Commands for " + ChatColor.YELLOW + "{addon}"), 
    AlreadyInside_Arena("AlreadyInside_Arena", 199, ChatColor.RED + "You're already inside an arena!"), 
    Requires_WorldEdit("Requires_WorldEdit", 200, ChatColor.DARK_RED + "WorldEdit " + ChatColor.RED + "is required for that!"), 
    CrashMessage_MissingBed("CrashMessage_MissingBed", 201, "Missing bed locations"), 
    CrashMessage_MissingTeamSpawn("CrashMessage_MissingTeamSpawn", 202, "Missing team-spawnpoints"), 
    CrashMessage_MissingLobbyLocation("CrashMessage_MissingLobbyLocation", 203, "Missing lobby location"), 
    CrashMessage_MissingGameDoneLocation("CrashMessage_MissingGameDoneLocation", 204, "Missing game-done-location"), 
    CrashMessage_TooFewItemSpawners("CrashMessage_TooFewItemSpawners", 205, "Bronze itemspawner are missing"), 
    ItemSpawner_List("ItemSpawner_List", 206, "Item Spawner:"), 
    Commands_List("Commands_List", 207, "Commands:"), 
    Regeneration_Done("Regeneration_Done", 208, ChatColor.GREEN + "The arena " + ChatColor.DARK_GREEN + "{arena}" + ChatColor.GREEN + " has been successfully regenerated after " + ChatColor.DARK_GREEN + "{time} seconds" + ChatColor.GREEN + "!"), 
    Regeneration_Stopped("Regeneration_Stopped", 209, ChatColor.RED + "The regeneration of " + ChatColor.DARK_RED + "{arena}" + ChatColor.RED + " has been cancelled after " + ChatColor.DARK_RED + "{time} seconds"), 
    WorldEdit_Changed("WorldEdit_Changed", 210, ChatColor.GREEN + "Changed the position {id} to " + ChatColor.DARK_GREEN + "x{x} y{y} z{z}"), 
    GetPositionAxe("GetPositionAxe", 211, ChatColor.GREEN + "Gave you the " + ChatColor.DARK_GREEN + "position axe"), 
    Tracker_TrackedPlayer("Tracker_TrackedPlayer", 212, ChatColor.GREEN + "This compass is now looking at the nearest tracked enemy."), 
    Tracker_ReuseDelay("Tracker_ReuseDelay", 213, ChatColor.RED + "Wait " + ChatColor.DARK_RED + "{time} seconds" + ChatColor.RED + " until you can use a tracker again!"), 
    Tracker_Failed_OnlyOne("Tracker_Failed_OnlyOne", 214, ChatColor.DARK_RED + "Failed to track nearest enemy: " + ChatColor.RED + "You are the only player in this round!"), 
    Spectator_Join("Spectator_Join", 215, ChatColor.GOLD + "You're now a spectator!"), 
    Spectator_Leave("Spectator_Leave", 216, ChatColor.GOLD + "You're not a spectator anymore."), 
    Spectator_HowToQuit("Spectator_HowToQuit", 217, ChatColor.YELLOW + "Leave this round using the command " + ChatColor.GOLD + "/bw leave"), 
    RecalculateStats_Sure1("RecalculateStats_Sure1", 218, ChatColor.YELLOW + "Are you sure that you want to recalculate the stats?"), 
    RecalculateStats_Sure2("RecalculateStats_Sure2", 219, ChatColor.YELLOW + "The process will already be executed automatically and can cause lag!"), 
    RecalculateStats_Sure3("RecalculateStats_Sure3", 220, ChatColor.GOLD + "If so, then rewrite this command within a few seconds."), 
    RecalculateStats_Done("RecalculateStats_Done", 221, ChatColor.GREEN + "Done after " + ChatColor.DARK_GREEN + "{time} seconds" + ChatColor.GREEN + "."), 
    EndLobby_Counting("EndLobby_Counting", 222, ChatColor.GOLD + "Teleporting you in " + ChatColor.YELLOW + "{number}" + " seconds " + ChatColor.GOLD + "to the lobby"), 
    EndLobby_Title("EndLobby_Title", 223, "{teamcolor" + ChatColor.BOLD + "{team" + ChatColor.WHITE + " won this round!"), 
    EndLobby_Title_Nobody("EndLobby_Title_Nobody", 224, new StringBuilder().append(ChatColor.RED).append(ChatColor.UNDERLINE).append("Nobody").append(ChatColor.WHITE).append(" won this round.").toString()), 
    ArenaVoting_NoAvaibleArenas("ArenaVoting_NoAvaibleArenas", 225, ChatColor.RED + "There's no arena left. Sorry!"), 
    ArenaVoting_ArenasUpdated("ArenaVoting_ArenasUpdated", 226, ChatColor.GOLD + "The arenas in the arena voting has been updated."), 
    ArenaVoting_Recount_NoArenaToVote("ArenaVoting_Recount_NoArenaToVote", 227, ChatColor.RED + "Reseting the countdown: There's no arena to vote for!"), 
    ArenaVoting_End("ArenaVoting_End", 228, ChatColor.GOLD + "The following arena won the voting: " + ChatColor.YELLOW + "{arena}"), 
    ArenaVoting_Recount_TooFewPlayers("ArenaVoting_Recount_TooFewPlayers", 229, ChatColor.RED + "Need " + ChatColor.DARK_RED + "{number}" + ChatColor.RED + " more players to play on this arena!"), 
    ArenaVoting_MinPlayers("ArenaVoting_MinPlayers", 230, "Min. players:"), 
    ForceStart_Already("ForceStart_Already", 231, ChatColor.RED + "Game is already starting!"), 
    Scoreboard_Lobby_ArenaName("Scoreboard_Lobby_ArenaName", 232, "Arena name:"), 
    Scoreboard_Lobby_Players("Scoreboard_Lobby_Players", 233, "Players:"), 
    Bed_OnlyDestroyAbleWith_TNT("Bed_OnlyDestroyAbleWith_TNT", 234, ChatColor.RED + "You can only destroy this bed with tnt!"), 
    ItemSpawner_Hologram_Title("ItemSpawner_Hologram_Title", 235, "{spawnercolor}{spawner} " + ChatColor.WHITE + "spawning in " + ChatColor.GRAY + "{time}" + ChatColor.WHITE + " seconds"), 
    MaxPlayers("MaxPlayers", 236, "Max. players"), 
    Shop_D_HyPixel_Avaible("Shop_D_HyPixel_Avaible", 237, ChatColor.DARK_GRAY + "Available:"), 
    Shop_D_HyPixel_ClickToBrowse("Shop_D_HyPixel_ClickToBrowse", 238, ChatColor.YELLOW + "Click to browse!"), 
    Shop_D_HyPixel_Items("Shop_D_HyPixel_Items", 239, ChatColor.DARK_GRAY + "Items:"), 
    Shop_D_HyPixel_ClickToPurchase("Shop_D_HyPixel_ClickToPurchase", 240, ChatColor.YELLOW + "Click to purchase!"), 
    Shop_D_HyPixel_Cost("Shop_D_HyPixel_Cost", 241, ChatColor.GRAY + "Cost: " + ChatColor.WHITE + "{color}{amount} {type}"), 
    Shop_D_HyPixel_GoBack("Shop_D_HyPixel_GoBack", 242, ChatColor.GREEN + "Go Back"), 
    Shop_D_HyPixel_TooExpensive("Shop_D_HyPixel_TooExpensive", 243, ChatColor.RED + "You don't have enough {type}!"), 
    Shop_D_HiveMC_ClickToView("Shop_D_HiveMC_ClickToView", 244, ChatColor.AQUA + "{icon} Click to view " + ChatColor.BOLD + "{item}"), 
    Shop_D_HiveMC_GoBack("Shop_D_HiveMC_GoBack", 245, new StringBuilder().append(ChatColor.RED).append(ChatColor.BOLD).append("Go back").toString()), 
    Shop_D_HiveMC_ReturnToMenu("Shop_D_HiveMC_ReturnToMenu", 246, ChatColor.GRAY + "Return to menu"), 
    Shop_D_HiveMC_ClickToGoBack("Shop_D_HiveMC_ClickToGoBack", 247, ChatColor.AQUA + "{icon} Click to go back"), 
    Shop_D_HiveMC_ClickToBuy("Shop_D_HiveMC_ClickToBuy", 248, ChatColor.AQUA + "{icon} Click to buy"), 
    Shop_D_HiveMC_Cost("Shop_D_HiveMC_Cost", 249, ChatColor.GOLD + "Cost"), 
    Shop_D_Rewinside_ShopType_New("Shop_D_Rewinside_ShopType_New", 250, "You are using the new and improved shop"), 
    Shop_D_Rewinside_ShopType_Old("Shop_D_Rewinside_ShopType_Old", 251, "You are using the old shop"), 
    Shop_D_Rewinside_ShopType_Switch("Shop_D_Rewinside_ShopType_Switch", 252, "Click here to switch between the versions"), 
    Shop_D_BergwerkLABS_CurrentPage("Shop_D_BergwerkLABS_CurrentPage", 253, ChatColor.AQUA + "Current page"), 
    Shop_D_BergwerkLABS_ChangePage("Shop_D_BergwerkLABS_ChangePage", 254, ChatColor.AQUA + "Page {page}"), 
    Shop_D_BergwerkLABS_Buy("Shop_D_BergwerkLABS_Buy", 255, ChatColor.GREEN + "Buy " + ChatColor.GRAY + ChatColor.ITALIC + "<Left click>"), 
    Shop_D_BergwerkLABS_Buy_TooExpensive("Shop_D_BergwerkLABS_Buy_TooExpensive", 256, ChatColor.GRAY + "Too expensive!"), 
    Shop_D_HyPixelV2_ClickToView("Shop_D_HyPixelV2_ClickToView", 257, ChatColor.YELLOW + "Click to view!"), 
    Shop_D_HyPixelV2_Seperator_Categories("Shop_D_HyPixelV2_Seperator_Categories", 258, ChatColor.DARK_GRAY + "\u2b06" + ChatColor.GRAY + " Categories"), 
    Shop_D_HyPixelV2_Seperator_Items("Shop_D_HyPixelV2_Seperator_Items", 259, ChatColor.DARK_GRAY + "\u2b07" + ChatColor.GRAY + " Items"), 
    ShopData_NotLoadedYet("ShopData_NotLoadedYet", 260, ChatColor.RED + "The shop is currently loading!"), 
    Lobby_CountdownTitle_GoodLuck("Lobby_CountdownTitle_GoodLuck", 261, ChatColor.GOLD + "Good Luck!"), 
    MiniShop_Title("MiniShop_Title", 262, "{title}" + ChatColor.GRAY + " disappears in " + ChatColor.DARK_GRAY + "{time} seconds"), 
    ArenaGUI_Back("ArenaGUI_Back", 263, ChatColor.RED + "Back"), 
    ArenaGUI_Page_Main("ArenaGUI_Page_Main", 264, "Main"), 
    ArenaGUI_Page_Teams("ArenaGUI_Page_Teams", 265, "Teams"), 
    ArenaGUI_Page_Itemspawners("ArenaGUI_Page_Itemspawners", 266, "Itemspawners"), 
    ArenaGUI_Page_Flags("ArenaGUI_Page_Flags", 267, "Flags"), 
    ArenaGUI_Page_Main_Configure("ArenaGUI_Page_Main_Configure", 268, ChatColor.YELLOW + "Configure"), 
    ArenaGUI_Page_Main_SetLobby("ArenaGUI_Page_Main_SetLobby", 269, ChatColor.YELLOW + "Set lobby at your position"), 
    ArenaGUI_Page_Main_Rename("ArenaGUI_Page_Main_Rename", 270, ChatColor.YELLOW + "Change name"), 
    ArenaGUI_Page_Main_Enable("ArenaGUI_Page_Main_Enable", 271, ChatColor.YELLOW + "Set enabled"), 
    ArenaGUI_Page_Main_Disable("ArenaGUI_Page_Main_Disable", 272, ChatColor.YELLOW + "Set disabled"), 
    ArenaGUI_Page_Main_Regenerate("ArenaGUI_Page_Main_Regenerate", 273, ChatColor.YELLOW + "Force regeneration"), 
    ArenaGUI_Page_Main_SaveBlocks("ArenaGUI_Page_Main_SaveBlocks", 274, ChatColor.YELLOW + "Save blocks/entities"), 
    ArenaGUI_Page_Main_SetWorld("ArenaGUI_Page_Main_SetWorld", 275, ChatColor.YELLOW + "Change world to your world"), 
    ArenaGUI_Page_Main_SetPosition("ArenaGUI_Page_Main_SetPosition", 276, ChatColor.YELLOW + "Change corners of arena"), 
    ArenaGUI_Page_Main_Teleport("ArenaGUI_Page_Main_Teleport", 277, ChatColor.YELLOW + "Teleport to the arena"), 
    ArenaGUI_Page_Main_Info("ArenaGUI_Page_Main_Info", 278, ChatColor.YELLOW + "View informations"), 
    ArenaGUI_Page_Main_Enter("ArenaGUI_Page_Main_Enter", 279, ChatColor.YELLOW + "Enter the arena"), 
    ArenaGUI_Page_Main_EnterSpectator("ArenaGUI_Page_Main_EnterSpectator", 280, ChatColor.YELLOW + "Enter the arena as a spectator"), 
    ArenaGUI_Page_Main_SetSpectatorSpawn("ArenaGUI_Page_Main_SetSpectatorSpawn", 281, ChatColor.YELLOW + "Set the spawnpoint for spectators"), 
    ArenaGUI_Page_Teams_SetSpawn("ArenaGUI_Page_Teams_SetSpawn", 282, ChatColor.YELLOW + "Set spawn at your position"), 
    ArenaGUI_Page_Teams_GetBed("ArenaGUI_Page_Teams_GetBed", 283, ChatColor.YELLOW + "Get bed block"), 
    ArenaGUI_Page_Itemspawners_Remove("ArenaGUI_Page_Itemspawners_Remove", 284, ChatColor.RED + "Remove itemspawners at your position"), 
    ArenaGUI_Page_Itemspawners_Add("ArenaGUI_Page_Itemspawners_Add", 285, ChatColor.YELLOW + "Add spawner at your position"), 
    ArenaGUI_Page_Itemspawners_Get("ArenaGUI_Page_Itemspawners_Get", 286, ChatColor.YELLOW + "Get {amount} of the items"), 
    ArenaGUI_Page_Flags_Modify("ArenaGUI_Page_Flags_Modify", 287, ChatColor.YELLOW + "Modify '" + ChatColor.GOLD + "{name" + ChatColor.YELLOW + "' ({type})"), 
    Flag_Modfiy_Success("Flag_Modfiy_Success", 288, ChatColor.GREEN + "Successfully changed " + ChatColor.DARK_GREEN + "{name} " + ChatColor.GREEN + "to " + ChatColor.DARK_GREEN + "{to}"), 
    Flag_Modfiy_WrongType("Flag_Modfiy_WrongType", 289, ChatColor.DARK_RED + "{value} " + ChatColor.RED + "is not an instance of " + ChatColor.DARK_RED + "{type}"), 
    ArenaType_NotSupported("ArenaType_NotSupported", 290, ChatColor.RED + "This is not supported for the type " + ChatColor.DARK_RED + "{type}" + ChatColor.RED + " of the arena " + ChatColor.DARK_RED + "{name}"), 
    Arena_AutoSavedBlocks("Arena_AutoSavedBlocks", 291, ChatColor.YELLOW + "Blocks inside the arena were automatically saved!"), 
    Ranking_Unranked("Ranking_Unranked", 292, "Unranked"), 
    Clone_Arena("Clone_Arena", 293, ChatColor.GREEN + "Successfully cloned arena " + ChatColor.DARK_GREEN + "{arena1} " + ChatColor.GREEN + "to " + ChatColor.DARK_GREEN + "{arena2}"), 
    Wait_AllArenasLoaded("Wait_AllArenasLoaded", 294, ChatColor.RED + "Wait until every arena has been successfully loaded!"), 
    Voteable_Arenas("Voteable_Arenas", 295, ChatColor.GOLD + "Voteable arenas:"), 
    Voteable_Arenas_More("Voteable_Arenas_More", 296, ChatColor.GRAY + "{amount} " + ChatColor.WHITE + "more arenas..."), 
    Please_SaveArena("Please_SaveArena", 297, ChatColor.GOLD + "Make sure to save your arena with: " + ChatColor.YELLOW + "/bw arena saveblocks <arena name>"), 
    GetSetupItem("GetSetupItem", 298, ChatColor.GREEN + "Gave you the " + ChatColor.DARK_GREEN + "setup item"), 
    Upgrade_Maximum("Upgrade_Maximum", 299, ChatColor.RED + "Max"), 
    Upgrade_Buy_Max("Upgrade_Buy_Max", 300, ChatColor.RED + "You can't upgrade this anymore!"), 
    OneTimePurchase("OneTimePurchase", 301, ChatColor.RED + "You are allowed to buy this only once!"), 
    ArenasGUI_Title("ArenasGUI_Title", 302, ChatColor.AQUA + "Arenas"), 
    Arena_CollidingArena1("Arena_CollidingArena1", 303, ChatColor.RED + "Please change the location of your arena."), 
    Arena_CollidingArena2("Arena_CollidingArena2", 304, ChatColor.RED + "It's intersecting with the arena: " + ChatColor.DARK_RED + "{arena}"), 
    Arena_CollidingArena3("Arena_CollidingArena3", 305, ChatColor.GOLD + "To change the location use the following command: " + ChatColor.YELLOW + "{command}"), 
    Backup_List("Backup_List", 306, ChatColor.GOLD + "Backup Files:"), 
    Backup_Create_Success("Backup_Create_Success", 307, ChatColor.GREEN + "Created a backup with the name " + ChatColor.DARK_GREEN + "{name" + ChatColor.GREEN + " after " + ChatColor.DARK_GREEN + "{time} " + ChatColor.GREEN + "seconds"), 
    Backup_Create_Exists("Backup_Create_Exists", 308, ChatColor.RED + "There's already a backup with the name " + ChatColor.DARK_RED + "{name}"), 
    Backup_Delete_Success("Backup_Delete_Success", 309, ChatColor.GREEN + "Deleted a backup with the name " + ChatColor.DARK_GREEN + "{name}"), 
    Backup_Unkown("Backup_Unkown", 310, ChatColor.RED + "Unkown backup " + ChatColor.DARK_RED + "{name}"), 
    Backup_Restore_Success("Backup_Restore_Success", 311, ChatColor.GREEN + "Successfully restored the backup " + ChatColor.DARK_GREEN + "{name" + " after " + ChatColor.DARK_GREEN + "{time}" + ChatColor.GREEN + " seconds"), 
    Backup_Restore_Ask1("Backup_Restore_Ask1", 312, ChatColor.GOLD + "Are you really sure that you want to restore the backup " + ChatColor.YELLOW + "{name}" + ChatColor.GOLD + "?"), 
    Backup_Restore_Ask2("Backup_Restore_Ask2", 313, ChatColor.GOLD + "If so, then please write the same command within the next 10 seconds"), 
    Scoreboard_BedState_Alive("Scoreboard_BedState_Alive", 314, ChatColor.GREEN + "Alive"), 
    Scoreboard_BedState_Destroyed("Scoreboard_BedState_Destroyed", 315, ChatColor.RED + "Destroyed"), 
    Death_Spectate_RespawnIn("Death_Spectate_RespawnIn", 316, ChatColor.GOLD + "Respawn in " + ChatColor.YELLOW + "{time} " + ChatColor.GOLD + "seconds"), 
    Spectator_ChangeArena_NoneAvailable("Spectator_ChangeArena_NoneAvailable", 317, ChatColor.RED + "No free arena is available!"), 
    Cages_Enable("Cages_Enable", 318, ChatColor.GREEN + "Cages for the arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "are now " + ChatColor.DARK_GREEN + "enabled!"), 
    Cages_Disable("Cages_Disable", 319, ChatColor.GREEN + "Cages for the arena " + ChatColor.DARK_GREEN + "{arena} " + ChatColor.GREEN + "are now " + ChatColor.RED + "disabled!"), 
    Cages_Set("Cages_Set", 320, ChatColor.GREEN + "Changed location of the cage for arena " + ChatColor.DARK_GREEN + "{arena" + ChatColor.GREEN + " and team " + ChatColor.DARK_GREEN + "{team}"), 
    Cages_Info_Title("Cages_Info_Title", 321, "Cages Data"), 
    Cages_Info_Arena("Cages_Info_Arena", 322, "Arena Name"), 
    Cages_Info_IsEnabled("Cages_Info_IsEnabled", 323, "Is Enabled"), 
    Cages_Info_TeamsLeft("Cages_Info_TeamsLeft", 324, "Teams Left"), 
    Cages_Info_TeamsSet("Cages_Info_TeamsSet", 325, "Teams Set"), 
    Cages_Warning_Missing("Cages_Warning_Missing", 326, ChatColor.GOLD + "Warning: " + ChatColor.YELLOW + "Some cages weren't set yet!"), 
    Shop_BuyGroup_Buy_LowerTier("Shop_BuyGroup_Buy_LowerTier", 327, ChatColor.RED + "You already have a higher tier item"), 
    SpectatorAdd_Failed_MissingLocation("SpectatorAdd_Failed_MissingLocation", 328, ChatColor.RED + "Failed to add you as a spectator, as there are no available points to teleport you at."), 
    SaveBlocks_Fail_Players("SaveBlocks_Fail_Players", 329, ChatColor.DARK_RED + "Failed to save the blocks: " + ChatColor.RED + "There are players in the world."), 
    CreateArena_Fail_MainWorld("CreateArena_Fail_MainWorld", 330, ChatColor.RED + "It is not possible to create an arena with the type world in your main world!"), 
    SaveBlocks_Start("SaveBlocks_Start", 331, ChatColor.GOLD + "Started blocks saving operation for the arena " + ChatColor.YELLOW + "{arena}" + ChatColor.GOLD + ". Estimated time: " + ChatColor.YELLOW + "{time}"), 
    SaveBlocks_Fail_AlreadyRunning("SaveBlocks_Fail_AlreadyRunning", 332, ChatColor.DARK_RED + "Failed to save the blocks: " + ChatColor.RED + "Operation is already running."), 
    SaveBlocks_Fail_NotStopped("SaveBlocks_Fail_NotStopped", 333, ChatColor.DARK_RED + "Failed to save the blocks: " + ChatColor.RED + "It's not stopped. (Stop it with /bw arena setenabled {arena} false)"), 
    SaveBlocks_Fail_Unkown("SaveBlocks_Fail_Unkown", 334, ChatColor.DARK_RED + "Failed to save the blocks: " + ChatColor.RED + "A weird error of the type '{type}' has occured"), 
    Regeneration_Fail_SavingBlocks("Regeneration_Fail_SavingBlocks", 335, ChatColor.DARK_RED + "Failed to start regeneration: " + ChatColor.RED + "It's currently saving blocks."), 
    DeathMessage_Killed_1("DeathMessage_Killed_1", 336, "{teamcolor}{player} " + ChatColor.GRAY + "has been killed by " + ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + ChatColor.GRAY + "with " + ChatColor.RED + "\u2764{heartpercent}%"), 
    DeathMessage_Killed_2("DeathMessage_Killed_2", 337, "{teamcolor}{player} " + ChatColor.GRAY + "lost a fight against " + ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + ChatColor.GRAY + "with " + ChatColor.RED + "\u2764{heartpercent}%"), 
    DeathMessage_Killed_3("DeathMessage_Killed_3", 338, "{teamcolor}{player} " + ChatColor.GRAY + "was slain by " + ChatColor.DARK_GRAY + "{killerteamcolor}{killer} " + ChatColor.GRAY + "with " + ChatColor.RED + "\u2764{heartpercent}%"), 
    DeathMessage_Void_1("DeathMessage_Void_1", 339, "{teamcolor}{player} " + ChatColor.GRAY + "fell out of the world"), 
    DeathMessage_Void_2("DeathMessage_Void_2", 340, "{teamcolor}{player} " + ChatColor.GRAY + "fell down a bridge and is still falling"), 
    DeathMessage_Explosion_1("DeathMessage_Explosion_1", 341, "{teamcolor}{player} " + ChatColor.GRAY + "exploded in dozents of pieces"), 
    DeathMessage_Explosion_2("DeathMessage_Explosion_2", 342, "{teamcolor}{player} " + ChatColor.GRAY + "blew up"), 
    DeathMessage_Fall_1("DeathMessage_Fall_1", 343, "{teamcolor}{player} " + ChatColor.GRAY + "broke all of his legs"), 
    DeathMessage_Fall_2("DeathMessage_Fall_2", 344, "{teamcolor}{player} " + ChatColor.GRAY + "fell down from a high place"), 
    DeathMessage_Fire_1("DeathMessage_Fire_1", 345, "{teamcolor}{player} " + ChatColor.GRAY + "was burned to death"), 
    DeathMessage_Fire_2("DeathMessage_Fire_2", 346, "{teamcolor}{player} " + ChatColor.GRAY + "was burned alive"), 
    DeathMessage_Default_1("DeathMessage_Default_1", 347, "{teamcolor}{player} " + ChatColor.GRAY + "died"), 
    Spectator("Spectator", 348, "Spectator"), 
    Countdown_Stopped("Countdown_Stopped", 349, "Stopped"), 
    ItemShop("ItemShop", 350, "Item shop"), 
    UpgradeShop("UpgradeShop", 351, "Upgrade shop"), 
    Motd_Loading("Motd_Loading", 352, "Loading..."), 
    Shop_Price("Shop_Price", 353, "Price: &7{number} {spawnercolor}{spawnertype}"), 
    Shop_Page_Block("Shop_Page_Block", 354, "Block"), 
    Shop_Page_Food("Shop_Page_Food", 355, "Food"), 
    Shop_Page_Armor("Shop_Page_Armor", 356, "Armor"), 
    Shop_Page_Sword("Shop_Page_Sword", 357, "Sword"), 
    Shop_Page_Bow("Shop_Page_Bow", 358, "Bow"), 
    Shop_Page_Pickaxe("Shop_Page_Pickaxe", 359, "Pickaxe"), 
    Shop_Page_Potion("Shop_Page_Potion", 360, "Potion"), 
    Shop_Page_Special("Shop_Page_Special", 361, "Special"), 
    Shop_Page_Extra("Shop_Page_Extra", 362, "Extra"), 
    Shop_Item_HardenedClay("Shop_Item_HardenedClay", 363, "Hardened Clay"), 
    Shop_Item_Endstone("Shop_Item_Endstone", 364, "Endstone"), 
    Shop_Item_Chest("Shop_Item_Chest", 365, "Chest"), 
    Shop_Item_Enderchest("Shop_Item_Enderchest", 366, "Enderchest"), 
    Shop_Item_Ladder("Shop_Item_Ladder", 367, "Ladder"), 
    Shop_Item_Web("Shop_Item_Web", 368, "Web"), 
    Shop_Item_Apple("Shop_Item_Apple", 369, "Apple"), 
    Shop_Item_GrilledPork("Shop_Item_GrilledPork", 370, "Grilled pork"), 
    Shop_Item_Cake("Shop_Item_Cake", 371, "Cake"), 
    Shop_Item_GoldenApple("Shop_Item_GoldenApple", 372, "Golden apple"), 
    Shop_Item_LeatherHelmet("Shop_Item_LeatherHelmet", 373, "Leather helmet"), 
    Shop_Item_LeatherLeggings("Shop_Item_LeatherLeggings", 374, "Leather leggings"), 
    Shop_Item_LeatherBoots("Shop_Item_LeatherBoots", 375, "Leather boots"), 
    Shop_Item_ChainmailChestplateLVL1("Shop_Item_ChainmailChestplateLVL1", 376, "Chainmail chestplate " + ChatColor.GRAY + "LVL 1"), 
    Shop_Item_ChainmailChestplateLVL2("Shop_Item_ChainmailChestplateLVL2", 377, "Chainmail chestplate " + ChatColor.GRAY + "LVL 2"), 
    Shop_Item_ChainmailChestplateLVL3("Shop_Item_ChainmailChestplateLVL3", 378, "Chainmail chestplate " + ChatColor.GRAY + "LVL 3"), 
    Shop_Item_KnockbackStick("Shop_Item_KnockbackStick", 379, "Knockback stick"), 
    Shop_Item_SwordLVL1("Shop_Item_SwordLVL1", 380, "Sword " + ChatColor.GRAY + "LVL 1"), 
    Shop_Item_SwordLVL2("Shop_Item_SwordLVL2", 381, "Sword " + ChatColor.GRAY + "LVL 2"), 
    Shop_Item_SwordLVL3("Shop_Item_SwordLVL3", 382, "Sword " + ChatColor.GRAY + "LVL 3"), 
    Shop_Item_BowLVL1("Shop_Item_BowLVL1", 383, "Bow " + ChatColor.GRAY + "LVL 1"), 
    Shop_Item_BowLVL2("Shop_Item_BowLVL2", 384, "Bow " + ChatColor.GRAY + "LVL 2"), 
    Shop_Item_BowLVL3("Shop_Item_BowLVL3", 385, "Bow " + ChatColor.GRAY + "LVL 3"), 
    Shop_Item_Arrow("Shop_Item_Arrow", 386, "Arrow"), 
    Shop_Item_PickaxeLVL1("Shop_Item_PickaxeLVL1", 387, "Pickaxe " + ChatColor.GRAY + "LVL 1"), 
    Shop_Item_PickaxeLVL2("Shop_Item_PickaxeLVL2", 388, "Pickaxe " + ChatColor.GRAY + "LVL 2"), 
    Shop_Item_PickaxeLVL3("Shop_Item_PickaxeLVL3", 389, "Pickaxe " + ChatColor.GRAY + "LVL 3"), 
    Shop_Item_PotionSwiftness("Shop_Item_PotionSwiftness", 390, "Potion of swiftness"), 
    Shop_Item_PotionRegeneration("Shop_Item_PotionRegeneration", 391, "Potion of regeneration"), 
    Shop_Item_PotionHealing("Shop_Item_PotionHealing", 392, "Potion of healing"), 
    Shop_Item_PotionStrength("Shop_Item_PotionStrength", 393, "Potion of strength"), 
    Shop_Item_Enderpearl("Shop_Item_Enderpearl", 394, "Enderpearl"), 
    Shop_Item_Teleporter("Shop_Item_Teleporter", 395, "Teleporter"), 
    Shop_Item_Minishop("Shop_Item_Minishop", 396, "Minishop"), 
    Shop_Item_Rescueplatform("Shop_Item_Rescueplatform", 397, "Rescue platform"), 
    Shop_Item_Tntsheep("Shop_Item_Tntsheep", 398, "TNT sheep"), 
    Shop_Item_MagnetShoes("Shop_Item_MagnetShoes", 399, "Magnet Shoes"), 
    Shop_Item_Trap("Shop_Item_Trap", 400, "Trap"), 
    Shop_Item_Bridge("Shop_Item_Bridge", 401, "Bridge"), 
    Shop_Item_GuardDog("Shop_Item_GuardDog", 402, "Guard Dog"), 
    Shop_Item_Tracker("Shop_Item_Tracker", 403, "Tracker"), 
    Shop_Item_FishingRod("Shop_Item_FishingRod", 404, "Fisching Rod"), 
    Shop_Item_Snowball("Shop_Item_Snowball", 405, "Snowball"), 
    UpgradeShop_Name_SwordDamage("UpgradeShop_Name_SwordDamage", 406, "Sharpness"), 
    UpgradeShop_Lore_SwordDamage("UpgradeShop_Lore_SwordDamage", 407, "Increases the sword damage"), 
    UpgradeShop_Name_Resistence("UpgradeShop_Name_Resistence", 408, "Armor Resistence"), 
    UpgradeShop_Lore_Resistence("UpgradeShop_Lore_Resistence", 409, "Increases the armor resistence"), 
    UpgradeShop_Name_HealRange("UpgradeShop_Name_HealRange", 410, "Heal Station"), 
    UpgradeShop_Lore_HealRange("UpgradeShop_Lore_HealRange", 411, "Heals you in your base"), 
    UpgradeShop_Name_SpawnerMultiplier("UpgradeShop_Name_SpawnerMultiplier", 412, "Spawner Multiplier"), 
    UpgradeShop_Lore_SpawnerMultiplier("UpgradeShop_Lore_SpawnerMultiplier", 413, "Increases the spawn rate in your base"), 
    UpgradeShop_Name_EnemyMiningFatique("UpgradeShop_Name_EnemyMiningFatique", 414, "Mining Fatique"), 
    UpgradeShop_Lore_EnemyMiningFatique("UpgradeShop_Lore_EnemyMiningFatique", 415, "Decreases the mining speed for enemies entering your base"), 
    UpgradeShop_Name_EnemyTrap("UpgradeShop_Name_EnemyTrap", 416, "Trap"), 
    UpgradeShop_Lore_EnemyTrap("UpgradeShop_Lore_EnemyTrap", 417, "Gives blind and slowness effect to the next player"), 
    Achievement_get_title("Achievement_get_title", 418, "New achievement!"), 
    Achievements_name_rageQuit("Achievements_name_rageQuit", 419, "Rage quit"), 
    Achievements_name_winRound("Achievements_name_winRound", 420, "Winner"), 
    Achievements_name_loseRound("Achievements_name_loseRound", 421, "Looser"), 
    Achievements_name_ownBedDestroyed("Achievements_name_ownBedDestroyed", 422, "Unlucky"), 
    Achievements_name_bestBow("Achievements_name_bestBow", 423, "OP"), 
    Achievements_name_useRescuePlatform("Achievements_name_useRescuePlatform", 424, "That was close!"), 
    Achievements_name_useEndepearl("Achievements_name_useEndepearl", 425, "Enderman"), 
    Achievements_name_useMinishop("Achievements_name_useMinishop", 426, "Shopping Mama"), 
    Achievements_name_killSomeoneWithBow("Achievements_name_killSomeoneWithBow", 427, "Katniss"), 
    Achievements_name_winIn3Minutes("Achievements_name_winIn3Minutes", 428, "Already over?!"), 
    Achievements_name_killSomeoneWithHalfAHeart("Achievements_name_killSomeoneWithHalfAHeart", 429, "Lucky strike"), 
    Achievements_name_win100Rounds("Achievements_name_win100Rounds", 430, "Champion"), 
    Achievements_name_useBridge("Achievements_name_useBridge", 431, "Bridge constructor"), 
    Achievements_name_useGuardDog("Achievements_name_useGuardDog", 432, "Police guard"), 
    Achievements_name_effectMagnetShoes("Achievements_name_effectMagnetShoes", 433, "Magnetic force"), 
    Achievements_name_useTeleporter("Achievements_name_useTeleporter", 434, "Beam me up, scotty!"), 
    Achievements_name_useTNTSheep("Achievements_name_useTNTSheep", 435, "Boom, boom, baby!"), 
    Achievements_name_useTracker("Achievements_name_useTracker", 436, "I am going to find you. And kill you."), 
    Achievements_name_placeTrap("Achievements_name_placeTrap", 437, "Mine"), 
    Achievements_name_runOverTrap("Achievements_name_runOverTrap", 438, "IT'S A TRAP!"), 
    Achievements_name_rankingInTop3("Achievements_name_rankingInTop3", 439, "E-Sports player"), 
    Achievements_name_goodKD("Achievements_name_goodKD", 440, "Professional player"), 
    Achievements_name_highPlayTime("Achievements_name_highPlayTime", 441, "#NoLife"), 
    Achievements_name_writeGGAtEnd("Achievements_name_writeGGAtEnd", 442, "GG"), 
    Achievements_name_winWithoutBed("Achievements_name_winWithoutBed", 443, "Can't Touch This"), 
    Achievements_name_die10SecsAfterBedDestruction("Achievements_name_die10SecsAfterBedDestruction", 444, "You didn't!"), 
    Achievements_name_optainEveryAchievement("Achievements_name_optainEveryAchievement", 445, "Addicted"), 
    Achievements_text_rageQuit("Achievements_text_rageQuit", 446, "Leave a running round"), 
    Achievements_text_winRound("Achievements_text_winRound", 447, "Win at least one round"), 
    Achievements_text_loseRound("Achievements_text_loseRound", 448, "Lose one round"), 
    Achievements_text_ownBedDestroyed("Achievements_text_ownBedDestroyed", 449, "If your bed is getting destroyed"), 
    Achievements_text_bestBow("Achievements_text_bestBow", 450, "Build the best bow"), 
    Achievements_text_useRescuePlatform("Achievements_text_useRescuePlatform", 451, "Use once a rescue platform-item"), 
    Achievements_text_useEndepearl("Achievements_text_useEndepearl", 452, "Use once an enderpearl"), 
    Achievements_text_useMinishop("Achievements_text_useMinishop", 453, "Use once a minishop"), 
    Achievements_text_killSomeoneWithBow("Achievements_text_killSomeoneWithBow", 454, "Kill someone with a bow"), 
    Achievements_text_winIn3Minutes("Achievements_text_winIn3Minutes", 455, "Win a round in 3 minutes"), 
    Achievements_text_killSomeoneWithHalfAHeart("Achievements_text_killSomeoneWithHalfAHeart", 456, "Kill an enemy with half a heart"), 
    Achievements_text_win100Rounds("Achievements_text_win100Rounds", 457, "Win 100 rounds"), 
    Achievements_text_useBridge("Achievements_text_useBridge", 458, "Use once the bridge-item"), 
    Achievements_text_useGuardDog("Achievements_text_useGuardDog", 459, "Breed once the guard dog"), 
    Achievements_text_effectMagnetShoes("Achievements_text_effectMagnetShoes", 460, "When your magnet shoes defended once a knockback"), 
    Achievements_text_useTeleporter("Achievements_text_useTeleporter", 461, "Use once the teleporter item"), 
    Achievements_text_useTNTSheep("Achievements_text_useTNTSheep", 462, "Breed once a sheep with TNT on it by the tntsheep-item"), 
    Achievements_text_useTracker("Achievements_text_useTracker", 463, "Use once the tracker"), 
    Achievements_text_placeTrap("Achievements_text_placeTrap", 464, "Build once a trap"), 
    Achievements_text_runOverTrap("Achievements_text_runOverTrap", 465, "Fire a trap by running over it"), 
    Achievements_text_rankingInTop3("Achievements_text_rankingInTop3", 466, "Be in the Top 3 in the ranking"), 
    Achievements_text_goodKD("Achievements_text_goodKD", 467, "Have a K/D that's higher as 5.0"), 
    Achievements_text_highPlayTime("Achievements_text_highPlayTime", 468, "Play at least 5 hours"), 
    Achievements_text_writeGGAtEnd("Achievements_text_writeGGAtEnd", 469, "Write 'GG' at the end of a game"), 
    Achievements_text_winWithoutBed("Achievements_text_winWithoutBed", 470, "Win with your bed destroyed"), 
    Achievements_text_die10SecsAfterBedDestruction("Achievements_text_die10SecsAfterBedDestruction", 471, "Die 10 seconds after your bed has been destroyed"), 
    Achievements_text_optainEveryAchievement("Achievements_text_optainEveryAchievement", 472, "Optain every achievement");
    
    private static MessagesPack pack;
    private final String defaultEnglish;
    
    static {
        Language.pack = new MessagesPack();
    }
    
    private Language(final String name, final int ordinal, final String s) {
        this.defaultEnglish = chatColorToString(s);
    }
    
    public String getMessage() {
        return this.getMessage(null, true);
    }
    
    public String getMessage(final boolean b) {
        return this.getMessage(null, b);
    }
    
    public String getMessage(@Nullable final CommandSender commandSender) {
        return this.getMessage(commandSender, true);
    }
    
    public String getMessage(@Nullable final CommandSender commandSender, final boolean b) {
        String g = null;
        if (commandSender != null && commandSender instanceof Player) {
            g = Version.a().g((Player)commandSender);
        }
        return this.finalizeGetMessage(this.getRawMessage(g), b);
    }
    
    public String getRawMessage(@Nullable final String s) {
        return Language.pack.a(s, this);
    }
    
    private String finalizeGetMessage(@Nullable String stringToChatColor, final boolean b) {
        if (stringToChatColor == null) {
            return "";
        }
        stringToChatColor = stringToChatColor(stringToChatColor);
        if (b && ConfigValue.messages_with_prefix.contains(this)) {
            return String.valueOf(getPrefix()) + stringToChatColor;
        }
        return stringToChatColor;
    }
    
    public static String getPrefix() {
        return getPrefix(null);
    }
    
    public static String getPrefix(final CommandSender commandSender) {
        return String.valueOf(Language.Prefix.getMessage(commandSender, false)) + " ";
    }
    
    public static String chatColorToString(String replace) {
        ChatColor[] values;
        for (int length = (values = ChatColor.values()).length, i = 0; i < length; ++i) {
            final ChatColor obj = values[i];
            replace = replace.replace(new StringBuilder().append(obj).toString(), "&" + obj.getChar());
        }
        return replace;
    }
    
    public static String stringToChatColor(String replace) {
        ChatColor[] values;
        for (int length = (values = ChatColor.values()).length, i = 0; i < length; ++i) {
            final ChatColor obj = values[i];
            replace = replace.replace("&" + obj.getChar(), new StringBuilder().append(obj).toString());
        }
        return replace;
    }
    
    public static Language getLanguage(final String anotherString) {
        Language[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Language language = values[i];
            if (language.name().equalsIgnoreCase(anotherString)) {
                return language;
            }
        }
        return null;
    }
    
    public static String replaceLanguageTranslations(final String s) {
        return replaceLanguageTranslations(null, s);
    }
    
    public static String replaceLanguageTranslations(@Nullable final CommandSender commandSender, String replace) {
        Language[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Language language = values[i];
            replace = replace.replace("%" + language.name() + "%", language.getMessage(commandSender));
        }
        return replace;
    }
    
    public static List<Language> getNotChangedMessagee() {
        return new ArrayList<Language>(Arrays.asList(values()));
    }
    
    public static void sendNotFoundArenaMessage(final CommandSender commandSender, final String s) {
        s.a(commandSender, b.a(Language.NotFound_Arena).a("arena", s));
        if (de.marcely.bedwars.config.b.a(s)) {
            s.a(commandSender, b.a(Language.NotFound_Arena_Loading));
        }
    }
    
    public static MessagesPack getPack() {
        return Language.pack;
    }
    
    public String getDefaultEnglish() {
        return this.defaultEnglish;
    }
}
