// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.arena.Arena;

public class t extends j
{
    private Arena arena;
    private ItemStack a;
    
    public t(final Arena arena, final ItemStack a) {
        this.arena = arena;
        this.a = a;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public ItemStack a() {
        return this.a;
    }
    
    @Override
    public String d() {
        return String.valueOf(j.a.l.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.a.getType().name() + ":" + this.a.getDurability();
    }
}
