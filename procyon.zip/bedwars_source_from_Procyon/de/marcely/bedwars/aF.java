// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.versions.Version;
import org.bukkit.event.entity.EntityDeathEvent;

public class aF
{
    public static void a(final EntityDeathEvent entityDeathEvent) {
        if (Version.a().getVersionNumber() >= 8 && entityDeathEvent.getEntityType() == EntityType.VILLAGER && entityDeathEvent.getEntity().getVehicle() != null && entityDeathEvent.getEntity().getVehicle().getType() == EntityType.ARMOR_STAND) {
            final ArmorStand armorStand = (ArmorStand)entityDeathEvent.getEntity().getVehicle();
            if (!armorStand.isVisible()) {
                armorStand.remove();
                return;
            }
            final String customName = entityDeathEvent.getEntity().getCustomName();
            if (customName.equals(ConfigValue.dealer_title) || customName.startsWith(ConfigValue.lobbyvillager_prefix) || Team.a((CommandSender)null, customName) != null) {
                entityDeathEvent.getEntity().getVehicle().remove();
            }
        }
        if (entityDeathEvent.getEntity().getType() == EntityType.PLAYER) {
            return;
        }
        final Arena a = s.a(entityDeathEvent.getEntity().getLocation());
        if (a != null && a.b() == ArenaStatus.f) {
            entityDeathEvent.getDrops().clear();
            entityDeathEvent.setDroppedExp(0);
        }
    }
}
