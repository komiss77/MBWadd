// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class bR extends bP
{
    @Override
    protected void a(final b b) {
        this.a(b, "arena", bY.a);
        this.a(b, "players", ca.a);
        this.a(b, "maxplayers", bW.a);
        this.a(b, "teams", cb.a);
        this.a(b, "maxplayersinteam", bX.a);
        this.a(b, "countdown", bV.a);
        this.a(b, "stats:rank", cv.a);
        this.a(b, "stats:wins", cy.a);
        this.a(b, "stats:loses", cs.a);
        this.a(b, "stats:kills", cr.a);
        this.a(b, "stats:deaths", cp.a);
        this.a(b, "stats:bedsdestroyed", co.a);
        this.a(b, "stats:roundsplayed", cw.a);
        this.a(b, "stats:playtime", cu.a);
        this.a(b, "stats:kd", cq.a);
        this.a(b, "stats:wl", cx.a);
        this.a(b, "server:onlineplayers", cn.a);
        this.a(b, "ip", ci.a);
        this.a(b, "date", cc.a);
    }
}
