// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;

public abstract class dI extends dD
{
    public dI(final String str) {
        super("playerarena-" + str);
    }
    
    @Override
    public String e(final Player player) {
        final Arena a = s.a(player);
        if (a != null) {
            return this.a(player, a);
        }
        return "/";
    }
    
    protected abstract String a(final Player p0, final Arena p1);
}
