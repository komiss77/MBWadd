// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.holographic.h;
import de.marcely.bedwars.versions.Version;
import java.util.Iterator;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import de.marcely.bedwars.holographic.i;
import java.util.ArrayList;
import org.bukkit.Location;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.b;
import de.marcely.bedwars.holographic.c;
import java.util.List;
import de.marcely.bedwars.holographic.f;

public class cJ extends f<cF>
{
    private boolean S;
    private boolean T;
    private boolean U;
    private String[] lines;
    private List<c<? extends b>> aa;
    
    public cJ(final g g, final Location location) {
        super(g, location);
        this.aa = new ArrayList<c<? extends b>>();
    }
    
    @Override
    public i a() {
        return i.b;
    }
    
    @Override
    public void a(final cF cf) {
        this.S = cf.S;
        this.T = cf.T;
        this.U = cf.U;
        this.a(cf.lines);
    }
    
    @Deprecated
    @Override
    public float getHeight() {
        return 0.0f;
    }
    
    @Override
    public void teleport(final Location location) {
        this.setLocation(location);
    }
    
    @Override
    protected void setLocation(final Location location) {
        this.location = location;
        this.V();
    }
    
    @Deprecated
    @Override
    public void setCustomName(@Nullable final String s) {
    }
    
    @Deprecated
    @Override
    protected void a(final int n, final Object o) throws Exception {
    }
    
    @Override
    public void I(final Player player) {
        final Iterator<c<? extends b>> iterator = this.aa.iterator();
        while (iterator.hasNext()) {
            ((f)iterator.next().a()).I(player);
        }
    }
    
    @Override
    public void T() {
        final Iterator<Player> iterator = this.v().iterator();
        while (iterator.hasNext()) {
            this.I(iterator.next());
        }
    }
    
    public void f(final List<String> list) {
        this.a((String[])list.stream().toArray(String[]::new));
    }
    
    public void a(final String... lines) {
        if (lines == null) {
            this.lines = new String[0];
            for (final c<? extends b> c : this.aa) {
                final Iterator<Player> iterator2 = this.v().iterator();
                while (iterator2.hasNext()) {
                    ((f)c.a()).H(iterator2.next());
                }
            }
            this.aa.clear();
            return;
        }
        if (this.aa.size() == lines.length) {
            for (int i = 0; i < this.aa.size(); ++i) {
                ((f<?>)this.aa.get(i).a()).setCustomName(lines[lines.length - i - 1]);
            }
            this.T();
            return;
        }
        for (final c<? extends b> c2 : this.aa) {
            final Iterator<Player> iterator4 = this.v().iterator();
            while (iterator4.hasNext()) {
                ((f)c2.a()).H(iterator4.next());
            }
        }
        this.aa.clear();
        this.lines = lines;
        int length = 0;
        if (this.S) {
            for (final String s : lines) {
                if (s.length() > length) {
                    length = s.length();
                }
            }
        }
        for (int k = lines.length - 1; k >= 0; --k) {
            String string = lines[k];
            if (string.isEmpty()) {
                string = " ";
            }
            if (this.S) {
                for (int n = (length - string.length()) / 2, l = 0; l < n; ++l) {
                    string = " " + string + " ";
                }
            }
            if (Version.a().getVersionNumber() >= 8) {
                final cE ce = new cE();
                ce.name = string;
                ce.b = true;
                final cE ce2 = ce;
                final cE ce3 = ce;
                final Boolean value = this.U;
                ce3.f = value;
                ce2.d = value;
                final c<cI> a = c.a(cI.class, this.location.clone(), ce);
                a.a().b(this.a());
                this.aa.add(a);
                final Iterator<Player> iterator5 = this.v().iterator();
                while (iterator5.hasNext()) {
                    a.a().G(iterator5.next());
                }
            }
            this.V();
        }
    }
    
    private void V() {
        for (int i = this.aa.size() - 1; i >= 0; --i) {
            final c<? extends b> c = this.aa.get(i);
            Location location;
            if (this.U) {
                location = this.location.clone().add(0.0, i * 0.21 - (this.T ? 0.9875 : 0.0) + 1.1805, 0.0);
            }
            else {
                location = this.location.clone().add(0.0, i * 0.21 - (this.T ? 1.975 : 0.0), 0.0);
            }
            ((f)c.a()).teleport(location);
        }
    }
    
    @Override
    protected void D(final Player player) {
        final Iterator<c<? extends b>> iterator = this.aa.iterator();
        while (iterator.hasNext()) {
            ((f)iterator.next().a()).G(player);
        }
    }
    
    @Override
    protected void E(final Player player) {
        final Iterator<c<? extends b>> iterator = this.aa.iterator();
        while (iterator.hasNext()) {
            ((f)iterator.next().a()).H(player);
        }
    }
    
    @Override
    public void F(final Player player) {
        final Iterator<c<? extends b>> iterator = this.aa.iterator();
        while (iterator.hasNext()) {
            ((f)iterator.next().a()).F(player);
        }
    }
    
    public boolean M() {
        return this.S;
    }
    
    public boolean N() {
        return this.T;
    }
    
    public boolean isSmall() {
        return this.U;
    }
    
    public String[] getLines() {
        return this.lines;
    }
    
    public List<c<? extends b>> x() {
        return this.aa;
    }
}
