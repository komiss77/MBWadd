// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public enum cD
{
    b("LEAVE", 0), 
    c("ARENA_STOP", 1), 
    d("TELEPORT_OUT_OF_ARENA", 2), 
    e("KICK", 3), 
    f("CHANGE_ARENA", 4), 
    g("DEATH_RESPAWN", 5), 
    h("CUSTOM", 6);
    
    static {
        a = new cD[] { cD.b, cD.c, cD.d, cD.e, cD.f, cD.g, cD.h };
    }
    
    private cD(final String name, final int ordinal) {
    }
}
