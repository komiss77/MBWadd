// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.SpectateReason;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class cz
{
    private final Player player;
    private final Arena arena;
    private final SpectateReason a;
    private final long j;
    
    public cz(final Player player, final Arena arena, final SpectateReason a) {
        this.player = player;
        this.arena = arena;
        this.a = a;
        this.j = System.currentTimeMillis();
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public SpectateReason a() {
        return this.a;
    }
    
    public long a() {
        return this.j;
    }
}
