// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import de.marcely.bedwars.util.s;
import java.util.Date;
import me.jumper251.replay.api.ReplayAPI;
import org.bukkit.event.EventHandler;
import de.marcely.bedwars.api.ArenaStatus;
import de.marcely.bedwars.api.event.ArenaStatusUpdateEvent;
import java.util.Iterator;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.util.HashMap;
import me.jumper251.replay.replaysystem.Replay;
import de.marcely.bedwars.game.arena.Arena;
import java.util.Map;
import org.bukkit.event.Listener;

public class cO extends cR implements Listener
{
    private final Map<Arena, Replay> I;
    
    public cO() {
        this.I = new HashMap<Arena, Replay>();
    }
    
    @Override
    public cT a() {
        return cT.x;
    }
    
    @Override
    public void onEnable() {
        Bukkit.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }
    
    @Override
    public void onDisable() {
        HandlerList.unregisterAll((Listener)this);
        for (final Replay replay : this.I.values()) {
            if (replay.isRecording()) {
                replay.getRecorder().stop(true);
            }
        }
        this.I.clear();
    }
    
    @EventHandler
    public void a(final ArenaStatusUpdateEvent arenaStatusUpdateEvent) {
        final Arena arena = (Arena)arenaStatusUpdateEvent.getArena();
        this.e(arena);
        if (arenaStatusUpdateEvent.getStatus() == ArenaStatus.Running) {
            this.d(arena);
        }
    }
    
    private void d(final Arena arena) {
        this.I.put(arena, ReplayAPI.getInstance().recordReplay("MBW: " + arena.getName() + " [" + s.a(new Date(), "MM.dd.yyyy hh:mm") + "]", (CommandSender)null, (Player[])arena.getPlayers().stream().toArray(Player[]::new)));
    }
    
    private void e(final Arena arena) {
        final Replay replay = this.I.get(arena);
        if (replay == null) {
            return;
        }
        if (replay.isRecording()) {
            replay.getRecorder().stop(true);
        }
        this.I.remove(arena);
    }
}
