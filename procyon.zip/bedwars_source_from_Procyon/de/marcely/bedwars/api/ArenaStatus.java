// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

public enum ArenaStatus
{
    Stopped("Stopped", 0, de.marcely.bedwars.game.arena.ArenaStatus.d), 
    Lobby("Lobby", 1, de.marcely.bedwars.game.arena.ArenaStatus.e), 
    Running("Running", 2, de.marcely.bedwars.game.arena.ArenaStatus.f), 
    Reseting("Reseting", 3, de.marcely.bedwars.game.arena.ArenaStatus.g), 
    EndLobby("EndLobby", 4, de.marcely.bedwars.game.arena.ArenaStatus.h);
    
    private final de.marcely.bedwars.game.arena.ArenaStatus nms;
    
    private ArenaStatus(final String name, final int ordinal, final de.marcely.bedwars.game.arena.ArenaStatus nms) {
        this.nms = nms;
    }
    
    public static ArenaStatus fromNMS(final de.marcely.bedwars.game.arena.ArenaStatus arenaStatus) {
        ArenaStatus[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final ArenaStatus arenaStatus2 = values[i];
            if (arenaStatus2.nms == arenaStatus) {
                return arenaStatus2;
            }
        }
        return null;
    }
    
    public de.marcely.bedwars.game.arena.ArenaStatus getNms() {
        return this.nms;
    }
}
