// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import org.bukkit.entity.EntityType;
import java.util.List;
import org.bukkit.inventory.ItemStack;

public class ExtraItem
{
    private final String name;
    private ItemStack is;
    private final List<ExtraItemListener> listeners;
    
    public ExtraItem(final String s, final ItemStack itemStack) {
        this(s, itemStack, null);
    }
    
    @Deprecated
    public ExtraItem(final String name, final ItemStack is, final EntityType entityType) {
        this.listeners = new ArrayList<ExtraItemListener>(4);
        this.name = name;
        if (entityType != null) {
            this.is = Version.a().a(is, entityType);
        }
        else {
            this.is = is;
        }
    }
    
    public void setItemStack(final ItemStack is) {
        this.is = is;
    }
    
    public String getName() {
        return this.name;
    }
    
    public ItemStack getItemStack() {
        return this.is.clone();
    }
    
    public ItemStack getItemStack(final int amount) {
        final ItemStack is = this.is;
        is.setAmount(amount);
        return is;
    }
    
    public void registerListener(final ExtraItemListener extraItemListener) {
        this.listeners.add(extraItemListener);
    }
    
    public boolean unregisterListener(final ExtraItemListener extraItemListener) {
        return this.listeners.remove(extraItemListener);
    }
    
    public List<ExtraItemListener> getListeners() {
        return this.listeners;
    }
}
