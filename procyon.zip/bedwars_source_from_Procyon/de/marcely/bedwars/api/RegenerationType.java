// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

public enum RegenerationType
{
    Region("Region", 0, de.marcely.bedwars.game.arena.RegenerationType.c), 
    World("World", 1, de.marcely.bedwars.game.arena.RegenerationType.d), 
    MapVote("MapVote", 2, de.marcely.bedwars.game.arena.RegenerationType.e);
    
    private final de.marcely.bedwars.game.arena.RegenerationType nms;
    
    private RegenerationType(final String name, final int ordinal, final de.marcely.bedwars.game.arena.RegenerationType nms) {
        this.nms = nms;
    }
    
    public boolean isNormal() {
        return this.nms.J();
    }
    
    public static RegenerationType fromNMS(final de.marcely.bedwars.game.arena.RegenerationType regenerationType) {
        RegenerationType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final RegenerationType regenerationType2 = values[i];
            if (regenerationType2.nms == regenerationType) {
                return regenerationType2;
            }
        }
        return null;
    }
    
    public de.marcely.bedwars.game.arena.RegenerationType getNms() {
        return this.nms;
    }
}
