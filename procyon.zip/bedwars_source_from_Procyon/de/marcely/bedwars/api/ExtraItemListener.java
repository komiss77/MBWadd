// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.api.event.ShopBuyEvent;

public interface ExtraItemListener
{
    void onShopBuy(final ShopBuyEvent p0);
    
    void onUse(final PlayerUseExtraItemEvent p0);
}
