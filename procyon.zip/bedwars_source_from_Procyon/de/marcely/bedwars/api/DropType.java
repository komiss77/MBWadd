// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import org.bukkit.Effect;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import javax.annotation.Nullable;
import org.bukkit.inventory.ItemStack;

public interface DropType
{
    void setName(final String p0);
    
    void setConfigItemstack(final ItemStack p0);
    
    void setCustomSpawner(@Nullable final Spawner p0);
    
    void setSpawnDelay(final double p0);
    
    void setSpawnRadius(final int p0);
    
    void setSound(@Nullable final Sound p0);
    
    void setTranquil(final boolean p0);
    
    void setMerging(final boolean p0);
    
    void setHologram(@Nullable final Material p0);
    
    void setChatColor(@Nullable final ChatColor p0);
    
    @Deprecated
    void setEffect(@Nullable final Effect p0);
    
    void setVarParticle(@Nullable final VarParticle p0);
    
    String getName();
    
    @Nullable
    ItemStack getActualItemstack();
    
    @Nullable
    ItemStack getConfigItemstack();
    
    @Nullable
    Spawner getCustomSpawner();
    
    double getSpawnDelay();
    
    int getSpawnRadius();
    
    @Nullable
    Sound getSound();
    
    boolean isTranquil();
    
    boolean isMerging();
    
    @Nullable
    Material getHologram();
    
    @Nullable
    ChatColor getChatColor();
    
    @Deprecated
    @Nullable
    Effect getEffect();
    
    VarParticle getVarParticle();
    
    boolean isDisabledForRound();
    
    void setDisabledForRound(final boolean p0);
}
