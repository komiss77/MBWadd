// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.ee;
import de.marcely.bedwars.eg;
import de.marcely.bedwars.sql.SQLConnection;
import java.util.Collection;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import de.marcely.bedwars.MBedwars;
import de.marcely.bedwars.aD;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.config.m;
import de.marcely.bedwars.game.shop.ShopDesignData;
import de.marcely.bedwars.game.shop.ShopDesign;
import de.marcely.bedwars.config.Config;
import de.marcely.bedwars.game.stats.StatsSign;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.cD;
import de.marcely.bedwars.cA;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.util.FutureResult;
import java.util.concurrent.Future;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import de.marcely.bedwars.game.stats.c;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import java.util.Iterator;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import javax.annotation.Nullable;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import java.util.List;

public class BedwarsAPI
{
    private static final APIConfiguration apiConfig;
    private static final List<String> registredCommands;
    private static final EntityAPI entityAPI;
    private static final ArenaPickerAPI arenaPickerAPI;
    
    static {
        apiConfig = new APIConfiguration();
        registredCommands = new ArrayList<String>();
        entityAPI = new EntityAPI();
        arenaPickerAPI = new ArenaPickerAPI();
    }
    
    @Nullable
    public static Arena getArena(final String s) {
        return s.b(s);
    }
    
    @Nullable
    public static Arena getArena(final Player player) {
        return s.a(player);
    }
    
    @Nullable
    public static Arena getArena(final Location location) {
        return s.a(location);
    }
    
    public static List<Arena> getArenas() {
        final ArrayList<de.marcely.bedwars.game.arena.Arena> list = (ArrayList<de.marcely.bedwars.game.arena.Arena>)new ArrayList<Arena>();
        final Iterator<de.marcely.bedwars.game.arena.Arena> iterator = s.af.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }
        return (List<Arena>)list;
    }
    
    public static List<Arena> getArenas(final Location location) {
        final ArrayList<de.marcely.bedwars.game.arena.Arena> list = (ArrayList<de.marcely.bedwars.game.arena.Arena>)new ArrayList<Arena>();
        final Iterator<de.marcely.bedwars.game.arena.Arena> iterator = s.getArenas(location).iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }
        return (List<Arena>)list;
    }
    
    @Nullable
    public static Arena createArena(final String name, final World world, final RegenerationType regenerationType, @Nullable String s) {
        if (s.b(name) != null) {
            return null;
        }
        if (name == null) {
            new NullPointerException("Name is null").printStackTrace();
        }
        if (world == null) {
            new NullPointerException("World is null").printStackTrace();
        }
        if (regenerationType == null) {
            new NullPointerException("RegenerationType is null").printStackTrace();
        }
        if (s == null) {
            s = "";
        }
        final de.marcely.bedwars.game.arena.Arena arena = new de.marcely.bedwars.game.arena.Arena();
        arena.setName(name);
        arena.setWorld(world);
        arena.a(regenerationType.getNms());
        arena.v(s);
        return arena;
    }
    
    @Deprecated
    @Nullable
    public static AddPlayerFail addPlayerToArena(final Player player, final Arena arena) {
        return addPlayerToArena(player, arena, null);
    }
    
    @Deprecated
    @Nullable
    public static AddPlayerFail addPlayerToArena(final Player player, final Arena arena, final Team team) {
        return arena.addPlayer(player, team);
    }
    
    @Deprecated
    public static boolean kickPlayerFromArena(final Player player, final Arena arena) {
        return kickPlayerFromArena(KickReason.Kick, player, arena);
    }
    
    @Deprecated
    public static boolean kickPlayerFromArena(final KickReason kickReason, final Player player, final Arena arena) {
        return arena.kickPlayer(player, kickReason);
    }
    
    @Nullable
    public static StatsAPI getPlayerStatsNow(final OfflinePlayer offlinePlayer) {
        try {
            if (!offlinePlayer.isOnline()) {
                return c.a(offlinePlayer.getName(), offlinePlayer.getUniqueId()).get();
            }
            return (StatsAPI)c.a((Player)offlinePlayer);
        }
        catch (InterruptedException | ExecutionException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    @Deprecated
    @Nullable
    public static StatsAPI getPlayerStatsNow(final UUID uuid) {
        try {
            return c.a(uuid).get();
        }
        catch (InterruptedException | ExecutionException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    public static Future<StatsAPI> getPlayerStats(final UUID uuid) {
        final Future<c> a = c.a(uuid);
        final FutureResult<StatsAPI> futureResult = new FutureResult<StatsAPI>();
        s.a((Future<Object>)a, new Runnable() {
            @Override
            public void run() {
                try {
                    futureResult.a(a.get());
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Object o2;
                    final Object o = o2;
                    futureResult.die();
                    ((Throwable)o).printStackTrace();
                }
            }
        });
        return futureResult;
    }
    
    @Deprecated
    public static StatsAPI getPlayerStats(final OfflinePlayer offlinePlayer) {
        return getPlayerStatsNow(offlinePlayer);
    }
    
    public static AchievementsAPI getPlayerAchievementsNow(final Player player) {
        return getPlayerAchievementsNow(player.getUniqueId());
    }
    
    @Nullable
    public static AchievementsAPI getPlayerAchievementsNow(final UUID uuid) {
        try {
            return UserAchievements.a(uuid).get();
        }
        catch (InterruptedException | ExecutionException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    public static Future<AchievementsAPI> getPlayerAchievements(final Player player) {
        return getPlayerAchievements(player.getUniqueId());
    }
    
    public static Future<AchievementsAPI> getPlayerAchievements(final UUID uuid) {
        final Future<UserAchievements> a = UserAchievements.a(uuid);
        final FutureResult<Object> futureResult = (FutureResult<Object>)new FutureResult<AchievementsAPI>();
        s.a(futureResult, new Runnable() {
            @Override
            public void run() {
                try {
                    futureResult.a(a.get());
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Object o2;
                    final Object o = o2;
                    futureResult.die();
                    ((Throwable)o).printStackTrace();
                }
            }
        });
        return (Future<AchievementsAPI>)futureResult;
    }
    
    @Deprecated
    public static boolean enterSpectatorMode(final Player player, final Arena arena) {
        return cA.a(player, (de.marcely.bedwars.game.arena.Arena)arena, SpectateReason.PLUGIN);
    }
    
    public static boolean enterSpectatorMode(final Player player, final Arena arena, final SpectateReason spectateReason) {
        return cA.a(player, (de.marcely.bedwars.game.arena.Arena)arena, spectateReason);
    }
    
    @Deprecated
    public static boolean kickFromSpectatorMode(final Player player) {
        return cA.a(player, cD.h);
    }
    
    @Deprecated
    public static List<RankingStatueAPI> getStatues(final int n) {
        final ArrayList<RankingStatueAPI> list = new ArrayList<RankingStatueAPI>(8);
        final Iterator<RankingStatueAPI> statuesIterator = getStatuesIterator(n);
        while (statuesIterator.hasNext()) {
            list.add(statuesIterator.next());
        }
        return list;
    }
    
    public static Iterator<RankingStatueAPI> getStatuesIterator(final int n) {
        return new Iterator<RankingStatueAPI>(n) {
            final Iterator<RankingStatue> parent = s.a(n);
            
            @Override
            public boolean hasNext() {
                return this.parent.hasNext();
            }
            
            @Override
            public RankingStatueAPI next() {
                return this.parent.next();
            }
        };
    }
    
    public static Iterator<StatsSignAPI> getStatsSignsIterator(final int n) {
        return new Iterator<StatsSignAPI>(n) {
            final Iterator<StatsSign> parent = s.b(n);
            
            @Override
            public boolean hasNext() {
                return this.parent.hasNext();
            }
            
            @Override
            public StatsSignAPI next() {
                return this.parent.next();
            }
        };
    }
    
    public static List<RankingStatueAPI> getStatues() {
        final ArrayList<RankingStatue> list = (ArrayList<RankingStatue>)new ArrayList<RankingStatueAPI>();
        final Iterator<RankingStatue> iterator = s.ad.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }
        return (List<RankingStatueAPI>)list;
    }
    
    public static void updateRanking() {
        s.updateRanking();
    }
    
    public static void reloadConfig() {
        reloadConfig(true);
    }
    
    public static void reloadConfig(final boolean b) {
        if (b) {
            for (final Arena arena : getArenas()) {
                if (arena.GetStatus() == ArenaStatus.Running) {
                    arena.kickAllPlayers();
                }
            }
        }
        Config.load();
    }
    
    public static boolean registerExtraItem(final ExtraItem extraItem) {
        return s.ak.add(extraItem);
    }
    
    public static boolean unregisterExtraItem(final ExtraItem extraItem) {
        return s.ak.remove(extraItem);
    }
    
    public static boolean registerSpawner(final Spawner spawner) {
        return s.al.add(spawner);
    }
    
    public static boolean unregisterSpawner(final Spawner spawner) {
        return s.al.remove(spawner);
    }
    
    public static boolean registerLobbyItem(final CustomLobbyItem customLobbyItem) {
        return s.am.add(customLobbyItem);
    }
    
    public static boolean unregisterLobbyItem(final CustomLobbyItem customLobbyItem) {
        return s.am.remove(customLobbyItem);
    }
    
    public static ShopDesignData createCustomShopDesignInstance(final ShopDesign shopDesign, final String s) {
        return new ShopDesignData(shopDesign, s);
    }
    
    public static List<ShopDesignData> getShopDesigns() {
        return ShopDesignData.getDesigns();
    }
    
    public static ShopDesignData getShopDesign(final String s) {
        return ShopDesignData.getDesignByName(s);
    }
    
    public static ShopDesignData getShopDesign() {
        return m.a;
    }
    
    @Nullable
    public static LobbyItem getLobbyItem(final String s) {
        return s.a(s);
    }
    
    @Nullable
    public static LobbyItem getLobbyItem(final int n) {
        return s.a(n);
    }
    
    @Nullable
    public static DropType getDropType(final String s) {
        return de.marcely.bedwars.game.DropType.a(s);
    }
    
    @Nullable
    public static DropType getDropType(final ItemStack itemStack) {
        return de.marcely.bedwars.game.DropType.a(itemStack);
    }
    
    public static List<DropType> getDropTypes() {
        final ArrayList<de.marcely.bedwars.game.DropType> list = (ArrayList<de.marcely.bedwars.game.DropType>)new ArrayList<DropType>();
        final Iterator<de.marcely.bedwars.game.DropType> iterator = de.marcely.bedwars.game.DropType.values().iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }
        return (List<DropType>)list;
    }
    
    @Nullable
    public static Player getLastDamager(final Player player) {
        final aD.a a = aD.f.get(player);
        return (a != null) ? a.damager : null;
    }
    
    public static boolean registerMBedwarsCommand(final String s) {
        if (MBedwars.a.getCommand(s) == null && !BedwarsAPI.registredCommands.contains(s)) {
            return false;
        }
        MBedwars.a.getCommand(s).setExecutor((CommandExecutor)MBedwars.a);
        BedwarsAPI.registredCommands.add(s);
        return true;
    }
    
    public static boolean unregisterMBedwarsCommand(final String s) {
        if (MBedwars.a.getCommand(s) == null || !MBedwars.a.getCommand(s).getExecutor().equals(MBedwars.a)) {
            return false;
        }
        MBedwars.a.getCommand(s).setExecutor((CommandExecutor)new CommandExecutor() {
            public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
                return false;
            }
        });
        BedwarsAPI.registredCommands.remove(s);
        return true;
    }
    
    public static List<String> getMBedwarsCommands() {
        return new ArrayList<String>(BedwarsAPI.registredCommands);
    }
    
    public static boolean isSQLConnected() {
        return s.isSQLConnected();
    }
    
    @Nullable
    public static SQLConnection getSQLConnection() {
        return (s.b != null && s.b.a() == eg.c) ? ((ee)s.b).b : null;
    }
    
    public static void addSQLConnectionListener(final SQLUpdateListener sqlUpdateListener) {
        s.an.add(sqlUpdateListener);
    }
    
    public static boolean removeSQLConnectionListener(final SQLUpdateListener sqlUpdateListener) {
        return s.an.remove(sqlUpdateListener);
    }
    
    public static void addConfigsLoadStartListener(final Runnable runnable) {
        s.ap.add(runnable);
    }
    
    public static boolean removeConfigsLoadStartListener(final Runnable runnable) {
        return s.ap.add(runnable);
    }
    
    public static void addConfigsLoadEndListener(final Runnable runnable) {
        s.ao.add(runnable);
    }
    
    public static boolean removeConfigsLoadEndListener(final Runnable runnable) {
        return s.ao.add(runnable);
    }
    
    public static Version getVersionManager() {
        return Version.a().a();
    }
    
    public static AddonManagerAPI getAddonManager() {
        return MBedwars.a;
    }
    
    @Deprecated
    public static CommandHandler getCommandHandler() {
        return MBedwars.a;
    }
    
    @Deprecated
    public static APIConfiguration getOpenAPIConfiguration() {
        return BedwarsAPI.apiConfig;
    }
    
    public static PluginState getPluginState() {
        return PluginState.fromInternal();
    }
    
    public static EntityAPI getEntityAPI() {
        return BedwarsAPI.entityAPI;
    }
    
    public static ArenaPickerAPI getArenaPickerAPI() {
        return BedwarsAPI.arenaPickerAPI;
    }
}
