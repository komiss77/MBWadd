// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.api.arena.picker.ArenaPickerExecutor;
import javax.annotation.Nullable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.arena.picker.ArenaConditionVariable;

public class ArenaPickerAPI
{
    public boolean registerConditionVariable(final ArenaConditionVariable<?> arenaConditionVariable) {
        if (s.aa.containsKey(arenaConditionVariable.getName())) {
            return false;
        }
        s.aa.put(arenaConditionVariable.getName(), arenaConditionVariable);
        return true;
    }
    
    @Nullable
    public ArenaConditionVariable<?> unregisterConditionVariable(final String s) {
        return s.aa.remove(s);
    }
    
    public boolean registerPickerExecutor(final String s, final ArenaPickerExecutor arenaPickerExecutor) {
        if (s.ab.containsKey(s)) {
            return false;
        }
        s.ab.put(s, arenaPickerExecutor);
        return true;
    }
    
    @Nullable
    public ArenaPickerExecutor unregisterPickerExecutor(final String s) {
        return s.ab.remove(s);
    }
}
