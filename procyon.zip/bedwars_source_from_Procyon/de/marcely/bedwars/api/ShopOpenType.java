// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

public enum ShopOpenType
{
    MINISHOP("MINISHOP", 0), 
    VILLAGER("VILLAGER", 1), 
    DEBUG("DEBUG", 2), 
    CUSTOM("CUSTOM", 3), 
    UNKOWN("UNKOWN", 4);
    
    private ShopOpenType(final String name, final int ordinal) {
    }
}
