// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.util.b;
import org.bukkit.entity.Entity;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import de.marcely.bedwars.versions.Version;
import org.bukkit.inventory.ItemStack;

public class VersionAPI
{
    public static ItemStack removeAttributes(final ItemStack itemStack) {
        return Version.a().removeAttributes(itemStack);
    }
    
    public static ItemStack addGlow(final ItemStack itemStack) {
        return Version.a().addGlow(itemStack);
    }
    
    public static void showSmallTitle(final Player player, final String s) {
        Version.a().b(s, player);
    }
    
    public static void showSmallTitle(final Player player, final String s, final int n) {
        Version.a().a(s, player, n);
    }
    
    public static void showBigTitle(final Player player, final String s) {
        Version.a().c(s, player);
    }
    
    public static void showBigTitle(final Player player, final String s, final int n) {
        Version.a().b(s, player, n);
    }
    
    public static void showTitle(final Player player, final String s, final String s2) {
        Version.a().a(s, s2, player);
    }
    
    public static void showTitle(final Player player, final String s, final String s2, final int n) {
        Version.a().a(s, s2, player, n);
    }
    
    public static List<Entity> getNearbyEntities(final Location location, final double n, final double n2, final double n3) {
        return b.getNearbyEntities(location, n, n2, n3);
    }
    
    public static List<Player> getNearbyPlayers(final Location location, final int n, final int n2) {
        return b.a(location, n, n2);
    }
}
