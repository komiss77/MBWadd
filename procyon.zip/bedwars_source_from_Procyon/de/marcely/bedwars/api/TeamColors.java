// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.game.location.XYZYP;
import javax.annotation.Nullable;
import de.marcely.bedwars.game.location.XYZD;
import java.util.List;

public interface TeamColors
{
    Arena getArena();
    
    List<Team> GetEnabledTeams();
    
    void setTeamEnabled(final Team p0, final boolean p1);
    
    boolean isTeamEnabled(final Team p0);
    
    @Nullable
    XYZD getBedLocation(final Team p0);
    
    void setBedLocation(final Team p0, final XYZD p1);
    
    @Nullable
    XYZYP getSpawnLocation(final Team p0);
    
    void setSpawnLocation(final Team p0, final XYZYP p1);
    
    boolean isBedDestroyed(final Team p0);
    
    void _0setBedDestroyed(final Team p0, final boolean p1);
    
    void _0reset();
}
