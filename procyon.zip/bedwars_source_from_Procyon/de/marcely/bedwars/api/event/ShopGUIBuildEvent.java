// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.event;

import javax.annotation.Nullable;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.game.shop.ShopDesign;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Event;

public class ShopGUIBuildEvent extends Event
{
    private static final HandlerList HANDLERS;
    private final Player player;
    private final ShopDesign design;
    private SimpleGUI gui;
    
    static {
        HANDLERS = new HandlerList();
    }
    
    public ShopGUIBuildEvent(final Player player, final ShopDesign design, @Nullable final SimpleGUI gui) {
        this.player = player;
        this.design = design;
        this.gui = gui;
    }
    
    public void setGUI(@Nullable final SimpleGUI gui) {
        this.gui = gui;
    }
    
    @Nullable
    public SimpleGUI getGUI() {
        return this.gui;
    }
    
    public HandlerList getHandlers() {
        return ShopGUIBuildEvent.HANDLERS;
    }
    
    public static HandlerList getHandlerList() {
        return ShopGUIBuildEvent.HANDLERS;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public ShopDesign getDesign() {
        return this.design;
    }
}
