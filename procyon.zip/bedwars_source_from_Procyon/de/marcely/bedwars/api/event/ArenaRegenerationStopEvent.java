// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.event;

import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.api.Arena;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Event;

public class ArenaRegenerationStopEvent extends Event
{
    private static final HandlerList HANDLERS;
    private Arena arena;
    private CommandSender sender;
    
    static {
        HANDLERS = new HandlerList();
    }
    
    public ArenaRegenerationStopEvent(final Arena arena, final CommandSender commandSender) {
        this.arena = arena;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    @Nullable
    public CommandSender getSender() {
        return this.sender;
    }
    
    public HandlerList getHandlers() {
        return ArenaRegenerationStopEvent.HANDLERS;
    }
    
    public static HandlerList getHandlerList() {
        return ArenaRegenerationStopEvent.HANDLERS;
    }
}
