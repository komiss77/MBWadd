// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.event;

import de.marcely.bedwars.game.shop.ShopDesignData;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public class PlayerOpenShopEvent extends Event implements Cancellable
{
    private static final HandlerList HANDLERS;
    private final Player player;
    private ShopDesignData design;
    private boolean cancel;
    
    static {
        HANDLERS = new HandlerList();
    }
    
    public PlayerOpenShopEvent(final Player player, final ShopDesignData design) {
        this.cancel = false;
        this.player = player;
        this.design = design;
    }
    
    public void setDesign(final ShopDesignData design) {
        this.design = design;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public ShopDesignData getDesign() {
        return this.design;
    }
    
    public boolean isCancelled() {
        return this.cancel;
    }
    
    public void setCancelled(final boolean cancel) {
        this.cancel = cancel;
    }
    
    public HandlerList getHandlers() {
        return PlayerOpenShopEvent.HANDLERS;
    }
    
    public static HandlerList getHandlerList() {
        return PlayerOpenShopEvent.HANDLERS;
    }
}
