// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import java.io.File;
import java.util.List;
import javax.annotation.Nullable;
import org.bukkit.plugin.Plugin;

public interface AddonManagerAPI
{
    void setAddonState(final Plugin p0, final boolean p1);
    
    @Nullable
    Boolean getAddonState(final Plugin p0);
    
    List<Plugin> getEnabledAddons();
    
    List<Plugin> getDisabledAddons();
    
    int getAddonID(final Plugin p0);
    
    Plugin getAddonByName(final String p0);
    
    Plugin getAddonByID(final int p0);
    
    int research();
    
    void recheck();
    
    File[] getSearchDirectories();
}
