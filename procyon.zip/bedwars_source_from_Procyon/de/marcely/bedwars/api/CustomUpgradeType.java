// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.game.shop.upgrade.UpgradeType;

public class CustomUpgradeType extends UpgradeType
{
    public CustomUpgradeType(final String s) {
        super(s, false);
    }
}
