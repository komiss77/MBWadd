// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.MBedwars;

public enum PluginState
{
    Enabling("Enabling", 0, true), 
    Running("Running", 1, true), 
    StartFailed("StartFailed", 2, false), 
    Disabling("Disabling", 3, false), 
    Disabled("Disabled", 4, false);
    
    private boolean taskable;
    
    private PluginState(final String name, final int ordinal, final boolean taskable) {
        this.taskable = taskable;
    }
    
    public MBedwars.PluginState getInternal() {
        MBedwars.PluginState[] values;
        for (int length = (values = MBedwars.PluginState.values()).length, i = 0; i < length; ++i) {
            final MBedwars.PluginState pluginState = values[i];
            if (pluginState.a() == this) {
                return pluginState;
            }
        }
        return null;
    }
    
    public static PluginState fromInternal() {
        PluginState[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final PluginState pluginState = values[i];
            if (MBedwars.a().a() == pluginState) {
                return pluginState;
            }
        }
        return null;
    }
    
    public boolean isTaskable() {
        return this.taskable;
    }
}
