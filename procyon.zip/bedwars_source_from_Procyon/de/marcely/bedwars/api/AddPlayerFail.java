// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import javax.annotation.Nullable;
import de.marcely.bedwars.game.arena.Arena;

public enum AddPlayerFail
{
    Full("Full", 0, Arena.AddPlayerFail.a), 
    AlreadyInside("AlreadyInside", 1, Arena.AddPlayerFail.b), 
    OnlyVoteArenas("OnlyVoteArenas", 2, Arena.AddPlayerFail.c), 
    OnlyNormalArenas("OnlyNormalArenas", 3, Arena.AddPlayerFail.d), 
    Plugin("Plugin", 4, Arena.AddPlayerFail.e);
    
    private final Arena.AddPlayerFail internal;
    
    private AddPlayerFail(final String name, final int ordinal, final Arena.AddPlayerFail internal) {
        this.internal = internal;
    }
    
    @Nullable
    public static AddPlayerFail fromInternal(final Arena.AddPlayerFail addPlayerFail) {
        AddPlayerFail[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final AddPlayerFail addPlayerFail2 = values[i];
            if (addPlayerFail2.internal == addPlayerFail) {
                return addPlayerFail2;
            }
        }
        return null;
    }
    
    public Arena.AddPlayerFail getInternal() {
        return this.internal;
    }
}
