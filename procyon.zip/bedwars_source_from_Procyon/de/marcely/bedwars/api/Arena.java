// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.Sound;
import java.util.HashMap;
import org.bukkit.entity.Player;
import java.util.List;
import org.bukkit.inventory.ItemStack;
import javax.annotation.Nullable;
import org.bukkit.Location;
import org.bukkit.World;
import de.marcely.bedwars.game.location.XYZ;

public interface Arena
{
    void addItemSpawner(final DropType p0, final XYZ p1);
    
    void setWorld(final World p0);
    
    void setStatus(final ArenaStatus p0);
    
    void setStatus(final ArenaStatus p0, final boolean p1);
    
    void setName(final String p0);
    
    void setLobby(final Location p0);
    
    void setAuthor(final String p0);
    
    void setTeamPlayers(final int p0);
    
    void setMinPlayers(final int p0);
    
    @Nullable
    World getWorld();
    
    XYZ getPosMin();
    
    XYZ getPosMax();
    
    int getPerTeamPlayers();
    
    @Nullable
    Location getLobby();
    
    boolean hasLobby();
    
    @Nullable
    ItemStack getIcon();
    
    TeamColors GetTeamColors();
    
    List<Player> getPlayers();
    
    List<Player> getSpectators();
    
    @Nullable
    Team GetPlayerTeam(final Player p0);
    
    int getTeamPlayers();
    
    ArenaStatus GetStatus();
    
    RegenerationType GetRegenerationType();
    
    HashMap<XYZ, DropType> getItemSpawners();
    
    String getAuthor();
    
    int getMinPlayers();
    
    boolean hasCustomName();
    
    String getCustomName();
    
    String getDisplayName();
    
    String getName();
    
    void setHasCustomName(final boolean p0);
    
    void setCustomName(final String p0);
    
    boolean isCurrentlyRegenerating();
    
    @Nullable
    AddPlayerFail addPlayer(final Player p0);
    
    @Nullable
    AddPlayerFail addPlayer(final Player p0, @Nullable final Team p1);
    
    boolean kickPlayer(final Player p0);
    
    boolean kickPlayer(final Player p0, final KickReason p1);
    
    void kickAllPlayers();
    
    void kickAllPlayers(final KickReason p0);
    
    void broadcast(final String p0);
    
    void broadcast(final Sound p0);
    
    long getGameStartTime();
    
    boolean isInside(final Location p0);
    
    void save();
    
    void saveBlocks();
    
    long getRunningTime();
    
    int getMaxPlayers();
    
    boolean isSleeping();
    
    List<Player> getPlayersInTeam(final Team p0);
    
    List<Team> getRemainingTeams();
    
    void teleportHere(final Player p0);
    
    void _0destroyBed(final Player p0, final Location p1, final Team p2);
    
    void _0end(final Team p0);
    
    void _0setIngameScoreboard(final Player p0);
    
    void _0setLobbyScoreboard(final Player p0);
    
    boolean _0remove();
}
