// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import java.util.UUID;
import javax.annotation.Nullable;
import org.bukkit.Location;

public interface StatsSignAPI
{
    int getPlace();
    
    @Nullable
    Location getLocation();
    
    @Nullable
    UUID getCurrentHolderUUID();
    
    @Nullable
    String getCurrentHolderName();
    
    boolean exists();
    
    boolean remove();
    
    boolean remove(final boolean p0);
}
