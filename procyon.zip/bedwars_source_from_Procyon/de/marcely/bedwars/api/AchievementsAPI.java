// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.achievements.Achievement;
import java.util.UUID;

public interface AchievementsAPI
{
    UUID getUUID();
    
    boolean has(final Achievement p0);
    
    void set(final Achievement p0, final boolean p1);
}
