// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import org.bukkit.command.CommandSender;
import java.util.Iterator;
import de.marcely.bedwars.MBedwars;
import java.util.ArrayList;
import de.marcely.configmanager2.ConfigManager;
import java.util.List;
import org.bukkit.plugin.Plugin;

public class BedwarsAddon
{
    private Plugin plugin;
    private List<BedwarsAddonCommand> commands;
    private ConfigManager configmanager;
    
    public BedwarsAddon(final Plugin plugin) {
        this.commands = new ArrayList<BedwarsAddonCommand>();
        this.configmanager = null;
        this.plugin = plugin;
        MBedwars.b.put(plugin, this);
    }
    
    public void registerCommand(final BedwarsAddonCommand bedwarsAddonCommand) {
        this.commands.add(bedwarsAddonCommand);
    }
    
    public BedwarsAddonCommand getCommand(final String anotherString) {
        for (final BedwarsAddonCommand bedwarsAddonCommand : this.commands) {
            if (bedwarsAddonCommand.command.equalsIgnoreCase(anotherString)) {
                return bedwarsAddonCommand;
            }
        }
        return null;
    }
    
    public List<BedwarsAddonCommand> getCommands() {
        return this.commands;
    }
    
    public ConfigManager getConfig() {
        if (this.configmanager == null) {
            this.configmanager = new ConfigManager(MBedwars.a.getName(), "/add-ons/" + this.plugin.getName() + ".yml");
        }
        return this.configmanager;
    }
    
    public Plugin getPlugin() {
        return this.plugin;
    }
    
    public int getID() {
        return MBedwars.a.getAddonID(this.plugin);
    }
    
    public abstract static class BedwarsAddonCommand
    {
        protected String command;
        protected String usage;
        protected String fullUsage;
        
        public BedwarsAddonCommand(final String s) {
            this(s, "");
        }
        
        public BedwarsAddonCommand(final String command, final String usage) {
            this.command = command;
            this.usage = usage;
        }
        
        public String getCommand() {
            return this.command;
        }
        
        public String getUsage() {
            return this.usage;
        }
        
        public abstract void onWrite(final CommandSender p0, final String[] p1, final String p2);
    }
}
