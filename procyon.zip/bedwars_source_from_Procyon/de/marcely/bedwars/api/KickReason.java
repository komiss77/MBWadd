// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

public enum KickReason
{
    Leave("Leave", 0, de.marcely.bedwars.game.arena.KickReason.b), 
    Kick("Kick", 1, de.marcely.bedwars.game.arena.KickReason.c), 
    Lose("Lose", 2, de.marcely.bedwars.game.arena.KickReason.d), 
    End("End", 3, de.marcely.bedwars.game.arena.KickReason.e), 
    Draw("Draw", 4, de.marcely.bedwars.game.arena.KickReason.g), 
    MapVote_SwitchArena("MapVote_SwitchArena", 5, de.marcely.bedwars.game.arena.KickReason.h), 
    Others("Others", 6, de.marcely.bedwars.game.arena.KickReason.c);
    
    private final de.marcely.bedwars.game.arena.KickReason internal;
    
    private KickReason(final String name, final int ordinal, final de.marcely.bedwars.game.arena.KickReason internal) {
        this.internal = internal;
    }
    
    public static KickReason fromInternal(final de.marcely.bedwars.game.arena.KickReason kickReason) {
        KickReason[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final KickReason kickReason2 = values[i];
            if (kickReason2.internal == kickReason) {
                return kickReason2;
            }
        }
        return KickReason.Others;
    }
    
    public de.marcely.bedwars.game.arena.KickReason getInternal() {
        return this.internal;
    }
}
