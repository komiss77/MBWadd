// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

public interface UpgradeStateAPI
{
    Arena getArena();
    
    Team GetTeam();
}
