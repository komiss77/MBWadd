// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.ChatColor;
import javax.annotation.Nullable;

public enum Team
{
    Yellow("Yellow", 0, de.marcely.bedwars.game.Team.c), 
    Orange("Orange", 1, de.marcely.bedwars.game.Team.d), 
    Red("Red", 2, de.marcely.bedwars.game.Team.e), 
    Blue("Blue", 3, de.marcely.bedwars.game.Team.f), 
    Light_Blue("Light_Blue", 4, de.marcely.bedwars.game.Team.g), 
    Cyan("Cyan", 5, de.marcely.bedwars.game.Team.h), 
    Light_Green("Light_Green", 6, de.marcely.bedwars.game.Team.i), 
    Green("Green", 7, de.marcely.bedwars.game.Team.j), 
    Purple("Purple", 8, de.marcely.bedwars.game.Team.k), 
    Pink("Pink", 9, de.marcely.bedwars.game.Team.l), 
    White("White", 10, de.marcely.bedwars.game.Team.m), 
    Light_Gray("Light_Gray", 11, de.marcely.bedwars.game.Team.n), 
    Gray("Gray", 12, de.marcely.bedwars.game.Team.o), 
    Brown("Brown", 13, de.marcely.bedwars.game.Team.p), 
    Black("Black", 14, de.marcely.bedwars.game.Team.q);
    
    private final de.marcely.bedwars.game.Team internal;
    
    private Team(final String name, final int ordinal, final de.marcely.bedwars.game.Team internal) {
        this.internal = internal;
    }
    
    @Nullable
    public static Team fromInternal(final de.marcely.bedwars.game.Team team) {
        if (team == null) {
            return null;
        }
        Team[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Team team2 = values[i];
            if (team2.internal == team) {
                return team2;
            }
        }
        return null;
    }
    
    public String getName() {
        return this.internal.getName();
    }
    
    public String getName(final boolean b) {
        return this.internal.getName(b);
    }
    
    public String getShortName() {
        return this.internal.m();
    }
    
    public ChatColor getChatColor() {
        return this.internal.getChatColor();
    }
    
    public DyeColor getDyeColor() {
        return this.internal.getDyeColor();
    }
    
    public Color getColor() {
        return this.internal.getColor();
    }
    
    public static Team getTeamByName(final String s) {
        return fromInternal(de.marcely.bedwars.game.Team.a(s));
    }
    
    public static Team getTeamByName(final String s, final boolean b) {
        return fromInternal(de.marcely.bedwars.game.Team.a(s, b));
    }
    
    public static Team getTeamByChatColor(final ChatColor chatColor) {
        return fromInternal(de.marcely.bedwars.game.Team.a(chatColor));
    }
    
    public static Team getTeamByDyeColor(final DyeColor dyeColor) {
        return fromInternal(de.marcely.bedwars.game.Team.a(dyeColor));
    }
    
    public de.marcely.bedwars.game.Team getInternal() {
        return this.internal;
    }
}
