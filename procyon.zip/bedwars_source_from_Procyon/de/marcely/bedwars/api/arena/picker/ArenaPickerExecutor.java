// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.arena.picker;

import javax.annotation.Nullable;
import de.marcely.bedwars.api.Arena;
import java.util.List;

public interface ArenaPickerExecutor
{
    @Nullable
    Arena run(final List<Arena> p0, final Arena p1);
}
