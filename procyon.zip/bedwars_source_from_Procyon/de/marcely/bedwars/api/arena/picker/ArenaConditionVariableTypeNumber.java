// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;

public class ArenaConditionVariableTypeNumber extends ArenaConditionVariableType<Float>
{
    public ArenaConditionVariableTypeNumber(final float f) {
        super(f);
    }
    
    @Override
    public byte getType() {
        return 0;
    }
    
    @Override
    public boolean equal(final Float n) {
        return (float)this.entry == n;
    }
    
    @Override
    public boolean notEqual(final Float n) {
        return (float)this.entry != n;
    }
    
    @Override
    public boolean greaterThan(final Float n) {
        return (float)this.entry > n;
    }
    
    @Override
    public boolean lessThan(final Float n) {
        return (float)this.entry < n;
    }
    
    @Override
    public boolean greaterThanOrEqual(final Float n) {
        return (float)this.entry >= n;
    }
    
    @Override
    public boolean lessThanOrEqual(final Float n) {
        return (float)this.entry <= n;
    }
}
