// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api.arena.picker;

import de.marcely.bedwars.game.arena.picker.condition.ArenaConditionVariableType;

public class ArenaConditionVariableTypeString extends ArenaConditionVariableType<String>
{
    public ArenaConditionVariableTypeString(final String s) {
        super(s);
    }
    
    @Override
    public byte getType() {
        return 1;
    }
    
    @Override
    public boolean equal(final String anObject) {
        return ((String)this.entry).equals(anObject);
    }
    
    @Override
    public boolean notEqual(final String anObject) {
        return !((String)this.entry).equals(anObject);
    }
    
    @Override
    public boolean greaterThan(final String s) {
        throw new IllegalStateException("Operation not supported");
    }
    
    @Override
    public boolean lessThan(final String s) {
        throw new IllegalStateException("Operation not supported");
    }
    
    @Override
    public boolean greaterThanOrEqual(final String s) {
        throw new IllegalStateException("Operation not supported");
    }
    
    @Override
    public boolean lessThanOrEqual(final String s) {
        throw new IllegalStateException("Operation not supported");
    }
}
