// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.game.LobbyItem;

public enum LobbyItemType
{
    Leave("Leave", 0, LobbyItem.LobbySpecialType.a), 
    SelectTeam("SelectTeam", 1, LobbyItem.LobbySpecialType.b), 
    VoteArena("VoteArena", 2, LobbyItem.LobbySpecialType.c), 
    ForceStart("ForceStart", 3, LobbyItem.LobbySpecialType.d), 
    Achievements("Achievements", 4, LobbyItem.LobbySpecialType.e), 
    Custom("Custom", 5, LobbyItem.LobbySpecialType.f);
    
    private final LobbyItem.LobbySpecialType nms;
    
    private LobbyItemType(final String name, final int ordinal, final LobbyItem.LobbySpecialType nms) {
        this.nms = nms;
    }
    
    public static LobbyItemType fromNMS(final LobbyItem.LobbySpecialType lobbySpecialType) {
        LobbyItemType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final LobbyItemType lobbyItemType = values[i];
            if (lobbyItemType.nms == lobbySpecialType) {
                return lobbyItemType;
            }
        }
        return null;
    }
    
    public LobbyItem.LobbySpecialType getNms() {
        return this.nms;
    }
}
