// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.command.d;
import de.marcely.bedwars.MBedwars;

public class APIConfiguration
{
    public boolean teamsEnabled;
    public boolean bedsEnabled;
    public boolean itemspawnersEnabled;
    
    public APIConfiguration() {
        this.teamsEnabled = true;
        this.bedsEnabled = true;
        this.itemspawnersEnabled = true;
    }
    
    public void update() {
        MBedwars.a.refresh();
        ((d)MBedwars.a.a("arena").a()).a.refresh();
    }
}
