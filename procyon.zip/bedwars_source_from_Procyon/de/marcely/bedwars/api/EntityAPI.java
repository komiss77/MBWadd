// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import de.marcely.bedwars.game.location.XYZYPW;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import de.marcely.bedwars.game.IEntity;
import org.bukkit.Location;
import de.marcely.bedwars.util.s;

public class EntityAPI
{
    public void save() {
        s.al();
    }
    
    public void removeAll() {
        s.i(false);
    }
    
    public void summonDealer(final Location location) {
        s.a(IEntity.a(location));
    }
    
    public void summonHub(final Location location, final Arena arena) {
        s.a(IEntity.a(location, (de.marcely.bedwars.game.arena.Arena)arena));
    }
    
    public void summonHub(final Location location, final int n, final int n2) {
        s.a(IEntity.a(location, n, n2));
    }
    
    public void summonTeamSelect(final Location location, final Team team) {
        s.a(IEntity.a(location, team.getInternal()));
    }
    
    public void summonUpgradeDealer(final Location location) {
        s.a(IEntity.b(location));
    }
    
    public List<Location> getDealers() {
        return this.find(IEntity.IEntityType.Dealer);
    }
    
    public List<Location> getHub() {
        return this.find(IEntity.IEntityType.Hub);
    }
    
    public List<Location> getTeamSelect() {
        return this.find(IEntity.IEntityType.TeamSelect);
    }
    
    public List<Location> getUpgradeDealer() {
        return this.find(IEntity.IEntityType.UpgradeDealer);
    }
    
    private List<Location> find(final IEntity.IEntityType entityType) {
        final ArrayList<Location> list = new ArrayList<Location>();
        for (final IEntity entity : s.U.get(entityType)) {
            if (entity.a().getWorld() != null) {
                list.add(entity.a().toBukkit());
            }
        }
        return list;
    }
    
    public int remove(final Location location) {
        return this.remove(location, true);
    }
    
    public int remove(final Location location, final boolean b) {
        int n = 0;
        IEntity.IEntityType[] values;
        for (int length = (values = IEntity.IEntityType.values()).length, i = 0; i < length; ++i) {
            n += this.remove(location, values[i], false);
        }
        if (b) {
            this.save();
        }
        return n;
    }
    
    public int remove(final Location location, final IEntity.IEntityType entityType) {
        return this.remove(location, entityType, true);
    }
    
    public int remove(final Location location, final IEntity.IEntityType entityType, final boolean b) {
        final XYZYPW value = XYZYPW.valueOf(location);
        int n = 0;
        for (int i = s.U.get(entityType).size() - 1; i >= 0; --i) {
            final IEntity entity = s.U.get(entityType).get(i);
            if (entity.a().equals(value)) {
                ++n;
                s.b(entity, b);
            }
        }
        return n;
    }
}
