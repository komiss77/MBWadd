// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import org.bukkit.Color;
import java.util.Iterator;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import de.marcely.bedwars.versions.Version;
import org.bukkit.Particle;
import org.bukkit.Effect;
import java.lang.reflect.Method;

public class VarParticle
{
    public static final VarParticle PARTICLE_CLOUD;
    public static final VarParticle PARTICLE_SMOKE;
    public static final VarParticle PARTICLE_COLOURED;
    private static Method METHOD_PLAYER_SPAWN_PARTICLE;
    private final ParticleKeepType keepType;
    private Effect effect;
    private Particle particle;
    
    static {
        PARTICLE_CLOUD = ofName("CLOUD");
        PARTICLE_SMOKE = ofName("SMOKE");
        if (Version.a().getVersionNumber() >= 9) {
            try {
                VarParticle.METHOD_PLAYER_SPAWN_PARTICLE = Player.class.getMethod("spawnParticle", Particle.class, Location.class, Integer.TYPE, Object.class);
            }
            catch (NoSuchMethodException | SecurityException ex) {
                final Throwable t;
                t.printStackTrace();
            }
        }
        if (Version.a().getVersionNumber() >= 13) {
            PARTICLE_COLOURED = ofName("REDSTONE");
        }
        else {
            PARTICLE_COLOURED = ofName("COLOURED_DUST");
        }
    }
    
    public VarParticle(final Effect effect) {
        this.keepType = ParticleKeepType.EFFECT;
        this.effect = effect;
    }
    
    public VarParticle(final Particle particle) {
        this.keepType = ParticleKeepType.PARTICLE;
        this.particle = particle;
    }
    
    public String getName() {
        switch (this.keepType) {
            case EFFECT: {
                return this.effect.name();
            }
            case PARTICLE: {
                return this.particle.name();
            }
            default: {
                return null;
            }
        }
    }
    
    public void play(final World world, final Location location, final int n) {
        final Iterator<Player> iterator = world.getPlayers().iterator();
        while (iterator.hasNext()) {
            this.play(iterator.next(), location, n);
        }
    }
    
    public void play(final World world, final Location location, final Color color) {
        final Iterator<Player> iterator = world.getPlayers().iterator();
        while (iterator.hasNext()) {
            this.play(iterator.next(), location, color);
        }
    }
    
    public void play(final Player obj, final Location location, final int n) {
        switch (this.keepType) {
            case EFFECT: {
                obj.playEffect(location, this.effect, n);
                break;
            }
            case PARTICLE: {
                try {
                    VarParticle.METHOD_PLAYER_SPAWN_PARTICLE.invoke(obj, this.particle, location, 1, null);
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
                break;
            }
        }
    }
    
    public void play(final Player player, final Location location, final Color color) {
        switch (this.keepType) {
            case EFFECT: {
                float n = color.getRed() / 255.0f;
                if (n == 0.0f) {
                    n = Float.MIN_NORMAL;
                }
                if (Version.a().getVersionNumber() < 13) {
                    player.spigot().playEffect(location, this.effect, 0, 1, n, color.getGreen() / 255.0f, color.getBlue() / 255.0f, 1.0f, 0, 32);
                    break;
                }
                player.playEffect(location, this.effect, 0);
                break;
            }
            case PARTICLE: {
                try {
                    if (Version.a().getVersionNumber() >= 13) {
                        VarParticle.METHOD_PLAYER_SPAWN_PARTICLE.invoke(player, this.particle, location, 1, Class.forName("org.bukkit.Particle$DustOptions").getConstructor(Color.class, Float.TYPE).newInstance(color, 1.0f));
                    }
                    else {
                        VarParticle.METHOD_PLAYER_SPAWN_PARTICLE.invoke(player, this.particle, location, 1, null);
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                break;
            }
        }
    }
    
    @Nullable
    public static VarParticle ofName(final String s) {
        if (Version.a().getVersionNumber() >= 9) {
            Particle[] values;
            for (int length = (values = Particle.values()).length, i = 0; i < length; ++i) {
                final Particle particle = values[i];
                if (particle.name().equalsIgnoreCase(s) || particle.name().replace("_", "").equalsIgnoreCase(s)) {
                    return new VarParticle(particle);
                }
            }
        }
        Effect[] values2;
        for (int length2 = (values2 = Effect.values()).length, j = 0; j < length2; ++j) {
            final Effect effect = values2[j];
            if (effect.name().equalsIgnoreCase(s) || effect.name().replace("_", "").equalsIgnoreCase(s)) {
                return new VarParticle(effect);
            }
        }
        return null;
    }
    
    public ParticleKeepType getKeepType() {
        return this.keepType;
    }
    
    public Effect getEffect() {
        return this.effect;
    }
    
    public Particle getParticle() {
        return this.particle;
    }
    
    public enum ParticleKeepType
    {
        EFFECT("EFFECT", 0), 
        PARTICLE("PARTICLE", 1);
        
        private ParticleKeepType(final String name, final int ordinal) {
        }
    }
}
