// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.api;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.LobbyItem;

public abstract class CustomLobbyItem extends LobbyItem.a
{
    public CustomLobbyItem(final String s) {
        super(LobbyItem.LobbySpecialType.f, s);
    }
    
    public abstract void onUse(final Player p0);
}
