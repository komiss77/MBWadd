// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.versions.Version;
import org.bukkit.entity.EntityType;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Sheep;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;

public class bE extends by
{
    private Arena arena;
    private Team team;
    private Sheep a;
    private BukkitTask d;
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Block clickedBlock = playerUseExtraItemEvent.getClickedBlock();
        final BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (clickedBlock == null) {
            this.done();
            return;
        }
        this.arena = (Arena)playerUseExtraItemEvent.getArena();
        this.team = this.arena.a(player);
        s.a(player, Achievement.r);
        this.L();
        final Location location = clickedBlock.getLocation();
        this.a(new Location(location.getWorld(), location.getX() + blockFace.getModX(), location.getY() + blockFace.getModY(), location.getZ() + blockFace.getModZ()));
    }
    
    @Override
    public void K() {
        if (this.a == null) {
            return;
        }
        this.a.remove();
        this.d.cancel();
    }
    
    private void a(final Location location) {
        final Sheep a = (Sheep)location.getWorld().spawnEntity(location, EntityType.SHEEP);
        this.a = a;
        final Sheep sheep = a;
        sheep.setMaxHealth(5.0);
        sheep.setHealth(5.0);
        sheep.setColor(this.team.getDyeColor());
        Version.a().a((Entity)sheep, ConfigValue.tntsheep_speed);
        Version.a().a((Entity)sheep, 50);
        final TNTPrimed passenger = (TNTPrimed)location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        passenger.setFuseTicks(100);
        passenger.setYield(5.0f);
        this.a.setPassenger((Entity)passenger);
        Sound.EXTRAITEM_TNTSHEEP_FUSE.play(location);
        this.d = new BukkitRunnable() {
            public void run() {
                bE.this.tick();
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 10L);
    }
    
    private void tick() {
        if (this.a.isDead()) {
            this.done();
            return;
        }
        final Player a = s.a(this.arena, this.a.getLocation(), this.team);
        if (a != null) {
            Version.a().a((Entity)this.a, (Entity)a);
        }
    }
}
