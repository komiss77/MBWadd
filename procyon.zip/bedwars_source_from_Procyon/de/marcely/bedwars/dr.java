// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import me.BukkitPVP.VIPHide.VIPHide;

public class dr extends dp
{
    private VIPHide a;
    
    @Override
    public cT a() {
        return cT.i;
    }
    
    @Override
    public void onEnable() {
        this.a = (VIPHide)Bukkit.getPluginManager().getPlugin("VIPHide");
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String c(final Player player) {
        return this.a.isDisguised(player) ? this.a.getName(player) : null;
    }
    
    @Override
    public String d(final Player player) {
        return null;
    }
}
