// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Collection;
import org.bukkit.ChatColor;
import de.marcely.bedwars.api.gui.GUIItem;
import java.util.List;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.util.i;
import java.util.ArrayList;
import de.marcely.bedwars.api.ExtraItem;
import org.bukkit.inventory.ItemStack;
import java.util.Iterator;
import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.api.ExtraItemListener;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerEvent;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import de.marcely.bedwars.game.shop.Shop;
import de.marcely.bedwars.api.ShopOpenType;
import de.marcely.bedwars.game.arena.ArenaStatus;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.game.stats.RankingStatue;
import de.marcely.bedwars.util.s;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import java.util.HashMap;
import de.marcely.bedwars.api.gui.GUI;
import de.marcely.bedwars.game.IEntity;
import java.util.Map;

public class aX
{
    public static Map<IEntity, GUI> i;
    
    static {
        aX.i = new HashMap<IEntity, GUI>();
    }
    
    public static void a(final PlayerInteractEntityEvent playerInteractEntityEvent) {
        final Entity rightClicked = playerInteractEntityEvent.getRightClicked();
        final Player player = playerInteractEntityEvent.getPlayer();
        if (rightClicked == null || player == null) {
            return;
        }
        final de.marcely.bedwars.game.arena.Arena a = s.a(player);
        if (cA.E.containsKey(player)) {
            playerInteractEntityEvent.setCancelled(true);
            return;
        }
        if (rightClicked.getType().toString().equals("ARMOR_STAND")) {
            for (final RankingStatue rankingStatue : s.ad) {
                if (rankingStatue.b() != null && rankingStatue.b().getEntityId() == rightClicked.getEntityId()) {
                    playerInteractEntityEvent.setCancelled(true);
                    return;
                }
            }
        }
        if (rightClicked.getType() == EntityType.VILLAGER && a != null) {
            playerInteractEntityEvent.setCancelled(true);
            if (a.b() == ArenaStatus.f && rightClicked.getType() == EntityType.VILLAGER) {
                Shop.eOpen(player, a, rightClicked.hasMetadata("mbw_isMinishop") ? ShopOpenType.MINISHOP : ShopOpenType.VILLAGER);
            }
        }
        if (a != null) {
            if (a.b().F()) {
                playerInteractEntityEvent.setCancelled(true);
            }
            else if (a.b() == ArenaStatus.f) {
                if (playerInteractEntityEvent.isCancelled()) {
                    return;
                }
                final ItemStack itemInHand = player.getItemInHand();
                final ExtraItem a2 = s.a(player, itemInHand);
                if (a2 != null) {
                    final PlayerUseExtraItemEvent playerUseExtraItemEvent = new PlayerUseExtraItemEvent(a2, a, (PlayerEvent)playerInteractEntityEvent, itemInHand);
                    Bukkit.getPluginManager().callEvent((Event)playerUseExtraItemEvent);
                    if (playerUseExtraItemEvent.isCancelled()) {
                        return;
                    }
                    playerInteractEntityEvent.setCancelled(true);
                    for (final ExtraItemListener extraItemListener : a2.getListeners()) {
                        try {
                            extraItemListener.onUse(playerUseExtraItemEvent);
                        }
                        catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
    }
    
    public static void t() {
        for (final Map.Entry<IEntity, GUI> entry : aX.i.entrySet()) {
            final IEntity entity = entry.getKey();
            final GUI gui = entry.getValue();
            final ArrayList<de.marcely.bedwars.game.arena.Arena> list = new ArrayList<de.marcely.bedwars.game.arena.Arena>();
            for (int i = 0; i < gui.getHeight() * 9; ++i) {
                final GUIItem item = gui.getItemAt(i);
                if (item != null && item.getItemStack() != null) {
                    final String removeChatColor = r.removeChatColor(de.marcely.bedwars.util.i.b(item.getItemStack()));
                    if (!de.marcely.bedwars.util.i.b(item.getItemStack()).equals("")) {
                        final de.marcely.bedwars.game.arena.Arena b = s.b(removeChatColor);
                        if (b != null) {
                            list.add(b);
                        }
                    }
                }
            }
            a(entity, list, gui.getTitle().substring(ConfigValue.lobbyvillager_prefix.length()));
        }
    }
    
    public static GUI a(final IEntity entity, final List<de.marcely.bedwars.game.arena.Arena> list, final String str) {
        GUI a = a(entity);
        if (a == null) {
            a = new GUI(String.valueOf(ConfigValue.lobbyvillager_prefix) + str, 0);
            aX.i.put(entity, a);
        }
        else {
            a.clear();
        }
        for (final de.marcely.bedwars.game.arena.Arena arena : list) {
            final List<String> o = arena.o();
            a.addItem(new GUIItem(de.marcely.bedwars.util.i.a(de.marcely.bedwars.util.i.a(arena.getIcon(), ChatColor.UNDERLINE + arena.getDisplayName()), (String[])o.toArray(new String[o.size()]))) {
                @Override
                public void onClick(final Player player, final boolean b, final boolean b2) {
                    final String b3 = s.b(player, arena);
                    if (b3 != null) {
                        player.sendMessage(b3);
                    }
                }
            });
            if (ConfigValue.gui_hubvillager_centered) {
                a.centerAtYAll(GUI.CenterFormatType.Beautiful);
            }
        }
        return a;
    }
    
    private static GUI a(final IEntity obj) {
        for (final Map.Entry<IEntity, V> entry : new ArrayList<Map.Entry<IEntity, V>>((Collection<? extends Map.Entry<IEntity, V>>)aX.i.entrySet())) {
            if (entry.getKey().a() != null) {
                if (entry.getKey().equals(obj)) {
                    return (GUI)entry.getValue();
                }
                continue;
            }
            else {
                s.b(entry.getKey());
            }
        }
        return null;
    }
}
