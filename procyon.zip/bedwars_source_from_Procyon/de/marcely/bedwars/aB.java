// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.List;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.ChatColor;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.location.XYZD;
import org.bukkit.event.Event;
import de.marcely.bedwars.api.event.BedPlaceEvent;
import de.marcely.bedwars.game.Team;
import java.util.Arrays;
import de.marcely.bedwars.versions.w;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.r;
import org.bukkit.command.CommandSender;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;
import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Material;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.game.location.XYZ;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.k;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.event.block.BlockPlaceEvent;

public class aB
{
    public static void a(final BlockPlaceEvent blockPlaceEvent) {
        final Player player = blockPlaceEvent.getPlayer();
        final Block block = blockPlaceEvent.getBlock();
        final Arena a = s.a(player);
        final byte data = block.getData();
        final ItemStack itemInHand = blockPlaceEvent.getItemInHand();
        if (a != null) {
            if (a.b() == ArenaStatus.f) {
                if (s.a(block.getLocation()) == null || a.a(block.getLocation())) {
                    blockPlaceEvent.setCancelled(true);
                }
                else {
                    final Material a2 = k.a(block.getType());
                    if (ConfigValue.placeableblock_whitelist_enabled && !s.W.containsKey(a2) && !ConfigValue.placeableblock_whitelist.contains(a2) && block.getType() != bx.g.getItemStack().getType()) {
                        blockPlaceEvent.setCancelled(true);
                    }
                    else {
                        blockPlaceEvent.setCancelled(false);
                        if (a2 == bx.g.getItemStack().getType()) {
                            a.n.put(XYZ.valueOf(block.getLocation()).toString(), blockPlaceEvent.getPlayer());
                            s.a(player, Achievement.t);
                        }
                        if (block.getType() == Material.TNT) {
                            blockPlaceEvent.setCancelled(false);
                            new BukkitRunnable() {
                                public void run() {
                                    block.setType(Material.AIR);
                                }
                            }.runTaskLater((Plugin)MBedwars.a, 1L);
                            block.getWorld().spawnEntity(block.getLocation(), EntityType.PRIMED_TNT);
                            return;
                        }
                        a.o.put(XYZ.valueOf(block.getLocation()).toString(), blockPlaceEvent.getPlayer());
                        if (ConfigValue.destroyblock_builtbyplayers || (ConfigValue.tnt_canbreakblocks && ConfigValue.tnt_canbreakblocks_breakby_player)) {
                            a.b(block);
                        }
                        if (itemInHand != null && itemInHand.getType() == Material.CHEST) {
                            final Location location = block.getLocation();
                            blockPlaceEvent.setCancelled(true);
                            if (s.e(location)) {
                                Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)MBedwars.a, (Runnable)new Runnable() {
                                    @Override
                                    public void run() {
                                        s.a(player, Material.CHEST);
                                        location.getWorld().getBlockAt(location).setType(Material.CHEST);
                                        location.getWorld().getBlockAt(location).setData(data);
                                    }
                                }, 1L);
                            }
                        }
                    }
                }
            }
            else {
                blockPlaceEvent.setCancelled(true);
            }
        }
        else {
            final Arena a3 = s.a(block.getLocation());
            if (a3 != null) {
                blockPlaceEvent.setCancelled(!s.hasPermission((CommandSender)player, Permission.ArenaBuild));
                if (a3 != null && s.hasPermission((CommandSender)player, Permission.ArenaBuild)) {
                    final String displayName = itemInHand.getItemMeta().getDisplayName();
                    if (displayName == null || !r.b(s.W, displayName)) {
                        return;
                    }
                    final Material type = block.getType();
                    if (type != ConfigValue.bed_block && Version.a().getVersionNumber() >= 13 && type == Material.AIR) {
                        final String a4 = ((w)Version.a().a()).a(block.getWorld(), block.getX(), block.getY(), block.getZ());
                        if (ConfigValue.bed_block != Material.BED_BLOCK || !a4.endsWith("_bed")) {
                            final String[] split = a4.split("_");
                            if (split.length >= 2) {
                                ("legacy_" + String.join("_", (CharSequence[])Arrays.copyOfRange(split, 1, split.length))).equals(type.name().toLowerCase());
                            }
                        }
                    }
                    final Team a5 = Team.a((CommandSender)player, r.removeChatColor(r.c(s.W, displayName)));
                    if (a5 != null) {
                        if (a3.a().r().contains(a5)) {
                            if (!a3.a().J()) {
                                return;
                            }
                            final BedPlaceEvent bedPlaceEvent = new BedPlaceEvent(player, a, a5, block.getLocation());
                            Bukkit.getPluginManager().callEvent((Event)bedPlaceEvent);
                            if (!bedPlaceEvent.isCancelled()) {
                                a3.a().a(XYZD.valueOf(block, ConfigValue.bed_block == Material.BED_BLOCK), a5);
                                b.b(a3);
                                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Saved_Bed).a("arena", a3.getName()).a("color", a5.a((CommandSender)player)).a("colorcode", new StringBuilder().append(a5.getChatColor()).toString()));
                            }
                        }
                        else {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Team_NotAddedYet).a("team", a5.a((CommandSender)player, true)).a("teamcolor", new StringBuilder().append(a5.getChatColor()).toString()).a("arena", a3.getName()));
                        }
                    }
                }
                else if (s.hasPermission((CommandSender)player, Permission.GetArena) && block.getType() == Material.SOUL_SAND) {
                    final List<Arena> arenas = s.getArenas(block.getLocation());
                    player.sendMessage("");
                    player.sendMessage(ChatColor.GOLD + "Arenas:");
                    final Iterator<Arena> iterator = arenas.iterator();
                    while (iterator.hasNext()) {
                        player.sendMessage(ChatColor.YELLOW + iterator.next().getName());
                    }
                    player.sendMessage("");
                }
            }
        }
    }
}
