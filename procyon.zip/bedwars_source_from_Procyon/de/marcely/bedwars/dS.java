// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.stats.c;

public class dS extends dR
{
    public dS() {
        super("playtime");
    }
    
    @Override
    public String c(final c c) {
        return s.a(c.getPlayTime());
    }
}
