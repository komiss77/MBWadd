// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.ArrayList;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.util.Iterator;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.Collection;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class C extends NormalPacket
{
    public byte k;
    public Collection<S> a;
    
    @Override
    public byte getPacketID() {
        return 3;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.k);
        bufferedWriteStream.writeUnsignedByte(this.a.size());
        final Iterator<S> iterator = this.a.iterator();
        while (iterator.hasNext()) {
            bufferedWriteStream.writeString(iterator.next().name());
        }
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.k = bufferedReadStream.readByte();
        final int unsignedByte = bufferedReadStream.readUnsignedByte();
        this.a = new ArrayList<S>(unsignedByte);
        for (int i = 0; i < unsignedByte; ++i) {
            final S a = S.a(bufferedReadStream.readString());
            if (a != null) {
                this.a.add(a);
            }
        }
    }
}
