// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.versions.Version;
import java.util.Collection;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class aC
{
    public static void a(final CreatureSpawnEvent creatureSpawnEvent) {
        final Arena a = s.a(creatureSpawnEvent.getLocation());
        final CreatureSpawnEvent.SpawnReason spawnReason = creatureSpawnEvent.getSpawnReason();
        if (spawnReason == CreatureSpawnEvent.SpawnReason.CUSTOM || spawnReason == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG) {
            if (a != null && !ConfigValue.entityspawning_enabled) {
                creatureSpawnEvent.setCancelled(false);
            }
        }
        else if (a != null && !ConfigValue.entityspawning_enabled) {
            creatureSpawnEvent.setCancelled(true);
        }
        if (creatureSpawnEvent.getEntityType() == EntityType.VILLAGER) {
            for (final Player player : new ArrayList<Player>(s.aj)) {
                if (player.getLocation().getX() == creatureSpawnEvent.getLocation().getX() && player.getLocation().getY() == creatureSpawnEvent.getLocation().getY() && player.getLocation().getZ() == creatureSpawnEvent.getLocation().getZ()) {
                    creatureSpawnEvent.setCancelled(false);
                    if (Version.a().getVersionNumber() > 8) {
                        continue;
                    }
                    s.aj.remove(player);
                }
            }
        }
        else if (Version.a().getVersionNumber() >= 8 && creatureSpawnEvent.getEntityType() == EntityType.ARMOR_STAND) {
            for (final Player player2 : new ArrayList<Player>(s.aj)) {
                if (player2.getLocation().getX() == creatureSpawnEvent.getLocation().getX() && player2.getLocation().getZ() == creatureSpawnEvent.getLocation().getZ()) {
                    creatureSpawnEvent.setCancelled(false);
                    if (Version.a().getVersionNumber() < 9) {
                        continue;
                    }
                    s.aj.remove(player2);
                }
            }
        }
    }
}
