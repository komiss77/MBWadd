// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.holographic.h;

public class cH extends h
{
    public String name;
    public int id;
    public boolean V;
    
    public cH() {
        this.name = "";
        this.id = s.RAND.nextInt(16);
    }
    
    public cH a(final String name) {
        this.name = name;
        return this;
    }
    
    public cH a(final int id) {
        this.id = id;
        return this;
    }
}
