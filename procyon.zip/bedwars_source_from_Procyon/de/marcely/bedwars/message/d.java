// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.message;

import de.marcely.bedwars.Language;

public class d
{
    private a a;
    private Language a;
    private String O;
    
    public a a() {
        return this.a;
    }
    
    public void a(final a a) {
        this.a = a;
    }
    
    public Language a() {
        return this.a;
    }
    
    public void b(final Language a) {
        this.a = a;
    }
    
    public String s() {
        return this.O;
    }
    
    public void z(final String o) {
        this.O = o;
    }
    
    public enum a
    {
        b("STRING", 0), 
        c("CONFIG", 1);
        
        static {
            a = new a[] { d.a.b, d.a.c };
        }
        
        private a(final String name, final int ordinal) {
        }
    }
}
