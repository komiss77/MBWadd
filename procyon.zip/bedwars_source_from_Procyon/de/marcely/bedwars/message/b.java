// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.message;

import de.marcely.bedwars.util.t;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.Language;
import java.util.HashMap;
import java.util.Map;
import de.marcely.bedwars.util.g;

public class b implements g.a
{
    private static g<b> a;
    private d a;
    private Map<String, String> M;
    private boolean ab;
    private boolean ac;
    private boolean ad;
    
    static {
        b.a = new g<b>() {
            public b d() {
                return new b(null);
            }
        };
    }
    
    private b() {
        this.a = new d();
        this.M = new HashMap<String, String>(4);
        this.ab = false;
        this.ac = false;
        this.ad = false;
    }
    
    @Override
    public void reset() {
        this.M.clear();
        this.ab = false;
        this.ac = false;
        this.ad = false;
        this.a.a(null);
        this.a.b(null);
        this.a.z(null);
    }
    
    public b a(final String s, final String s2) {
        this.M.put(s, s2);
        return this;
    }
    
    public boolean T() {
        return this.ab;
    }
    
    public boolean U() {
        return this.ac;
    }
    
    public boolean V() {
        return this.ad;
    }
    
    public b a() {
        this.ab = true;
        return this;
    }
    
    public b b() {
        this.ac = true;
        return this;
    }
    
    public b c() {
        this.ad = true;
        return this;
    }
    
    public boolean W() {
        return this.a.a() == null;
    }
    
    public boolean X() {
        if (this.W()) {
            return false;
        }
        b.a.a(this);
        return true;
    }
    
    @Nullable
    public String f(@Nullable final CommandSender commandSender) {
        return this.b(commandSender, true);
    }
    
    @Nullable
    public String b(@Nullable final CommandSender commandSender, final boolean b) {
        if (this.W()) {
            throw new IllegalStateException("Instance is already freed");
        }
        String a = null;
        try {
            a = s.a.a(commandSender, this);
        }
        catch (Error error) {
            error.printStackTrace();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (b) {
            this.X();
        }
        return a;
    }
    
    public static b a(final Language language) {
        t.c(language);
        final b b = de.marcely.bedwars.message.b.a.b();
        b.a.a(d.a.c);
        b.a.b(language);
        return b;
    }
    
    @Nullable
    public static b a(final String s) {
        t.c(s);
        final b b = de.marcely.bedwars.message.b.a.b();
        b.a.a(d.a.b);
        b.a.z(s);
        return b;
    }
    
    public d a() {
        return this.a;
    }
    
    public Map<String, String> getPlaceholders() {
        return this.M;
    }
}
