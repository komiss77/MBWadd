// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.message;

import java.util.Iterator;
import java.util.Map;
import de.marcely.bedwars.Language;
import org.bukkit.Bukkit;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

public class a implements c
{
    private static /* synthetic */ int[] r;
    
    @Override
    public String a(@Nullable CommandSender consoleSender, final b b) {
        if (consoleSender == null) {
            consoleSender = (CommandSender)Bukkit.getConsoleSender();
        }
        String str = null;
        switch (s()[b.a().a().ordinal()]) {
            case 1: {
                str = b.a().s();
                break;
            }
            case 2: {
                str = b.a().a().getMessage(consoleSender);
                break;
            }
        }
        if (str == null) {
            throw new RuntimeException("Input is null");
        }
        if (b.V()) {
            str = Language.replaceLanguageTranslations(consoleSender, str);
        }
        if (b.T()) {
            str = String.valueOf(Language.Prefix.getMessage(consoleSender)) + " " + str;
        }
        if (b.getPlaceholders().size() >= 1) {
            for (final Map.Entry<String, String> entry : b.getPlaceholders().entrySet()) {
                if (entry.getKey() != null) {
                    if (entry.getValue() == null) {
                        continue;
                    }
                    str = str.replace("{" + entry.getKey() + "}", entry.getValue());
                }
            }
        }
        if (b.U()) {
            str = Language.stringToChatColor(str);
        }
        return str;
    }
    
    static /* synthetic */ int[] s() {
        final int[] r = a.r;
        if (r != null) {
            return r;
        }
        final int[] r2 = new int[d.a.values().length];
        try {
            r2[d.a.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            r2[d.a.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        return a.r = r2;
    }
}
