// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.message;

import java.util.Locale;
import java.util.HashMap;
import de.marcely.bedwars.Language;
import java.util.Map;

public class MessagesPack
{
    private final Map<String, Map<Language, String>> N;
    private Map<Language, String> O;
    
    public MessagesPack() {
        this.N = new HashMap<String, Map<Language, String>>();
        this.a(new HashMap<Language, String>(0));
    }
    
    public void a(final Locale locale, final Map<Language, String> map) {
        this.N.put(locale.toString(), map);
    }
    
    public void a(final Map<Language, String> o) {
        this.O = o;
    }
    
    public void clear() {
        this.N.clear();
    }
    
    public String a(final String s, final Language language) {
        Map<Language, String> o = this.N.get(s);
        if (o == null) {
            o = this.O;
        }
        final String s2 = o.get(language);
        return (s2 != null) ? s2 : language.getDefaultEnglish();
    }
    
    public String a(final Locale locale, final Language language) {
        return this.a(locale.toString(), language);
    }
}
