// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.message;

import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

public interface c
{
    String a(@Nullable final CommandSender p0, final b p1);
}
