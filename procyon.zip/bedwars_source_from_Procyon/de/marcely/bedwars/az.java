// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Collection;
import java.util.Iterator;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.game.location.XYZ;
import org.bukkit.plugin.Plugin;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.h;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.Arrays;
import de.marcely.bedwars.versions.w;
import org.bukkit.Material;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.config.q;
import de.marcely.bedwars.config.b;
import java.util.Map;
import de.marcely.bedwars.game.location.XYZW;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.a;
import org.bukkit.event.block.BlockBreakEvent;

public class az
{
    public static void a(final BlockBreakEvent blockBreakEvent) {
        final Player player = blockBreakEvent.getPlayer();
        final Block block = blockBreakEvent.getBlock();
        if (a.b(block)) {
            if (s.hasPermission((CommandSender)player, Permission.Command_AddSign)) {
                final Iterator<Map.Entry<XYZW, String>> iterator = s.S.entrySet().iterator();
                while (iterator.hasNext()) {
                    final XYZW xyzw = iterator.next().getKey();
                    if (xyzw.getWorld() == null && !b.o() && !s.g(xyzw.getWorldString())) {
                        s.S.remove(xyzw);
                    }
                    if (block.getWorld().equals(xyzw.getWorld()) && xyzw.getX() == block.getX() && xyzw.getY() == block.getY() && xyzw.getZ() == block.getZ()) {
                        s.S.remove(xyzw);
                        s.ai();
                        s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Removed_Sign).a());
                        return;
                    }
                }
            }
            if (s.hasPermission((CommandSender)player, Permission.Command_AddStatsSign) && s.T.remove(block.getLocation().toString()) != null) {
                q.save();
                s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Removed_Sign).a());
                return;
            }
        }
        final Arena a = s.a(player);
        if (a != null) {
            if (a.b() == ArenaStatus.f) {
                final Material type = block.getType();
                int equals = (type == ConfigValue.bed_block) ? 1 : 0;
                if (equals == 0 && Version.a().getVersionNumber() >= 13 && type == Material.AIR) {
                    final String a2 = ((w)Version.a().a()).a(block.getWorld(), block.getX(), block.getY(), block.getZ());
                    if (ConfigValue.bed_block == Material.BED_BLOCK && a2.endsWith("_bed")) {
                        equals = 1;
                    }
                    else {
                        final String[] split = a2.split("_");
                        if (split.length >= 2) {
                            equals = (("legacy_" + String.join("_", (CharSequence[])Arrays.copyOfRange(split, 1, split.length))).equals(type.name().toLowerCase()) ? 1 : 0);
                        }
                    }
                }
                if (equals != 0) {
                    final h a3 = a.a();
                    final Team a4 = a3.a(block.getLocation());
                    if (a4 != null) {
                        blockBreakEvent.setCancelled(true);
                        if (ConfigValue.bed_onlydestroyablewith_tnt) {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.Bed_OnlyDestroyAbleWith_TNT));
                            return;
                        }
                        if (!ConfigValue.ownbed_destroyable && a4 == a.a(player)) {
                            s.a((CommandSender)player, de.marcely.bedwars.message.b.a(Language.NotAllowed_BedDestroy));
                            return;
                        }
                        blockBreakEvent.setCancelled(true);
                        new BukkitRunnable() {
                            public void run() {
                                Block[] a;
                                for (int length = (a = ((h)block).a(block)).length, i = 0; i < length; ++i) {
                                    a[i].setType(Material.AIR, false);
                                }
                                a.a(player, block.getLocation(), block);
                            }
                        }.runTaskLater((Plugin)MBedwars.a, 0L);
                        return;
                    }
                }
                if (type == ConfigValue.rescueplatform_material) {
                    blockBreakEvent.setCancelled(true);
                    new BukkitRunnable() {
                        public void run() {
                            blockBreakEvent.getBlock().setType(Material.AIR);
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 1L);
                    return;
                }
                if (block.getType() == Material.TNT) {
                    for (final Map.Entry<String, Player> entry : a.o.entrySet()) {
                        if (XYZ.ofString(entry.getKey()).equals(XYZ.valueOf(block.getLocation()))) {
                            a.o.remove(entry.getKey());
                            break;
                        }
                    }
                }
                if (a.a(block.getLocation())) {
                    blockBreakEvent.setCancelled(true);
                    return;
                }
                if (block.getType() == Material.ENDER_CHEST || block.getType() == Material.WEB) {
                    new BukkitRunnable() {
                        public void run() {
                            if (((Block)blockBreakEvent).getType() != null && ((Block)blockBreakEvent).getType() != Material.AIR) {
                                s.f(blockBreakEvent.getBlock());
                                blockBreakEvent.getBlock().getWorld().dropItemNaturally(blockBreakEvent.getBlock().getLocation(), new ItemStack(((Block)blockBreakEvent).getType(), 1));
                            }
                        }
                    }.runTaskLater((Plugin)MBedwars.a, 0L);
                }
                for (final Map.Entry<String, Player> entry2 : a.n.entrySet()) {
                    if (XYZ.ofString(entry2.getKey()).equals(XYZ.valueOf(block.getLocation()))) {
                        a.n.remove(entry2.getKey());
                        break;
                    }
                }
                if (ConfigValue.destroyblock_builtbyplayers && !a.a(block)) {
                    blockBreakEvent.setCancelled(true);
                    return;
                }
                final Arena a5 = s.a(block.getLocation());
                if ((ConfigValue.placeableblock_whitelist_enabled && !s.W.containsKey(type) && !ConfigValue.placeableblock_whitelist.contains(type) && block.getType() != bx.g.getItemStack().getType()) || a5 == null || !a5.equals(a)) {
                    blockBreakEvent.setCancelled(true);
                }
                else {
                    final Collection drops = block.getDrops();
                    if (drops.size() >= 1 && drops.iterator().next().getType() != block.getType()) {
                        blockBreakEvent.setCancelled(true);
                        block.getWorld().dropItemNaturally(block.getLocation().add(s.RAND.nextFloat() * 0.5f + 0.25, s.RAND.nextFloat() * 0.5f + 0.25, s.RAND.nextFloat() * 0.5f + 0.25), new ItemStack(block.getType()));
                        block.setType(Material.AIR);
                    }
                    else {
                        blockBreakEvent.setCancelled(false);
                    }
                }
            }
            else {
                blockBreakEvent.setCancelled(true);
            }
        }
        else if (cA.E.containsKey(player)) {
            blockBreakEvent.setCancelled(true);
        }
        else if (s.a(block.getLocation()) != null) {
            blockBreakEvent.setCancelled(!s.hasPermission((CommandSender)player, Permission.ArenaBuild));
        }
    }
}
