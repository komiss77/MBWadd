// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.stats.c;

public abstract class ct extends bS<c>
{
    @Override
    public bP.c a() {
        return bP.c.c;
    }
    
    @Override
    public String c(final Arena arena) {
        return null;
    }
}
