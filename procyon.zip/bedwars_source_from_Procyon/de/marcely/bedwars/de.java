// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import cloud.timo.TimoCloud.api.objects.ServerObject;
import cloud.timo.TimoCloud.api.TimoCloudAPI;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.d;

public class de extends cZ
{
    private d a;
    
    @Override
    public cT a() {
        return cT.e;
    }
    
    @Override
    public void onEnable() {
        final Arena b = s.b(ConfigValue.cloudsystem_arena);
        if (b == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        b.a(this.a = new d() {
            final /* synthetic */ de a = TimoCloudAPI.getBukkitAPI().getThisServer();
            private final /* synthetic */ ServerObject a = TimoCloudAPI.getBukkitAPI().getThisServer();
            private static /* synthetic */ int[] p;
            
            @Override
            public void a(final Arena arena, final a a) {
                switch (q()[a.ordinal()]) {
                    case 3:
                    case 4:
                    case 7: {
                        ServerObject.this.setExtra(ConfigValue.cloudsystem_extra.a(arena));
                        break;
                    }
                    case 5: {
                        ServerObject.this.setState(arena.b().b(arena));
                        break;
                    }
                }
            }
            
            static /* synthetic */ int[] q() {
                final int[] p = de$1.p;
                if (p != null) {
                    return p;
                }
                final int[] p2 = new int[a.values().length];
                try {
                    p2[a.a.ordinal()] = 1;
                }
                catch (NoSuchFieldError noSuchFieldError) {}
                try {
                    p2[a.f.ordinal()] = 6;
                }
                catch (NoSuchFieldError noSuchFieldError2) {}
                try {
                    p2[a.c.ordinal()] = 3;
                }
                catch (NoSuchFieldError noSuchFieldError3) {}
                try {
                    p2[a.d.ordinal()] = 4;
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
                try {
                    p2[a.b.ordinal()] = 2;
                }
                catch (NoSuchFieldError noSuchFieldError5) {}
                try {
                    p2[a.g.ordinal()] = 7;
                }
                catch (NoSuchFieldError noSuchFieldError6) {}
                try {
                    p2[a.e.ordinal()] = 5;
                }
                catch (NoSuchFieldError noSuchFieldError7) {}
                return de$1.p = p2;
            }
        });
    }
    
    @Override
    public void onDisable() {
        final Arena b = s.b(ConfigValue.cloudsystem_arena);
        if (b != null) {
            b.a(this.a);
        }
    }
}
