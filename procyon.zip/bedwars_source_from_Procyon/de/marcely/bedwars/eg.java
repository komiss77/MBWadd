// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public enum eg
{
    b("LOCAL", 0), 
    c("SQL", 1);
    
    static {
        a = new eg[] { eg.b, eg.c };
    }
    
    private eg(final String name, final int ordinal) {
    }
}
