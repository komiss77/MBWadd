// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class bo extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public bo() {
        this("This is not allowed!");
    }
    
    public bo(final String message) {
        super(message);
    }
}
