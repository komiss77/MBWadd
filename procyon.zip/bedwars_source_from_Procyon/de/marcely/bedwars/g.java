// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import org.bukkit.entity.Player;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.util.s;
import java.net.DatagramPacket;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Bukkit;
import de.marcely.bedwars.config.ConfigValue;
import java.util.HashMap;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.game.arena.Arena;
import java.util.UUID;
import java.util.Map;

public class g
{
    public Map<UUID, Arena> c;
    private Plugin plugin;
    private f a;
    private a a;
    
    public g(final Plugin plugin, final f a) {
        this.c = new HashMap<UUID, Arena>();
        this.a = g.a.b;
        if (a.h()) {
            this.plugin = plugin;
            this.a = a;
            this.open();
        }
        else {
            this.a = g.a.f;
            d.d("Failed to create communication: channel isn't registred");
        }
    }
    
    private void open() {
        this.a = g.a.c;
        this.a(new i(new A(ConfigValue.bungeecord_subchannel), this.a) {
            @Override
            public void done() {
                Bukkit.getScheduler().scheduleSyncDelayedTask(g.this.plugin, (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        if (g.this.a() == g.a.c) {
                            d.d("Got no answer from channel: Disabling channel. Retrying in 10 seconds");
                            g.a(g.this, g.a.d);
                            new BukkitRunnable() {
                                public void run() {
                                    g.this.open();
                                }
                            }.runTaskLater(g.this.plugin, 200L);
                        }
                    }
                }, 100L);
            }
        });
    }
    
    public void a(final j j) {
        j.a(this.a);
    }
    
    private void a(final i i) {
        i.a().c(i);
    }
    
    public void a(final DatagramPacket datagramPacket) {
        if (this.a().i()) {
            final String substring = new String(datagramPacket.getData()).substring(0, datagramPacket.getLength());
            if (substring.length() >= 1) {
                final String[] split = substring.split("/");
                if (s.isInteger(split[0])) {
                    final j.a a = j.a.a(Integer.valueOf(split[0]));
                    if (a == j.a.a) {
                        if (this.a() == g.a.c) {
                            final o a2 = o.a(substring);
                            if (a2 != null) {
                                MBedwars.a.setName(a2.f());
                                for (final Arena arena : s.af) {
                                    this.a(new q(arena));
                                    this.a(new q(arena));
                                }
                                this.a = g.a.e;
                                d.e("Got answer from channel: Channel is now running");
                            }
                        }
                    }
                    else if (a != j.a.b && a == j.a.c) {
                        Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)MBedwars.a, (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                final p a = p.a(substring);
                                if (a != null) {
                                    final Player player = de.marcely.bedwars.util.b.getPlayer(a.getUUID());
                                    if (player == null) {
                                        g.this.c.put(a.getUUID(), a.getArena());
                                    }
                                    else {
                                        final Arena arena = a.getArena();
                                        String b = null;
                                        if (arena != null && !arena.getPlayers().contains(player)) {
                                            b = s.b(player, arena);
                                        }
                                        if (b != null) {
                                            player.sendMessage(b);
                                            MBedwars.a.c(player);
                                        }
                                    }
                                }
                            }
                        }, 10L);
                    }
                }
                else {
                    d.d("Failed to open packet: Received a non-numeric packet");
                }
            }
        }
    }
    
    public Plugin getPlugin() {
        return this.plugin;
    }
    
    public f a() {
        return this.a;
    }
    
    public a a() {
        return this.a;
    }
    
    static /* synthetic */ void a(final g g, final a a) {
        g.a = a;
    }
    
    public enum a
    {
        b("Enabling", 0, false), 
        c("WaitChannelAnswerEnabled", 1, true), 
        d("Stopped", 2, false), 
        e("Running", 3, true), 
        f("Error", 4, false);
        
        private boolean d;
        
        static {
            a = new a[] { g.a.b, g.a.c, g.a.d, g.a.e, g.a.f };
        }
        
        private a(final String name, final int ordinal, final boolean d) {
            this.d = d;
        }
        
        public boolean i() {
            return this.d;
        }
    }
}
