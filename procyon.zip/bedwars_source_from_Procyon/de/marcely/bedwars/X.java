// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import org.spigotmc.event.entity.EntityDismountEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

@Deprecated
public class X
{
    private Player player;
    private String u;
    private ArmorStand a;
    private BukkitRunnable a;
    private static List<X> s;
    
    static {
        X.s = new ArrayList<X>();
    }
    
    public X(final Player player, final String u) {
        this.a = null;
        this.player = player;
        this.u = u;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public String getString() {
        return this.u;
    }
    
    public Entity getEntity() {
        return (Entity)this.a;
    }
    
    public void setString(final String s) {
        this.u = s;
        if (this.a != null) {
            this.a.setCustomName(s);
        }
    }
    
    public boolean exists() {
        return this.a != null && !this.a.isDead();
    }
    
    public void create() {
        if (!this.exists()) {
            X.s.add(this);
            (this.a = (ArmorStand)this.player.getWorld().spawnEntity(this.player.getLocation(), EntityType.ARMOR_STAND)).setVisible(false);
            this.a.setGravity(false);
            this.a.setSmall(true);
            this.a.setCustomName(this.u);
            this.a.setCustomNameVisible(true);
            (this.a = new BukkitRunnable() {
                public void run() {
                    X.this.a.teleport(X.this.player.getLocation().clone().add(0.0, 4.5, 0.0));
                }
            }).runTaskTimer((Plugin)MBedwars.a, 0L, 1L);
        }
    }
    
    public void remove() {
        if (this.exists()) {
            this.a.cancel();
            this.a.remove();
            X.s.remove(this);
        }
    }
    
    public static void a(final EntityDismountEvent entityDismountEvent) {
        for (final X x : X.s) {
            if (x.getEntity() != null && x.getEntity().equals(entityDismountEvent.getDismounted())) {
                x.getPlayer().setPassenger(x.getEntity());
            }
        }
    }
}
