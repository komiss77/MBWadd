// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class cq extends ct
{
    public static cq a;
    
    static {
        cq.a = new cq();
    }
    
    public String b(final c c) {
        return new StringBuilder().append(c.b()).toString();
    }
}
