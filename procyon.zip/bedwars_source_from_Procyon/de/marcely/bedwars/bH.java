// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;

public class bH extends by
{
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        playerUseExtraItemEvent.setCancelled(true);
    }
    
    @Override
    public void K() {
    }
}
