// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.util.HashMap;
import java.util.Map;

public class el
{
    private static final byte VERSION = 2;
    public static final String Y = "4.0.13";
    private static final String Z = "Q=7DTZPAd9Lvgx7R";
    private final ei a;
    private final ek a;
    private ej e;
    public Map<Byte, em> ae;
    private byte y;
    
    public el(final ei a) {
        this.ae = new HashMap<Byte, em>();
        this.y = -127;
        this.a = a;
        this.a = new eh(this);
        this.e = ej.b;
    }
    
    public void a(final ei.a a) {
        this.a(ej.b);
        if (a == null) {
            return;
        }
        this.a.a(a);
    }
    
    public void run() {
        this.a(ej.c);
        final es es = new es();
        es.k = 2;
        es.aa = "4.0.13";
        es.ab = "Q=7DTZPAd9Lvgx7R";
        es.B = 0;
        this.a(es);
    }
    
    public void a(final ej e) {
        this.e = e;
    }
    
    public void a(final byte[] array) {
        try {
            final ex a = ex.a(new BufferedReadStream(array));
            if (a != null) {
                this.a.a(a, this.e);
            }
            else {
                d.n("Received unkown packet with the ID '" + array[0] + "'");
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final ex ex) {
        final BufferedWriteStream bufferedWriteStream = new BufferedWriteStream();
        try {
            ex.write(bufferedWriteStream);
            this.a.a().sendBinary(bufferedWriteStream.toByteArray());
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
        }
    }
    
    public void a(final de.marcely.bedwars.extlibrary.d d, final em em) {
        final byte y = this.y;
        this.y = (byte)(y + 1);
        final byte b = y;
        this.ae.put(b, em);
        final eo eo = new eo();
        eo.a = d.a;
        eo.version = d.version;
        eo.e = d.e;
        eo.z = b;
        this.a(eo);
    }
    
    public ei a() {
        return this.a;
    }
    
    public ej a() {
        return this.e;
    }
}
