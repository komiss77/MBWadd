// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.inventivetalent.nicknamer.NickNamerPlugin;
import org.inventivetalent.nicknamer.api.NickManager;

public class dq extends dp
{
    private NickManager a;
    
    @Override
    public cT a() {
        return cT.h;
    }
    
    @Override
    public void onEnable() {
        this.a = ((NickNamerPlugin)Bukkit.getPluginManager().getPlugin("NickNamer")).getAPI();
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String c(final Player player) {
        if (this.a.isNicked(player.getUniqueId())) {
            return this.a.getNick(player.getUniqueId());
        }
        return null;
    }
    
    @Override
    public String d(final Player player) {
        return null;
    }
}
