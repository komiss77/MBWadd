// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.api.gui.GUIItem;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.Material;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.api.gui.AnvilGUI;
import de.marcely.bedwars.api.gui.Clickable;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryType;
import de.marcely.bedwars.api.gui.SimpleGUI;
import de.marcely.bedwars.api.gui.GUI;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

public class aK
{
    public static void a(final InventoryClickEvent inventoryClickEvent) {
        final Player player = (Player)inventoryClickEvent.getWhoClicked();
        if (GUI.openInventories.containsKey(player)) {
            final SimpleGUI simpleGUI = GUI.openInventories.get(player);
            if (inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() == InventoryType.PLAYER && inventoryClickEvent.isShiftClick() && simpleGUI.isCancellable()) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
            if (((inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() != InventoryType.PLAYER) || inventoryClickEvent.getClick() == ClickType.DOUBLE_CLICK) && simpleGUI.isCancellable()) {
                inventoryClickEvent.setCancelled(true);
                if (simpleGUI instanceof Clickable) {
                    final GUIItem item = ((Clickable)simpleGUI).getItemAt(inventoryClickEvent.getSlot());
                    if (item != null) {
                        item.onClick(player, inventoryClickEvent.isLeftClick(), inventoryClickEvent.isShiftClick());
                    }
                }
                else if (simpleGUI instanceof AnvilGUI && inventoryClickEvent.getSlot() == 2) {
                    final AnvilGUI anvilGUI = (AnvilGUI)simpleGUI;
                    if (anvilGUI.getWroteListener() != null) {
                        final ItemStack item2 = inventoryClickEvent.getInventory().getItem(2);
                        if (item2 != null) {
                            final String b = i.b(item2);
                            if (Version.a().getVersionNumber() >= 13) {
                                item2.setType(Material.AIR);
                            }
                            if (b.length() >= 1) {
                                player.closeInventory();
                                anvilGUI.getWroteListener().run(i.b(item2));
                            }
                        }
                    }
                }
            }
        }
        final Arena a = s.a(player);
        if (a != null) {
            if (a.b().F()) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
            if (a.b() == ArenaStatus.f && !ConfigValue.armor_interactable && inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().getType() == InventoryType.PLAYER && inventoryClickEvent.getSlotType() == InventoryType.SlotType.ARMOR) {
                inventoryClickEvent.setCancelled(true);
                return;
            }
        }
        if (cA.E.containsKey(player)) {
            inventoryClickEvent.setCancelled(true);
        }
    }
}
