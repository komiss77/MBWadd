// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class bp extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public bp() {
        this("Not synchronized!");
    }
    
    public bp(final String message) {
        super(message);
    }
}
