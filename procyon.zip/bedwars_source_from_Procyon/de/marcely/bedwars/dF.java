// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.Team;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dF extends dI
{
    public dF() {
        super("current-team");
    }
    
    @Override
    protected String a(final Player player, final Arena arena) {
        final Team a = arena.a(player);
        return (a != null) ? a.a((CommandSender)player, true) : "";
    }
}
