// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.Listener;

public class as implements Listener
{
    public static boolean u;
    
    static {
        as.u = false;
    }
    
    @EventHandler
    public void a(final PlayerJoinEvent playerJoinEvent) {
        aY.a(playerJoinEvent);
    }
    
    @EventHandler
    public void a(final PlayerQuitEvent playerQuitEvent) {
        bc.a(playerQuitEvent);
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void a(final PlayerDeathEvent playerDeathEvent) {
        aR.a(playerDeathEvent);
    }
    
    @EventHandler
    public void a(final EntityDeathEvent entityDeathEvent) {
        aF.a(entityDeathEvent);
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final PlayerRespawnEvent playerRespawnEvent) {
        bd.a(playerRespawnEvent);
    }
    
    @EventHandler
    public void a(final InventoryClickEvent inventoryClickEvent) {
        aK.a(inventoryClickEvent);
    }
    
    @EventHandler
    public void a(final InventoryDragEvent inventoryDragEvent) {
        aM.a(inventoryDragEvent);
    }
    
    @EventHandler
    public void a(final InventoryCloseEvent inventoryCloseEvent) {
        aL.a(inventoryCloseEvent);
    }
    
    @EventHandler
    public void a(final PlayerInteractEntityEvent playerInteractEntityEvent) {
        as.u = true;
        aX.a(playerInteractEntityEvent);
    }
    
    @EventHandler
    public void a(final BlockBreakEvent blockBreakEvent) {
        az.a(blockBreakEvent);
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final BlockPlaceEvent blockPlaceEvent) {
        aB.a(blockPlaceEvent);
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final CreatureSpawnEvent creatureSpawnEvent) {
        aC.a(creatureSpawnEvent);
    }
    
    @EventHandler
    public void a(final PlayerTeleportEvent playerTeleportEvent) {
        be.a(playerTeleportEvent);
    }
    
    @EventHandler
    public void a(final InventoryOpenEvent inventoryOpenEvent) {
        aN.a(inventoryOpenEvent);
    }
    
    @EventHandler
    public void a(final FoodLevelChangeEvent foodLevelChangeEvent) {
        aI.a(foodLevelChangeEvent);
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final PlayerPickupItemEvent playerPickupItemEvent) {
        ba.b(playerPickupItemEvent);
    }
    
    @EventHandler
    public void a(final PlayerInteractEvent playerInteractEvent) {
        aV.a(playerInteractEvent);
    }
    
    @EventHandler
    public void a(final EntityDamageByEntityEvent entityDamageByEntityEvent) {
        aE.a(entityDamageByEntityEvent);
    }
    
    @EventHandler
    public void a(final EntityDamageEvent entityDamageEvent) {
        aD.a(entityDamageEvent);
    }
    
    @EventHandler
    public void a(final PlayerMoveEvent playerMoveEvent) {
        aZ.a(playerMoveEvent);
    }
    
    @EventHandler
    public void a(final PlayerToggleFlightEvent playerToggleFlightEvent) {
        bf.a(playerToggleFlightEvent);
    }
    
    @EventHandler
    public void a(final PlayerGameModeChangeEvent playerGameModeChangeEvent) {
        aU.a(playerGameModeChangeEvent);
    }
    
    @EventHandler
    public void a(final PlayerDropItemEvent playerDropItemEvent) {
        aS.a(playerDropItemEvent);
    }
    
    @EventHandler
    public void a(final EntityExplodeEvent entityExplodeEvent) {
        aG.a(entityExplodeEvent);
    }
    
    @EventHandler
    public void a(final ServerListPingEvent serverListPingEvent) {
        ax.a(serverListPingEvent);
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final AsyncPlayerChatEvent asyncPlayerChatEvent) {
        aP.a(asyncPlayerChatEvent);
    }
    
    @EventHandler
    public void a(final PlayerExpChangeEvent playerExpChangeEvent) {
        aT.a(playerExpChangeEvent);
    }
    
    @EventHandler
    public void a(final WeatherChangeEvent weatherChangeEvent) {
        bi.a(weatherChangeEvent);
    }
    
    @EventHandler
    public void a(final EntityTeleportEvent entityTeleportEvent) {
        aH.a(entityTeleportEvent);
    }
    
    @EventHandler
    public void a(final PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        aQ.a(playerCommandPreprocessEvent);
    }
    
    @EventHandler
    public void a(final WorldLoadEvent worldLoadEvent) {
        bj.a(worldLoadEvent);
    }
    
    @EventHandler
    public void a(final ChunkLoadEvent chunkLoadEvent) {
        bg.a(chunkLoadEvent);
    }
    
    @EventHandler
    public void a(final PlayerPortalEvent playerPortalEvent) {
        bb.a(playerPortalEvent);
    }
    
    @EventHandler
    public void a(final PlayerBedEnterEvent playerBedEnterEvent) {
        aO.a(playerBedEnterEvent);
    }
    
    @EventHandler
    public void a(final CraftItemEvent craftItemEvent) {
        aJ.a(craftItemEvent);
    }
    
    @EventHandler
    public void a(final ChunkUnloadEvent chunkUnloadEvent) {
        bh.b(chunkUnloadEvent);
    }
    
    @EventHandler
    public void a(final PluginDisableEvent pluginDisableEvent) {
        aw.a(pluginDisableEvent);
    }
}
