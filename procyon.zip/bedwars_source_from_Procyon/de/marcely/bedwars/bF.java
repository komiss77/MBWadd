// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.awt.Color;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.Location;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.metadata.Metadatable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class bF extends by implements Listener
{
    private static final String E = "MBW_EI_TP_USE";
    private Player player;
    private int slot;
    private BukkitTask d;
    private float c;
    private int W;
    private int X;
    private a a;
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        final Arena arena = (Arena)playerUseExtraItemEvent.getArena();
        final ItemStack item = playerUseExtraItemEvent.getItem();
        if (System.currentTimeMillis() - s.a((Metadatable)player, "MBW_EI_TP_USE", 0L) <= ConfigValue.teleporter_countdown * 1000) {
            this.done();
            return;
        }
        s.a(player, Achievement.q);
        Sound.EXTRAITEM_TELEPORTER_USE.play(player);
        if (!ConfigValue.teleporter_countdown_enabled) {
            this.L();
            arena.a(player, arena.a().a(arena.a(player)).toBukkit(arena.getWorld()));
            this.done();
            return;
        }
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
        player.setMetadata("MBW_EI_TP_USE", (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)System.currentTimeMillis()));
        s.a((CommandSender)player, b.a(Language.Teleporter));
        this.player = playerUseExtraItemEvent.getPlayer();
        this.X = ConfigValue.teleporter_countdown * 20;
        this.c = player.getExp();
        this.W = player.getLevel();
        this.slot = player.getInventory().getHeldItemSlot();
        this.a = new a(null);
        if (bx.b.getItemStack().getType() == Material.SULPHUR) {
            item.setType(Material.GLOWSTONE_DUST);
        }
        this.d = new BukkitRunnable() {
            public void run() {
                if (bF.this.X == 0) {
                    item.setAmount(item.getAmount() - 1);
                    if (item.getAmount() <= 0) {
                        player.getInventory().setItem(bF.this.slot, new ItemStack(Material.AIR));
                    }
                    else {
                        item.setType(bx.b.getItemStack().getType());
                        player.getInventory().setItem(bF.this.slot, item);
                    }
                    if (arena != null) {
                        arena.a(player, s.b(arena.a().a(arena.a(player)).toBukkit(arena.getWorld())));
                    }
                    by.this.done();
                    return;
                }
                bF.this.tick();
                bF.this.a.c(bF.this);
            }
        }.runTaskTimer((Plugin)MBedwars.a, 0L, 1L);
    }
    
    @Override
    public void K() {
        if (this.d != null) {
            HandlerList.unregisterAll((Listener)this);
            this.player.removeMetadata("MBW_EI_TP_USE", (Plugin)MBedwars.a);
            this.d.cancel();
            this.a.d(this);
            this.player.setExp(this.c);
            this.player.setLevel(this.W);
            final ItemStack item = this.player.getInventory().getItem(this.slot);
            if (item != null) {
                item.setType(bx.b.getItemStack().getType());
            }
        }
    }
    
    private void tick() {
        this.player.setExp((float)(this.X / (double)(ConfigValue.teleporter_countdown * 20)));
        this.player.setLevel(this.X / 20 + 1);
        --this.X;
        int n = this.X / 15;
        if (n <= 2) {
            n = 2;
        }
        else if (n > 25) {
            n = 25;
        }
        if (this.X % n == 0) {
            Sound.TELEPORTER_COUNTING.play(this.player.getLocation());
        }
    }
    
    @EventHandler
    protected void a(final InventoryClickEvent inventoryClickEvent) {
        if (inventoryClickEvent.getWhoClicked() == this.player && inventoryClickEvent.getSlot() == this.slot) {
            inventoryClickEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    protected void a(final PlayerDropItemEvent playerDropItemEvent) {
        if (playerDropItemEvent.getPlayer() == this.player && playerDropItemEvent.getPlayer().getInventory().getHeldItemSlot() == this.slot) {
            playerDropItemEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    protected void a(final PlayerMoveEvent playerMoveEvent) {
        if (playerMoveEvent.getPlayer() == this.player && playerMoveEvent.getFrom().distance(playerMoveEvent.getTo()) >= 0.2) {
            s.a((CommandSender)this.player, b.a(Language.Teleporter_Failed));
            this.done();
        }
    }
    
    private static class a
    {
        final float d = 1.75f;
        final float e;
        int Y;
        float y;
        
        private a() {
            this.e = 1.75f / (ConfigValue.teleporter_countdown * 20.0f);
            this.Y = 0;
            this.y = 0.0f;
        }
        
        public void c(final bF bf) {
            if (this.y < 1.75f) {
                if (this.Y < 360) {
                    this.Y += 5;
                    this.a(this.y, (float)this.Y, bf.player.getLocation().add(0.0, (double)this.y, 0.0).clone(), 1.75f);
                }
                else {
                    this.Y = 0;
                }
                this.y += this.e;
            }
        }
        
        private void a(final float n, final float n2, final Location location, final float n3) {
            final float n4 = n / n3;
            final double radians = Math.toRadians(n2);
            final double radians2 = Math.toRadians(n2 + 120.0f);
            final double radians3 = Math.toRadians(n2 + 240.0f);
            location.add(Math.cos(radians) * 1.0, 0.0, Math.sin(radians) * 2.0);
            this.b(location, n4);
            location.subtract(Math.cos(radians) * 1.0, 0.0, Math.sin(radians) * 1.0);
            location.add(Math.cos(radians2) * 1.0, 0.0, Math.sin(radians2) * 1.0);
            this.b(location, n4);
            location.subtract(Math.cos(radians2) * 1.0, 0.0, Math.sin(radians2) * 1.0);
            location.add(Math.cos(radians3) * 1.0, 0.0, Math.sin(radians3) * 1.0);
            this.b(location, n4);
            location.subtract(Math.cos(radians3) * 1.0, 0.0, Math.sin(radians3) * 1.0);
        }
        
        private void b(final Location location, final float h) {
            final Iterator<Player> iterator = de.marcely.bedwars.util.b.getOnlinePlayers().iterator();
            while (iterator.hasNext()) {
                VarParticle.PARTICLE_COLOURED.play(iterator.next(), location, s.a(Color.getHSBColor(h, 1.0f, 1.0f)));
            }
        }
        
        public void d(final bF bf) {
            new BukkitRunnable(bf) {
                final Location loc = bf.player.getLocation().clone();
                final float f = a.this.y;
                float g = 0.0f;
                
                public void run() {
                    float n = this.f - this.g;
                    while ((n -= 0.3f) > 0.0f) {
                        a.this.a(n, (float)a.this.Y, this.loc.clone().add(0.0, (double)n, 0.0), this.f);
                    }
                    this.g += 0.05f;
                    if (this.g >= this.f) {
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
        }
    }
}
