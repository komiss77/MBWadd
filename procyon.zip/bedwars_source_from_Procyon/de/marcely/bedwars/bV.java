// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.r;
import de.marcely.bedwars.game.arena.Arena;

public class bV extends bS<Arena>
{
    public static bV a;
    
    static {
        bV.a = new bV();
    }
    
    @Override
    public bP.c a() {
        return bP.c.e;
    }
    
    @Override
    public String c(final Arena arena) {
        if (arena.a == null) {
            return Language.Countdown_Stopped.getMessage();
        }
        return String.valueOf(r.a(new StringBuilder().append((int)Math.floor(arena.a.getValue() / 60)).toString(), '0', 2)) + ":" + r.a(new StringBuilder().append(arena.a.getValue() % 60).toString(), '0', 2);
    }
}
