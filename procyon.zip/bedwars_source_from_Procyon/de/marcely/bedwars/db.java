// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.dytanic.cloudnet.wrapper.Wrapper;
import de.dytanic.cloudnet.ext.bridge.bukkit.BukkitCloudNetHelper;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.d;

public class db extends cZ
{
    private d a;
    private Arena arena;
    private static /* synthetic */ int[] l;
    
    @Override
    public cT a() {
        return cT.c;
    }
    
    @Override
    public void onEnable() {
        this.arena = s.b(ConfigValue.cloudsystem_arena);
        if (this.arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.a = new d() {
            @Override
            public void a(final Arena arena, final a a) {
                db.this.b(arena, a);
            }
        };
        this.arena.a(this.a);
    }
    
    private void b(final Arena arena, final d.a a) {
        if (a == d.a.e && arena.b() == ArenaStatus.f) {
            BukkitCloudNetHelper.changeToIngame();
            return;
        }
        BukkitCloudNetHelper.setState(a(arena.b()));
        BukkitCloudNetHelper.setExtra(ConfigValue.cloudsystem_extra.a(arena));
        Wrapper.getInstance().publishServiceInfoUpdate();
    }
    
    private static String a(final ArenaStatus arenaStatus) {
        switch (m()[arenaStatus.ordinal()]) {
            case 3: {
                return "ingame";
            }
            case 2: {
                return "lobby";
            }
            default: {
                return "offline";
            }
        }
    }
    
    @Override
    public void onDisable() {
        if (this.arena != null) {
            this.arena.a(this.a);
        }
    }
    
    static /* synthetic */ int[] m() {
        final int[] l = db.l;
        if (l != null) {
            return l;
        }
        final int[] i = new int[ArenaStatus.values().length];
        try {
            i[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            i[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            i[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return db.l = i;
    }
}
