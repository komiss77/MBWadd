// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.flag.Value;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.flag.d;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class H extends NormalPacket
{
    public String name;
    public d a;
    
    @Override
    public byte getPacketID() {
        return 32;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
        this.a.write(bufferedWriteStream);
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
        this.a = (d)Value.a(bufferedReadStream);
    }
}
