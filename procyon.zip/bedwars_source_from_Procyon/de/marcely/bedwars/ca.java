// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class ca extends bZ
{
    public static ca a;
    
    static {
        ca.a = new ca();
    }
    
    @Override
    public bP.c a() {
        return bP.c.a;
    }
    
    @Override
    public String c(final Arena arena) {
        return new StringBuilder().append(arena.getPlayers().size()).toString();
    }
}
