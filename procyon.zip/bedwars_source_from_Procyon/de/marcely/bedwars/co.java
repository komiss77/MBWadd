// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class co extends ct
{
    public static co a;
    
    static {
        co.a = new co();
    }
    
    public String b(final c c) {
        return new StringBuilder().append(c.getBedsDestroyed()).toString();
    }
}
