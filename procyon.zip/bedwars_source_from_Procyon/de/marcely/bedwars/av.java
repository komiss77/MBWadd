// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Location;
import java.util.List;
import de.marcely.bedwars.game.arena.h;
import java.util.Iterator;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.Material;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import java.util.Map;
import de.marcely.bedwars.game.location.XYZ;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.util.b;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;

public class av
{
    public static void a(final b b) {
        final Arena a = s.a(b.loc);
        if (a != null && a.b() == ArenaStatus.f) {
            b.a = false;
            for (final Entity entity : b.getNearbyEntities(b.loc, 3.0, 3.0, 3.0)) {
                if (entity.getType() == EntityType.SHEEP) {
                    ((Sheep)entity).setHealth(0.0);
                }
            }
            final Block block = b.loc.getBlock();
            boolean b2 = false;
            Object o = null;
            final XYZ value = XYZ.valueOf(block.getLocation());
            value.floor();
            for (final Map.Entry<String, Player> entry : a.o.entrySet()) {
                if (XYZ.ofString(entry.getKey()).equals(value)) {
                    b2 = true;
                    o = a.o.remove(entry.getKey());
                    break;
                }
            }
            final Iterator<Block> iterator3 = b.A.iterator();
            while (iterator3.hasNext()) {
                final Block block2 = iterator3.next();
                if (block2.getType() == ConfigValue.bed_block) {
                    final h a2 = a.a();
                    for (final Team team : a2.r()) {
                        if (a2.a(team) != null && s.a(XYZ.valueOf(block2.getLocation()), a2.a(team))) {
                            iterator3.remove();
                            if (!ConfigValue.bed_onlydestroyablewith_tnt) {
                                continue;
                            }
                            if (!b2) {
                                continue;
                            }
                            if (ConfigValue.ownbed_destroyable || (!ConfigValue.ownbed_destroyable && team != a.a((Player)o))) {
                                block2.setType(Material.AIR);
                                a.a((Player)o, block.getLocation(), team);
                                s.a(block, ConfigValue.bed_block.name().contains("BED") ? 2 : 1);
                            }
                            else {
                                s.a((CommandSender)o, de.marcely.bedwars.message.b.a(Language.NotAllowed_BedDestroy));
                            }
                        }
                    }
                }
            }
            Block[] a3;
            for (int length = (a3 = a.a().a()).length, i = 0; i < length; ++i) {
                b.A.remove(a3[i].getRelative(BlockFace.DOWN));
            }
            final Iterator<Block> iterator5 = b.A.iterator();
            while (iterator5.hasNext()) {
                final Block block3 = iterator5.next();
                if (!ConfigValue.tnt_canbreakblocks) {
                    iterator5.remove();
                }
                else if (ConfigValue.tnt_canbreakblocks_breakby_player && !a.a(block3)) {
                    iterator5.remove();
                }
                else {
                    VarParticle.PARTICLE_SMOKE.play(b.loc.getWorld(), block3.getLocation().add(0.0, 1.0, 0.0), 1);
                }
            }
        }
    }
    
    public enum a
    {
        a("TNT", 0), 
        b("OTHER", 1);
        
        static {
            a = new a[] { av.a.a, av.a.b };
        }
        
        private a(final String name, final int ordinal) {
        }
    }
    
    public static class b
    {
        public final a c;
        public final List<Block> A;
        public final Location loc;
        public Boolean a;
        
        public b(final a c, final List<Block> a, final Location loc) {
            this.a = false;
            this.c = c;
            this.A = a;
            this.loc = loc;
        }
    }
}
