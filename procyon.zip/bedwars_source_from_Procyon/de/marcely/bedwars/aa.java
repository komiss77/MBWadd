// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.versions.Version;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.List;

@Deprecated
public class aa
{
    private List<a> t;
    private static HashMap<Player, c> c;
    private int entityId;
    private List<Player> players;
    private b a;
    
    static {
        aa.c = new HashMap<Player, c>();
    }
    
    public aa() {
        this.t = new ArrayList<a>();
        this.players = new ArrayList<Player>();
        if (Version.a().getVersionNumber() >= 8) {
            this.a = new ac();
        }
        else {
            this.a = new ab();
        }
    }
    
    public void a(final a a) {
        this.t.add(a);
    }
    
    public void b(final a a) {
        this.t.remove(a);
    }
    
    public void a(final int entityId) {
        this.entityId = entityId;
    }
    
    protected void e(final Player player) {
        if (this.players.contains(player)) {
            return;
        }
        this.players.add(player);
        boolean b = false;
        c value;
        if (!aa.c.containsKey(player)) {
            b = true;
            value = new c();
            value.player = player;
            aa.c.put(player, value);
        }
        else {
            value = aa.c.get(player);
        }
        value.u.add(this);
        if (b) {
            this.a.a(value);
        }
    }
    
    protected void f(final Player key) {
        if (!this.players.contains(key)) {
            return;
        }
        this.players.remove(key);
        final c c = aa.c.get(key);
        c.u.remove(this);
        if (c.u.size() == 0) {
            aa.c.remove(key);
            if (key.isOnline()) {
                try {
                    final Method method = c.d.getClass().getMethod("remove", NMSClass.J);
                    method.setAccessible(true);
                    method.invoke(c.d, c.e);
                }
                catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
                catch (InvocationTargetException ex2) {}
            }
            aa.c.remove(key);
        }
    }
    
    public static void onDisable() {
        final Iterator<Player> iterator = aa.c.keySet().iterator();
        while (iterator.hasNext()) {
            final c c = aa.c.get(iterator.next());
            try {
                final Method method = c.d.getClass().getMethod("remove", NMSClass.J);
                method.setAccessible(true);
                method.invoke(c.d, c.e);
            }
            catch (IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException ex) {
                final Throwable t;
                t.printStackTrace();
            }
            catch (InvocationTargetException ex2) {}
        }
    }
    
    public List<a> i() {
        return this.t;
    }
    
    public int getEntityId() {
        return this.entityId;
    }
    
    @Deprecated
    public static class c
    {
        public Player player;
        public Object d;
        public Object e;
        public List<aa> u;
        
        public c() {
            this.u = new ArrayList<aa>();
        }
    }
    
    public interface a
    {
        void g(final Player p0);
        
        void h(final Player p0);
    }
    
    @Deprecated
    public interface b
    {
        void a(final c p0);
    }
}
