// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.List;
import de.marcely.bedwars.util.s;
import net.minecraft.util.io.netty.channel.ChannelPromise;
import net.minecraft.util.io.netty.channel.ChannelHandlerContext;
import java.lang.reflect.Field;
import java.util.NoSuchElementException;
import java.lang.reflect.InvocationTargetException;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.NMSClass;
import net.minecraft.util.io.netty.channel.Channel;
import net.minecraft.util.io.netty.channel.ChannelHandler;
import net.minecraft.util.io.netty.channel.ChannelDuplexHandler;

@ChannelHandler.Sharable
public class dW extends ChannelDuplexHandler implements dZ
{
    private final dY a;
    private Channel channel;
    private boolean ae;
    
    public dW(final dY a) {
        this.channel = null;
        this.ae = false;
        this.a = a;
    }
    
    public dY a() {
        return this.a;
    }
    
    public boolean isInjected() {
        return this.channel != null && this.channel.isActive() && this.channel.pipeline().names().contains("MBedwars_NI");
    }
    
    public boolean inject() {
        if (this.isInjected()) {
            return false;
        }
        try {
            final Object cast = NMSClass.m.cast(this.a.getPlayer());
            final Object invoke = cast.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(cast, new Object[0]);
            final Object value = invoke.getClass().getDeclaredField("playerConnection").get(invoke);
            final Object value2 = value.getClass().getDeclaredField("networkManager").get(value);
            final Field declaredField = value2.getClass().getDeclaredField((Version.a().t() >= 2) ? "m" : "k");
            declaredField.setAccessible(true);
            this.channel = (Channel)declaredField.get(value2);
            try {
                this.channel.pipeline().addBefore("packet_handler", "MBedwars_NI", (ChannelHandler)this);
            }
            catch (IllegalArgumentException ex) {
                this.channel.pipeline().remove("MBedwars_NI");
                this.channel.pipeline().addBefore("packet_handler", "MBedwars_NI", (ChannelHandler)this);
            }
        }
        catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | SecurityException | NoSuchFieldException ex2) {
            final Throwable t;
            t.printStackTrace();
        }
        catch (NoSuchElementException ex3) {
            return false;
        }
        return true;
    }
    
    public boolean Y() {
        if (!this.isInjected()) {
            return false;
        }
        try {
            this.channel.pipeline().remove("MBedwars_NI");
        }
        catch (NoSuchElementException ex) {}
        this.channel = null;
        return true;
    }
    
    public void channelRead(final ChannelHandlerContext channelHandlerContext, final Object obj) throws Exception {
        try {
            if (NMSClass.H.isInstance(obj)) {
                final Field declaredField = NMSClass.H.getDeclaredField("a");
                declaredField.setAccessible(true);
                final int int1 = declaredField.getInt(obj);
                final Field declaredField2 = NMSClass.H.getDeclaredField("action");
                declaredField2.setAccessible(true);
                final Object value = declaredField2.get(obj);
                final String s = (String)value.getClass().getMethod("name", (Class<?>[])new Class[0]).invoke(value, new Object[0]);
                if (s.equals("INTERACT")) {
                    this.a.d(int1);
                }
                else if (s.equals("ATTACK")) {
                    this.a.e(int1);
                }
            }
            else if (NMSClass.Q.isInstance(obj)) {
                final String[] c = this.a.c((String)NMSClass.Q.getDeclaredMethod("c", (Class<?>[])new Class[0]).invoke(obj, new Object[0]));
                if (c != null) {
                    Version.a().sendPacket(this.a.getPlayer(), NMSClass.P.getDeclaredConstructor(String[].class).newInstance(c));
                    return;
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        super.channelRead(channelHandlerContext, obj);
    }
    
    public void write(final ChannelHandlerContext channelHandlerContext, final Object o, final ChannelPromise channelPromise) throws Exception {
        boolean b = false;
        try {
            if (NMSClass.R.isInstance(o)) {
                final Field declaredField = NMSClass.R.getDeclaredField("a");
                declaredField.setAccessible(true);
                final long longValue = (long)declaredField.get(o);
                final Field declaredField2 = NMSClass.R.getDeclaredField("b");
                declaredField2.setAccessible(true);
                b = this.a.a(longValue, (long)declaredField2.get(o));
            }
            else if (NMSClass.ab.isInstance(o)) {
                if (cA.a(s.a(NMSClass.ab, "a").getInt(o))) {
                    s.a(NMSClass.ab, "c").set(o, 0);
                }
            }
            else if (NMSClass.K.isInstance(o)) {
                if (cA.a(s.a(NMSClass.K, "a").getInt(o))) {
                    s.a(NMSClass.K, "c").setInt(o, (int)Math.floor(-640.0));
                }
            }
            else if (NMSClass.U.isInstance(o)) {
                b = this.a.a((float)s.a(NMSClass.U, "a").get(o), (int)s.a(NMSClass.U, "b").get(o), (float)s.a(NMSClass.U, "c").get(o));
            }
            else if (NMSClass.L.isInstance(o)) {
                if ((int)s.a(NMSClass.L, "a").get(o) == this.a.getPlayer().getEntityId()) {
                    for (final Object next : (List)s.a(NMSClass.L, "b").get(o)) {
                        final int intValue = (int)s.a(next.getClass(), "b").get(next);
                        final Object value = s.a(next.getClass(), "c").get(next);
                        if (intValue == 6) {
                            b = this.a.b((float)value);
                        }
                    }
                }
            }
            else if (NMSClass.E.isInstance(o)) {
                b = this.a.a((int)s.a(NMSClass.E, "a").get(o), s.a(NMSClass.E, "b").get(o), s.a(NMSClass.E, "c").get(o));
            }
            else if (NMSClass.Y.isInstance(o)) {
                this.a.a((int)s.a(NMSClass.Y, "a").get(o), (int)s.a(NMSClass.Y, "b").get(o), this.ae);
            }
            else if (NMSClass.Z != null) {
                final int[] array = (int[])s.a(NMSClass.Z, "a").get(o);
                final int[] array2 = (int[])s.a(NMSClass.Z, "b").get(o);
                for (int i = 0; i < array.length; ++i) {
                    this.a.a(array[i], array2[i], this.ae);
                }
            }
            else if (NMSClass.ad.isInstance(o)) {
                b = this.a.Z();
                if (!b) {
                    this.ae = true;
                }
            }
            else if (NMSClass.ae.isInstance(o) && this.ae) {
                this.ae = false;
                this.a.ad();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (!b) {
            super.write(channelHandlerContext, o, channelPromise);
        }
    }
}
