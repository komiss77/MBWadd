// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.io.File;
import java.util.Random;

@Deprecated
public class Y
{
    private static final Random a;
    private File b;
    private a.b<String, Object> a;
    
    static {
        a = new Random();
    }
    
    public Y(final File file) {
        this(file, true);
    }
    
    public Y(final File file, final boolean b) {
        this.b = null;
        this.a = new a.b<String, Object>();
        this.b(file.getAbsolutePath(), b);
    }
    
    public Y(final String s, final String s2) {
        this(s, s2, true);
    }
    
    public Y(final String str, final String str2, final boolean b) {
        this.b = null;
        this.a = new a.b<String, Object>();
        this.b("plugins/" + str + "/" + str2, b);
    }
    
    public void r(final String s) {
        this.a.put(s, null);
    }
    
    public void addConfig(final String s, final Object o) {
        this.a.put(s, o);
    }
    
    public void j(final String s, final String s2) {
        this.a.put(s, s2);
    }
    
    public void a(final String s, final boolean b) {
        this.a.put(s, b);
    }
    
    public void a(final String s, final Double n) {
        this.a.put(s, n);
    }
    
    public void a(final String s, final int i) {
        this.a.put(s, i);
    }
    
    public void addComment(final String str) {
        this.j("# " + str, "");
    }
    
    public String getConfigString(final String s) {
        final Object a = this.a(s);
        if (a instanceof String) {
            return (String)a;
        }
        return null;
    }
    
    public Boolean getConfigBoolean(final String s) {
        final Object a = this.a(s);
        if (a instanceof Boolean) {
            return (boolean)a;
        }
        if (a instanceof String) {
            final String value = String.valueOf(a);
            if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
                return Boolean.valueOf(value);
            }
        }
        return null;
    }
    
    public Double getConfigDouble(final String s) {
        final Object a = this.a(s);
        if (a instanceof Double) {
            return (double)a;
        }
        if (a instanceof Float) {
            return (double)(float)a;
        }
        if (a instanceof String) {
            return Double.valueOf((String)a);
        }
        return null;
    }
    
    public Integer getConfigInt(final String s) {
        final Object a = this.a(s);
        if (a instanceof String && c(String.valueOf(a))) {
            return Integer.valueOf(String.valueOf(a));
        }
        return null;
    }
    
    public void addEmptyLine() {
        this.j("empty" + Y.a.nextInt(), null);
    }
    
    public a.b<String, String> a(final String prefix) {
        final a.b<String, String> b = new a.b<String, String>();
        for (final a.a<String, Object> a : this.a.entrySet()) {
            final String s = a.getKey();
            if (s.startsWith(prefix)) {
                if (a.getValue() != null) {
                    b.put(s, a.getValue().toString());
                }
                else {
                    b.put(s, null);
                }
            }
        }
        return b;
    }
    
    public a.b<String, String> b(final String suffix) {
        final a.b<String, String> b = new a.b<String, String>();
        for (final a.a<String, Object> a : this.a.entrySet()) {
            final String s = a.getKey();
            if (s.endsWith(suffix)) {
                if (a.getValue() != null) {
                    b.put(s, a.getValue().toString());
                }
                else {
                    b.put(s, null);
                }
            }
        }
        return b;
    }
    
    public a.b<String, String> c(final String anObject) {
        final a.b<String, String> b = new a.b<String, String>();
        for (final a.a<String, Object> a : this.a.entrySet()) {
            final String s = a.getKey();
            if (s.equals(anObject)) {
                if (a.getValue() != null) {
                    b.put(s, a.getValue().toString());
                }
                else {
                    b.put(s, null);
                }
            }
        }
        return b;
    }
    
    public Object a(final String s) {
        return this.a.getFirst(s);
    }
    
    public boolean update() {
        if (!this.b.exists()) {
            this.save();
            return false;
        }
        return true;
    }
    
    public a.b<String, Object> a(final int n) {
        final a.b<String, Object> b = new a.b<String, Object>();
        for (final a.a<String, Object> a : this.a.entrySet()) {
            final String obj = a.getKey();
            String value = a.getValue();
            if (!String.valueOf(obj).startsWith("# ") && obj.split("\\.").length - 1 == n) {
                String s = "";
                int n2 = 1;
                final int length = obj.split("\\.").length;
                String[] split;
                for (int length2 = (split = obj.split("\\.")).length, i = 0; i < length2; ++i) {
                    String substring;
                    for (substring = split[i]; substring.startsWith("\t"); substring = substring.substring(1, substring.length())) {}
                    if (n2 >= length) {
                        s = String.valueOf(s) + substring;
                    }
                    else {
                        s = String.valueOf(s) + substring + ".";
                        ++n2;
                    }
                }
                if (value instanceof String) {
                    String substring2;
                    for (substring2 = value; substring2.startsWith("\t"); substring2 = substring2.substring(1, substring2.length())) {}
                    value = substring2;
                }
                b.put(s, value);
            }
        }
        return b;
    }
    
    public void save() {
        try {
            this.p();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void p() throws IOException {
        if (this.b.exists()) {
            this.b.delete();
        }
        final BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.b), "UTF8"));
        final ArrayList<String> list = new ArrayList<String>();
        for (final a.a<String, Object> a : this.a.entrySet()) {
            final String s = a.getKey();
            final Object value = a.getValue();
            if (s.startsWith("empty") && value == null) {
                bufferedWriter.write("");
                bufferedWriter.newLine();
            }
            else if (!String.valueOf(s).startsWith("# ")) {
                if (s.split("\\.").length >= 2) {
                    String target = "";
                    for (int i = 0; i < s.split("\\.").length - 1; ++i) {
                        if (i <= s.split("\\.").length - 2) {
                            target = String.valueOf(target) + s.split("\\.")[i];
                        }
                        else {
                            target = String.valueOf(target) + s.split("\\.")[i] + ".";
                        }
                    }
                    if (list.contains(target)) {
                        continue;
                    }
                    bufferedWriter.write(String.valueOf(target) + " {");
                    bufferedWriter.newLine();
                    for (final a.a<String, Object> a2 : this.a.entrySet()) {
                        final String obj = a2.getKey();
                        final Object value2 = a2.getValue();
                        if (!String.valueOf(obj).startsWith("# ") && obj.split("\\.").length >= 2) {
                            String anObject = "";
                            for (int j = 0; j < obj.split("\\.").length - 1; ++j) {
                                if (j <= obj.split("\\.").length - 2) {
                                    anObject = String.valueOf(anObject) + obj.split("\\.")[j];
                                }
                                else {
                                    anObject = String.valueOf(anObject) + obj.split("\\.")[j] + ".";
                                }
                            }
                            if (!target.equals(anObject)) {
                                continue;
                            }
                            String string = "";
                            for (int k = 0; k < obj.split("\\.").length - 1; ++k) {
                                string = String.valueOf(string) + "\t";
                            }
                            if (value2 != null) {
                                bufferedWriter.write(String.valueOf(string) + obj.replace(target, "").substring(1) + ": " + String.valueOf(value2));
                            }
                            else {
                                bufferedWriter.write(String.valueOf(string) + obj.replace(target, "").substring(1));
                            }
                            bufferedWriter.newLine();
                        }
                    }
                    list.add(target);
                    bufferedWriter.write("");
                    bufferedWriter.newLine();
                }
                else {
                    if (value != null) {
                        bufferedWriter.write(String.valueOf(s) + ": " + String.valueOf(value));
                    }
                    else {
                        bufferedWriter.write(s);
                    }
                    bufferedWriter.newLine();
                }
            }
            else {
                bufferedWriter.write(s);
                bufferedWriter.newLine();
            }
        }
        bufferedWriter.close();
    }
    
    public void load() {
        this.b(true);
    }
    
    public void b(final boolean b) {
        BufferedReader bufferedReader = null;
        try {
            if (!b) {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(this.b)));
            }
            else {
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(this.b), "UTF8"));
            }
        }
        catch (Exception ex) {
            System.err.println("[MBedwars] There was an issue with loading a config with utf8.");
            if (!b) {
                ex.printStackTrace();
            }
            else {
                this.b(false);
            }
        }
        String obj = "";
        try {
            this.clear();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                boolean b2 = false;
                if (line.endsWith("{")) {
                    String s;
                    for (s = line.substring(0, line.length() - 1); s.startsWith("\t"); s = s.substring(1, s.length())) {}
                    while (s.endsWith(" ")) {
                        s = s.substring(0, s.length() - 1);
                    }
                    if (obj.equals("")) {
                        obj = String.valueOf(obj) + s;
                    }
                    else {
                        obj = String.valueOf(obj) + "." + s;
                    }
                    b2 = true;
                }
                else if (line.startsWith("") && !line.equals("")) {
                    final String[] split = obj.split("\\.");
                    obj = obj.substring(0, obj.length() - split[split.length - 1].length());
                    b2 = true;
                }
                if (!b2) {
                    final String[] split2 = line.split(":");
                    String substring = split2[0];
                    String s2 = "";
                    int i = 1;
                    if (split2.length >= 2) {
                        while (i < split2.length) {
                            if (i > 1) {
                                s2 = String.valueOf(s2) + ":" + split2[i];
                            }
                            else {
                                s2 = String.valueOf(s2) + split2[i];
                            }
                            ++i;
                        }
                    }
                    else {
                        s2 = null;
                    }
                    if (s2 != null) {
                        while (s2.startsWith("\t") || s2.startsWith(" ")) {
                            s2 = s2.substring(1, s2.length());
                        }
                    }
                    while (substring.startsWith("\t") || substring.startsWith(" ")) {
                        substring = substring.substring(1, substring.length());
                    }
                    if (obj.equals("")) {
                        this.a.put(substring, s2);
                    }
                    else {
                        this.a.put(String.valueOf(obj) + "." + substring, s2);
                    }
                }
            }
            bufferedReader.close();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
    }
    
    public List<String> c(final String obj) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final a.a<String, String> a : this.a(obj).entrySet()) {
            String s;
            for (s = String.valueOf(a.getKey().replaceFirst(obj.endsWith(".") ? obj : new StringBuilder(String.valueOf(obj)).append(".").toString(), "")) + ((a.getValue() != null) ? (": " + a.getValue()) : ""); s.startsWith("\t") || s.startsWith(" "); s = s.substring(1, s.length())) {}
            list.add(s);
        }
        return list;
    }
    
    public void clear() {
        this.a.clear();
    }
    
    public boolean exists() {
        return this.b.exists();
    }
    
    public boolean isEmpty() {
        return this.b.length() == 0L;
    }
    
    public void setPath(final String s) {
        this.b(s, true);
    }
    
    public void b(final String pathname, final boolean b) {
        this.b = new File(pathname);
        final File parentFile = this.b.getParentFile();
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        if (b && !this.b.exists()) {
            try {
                this.b.createNewFile();
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public String getPath() {
        return this.b.getPath();
    }
    
    public File getFile() {
        return this.b;
    }
    
    public a.b<String, Object> a() {
        return this.a;
    }
    
    private static boolean c(final String s) {
        try {
            Integer.valueOf(s);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    public static class a
    {
        public static class a<obj1, obj2> implements Map.Entry<obj1, obj2>
        {
            private obj1 b;
            private obj2 c;
            
            public a(final obj1 b, final obj2 c) {
                this.b = b;
                this.c = c;
            }
            
            @Override
            public obj1 getKey() {
                return this.b;
            }
            
            @Override
            public obj2 getValue() {
                return this.c;
            }
            
            @Override
            public obj2 setValue(final obj2 c) {
                return this.c = c;
            }
        }
        
        public static class b<obj1, obj2>
        {
            List<obj1> l1;
            List<obj2> l2;
            
            public b() {
                this.l1 = new ArrayList<obj1>();
                this.l2 = new ArrayList<obj2>();
            }
            
            public b(final b<obj1, obj2> b) {
                this.l1 = new ArrayList<obj1>();
                this.l2 = new ArrayList<obj2>();
                this.l1 = new ArrayList<obj1>((Collection<? extends obj1>)b.l1);
                this.l2 = new ArrayList<obj2>((Collection<? extends obj2>)b.l2);
            }
            
            public int size() {
                return this.l1.size();
            }
            
            public void put(final obj1 obj1, final obj2 obj2) {
                this.l1.add(obj1);
                this.l2.add(obj2);
            }
            
            public obj2 getFirst(final obj1 obj1) {
                if (this.get(obj1).size() >= 1) {
                    return this.get(obj1).get(0);
                }
                return null;
            }
            
            public List<obj2> get(final obj1 obj1) {
                final ArrayList<obj2> list = new ArrayList<obj2>();
                int n = 0;
                final Iterator<obj1> iterator = this.l1.iterator();
                while (iterator.hasNext()) {
                    if (obj1.equals(iterator.next())) {
                        list.add(this.l2.get(n));
                    }
                    ++n;
                }
                return list;
            }
            
            public List<Y.a.a<obj1, obj2>> entrySet() {
                final ArrayList<Y.a.a<Object, obj2>> list = (ArrayList<Y.a.a<Object, obj2>>)new ArrayList<Y.a.a<obj1, obj2>>();
                int n = 0;
                final Iterator<obj1> iterator = new ArrayList<obj1>((Collection<? extends obj1>)this.l1).iterator();
                while (iterator.hasNext()) {
                    list.add(new Y.a.a<obj1, obj2>(iterator.next(), this.l2.get(n)));
                    ++n;
                }
                return (List<Y.a.a<obj1, obj2>>)list;
            }
            
            public void remove(final obj1 obj) {
                int n = 0;
                final Iterator<obj1> iterator = this.l1.iterator();
                while (iterator.hasNext()) {
                    if (iterator.next().equals(obj)) {
                        this.l1.remove(n);
                        this.l2.remove(n);
                    }
                    ++n;
                }
            }
            
            public void remove(final obj1 obj, final obj2 obj2) {
                int n = 0;
                final Iterator<Object> iterator = new ArrayList<Object>(this.l1).iterator();
                while (iterator.hasNext()) {
                    if (iterator.next().equals(obj) && this.l2.get(n).equals(obj2)) {
                        this.l1.remove(n);
                        this.l2.remove(n);
                        --n;
                    }
                    ++n;
                }
            }
            
            public boolean containsKey(final obj1 obj1) {
                return this.l1.contains(obj1);
            }
            
            public boolean containsValue(final obj2 obj2) {
                return this.l2.contains(obj2);
            }
            
            public void replace(final obj1 obj1, final obj2 obj2) {
                this.remove(obj1);
                this.put(obj1, obj2);
            }
            
            public List<obj1> keySet() {
                return new ArrayList<obj1>((Collection<? extends obj1>)this.l1);
            }
            
            public List<obj2> values() {
                return new ArrayList<obj2>((Collection<? extends obj2>)this.l2);
            }
            
            public boolean removeFirst() {
                if (this.size() >= 1) {
                    this.l1.remove(0);
                    this.l2.remove(0);
                    return true;
                }
                return false;
            }
            
            public boolean removeLast() {
                if (this.size() >= 1) {
                    this.l1.remove(this.l1.size() - 1);
                    this.l2.remove(this.l2.size() - 2);
                    return true;
                }
                return false;
            }
            
            public void clear() {
                this.l1.clear();
                this.l2.clear();
            }
        }
    }
}
