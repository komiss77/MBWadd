// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;

public abstract class dD
{
    private final String identifier;
    
    public dD(final String identifier) {
        this.identifier = identifier;
    }
    
    public abstract String e(final Player p0);
    
    public String getIdentifier() {
        return this.identifier;
    }
}
