// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.concurrent.ExecutionException;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.e;
import java.util.ArrayList;
import de.marcely.bedwars.game.stats.c;
import java.util.List;
import de.marcely.bedwars.util.n;
import org.bukkit.entity.Player;
import de.marcely.bedwars.holographic.i;
import org.bukkit.Location;
import de.marcely.bedwars.holographic.g;

public class cM extends cJ
{
    public cM(final g g, final Location location) {
        super(g, location);
    }
    
    @Override
    public i a() {
        return i.c;
    }
    
    @Override
    protected void D(final Player player) {
        this.a(player, list -> {
            this.f(list);
            super.D(player);
        });
    }
    
    private void a(final Player player, final n<List<String>> n) {
        s.a(c.a(player), new Runnable() {
            @Override
            public void run() {
                try {
                    final c c = de.marcely.bedwars.game.stats.c.a(player).get();
                    final ArrayList<String> list = new ArrayList<String>();
                    final Iterator<String> iterator = e.m.iterator();
                    while (iterator.hasNext()) {
                        list.add(iterator.next().replace("{player}", player.getName()).replace("{kd}", new StringBuilder().append(c.b()).toString()).replace("{wl}", new StringBuilder().append(c.a()).toString()).replace("{wins}", new StringBuilder().append(c.getWins()).toString()).replace("{loses}", new StringBuilder().append(c.getLoses()).toString()).replace("{kills}", new StringBuilder().append(c.getKills()).toString()).replace("{deaths}", new StringBuilder().append(c.getDeaths()).toString()).replace("{bedsdestroyed}", new StringBuilder().append(c.getBedsDestroyed()).toString()).replace("{roundsplayed}", new StringBuilder().append(c.getRoundsPlayed()).toString()).replace("{playtime}", s.a(c.getPlayTime())).replace("{uuid}", player.getUniqueId().toString()).replace("{world}", player.getWorld().getName()).replace("{rank}", new StringBuilder().append((c.getRank() != -1) ? Integer.valueOf(c.getRank()) : de.marcely.bedwars.message.b.a(Language.Ranking_Unranked).f((CommandSender)player)).toString()));
                    }
                    n.call(list);
                }
                catch (InterruptedException | ExecutionException ex) {
                    final Throwable t;
                    t.printStackTrace();
                }
            }
        });
    }
}
