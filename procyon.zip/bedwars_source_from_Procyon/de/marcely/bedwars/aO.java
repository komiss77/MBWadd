// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.event.player.PlayerBedEnterEvent;

public class aO
{
    public static void a(final PlayerBedEnterEvent playerBedEnterEvent) {
        final Arena a = s.a(playerBedEnterEvent.getPlayer());
        if (a != null && ((a.b() == ArenaStatus.f && !ConfigValue.interacting) || a.b() != ArenaStatus.f) && ((a.b() == ArenaStatus.f && !ConfigValue.interacting) || a.b() != ArenaStatus.f)) {
            playerBedEnterEvent.setCancelled(true);
        }
    }
}
