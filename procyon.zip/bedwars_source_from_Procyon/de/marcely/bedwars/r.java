// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class r extends j
{
    private String g;
    
    public r(final String g) {
        this.g = g;
    }
    
    public String e() {
        return this.g;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.m.getID()) + "/" + this.e().replace("/", "&sKEYslash;");
    }
    
    public static r a(final String s) {
        final String[] split = s.split("/");
        if (split.length == 2) {
            return new r(split[1].replace("&sKEYslash;", "/"));
        }
        return null;
    }
}
