// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.extlibrary;

import java.io.IOException;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.cR;
import javax.annotation.Nullable;
import de.marcely.bedwars.util.o;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.StandardOpenOption;
import java.nio.file.OpenOption;
import java.util.Iterator;
import java.nio.file.Files;
import java.util.Collection;
import java.util.ArrayList;
import de.marcely.bedwars.util.s;
import java.util.List;
import java.io.File;
import java.io.Closeable;

public class c implements Closeable, AutoCloseable
{
    public static boolean w;
    private final File folder;
    private final b b;
    private List<d> E;
    
    static {
        c.w = false;
    }
    
    public c() {
        this(s.p);
    }
    
    public c(final File file) {
        this.folder = file;
        this.b = new b(new File(file, "library.db"));
        if (c.w) {
            de.marcely.bedwars.d.a("Send this to the dev: Debugging 0 is still enabled!");
        }
    }
    
    public void a(final Runnable runnable) {
        this.b.connect(new Runnable() {
            @Override
            public void run() {
                c.a(c.this, new ArrayList());
                c.this.E.addAll(c.this.b.a());
                c.this.u();
                runnable.run();
            }
        });
    }
    
    public void u() {
        try {
            final Iterator<d> iterator = this.E.iterator();
            while (iterator.hasNext()) {
                final d d = iterator.next();
                final File a = this.a(d);
                if (!a.exists()) {
                    iterator.remove();
                    this.b.c(d);
                }
                else {
                    final long a2 = de.marcely.bedwars.util.c.a(Files.readAllBytes(a.toPath()));
                    if (c.w || a2 == d.e) {
                        continue;
                    }
                    iterator.remove();
                    this.b.c(d);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public boolean a(final short n, final int n2, final long n3) {
        for (final d d : this.E) {
            if (d.a == n && d.version == n2 && d.e == n3) {
                return true;
            }
        }
        return false;
    }
    
    public void a(final d d, final byte[] bytes) {
        if (this.a(d.a, d.version, d.e)) {
            return;
        }
        try {
            Files.write(this.a(d).toPath(), bytes, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);
            this.b.b(d);
            this.E.add(d);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final d d, final String str) {
        if (this.a(d.a, d.version, d.e)) {
            return;
        }
        try {
            final InputStream resourceAsStream = a.getResourceAsStream(str);
            if (resourceAsStream == null) {
                throw new RuntimeException("A fatal error occured. JAR seems to be corrupted (Missing '" + str + "')");
            }
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int read;
            while ((read = resourceAsStream.read()) != -1) {
                byteArrayOutputStream.write(read);
            }
            final byte[] byteArray = byteArrayOutputStream.toByteArray();
            final long a = de.marcely.bedwars.util.c.a(byteArray);
            resourceAsStream.close();
            byteArrayOutputStream.close();
            d.e = a;
            this.a(d, byteArray);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final d d, final boolean b) throws Exception {
        o.a(this.a(d), b);
    }
    
    private boolean a(final ExtLibrary extLibrary) throws Exception {
        if (extLibrary == null) {
            return false;
        }
        if (!extLibrary.loaded) {
            final d a = this.a(extLibrary.getId());
            if (a == null) {
                return false;
            }
            this.a(a, extLibrary.y());
            extLibrary.loaded = true;
        }
        return true;
    }
    
    private File a(final d d) {
        return new File(this.folder, String.valueOf(d.a) + "." + d.name.toLowerCase().replace(" ", "_") + ".jar");
    }
    
    @Nullable
    public d a(final short n) {
        for (final d d : this.E) {
            if (d.a == n) {
                return d;
            }
        }
        return null;
    }
    
    public void loadLibraries() {
        for (final cR cr : s.b.h().values()) {
            try {
                if (!this.a(cr.a())) {
                    continue;
                }
                cr.X();
            }
            catch (Error error) {
                error.printStackTrace();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        if (ConfigValue.sql_enabled && ConfigValue.sql_type.getExtLibrary() != null) {
            try {
                this.a(ConfigValue.sql_type.getExtLibrary());
            }
            catch (Error error2) {
                error2.printStackTrace();
            }
            catch (Exception ex2) {
                ex2.printStackTrace();
            }
        }
    }
    
    @Override
    public void close() throws IOException {
        this.b.close();
    }
    
    public File getFolder() {
        return this.folder;
    }
    
    static /* synthetic */ void a(final c c, final List e) {
        c.E = (List<d>)e;
    }
}
