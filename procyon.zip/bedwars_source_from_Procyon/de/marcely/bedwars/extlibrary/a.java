// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.extlibrary;

import de.marcely.bedwars.MBedwars;
import java.io.InputStream;

public class a
{
    public static InputStream getResourceAsStream(final String str) {
        return MBedwars.a.getResource("de/marcely/bedwars/extlibrary/" + str);
    }
}
