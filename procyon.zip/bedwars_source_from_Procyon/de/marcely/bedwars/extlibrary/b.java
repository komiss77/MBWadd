// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.extlibrary;

import java.sql.ResultSet;
import de.marcely.bedwars.sql.SQLResult;
import java.util.ArrayList;
import java.util.Collection;
import de.marcely.bedwars.sql.SQLTask;
import de.marcely.bedwars.sql.EmptySQLTask;
import java.io.IOException;
import de.marcely.bedwars.sql.SQLType;
import java.io.File;
import de.marcely.bedwars.sql.SQLConnection;
import java.io.Closeable;

public class b implements Closeable, AutoCloseable
{
    private final SQLConnection a;
    
    public b(final File file) {
        this.a = new SQLConnection(SQLType.SQLite, file, true);
        this.a.doLog = false;
    }
    
    @Override
    public void close() throws IOException {
        this.a.disconnect();
    }
    
    public boolean connect(final Runnable runnable) {
        return this.a.connect(new Runnable() {
            @Override
            public void run() {
                b.this.init();
                runnable.run();
            }
        });
    }
    
    private void init() {
        try {
            this.a.doTask(new EmptySQLTask("CREATE TABLE IF NOT EXISTS InstalledLibraries(ID SMALLINT NOT NULL,Name VARCHAR(32) NOT NULL,Version UNSIGNED SMALLINT NOT NULL,Checksum BIGINT NOT NULL)", false));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public Collection<d> a() {
        try {
            final SQLResult doTask = this.a.doTask(new EmptySQLTask("SELECT * FROM InstalledLibraries", true));
            final ResultSet result = doTask.getResult();
            final ArrayList<d> list = new ArrayList<d>();
            while (result.next()) {
                final d d = new d();
                d.a = result.getShort("ID");
                d.name = result.getString("Name");
                d.version = result.getInt("Version");
                d.e = result.getLong("Checksum");
                list.add(d);
            }
            doTask.closeAll();
            return list;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void b(final d d) {
        this.c(d);
        try {
            this.a.doTask(new EmptySQLTask("INSERT INTO InstalledLibraries VALUES (?, ?, ?, ?)", false).addParameter(d.a).addParameter(d.name).addParameter(d.version).addParameter(d.e));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void c(final d d) {
        this.a(d.a);
    }
    
    public void a(final short s) {
        try {
            this.a.doTask(new EmptySQLTask("DELETE FROM InstalledLibraries WHERE ID = ?", false).addParameter(s));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
