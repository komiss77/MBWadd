// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.extlibrary;

public enum ExtLibrary
{
    a("WORLD_EDIT_V1", 0, 0, true), 
    b("WORLD_EDIT_V7", 1, 1, true), 
    c("DRIVER_MARIADB", 2, 2, false), 
    d("DRIVER_MYSQL", 3, 3, false);
    
    private final short a;
    private final boolean v;
    public boolean loaded;
    
    static {
        a = new ExtLibrary[] { ExtLibrary.a, ExtLibrary.b, ExtLibrary.c, ExtLibrary.d };
    }
    
    private ExtLibrary(final String name, final int ordinal, final int n, final boolean v) {
        this.loaded = false;
        this.a = (short)n;
        this.v = v;
    }
    
    public short getId() {
        return this.a;
    }
    
    public boolean y() {
        return this.v;
    }
}
