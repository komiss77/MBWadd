// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.inventory.PlayerData;
import java.io.File;
import de.marcely.bedwars.game.arena.c;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.inventory.b;
import de.marcely.bedwars.config.ConfigValue;
import javax.annotation.Nullable;
import org.bukkit.entity.Player;

public class bK
{
    @Nullable
    public bI a(final Player player) {
        try {
            return bJ.a(this, player.getUniqueId());
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public bI b(final Player player) {
        bI a = this.a(player);
        if (a == null) {
            a = new bI(this, player.getUniqueId());
            try {
                a.v(player);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return a;
    }
    
    public void b(final bI bi) {
        try {
            bJ.a(bi);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void z(final Player player) {
        if (!ConfigValue.inventory_backup || !player.isOnline()) {
            return;
        }
        final bI a = this.a(player);
        if (a == null) {
            final File a2 = b.a(player.getUniqueId());
            if (!a2.exists()) {
                return;
            }
            d.l("Found old player inventory file by " + player.getName() + "! Trying to load, convert and delete it...");
            try {
                final PlayerData a3 = b.a(player);
                if (a3.isIngame()) {
                    a3.u(player);
                }
                a2.delete();
            }
            catch (Error error) {
                d.k("An error occured during inventory-conversion task. Deleting the deprecated file as there's no use for it.");
                a2.delete();
            }
            catch (Exception ex) {
                d.k("An error occured during inventory-conversion task. Deleting the deprecated file as there's no use for it.");
                a2.delete();
            }
        }
        else {
            if (!a.isIngame()) {
                return;
            }
            s.b(player, (Arena)null);
            a.x(player);
            a.f(false);
            a.save();
            c.t(player);
        }
    }
    
    public void A(final Player player) {
        if (!ConfigValue.inventory_backup) {
            return;
        }
        final bI b = this.b(player);
        if (b.isIngame()) {
            return;
        }
        b.v(player);
        b.f(true);
        b.save();
    }
}
