// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class I extends NormalPacket
{
    public String name;
    
    @Override
    public byte getPacketID() {
        return 33;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
    }
}
