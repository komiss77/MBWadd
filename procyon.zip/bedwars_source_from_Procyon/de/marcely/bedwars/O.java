// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class O extends NormalPacket
{
    public a a;
    
    @Override
    public byte getPacketID() {
        return 49;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.a.name());
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.a = O.a.a(bufferedReadStream.readString());
        if (this.a == null) {
            this.a = O.a.e;
        }
    }
    
    public enum a
    {
        b("OKAY", 0), 
        c("FAILED_TOO_FULL", 1), 
        d("FAILED_NOT_LOBBY", 2), 
        e("FAILED_UNKOWN", 3);
        
        static {
            a = new a[] { O.a.b, O.a.c, O.a.d, O.a.e };
        }
        
        private a(final String name, final int ordinal) {
        }
        
        @Nullable
        public static a a(final String anObject) {
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                if (a.name().equals(anObject)) {
                    return a;
                }
            }
            return null;
        }
    }
}
