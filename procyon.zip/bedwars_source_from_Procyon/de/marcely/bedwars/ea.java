// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;
import java.util.List;
import org.bukkit.entity.Player;

public abstract class ea
{
    public void a(final Player player, final int n) {
    }
    
    public void b(final Player player, final int n) {
    }
    
    @Nullable
    public List<String> a(final Player player, final String s) {
        return null;
    }
    
    public boolean a(final Player player, final long n, final long n2) {
        return false;
    }
    
    public boolean a(final Player player, final float n, final int n2, final float n3) {
        return false;
    }
    
    public boolean a(final Player player, final float n) {
        return false;
    }
    
    public boolean b(final Player player, final int n, final Object o, final Object o2) {
        return false;
    }
    
    public void a(final Player player, final int n, final int n2) {
    }
}
