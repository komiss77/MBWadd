// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.IOException;

public class bl extends IOException
{
    private static final long serialVersionUID = 3580004729936969847L;
    
    public bl(final String message) {
        super(message);
    }
    
    public bl(final String message, final Throwable cause) {
        super(message, cause);
    }
    
    public bl(final Throwable cause) {
        super(cause);
    }
}
