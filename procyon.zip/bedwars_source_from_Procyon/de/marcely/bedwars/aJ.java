// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.CraftItemEvent;

public class aJ
{
    public static void a(final CraftItemEvent craftItemEvent) {
        final Arena a = s.a((Player)craftItemEvent.getWhoClicked());
        if (a != null && (a.b() != ArenaStatus.f || (!ConfigValue.interacting && a.b() == ArenaStatus.f))) {
            craftItemEvent.setCancelled(true);
        }
    }
}
