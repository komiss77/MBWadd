// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;

public class ci extends bS<Void>
{
    public static ci a;
    
    static {
        ci.a = new ci();
    }
    
    @Override
    public bP.c a() {
        return bP.c.a;
    }
    
    @Override
    public String a(final Void void1) {
        return this.c(null);
    }
    
    @Override
    public String c(final Arena arena) {
        return ConfigValue.ip_display;
    }
}
