// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.command.t;
import de.marcely.bedwars.game.arena.KickReason;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.r;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class aQ
{
    public static void a(final PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        if (r.a(ConfigValue.hubcommands, playerCommandPreprocessEvent.getMessage())) {
            final Player player = playerCommandPreprocessEvent.getPlayer();
            final Arena a = s.a(player);
            if (a != null) {
                a.a(KickReason.b, player);
                playerCommandPreprocessEvent.setCancelled(true);
            }
            else if (cA.E.containsKey(player)) {
                cA.a(player, cD.b);
                playerCommandPreprocessEvent.setCancelled(true);
            }
        }
        else if (ConfigValue.allowcommand_stats && playerCommandPreprocessEvent.getMessage().toLowerCase().startsWith("/stats")) {
            final Player player2 = playerCommandPreprocessEvent.getPlayer();
            final Arena a2 = s.a(player2);
            if (ConfigValue.allowcommand_stats_global || a2 != null) {
                playerCommandPreprocessEvent.setCancelled(true);
                ((t)MBedwars.a.a("stats").a()).a((CommandSender)player2, "stats", "", playerCommandPreprocessEvent.getMessage().split(" "));
            }
        }
    }
}
