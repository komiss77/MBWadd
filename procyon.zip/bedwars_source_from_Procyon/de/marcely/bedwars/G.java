// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class G extends NormalPacket
{
    public String h;
    
    @Override
    public byte getPacketID() {
        return 18;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.h);
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.h = bufferedReadStream.readString();
    }
}
