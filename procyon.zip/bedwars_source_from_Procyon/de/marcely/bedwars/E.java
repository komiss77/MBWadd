// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.util.UUID;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class E extends NormalPacket
{
    public UUID uuid;
    public String name;
    
    @Override
    public byte getPacketID() {
        return 48;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.uuid.toString());
        bufferedWriteStream.writeString(this.name);
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.uuid = UUID.fromString(bufferedReadStream.readString());
        this.name = bufferedReadStream.readString();
    }
}
