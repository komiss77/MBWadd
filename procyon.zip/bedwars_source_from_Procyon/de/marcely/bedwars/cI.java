// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.holographic.h;
import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.ArmorStand;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.versions.NMSClass;
import de.marcely.bedwars.holographic.i;
import org.bukkit.Location;
import de.marcely.bedwars.holographic.g;
import de.marcely.bedwars.holographic.e;
import de.marcely.bedwars.holographic.b;
import de.marcely.bedwars.holographic.a;
import de.marcely.bedwars.holographic.f;

public class cI extends f<cE> implements a, b
{
    private Object h;
    private Object i;
    private final e a;
    private boolean U;
    
    public cI(final g g, final Location location) {
        super(g, location);
        this.a = new e(this);
    }
    
    @Override
    public i a() {
        return de.marcely.bedwars.holographic.i.a;
    }
    
    @Override
    public float getHeight() {
        return this.U ? 0.9875f : 1.975f;
    }
    
    @Override
    public void a(final cE ce) {
        try {
            final Object cast = NMSClass.l.cast(this.location.getWorld());
            final Object invoke = cast.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(cast, new Object[0]);
            if (Version.a().getVersionNumber() <= 13) {
                this.g = NMSClass.A.getDeclaredConstructor(NMSClass.n).newInstance(invoke);
            }
            else {
                this.g = NMSClass.A.getDeclaredConstructor(NMSClass.X, NMSClass.n).newInstance(NMSClass.X.getField("ARMOR_STAND").get(null), invoke);
            }
            final int[] array = { (int)NMSClass.q.getMethod("getId", (Class<?>[])new Class[0]).invoke(this.g, new Object[0]) };
            this.entityId = array[0];
            this.i = NMSClass.y.getDeclaredConstructor(int[].class).newInstance(array);
            this.setLocation(this.location);
            this.setCustomName(ce.name);
            ce.a((ArmorStand)NMSClass.q.getMethod("getBukkitEntity", (Class<?>[])new Class[0]).invoke(this.g, new Object[0]), this);
            this.h = NMSClass.B.getDeclaredConstructor(NMSClass.t).newInstance(this.g);
            this.U = ce.d;
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    protected void D(final Player player) {
        Version.a().sendPacket(player, this.h);
        this.a.send(player);
        this.F(player);
    }
    
    @Override
    protected void E(final Player player) {
        Version.a().sendPacket(player, this.i);
    }
    
    @Override
    public void F(final Player player) {
        try {
            Version.a().sendPacket(player, NMSClass.K.getDeclaredConstructor(NMSClass.q).newInstance(this.g));
            if (Version.a().getVersionNumber() >= 9) {
                Version.a().sendPacket(player, NMSClass.O.getDeclaredConstructor(Integer.TYPE, Byte.TYPE, Byte.TYPE, Boolean.TYPE).newInstance(this.entityId, (byte)(this.location.getYaw() * 256.0f / 360.0f), (byte)(this.location.getPitch() * 256.0f / 360.0f), true));
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public void a(final Player player, final float n) {
        try {
            final Object instance = NMSClass.z.getDeclaredConstructor(NMSClass.q, Byte.TYPE).newInstance(this.g, 2);
            if (!this.a(this.getHealth() - n)) {
                Version.a().sendPacket(player, instance);
                Sound.ENTITY_ARMOR_STAND_HIT.play(this.getLocation());
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public boolean a(final float f) {
        try {
            final float health = this.getHealth();
            NMSClass.t.getMethod("setHealth", Float.TYPE).invoke(this.g, f);
            if (f <= 0.0f && health >= 1.0f) {
                final Object instance = NMSClass.z.getDeclaredConstructor(NMSClass.q, Byte.TYPE).newInstance(this.g, 3);
                final Iterator<Player> iterator = de.marcely.bedwars.util.b.a(this.location, Bukkit.getViewDistance() * 16).iterator();
                while (iterator.hasNext()) {
                    Version.a().sendPacket(iterator.next(), instance);
                }
                Sound.ENTITY_ARMOR_STAND_BREAK.play(this.getLocation());
                new BukkitRunnable() {
                    public void run() {
                        cI.this.a.R();
                    }
                }.runTaskLaterAsynchronously((Plugin)MBedwars.a, 40L);
                return true;
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    @Override
    public float getHealth() {
        try {
            return (float)NMSClass.t.getMethod("getHealth", (Class<?>[])new Class[0]).invoke(this.g, new Object[0]);
        }
        catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException ex) {
            final Throwable t;
            t.printStackTrace();
            return -1.0f;
        }
    }
    
    @Override
    public void setCustomName(@Nullable final String s) {
        this.y(s);
    }
    
    @Override
    public e a() {
        return this.a;
    }
}
