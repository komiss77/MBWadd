// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.FutureResult;

public class bn extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public bn(final FutureResult<?> futureResult, final String message) {
        super(message);
    }
}
