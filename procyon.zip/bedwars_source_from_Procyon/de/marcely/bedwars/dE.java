// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dE extends dI
{
    public dE() {
        super("current-team-color");
    }
    
    @Override
    protected String a(final Player player, final Arena arena) {
        final Team a = arena.a(player);
        return (a != null) ? new StringBuilder().append(a.getChatColor()).toString() : "";
    }
}
