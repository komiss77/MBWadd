// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class dN extends dR
{
    public dN() {
        super("bedsdestroyed");
    }
    
    @Override
    public String c(final c c) {
        return new StringBuilder().append(c.getBedsDestroyed()).toString();
    }
}
