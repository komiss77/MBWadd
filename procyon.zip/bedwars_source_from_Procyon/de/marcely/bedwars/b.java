// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipFile;
import org.apache.commons.io.FileUtils;
import de.marcely.bedwars.versions.Version;
import java.io.FileInputStream;
import java.util.zip.ZipEntry;
import javax.annotation.Nullable;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;
import de.marcely.bedwars.util.s;
import java.io.File;

public class b
{
    private final File file;
    private final String name;
    
    public b(final String s) {
        this.file = new File(s.n, String.valueOf(s) + ".zip");
        this.name = s;
    }
    
    @Nullable
    public Long a() {
        if (this.file.exists()) {
            return null;
        }
        final long currentTimeMillis = System.currentTimeMillis();
        try {
            this.file.createNewFile();
            final ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(this.file));
            zipOutputStream.setLevel(5);
            this.a(s.f, zipOutputStream);
            zipOutputStream.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        return System.currentTimeMillis() - currentTimeMillis;
    }
    
    private void a(final File file, final ZipOutputStream zipOutputStream) throws IOException {
        File[] listFiles;
        for (int length = (listFiles = file.listFiles()).length, i = 0; i < length; ++i) {
            final File file2 = listFiles[i];
            if (file2.isDirectory()) {
                if (!file2.getAbsolutePath().equals(s.n.getAbsolutePath())) {
                    this.a(file2, zipOutputStream);
                }
            }
            else {
                zipOutputStream.putNextEntry(new ZipEntry(s.a(file2)));
                final FileInputStream fileInputStream = new FileInputStream(file2);
                final byte[] array = new byte[1024];
                int read;
                while ((read = fileInputStream.read(array)) > 0) {
                    zipOutputStream.write(array, 0, read);
                }
                fileInputStream.close();
            }
        }
    }
    
    public boolean b() {
        try {
            this.delete(s.g);
            if (Version.a().getVersionNumber() >= 8) {
                FileUtils.copyDirectory(s.f, s.g);
            }
            else {
                net.minecraft.util.org.apache.commons.io.FileUtils.copyDirectory(s.f, s.g);
            }
            File[] listFiles;
            for (int length = (listFiles = s.f.listFiles()).length, i = 0; i < length; ++i) {
                final File file = listFiles[i];
                if (!file.getName().equals(s.h.getName())) {
                    this.delete(file);
                }
            }
            File[] listFiles2;
            for (int length2 = (listFiles2 = s.h.listFiles()).length, j = 0; j < length2; ++j) {
                final File file2 = listFiles2[j];
                if (!file2.getName().equals(s.n.getName())) {
                    this.delete(file2);
                }
            }
            final ZipFile zipFile = new ZipFile(this.file);
            final Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry zipEntry = (ZipEntry)entries.nextElement();
                final File file3 = new File(s.f, zipEntry.getName());
                if (Version.a().getVersionNumber() >= 8) {
                    FileUtils.copyInputStreamToFile(zipFile.getInputStream(zipEntry), file3);
                }
                else {
                    net.minecraft.util.org.apache.commons.io.FileUtils.copyInputStreamToFile(zipFile.getInputStream(zipEntry), file3);
                }
            }
            zipFile.close();
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    private void delete(final File file) {
        if (!file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] listFiles;
            for (int length = (listFiles = file.listFiles()).length, i = 0; i < length; ++i) {
                this.delete(listFiles[i]);
            }
        }
        file.delete();
    }
    
    public static b[] a() {
        final ArrayList<b> list = new ArrayList<b>();
        File[] listFiles;
        for (int length = (listFiles = s.n.listFiles()).length, i = 0; i < length; ++i) {
            final File file = listFiles[i];
            if (file.getName().endsWith(".zip")) {
                list.add(new b(file.getName().substring(0, file.getName().length() - 4)));
            }
        }
        return list.toArray(new b[list.size()]);
    }
    
    public File getFile() {
        return this.file;
    }
    
    public String getName() {
        return this.name;
    }
}
