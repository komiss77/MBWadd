// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.holographic.i;
import org.bukkit.Location;
import de.marcely.bedwars.holographic.g;

public class cL extends cK
{
    private boolean W;
    
    public cL(final g g, final Location location) {
        super(g, location);
        this.W = false;
    }
    
    @Override
    public i a() {
        return de.marcely.bedwars.holographic.i.e;
    }
    
    @Override
    protected void D(final Player player) {
        if (this.W) {
            return;
        }
        this.W = true;
        this.uuid = player.getUniqueId();
        this.W();
        super.D(player);
        this.uuid = null;
        this.W = false;
    }
}
