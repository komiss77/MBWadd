// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.PluginState;
import org.apache.commons.io.FileUtils;
import java.io.InputStream;
import java.net.URL;
import java.io.FileOutputStream;
import java.io.IOException;
import com.google.common.io.Files;
import java.io.File;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.api.gui.GUI;
import java.util.Collection;
import de.marcely.bedwars.game.stats.RankingStatue;
import java.util.ArrayList;
import de.marcely.bedwars.config.b;
import de.marcely.bedwars.game.arena.KickReason;
import java.util.Iterator;
import de.marcely.bedwars.achievements.UserAchievements;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.config.Config;
import de.marcely.bedwars.config.h;
import de.marcely.bedwars.game.shop.upgrade.DefaultUpgradeType;
import de.marcely.bedwars.api.BedwarsAPI;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.Player;
import de.marcely.bedwars.util.l;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.HashMap;
import de.marcely.bedwars.command.CommandHandler;
import de.marcely.bedwars.api.BedwarsAddon;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.game.arena.Arena;
import java.util.Map;
import org.bukkit.command.CommandExecutor;
import org.bukkit.plugin.java.JavaPlugin;

public class MBedwars extends JavaPlugin implements CommandExecutor
{
    public static MBedwars a;
    public Map<String, Arena> a;
    public static f a;
    public static g a;
    public static Map<Plugin, BedwarsAddon> b;
    public static CommandHandler a;
    public static dv a;
    public static a a;
    @Deprecated
    public static PluginState a;
    public static final e a;
    
    static {
        MBedwars.a = null;
        MBedwars.a = null;
        MBedwars.a = null;
        MBedwars.b = new HashMap<Plugin, BedwarsAddon>();
        MBedwars.a = new dv();
        MBedwars.a = new a();
        a = new e();
    }
    
    public MBedwars() {
        this.a = new HashMap<String, Arena>();
    }
    
    public void onEnable() {
        MBedwars.a = PluginState.b;
        MBedwars.a = this;
        a();
        d();
        if (Version.init()) {
            final String c = Version.a().c("spawn-npcs");
            final String c2 = Version.a().c("spawn-protection");
            if (Version.a().getVersionNumber() >= 13 && !Version.a().af()) {
                d.a("Server has been started without the '--forceUpgrade' parameter.\nThis may cause some crashes when upgrading from an older version");
            }
            if (c != null && c.equals("false")) {
                d.a("'spawn-npcs' is disabled in the server.properties!\nChange that to true to prevent issues.");
            }
            if (c2 == null || !s.isInteger(c2) || Integer.valueOf(c2) >= 1) {
                d.a("'spawn-protection' hasn't been set to 0 in the server.properties!\nChange that to prevent possible issues with players who won't be able to place/break blocks at a specific region in your arena.");
            }
            if (MBedwars.a == PluginState.f) {
                return;
            }
            if (!a().isTaskable()) {
                return;
            }
            new BukkitRunnable() {
                boolean a = true;
                
                public void run() {
                    MBedwars.a.a(this.a ? e.a.c : e.a.f);
                    this.a = false;
                }
            }.runTaskTimer((Plugin)this, 1L, 72000L);
            s.e = ((Version.a().getVersionNumber() >= 8) ? Material.BARRIER : Material.CLAY_BALL);
            s.k = new Location(s.a(), 0.0, 0.0, 0.0);
            s.a = Thread.currentThread();
            s.a = new de.marcely.bedwars.message.a();
            s.a = new l(true);
            MBedwars.a = new CommandHandler();
            cB.init();
            s.b.run();
            (s.b = new cS()).loadLibraries();
            for (final Player player : Version.a().getOnlinePlayers()) {
                final dY dy = new dY(player);
                dy.inject();
                s.Z.put(player, dy);
                dy.a(new c());
                s.b.z(player);
                final Arena a = s.a(player.getLocation());
                if (a != null) {
                    s.b(player, a);
                }
            }
            new BukkitRunnable() {
                public void run() {
                    s.c(new Runnable() {
                        final /* synthetic */ MBedwars$2 a = System.currentTimeMillis();
                        private final /* synthetic */ long a = System.currentTimeMillis();
                        
                        @Override
                        public void run() {
                            d.c("Updated stats after " + (System.currentTimeMillis() - long.this) / 1000.0 + " seconds");
                        }
                    });
                }
            }.runTaskTimer((Plugin)MBedwars.a, (long)(ConfigValue.restart_oncearenaend ? 100 : 18000), 60000L);
            s.A("de.marcely.bedwars.game.arena.KickReason");
            s.A("de.marcely.bedwars.versions.NMSClass");
            if (Version.a().getVersionNumber() >= 8) {
                ConfigValue.rescueplatform_item = new ItemStack(Material.SLIME_BLOCK);
                ConfigValue.rescueplatform_material = Material.SLIME_BLOCK;
            }
            else {
                ConfigValue.rescueplatform_item = new ItemStack(Material.STAINED_GLASS);
                ConfigValue.rescueplatform_material = Material.STAINED_GLASS;
            }
            this.getServer().getPluginManager().registerEvents((Listener)new as(), (Plugin)this);
            this.getServer().getPluginManager().registerEvents((Listener)new au(), (Plugin)this);
            if (Version.a().getVersionNumber() >= 10) {
                this.getServer().getPluginManager().registerEvents((Listener)new at(), (Plugin)this);
            }
            BedwarsAPI.registerMBedwarsCommand("bw");
            BedwarsAPI.registerMBedwarsCommand("bedwars");
            BedwarsAPI.registerMBedwarsCommand("mbedwars");
            DefaultUpgradeType.init();
            bu.init();
            de.marcely.bedwars.game.arena.picker.condition.e.init();
            h.onEnable();
            Config.a(true, null);
            de.marcely.bedwars.game.stats.c.onEnable();
            UserAchievements.onEnable();
            ak.onEnable();
            if (!a().isTaskable()) {
                return;
            }
            new BukkitRunnable() {
                public void run() {
                    s.a.start();
                    for (int i = s.ag.size() - 1; i >= 0; --i) {
                        s.ag.get(i).a().D();
                    }
                    s.a.a(l.a.c);
                }
            }.runTaskTimer((Plugin)this, 1L, 1L);
            new BukkitRunnable() {
                public void run() {
                    s.af();
                    s.ag();
                }
            }.runTaskLater((Plugin)this, 1L);
            if (ConfigValue.autojoin_way == Config.AutoJoin_SendBackWay.b || ConfigValue.bungeecord_enabled) {
                this.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
            }
            if (ConfigValue.bungeecord_enabled) {
                MBedwars.a = new f(ConfigValue.bungeecord_hub_address);
                MBedwars.a = new g((Plugin)this, MBedwars.a);
                de.marcely.bedwars.h.onEnable();
            }
            MBedwars.a = PluginState.c;
        }
        else {
            MBedwars.a = PluginState.d;
        }
    }
    
    public void onDisable() {
        MBedwars.a = PluginState.e;
        try {
            MBedwars.a.a(ei.a.f);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        s.b.stop();
        final Iterator<Player> iterator = cA.E.keySet().iterator();
        while (iterator.hasNext()) {
            cA.a(iterator.next(), cD.c);
        }
        for (final Arena arena : s.af) {
            arena.a(KickReason.c);
            arena.B();
            if (arena.B()) {
                arena.a.cancel();
            }
        }
        if (s.af.size() >= 1) {
            de.marcely.bedwars.config.b.saveAll();
        }
        for (final RankingStatue rankingStatue : new ArrayList<RankingStatue>(s.ad)) {
            if (rankingStatue != null) {
                rankingStatue.remove(false);
            }
        }
        bC.removeAll();
        if (s.b != null) {
            s.b.shutdown();
        }
        de.marcely.bedwars.game.stats.d.P();
        s.i(false);
        final Iterator<Player> iterator4 = GUI.openInventories.keySet().iterator();
        while (iterator4.hasNext()) {
            iterator4.next().closeInventory();
        }
        if (s.Z != null) {
            final Iterator<Player> iterator5 = s.Z.keySet().iterator();
            while (iterator5.hasNext()) {
                s.Z.get(iterator5.next()).Y();
            }
            s.Z.clear();
        }
        for (final Thread thread : MThread.getRunningThreads()) {
            if (thread instanceof MThread) {
                thread.stop();
            }
        }
        if (ConfigValue.bungeecord_enabled) {
            de.marcely.bedwars.h.onDisable();
        }
        UserAchievements.e();
        de.marcely.bedwars.game.stats.c.e();
        MBedwars.a = PluginState.f;
    }
    
    public boolean c() {
        return true;
    }
    
    public static void a() {
        File[] a;
        for (int length = (a = s.a()).length, i = 0; i < length; ++i) {
            final File file = a[i];
            if (!file.exists()) {
                file.mkdir();
            }
        }
    }
    
    public static String getVersion() {
        return "4.0.13";
    }
    
    public static void h(final String pathname, final String obj) {
        File[] listFiles;
        for (int length = (listFiles = new File(pathname).listFiles()).length, i = 0; i < length; ++i) {
            final File file = listFiles[i];
            if (!file.isHidden() && !file.isDirectory()) {
                try {
                    Files.copy(file, new File(String.valueOf(obj) + file.getName()));
                }
                catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    public static void p(final String pathname) {
        final File file = new File(pathname);
        if (file.isDirectory()) {
            boolean b = true;
            File[] listFiles;
            for (int length = (listFiles = file.listFiles()).length, i = 0; i < length; ++i) {
                final File file2 = listFiles[i];
                if (file2.isFile()) {
                    file2.delete();
                }
                else {
                    b = false;
                }
            }
            if (b) {
                file.delete();
            }
        }
    }
    
    public static void a(final String name, final String s, final boolean b) {
        try {
            if (!b && new File(s).exists()) {
                return;
            }
            final URL resource = JavaPlugin.class.getClassLoader().getResource(name);
            final FileOutputStream fileOutputStream = new FileOutputStream(s);
            final InputStream openStream = resource.openStream();
            final byte[] b2 = new byte[4096];
            for (int i = openStream.read(b2); i != -1; i = openStream.read(b2)) {
                fileOutputStream.write(b2, 0, i);
            }
            fileOutputStream.close();
            openStream.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static boolean d() {
        return MBedwars.a != null && MBedwars.a.h();
    }
    
    public static void moveFile(final File file, final File file2) {
        try {
            FileUtils.moveFile(file, file2);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private static void d() {
        i("config.yml", s.a(s.s));
        i("achievements-config.yml", s.a(s.u));
        i("hologram-lines.yml", s.a(s.t));
        i("itemspawners.yml", s.a(s.v));
        i("lobby-config.yml", s.a(s.w));
        i("ranking-lines.yml", s.a(s.x));
        i("scoreboard-ingame.yml", s.a(s.y));
        i("scoreboard-lobby.yml", s.a(s.z));
        i("shop-config.yml", s.a(s.A));
        i("sounds-config.yml", s.a(s.C));
        i("upgrade-shop-config.yml", s.a(s.B));
    }
    
    private static void i(final String child, final String child2) {
        final File file = new File(s.f, child);
        final File file2 = new File(s.f, child2);
        if (!file2.exists() && file.exists()) {
            d.c("Moving '" + s.a(file) + "' to '" + s.a(file2) + "'");
            moveFile(file, file2);
        }
    }
    
    public static PluginState a() {
        return MBedwars.a;
    }
    
    public ClassLoader a() {
        return super.getClassLoader();
    }
    
    public boolean a(final CommandSender commandSender) {
        if (Config.g() > 0) {
            return false;
        }
        final Iterator<Arena> iterator = s.af.iterator();
        while (iterator.hasNext()) {
            iterator.next().a(KickReason.c);
        }
        ((de.marcely.bedwars.command.arena.f)((de.marcely.bedwars.command.d)MBedwars.a.a("arena").a()).a.a("gui").a()).e.clear();
        UserAchievements.e();
        de.marcely.bedwars.game.stats.c.e();
        Language.getPack().clear();
        Config.a(false, commandSender);
        return true;
    }
    
    public enum PluginState
    {
        b("Enabling", 0, true, de.marcely.bedwars.api.PluginState.Enabling), 
        c("Running", 1, true, de.marcely.bedwars.api.PluginState.Running), 
        d("StartFailed", 2, false, de.marcely.bedwars.api.PluginState.StartFailed), 
        e("Disabling", 3, false, de.marcely.bedwars.api.PluginState.Disabling), 
        f("Disabled", 4, false, de.marcely.bedwars.api.PluginState.Disabled);
        
        private final boolean taskable;
        private final de.marcely.bedwars.api.PluginState a;
        
        static {
            a = new PluginState[] { PluginState.b, PluginState.c, PluginState.d, PluginState.e, PluginState.f };
        }
        
        private PluginState(final String name, final int ordinal, final boolean taskable, final de.marcely.bedwars.api.PluginState a) {
            this.taskable = taskable;
            this.a = a;
        }
        
        public boolean isTaskable() {
            return this.taskable;
        }
        
        public de.marcely.bedwars.api.PluginState a() {
            return this.a;
        }
    }
}
