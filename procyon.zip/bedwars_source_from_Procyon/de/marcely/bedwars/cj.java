// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import de.marcely.bedwars.util.m;

public class cj extends cm
{
    public static cj a;
    
    static {
        cj.a = new cj();
    }
    
    @Override
    public String a(final m m) {
        final Arena arena = m.getArena();
        final Team team = m.getTeam();
        final Player player = m.getPlayer();
        if (team == null) {
            return "?";
        }
        return arena.a().a().contains(team) ? b.a(Language.Scoreboard_BedState_Destroyed).f((CommandSender)player) : b.a(Language.Scoreboard_BedState_Alive).f((CommandSender)player);
    }
}
