// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;

public class dC extends dy
{
    public dC(final Arena arena) {
        super(arena, "teams");
    }
    
    @Override
    public String e(final Player player) {
        return new StringBuilder().append(this.arena.a().r().size()).toString();
    }
}
