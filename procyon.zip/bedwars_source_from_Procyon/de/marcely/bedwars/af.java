// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.IOException;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;
import de.marcely.bedwars.util.s;
import org.bukkit.Bukkit;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.MThread;

@Deprecated
public class af
{
    private static final int w = 59;
    private static final String URL = "http://mbedwars.marcely.de/versions.req?bwv={bwversion}&mcv={mcversion}&ip={ip}&mac={mac}";
    private static boolean n;
    
    static {
        af.n = false;
    }
    
    public static void update() {
        c(true);
    }
    
    public static void c(final boolean b) {
        a(3, b);
    }
    
    public static void a(final int n, final boolean b) {
        af.n = true;
        if (n <= 0) {
            d.b("=============================");
            d.b("Sorry, but we were unable to identify your version.");
            d.b("Please try it again with a working internet connection!");
            d.b("============================");
            af.n = false;
            return;
        }
        final MThread mThread = new MThread(MThread.ThreadType.e) {
            @Override
            public void run() {
                try {
                    final String version = MBedwars.getVersion();
                    final String name = Version.a().a().name();
                    final String string = String.valueOf(Bukkit.getIp()) + ":" + Bukkit.getPort();
                    s.sleep(200L);
                    final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("http://mbedwars.marcely.de/versions.req?bwv={bwversion}&mcv={mcversion}&ip={ip}&mac={mac}".replace("{bwversion}", version).replace("{mcversion}", name).replace("{ip}", string).replace("{mac}", s.t())).openConnection();
                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");
                    httpURLConnection.connect();
                    s.sleep(50L);
                    if (httpURLConnection.getResponseCode() == 200) {
                        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        final MBedwars a = MBedwars.a;
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            if (line.equals("59")) {
                                af.d(false);
                                return;
                            }
                        }
                        d.b("=============================");
                        d.b("It seems like that your current version (" + MBedwars.getVersion() + ") is outdated.");
                        d.b("Please install the latest version to fix that!");
                        d.b("============================");
                        MBedwars.a = MBedwars.PluginState.f;
                        af.d(false);
                        MBedwars.a.getCommands().clear();
                        s.Y = null;
                        s.Z = null;
                        new BukkitRunnable() {
                            public void run() {
                                Bukkit.getPluginManager().disablePlugin(a);
                            }
                        }.runTask((Plugin)a);
                    }
                    else {
                        af.a(n - 1, b);
                    }
                }
                catch (IOException ex) {
                    af.a(n - 1, b);
                }
            }
        };
        if (b) {
            mThread.start();
        }
        else {
            mThread.run();
        }
    }
    
    public static boolean q() {
        return af.n;
    }
    
    static /* synthetic */ void d(final boolean n) {
        af.n = n;
    }
}
