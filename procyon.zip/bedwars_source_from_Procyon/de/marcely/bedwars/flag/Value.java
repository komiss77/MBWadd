// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import javax.annotation.Nullable;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class Value<T>
{
    private o a;
    protected T value;
    
    public Value(final o o) {
        this(o, null);
    }
    
    public Value(final o a, final T value) {
        this.a = a;
        this.value = value;
    }
    
    public abstract String g();
    
    public abstract void t(final String p0) throws Exception;
    
    protected abstract void a(final BufferedWriteStream p0);
    
    protected abstract void a(final BufferedReadStream p0);
    
    public void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.a.getId());
        this.a(bufferedWriteStream);
    }
    
    @Nullable
    public static Value<?> a(final BufferedReadStream bufferedReadStream) {
        final o a = o.a(bufferedReadStream.readByte());
        if (a == null) {
            return null;
        }
        final Value<?> a2 = a.a();
        a2.a(bufferedReadStream);
        return a2;
    }
    
    @Override
    public String toString() {
        return this.value.toString();
    }
    
    public o a() {
        return this.a;
    }
    
    public T getValue() {
        return this.value;
    }
    
    public void setValue(final T value) {
        this.value = value;
    }
}
