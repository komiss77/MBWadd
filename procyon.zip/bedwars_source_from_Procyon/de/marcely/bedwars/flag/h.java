// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class h extends Value<Float>
{
    public h() {
        this(0.0f);
    }
    
    public h(final Float n) {
        super(o.f, n);
    }
    
    @Override
    public String g() {
        return new StringBuilder().append(this.value).toString();
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)Float.valueOf(Float.parseFloat(s));
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeFloat((float)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)Float.valueOf(bufferedReadStream.readFloat());
    }
}
