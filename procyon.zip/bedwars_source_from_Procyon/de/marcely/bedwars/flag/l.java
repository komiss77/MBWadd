// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class l extends Value<Long>
{
    public l() {
        this(0L);
    }
    
    public l(final Long n) {
        super(o.e, n);
    }
    
    @Override
    public String g() {
        return new StringBuilder().append(this.value).toString();
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)Long.valueOf(Long.parseLong(s));
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedLong((long)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)Long.valueOf(bufferedReadStream.readSignedLong());
    }
}
