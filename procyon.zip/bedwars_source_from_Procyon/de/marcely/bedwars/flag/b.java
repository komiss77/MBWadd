// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.nio.charset.StandardCharsets;

public class b extends Value<byte[]>
{
    public b() {
        this(new byte[0]);
    }
    
    public b(final byte[] array) {
        super(o.k, array);
    }
    
    @Override
    public String g() {
        return new String((byte[])(Object)this.value, StandardCharsets.UTF_8);
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)(Object)s.getBytes(StandardCharsets.UTF_8);
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByteArray((byte[])(Object)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)(Object)bufferedReadStream.readByteArray();
    }
    
    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < ((byte[])(Object)this.value).length; ++i) {
            str = String.valueOf(str) + ((byte[])(Object)this.value)[i];
            if (i + 1 < ((byte[])(Object)this.value).length) {
                str = String.valueOf(str) + ", ";
            }
        }
        return "[" + str + "]";
    }
}
