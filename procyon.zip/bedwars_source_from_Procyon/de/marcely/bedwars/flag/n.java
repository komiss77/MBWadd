// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class n extends Value<String>
{
    public n() {
        this("");
    }
    
    public n(final String s) {
        super(o.h, s);
    }
    
    @Override
    public String g() {
        return (String)this.value;
    }
    
    @Override
    public void t(final String value) throws Exception {
        this.value = (T)value;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString((String)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)bufferedReadStream.readString();
    }
    
    @Override
    public String toString() {
        return "\"" + (String)this.value + "\"";
    }
}
