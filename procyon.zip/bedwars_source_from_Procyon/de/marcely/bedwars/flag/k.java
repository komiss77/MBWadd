// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.br;

public class k extends Value<long[]>
{
    public k() {
        this(new long[0]);
    }
    
    public k(final long[] array) {
        super(o.n, array);
    }
    
    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }
    
    @Override
    public void t(final String s) throws Exception {
        new br().printStackTrace();
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((long[])(Object)this.value).length);
        for (int i = 0; i < ((long[])(Object)this.value).length; ++i) {
            bufferedWriteStream.writeSignedLong(((long[])(Object)this.value)[i]);
        }
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        final int unsignedShort = bufferedReadStream.readUnsignedShort();
        this.value = (T)(Object)new long[unsignedShort];
        for (int i = 0; i < unsignedShort; ++i) {
            ((long[])(Object)this.value)[i] = bufferedReadStream.readSignedLong();
        }
    }
    
    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < ((long[])(Object)this.value).length; ++i) {
            str = String.valueOf(str) + ((long[])(Object)this.value)[i];
            if (i + 1 < ((long[])(Object)this.value).length) {
                str = String.valueOf(str) + ", ";
            }
        }
        return "[" + str + "]";
    }
}
