// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.br;

public class i extends Value<int[]>
{
    public i() {
        this(new int[0]);
    }
    
    public i(final int[] array) {
        super(o.l, array);
    }
    
    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }
    
    @Override
    public void t(final String s) throws Exception {
        new br().printStackTrace();
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((int[])(Object)this.value).length);
        for (int i = 0; i < ((int[])(Object)this.value).length; ++i) {
            bufferedWriteStream.writeSignedInt(((int[])(Object)this.value)[i]);
        }
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        final int unsignedShort = bufferedReadStream.readUnsignedShort();
        this.value = (T)(Object)new int[unsignedShort];
        for (int i = 0; i < unsignedShort; ++i) {
            ((int[])(Object)this.value)[i] = bufferedReadStream.readSignedInt();
        }
    }
}
