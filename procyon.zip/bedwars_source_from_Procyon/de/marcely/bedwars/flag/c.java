// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class c extends Value<Byte>
{
    public c() {
        this((Byte)0);
    }
    
    public c(final Byte b) {
        super(o.b, b);
    }
    
    @Override
    public String g() {
        return new String(new byte[] { (byte)this.value });
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)Byte.valueOf(s.getBytes()[0]);
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte((byte)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)Byte.valueOf(bufferedReadStream.readByte());
    }
}
