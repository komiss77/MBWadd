// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import javax.annotation.Nullable;

public enum o
{
    b("BYTE", 0, (byte)0), 
    c("SHORT", 1, (byte)1), 
    d("INTEGER", 2, (byte)2), 
    e("LONG", 3, (byte)3), 
    f("FLOAT", 4, (byte)4), 
    g("DOUBLE", 5, (byte)5), 
    h("STRING", 6, (byte)6), 
    i("BOOLEAN", 7, (byte)7), 
    j("COLLECTION", 8, (byte)8), 
    k("ARRAY_BYTE", 9, (byte)9), 
    l("ARRAY_INTEGER", 10, (byte)10), 
    m("COLLECTION_FLAGS", 11, (byte)11), 
    n("ARRAY_LONG", 12, (byte)12);
    
    private byte id;
    private static /* synthetic */ int[] h;
    
    static {
        a = new o[] { o.b, o.c, o.d, o.e, o.f, o.g, o.h, o.i, o.j, o.k, o.l, o.m, o.n };
    }
    
    private o(final String name, final int ordinal, final byte id) {
        this.id = id;
    }
    
    public Value<?> a() {
        switch (h()[this.ordinal()]) {
            case 1: {
                return new c();
            }
            case 2: {
                return new m();
            }
            case 3: {
                return new j();
            }
            case 4: {
                return new l();
            }
            case 5: {
                return new h();
            }
            case 6: {
                return new f();
            }
            case 7: {
                return new n();
            }
            case 8: {
                return new a();
            }
            case 9: {
                return new e();
            }
            case 10: {
                return new b();
            }
            case 11: {
                return new i();
            }
            case 12: {
                return new d();
            }
            case 13: {
                return new k();
            }
            default: {
                return null;
            }
        }
    }
    
    @Nullable
    public static o a(final byte b) {
        o[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final o o = values[i];
            if (o.id == b) {
                return o;
            }
        }
        return null;
    }
    
    public byte getId() {
        return this.id;
    }
    
    static /* synthetic */ int[] h() {
        final int[] h = o.h;
        if (h != null) {
            return h;
        }
        final int[] h2 = new int[values().length];
        try {
            h2[o.k.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            h2[o.l.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            h2[o.n.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            h2[o.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            h2[o.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            h2[o.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            h2[o.m.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            h2[o.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            h2[o.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            h2[o.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            h2[o.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            h2[o.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            h2[o.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        return o.h = h2;
    }
}
