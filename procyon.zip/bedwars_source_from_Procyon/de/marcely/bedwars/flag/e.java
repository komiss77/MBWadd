// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import java.util.ArrayDeque;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.util.Iterator;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.br;
import java.util.LinkedList;
import java.util.Collection;

public class e extends Value<Collection<Value<?>>>
{
    public e() {
        this(new LinkedList<Value<?>>());
    }
    
    public e(final Collection<Value<?>> collection) {
        super(o.j, collection);
    }
    
    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }
    
    @Override
    public void t(final String s) throws Exception {
        new br().printStackTrace();
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((Collection)this.value).size());
        final Iterator<Value> iterator = ((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            iterator.next().write(bufferedWriteStream);
        }
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        final int unsignedShort = bufferedReadStream.readUnsignedShort();
        this.value = (T)new ArrayDeque(unsignedShort);
        for (int i = 0; i < unsignedShort; ++i) {
            ((Collection)this.value).add(Value.a(bufferedReadStream));
        }
    }
    
    @Override
    public String toString() {
        String str = "";
        final Iterator<Value> iterator = (Iterator<Value>)((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            str = String.valueOf(str) + iterator.next().toString();
            if (iterator.hasNext()) {
                str = String.valueOf(str) + ", ";
            }
        }
        return "[" + str + "]";
    }
    
    public void a(final Value<?> value) {
        ((Collection)this.value).add(value);
    }
}
