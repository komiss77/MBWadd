// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class g
{
    private final String key;
    Value<?> value;
    
    public g(final String key, final Value<?> value) {
        this.key = key;
        this.value = value;
    }
    
    public void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.key);
        this.value.write(bufferedWriteStream);
    }
    
    public <T extends Value<?>> T a(final Class<T> clazz) {
        return (T)this.getValue();
    }
    
    @Override
    public String toString() {
        return "{Key: \"" + this.key + "\", ValueType: \"" + this.value.a() + "\", Value: " + this.value.toString() + "}";
    }
    
    public static g a(final BufferedReadStream bufferedReadStream) {
        return new g(bufferedReadStream.readString(), Value.a(bufferedReadStream));
    }
    
    public String getKey() {
        return this.key;
    }
    
    public Value<?> getValue() {
        return this.value;
    }
    
    public void b(final Value<?> value) {
        this.value = value;
    }
}
