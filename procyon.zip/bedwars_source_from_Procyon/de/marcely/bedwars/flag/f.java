// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class f extends Value<Double>
{
    public f() {
        this(0.0);
    }
    
    public f(final Double n) {
        super(o.g, n);
    }
    
    @Override
    public String g() {
        return new StringBuilder().append(this.value).toString();
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)Double.valueOf(Double.parseDouble(s));
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeDouble((double)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)Double.valueOf(bufferedReadStream.readDouble());
    }
}
