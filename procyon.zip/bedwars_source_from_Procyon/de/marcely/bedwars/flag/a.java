// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class a extends Value<Boolean>
{
    public a() {
        this(false);
    }
    
    public a(final Boolean b) {
        super(o.i, b);
    }
    
    @Override
    public String g() {
        return new StringBuilder().append(this.value).toString();
    }
    
    @Override
    public void t(final String s) throws Exception {
        this.value = (T)Boolean.valueOf(s);
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeBoolean((boolean)this.value);
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.value = (T)Boolean.valueOf(bufferedReadStream.readBoolean());
    }
}
