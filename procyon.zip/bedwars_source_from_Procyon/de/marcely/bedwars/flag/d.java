// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.flag;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.util.Iterator;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.br;
import java.util.LinkedList;
import java.util.Collection;

public class d extends Value<Collection<g>>
{
    public d() {
        this(new LinkedList<g>());
    }
    
    public d(final Collection<g> collection) {
        super(o.m, collection);
    }
    
    @Override
    public String g() {
        new br().printStackTrace();
        return null;
    }
    
    @Override
    public void t(final String s) throws Exception {
        new br().printStackTrace();
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeUnsignedShort(((Collection)this.value).size());
        final Iterator<g> iterator = ((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            iterator.next().write(bufferedWriteStream);
        }
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        final int unsignedShort = bufferedReadStream.readUnsignedShort();
        this.value = (T)new ArrayDeque(unsignedShort);
        for (int i = 0; i < unsignedShort; ++i) {
            ((Collection)this.value).add(g.a(bufferedReadStream));
        }
    }
    
    @Override
    public String toString() {
        String str = "";
        final Iterator<g> iterator = (Iterator<g>)((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            str = String.valueOf(str) + iterator.next().toString();
            if (iterator.hasNext()) {
                str = String.valueOf(str) + ", ";
            }
        }
        return "[" + str + "]";
    }
    
    @Nullable
    public g a(final String anObject) {
        for (final g g : (Collection)this.value) {
            if (g.getKey().equals(anObject)) {
                return g;
            }
        }
        return null;
    }
    
    public boolean e(final String anObject) {
        final Iterator<g> iterator = (Iterator<g>)((Collection)this.value).iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getKey().equals(anObject)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }
    
    public void a(final g g) {
        this.getValue().add(g);
    }
    
    public void clear() {
        ((Value<Collection>)this).getValue().clear();
    }
}
