// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.UnknownHostException;
import java.net.SocketException;
import java.net.InetSocketAddress;
import org.bukkit.Bukkit;
import java.net.InetAddress;
import java.net.SocketAddress;
import de.marcely.bedwars.util.MThread;
import java.net.DatagramSocket;

public class l implements k
{
    private int packetSize;
    private DatagramSocket socket;
    private MThread a;
    
    public l() {
        this.packetSize = 1024;
        this.socket = null;
        this.a = null;
    }
    
    public l(final int packetSize) {
        this.packetSize = 1024;
        this.socket = null;
        this.a = null;
        this.packetSize = packetSize;
    }
    
    public int a() {
        return this.packetSize;
    }
    
    public DatagramSocket a() {
        return this.socket;
    }
    
    public boolean isInjected() {
        return this.socket != null;
    }
    
    public boolean j() {
        return this.a != null;
    }
    
    public MThread a() {
        return this.a;
    }
    
    public boolean inject() {
        if (!this.isInjected()) {
            try {
                (this.socket = new DatagramSocket((SocketAddress)null)).bind(new InetSocketAddress(InetAddress.getLocalHost(), Bukkit.getServer().getPort()));
            }
            catch (SocketException | UnknownHostException ex) {
                final Object o2;
                final Object o = o2;
                d.d("Failed to bind into socket!");
                d.e("Maybe restarting your server will fix that.");
                ((Throwable)o).printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }
    
    public boolean close() {
        if (this.isInjected()) {
            this.l();
            this.socket.close();
            this.socket = null;
            return true;
        }
        return false;
    }
    
    public DatagramPacket a(final InetAddress address, final int port, final byte[] buf) {
        final DatagramPacket p3 = new DatagramPacket(buf, buf.length, address, port);
        try {
            this.socket.send(p3);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        return p3;
    }
    
    public boolean k() {
        if (!this.j()) {
            (this.a = new MThread(MThread.ThreadType.a) {
                @Override
                public void run() {
                    while (l.this.j()) {
                        final byte[] buf = new byte[1024];
                        final DatagramPacket p = new DatagramPacket(buf, buf.length);
                        try {
                            l.this.socket.receive(p);
                        }
                        catch (IOException ex) {}
                        if (p != null && p.getLength() >= 1) {
                            l.this.b(p);
                        }
                    }
                }
            }).start();
            return true;
        }
        return false;
    }
    
    public boolean l() {
        if (this.j()) {
            this.a.interrupt();
            this.a = null;
            return true;
        }
        return false;
    }
    
    @Override
    public void b(final DatagramPacket datagramPacket) {
    }
}
