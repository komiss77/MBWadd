// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.dytanic.cloudnet.lib.server.ServerState;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.dytanic.cloudnet.bridge.CloudServer;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.game.arena.d;

public class da extends cZ
{
    private d a;
    private Arena arena;
    private static /* synthetic */ int[] l;
    
    @Override
    public cT a() {
        return cT.b;
    }
    
    @Override
    public void onEnable() {
        this.arena = s.b(ConfigValue.cloudsystem_arena);
        if (this.arena == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.b(this.arena, d.a.g);
        this.b(this.arena, d.a.e);
        this.a = new d() {
            @Override
            public void a(final Arena arena, final a a) {
                da.this.b(arena, a);
            }
        };
        this.arena.a(this.a);
    }
    
    private void b(final Arena arena, final d.a a) {
        final CloudServer instance = CloudServer.getInstance();
        if (a == d.a.e && arena.b() == ArenaStatus.f) {
            instance.changeToIngame();
            return;
        }
        instance.setServerState(a(arena.b()));
        instance.setMotd(ConfigValue.cloudsystem_extra.a(arena));
        instance.update();
    }
    
    @Override
    public void onDisable() {
        if (this.arena != null) {
            this.arena.a(this.a);
        }
    }
    
    private static ServerState a(final ArenaStatus arenaStatus) {
        switch (m()[arenaStatus.ordinal()]) {
            case 3: {
                return ServerState.INGAME;
            }
            case 2: {
                return ServerState.LOBBY;
            }
            default: {
                return ServerState.OFFLINE;
            }
        }
    }
    
    static /* synthetic */ int[] m() {
        final int[] l = da.l;
        if (l != null) {
            return l;
        }
        final int[] i = new int[ArenaStatus.values().length];
        try {
            i[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            i[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            i[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return da.l = i;
    }
}
