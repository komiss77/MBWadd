// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import de.marcely.bedwars.achievements.UserAchievements;
import javax.xml.stream.XMLStreamWriter;
import java.io.Writer;
import javax.xml.stream.XMLOutputFactory;
import java.io.FileWriter;
import de.marcely.bedwars.util.s;
import java.util.ArrayList;
import org.bukkit.OfflinePlayer;
import javax.xml.stream.XMLStreamReader;
import java.io.Reader;
import java.io.IOException;
import javax.xml.stream.XMLStreamException;
import org.bukkit.Bukkit;
import javax.xml.stream.XMLInputFactory;
import java.io.FileReader;
import java.io.File;
import de.marcely.bedwars.game.stats.c;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.UUID;

public class ed extends ef
{
    public ed() {
        super(eg.b);
    }
    
    @Override
    public boolean aa() {
        return true;
    }
    
    @Override
    public boolean ab() {
        return true;
    }
    
    @Override
    public boolean isConnected() {
        return true;
    }
    
    @Override
    public Future<Boolean> d(final UUID uuid) {
        return this.a((Callable<Boolean>)new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                return b(uuid).exists();
            }
        });
    }
    
    @Override
    public Future<c> a(final UUID uuid, final String s) {
        return this.a((Callable<c>)new Callable<c>() {
            public c c() throws Exception {
                if (!b(uuid).exists()) {
                    return new c(s, uuid, false);
                }
                Reader reader = null;
                try {
                    reader = new FileReader(new File("plugins/MBedwars/data/playerstats/" + uuid.toString() + ".yml"));
                    final c c = new c(s, uuid, false);
                    final XMLStreamReader xmlStreamReader = XMLInputFactory.newInstance().createXMLStreamReader(reader);
                    while (xmlStreamReader.hasNext()) {
                        if (xmlStreamReader.next() == 1) {
                            if (xmlStreamReader.getLocalName().equals("stats")) {
                                for (int i = 0; i < xmlStreamReader.getAttributeCount(); ++i) {
                                    final String attributeLocalName = xmlStreamReader.getAttributeLocalName(i);
                                    final String attributeValue = xmlStreamReader.getAttributeValue(i);
                                    if (attributeLocalName.equals("rank")) {
                                        c.setRank(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("wins")) {
                                        c.setWins(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("loses")) {
                                        c.setLoses(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("kills")) {
                                        c.setKills(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("deaths")) {
                                        c.setDeaths(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("bedsDestroyed")) {
                                        c.setBedsDestroyed(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("roundsPlayed")) {
                                        c.setRoundsPlayed(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("playTime")) {
                                        c.setPlayTime(Long.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("coins")) {
                                        c.setCoins(Integer.valueOf(attributeValue));
                                    }
                                    else if (attributeLocalName.equals("finalKills")) {
                                        c.setFinalKills(Integer.valueOf(attributeValue));
                                    }
                                }
                            }
                            else if (xmlStreamReader.getLocalName().equals("user_name")) {
                                c.x(xmlStreamReader.getElementText());
                            }
                            else {
                                if (!xmlStreamReader.getLocalName().equals("user_id")) {
                                    continue;
                                }
                                c.b(UUID.fromString(xmlStreamReader.getElementText()));
                            }
                        }
                    }
                    if (c.getPlayerName() == null || c.getPlayerName().length() < 2) {
                        d.b("Fixing username in stats of user with UUID '" + uuid + "'...");
                        final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(uuid);
                        if (offlinePlayer != null && offlinePlayer.getName() != null) {
                            c.x(offlinePlayer.getName());
                            c.save();
                            d.c("-> Fix was successful (Username: " + c.getPlayerName() + ") !");
                        }
                        else {
                            d.b("-> Failed as the user never joined the server before");
                        }
                    }
                    return c;
                }
                catch (XMLStreamException ex) {}
                catch (IOException ex2) {
                    d.b("Failed to load corrupted stats by '" + uuid + "'. Loading empty stats.");
                }
                finally {
                    ((InputStreamReader)reader).close();
                }
                return null;
            }
        });
    }
    
    @Override
    public Future<UUID[]> c() {
        return this.a((Callable<UUID[]>)new Callable<UUID[]>() {
            public UUID[] a() throws Exception {
                final ArrayList<UUID> list = new ArrayList<UUID>();
                File[] listFiles;
                for (int length = (listFiles = s.m.listFiles()).length, i = 0; i < length; ++i) {
                    final File file = listFiles[i];
                    if (file.getName().endsWith(".yml")) {
                        list.add(UUID.fromString(file.getName().replaceFirst(".yml", "")));
                    }
                }
                return list.toArray(new UUID[list.size()]);
            }
        });
    }
    
    @Override
    public Future<Void> a(final c c) {
        return this.a((Callable<Void>)new Callable<Void>() {
            public Void a() throws Exception {
                final File d = b(c.getUUID());
                if (d.exists()) {
                    d.delete();
                }
                return null;
            }
        });
    }
    
    @Override
    public Future<Void> b(final c c) {
        return this.a((Callable<Void>)new Callable<Void>() {
            public Void a() throws Exception {
                Writer writer = null;
                try {
                    writer = new FileWriter(b(c.getUUID()));
                    final XMLStreamWriter xmlStreamWriter = XMLOutputFactory.newInstance().createXMLStreamWriter(writer);
                    xmlStreamWriter.writeStartDocument();
                    xmlStreamWriter.writeStartElement("stats");
                    xmlStreamWriter.writeAttribute("rank", new StringBuilder().append(c.getRank()).toString());
                    xmlStreamWriter.writeAttribute("wins", new StringBuilder().append(c.getWins()).toString());
                    xmlStreamWriter.writeAttribute("loses", new StringBuilder().append(c.getLoses()).toString());
                    xmlStreamWriter.writeAttribute("kills", new StringBuilder().append(c.getKills()).toString());
                    xmlStreamWriter.writeAttribute("deaths", new StringBuilder().append(c.getDeaths()).toString());
                    xmlStreamWriter.writeAttribute("bedsDestroyed", new StringBuilder().append(c.getBedsDestroyed()).toString());
                    xmlStreamWriter.writeAttribute("roundsPlayed", new StringBuilder().append(c.getRoundsPlayed()).toString());
                    xmlStreamWriter.writeAttribute("playTime", new StringBuilder().append(c.getPlayTime()).toString());
                    xmlStreamWriter.writeAttribute("coins", new StringBuilder().append(c.getCoins()).toString());
                    xmlStreamWriter.writeAttribute("finalKills", new StringBuilder().append(c.q()).toString());
                    xmlStreamWriter.writeStartElement("user_name");
                    xmlStreamWriter.writeCharacters((c.getPlayerName() != null) ? c.getPlayerName() : "?");
                    xmlStreamWriter.writeEndElement();
                    xmlStreamWriter.writeStartElement("user_uuid");
                    xmlStreamWriter.writeCharacters(c.getUUID().toString());
                    xmlStreamWriter.writeEndElement();
                    xmlStreamWriter.writeEndElement();
                    xmlStreamWriter.writeEndDocument();
                    xmlStreamWriter.flush();
                }
                catch (XMLStreamException ex2) {}
                catch (IOException ex) {
                    ex.printStackTrace();
                    return null;
                }
                finally {
                    ((OutputStreamWriter)writer).close();
                }
                ((OutputStreamWriter)writer).close();
                return null;
            }
        });
    }
    
    @Override
    public Future<Boolean> e(final UUID uuid) {
        return this.a((Callable<Boolean>)new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                return c(uuid).exists();
            }
        });
    }
    
    @Override
    public Future<UserAchievements> f(final UUID uuid) {
        return this.a((Callable<UserAchievements>)new Callable<UserAchievements>() {
            public UserAchievements a() throws Exception {
                if (!c(uuid).exists()) {
                    return null;
                }
                final FileInputStream in = new FileInputStream(c(uuid));
                final ObjectInputStream objectInputStream = new ObjectInputStream(in);
                final UserAchievements userAchievements = (UserAchievements)objectInputStream.readObject();
                userAchievements.uuid = uuid;
                in.close();
                objectInputStream.close();
                return userAchievements;
            }
        });
    }
    
    @Override
    public Future<Void> a(final UserAchievements userAchievements) {
        return this.a((Callable<Void>)new Callable<Void>() {
            public Void a() throws Exception {
                final File e = c(userAchievements.getUUID());
                if (e.exists()) {
                    e.delete();
                }
                return null;
            }
        });
    }
    
    @Override
    public Future<Void> b(final UserAchievements userAchievements) {
        return this.a((Callable<Void>)new Callable<Void>() {
            public Void a() throws Exception {
                final FileOutputStream out = new FileOutputStream(c(userAchievements.getUUID()));
                final ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);
                objectOutputStream.writeObject(userAchievements);
                objectOutputStream.close();
                out.close();
                return null;
            }
        });
    }
    
    private static File b(final UUID uuid) {
        return new File(s.m, String.valueOf(uuid.toString()) + ".yml");
    }
    
    private static File c(final UUID uuid) {
        return new File(s.k, String.valueOf(uuid.toString()) + ".cfg");
    }
}
