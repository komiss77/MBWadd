// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;

public class cV extends cR
{
    public ProtocolManager a;
    
    @Override
    public cT a() {
        return cT.u;
    }
    
    @Override
    public void onEnable() {
        this.a = ProtocolLibrary.getProtocolManager();
    }
    
    @Override
    public void onDisable() {
    }
}
