// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.flag.g;
import de.marcely.bedwars.versions.w;
import de.marcely.bedwars.flag.Value;
import org.bukkit.Material;
import de.marcely.bedwars.util.s;
import de.marcely.sbenlib.util.BufferedReadStream;
import org.bukkit.World;
import de.marcely.bedwars.flag.d;
import java.util.Collection;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.h;
import de.marcely.bedwars.util.a;
import de.marcely.sbenlib.util.BufferedWriteStream;
import org.bukkit.block.Block;

public class bL
{
    public static void a(final Block block, final BufferedWriteStream bufferedWriteStream, final bN bn) {
        if (a.a(block).equals("AIR")) {
            return;
        }
        bufferedWriteStream.writeSignedInt(block.getTypeId());
        h.a(block.getX() - bn.ad, bufferedWriteStream);
        bufferedWriteStream.writeUnsignedByte(block.getY());
        h.a(block.getZ() - bn.ae, bufferedWriteStream);
        bn.ad = block.getX();
        bn.ae = block.getZ();
        if (Version.a().getVersionNumber() < 13) {
            bufferedWriteStream.writeByte(block.getData());
        }
        final d a = Version.a().a(block.getLocation());
        if (a == null || ((Value<Collection>)a).getValue().size() == 0) {
            bufferedWriteStream.writeByte((byte)(-1));
            return;
        }
        a.write(bufferedWriteStream);
    }
    
    public static boolean a(final World world, final BufferedReadStream bufferedReadStream, final Version version, final boolean b, final bN bn, final int n) throws Exception {
        final int signedInt = bufferedReadStream.readSignedInt();
        if (signedInt == Integer.MIN_VALUE) {
            return true;
        }
        final int ad = bn.ad + h.a(bufferedReadStream);
        bn.ad = ad;
        final int n2 = ad;
        final int unsignedByte = bufferedReadStream.readUnsignedByte();
        final int ae = bn.ae + h.a(bufferedReadStream);
        bn.ae = ae;
        final Block a = s.a(world, n2, unsignedByte, ae);
        if (version.getVersion() < 13) {
            final Material material = Material.getMaterial(signedInt);
            if (material == null) {
                if (!b) {
                    a.setType(Material.AIR);
                }
                else {
                    Version.a().a(a.getLocation(), Material.AIR, (byte)0);
                }
                bufferedReadStream.readByte();
                Value.a(bufferedReadStream);
                return false;
            }
            if (b) {
                Version.a().a(a.getLocation(), material, bufferedReadStream.readByte());
            }
            else {
                a.setType(material);
                a.setData(bufferedReadStream.readByte());
            }
        }
        else if (n <= 1) {
            final String string = bufferedReadStream.readString();
            if (n == 0) {
                final Material material2 = Material.getMaterial(string);
                if (material2 != null) {
                    Version.a().a(a.getLocation(), material2, (byte)0);
                }
            }
            else {
                ((w)Version.a().a()).b(a.getWorld(), a.getX(), a.getY(), a.getZ(), string);
            }
        }
        d d = (d)Value.a(bufferedReadStream);
        if (d != null && ((Value<Collection>)d).getValue().size() > 0) {
            if (n <= 1) {
                final d d2 = d;
                d = new d();
                d.a(new g("entity", d2));
            }
            Version.a().a(a.getLocation(), d);
        }
        return false;
    }
}
