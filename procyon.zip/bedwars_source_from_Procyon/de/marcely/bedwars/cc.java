// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;

public class cc extends bS<Void>
{
    public static cc a;
    
    static {
        cc.a = new cc();
    }
    
    @Override
    public bP.c a() {
        return bP.c.d;
    }
    
    @Override
    public String a(final Void void1) {
        return this.c(null);
    }
    
    @Override
    public String c(final Arena arena) {
        return s.u();
    }
}
