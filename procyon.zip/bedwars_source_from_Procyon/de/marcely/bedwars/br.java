// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class br extends Exception
{
    private static final long serialVersionUID = 1L;
    
    public br() {
        this("This is not supported!");
    }
    
    public br(final String message) {
        super(message);
    }
}
