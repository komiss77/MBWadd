// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.World;
import java.io.File;
import org.bukkit.plugin.Plugin;
import java.util.Iterator;
import org.bukkit.Chunk;
import de.marcely.bedwars.util.Synchronizer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import de.marcely.bedwars.util.MThread;
import de.marcely.bedwars.game.regeneration.serializable.REntity;
import de.marcely.bedwars.game.regeneration.serializable.RBlock;
import org.bukkit.Material;
import org.bukkit.Location;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import java.util.List;
import de.marcely.bedwars.game.regeneration.RegionData;
import de.marcely.bedwars.game.arena.RegenerationType;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import org.bukkit.command.CommandSender;
import org.bukkit.scheduler.BukkitRunnable;
import de.marcely.bedwars.game.arena.Arena;

@Deprecated
public class aj
{
    private Arena arena;
    private BukkitRunnable a;
    private int regenerationSpeed;
    private CommandSender sender;
    private boolean running;
    private int x;
    private int y;
    private int z;
    private int xMax;
    private int yMax;
    private int B;
    private long d;
    
    public aj(final Arena arena, final int regenerationSpeed, final CommandSender sender) {
        this.running = false;
        this.d = -1L;
        this.arena = arena;
        this.regenerationSpeed = regenerationSpeed;
        this.sender = sender;
    }
    
    public void b(final int regenerationSpeed) {
        this.regenerationSpeed = regenerationSpeed;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public int getRegenerationSpeed() {
        return this.regenerationSpeed;
    }
    
    public boolean isRunning() {
        return this.running;
    }
    
    public boolean cancel() {
        if (this.isRunning()) {
            this.running = false;
            if (this.a != null) {
                this.a.cancel();
            }
            if (this.sender != null) {
                s.a(this.sender, b.a(Language.Regeneration_Stopped).a("arena", this.arena.getName()).a("time", new StringBuilder().append((System.currentTimeMillis() - this.d) / 1000.0).toString()));
            }
            return true;
        }
        return false;
    }
    
    public boolean run() {
        if (!this.isRunning()) {
            this.running = true;
            this.arena.a(ArenaStatus.g, true);
            if (this.arena.a() == RegenerationType.c) {
                this.x = (int)this.arena.getPosMin().getX();
                this.y = (int)this.arena.getPosMin().getY();
                this.z = (int)this.arena.getPosMin().getZ();
                this.xMax = (int)this.arena.getPosMax().getX();
                this.yMax = (int)this.arena.getPosMax().getY();
                this.B = (int)this.arena.getPosMax().getZ();
            }
            this.q();
            return true;
        }
        return false;
    }
    
    private void q() {
        boolean b = false;
        synchronized (this) {
            b = true;
        }
        if (!b) {
            new bp().printStackTrace();
            return;
        }
        if (this.arena.getWorld() == null) {
            de.marcely.bedwars.d.b("There's a problem with the world by the arena '" + this.arena.getName() + "'!!");
            this.arena.a(ArenaStatus.e);
            return;
        }
        if (!ak.exists(this.arena.getName())) {
            de.marcely.bedwars.d.b("Missing '/MBedwars/arenablocks/" + this.arena.getName() + ".yml' file!!");
            this.arena.a(ArenaStatus.e);
            return;
        }
        this.d = System.currentTimeMillis();
        if (this.arena.a() == RegenerationType.c) {
            ak.a(new ak.a() {
                final /* synthetic */ aj a;
                
                @Override
                public void a(final RegionData regionData) {
                    if (regionData == null) {
                        de.marcely.bedwars.d.b("The file '/MBedwars/arenablocks/" + aj.this.arena.getName() + ".yml' is corrupted!!");
                        aj.this.arena.a(ArenaStatus.e);
                        de.marcely.bedwars.config.b.b(aj.this.arena);
                        return;
                    }
                    if (regionData.getBlocks().size() == 0) {
                        de.marcely.bedwars.d.b("The file '/MBedwars/arenablocks/" + aj.this.arena.getName() + ".yml' is empty!!");
                        aj.this.arena.a(ArenaStatus.e);
                        de.marcely.bedwars.config.b.b(aj.this.arena);
                        return;
                    }
                    aj.a(aj.this, new BukkitRunnable() {
                        int C = 0;
                        int D = (int)((aj$1)ak.a.this).a.arena.getPosMin().getX();
                        int E = (int)((aj$1)ak.a.this).a.arena.getPosMin().getY();
                        int F = (int)((aj$1)ak.a.this).a.arena.getPosMin().getZ();
                        int G = 0;
                        int H = -1;
                        int I = 0;
                        boolean p = false;
                        private final /* synthetic */ List w = al.b.a(regionData.getBlocks());
                        
                        public void run() {
                            if (this.C == 0) {
                                for (final Entity entity : ((aj$1)regionData).a.arena.getWorld().getEntities()) {
                                    if (entity.getType() != EntityType.PLAYER && entity.getType() != EntityType.DROPPED_ITEM && ((aj$1)regionData).a.arena.isInside(entity.getLocation())) {
                                        entity.remove();
                                    }
                                }
                                ++this.C;
                            }
                            else if (this.C == 1) {
                                for (int i = 0; i < ConfigValue.regeneration_speed_ms; ++i) {
                                    ++this.D;
                                    if (this.D > ((aj$1)regionData).a.arena.getPosMax().getX()) {
                                        this.D = (int)((aj$1)regionData).a.arena.getPosMin().getX();
                                        ++this.E;
                                    }
                                    if (this.E > ((aj$1)regionData).a.arena.getPosMax().getY()) {
                                        this.E = (int)((aj$1)regionData).a.arena.getPosMin().getY();
                                        ++this.F;
                                    }
                                    if (this.F > ((aj$1)regionData).a.arena.getPosMax().getZ()) {
                                        ++this.C;
                                        return;
                                    }
                                    Version.a().a(new Location(((aj$1)regionData).a.arena.getWorld(), (double)this.D, (double)this.E, (double)this.F), Material.AIR, (byte)0);
                                }
                            }
                            else if (this.C == 2) {
                                if (this.G < regionData.getBlocks().size()) {
                                    int size = this.G + ConfigValue.regeneration_speed_ms;
                                    if (size > regionData.getBlocks().size()) {
                                        size = regionData.getBlocks().size();
                                    }
                                    for (int j = this.G; j < size; ++j) {
                                        if (j % 50000 == 0) {
                                            ++this.H;
                                        }
                                        final RBlock rBlock = this.w.get(this.H).blocks.get(j - this.H * 50000);
                                        try {
                                            rBlock.a(((aj$1)regionData).a.arena.getWorld(), ((aj$1)regionData).a.arena);
                                        }
                                        catch (Exception ex) {
                                            de.marcely.bedwars.d.b("[Regeneration] Skipped block placement at X" + rBlock.getX() + " Y" + rBlock.getY() + " Z" + rBlock.getZ() + " in arena " + ((aj$1)regionData).a.arena.getName());
                                        }
                                    }
                                    this.G = size;
                                }
                                else {
                                    ++this.C;
                                }
                            }
                            else if (this.C == 3) {
                                int n = ((aj$1)regionData).a.regenerationSpeed / 25000;
                                if (n <= 0) {
                                    n = 1;
                                }
                                boolean b = false;
                                for (int k = 0; k < n; ++k) {
                                    final int n2 = this.I + k;
                                    if (n2 >= regionData.getEntities().size()) {
                                        b = true;
                                        break;
                                    }
                                    final REntity rEntity = regionData.getEntities().get(n2);
                                    try {
                                        rEntity.a(((aj$1)regionData).a.arena.getWorld());
                                    }
                                    catch (Exception ex2) {
                                        de.marcely.bedwars.d.b("[Regeneration] Skipped entity type " + rEntity.getType().name() + " in arena " + ((aj$1)regionData).a.arena.getName());
                                    }
                                }
                                this.I += n;
                                if (b) {
                                    for (final REntity rEntity2 : regionData.getEntities()) {
                                        if (rEntity2.b() != null && rEntity2.a() != null) {
                                            final REntity a = regionData.a(rEntity2.b());
                                            if (a.a() == null) {
                                                continue;
                                            }
                                            rEntity2.a().setPassenger(a.a());
                                        }
                                    }
                                    ++this.C;
                                }
                            }
                            else if (this.C == 4) {
                                if (!this.p) {
                                    this.p = true;
                                    new MThread(MThread.ThreadType.m, ((aj$1)regionData).a.arena.getName()) {
                                        private final /* synthetic */ List x = ((aj$1)regionData).a.arena.m();
                                        
                                        @Override
                                        public void run() {
                                            final ArrayList<Player> list = new ArrayList<Player>();
                                            for (final Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(((aj$1)regionData).a.arena.a().toBukkit(((aj$1)regionData).a.arena.getWorld()), Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16, Bukkit.getViewDistance() * 16)) {
                                                if (entity.getType() == EntityType.PLAYER) {
                                                    list.add((Player)entity);
                                                }
                                            }
                                            new Synchronizer() {
                                                private final /* synthetic */ List x = aj$1$1$1.this.x;
                                                
                                                @Override
                                                public void run() {
                                                    final Iterator<Chunk> iterator = this.x.iterator();
                                                    while (iterator.hasNext()) {
                                                        Version.a().a(iterator.next(), (Player[])list.toArray(new Player[list.size()]));
                                                    }
                                                }
                                            };
                                            final BukkitRunnable a = BukkitRunnable.this;
                                            ++a.C;
                                        }
                                    }.start();
                                }
                            }
                            else if (this.C == 5) {
                                aj.a(((aj$1)regionData).a, false);
                                aj.this.r();
                                ((aj$1)regionData).a.arena.a().reset();
                                this.cancel();
                                ((aj$1)regionData).a.arena.a(ArenaStatus.e);
                                de.marcely.bedwars.config.b.b(((aj$1)regionData).a.arena);
                            }
                        }
                    });
                    aj.this.a.runTaskTimer((Plugin)MBedwars.a, 0L, (long)ConfigValue.performance.v);
                }
            }, null, this.arena);
        }
        else if (this.arena.a() == RegenerationType.d) {
            new Synchronizer() {
                final /* synthetic */ aj a = de.marcely.bedwars.game.regeneration.d.a(aj.this.arena.getWorld(), new File("plugins/MBedwars/data/arenablocks/" + aj.this.arena.getName() + ".yml"));
                private final /* synthetic */ World a = de.marcely.bedwars.game.regeneration.d.a(aj.this.arena.getWorld(), new File("plugins/MBedwars/data/arenablocks/" + aj.this.arena.getName() + ".yml"));
                
                @Override
                public void run() {
                    if (World.this != null) {
                        aj.this.arena.setWorld(World.this);
                        for (final Entity entity : de.marcely.bedwars.util.b.getNearbyEntities(new Location(aj.this.arena.getWorld(), (double)(aj.this.x + (aj.this.xMax - aj.this.x) / 2), (double)(aj.this.y + (aj.this.yMax - aj.this.y) / 2), (double)(aj.this.z + (aj.this.B - aj.this.z) / 2)), (aj.this.xMax - aj.this.x) / 2, (aj.this.yMax - aj.this.y) / 2, (aj.this.B - aj.this.z) / 2)) {
                            if (entity.getType() == EntityType.DROPPED_ITEM || entity.getType() == EntityType.EXPERIENCE_ORB) {
                                entity.remove();
                            }
                        }
                        aj.this.arena.a().reset();
                        aj.this.arena.a(ArenaStatus.e);
                        de.marcely.bedwars.config.b.b(aj.this.arena);
                        aj.this.r();
                    }
                    else {
                        de.marcely.bedwars.d.b("The file '/MBedwars/arenablocks/" + aj.this.arena.getName() + ".yml' is corrupted!!");
                        aj.this.arena.a(ArenaStatus.e);
                        de.marcely.bedwars.config.b.b(aj.this.arena);
                    }
                }
            };
        }
    }
    
    private void r() {
        if (this.sender != null) {
            s.a(this.sender, b.a(Language.Regeneration_Done).a("arena", (this.arena != null) ? this.arena.getName() : "Unkown").a("time", new StringBuilder().append((System.currentTimeMillis() - this.d) / 1000.0).toString()));
        }
    }
    
    static /* synthetic */ void a(final aj aj, final boolean running) {
        aj.running = running;
    }
    
    static /* synthetic */ void a(final aj aj, final BukkitRunnable a) {
        aj.a = a;
    }
}
