// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.config.ConfigValue;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import com.mysql.jdbc.Connection;

@Deprecated
public class ah
{
    private String host;
    private String database;
    private String username;
    private String password;
    private int port;
    private Connection a;
    private static ah a;
    
    static {
        ah.a = new ah();
    }
    
    public ah() {
        this.a = null;
    }
    
    public ah(final String host, final int port, final String database, final String username, final String password) {
        this.a = null;
        this.host = host;
        this.port = port;
        this.database = database;
        this.username = username;
        this.password = password;
    }
    
    public boolean isConnected() {
        try {
            return this.a != null && !this.a.isClosed();
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    public String getHost() {
        return this.host;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public String getDatabase() {
        return this.database;
    }
    
    public Connection a() {
        try {
            if (!this.isConnected()) {
                this.connect();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return this.a;
    }
    
    public boolean connect() throws SQLException {
        if (!this.isConnected()) {
            this.a = (Connection)DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database + "?autoReconnect=true", this.username, this.password);
            return true;
        }
        return false;
    }
    
    public boolean close() {
        if (this.isConnected()) {
            try {
                this.a.close();
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
            this.a = null;
            return true;
        }
        return false;
    }
    
    public void k(final String str, final String str2) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [createTableIfNotExists]");
            return;
        }
        final PreparedStatement prepareStatement = this.a.prepareStatement("CREATE TABLE IF NOT EXISTS " + str + " (" + str2 + ")");
        prepareStatement.execute();
        prepareStatement.close();
    }
    
    public void a(final String str, final String str2, final String str3, final String str4) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [addColoumToTableIfNotExists]");
            return;
        }
        try {
            final PreparedStatement prepareStatement = this.a.prepareStatement("ALTER TABLE " + str + " ADD " + str2 + " " + str3 + " NOT NULL DEFAULT '" + str4 + "'");
            prepareStatement.execute();
            prepareStatement.close();
        }
        catch (SQLException ex) {}
    }
    
    public void a(final String str, final String str2, final String str3) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [setStatementsInTable]");
            return;
        }
        final PreparedStatement prepareStatement = this.a.prepareStatement("INSERT INTO " + str + " (" + str2 + ") VALUES (" + str3 + ")");
        prepareStatement.execute();
        prepareStatement.close();
    }
    
    public void a(final String str, final String str2, final String str3, final String str4, final String str5) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [updateStatementInTable]");
            return;
        }
        final PreparedStatement prepareStatement = this.a.prepareStatement("UPDATE " + str + " SET " + str4 + " = '" + str5 + "' WHERE " + str2 + " = '" + str3 + "'");
        prepareStatement.execute();
        prepareStatement.close();
    }
    
    public boolean a(final String str, final String str2, final String str3) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [existsInTable]");
            return false;
        }
        final PreparedStatement prepareStatement = this.a.prepareStatement("SELECT COUNT(*) FROM " + str + " WHERE " + str2 + "='" + str3 + "'");
        final ResultSet executeQuery = prepareStatement.executeQuery();
        boolean b = false;
        if (executeQuery.next()) {
            b = (executeQuery.getInt(1) >= 1);
        }
        executeQuery.close();
        prepareStatement.close();
        return b;
    }
    
    public List<String> a(final String str, final String str2) throws SQLException {
        if (!this.isConnected()) {
            d.g("Tried to make an operation while it is not connected. [getValuesInTable]");
            return null;
        }
        final PreparedStatement prepareStatement = this.a.prepareStatement("SELECT " + str2 + " FROM " + str);
        final ResultSet executeQuery = prepareStatement.executeQuery();
        final ArrayList<String> list = new ArrayList<String>();
        while (executeQuery.next()) {
            list.add(executeQuery.getString(1));
        }
        executeQuery.close();
        prepareStatement.close();
        return list;
    }
    
    public static void onEnable() {
        if (ConfigValue.sql_enabled) {
            ah.a = new ah(ConfigValue.sql_host, ConfigValue.sql_port, ConfigValue.sql_database, ConfigValue.sql_user, ConfigValue.sql_password);
            try {
                ah.a.connect();
                d.f("MySQL is now successfully enabled.");
            }
            catch (SQLException ex) {
                d.a(ex);
            }
        }
    }
    
    public static void onDisable() {
        if (s()) {
            ah.a.close();
        }
    }
    
    public static boolean s() {
        return ah.a != null && ah.a.isConnected();
    }
    
    public static ah a() {
        return ah.a;
    }
}
