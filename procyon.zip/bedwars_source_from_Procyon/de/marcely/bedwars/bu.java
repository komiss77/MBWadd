// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.List;
import java.util.Iterator;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.Arena;
import de.marcely.bedwars.api.arena.picker.ArenaPickerExecutor;

public enum bu
{
    a("RANDOM", 0, (list, p1) -> list.get(s.RAND.nextInt(list.size()))), 
    b("BEST", 1, (list2, arena2) -> {
        list2.stream().map(arena -> arena.getPlayers().size()).mapToInt(n -> n).max().orElse(-1);
        list2.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getPlayers().size() != n2) {
                iterator.remove();
            }
        }
        if (arena2 != null && list2.contains(arena2)) {
            return arena2;
        }
        else {
            return (Arena)list2.get(s.RAND.nextInt(list2.size()));
        }
    });
    
    private final ArenaPickerExecutor b;
    
    static {
        a = new bu[] { bu.a, bu.b };
    }
    
    private bu(final String name, final int ordinal, final ArenaPickerExecutor b) {
        this.b = b;
    }
    
    public static void init() {
        if (s.ab.size() >= 1) {
            return;
        }
        bu[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final bu bu = values[i];
            s.ab.put(bu.toString().toLowerCase(), bu.b);
        }
    }
    
    public ArenaPickerExecutor b() {
        return this.b;
    }
}
