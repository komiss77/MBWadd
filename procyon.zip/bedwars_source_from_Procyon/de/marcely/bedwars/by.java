// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;

public abstract class by
{
    private PlayerUseExtraItemEvent a;
    
    protected abstract void onUse(final PlayerUseExtraItemEvent p0);
    
    public abstract void K();
    
    public void a(final PlayerUseExtraItemEvent a) {
        this.onUse(this.a = a);
        if (this.isActive()) {
            ((Arena)a.getArena()).N.add(this);
        }
    }
    
    public boolean isActive() {
        return this.a != null;
    }
    
    public void stop() {
        this.done();
    }
    
    protected void done() {
        if (!this.isActive()) {
            return;
        }
        ((Arena)this.a.getArena()).N.remove(this);
        this.a = null;
        this.K();
    }
    
    protected void L() {
        s.a(this.a.getPlayer(), this.a.getExtraItem().getItemStack(1), this.a.getPlayer().getInventory().getHeldItemSlot());
    }
}
