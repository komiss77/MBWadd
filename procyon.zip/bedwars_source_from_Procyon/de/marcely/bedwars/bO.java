// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.io.InputStream;
import de.marcely.bedwars.util.f;
import java.util.zip.InflaterInputStream;
import de.marcely.sbenlib.util.BufferedReadStream;
import java.io.FileInputStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Deflater;
import java.io.FileOutputStream;
import de.marcely.bedwars.util.n;
import org.bukkit.Location;
import de.marcely.bedwars.versions.Version;
import java.io.File;

public class bO extends bN
{
    public static final byte VERSION = 1;
    private static final byte n = 5;
    private static final byte[] a;
    private final File file;
    
    static {
        a = new byte[] { 77, 97, 114, 99, 101, 108, 121, 115, 82, 103, 110, 83, 121, 115, 116, 101, 109 };
    }
    
    public bO(final File file, final int n, final int n2, final int n3) {
        super(n, n2, n3);
        this.file = file;
    }
    
    public bO(final File file, final Version version, final long n, final int n2, final int n3, final int n4) {
        super(n2, n3, n4);
        this.file = file;
    }
    
    public void a(final Location location, final Runnable runnable, final n<Long> n) throws Exception {
        if (this.file.exists()) {
            this.file.delete();
        }
        this.file.createNewFile();
        final FileOutputStream out = new FileOutputStream(this.file);
        out.write(bO.a);
        out.write(1);
        final BufferedWriteStream bufferedWriteStream = new BufferedWriteStream(new DeflaterOutputStream(out, new Deflater(5)));
        super.a(bufferedWriteStream, location, new Runnable() {
            @Override
            public void run() {
                ((BufferedWriteStream)runnable).close();
                runnable.run();
            }
        }, n);
    }
    
    @Override
    public void a(final BufferedWriteStream bufferedWriteStream, final Location location, final Runnable runnable, final n<Long> n) {
        new bo().printStackTrace();
    }
    
    public static b a(final File file, final Location location, final boolean b) throws Exception {
        if (!file.exists()) {
            return new b(c.g, "?");
        }
        InputStream in = null;
        try {
            in = new FileInputStream(file);
            final BufferedReadStream bufferedReadStream = new BufferedReadStream(in);
            if (!bufferedReadStream.readAndCheckMagic(bO.a)) {
                bufferedReadStream.close();
                return new b(c.b, "?");
            }
            final byte byte1 = bufferedReadStream.readByte();
            if (byte1 < 0 || byte1 > 1) {
                bufferedReadStream.close();
                return new b(c.h, "?");
            }
            BufferedReadStream bufferedReadStream2;
            if (byte1 == 0) {
                bufferedReadStream2 = new BufferedReadStream(in);
            }
            else {
                bufferedReadStream2 = new BufferedReadStream(f.readFully(new InflaterInputStream(in), -1, true));
            }
            return bN.a(bufferedReadStream2, location, b);
        }
        catch (Exception ex) {
            if (in != null) {
                ((FileInputStream)in).close();
            }
            throw ex;
        }
    }
    
    public File getFile() {
        return this.file;
    }
}
