// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Bukkit;
import de.marcely.bedwars.game.arena.Arena;

public class cn extends bS<Void>
{
    public static cn a;
    
    static {
        cn.a = new cn();
    }
    
    @Override
    public bP.c a() {
        return bP.c.a;
    }
    
    @Override
    public String a(final Void void1) {
        return this.c(null);
    }
    
    @Override
    public String c(final Arena arena) {
        return new StringBuilder().append(Bukkit.getOnlinePlayers().size()).toString();
    }
}
