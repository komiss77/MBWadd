// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import de.marcely.bedwars.message.b;
import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.TimerTask;
import de.marcely.bedwars.util.Synchronizer;
import de.marcely.bedwars.util.MThread;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import javax.annotation.Nullable;
import de.marcely.bedwars.extlibrary.c;
import java.util.Timer;

public class e
{
    private static final String c = "ws://msrv.marcely.de:1406";
    private Object a;
    private Timer a;
    private c a;
    private a a;
    private boolean running;
    @Nullable
    private String d;
    private boolean c;
    
    public e() {
        this.running = false;
        this.d = "?";
        this.c = false;
    }
    
    public boolean isRunning() {
        return this.running;
    }
    
    public boolean a(final a a) {
        return this.a(a, null);
    }
    
    public boolean a(final a a, @Nullable final CommandSender commandSender) {
        if (this.isRunning()) {
            return false;
        }
        if (Bukkit.isPrimaryThread()) {
            new MThread(MThread.ThreadType.r) {
                @Override
                public void run() {
                    ((e)a).a(a, commandSender);
                }
            }.start();
            return true;
        }
        this.running = true;
        this.a = a;
        if (a.g()) {
            (this.a = new c()).a(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (a == e.a.c) {
                            new Synchronizer(true) {
                                @Override
                                public void run() {
                                    ((e)a).a.loadLibraries();
                                }
                            };
                        }
                        e.this.a(commandSender);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        }
        else {
            try {
                this.a(commandSender);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        (this.a = new Timer()).schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    final ei ei = (ei)e.this.a;
                    if (ei == null) {
                        de.marcely.bedwars.d.b("A network error occured");
                        for (final Thread thread : MThread.getRunningThreads()) {
                            de.marcely.bedwars.d.b("Thread: " + MThread.getDisplayInfo(thread));
                            StackTraceElement[] stackTrace;
                            for (int length = (stackTrace = thread.getStackTrace()).length, i = 0; i < length; ++i) {
                                de.marcely.bedwars.d.b("\t" + stackTrace[i].toString());
                            }
                        }
                    }
                    if (ei != null && ei.isConnected()) {
                        e.this.a(de.marcely.bedwars.ei.a.f);
                    }
                    else {
                        e.this.a(de.marcely.bedwars.ei.a.a);
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }, 20000L);
        return true;
    }
    
    private void a(@Nullable final CommandSender commandSender) throws Exception {
        if (this.a == e.a.c) {
            final de.marcely.bedwars.extlibrary.d d = new de.marcely.bedwars.extlibrary.d();
            d.a = -1;
            d.name = "Java-WebSocket";
            d.version = 28;
            this.a.a(d, "websocket.jar");
            this.a.a(d, true);
        }
        this.a = new ei(URI.create("ws://msrv.marcely.de:1406")) {
            @Override
            public void onConnect() {
                if (e.this.a == e.a.c) {
                    this.a().a(new eq());
                }
            }
            
            @Override
            public void b(final ei.a a) {
                try {
                    e.this.a(a);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            
            @Override
            public void a(final de.marcely.bedwars.extlibrary.d[] array) {
                if (e.this.a != e.a.c) {
                    return;
                }
                boolean b = false;
                for (final de.marcely.bedwars.extlibrary.d d : array) {
                    if (!e.this.a.a(d.a, d.version, d.e)) {
                        e.this.a(d);
                        b = true;
                    }
                }
                if (!b) {
                    this.a(ei.a.f);
                }
            }
            
            @Override
            public void a(final boolean b, final String s) {
                e.a(e.this, b);
                if (b) {
                    e.a(e.this, s);
                }
                else {
                    e.a(e.this, "4.0.13");
                }
                if (b) {
                    de.marcely.bedwars.d.c(String.valueOf(Language.newUpdate.getMessage(commandSender)) + ": " + s);
                }
                if (commandSender != null) {
                    if (b) {
                        commandSender.sendMessage(String.valueOf(Language.newUpdate.getMessage(commandSender)) + ": " + s);
                    }
                    else {
                        s.a(commandSender, b.a(Language.noNewUpdate));
                    }
                }
                if (e.this.a == e.a.e || e.this.a == e.a.f) {
                    this.a(ei.a.f);
                }
            }
        };
        ((ei)this.a).connect();
    }
    
    private void a(final de.marcely.bedwars.extlibrary.d d) {
        ((ei)this.a).a().a(d, new em() {
            @Override
            public void a(final byte[] array, final int n) {
                try {
                    if (de.marcely.bedwars.util.c.a(array) != d.e) {
                        throw new RuntimeException("Self calculated checksum is different than expected checksum");
                    }
                    e.this.a.a(d, array);
                    de.marcely.bedwars.d.i("Downloaded module '" + d.name + "' v." + d.version);
                    if (n == 0) {
                        e.this.a(ei.a.f);
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
    
    public void a(final ei.a a) throws Exception {
        if (this.a != null) {
            if (a == ei.a.b) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("The use to this plugin has been banned for you.");
                de.marcely.bedwars.d.b("If you think that you didn't do anything wrong or think that this is an error, then please contact our support.");
                de.marcely.bedwars.d.b("============================");
                s.a(true, this.a);
            }
            else if (a == ei.a.e) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("It seems like that your current version (" + MBedwars.getVersion() + ") is outdated.");
                de.marcely.bedwars.d.b("Please install the latest version to fix that!");
                de.marcely.bedwars.d.b("Otherwise some plugin components, such as WorldEdit, SQL, etc. may won't work.");
                de.marcely.bedwars.d.b("============================");
                s.a(false, this.a);
            }
            else if (a == ei.a.a || a == ei.a.h || a == ei.a.c || a == ei.a.d) {
                de.marcely.bedwars.d.b("=============================");
                de.marcely.bedwars.d.b("Sorry, but we weren't able to identify your version.");
                de.marcely.bedwars.d.b("Please try it again with a working internet connection or look for an update!");
                de.marcely.bedwars.d.b("Otherwise some plugin components, such as WorldEdit, SQL, etc. may won't work.");
                de.marcely.bedwars.d.b("============================");
            }
            final ei ei = (ei)this.a;
            this.a = null;
            this.running = false;
            ei.a(a);
            if (this.a != null) {
                if (a == de.marcely.bedwars.ei.a.f) {
                    this.a.loadLibraries();
                }
                this.a.close();
            }
            if (this.a != null) {
                this.a.cancel();
                this.a = null;
            }
        }
    }
    
    @Nullable
    public String c() {
        return this.d;
    }
    
    public boolean f() {
        return this.c;
    }
    
    static /* synthetic */ void a(final e e, final boolean c) {
        e.c = c;
    }
    
    static /* synthetic */ void a(final e e, final String d) {
        e.d = d;
    }
    
    public enum a
    {
        c("BOOT", 0), 
        d("BOOT_BASIC", 1), 
        e("CHECK_UPDATE", 2), 
        f("INTERVAL", 3);
        
        static {
            a = new a[] { de.marcely.bedwars.e.a.c, de.marcely.bedwars.e.a.d, de.marcely.bedwars.e.a.e, de.marcely.bedwars.e.a.f };
        }
        
        private a(final String name, final int ordinal) {
        }
        
        public boolean g() {
            return this == de.marcely.bedwars.e.a.c;
        }
    }
}
