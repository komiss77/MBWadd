// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class z extends j
{
    private Arena arena;
    private int c;
    private int e;
    
    public z(final Arena arena, final int c, final int e) {
        this.arena = arena;
        this.c = c;
        this.e = e;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    public int c() {
        return this.c;
    }
    
    public int d() {
        return this.e;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.o.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;") + "/" + this.c();
    }
}
