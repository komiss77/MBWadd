// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class aW
{
    public static void a(final PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
        if (!as.u) {
            final PlayerInteractEntityEvent playerInteractEntityEvent = new PlayerInteractEntityEvent(playerInteractAtEntityEvent.getPlayer(), playerInteractAtEntityEvent.getRightClicked());
            aX.a(playerInteractEntityEvent);
            if (playerInteractEntityEvent.isCancelled()) {
                playerInteractAtEntityEvent.setCancelled(true);
            }
        }
    }
}
