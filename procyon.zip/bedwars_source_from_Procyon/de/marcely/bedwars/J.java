// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class J extends NormalPacket
{
    public String name;
    public String j;
    
    @Override
    public byte getPacketID() {
        return 35;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.name);
        bufferedWriteStream.writeString(this.j);
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
        this.name = bufferedReadStream.readString();
        this.j = bufferedReadStream.readString();
    }
}
