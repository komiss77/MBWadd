// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.Iterator;
import java.util.List;
import java.lang.reflect.Field;
import org.bukkit.entity.Player;
import de.marcely.bedwars.versions.NMSClass;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.events.PacketListener;
import com.comphenix.protocol.ProtocolManager;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.versions.Version;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import com.comphenix.protocol.PacketType;
import org.bukkit.plugin.Plugin;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;

public class ec extends PacketAdapter implements dZ
{
    private final dY a;
    private boolean af;
    private boolean ae;
    
    public ec(final dY a) {
        super((Plugin)MBedwars.a, ListenerPriority.NORMAL, a());
        this.af = false;
        this.ae = false;
        this.a = a;
    }
    
    private static PacketType[] a() {
        final ArrayList list = new ArrayList();
        list.addAll(Arrays.asList(PacketType.Play.Client.USE_ENTITY, PacketType.Play.Client.TAB_COMPLETE, PacketType.Play.Server.UPDATE_TIME, PacketType.Play.Server.UPDATE_HEALTH, PacketType.Play.Server.ENTITY_METADATA, PacketType.Play.Server.MAP_CHUNK, PacketType.Play.Server.ENTITY, PacketType.Play.Server.ENTITY_TELEPORT, PacketType.Play.Server.ENTITY, PacketType.Play.Server.POSITION, PacketType.Play.Server.RESPAWN));
        if (Version.a().getVersionNumber() <= 8) {
            list.addAll(Arrays.asList(PacketType.Play.Server.MAP_CHUNK_BULK, PacketType.Play.Server.REL_ENTITY_MOVE));
        }
        return (PacketType[])list.stream().toArray(PacketType[]::new);
    }
    
    public dY a() {
        return this.a;
    }
    
    public boolean isInjected() {
        if (!this.af) {
            return false;
        }
        final ProtocolManager a = s.b.get(cV.class).a;
        return a != null && !a.isClosed();
    }
    
    public boolean inject() {
        final ProtocolManager a = s.b.get(cV.class).a;
        if (this.af || a == null || a.isClosed()) {
            return false;
        }
        a.addPacketListener((PacketListener)this);
        return this.af = true;
    }
    
    public boolean Y() {
        if (!this.isInjected()) {
            return false;
        }
        s.b.get(cV.class).a.removePacketListener((PacketListener)this);
        this.af = false;
        return true;
    }
    
    public void onPacketReceiving(final PacketEvent packetEvent) {
        final Player player = packetEvent.getPlayer();
        if (player != this.a.getPlayer()) {
            return;
        }
        final PacketType packetType = packetEvent.getPacketType();
        final Object handle = packetEvent.getPacket().getHandle();
        try {
            if (packetType == PacketType.Play.Client.USE_ENTITY) {
                final Field declaredField = NMSClass.H.getDeclaredField("a");
                declaredField.setAccessible(true);
                final int int1 = declaredField.getInt(handle);
                final Field declaredField2 = NMSClass.H.getDeclaredField("action");
                declaredField2.setAccessible(true);
                final Object value = declaredField2.get(handle);
                final String s = (String)value.getClass().getMethod("name", (Class<?>[])new Class[0]).invoke(value, new Object[0]);
                if (s.equals("INTERACT")) {
                    this.a.d(int1);
                }
                else if (s.equals("ATTACK")) {
                    this.a.e(int1);
                }
            }
            else if (Version.a().getVersionNumber() <= 9 && packetType == PacketType.Play.Client.TAB_COMPLETE) {
                final String[] c = this.a.c((String)NMSClass.Q.getDeclaredMethod("a", (Class<?>[])new Class[0]).invoke(handle, new Object[0]));
                if (c != null) {
                    Version.a().sendPacket(player, NMSClass.P.getDeclaredConstructor(String[].class).newInstance(c));
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void onPacketSending(final PacketEvent packetEvent) {
        if (packetEvent.getPlayer() != this.a.getPlayer()) {
            return;
        }
        final PacketType packetType = packetEvent.getPacketType();
        final Object handle = packetEvent.getPacket().getHandle();
        boolean b = false;
        try {
            if (packetType == PacketType.Play.Server.UPDATE_TIME) {
                final Field declaredField = NMSClass.R.getDeclaredField("a");
                declaredField.setAccessible(true);
                final long longValue = (long)declaredField.get(handle);
                final Field declaredField2 = NMSClass.R.getDeclaredField("b");
                declaredField2.setAccessible(true);
                b = this.a.a(longValue, (long)declaredField2.get(handle));
            }
            else if (packetType == PacketType.Play.Server.REL_ENTITY_MOVE || packetType == PacketType.Play.Server.REL_ENTITY_MOVE_LOOK) {
                if (cA.a(s.a(NMSClass.ab, "a").getInt(handle))) {
                    s.a(NMSClass.ab, "c").set(handle, 0);
                }
            }
            else if (packetType == PacketType.Play.Server.ENTITY_TELEPORT) {
                if (cA.a(s.a(NMSClass.K, "a").getInt(handle))) {
                    if (Version.a().getVersionNumber() >= 9) {
                        s.a(NMSClass.K, "c").setDouble(handle, -20.0);
                    }
                    else {
                        s.a(NMSClass.K, "c").setInt(handle, (int)Math.floor(-640.0));
                    }
                }
            }
            else if (packetType == PacketType.Play.Server.UPDATE_HEALTH) {
                b = this.a.a((float)s.a(NMSClass.U, "a").get(handle), (int)s.a(NMSClass.U, "b").get(handle), (float)s.a(NMSClass.U, "c").get(handle));
            }
            else if (packetType == PacketType.Play.Server.ENTITY_METADATA) {
                if ((int)s.a(NMSClass.L, "a").get(handle) == this.a.getPlayer().getEntityId()) {
                    for (final Object next : (List)s.a(NMSClass.L, "b").get(handle)) {
                        int n;
                        Object o;
                        if (Version.a().getVersionNumber() >= 9) {
                            final Object value = s.a(next.getClass(), "a").get(next);
                            n = s.a(value.getClass(), "a").getInt(value);
                            o = s.a(next.getClass(), "b").get(next);
                        }
                        else {
                            n = s.a(next.getClass(), "b").getInt(next);
                            o = s.a(next.getClass(), "c").get(next);
                        }
                        if (Version.a().getVersionNumber() >= 14) {
                            if (n != 8) {
                                continue;
                            }
                            b = this.a.b((float)o);
                        }
                        else if (Version.a().getVersionNumber() >= 10) {
                            if (n != 7) {
                                continue;
                            }
                            b = this.a.b((float)o);
                        }
                        else {
                            if (n != 6) {
                                continue;
                            }
                            b = this.a.b((float)o);
                        }
                    }
                }
            }
            else if (packetType == PacketType.Play.Server.ENTITY_EQUIPMENT) {
                b = this.a.a((int)s.a(NMSClass.E, "a").get(handle), s.a(NMSClass.E, "b").get(handle), s.a(NMSClass.E, "c").get(handle));
            }
            else if (packetType == PacketType.Play.Server.MAP_CHUNK) {
                this.a.a((int)s.a(NMSClass.Y, "a").get(handle), (int)s.a(NMSClass.Y, "b").get(handle), this.ae);
            }
            else if (packetType == PacketType.Play.Server.MAP_CHUNK_BULK) {
                final int[] array = (int[])s.a(NMSClass.Z, "a").get(handle);
                final int[] array2 = (int[])s.a(NMSClass.Z, "b").get(handle);
                for (int i = 0; i < array.length; ++i) {
                    this.a.a(array[i], array2[i], this.ae);
                }
            }
            else if (packetType == PacketType.Play.Server.RESPAWN) {
                b = this.a.Z();
                if (!b) {
                    this.ae = true;
                }
            }
            else if (packetType == PacketType.Play.Server.POSITION && this.ae) {
                this.ae = false;
                this.a.ad();
            }
            if (b) {
                packetEvent.setCancelled(true);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
