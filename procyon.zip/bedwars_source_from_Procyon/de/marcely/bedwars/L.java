// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.sbenlib.network.packets.data.NormalPacket;

public class L extends NormalPacket
{
    @Override
    public byte getPacketID() {
        return 2;
    }
    
    @Override
    protected void write(final BufferedWriteStream bufferedWriteStream) {
    }
    
    @Override
    protected void read(final BufferedReadStream bufferedReadStream) {
    }
}
