// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class cw extends ct
{
    public static cw a;
    
    static {
        cw.a = new cw();
    }
    
    public String b(final c c) {
        return new StringBuilder().append(c.getRoundsPlayed()).toString();
    }
}
