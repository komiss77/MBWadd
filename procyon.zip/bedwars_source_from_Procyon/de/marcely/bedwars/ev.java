// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class ev extends ex
{
    public static final byte REPLY_SUCCESS = -1;
    public static final byte C = 0;
    public static final byte G = 1;
    public byte reply;
    
    @Override
    public ey a() {
        return ey.d;
    }
    
    @Override
    protected void a(final BufferedWriteStream bufferedWriteStream) {
    }
    
    @Override
    protected void a(final BufferedReadStream bufferedReadStream) {
        this.reply = bufferedReadStream.readByte();
    }
}
