// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.sql;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLTimeoutException;
import org.bukkit.plugin.Plugin;
import de.marcely.bedwars.MBedwars;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.Iterator;
import java.sql.SQLException;
import de.marcely.bedwars.api.SQLUpdateListener;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import java.sql.DriverManager;
import de.marcely.bedwars.d;
import java.sql.Connection;
import java.io.File;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.scheduler.BukkitTask;
import de.marcely.bedwars.util.MThread;
import java.util.Stack;

public class SQLConnection
{
    private static final int TIMEOUT = 12;
    private static final int TIMEOUT_WARN_COOLDOWN = 180000;
    public boolean doLog;
    private final String connectionString;
    private final String username;
    private final String password;
    private final SQLType type;
    private final boolean threaded;
    private boolean connected;
    private boolean isConnecting;
    private Stack<SQLTask> tasks;
    private MThread thread;
    private BukkitTask task;
    private long lastTimeoutWarn;
    private int timeoutWarnsSinceLastTime;
    
    public SQLConnection(final SQLType sqlType, final String str, final int i, final String str2, final String s, final String s2, final boolean b) {
        this(sqlType, "jdbc:" + sqlType.getName() + "://" + str + ":" + i + "/" + str2 + ConfigValue.sql_parameters, s, s2, b);
    }
    
    public SQLConnection(final SQLType sqlType, final File file, final boolean b) {
        this(sqlType, "jdbc:" + sqlType.getName() + "://" + file.getAbsolutePath(), null, null, b);
    }
    
    public SQLConnection(final SQLType type, final String connectionString, final String username, final String password, final boolean threaded) {
        this.doLog = true;
        this.connected = false;
        this.isConnecting = false;
        this.tasks = new Stack<SQLTask>();
        this.lastTimeoutWarn = 0L;
        this.timeoutWarnsSinceLastTime = 0;
        this.type = type;
        this.username = username;
        this.password = password;
        this.threaded = threaded;
        this.connectionString = connectionString;
    }
    
    private void loadDriver() {
        try {
            Class.forName(this.type.getDriver());
        }
        catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
    
    @Nullable
    private Connection open() throws Exception {
        if (this.type == SQLType.SQLite) {
            try {
                Class.forName("org.sqlite.JDBC");
            }
            catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        else if (this.type.getExtLibrary() != null) {
            final long currentTimeMillis = System.currentTimeMillis();
            while (!this.type.getExtLibrary().loaded) {
                if (System.currentTimeMillis() > currentTimeMillis + 15000L) {
                    d.g("FAILED TO OPEN SQL CONNECTION: Failed to download/read needed drivers. Make sure that you have a working internet connection");
                    return null;
                }
                Thread.sleep(1000L);
            }
            this.loadDriver();
        }
        if (this.username != null) {
            return DriverManager.getConnection(this.connectionString, this.username, this.password);
        }
        return DriverManager.getConnection(this.connectionString);
    }
    
    public boolean connect() {
        return this.connect(null);
    }
    
    public boolean connect(@Nullable final Runnable runnable) {
        if (this.isConnected()) {
            return false;
        }
        this.isConnecting = true;
        if (this.threaded) {
            (this.thread = new MThread(MThread.ThreadType.b) {
                @Override
                public void run() {
                    try {
                        SQLConnection.this.open().close();
                        if (SQLConnection.this.doLog) {
                            final Iterator<SQLUpdateListener> iterator = s.an.iterator();
                            while (iterator.hasNext()) {
                                iterator.next().onConnect(SQLConnection.this);
                            }
                            d.f("Successfully connected to the SQL server");
                        }
                        SQLConnection.access$1(SQLConnection.this, true);
                        SQLConnection.access$2(SQLConnection.this, false);
                        if (runnable != null) {
                            runnable.run();
                        }
                    }
                    catch (SQLException ex) {
                        d.a(ex);
                    }
                    catch (Exception ex2) {
                        ex2.printStackTrace();
                    }
                    SQLConnection.access$2(SQLConnection.this, false);
                    while (SQLConnection.this.isConnected()) {
                        SQLConnection.this.finishTasks();
                        try {
                            Thread.sleep(1000L);
                        }
                        catch (InterruptedException ex3) {}
                    }
                }
            }).start();
        }
        else {
            try {
                this.open().close();
                if (this.doLog) {
                    final Iterator<SQLUpdateListener> iterator = s.an.iterator();
                    while (iterator.hasNext()) {
                        iterator.next().onConnect(this);
                    }
                    d.f("Successfully connected to the SQL server");
                }
                this.connected = true;
                this.isConnecting = false;
                if (runnable != null) {
                    runnable.run();
                }
            }
            catch (SQLException ex) {
                d.a(ex);
            }
            catch (Exception ex2) {
                ex2.printStackTrace();
            }
            this.isConnecting = false;
            if (this.task == null) {
                this.task = new BukkitRunnable() {
                    public void run() {
                        if (SQLConnection.this.isConnected()) {
                            SQLConnection.this.finishTasks();
                        }
                        else {
                            this.cancel();
                        }
                    }
                }.runTaskTimer((Plugin)MBedwars.a, 20L, 20L);
            }
        }
        return true;
    }
    
    public boolean disconnect() {
        if (!this.isConnected()) {
            return false;
        }
        this.connected = false;
        if (this.thread != null) {
            this.thread = null;
        }
        else if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        final Iterator<SQLUpdateListener> iterator = s.an.iterator();
        while (iterator.hasNext()) {
            iterator.next().onDisconnect();
        }
        return true;
    }
    
    public boolean addTask(final SQLTask item) {
        if (!this.isConnected()) {
            return false;
        }
        this.tasks.push(item);
        return true;
    }
    
    private void finishTasks() {
        if (!this.tasks.empty()) {
            try {
                final Connection open = this.open();
                while (!this.tasks.isEmpty()) {
                    final SQLTask sqlTask = this.tasks.pop();
                    sqlTask.finished(this.doTask(sqlTask, open));
                }
                open.close();
            }
            catch (SQLException ex) {
                d.a(ex);
            }
            catch (Exception ex2) {
                ex2.printStackTrace();
            }
        }
    }
    
    @Nullable
    public SQLResult doTask(final SQLTask sqlTask) {
        SQLResult doTask = null;
        try {
            final Connection open = this.open();
            doTask = this.doTask(sqlTask, open);
            if (!sqlTask.isWithResult()) {
                open.close();
            }
        }
        catch (SQLException ex) {
            d.a(ex);
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
        }
        return doTask;
    }
    
    @Nullable
    private SQLResult doTask(final SQLTask sqlTask, final Connection connection) {
        while (this.isConnecting()) {
            try {
                Thread.sleep(50L);
            }
            catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        if (!this.isConnected()) {
            d.g("Failed to execute a SQL task as we aren't connected. Restart/Reload this plugin to reconnect.");
            return null;
        }
        try {
            final PreparedStatement prepareStatement = connection.prepareStatement(sqlTask.getTask());
            for (int i = 0; i < sqlTask.getParameters().size(); ++i) {
                prepareStatement.setObject(i + 1, sqlTask.getParameters().get(i));
            }
            prepareStatement.setQueryTimeout(12000);
            if (sqlTask.isWithResult()) {
                final ResultSet executeQuery = prepareStatement.executeQuery();
                sqlTask.finished(new SQLResult(connection, executeQuery));
                return new SQLResult(connection, executeQuery);
            }
            prepareStatement.executeUpdate();
            sqlTask.finished(null);
            prepareStatement.close();
            return null;
        }
        catch (SQLTimeoutException ex3) {
            if (System.currentTimeMillis() >= this.lastTimeoutWarn + 180000L) {
                d.g("Very slow network! Timed out after 12 seconds. " + this.timeoutWarnsSinceLastTime + " Queries have been canceled.");
                this.lastTimeoutWarn = System.currentTimeMillis();
                this.timeoutWarnsSinceLastTime = 0;
            }
            else {
                ++this.timeoutWarnsSinceLastTime;
            }
        }
        catch (SQLException ex2) {
            sqlTask.failed(ex2);
        }
        return null;
    }
    
    public SQLType getType() {
        return this.type;
    }
    
    public boolean isThreaded() {
        return this.threaded;
    }
    
    public boolean isConnected() {
        return this.connected;
    }
    
    public boolean isConnecting() {
        return this.isConnecting;
    }
    
    public Stack<SQLTask> getTasks() {
        return this.tasks;
    }
    
    static /* synthetic */ void access$1(final SQLConnection sqlConnection, final boolean connected) {
        sqlConnection.connected = connected;
    }
    
    static /* synthetic */ void access$2(final SQLConnection sqlConnection, final boolean isConnecting) {
        sqlConnection.isConnecting = isConnecting;
    }
}
