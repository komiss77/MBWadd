// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.sql;

import javax.annotation.Nullable;
import de.marcely.bedwars.extlibrary.ExtLibrary;

public enum SQLType
{
    MySQL("MySQL", 0, "mysql"), 
    MariaDB("MariaDB", 1, "mariadb", ExtLibrary.c, "org.mariadb.jdbc.Driver"), 
    MSSQL("MSSQL", 2, "sqlserver"), 
    SQLite("SQLite", 3, "sqlite");
    
    private final String name;
    @Nullable
    private final ExtLibrary extLibrary;
    @Nullable
    private final String driver;
    
    private SQLType(final String s, final int n, final String s2) {
        this(s, n, s2, null, null);
    }
    
    private SQLType(final String name, final int ordinal, final String name2, @Nullable final ExtLibrary extLibrary, final String driver) {
        this.name = name2;
        this.extLibrary = extLibrary;
        this.driver = driver;
    }
    
    public static SQLType getSQLType(final String s) {
        SQLType[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final SQLType sqlType = values[i];
            if (sqlType.name.equalsIgnoreCase(s) || sqlType.name().equalsIgnoreCase(s)) {
                return sqlType;
            }
        }
        return null;
    }
    
    public String getName() {
        return this.name;
    }
    
    @Nullable
    public ExtLibrary getExtLibrary() {
        return this.extLibrary;
    }
    
    @Nullable
    public String getDriver() {
        return this.driver;
    }
}
