// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.sql;

public class EmptySQLTask extends SQLTask
{
    public EmptySQLTask(final String s, final boolean b) {
        super(s, b);
    }
    
    @Override
    public void finished(final SQLResult sqlResult) {
    }
}
