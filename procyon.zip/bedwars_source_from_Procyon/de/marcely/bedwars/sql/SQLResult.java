// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.sql;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;

public class SQLResult
{
    private final Connection connection;
    private final ResultSet result;
    
    public SQLResult(final Connection connection, final ResultSet result) {
        this.connection = connection;
        this.result = result;
    }
    
    public void closeAll() throws SQLException {
        this.connection.close();
        this.result.close();
    }
    
    public ResultSet getResult() {
        return this.result;
    }
}
