// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.sql;

import de.marcely.bedwars.d;
import java.sql.SQLException;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public abstract class SQLTask
{
    private final String task;
    private final boolean withResult;
    private final List<Object> parameters;
    
    public SQLTask(final String task, final boolean withResult) {
        this.parameters = new ArrayList<Object>();
        this.task = task;
        this.withResult = withResult;
    }
    
    public abstract void finished(@Nullable final SQLResult p0);
    
    public void failed(final SQLException ex) {
        d.a(ex);
    }
    
    public SQLTask addParameter(final Object o) {
        this.parameters.add(o);
        return this;
    }
    
    public String getTask() {
        return this.task;
    }
    
    public boolean isWithResult() {
        return this.withResult;
    }
    
    public List<Object> getParameters() {
        return this.parameters;
    }
}
