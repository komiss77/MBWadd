// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class A extends j
{
    private String h;
    
    public A(final String h) {
        this.h = h;
    }
    
    public String f() {
        return this.h;
    }
    
    @Override
    public String d() {
        return a.e.getID() + "/" + this.f();
    }
    
    public static A a(final String s) {
        final String[] split = s.split("/");
        if (split.length == 2) {
            return new A(split[1]);
        }
        return null;
    }
}
