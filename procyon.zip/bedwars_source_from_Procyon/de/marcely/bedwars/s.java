// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;

public class s extends j
{
    private Arena arena;
    
    public s(final Arena arena) {
        this.arena = arena;
    }
    
    public Arena getArena() {
        return this.arena;
    }
    
    @Override
    public String d() {
        return String.valueOf(a.g.getID()) + "/" + this.arena.getName().replace("/", "&sKEYslash;");
    }
}
