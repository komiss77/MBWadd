// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Color;
import de.marcely.bedwars.api.VarParticle;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.message.b;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.entity.Entity;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.versions.Version;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.entity.EntityType;
import org.bukkit.event.HandlerList;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Block;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.api.event.PlayerUseExtraItemEvent;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Villager;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class bB extends by implements Listener
{
    private Player player;
    private BukkitTask d;
    private Villager a;
    private Ocelot a;
    private ArmorStand b;
    private int U;
    private int V;
    private a a;
    
    public bB() {
        this.U = 0;
        this.V = 20;
        this.a = new a(null);
    }
    
    public void onUse(final PlayerUseExtraItemEvent playerUseExtraItemEvent) {
        final Player player = playerUseExtraItemEvent.getPlayer();
        this.player = player;
        final Player player2 = player;
        final Block clickedBlock = playerUseExtraItemEvent.getClickedBlock();
        final BlockFace blockFace = playerUseExtraItemEvent.getBlockFace();
        if (clickedBlock == null) {
            this.done();
            return;
        }
        s.a(player2, Achievement.i);
        Sound.EXTRAITEM_MINISHOP_USE.play(player2);
        this.L();
        final Location location = clickedBlock.getLocation();
        final Location location2 = new Location(location.getWorld(), location.getX() + blockFace.getModX(), location.getY() + blockFace.getModY(), location.getZ() + blockFace.getModZ());
        this.L();
        this.a(location2);
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)MBedwars.a);
    }
    
    @Override
    public void K() {
        HandlerList.unregisterAll((Listener)this);
        if (this.a == null) {
            return;
        }
        this.c(this.a.getLocation());
        Sound.ENTITY_VILLAGER_DEATH.play(this.a.getLocation());
        this.a.remove();
        this.a.remove();
        this.b.remove();
        this.d.cancel();
    }
    
    private void a(final Location location) {
        final Villager a = (Villager)location.getWorld().spawnEntity(location, EntityType.VILLAGER);
        this.a = a;
        final Villager villager = a;
        villager.setMetadata("mbw_isMinishop", (MetadataValue)new FixedMetadataValue((Plugin)MBedwars.a, (Object)true));
        villager.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 4));
        final Ocelot a2 = (Ocelot)location.getWorld().spawnEntity(location, EntityType.OCELOT);
        this.a = a2;
        final Ocelot ocelot = a2;
        Version.a().a((Entity)ocelot, ConfigValue.minishop_speed);
        ocelot.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
        ocelot.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 1));
        Version.a().c((Entity)ocelot, true);
        final ArmorStand b = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
        this.b = b;
        final ArmorStand armorStand = b;
        armorStand.setVisible(false);
        armorStand.setGravity(false);
        armorStand.setCustomNameVisible(true);
        this.d = new BukkitRunnable() {
            public void run() {
                bB.this.tick();
                final bB a = bB.this;
                bB.a(a, a.U + 1);
            }
        }.runTaskTimer((Plugin)MBedwars.a, 1L, 1L);
    }
    
    private void tick() {
        if (this.a.isDead() || this.a.isDead()) {
            this.done();
            return;
        }
        this.a.teleport((Entity)this.a);
        this.b.teleport((Entity)this.a);
        if (this.player != null) {
            Version.a().a((Entity)this.a, (Entity)this.player);
        }
        if (this.U % 20 == 0) {
            --this.V;
            if (this.V >= 0) {
                this.b.setCustomName(de.marcely.bedwars.message.b.a(Language.MiniShop_Title).a("title", ConfigValue.dealer_title).a("time", new StringBuilder().append(this.V).toString()).f((CommandSender)this.player));
            }
            else {
                this.done();
            }
        }
        this.a.d(this.a.getLocation());
    }
    
    @EventHandler
    public void a(final PlayerInteractEntityEvent playerInteractEntityEvent) {
        if (playerInteractEntityEvent.getRightClicked() == this.b) {
            playerInteractEntityEvent.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void a(final EntityDamageEvent entityDamageEvent) {
        final Entity entity = entityDamageEvent.getEntity();
        if (entity == this.a) {
            entityDamageEvent.setCancelled(false);
            Version.a().a((Entity)this.a, (float)entityDamageEvent.getFinalDamage());
        }
        else if (entity == this.a) {
            entityDamageEvent.setCancelled(false);
            new BukkitRunnable() {
                public void run() {
                    ((bB)entity).a.setVelocity(entity.getVelocity());
                }
            }.runTaskLater((Plugin)MBedwars.a, 1L);
        }
    }
    
    private void c(final Location location) {
        for (int i = 0; i < 6; ++i) {
            VarParticle.PARTICLE_SMOKE.play(location.getWorld(), location.clone().add(s.RAND.nextInt(6) / 10.0, s.RAND.nextInt(8) / 10.0 * (s.RAND.nextInt(2) + 1), s.RAND.nextInt(6) / 10.0), s.RAND.nextInt(10));
        }
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 1.4, 0.4), 0);
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 0.6, 0.4), 0);
        VarParticle.PARTICLE_CLOUD.play(location.getWorld(), location.clone().add(0.4, 0.1, 0.4), 0);
    }
    
    static /* synthetic */ void a(final bB bb, final int u) {
        bb.U = u;
    }
    
    private static class a
    {
        float x1;
        float y1;
        float a;
        float x2;
        float y2;
        float b;
        
        private a() {
            this.x1 = 1.0f;
            this.y1 = 1.0f;
            this.a = 1.0f;
            this.x2 = 0.0f;
            this.y2 = 0.0f;
            this.b = 0.0f;
        }
        
        public void d(final Location location) {
            this.x1 -= (float)0.025;
            if (this.x1 <= -1.0f) {
                this.x1 = 1.0f;
            }
            this.y1 -= (float)0.035;
            if (this.y1 <= -1.0f) {
                this.y1 = 1.0f;
            }
            this.a -= (float)0.0125;
            if (this.a <= -1.0f) {
                this.a = 1.0f;
            }
            this.a(location.clone().add(Math.cos(-this.x1) * 2.0 - 1.5, Math.cos(this.y1) * 4.0 - 2.0, Math.cos(-this.a) * 2.0 - 1.5), Math.abs(this.x1 + this.y1 + this.a) / 3.0f);
            this.x2 += (float)0.025;
            if (this.x2 >= 1.0f) {
                this.x2 = -1.0f;
            }
            this.y2 += (float)0.035;
            if (this.y2 >= 1.0f) {
                this.y2 = -1.0f;
            }
            this.b += (float)0.0125;
            if (this.b >= 1.0f) {
                this.b = -1.0f;
            }
            this.a(location.clone().add(Math.cos(-this.x2) * 2.0 - 1.5, Math.cos(this.y2) * 4.0 - 2.0, Math.cos(-this.b) * 2.0 - 1.5), Math.abs(this.x2 + this.y2 + this.b) / 3.0f);
        }
        
        private void a(final Location location, final float n) {
            VarParticle.PARTICLE_COLOURED.play(location.getWorld(), location, Color.fromRGB((int)(n * 255.0f), (int)(n * 255.0f), (int)(n * 255.0f)));
        }
    }
}
