// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Material;
import java.util.Iterator;
import org.bukkit.block.Block;
import java.util.List;
import org.bukkit.event.block.BlockExplodeEvent;

public class aA
{
    private static /* synthetic */ int[] e;
    
    public static void a(final BlockExplodeEvent blockExplodeEvent) {
        av.a a = null;
        switch (e()[blockExplodeEvent.getBlock().getType().ordinal()]) {
            case 47: {
                a = av.a.a;
                break;
            }
            default: {
                a = av.a.b;
                break;
            }
        }
        final av.b b = new av.b(a, blockExplodeEvent.blockList(), blockExplodeEvent.getBlock().getLocation());
        av.a(b);
        if (b.a != null) {
            blockExplodeEvent.setCancelled((boolean)b.a);
        }
        final Iterator<Block> iterator = (Iterator<Block>)blockExplodeEvent.blockList().iterator();
        while (iterator.hasNext()) {
            if (!b.A.contains(iterator.next())) {
                iterator.remove();
            }
        }
    }
    
    static /* synthetic */ int[] e() {
        final int[] e = aA.e;
        if (e != null) {
            return e;
        }
        final int[] e2 = new int[Material.values().length];
        try {
            e2[Material.ACACIA_DOOR.ordinal()] = 197;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            e2[Material.ACACIA_DOOR_ITEM.ordinal()] = 372;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            e2[Material.ACACIA_FENCE.ordinal()] = 193;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            e2[Material.ACACIA_FENCE_GATE.ordinal()] = 188;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            e2[Material.ACACIA_STAIRS.ordinal()] = 164;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            e2[Material.ACTIVATOR_RAIL.ordinal()] = 158;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            e2[Material.AIR.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            e2[Material.ANVIL.ordinal()] = 146;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            e2[Material.APPLE.ordinal()] = 203;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            e2[Material.ARMOR_STAND.ordinal()] = 359;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            e2[Material.ARROW.ordinal()] = 205;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            e2[Material.BAKED_POTATO.ordinal()] = 336;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            e2[Material.BANNER.ordinal()] = 368;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            e2[Material.BARRIER.ordinal()] = 167;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        try {
            e2[Material.BEACON.ordinal()] = 139;
        }
        catch (NoSuchFieldError noSuchFieldError15) {}
        try {
            e2[Material.BED.ordinal()] = 298;
        }
        catch (NoSuchFieldError noSuchFieldError16) {}
        try {
            e2[Material.BEDROCK.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError17) {}
        try {
            e2[Material.BED_BLOCK.ordinal()] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError18) {}
        try {
            e2[Material.BIRCH_DOOR.ordinal()] = 195;
        }
        catch (NoSuchFieldError noSuchFieldError19) {}
        try {
            e2[Material.BIRCH_DOOR_ITEM.ordinal()] = 370;
        }
        catch (NoSuchFieldError noSuchFieldError20) {}
        try {
            e2[Material.BIRCH_FENCE.ordinal()] = 190;
        }
        catch (NoSuchFieldError noSuchFieldError21) {}
        try {
            e2[Material.BIRCH_FENCE_GATE.ordinal()] = 185;
        }
        catch (NoSuchFieldError noSuchFieldError22) {}
        try {
            e2[Material.BIRCH_WOOD_STAIRS.ordinal()] = 136;
        }
        catch (NoSuchFieldError noSuchFieldError23) {}
        try {
            e2[Material.BLAZE_POWDER.ordinal()] = 320;
        }
        catch (NoSuchFieldError noSuchFieldError24) {}
        try {
            e2[Material.BLAZE_ROD.ordinal()] = 312;
        }
        catch (NoSuchFieldError noSuchFieldError25) {}
        try {
            e2[Material.BOAT.ordinal()] = 276;
        }
        catch (NoSuchFieldError noSuchFieldError26) {}
        try {
            e2[Material.BONE.ordinal()] = 295;
        }
        catch (NoSuchFieldError noSuchFieldError27) {}
        try {
            e2[Material.BOOK.ordinal()] = 283;
        }
        catch (NoSuchFieldError noSuchFieldError28) {}
        try {
            e2[Material.BOOKSHELF.ordinal()] = 48;
        }
        catch (NoSuchFieldError noSuchFieldError29) {}
        try {
            e2[Material.BOOK_AND_QUILL.ordinal()] = 329;
        }
        catch (NoSuchFieldError noSuchFieldError30) {}
        try {
            e2[Material.BOW.ordinal()] = 204;
        }
        catch (NoSuchFieldError noSuchFieldError31) {}
        try {
            e2[Material.BOWL.ordinal()] = 224;
        }
        catch (NoSuchFieldError noSuchFieldError32) {}
        try {
            e2[Material.BREAD.ordinal()] = 240;
        }
        catch (NoSuchFieldError noSuchFieldError33) {}
        try {
            e2[Material.BREWING_STAND.ordinal()] = 118;
        }
        catch (NoSuchFieldError noSuchFieldError34) {}
        try {
            e2[Material.BREWING_STAND_ITEM.ordinal()] = 322;
        }
        catch (NoSuchFieldError noSuchFieldError35) {}
        try {
            e2[Material.BRICK.ordinal()] = 46;
        }
        catch (NoSuchFieldError noSuchFieldError36) {}
        try {
            e2[Material.BRICK_STAIRS.ordinal()] = 109;
        }
        catch (NoSuchFieldError noSuchFieldError37) {}
        try {
            e2[Material.BROWN_MUSHROOM.ordinal()] = 40;
        }
        catch (NoSuchFieldError noSuchFieldError38) {}
        try {
            e2[Material.BUCKET.ordinal()] = 268;
        }
        catch (NoSuchFieldError noSuchFieldError39) {}
        try {
            e2[Material.BURNING_FURNACE.ordinal()] = 63;
        }
        catch (NoSuchFieldError noSuchFieldError40) {}
        try {
            e2[Material.CACTUS.ordinal()] = 82;
        }
        catch (NoSuchFieldError noSuchFieldError41) {}
        try {
            e2[Material.CAKE.ordinal()] = 297;
        }
        catch (NoSuchFieldError noSuchFieldError42) {}
        try {
            e2[Material.CAKE_BLOCK.ordinal()] = 93;
        }
        catch (NoSuchFieldError noSuchFieldError43) {}
        try {
            e2[Material.CARPET.ordinal()] = 172;
        }
        catch (NoSuchFieldError noSuchFieldError44) {}
        try {
            e2[Material.CARROT.ordinal()] = 142;
        }
        catch (NoSuchFieldError noSuchFieldError45) {}
        try {
            e2[Material.CARROT_ITEM.ordinal()] = 334;
        }
        catch (NoSuchFieldError noSuchFieldError46) {}
        try {
            e2[Material.CARROT_STICK.ordinal()] = 341;
        }
        catch (NoSuchFieldError noSuchFieldError47) {}
        try {
            e2[Material.CAULDRON.ordinal()] = 119;
        }
        catch (NoSuchFieldError noSuchFieldError48) {}
        try {
            e2[Material.CAULDRON_ITEM.ordinal()] = 323;
        }
        catch (NoSuchFieldError noSuchFieldError49) {}
        try {
            e2[Material.CHAINMAIL_BOOTS.ordinal()] = 248;
        }
        catch (NoSuchFieldError noSuchFieldError50) {}
        try {
            e2[Material.CHAINMAIL_CHESTPLATE.ordinal()] = 246;
        }
        catch (NoSuchFieldError noSuchFieldError51) {}
        try {
            e2[Material.CHAINMAIL_HELMET.ordinal()] = 245;
        }
        catch (NoSuchFieldError noSuchFieldError52) {}
        try {
            e2[Material.CHAINMAIL_LEGGINGS.ordinal()] = 247;
        }
        catch (NoSuchFieldError noSuchFieldError53) {}
        try {
            e2[Material.CHEST.ordinal()] = 55;
        }
        catch (NoSuchFieldError noSuchFieldError54) {}
        try {
            e2[Material.CLAY.ordinal()] = 83;
        }
        catch (NoSuchFieldError noSuchFieldError55) {}
        try {
            e2[Material.CLAY_BALL.ordinal()] = 280;
        }
        catch (NoSuchFieldError noSuchFieldError56) {}
        try {
            e2[Material.CLAY_BRICK.ordinal()] = 279;
        }
        catch (NoSuchFieldError noSuchFieldError57) {}
        try {
            e2[Material.COAL.ordinal()] = 206;
        }
        catch (NoSuchFieldError noSuchFieldError58) {}
        try {
            e2[Material.COAL_BLOCK.ordinal()] = 174;
        }
        catch (NoSuchFieldError noSuchFieldError59) {}
        try {
            e2[Material.COAL_ORE.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError60) {}
        try {
            e2[Material.COBBLESTONE.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError61) {}
        try {
            e2[Material.COBBLESTONE_STAIRS.ordinal()] = 68;
        }
        catch (NoSuchFieldError noSuchFieldError62) {}
        try {
            e2[Material.COBBLE_WALL.ordinal()] = 140;
        }
        catch (NoSuchFieldError noSuchFieldError63) {}
        try {
            e2[Material.COCOA.ordinal()] = 128;
        }
        catch (NoSuchFieldError noSuchFieldError64) {}
        try {
            e2[Material.COMMAND.ordinal()] = 138;
        }
        catch (NoSuchFieldError noSuchFieldError65) {}
        try {
            e2[Material.COMMAND_MINECART.ordinal()] = 365;
        }
        catch (NoSuchFieldError noSuchFieldError66) {}
        try {
            e2[Material.COMPASS.ordinal()] = 288;
        }
        catch (NoSuchFieldError noSuchFieldError67) {}
        try {
            e2[Material.COOKED_BEEF.ordinal()] = 307;
        }
        catch (NoSuchFieldError noSuchFieldError68) {}
        try {
            e2[Material.COOKED_CHICKEN.ordinal()] = 309;
        }
        catch (NoSuchFieldError noSuchFieldError69) {}
        try {
            e2[Material.COOKED_FISH.ordinal()] = 293;
        }
        catch (NoSuchFieldError noSuchFieldError70) {}
        try {
            e2[Material.COOKED_MUTTON.ordinal()] = 367;
        }
        catch (NoSuchFieldError noSuchFieldError71) {}
        try {
            e2[Material.COOKED_RABBIT.ordinal()] = 355;
        }
        catch (NoSuchFieldError noSuchFieldError72) {}
        try {
            e2[Material.COOKIE.ordinal()] = 300;
        }
        catch (NoSuchFieldError noSuchFieldError73) {}
        try {
            e2[Material.CROPS.ordinal()] = 60;
        }
        catch (NoSuchFieldError noSuchFieldError74) {}
        try {
            e2[Material.DARK_OAK_DOOR.ordinal()] = 198;
        }
        catch (NoSuchFieldError noSuchFieldError75) {}
        try {
            e2[Material.DARK_OAK_DOOR_ITEM.ordinal()] = 373;
        }
        catch (NoSuchFieldError noSuchFieldError76) {}
        try {
            e2[Material.DARK_OAK_FENCE.ordinal()] = 192;
        }
        catch (NoSuchFieldError noSuchFieldError77) {}
        try {
            e2[Material.DARK_OAK_FENCE_GATE.ordinal()] = 187;
        }
        catch (NoSuchFieldError noSuchFieldError78) {}
        try {
            e2[Material.DARK_OAK_STAIRS.ordinal()] = 165;
        }
        catch (NoSuchFieldError noSuchFieldError79) {}
        try {
            e2[Material.DAYLIGHT_DETECTOR.ordinal()] = 152;
        }
        catch (NoSuchFieldError noSuchFieldError80) {}
        try {
            e2[Material.DAYLIGHT_DETECTOR_INVERTED.ordinal()] = 179;
        }
        catch (NoSuchFieldError noSuchFieldError81) {}
        try {
            e2[Material.DEAD_BUSH.ordinal()] = 33;
        }
        catch (NoSuchFieldError noSuchFieldError82) {}
        try {
            e2[Material.DETECTOR_RAIL.ordinal()] = 29;
        }
        catch (NoSuchFieldError noSuchFieldError83) {}
        try {
            e2[Material.DIAMOND.ordinal()] = 207;
        }
        catch (NoSuchFieldError noSuchFieldError84) {}
        try {
            e2[Material.DIAMOND_AXE.ordinal()] = 222;
        }
        catch (NoSuchFieldError noSuchFieldError85) {}
        try {
            e2[Material.DIAMOND_BARDING.ordinal()] = 362;
        }
        catch (NoSuchFieldError noSuchFieldError86) {}
        try {
            e2[Material.DIAMOND_BLOCK.ordinal()] = 58;
        }
        catch (NoSuchFieldError noSuchFieldError87) {}
        try {
            e2[Material.DIAMOND_BOOTS.ordinal()] = 256;
        }
        catch (NoSuchFieldError noSuchFieldError88) {}
        try {
            e2[Material.DIAMOND_CHESTPLATE.ordinal()] = 254;
        }
        catch (NoSuchFieldError noSuchFieldError89) {}
        try {
            e2[Material.DIAMOND_HELMET.ordinal()] = 253;
        }
        catch (NoSuchFieldError noSuchFieldError90) {}
        try {
            e2[Material.DIAMOND_HOE.ordinal()] = 236;
        }
        catch (NoSuchFieldError noSuchFieldError91) {}
        try {
            e2[Material.DIAMOND_LEGGINGS.ordinal()] = 255;
        }
        catch (NoSuchFieldError noSuchFieldError92) {}
        try {
            e2[Material.DIAMOND_ORE.ordinal()] = 57;
        }
        catch (NoSuchFieldError noSuchFieldError93) {}
        try {
            e2[Material.DIAMOND_PICKAXE.ordinal()] = 221;
        }
        catch (NoSuchFieldError noSuchFieldError94) {}
        try {
            e2[Material.DIAMOND_SPADE.ordinal()] = 220;
        }
        catch (NoSuchFieldError noSuchFieldError95) {}
        try {
            e2[Material.DIAMOND_SWORD.ordinal()] = 219;
        }
        catch (NoSuchFieldError noSuchFieldError96) {}
        try {
            e2[Material.DIODE.ordinal()] = 299;
        }
        catch (NoSuchFieldError noSuchFieldError97) {}
        try {
            e2[Material.DIODE_BLOCK_OFF.ordinal()] = 94;
        }
        catch (NoSuchFieldError noSuchFieldError98) {}
        try {
            e2[Material.DIODE_BLOCK_ON.ordinal()] = 95;
        }
        catch (NoSuchFieldError noSuchFieldError99) {}
        try {
            e2[Material.DIRT.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError100) {}
        try {
            e2[Material.DISPENSER.ordinal()] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError101) {}
        try {
            e2[Material.DOUBLE_PLANT.ordinal()] = 176;
        }
        catch (NoSuchFieldError noSuchFieldError102) {}
        try {
            e2[Material.DOUBLE_STEP.ordinal()] = 44;
        }
        catch (NoSuchFieldError noSuchFieldError103) {}
        try {
            e2[Material.DOUBLE_STONE_SLAB2.ordinal()] = 182;
        }
        catch (NoSuchFieldError noSuchFieldError104) {}
        try {
            e2[Material.DRAGON_EGG.ordinal()] = 123;
        }
        catch (NoSuchFieldError noSuchFieldError105) {}
        try {
            e2[Material.DROPPER.ordinal()] = 159;
        }
        catch (NoSuchFieldError noSuchFieldError106) {}
        try {
            e2[Material.EGG.ordinal()] = 287;
        }
        catch (NoSuchFieldError noSuchFieldError107) {}
        try {
            e2[Material.EMERALD.ordinal()] = 331;
        }
        catch (NoSuchFieldError noSuchFieldError108) {}
        try {
            e2[Material.EMERALD_BLOCK.ordinal()] = 134;
        }
        catch (NoSuchFieldError noSuchFieldError109) {}
        try {
            e2[Material.EMERALD_ORE.ordinal()] = 130;
        }
        catch (NoSuchFieldError noSuchFieldError110) {}
        try {
            e2[Material.EMPTY_MAP.ordinal()] = 338;
        }
        catch (NoSuchFieldError noSuchFieldError111) {}
        try {
            e2[Material.ENCHANTED_BOOK.ordinal()] = 346;
        }
        catch (NoSuchFieldError noSuchFieldError112) {}
        try {
            e2[Material.ENCHANTMENT_TABLE.ordinal()] = 117;
        }
        catch (NoSuchFieldError noSuchFieldError113) {}
        try {
            e2[Material.ENDER_CHEST.ordinal()] = 131;
        }
        catch (NoSuchFieldError noSuchFieldError114) {}
        try {
            e2[Material.ENDER_PEARL.ordinal()] = 311;
        }
        catch (NoSuchFieldError noSuchFieldError115) {}
        try {
            e2[Material.ENDER_PORTAL.ordinal()] = 120;
        }
        catch (NoSuchFieldError noSuchFieldError116) {}
        try {
            e2[Material.ENDER_PORTAL_FRAME.ordinal()] = 121;
        }
        catch (NoSuchFieldError noSuchFieldError117) {}
        try {
            e2[Material.ENDER_STONE.ordinal()] = 122;
        }
        catch (NoSuchFieldError noSuchFieldError118) {}
        try {
            e2[Material.EXPLOSIVE_MINECART.ordinal()] = 350;
        }
        catch (NoSuchFieldError noSuchFieldError119) {}
        try {
            e2[Material.EXP_BOTTLE.ordinal()] = 327;
        }
        catch (NoSuchFieldError noSuchFieldError120) {}
        try {
            e2[Material.EYE_OF_ENDER.ordinal()] = 324;
        }
        catch (NoSuchFieldError noSuchFieldError121) {}
        try {
            e2[Material.FEATHER.ordinal()] = 231;
        }
        catch (NoSuchFieldError noSuchFieldError122) {}
        try {
            e2[Material.FENCE.ordinal()] = 86;
        }
        catch (NoSuchFieldError noSuchFieldError123) {}
        try {
            e2[Material.FENCE_GATE.ordinal()] = 108;
        }
        catch (NoSuchFieldError noSuchFieldError124) {}
        try {
            e2[Material.FERMENTED_SPIDER_EYE.ordinal()] = 319;
        }
        catch (NoSuchFieldError noSuchFieldError125) {}
        try {
            e2[Material.FIRE.ordinal()] = 52;
        }
        catch (NoSuchFieldError noSuchFieldError126) {}
        try {
            e2[Material.FIREBALL.ordinal()] = 328;
        }
        catch (NoSuchFieldError noSuchFieldError127) {}
        try {
            e2[Material.FIREWORK.ordinal()] = 344;
        }
        catch (NoSuchFieldError noSuchFieldError128) {}
        try {
            e2[Material.FIREWORK_CHARGE.ordinal()] = 345;
        }
        catch (NoSuchFieldError noSuchFieldError129) {}
        try {
            e2[Material.FISHING_ROD.ordinal()] = 289;
        }
        catch (NoSuchFieldError noSuchFieldError130) {}
        try {
            e2[Material.FLINT.ordinal()] = 261;
        }
        catch (NoSuchFieldError noSuchFieldError131) {}
        try {
            e2[Material.FLINT_AND_STEEL.ordinal()] = 202;
        }
        catch (NoSuchFieldError noSuchFieldError132) {}
        try {
            e2[Material.FLOWER_POT.ordinal()] = 141;
        }
        catch (NoSuchFieldError noSuchFieldError133) {}
        try {
            e2[Material.FLOWER_POT_ITEM.ordinal()] = 333;
        }
        catch (NoSuchFieldError noSuchFieldError134) {}
        try {
            e2[Material.FURNACE.ordinal()] = 62;
        }
        catch (NoSuchFieldError noSuchFieldError135) {}
        try {
            e2[Material.GHAST_TEAR.ordinal()] = 313;
        }
        catch (NoSuchFieldError noSuchFieldError136) {}
        try {
            e2[Material.GLASS.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError137) {}
        try {
            e2[Material.GLASS_BOTTLE.ordinal()] = 317;
        }
        catch (NoSuchFieldError noSuchFieldError138) {}
        try {
            e2[Material.GLOWING_REDSTONE_ORE.ordinal()] = 75;
        }
        catch (NoSuchFieldError noSuchFieldError139) {}
        try {
            e2[Material.GLOWSTONE.ordinal()] = 90;
        }
        catch (NoSuchFieldError noSuchFieldError140) {}
        try {
            e2[Material.GLOWSTONE_DUST.ordinal()] = 291;
        }
        catch (NoSuchFieldError noSuchFieldError141) {}
        try {
            e2[Material.GOLDEN_APPLE.ordinal()] = 265;
        }
        catch (NoSuchFieldError noSuchFieldError142) {}
        try {
            e2[Material.GOLDEN_CARROT.ordinal()] = 339;
        }
        catch (NoSuchFieldError noSuchFieldError143) {}
        try {
            e2[Material.GOLD_AXE.ordinal()] = 229;
        }
        catch (NoSuchFieldError noSuchFieldError144) {}
        try {
            e2[Material.GOLD_BARDING.ordinal()] = 361;
        }
        catch (NoSuchFieldError noSuchFieldError145) {}
        try {
            e2[Material.GOLD_BLOCK.ordinal()] = 42;
        }
        catch (NoSuchFieldError noSuchFieldError146) {}
        try {
            e2[Material.GOLD_BOOTS.ordinal()] = 260;
        }
        catch (NoSuchFieldError noSuchFieldError147) {}
        try {
            e2[Material.GOLD_CHESTPLATE.ordinal()] = 258;
        }
        catch (NoSuchFieldError noSuchFieldError148) {}
        try {
            e2[Material.GOLD_HELMET.ordinal()] = 257;
        }
        catch (NoSuchFieldError noSuchFieldError149) {}
        try {
            e2[Material.GOLD_HOE.ordinal()] = 237;
        }
        catch (NoSuchFieldError noSuchFieldError150) {}
        try {
            e2[Material.GOLD_INGOT.ordinal()] = 209;
        }
        catch (NoSuchFieldError noSuchFieldError151) {}
        try {
            e2[Material.GOLD_LEGGINGS.ordinal()] = 259;
        }
        catch (NoSuchFieldError noSuchFieldError152) {}
        try {
            e2[Material.GOLD_NUGGET.ordinal()] = 314;
        }
        catch (NoSuchFieldError noSuchFieldError153) {}
        try {
            e2[Material.GOLD_ORE.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError154) {}
        try {
            e2[Material.GOLD_PICKAXE.ordinal()] = 228;
        }
        catch (NoSuchFieldError noSuchFieldError155) {}
        try {
            e2[Material.GOLD_PLATE.ordinal()] = 148;
        }
        catch (NoSuchFieldError noSuchFieldError156) {}
        try {
            e2[Material.GOLD_RECORD.ordinal()] = 374;
        }
        catch (NoSuchFieldError noSuchFieldError157) {}
        try {
            e2[Material.GOLD_SPADE.ordinal()] = 227;
        }
        catch (NoSuchFieldError noSuchFieldError158) {}
        try {
            e2[Material.GOLD_SWORD.ordinal()] = 226;
        }
        catch (NoSuchFieldError noSuchFieldError159) {}
        try {
            e2[Material.GRASS.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError160) {}
        try {
            e2[Material.GRAVEL.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError161) {}
        try {
            e2[Material.GREEN_RECORD.ordinal()] = 375;
        }
        catch (NoSuchFieldError noSuchFieldError162) {}
        try {
            e2[Material.GRILLED_PORK.ordinal()] = 263;
        }
        catch (NoSuchFieldError noSuchFieldError163) {}
        try {
            e2[Material.HARD_CLAY.ordinal()] = 173;
        }
        catch (NoSuchFieldError noSuchFieldError164) {}
        try {
            e2[Material.HAY_BLOCK.ordinal()] = 171;
        }
        catch (NoSuchFieldError noSuchFieldError165) {}
        try {
            e2[Material.HOPPER.ordinal()] = 155;
        }
        catch (NoSuchFieldError noSuchFieldError166) {}
        try {
            e2[Material.HOPPER_MINECART.ordinal()] = 351;
        }
        catch (NoSuchFieldError noSuchFieldError167) {}
        try {
            e2[Material.HUGE_MUSHROOM_1.ordinal()] = 100;
        }
        catch (NoSuchFieldError noSuchFieldError168) {}
        try {
            e2[Material.HUGE_MUSHROOM_2.ordinal()] = 101;
        }
        catch (NoSuchFieldError noSuchFieldError169) {}
        try {
            e2[Material.ICE.ordinal()] = 80;
        }
        catch (NoSuchFieldError noSuchFieldError170) {}
        try {
            e2[Material.INK_SACK.ordinal()] = 294;
        }
        catch (NoSuchFieldError noSuchFieldError171) {}
        try {
            e2[Material.IRON_AXE.ordinal()] = 201;
        }
        catch (NoSuchFieldError noSuchFieldError172) {}
        try {
            e2[Material.IRON_BARDING.ordinal()] = 360;
        }
        catch (NoSuchFieldError noSuchFieldError173) {}
        try {
            e2[Material.IRON_BLOCK.ordinal()] = 43;
        }
        catch (NoSuchFieldError noSuchFieldError174) {}
        try {
            e2[Material.IRON_BOOTS.ordinal()] = 252;
        }
        catch (NoSuchFieldError noSuchFieldError175) {}
        try {
            e2[Material.IRON_CHESTPLATE.ordinal()] = 250;
        }
        catch (NoSuchFieldError noSuchFieldError176) {}
        try {
            e2[Material.IRON_DOOR.ordinal()] = 273;
        }
        catch (NoSuchFieldError noSuchFieldError177) {}
        try {
            e2[Material.IRON_DOOR_BLOCK.ordinal()] = 72;
        }
        catch (NoSuchFieldError noSuchFieldError178) {}
        try {
            e2[Material.IRON_FENCE.ordinal()] = 102;
        }
        catch (NoSuchFieldError noSuchFieldError179) {}
        try {
            e2[Material.IRON_HELMET.ordinal()] = 249;
        }
        catch (NoSuchFieldError noSuchFieldError180) {}
        try {
            e2[Material.IRON_HOE.ordinal()] = 235;
        }
        catch (NoSuchFieldError noSuchFieldError181) {}
        try {
            e2[Material.IRON_INGOT.ordinal()] = 208;
        }
        catch (NoSuchFieldError noSuchFieldError182) {}
        try {
            e2[Material.IRON_LEGGINGS.ordinal()] = 251;
        }
        catch (NoSuchFieldError noSuchFieldError183) {}
        try {
            e2[Material.IRON_ORE.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError184) {}
        try {
            e2[Material.IRON_PICKAXE.ordinal()] = 200;
        }
        catch (NoSuchFieldError noSuchFieldError185) {}
        try {
            e2[Material.IRON_PLATE.ordinal()] = 149;
        }
        catch (NoSuchFieldError noSuchFieldError186) {}
        try {
            e2[Material.IRON_SPADE.ordinal()] = 199;
        }
        catch (NoSuchFieldError noSuchFieldError187) {}
        try {
            e2[Material.IRON_SWORD.ordinal()] = 210;
        }
        catch (NoSuchFieldError noSuchFieldError188) {}
        try {
            e2[Material.IRON_TRAPDOOR.ordinal()] = 168;
        }
        catch (NoSuchFieldError noSuchFieldError189) {}
        try {
            e2[Material.ITEM_FRAME.ordinal()] = 332;
        }
        catch (NoSuchFieldError noSuchFieldError190) {}
        try {
            e2[Material.JACK_O_LANTERN.ordinal()] = 92;
        }
        catch (NoSuchFieldError noSuchFieldError191) {}
        try {
            e2[Material.JUKEBOX.ordinal()] = 85;
        }
        catch (NoSuchFieldError noSuchFieldError192) {}
        try {
            e2[Material.JUNGLE_DOOR.ordinal()] = 196;
        }
        catch (NoSuchFieldError noSuchFieldError193) {}
        try {
            e2[Material.JUNGLE_DOOR_ITEM.ordinal()] = 371;
        }
        catch (NoSuchFieldError noSuchFieldError194) {}
        try {
            e2[Material.JUNGLE_FENCE.ordinal()] = 191;
        }
        catch (NoSuchFieldError noSuchFieldError195) {}
        try {
            e2[Material.JUNGLE_FENCE_GATE.ordinal()] = 186;
        }
        catch (NoSuchFieldError noSuchFieldError196) {}
        try {
            e2[Material.JUNGLE_WOOD_STAIRS.ordinal()] = 137;
        }
        catch (NoSuchFieldError noSuchFieldError197) {}
        try {
            e2[Material.LADDER.ordinal()] = 66;
        }
        catch (NoSuchFieldError noSuchFieldError198) {}
        try {
            e2[Material.LAPIS_BLOCK.ordinal()] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError199) {}
        try {
            e2[Material.LAPIS_ORE.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError200) {}
        try {
            e2[Material.LAVA.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError201) {}
        try {
            e2[Material.LAVA_BUCKET.ordinal()] = 270;
        }
        catch (NoSuchFieldError noSuchFieldError202) {}
        try {
            e2[Material.LEASH.ordinal()] = 363;
        }
        catch (NoSuchFieldError noSuchFieldError203) {}
        try {
            e2[Material.LEATHER.ordinal()] = 277;
        }
        catch (NoSuchFieldError noSuchFieldError204) {}
        try {
            e2[Material.LEATHER_BOOTS.ordinal()] = 244;
        }
        catch (NoSuchFieldError noSuchFieldError205) {}
        try {
            e2[Material.LEATHER_CHESTPLATE.ordinal()] = 242;
        }
        catch (NoSuchFieldError noSuchFieldError206) {}
        try {
            e2[Material.LEATHER_HELMET.ordinal()] = 241;
        }
        catch (NoSuchFieldError noSuchFieldError207) {}
        try {
            e2[Material.LEATHER_LEGGINGS.ordinal()] = 243;
        }
        catch (NoSuchFieldError noSuchFieldError208) {}
        try {
            e2[Material.LEAVES.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError209) {}
        try {
            e2[Material.LEAVES_2.ordinal()] = 162;
        }
        catch (NoSuchFieldError noSuchFieldError210) {}
        try {
            e2[Material.LEVER.ordinal()] = 70;
        }
        catch (NoSuchFieldError noSuchFieldError211) {}
        try {
            e2[Material.LOG.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError212) {}
        try {
            e2[Material.LOG_2.ordinal()] = 163;
        }
        catch (NoSuchFieldError noSuchFieldError213) {}
        try {
            e2[Material.LONG_GRASS.ordinal()] = 32;
        }
        catch (NoSuchFieldError noSuchFieldError214) {}
        try {
            e2[Material.MAGMA_CREAM.ordinal()] = 321;
        }
        catch (NoSuchFieldError noSuchFieldError215) {}
        try {
            e2[Material.MAP.ordinal()] = 301;
        }
        catch (NoSuchFieldError noSuchFieldError216) {}
        try {
            e2[Material.MELON.ordinal()] = 303;
        }
        catch (NoSuchFieldError noSuchFieldError217) {}
        try {
            e2[Material.MELON_BLOCK.ordinal()] = 104;
        }
        catch (NoSuchFieldError noSuchFieldError218) {}
        try {
            e2[Material.MELON_SEEDS.ordinal()] = 305;
        }
        catch (NoSuchFieldError noSuchFieldError219) {}
        try {
            e2[Material.MELON_STEM.ordinal()] = 106;
        }
        catch (NoSuchFieldError noSuchFieldError220) {}
        try {
            e2[Material.MILK_BUCKET.ordinal()] = 278;
        }
        catch (NoSuchFieldError noSuchFieldError221) {}
        try {
            e2[Material.MINECART.ordinal()] = 271;
        }
        catch (NoSuchFieldError noSuchFieldError222) {}
        try {
            e2[Material.MOB_SPAWNER.ordinal()] = 53;
        }
        catch (NoSuchFieldError noSuchFieldError223) {}
        try {
            e2[Material.MONSTER_EGG.ordinal()] = 326;
        }
        catch (NoSuchFieldError noSuchFieldError224) {}
        try {
            e2[Material.MONSTER_EGGS.ordinal()] = 98;
        }
        catch (NoSuchFieldError noSuchFieldError225) {}
        try {
            e2[Material.MOSSY_COBBLESTONE.ordinal()] = 49;
        }
        catch (NoSuchFieldError noSuchFieldError226) {}
        try {
            e2[Material.MUSHROOM_SOUP.ordinal()] = 225;
        }
        catch (NoSuchFieldError noSuchFieldError227) {}
        try {
            e2[Material.MUTTON.ordinal()] = 366;
        }
        catch (NoSuchFieldError noSuchFieldError228) {}
        try {
            e2[Material.MYCEL.ordinal()] = 111;
        }
        catch (NoSuchFieldError noSuchFieldError229) {}
        try {
            e2[Material.NAME_TAG.ordinal()] = 364;
        }
        catch (NoSuchFieldError noSuchFieldError230) {}
        try {
            e2[Material.NETHERRACK.ordinal()] = 88;
        }
        catch (NoSuchFieldError noSuchFieldError231) {}
        try {
            e2[Material.NETHER_BRICK.ordinal()] = 113;
        }
        catch (NoSuchFieldError noSuchFieldError232) {}
        try {
            e2[Material.NETHER_BRICK_ITEM.ordinal()] = 348;
        }
        catch (NoSuchFieldError noSuchFieldError233) {}
        try {
            e2[Material.NETHER_BRICK_STAIRS.ordinal()] = 115;
        }
        catch (NoSuchFieldError noSuchFieldError234) {}
        try {
            e2[Material.NETHER_FENCE.ordinal()] = 114;
        }
        catch (NoSuchFieldError noSuchFieldError235) {}
        try {
            e2[Material.NETHER_STALK.ordinal()] = 315;
        }
        catch (NoSuchFieldError noSuchFieldError236) {}
        try {
            e2[Material.NETHER_STAR.ordinal()] = 342;
        }
        catch (NoSuchFieldError noSuchFieldError237) {}
        try {
            e2[Material.NETHER_WARTS.ordinal()] = 116;
        }
        catch (NoSuchFieldError noSuchFieldError238) {}
        try {
            e2[Material.NOTE_BLOCK.ordinal()] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError239) {}
        try {
            e2[Material.OBSIDIAN.ordinal()] = 50;
        }
        catch (NoSuchFieldError noSuchFieldError240) {}
        try {
            e2[Material.PACKED_ICE.ordinal()] = 175;
        }
        catch (NoSuchFieldError noSuchFieldError241) {}
        try {
            e2[Material.PAINTING.ordinal()] = 264;
        }
        catch (NoSuchFieldError noSuchFieldError242) {}
        try {
            e2[Material.PAPER.ordinal()] = 282;
        }
        catch (NoSuchFieldError noSuchFieldError243) {}
        try {
            e2[Material.PISTON_BASE.ordinal()] = 34;
        }
        catch (NoSuchFieldError noSuchFieldError244) {}
        try {
            e2[Material.PISTON_EXTENSION.ordinal()] = 35;
        }
        catch (NoSuchFieldError noSuchFieldError245) {}
        try {
            e2[Material.PISTON_MOVING_PIECE.ordinal()] = 37;
        }
        catch (NoSuchFieldError noSuchFieldError246) {}
        try {
            e2[Material.PISTON_STICKY_BASE.ordinal()] = 30;
        }
        catch (NoSuchFieldError noSuchFieldError247) {}
        try {
            e2[Material.POISONOUS_POTATO.ordinal()] = 337;
        }
        catch (NoSuchFieldError noSuchFieldError248) {}
        try {
            e2[Material.PORK.ordinal()] = 262;
        }
        catch (NoSuchFieldError noSuchFieldError249) {}
        try {
            e2[Material.PORTAL.ordinal()] = 91;
        }
        catch (NoSuchFieldError noSuchFieldError250) {}
        try {
            e2[Material.POTATO.ordinal()] = 143;
        }
        catch (NoSuchFieldError noSuchFieldError251) {}
        try {
            e2[Material.POTATO_ITEM.ordinal()] = 335;
        }
        catch (NoSuchFieldError noSuchFieldError252) {}
        try {
            e2[Material.POTION.ordinal()] = 316;
        }
        catch (NoSuchFieldError noSuchFieldError253) {}
        try {
            e2[Material.POWERED_MINECART.ordinal()] = 286;
        }
        catch (NoSuchFieldError noSuchFieldError254) {}
        try {
            e2[Material.POWERED_RAIL.ordinal()] = 28;
        }
        catch (NoSuchFieldError noSuchFieldError255) {}
        try {
            e2[Material.PRISMARINE.ordinal()] = 169;
        }
        catch (NoSuchFieldError noSuchFieldError256) {}
        try {
            e2[Material.PRISMARINE_CRYSTALS.ordinal()] = 353;
        }
        catch (NoSuchFieldError noSuchFieldError257) {}
        try {
            e2[Material.PRISMARINE_SHARD.ordinal()] = 352;
        }
        catch (NoSuchFieldError noSuchFieldError258) {}
        try {
            e2[Material.PUMPKIN.ordinal()] = 87;
        }
        catch (NoSuchFieldError noSuchFieldError259) {}
        try {
            e2[Material.PUMPKIN_PIE.ordinal()] = 343;
        }
        catch (NoSuchFieldError noSuchFieldError260) {}
        try {
            e2[Material.PUMPKIN_SEEDS.ordinal()] = 304;
        }
        catch (NoSuchFieldError noSuchFieldError261) {}
        try {
            e2[Material.PUMPKIN_STEM.ordinal()] = 105;
        }
        catch (NoSuchFieldError noSuchFieldError262) {}
        try {
            e2[Material.QUARTZ.ordinal()] = 349;
        }
        catch (NoSuchFieldError noSuchFieldError263) {}
        try {
            e2[Material.QUARTZ_BLOCK.ordinal()] = 156;
        }
        catch (NoSuchFieldError noSuchFieldError264) {}
        try {
            e2[Material.QUARTZ_ORE.ordinal()] = 154;
        }
        catch (NoSuchFieldError noSuchFieldError265) {}
        try {
            e2[Material.QUARTZ_STAIRS.ordinal()] = 157;
        }
        catch (NoSuchFieldError noSuchFieldError266) {}
        try {
            e2[Material.RABBIT.ordinal()] = 354;
        }
        catch (NoSuchFieldError noSuchFieldError267) {}
        try {
            e2[Material.RABBIT_FOOT.ordinal()] = 357;
        }
        catch (NoSuchFieldError noSuchFieldError268) {}
        try {
            e2[Material.RABBIT_HIDE.ordinal()] = 358;
        }
        catch (NoSuchFieldError noSuchFieldError269) {}
        try {
            e2[Material.RABBIT_STEW.ordinal()] = 356;
        }
        catch (NoSuchFieldError noSuchFieldError270) {}
        try {
            e2[Material.RAILS.ordinal()] = 67;
        }
        catch (NoSuchFieldError noSuchFieldError271) {}
        try {
            e2[Material.RAW_BEEF.ordinal()] = 306;
        }
        catch (NoSuchFieldError noSuchFieldError272) {}
        try {
            e2[Material.RAW_CHICKEN.ordinal()] = 308;
        }
        catch (NoSuchFieldError noSuchFieldError273) {}
        try {
            e2[Material.RAW_FISH.ordinal()] = 292;
        }
        catch (NoSuchFieldError noSuchFieldError274) {}
        try {
            e2[Material.RECORD_10.ordinal()] = 383;
        }
        catch (NoSuchFieldError noSuchFieldError275) {}
        try {
            e2[Material.RECORD_11.ordinal()] = 384;
        }
        catch (NoSuchFieldError noSuchFieldError276) {}
        try {
            e2[Material.RECORD_12.ordinal()] = 385;
        }
        catch (NoSuchFieldError noSuchFieldError277) {}
        try {
            e2[Material.RECORD_3.ordinal()] = 376;
        }
        catch (NoSuchFieldError noSuchFieldError278) {}
        try {
            e2[Material.RECORD_4.ordinal()] = 377;
        }
        catch (NoSuchFieldError noSuchFieldError279) {}
        try {
            e2[Material.RECORD_5.ordinal()] = 378;
        }
        catch (NoSuchFieldError noSuchFieldError280) {}
        try {
            e2[Material.RECORD_6.ordinal()] = 379;
        }
        catch (NoSuchFieldError noSuchFieldError281) {}
        try {
            e2[Material.RECORD_7.ordinal()] = 380;
        }
        catch (NoSuchFieldError noSuchFieldError282) {}
        try {
            e2[Material.RECORD_8.ordinal()] = 381;
        }
        catch (NoSuchFieldError noSuchFieldError283) {}
        try {
            e2[Material.RECORD_9.ordinal()] = 382;
        }
        catch (NoSuchFieldError noSuchFieldError284) {}
        try {
            e2[Material.REDSTONE.ordinal()] = 274;
        }
        catch (NoSuchFieldError noSuchFieldError285) {}
        try {
            e2[Material.REDSTONE_BLOCK.ordinal()] = 153;
        }
        catch (NoSuchFieldError noSuchFieldError286) {}
        try {
            e2[Material.REDSTONE_COMPARATOR.ordinal()] = 347;
        }
        catch (NoSuchFieldError noSuchFieldError287) {}
        try {
            e2[Material.REDSTONE_COMPARATOR_OFF.ordinal()] = 150;
        }
        catch (NoSuchFieldError noSuchFieldError288) {}
        try {
            e2[Material.REDSTONE_COMPARATOR_ON.ordinal()] = 151;
        }
        catch (NoSuchFieldError noSuchFieldError289) {}
        try {
            e2[Material.REDSTONE_LAMP_OFF.ordinal()] = 124;
        }
        catch (NoSuchFieldError noSuchFieldError290) {}
        try {
            e2[Material.REDSTONE_LAMP_ON.ordinal()] = 125;
        }
        catch (NoSuchFieldError noSuchFieldError291) {}
        try {
            e2[Material.REDSTONE_ORE.ordinal()] = 74;
        }
        catch (NoSuchFieldError noSuchFieldError292) {}
        try {
            e2[Material.REDSTONE_TORCH_OFF.ordinal()] = 76;
        }
        catch (NoSuchFieldError noSuchFieldError293) {}
        try {
            e2[Material.REDSTONE_TORCH_ON.ordinal()] = 77;
        }
        catch (NoSuchFieldError noSuchFieldError294) {}
        try {
            e2[Material.REDSTONE_WIRE.ordinal()] = 56;
        }
        catch (NoSuchFieldError noSuchFieldError295) {}
        try {
            e2[Material.RED_MUSHROOM.ordinal()] = 41;
        }
        catch (NoSuchFieldError noSuchFieldError296) {}
        try {
            e2[Material.RED_ROSE.ordinal()] = 39;
        }
        catch (NoSuchFieldError noSuchFieldError297) {}
        try {
            e2[Material.RED_SANDSTONE.ordinal()] = 180;
        }
        catch (NoSuchFieldError noSuchFieldError298) {}
        try {
            e2[Material.RED_SANDSTONE_STAIRS.ordinal()] = 181;
        }
        catch (NoSuchFieldError noSuchFieldError299) {}
        try {
            e2[Material.ROTTEN_FLESH.ordinal()] = 310;
        }
        catch (NoSuchFieldError noSuchFieldError300) {}
        try {
            e2[Material.SADDLE.ordinal()] = 272;
        }
        catch (NoSuchFieldError noSuchFieldError301) {}
        try {
            e2[Material.SAND.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError302) {}
        try {
            e2[Material.SANDSTONE.ordinal()] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError303) {}
        try {
            e2[Material.SANDSTONE_STAIRS.ordinal()] = 129;
        }
        catch (NoSuchFieldError noSuchFieldError304) {}
        try {
            e2[Material.SAPLING.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError305) {}
        try {
            e2[Material.SEA_LANTERN.ordinal()] = 170;
        }
        catch (NoSuchFieldError noSuchFieldError306) {}
        try {
            e2[Material.SEEDS.ordinal()] = 238;
        }
        catch (NoSuchFieldError noSuchFieldError307) {}
        try {
            e2[Material.SHEARS.ordinal()] = 302;
        }
        catch (NoSuchFieldError noSuchFieldError308) {}
        try {
            e2[Material.SIGN.ordinal()] = 266;
        }
        catch (NoSuchFieldError noSuchFieldError309) {}
        try {
            e2[Material.SIGN_POST.ordinal()] = 64;
        }
        catch (NoSuchFieldError noSuchFieldError310) {}
        try {
            e2[Material.SKULL.ordinal()] = 145;
        }
        catch (NoSuchFieldError noSuchFieldError311) {}
        try {
            e2[Material.SKULL_ITEM.ordinal()] = 340;
        }
        catch (NoSuchFieldError noSuchFieldError312) {}
        try {
            e2[Material.SLIME_BALL.ordinal()] = 284;
        }
        catch (NoSuchFieldError noSuchFieldError313) {}
        try {
            e2[Material.SLIME_BLOCK.ordinal()] = 166;
        }
        catch (NoSuchFieldError noSuchFieldError314) {}
        try {
            e2[Material.SMOOTH_BRICK.ordinal()] = 99;
        }
        catch (NoSuchFieldError noSuchFieldError315) {}
        try {
            e2[Material.SMOOTH_STAIRS.ordinal()] = 110;
        }
        catch (NoSuchFieldError noSuchFieldError316) {}
        try {
            e2[Material.SNOW.ordinal()] = 79;
        }
        catch (NoSuchFieldError noSuchFieldError317) {}
        try {
            e2[Material.SNOW_BALL.ordinal()] = 275;
        }
        catch (NoSuchFieldError noSuchFieldError318) {}
        try {
            e2[Material.SNOW_BLOCK.ordinal()] = 81;
        }
        catch (NoSuchFieldError noSuchFieldError319) {}
        try {
            e2[Material.SOIL.ordinal()] = 61;
        }
        catch (NoSuchFieldError noSuchFieldError320) {}
        try {
            e2[Material.SOUL_SAND.ordinal()] = 89;
        }
        catch (NoSuchFieldError noSuchFieldError321) {}
        try {
            e2[Material.SPECKLED_MELON.ordinal()] = 325;
        }
        catch (NoSuchFieldError noSuchFieldError322) {}
        try {
            e2[Material.SPIDER_EYE.ordinal()] = 318;
        }
        catch (NoSuchFieldError noSuchFieldError323) {}
        try {
            e2[Material.SPONGE.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError324) {}
        try {
            e2[Material.SPRUCE_DOOR.ordinal()] = 194;
        }
        catch (NoSuchFieldError noSuchFieldError325) {}
        try {
            e2[Material.SPRUCE_DOOR_ITEM.ordinal()] = 369;
        }
        catch (NoSuchFieldError noSuchFieldError326) {}
        try {
            e2[Material.SPRUCE_FENCE.ordinal()] = 189;
        }
        catch (NoSuchFieldError noSuchFieldError327) {}
        try {
            e2[Material.SPRUCE_FENCE_GATE.ordinal()] = 184;
        }
        catch (NoSuchFieldError noSuchFieldError328) {}
        try {
            e2[Material.SPRUCE_WOOD_STAIRS.ordinal()] = 135;
        }
        catch (NoSuchFieldError noSuchFieldError329) {}
        try {
            e2[Material.STAINED_CLAY.ordinal()] = 160;
        }
        catch (NoSuchFieldError noSuchFieldError330) {}
        try {
            e2[Material.STAINED_GLASS.ordinal()] = 96;
        }
        catch (NoSuchFieldError noSuchFieldError331) {}
        try {
            e2[Material.STAINED_GLASS_PANE.ordinal()] = 161;
        }
        catch (NoSuchFieldError noSuchFieldError332) {}
        try {
            e2[Material.STANDING_BANNER.ordinal()] = 177;
        }
        catch (NoSuchFieldError noSuchFieldError333) {}
        try {
            e2[Material.STATIONARY_LAVA.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError334) {}
        try {
            e2[Material.STATIONARY_WATER.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError335) {}
        try {
            e2[Material.STEP.ordinal()] = 45;
        }
        catch (NoSuchFieldError noSuchFieldError336) {}
        try {
            e2[Material.STICK.ordinal()] = 223;
        }
        catch (NoSuchFieldError noSuchFieldError337) {}
        try {
            e2[Material.STONE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError338) {}
        try {
            e2[Material.STONE_AXE.ordinal()] = 218;
        }
        catch (NoSuchFieldError noSuchFieldError339) {}
        try {
            e2[Material.STONE_BUTTON.ordinal()] = 78;
        }
        catch (NoSuchFieldError noSuchFieldError340) {}
        try {
            e2[Material.STONE_HOE.ordinal()] = 234;
        }
        catch (NoSuchFieldError noSuchFieldError341) {}
        try {
            e2[Material.STONE_PICKAXE.ordinal()] = 217;
        }
        catch (NoSuchFieldError noSuchFieldError342) {}
        try {
            e2[Material.STONE_PLATE.ordinal()] = 71;
        }
        catch (NoSuchFieldError noSuchFieldError343) {}
        try {
            e2[Material.STONE_SLAB2.ordinal()] = 183;
        }
        catch (NoSuchFieldError noSuchFieldError344) {}
        try {
            e2[Material.STONE_SPADE.ordinal()] = 216;
        }
        catch (NoSuchFieldError noSuchFieldError345) {}
        try {
            e2[Material.STONE_SWORD.ordinal()] = 215;
        }
        catch (NoSuchFieldError noSuchFieldError346) {}
        try {
            e2[Material.STORAGE_MINECART.ordinal()] = 285;
        }
        catch (NoSuchFieldError noSuchFieldError347) {}
        try {
            e2[Material.STRING.ordinal()] = 230;
        }
        catch (NoSuchFieldError noSuchFieldError348) {}
        try {
            e2[Material.SUGAR.ordinal()] = 296;
        }
        catch (NoSuchFieldError noSuchFieldError349) {}
        try {
            e2[Material.SUGAR_CANE.ordinal()] = 281;
        }
        catch (NoSuchFieldError noSuchFieldError350) {}
        try {
            e2[Material.SUGAR_CANE_BLOCK.ordinal()] = 84;
        }
        catch (NoSuchFieldError noSuchFieldError351) {}
        try {
            e2[Material.SULPHUR.ordinal()] = 232;
        }
        catch (NoSuchFieldError noSuchFieldError352) {}
        try {
            e2[Material.THIN_GLASS.ordinal()] = 103;
        }
        catch (NoSuchFieldError noSuchFieldError353) {}
        try {
            e2[Material.TNT.ordinal()] = 47;
        }
        catch (NoSuchFieldError noSuchFieldError354) {}
        try {
            e2[Material.TORCH.ordinal()] = 51;
        }
        catch (NoSuchFieldError noSuchFieldError355) {}
        try {
            e2[Material.TRAPPED_CHEST.ordinal()] = 147;
        }
        catch (NoSuchFieldError noSuchFieldError356) {}
        try {
            e2[Material.TRAP_DOOR.ordinal()] = 97;
        }
        catch (NoSuchFieldError noSuchFieldError357) {}
        try {
            e2[Material.TRIPWIRE.ordinal()] = 133;
        }
        catch (NoSuchFieldError noSuchFieldError358) {}
        try {
            e2[Material.TRIPWIRE_HOOK.ordinal()] = 132;
        }
        catch (NoSuchFieldError noSuchFieldError359) {}
        try {
            e2[Material.VINE.ordinal()] = 107;
        }
        catch (NoSuchFieldError noSuchFieldError360) {}
        try {
            e2[Material.WALL_BANNER.ordinal()] = 178;
        }
        catch (NoSuchFieldError noSuchFieldError361) {}
        try {
            e2[Material.WALL_SIGN.ordinal()] = 69;
        }
        catch (NoSuchFieldError noSuchFieldError362) {}
        try {
            e2[Material.WATCH.ordinal()] = 290;
        }
        catch (NoSuchFieldError noSuchFieldError363) {}
        try {
            e2[Material.WATER.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError364) {}
        try {
            e2[Material.WATER_BUCKET.ordinal()] = 269;
        }
        catch (NoSuchFieldError noSuchFieldError365) {}
        try {
            e2[Material.WATER_LILY.ordinal()] = 112;
        }
        catch (NoSuchFieldError noSuchFieldError366) {}
        try {
            e2[Material.WEB.ordinal()] = 31;
        }
        catch (NoSuchFieldError noSuchFieldError367) {}
        try {
            e2[Material.WHEAT.ordinal()] = 239;
        }
        catch (NoSuchFieldError noSuchFieldError368) {}
        try {
            e2[Material.WOOD.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError369) {}
        try {
            e2[Material.WOODEN_DOOR.ordinal()] = 65;
        }
        catch (NoSuchFieldError noSuchFieldError370) {}
        try {
            e2[Material.WOOD_AXE.ordinal()] = 214;
        }
        catch (NoSuchFieldError noSuchFieldError371) {}
        try {
            e2[Material.WOOD_BUTTON.ordinal()] = 144;
        }
        catch (NoSuchFieldError noSuchFieldError372) {}
        try {
            e2[Material.WOOD_DOOR.ordinal()] = 267;
        }
        catch (NoSuchFieldError noSuchFieldError373) {}
        try {
            e2[Material.WOOD_DOUBLE_STEP.ordinal()] = 126;
        }
        catch (NoSuchFieldError noSuchFieldError374) {}
        try {
            e2[Material.WOOD_HOE.ordinal()] = 233;
        }
        catch (NoSuchFieldError noSuchFieldError375) {}
        try {
            e2[Material.WOOD_PICKAXE.ordinal()] = 213;
        }
        catch (NoSuchFieldError noSuchFieldError376) {}
        try {
            e2[Material.WOOD_PLATE.ordinal()] = 73;
        }
        catch (NoSuchFieldError noSuchFieldError377) {}
        try {
            e2[Material.WOOD_SPADE.ordinal()] = 212;
        }
        catch (NoSuchFieldError noSuchFieldError378) {}
        try {
            e2[Material.WOOD_STAIRS.ordinal()] = 54;
        }
        catch (NoSuchFieldError noSuchFieldError379) {}
        try {
            e2[Material.WOOD_STEP.ordinal()] = 127;
        }
        catch (NoSuchFieldError noSuchFieldError380) {}
        try {
            e2[Material.WOOD_SWORD.ordinal()] = 211;
        }
        catch (NoSuchFieldError noSuchFieldError381) {}
        try {
            e2[Material.WOOL.ordinal()] = 36;
        }
        catch (NoSuchFieldError noSuchFieldError382) {}
        try {
            e2[Material.WORKBENCH.ordinal()] = 59;
        }
        catch (NoSuchFieldError noSuchFieldError383) {}
        try {
            e2[Material.WRITTEN_BOOK.ordinal()] = 330;
        }
        catch (NoSuchFieldError noSuchFieldError384) {}
        try {
            e2[Material.YELLOW_FLOWER.ordinal()] = 38;
        }
        catch (NoSuchFieldError noSuchFieldError385) {}
        return aA.e = e2;
    }
}
