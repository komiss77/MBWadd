// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import java.util.concurrent.Callable;
import de.marcely.bedwars.achievements.UserAchievements;
import de.marcely.bedwars.game.stats.c;
import java.util.concurrent.Future;
import java.util.UUID;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.util.MThread;
import java.util.ArrayDeque;
import de.marcely.bedwars.util.e;
import java.util.Queue;

public abstract class ef
{
    private eg a;
    public final Queue<e<?>> a;
    private boolean isRunning;
    
    public ef(final eg a) {
        this.isRunning = true;
        this.a = a;
        this.a = new ArrayDeque<e<?>>();
        new MThread(MThread.ThreadType.q, "Type:" + a.name()) {
            @Override
            public void run() {
                while (ef.this.isRunning) {
                    if (ef.this.a.size() >= 1) {
                        e<?> e;
                        while ((e = ef.this.a.poll()) != null) {
                            if (!e.isDone()) {
                                e.ae();
                            }
                        }
                    }
                    s.sleep(50L);
                }
            }
        }.start();
    }
    
    public void shutdown() {
        if (!this.isConnected()) {
            this.a.clear();
        }
        this.ab();
        this.isRunning = false;
        d.c("Successfully shut down service: " + this.a.name());
    }
    
    public abstract boolean aa();
    
    public abstract boolean ab();
    
    public abstract boolean isConnected();
    
    public abstract Future<Boolean> d(final UUID p0);
    
    public abstract Future<c> a(final UUID p0, final String p1);
    
    public abstract Future<UUID[]> c();
    
    public abstract Future<Void> a(final c p0);
    
    public abstract Future<Void> b(final c p0);
    
    public abstract Future<Boolean> e(final UUID p0);
    
    public abstract Future<UserAchievements> f(final UUID p0);
    
    public abstract Future<Void> a(final UserAchievements p0);
    
    public abstract Future<Void> b(final UserAchievements p0);
    
    protected <T> Future<T> a(final Callable<T> callable) {
        final e<Object> e = new e<Object>((Callable<Object>)callable);
        this.a.add(e);
        return (Future<T>)e;
    }
    
    public eg a() {
        return this.a;
    }
}
