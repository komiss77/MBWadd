// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.plugin.Plugin;
import java.net.NetworkInterface;
import java.net.InetAddress;
import de.marcely.bedwars.versions.Version;
import org.bukkit.Bukkit;

public class eh extends ek
{
    private final el a;
    private boolean ap;
    
    public eh(final el a) {
        this.ap = false;
        this.a = a;
    }
    
    @Override
    public void a(final et et) {
        switch (et.reply) {
            case -1: {
                this.a.a(ej.d);
                final eu eu = new eu();
                eu.ac = Bukkit.getBukkitVersion();
                eu.ad = Version.a().a().name();
                final Plugin[] plugins = Bukkit.getPluginManager().getPlugins();
                eu.a = new eu.a[plugins.length];
                for (int i = 0; i < plugins.length; ++i) {
                    eu.a[i] = de.marcely.bedwars.eu.a.a(plugins[i]);
                }
                try {
                    eu.b = NetworkInterface.getByInetAddress(InetAddress.getLocalHost()).getHardwareAddress();
                    if (eu.b.length > 32) {
                        eu.b = null;
                    }
                }
                catch (Exception ex) {}
                this.a.a(eu);
                break;
            }
            case 1: {
                this.a.a(ei.a.d);
                break;
            }
            case 3: {
                this.a.a(ei.a.e);
                break;
            }
            default: {
                this.a.a(ei.a.c);
                break;
            }
        }
    }
    
    @Override
    public void a(final ev ev) {
        switch (ev.reply) {
            case -1: {
                this.a.a(ej.a);
                this.a.a().onConnect();
                break;
            }
            case 1: {
                this.a.a(ei.a.b);
                break;
            }
            default: {
                this.a.a(ei.a.c);
                break;
            }
        }
    }
    
    @Override
    public void a(final er er) {
        if (!this.ap) {
            this.ap = true;
            this.a.a().a(er.a);
        }
    }
    
    @Override
    public void a(final ep ep) {
        final em em = this.a.ae.get(ep.z);
        if (em != null) {
            this.a.ae.remove(ep.z);
            em.a(ep.data, this.a.ae.size());
        }
    }
    
    @Override
    public void a(final en en) {
        this.a.a().a(en.name.length() > 1, en.name);
    }
    
    @Override
    public void a(final ew ew) {
        switch (ew.L) {
            case 0: {
                d.m("SERVER MESSAGE: " + ew.message);
                break;
            }
            case 16: {
                d.n("SERVER MESSAGE: " + ew.message);
                break;
            }
            case 17: {
                d.n("SERVER MESSAGE: " + ew.message);
                break;
            }
        }
    }
}
