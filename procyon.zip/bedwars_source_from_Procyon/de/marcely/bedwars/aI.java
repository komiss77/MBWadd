// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Player;
import org.bukkit.entity.EntityType;
import org.bukkit.event.entity.FoodLevelChangeEvent;

public class aI
{
    public static void a(final FoodLevelChangeEvent foodLevelChangeEvent) {
        if (foodLevelChangeEvent.getEntity().getType() == EntityType.PLAYER) {
            final Player player = (Player)foodLevelChangeEvent.getEntity();
            final Arena a = s.a(player);
            if (a != null) {
                if (a.b().F() || !ConfigValue.hunger) {
                    foodLevelChangeEvent.setCancelled(true);
                }
            }
            else if (cA.E.containsKey(player)) {
                foodLevelChangeEvent.setCancelled(true);
            }
        }
    }
}
