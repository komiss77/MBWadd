// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.library.worldedit.a;

public enum cT
{
    a("CaveCloud", (Class<? extends cR>)cY.class, true), 
    b("CloudNetAPI", (Class<? extends cR>)da.class, true), 
    c("CloudNet-Bridge", (Class<? extends cR>)db.class, true), 
    d("CloudSystem", (Class<? extends cR>)dc.class, true), 
    e("TimoCloud", (Class<? extends cR>)de.class, true), 
    f("ReformCloudAPISpigot", (Class<? extends cR>)dd.class, true), 
    g("AutoNicker", (Class<? extends cR>)dk.class), 
    h("NickNamer", (Class<? extends cR>)dq.class), 
    i("VIPHide", (Class<? extends cR>)dr.class), 
    j("BetterNick", (Class<? extends cR>)dl.class), 
    k("EazyNick", (Class<? extends cR>)dm.class), 
    l("NickAPI", (Class<? extends cR>)do.class), 
    m("NametagEdit", (Class<? extends cR>)dn.class), 
    n("PlaceholderAPI", (Class<? extends cR>)dt.class), 
    o("MVdWPlaceholderAPI", (Class<? extends cR>)ds.class), 
    p("PvPLevels", (Class<? extends cR>)dj.class), 
    q("DKCoins", (Class<? extends cR>)dh.class), 
    r("NickAPI", (Class<? extends cR>)di.class), 
    s("GroupManager", (Class<? extends cR>)cP.class), 
    t("FeatherBoard", (Class<? extends cR>)cQ.class), 
    u("ProtocolLib", (Class<? extends cR>)cV.class), 
    v("Vault", (Class<? extends cR>)cW.class), 
    w("Spigot-Party-API-PAF", (Class<? extends cR>)cU.class), 
    x("AdvancedReplay", (Class<? extends cR>)cO.class), 
    y("ReplaySystem", (Class<? extends cR>)cX.class, true), 
    z("RegionEdit", (Class<? extends cR>)a.class, false, true);
    
    private final String pluginName;
    private final Class<? extends cR> clazz;
    private final boolean X;
    private final boolean Y;
    
    static {
        a = new cT[] { cT.a, cT.b, cT.c, cT.d, cT.e, cT.f, cT.g, cT.h, cT.i, cT.j, cT.k, cT.l, cT.m, cT.n, cT.o, cT.p, cT.q, cT.r, cT.s, cT.t, cT.u, cT.v, cT.w, cT.x, cT.y, cT.z };
    }
    
    private cT(final String s2, final Class<? extends cR> clazz) {
        this(s2, clazz, false, false);
    }
    
    private cT(final String s2, final Class<? extends cR> clazz, final boolean b) {
        this(s2, clazz, b, false);
    }
    
    private cT(final String pluginName, final Class<? extends cR> clazz, final boolean x, final boolean y) {
        this.pluginName = pluginName;
        this.clazz = clazz;
        this.X = x;
        this.Y = y;
    }
    
    public String getPluginName() {
        return this.pluginName;
    }
    
    public Class<? extends cR> getClazz() {
        return this.clazz;
    }
    
    public boolean O() {
        return this.X;
    }
    
    public boolean P() {
        return this.Y;
    }
}
