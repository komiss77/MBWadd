// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class ex
{
    public abstract ey a();
    
    protected abstract void a(final BufferedWriteStream p0);
    
    protected abstract void a(final BufferedReadStream p0);
    
    public void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.a().getId());
        this.a(bufferedWriteStream);
    }
    
    @Nullable
    public static ex a(final BufferedReadStream bufferedReadStream) {
        final ey a = ey.a(bufferedReadStream.readByte());
        if (a != null) {
            final ex a2 = a.a();
            a2.a(bufferedReadStream);
            return a2;
        }
        return null;
    }
}
