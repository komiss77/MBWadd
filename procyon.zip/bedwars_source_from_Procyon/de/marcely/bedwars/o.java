// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public class o extends j
{
    private String h;
    
    public o(final String h) {
        this.h = h;
    }
    
    public String f() {
        return this.h;
    }
    
    @Override
    public String d() {
        return a.a.getID() + "/" + this.f();
    }
    
    public static o a(final String s) {
        final String[] split = s.split("/");
        if (split.length == 2) {
            return new o(split[1]);
        }
        return null;
    }
}
