// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Entity;
import java.util.Iterator;
import org.bukkit.Chunk;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import org.bukkit.event.world.ChunkLoadEvent;

public class bg
{
    public static void a(final ChunkLoadEvent chunkLoadEvent) {
        final Chunk chunk = chunkLoadEvent.getChunk();
        final String string = String.valueOf(chunk.getX()) + "." + chunk.getZ();
        for (final Arena arena : s.af) {
            if (arena.b() == ArenaStatus.f && !arena.L.contains(string)) {
                Entity[] entities;
                for (int length = (entities = chunk.getEntities()).length, i = 0; i < length; ++i) {
                    final Entity entity = entities[i];
                    if (entity.getType() == EntityType.DROPPED_ITEM && arena.isInside(entity.getLocation())) {
                        entity.remove();
                    }
                }
                arena.L.add(string);
            }
        }
    }
}
