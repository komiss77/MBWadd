// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import javax.annotation.Nullable;
import java.util.Iterator;
import de.marcely.bedwars.util.i;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.api.SpectateReason;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.spectator.item.b;
import java.util.ArrayList;
import de.marcely.bedwars.game.spectator.item.SpectatorItem;
import java.util.List;

public class cB
{
    public static final List<cC> U;
    public static final List<SpectatorItem> V;
    
    static {
        U = new ArrayList<cC>();
        V = new ArrayList<SpectatorItem>();
    }
    
    public static void init() {
        cB.U.clear();
        b[] values;
        for (int length = (values = b.values()).length, i = 0; i < length; ++i) {
            cB.U.add(values[i].a());
        }
    }
    
    public static void a(final Player player, final SpectateReason spectateReason) {
        s.M(player);
        for (final SpectatorItem spectatorItem : cB.V) {
            if (spectateReason == SpectateReason.DEATH && !spectatorItem.a().a(player, spectateReason)) {
                continue;
            }
            player.getInventory().setItem(spectatorItem.getSlot(), i.a(spectatorItem.getItem().clone(), spectatorItem.q()));
        }
    }
    
    @Nullable
    public static SpectatorItem a(final int n) {
        for (final SpectatorItem spectatorItem : cB.V) {
            if (spectatorItem.getSlot() == n) {
                return spectatorItem;
            }
        }
        return null;
    }
    
    @Nullable
    public static cC a(final String anotherString) {
        for (final cC cc : cB.U) {
            if (cc.getIdentifier().equalsIgnoreCase(anotherString)) {
                return cc;
            }
        }
        return null;
    }
}
