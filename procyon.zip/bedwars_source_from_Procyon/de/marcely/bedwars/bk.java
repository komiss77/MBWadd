// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.util.s;
import org.bukkit.event.world.WorldUnloadEvent;

public class bk
{
    public static void a(final WorldUnloadEvent worldUnloadEvent) {
        s.b.a(worldUnloadEvent.getWorld());
    }
}
