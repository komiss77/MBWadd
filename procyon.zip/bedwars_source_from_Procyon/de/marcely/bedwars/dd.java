// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import systems.reformcloud.meta.enums.ServerState;
import de.marcely.bedwars.game.arena.ArenaStatus;
import systems.reformcloud.meta.info.ServerInfo;
import systems.reformcloud.ReformCloudAPISpigot;
import de.marcely.bedwars.game.arena.Arena;
import de.marcely.bedwars.util.s;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.game.arena.d;

public class dd extends cZ
{
    private d a;
    private static /* synthetic */ int[] l;
    
    @Override
    public cT a() {
        return cT.f;
    }
    
    @Override
    public void onEnable() {
        final Arena b = s.b(ConfigValue.cloudsystem_arena);
        if (b == null) {
            de.marcely.bedwars.d.h("Unkown arena '" + ConfigValue.cloudsystem_arena + "'");
            return;
        }
        this.f(b);
        b.a(this.a = new d() {
            @Override
            public void a(final Arena arena, final a a) {
                dd.this.f(arena);
            }
        });
    }
    
    private void f(final Arena arena) {
        final ServerInfo serverInfo = ReformCloudAPISpigot.getInstance().getServerInfo();
        serverInfo.setMotd(ConfigValue.cloudsystem_extra.a(arena));
        serverInfo.setOnline(arena.getPlayers().size());
        serverInfo.setServerState(this.a(arena.b()));
    }
    
    private ServerState a(final ArenaStatus arenaStatus) {
        switch (m()[arenaStatus.ordinal()]) {
            case 1:
            case 3: {
                return ServerState.HIDDEN;
            }
            case 2: {
                return ServerState.READY;
            }
            case 4:
            case 5: {
                return ServerState.NOT_READY;
            }
            default: {
                return ServerState.READY;
            }
        }
    }
    
    @Override
    public void onDisable() {
        final Arena b = s.b(ConfigValue.cloudsystem_arena);
        if (b != null) {
            b.a(this.a);
        }
    }
    
    static /* synthetic */ int[] m() {
        final int[] l = dd.l;
        if (l != null) {
            return l;
        }
        final int[] i = new int[ArenaStatus.values().length];
        try {
            i[ArenaStatus.h.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            i[ArenaStatus.e.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            i[ArenaStatus.g.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            i[ArenaStatus.f.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            i[ArenaStatus.d.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        return dd.l = i;
    }
}
