// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.arena.Arena;
import org.bukkit.entity.Player;

public class dL extends dI
{
    public dL() {
        super("teamsize");
    }
    
    @Override
    protected String a(final Player player, final Arena arena) {
        return new StringBuilder().append(arena.getPerTeamPlayers()).toString();
    }
}
