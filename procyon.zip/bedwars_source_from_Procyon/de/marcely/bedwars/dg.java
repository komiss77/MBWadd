// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.Player;

public abstract class dg extends cR
{
    public abstract void a(final Player p0, final df p1);
}
