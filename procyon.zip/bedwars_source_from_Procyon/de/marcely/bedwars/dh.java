// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import ch.dkrieger.coinsystem.core.CoinSystem;
import de.marcely.bedwars.config.ConfigValue;
import org.bukkit.entity.Player;

public class dh extends dg
{
    private static /* synthetic */ int[] q;
    
    @Override
    public cT a() {
        return cT.q;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public void a(final Player player, final df df) {
        switch (r()[df.ordinal()]) {
            case 1: {
                this.c(player, ConfigValue.coins_give_win);
                break;
            }
            case 2: {
                this.c(player, ConfigValue.coins_give_lose);
                break;
            }
            case 3: {
                this.c(player, ConfigValue.coins_give_beddestroy);
                break;
            }
            case 4: {
                this.c(player, ConfigValue.coins_give_killplayer);
                break;
            }
        }
    }
    
    private void c(final Player player, final int n) {
        CoinSystem.getInstance().getPlayerManager().getPlayer(player.getUniqueId()).addCoins((long)n);
    }
    
    static /* synthetic */ int[] r() {
        final int[] q = dh.q;
        if (q != null) {
            return q;
        }
        final int[] q2 = new int[df.values().length];
        try {
            q2[df.c.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            q2[df.d.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            q2[df.b.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            q2[df.a.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        return dh.q = q2;
    }
}
