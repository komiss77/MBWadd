// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.flag.Value;
import de.marcely.sbenlib.util.BufferedReadStream;
import javax.annotation.Nullable;
import org.bukkit.entity.EntityType;
import de.marcely.bedwars.versions.Version;
import de.marcely.bedwars.util.s;
import org.bukkit.entity.Entity;
import org.bukkit.World;
import de.marcely.sbenlib.util.BufferedWriteStream;
import de.marcely.bedwars.flag.d;

public class bM
{
    public String type;
    public d c;
    
    public bM(final String type, final d c) {
        this.type = type;
        this.c = c;
    }
    
    public void write(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.type);
        this.c.write(bufferedWriteStream);
    }
    
    @Nullable
    public Entity b(final World world) {
        final EntityType a = s.a(this.type);
        if (a == null) {
            return null;
        }
        return Version.a().a(world, a, this.c);
    }
    
    public static bM a(final BufferedReadStream bufferedReadStream) {
        return new bM(bufferedReadStream.readString(), (d)Value.a(bufferedReadStream));
    }
    
    public static bM a(final Entity entity) {
        return new bM(entity.getType().toString(), Version.a().a(entity));
    }
}
