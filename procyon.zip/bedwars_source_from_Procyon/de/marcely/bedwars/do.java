// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import cloud.evaped.nickapi.api.APIManager;
import org.bukkit.entity.Player;

public class do extends dp
{
    @Override
    public cT a() {
        return cT.l;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String c(final Player player) {
        return APIManager.getNickAPI().isNicked(player) ? player.getName() : null;
    }
    
    @Override
    public String d(final Player player) {
        return APIManager.getNickAPI().isNicked(player) ? APIManager.getNickAPI().getRealName(player) : null;
    }
}
