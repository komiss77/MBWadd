// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import me.blvckbytes.autonicker.NickSession;
import me.blvckbytes.autonicker.api.NickAPI;
import org.bukkit.entity.Player;

public class dk extends dp
{
    @Override
    public cT a() {
        return cT.g;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public String c(final Player player) {
        final NickSession session = NickAPI.getSession(player);
        if (session.isNicked()) {
            return session.current_nick;
        }
        return null;
    }
    
    @Override
    public String d(final Player player) {
        final NickSession session = NickAPI.getSession(player);
        if (session.isNicked()) {
            return session.real_name;
        }
        return null;
    }
}
