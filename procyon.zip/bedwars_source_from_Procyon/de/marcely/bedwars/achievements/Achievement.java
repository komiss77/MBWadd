// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.achievements;

import de.marcely.bedwars.message.b;
import de.marcely.bedwars.Language;
import javax.annotation.Nullable;
import org.bukkit.command.CommandSender;

public enum Achievement
{
    b("RageQuit", 0, 0, "Default_Leave_Ingame"), 
    c("WinRound", 1, 1, "Default_Win_Round"), 
    d("LoseRound", 2, 2, "Default_LoseRounds"), 
    @Deprecated
    e("Unlucky", 3, 3, "Default_Unlucky"), 
    f("OPBow", 4, 4, "Default_OPBow"), 
    g("useRescuePlatform", 5, 5, "Default_Use_RescuePlatform"), 
    h("useEnderpearl", 6, 6, "Default_Use_EnderPearl"), 
    i("useMinishop", 7, 7, "Default_Use_MiniShop"), 
    j("killWithBow", 8, 8, " Default_Kill_WBow"), 
    k("winRoundIn3Minutes", 9, 9, "Default_WinInTime"), 
    l("killEnemyWithHalfHeart", 10, 10, "Default_Kill_WHalfHeart"), 
    m("win100Rounds", 11, 11, "Default_Win_AmountRounds"), 
    n("useBridge", 12, 12, "Default_Use_Bridge"), 
    o("useGuardDog", 13, 13, "Default_Use_GD"), 
    p("effectMagnetShoes", 14, 14, "Default_Use_MagnetShoes"), 
    q("useTeleporter", 15, 15, "Default_Use_Teleporter"), 
    r("useTNTSheep", 16, 16, "Default_Use_TNTSheep"), 
    s("useTracker", 17, 17, "Default_Use_Tracker"), 
    t("placeTrap", 18, 18, "Default_Trap_Place"), 
    u("runOverTrap", 19, 19, "Default_Trap_Interact"), 
    v("rankingInTop3", 20, 20, "Default_Rank_InTop3"), 
    w("goodKD", 21, 21, "Default_Stats_GoodKD"), 
    x("highPlayTime", 22, 22, "Default_Stats_HighPlaytIME"), 
    y("writeGGAtEnd", 23, 23, "Default_WriteGG_End"), 
    z("winWithoutBed", 24, 24, "Default_Win_WithoutBed"), 
    A("die10SecsAfterBedDestruction", 25, 25, "Default_Die_SecsAfterBedDestroyed"), 
    B("optainEveryAchievement", 26, 26, "Default_WinEveryAchievement");
    
    private final int id;
    public final String identifier;
    private static /* synthetic */ int[] a;
    private static final /* synthetic */ Achievement[] a;
    
    static {
        a = new Achievement[] { Achievement.b, Achievement.c, Achievement.d, Achievement.e, Achievement.f, Achievement.g, Achievement.h, Achievement.i, Achievement.j, Achievement.k, Achievement.l, Achievement.m, Achievement.n, Achievement.o, Achievement.p, Achievement.q, Achievement.r, Achievement.s, Achievement.t, Achievement.u, Achievement.v, Achievement.w, Achievement.x, Achievement.y, Achievement.z, Achievement.A, Achievement.B };
    }
    
    private Achievement(final String name, final int ordinal, final int id, final String identifier) {
        this.id = id;
        this.identifier = identifier;
    }
    
    public String a(@Nullable final CommandSender commandSender) {
        switch (a()[this.ordinal()]) {
            case 1: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_rageQuit).f(commandSender);
            }
            case 2: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_winRound).f(commandSender);
            }
            case 3: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_loseRound).f(commandSender);
            }
            case 4: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_ownBedDestroyed).f(commandSender);
            }
            case 5: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_bestBow).f(commandSender);
            }
            case 6: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useRescuePlatform).f(commandSender);
            }
            case 7: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useEndepearl).f(commandSender);
            }
            case 8: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useMinishop).f(commandSender);
            }
            case 9: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_killSomeoneWithBow).f(commandSender);
            }
            case 10: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_winIn3Minutes).f(commandSender);
            }
            case 11: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_killSomeoneWithHalfAHeart).f(commandSender);
            }
            case 12: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_win100Rounds).f(commandSender);
            }
            case 13: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useBridge).f(commandSender);
            }
            case 14: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useGuardDog).f(commandSender);
            }
            case 15: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_effectMagnetShoes).f(commandSender);
            }
            case 16: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useTeleporter).f(commandSender);
            }
            case 17: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useTNTSheep).f(commandSender);
            }
            case 18: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_useTracker).f(commandSender);
            }
            case 19: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_placeTrap).f(commandSender);
            }
            case 20: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_runOverTrap).f(commandSender);
            }
            case 21: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_rankingInTop3).f(commandSender);
            }
            case 22: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_goodKD).f(commandSender);
            }
            case 23: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_highPlayTime).f(commandSender);
            }
            case 24: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_writeGGAtEnd).f(commandSender);
            }
            case 25: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_winWithoutBed).f(commandSender);
            }
            case 26: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_die10SecsAfterBedDestruction).f(commandSender);
            }
            case 27: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_name_optainEveryAchievement).f(commandSender);
            }
            default: {
                return null;
            }
        }
    }
    
    @Deprecated
    public String b(@Nullable final CommandSender commandSender) {
        return this.c(commandSender);
    }
    
    public String c(@Nullable final CommandSender commandSender) {
        switch (a()[this.ordinal()]) {
            case 1: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_rageQuit).f(commandSender);
            }
            case 2: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_winRound).f(commandSender);
            }
            case 3: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_loseRound).f(commandSender);
            }
            case 4: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_ownBedDestroyed).f(commandSender);
            }
            case 5: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_bestBow).f(commandSender);
            }
            case 6: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useRescuePlatform).f(commandSender);
            }
            case 7: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useEndepearl).f(commandSender);
            }
            case 8: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useMinishop).f(commandSender);
            }
            case 9: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_killSomeoneWithBow).f(commandSender);
            }
            case 10: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_winIn3Minutes).f(commandSender);
            }
            case 11: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_killSomeoneWithHalfAHeart).f(commandSender);
            }
            case 12: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_win100Rounds).f(commandSender);
            }
            case 13: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useBridge).f(commandSender);
            }
            case 14: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useGuardDog).f(commandSender);
            }
            case 15: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_effectMagnetShoes).f(commandSender);
            }
            case 16: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useTeleporter).f(commandSender);
            }
            case 17: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useTNTSheep).f(commandSender);
            }
            case 18: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_useTracker).f(commandSender);
            }
            case 19: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_placeTrap).f(commandSender);
            }
            case 20: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_runOverTrap).f(commandSender);
            }
            case 21: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_rankingInTop3).f(commandSender);
            }
            case 22: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_goodKD).f(commandSender);
            }
            case 23: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_highPlayTime).f(commandSender);
            }
            case 24: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_writeGGAtEnd).f(commandSender);
            }
            case 25: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_winWithoutBed).f(commandSender);
            }
            case 26: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_die10SecsAfterBedDestruction).f(commandSender);
            }
            case 27: {
                return de.marcely.bedwars.message.b.a(Language.Achievements_text_optainEveryAchievement).f(commandSender);
            }
            default: {
                return null;
            }
        }
    }
    
    public int getID() {
        return this.id;
    }
    
    @Nullable
    public static Achievement a(final int n) {
        Achievement[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Achievement achievement = values[i];
            if (achievement.getID() == n) {
                return achievement;
            }
        }
        return null;
    }
    
    @Nullable
    public static Achievement a(final String s) {
        Achievement[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final Achievement achievement = values[i];
            if (achievement.name().equalsIgnoreCase(s) || achievement.identifier.equalsIgnoreCase(s)) {
                return achievement;
            }
        }
        return null;
    }
    
    static /* synthetic */ int[] a() {
        final int[] a = Achievement.a;
        if (a != null) {
            return a;
        }
        final int[] a2 = new int[values().length];
        try {
            a2[Achievement.d.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            a2[Achievement.f.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            a2[Achievement.b.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            a2[Achievement.e.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            a2[Achievement.c.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            a2[Achievement.A.ordinal()] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            a2[Achievement.p.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            a2[Achievement.w.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            a2[Achievement.x.ordinal()] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            a2[Achievement.l.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            a2[Achievement.j.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            a2[Achievement.B.ordinal()] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            a2[Achievement.t.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            a2[Achievement.v.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        try {
            a2[Achievement.u.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError15) {}
        try {
            a2[Achievement.n.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError16) {}
        try {
            a2[Achievement.h.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError17) {}
        try {
            a2[Achievement.o.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError18) {}
        try {
            a2[Achievement.i.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError19) {}
        try {
            a2[Achievement.g.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError20) {}
        try {
            a2[Achievement.r.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError21) {}
        try {
            a2[Achievement.q.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError22) {}
        try {
            a2[Achievement.s.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError23) {}
        try {
            a2[Achievement.m.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError24) {}
        try {
            a2[Achievement.k.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError25) {}
        try {
            a2[Achievement.z.ordinal()] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError26) {}
        try {
            a2[Achievement.y.ordinal()] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError27) {}
        return Achievement.a = a2;
    }
}
