// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars.achievements;

import de.marcely.bedwars.util.s;
import java.util.concurrent.ExecutionException;
import de.marcely.bedwars.util.FutureResult;
import java.util.concurrent.Future;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import java.io.Serializable;
import de.marcely.bedwars.api.AchievementsAPI;

public class UserAchievements implements AchievementsAPI, Serializable
{
    private static final long serialVersionUID = 3822281586530543702L;
    public UUID uuid;
    private final List<Achievement> gotAchievements;
    private static Map<UUID, UserAchievements> loadedAchievements;
    
    static {
        UserAchievements.loadedAchievements = new HashMap<UUID, UserAchievements>();
    }
    
    public UserAchievements(final UUID uuid) {
        this(uuid, new ArrayList<Achievement>());
    }
    
    public UserAchievements(final UUID uuid, final Achievement... a) {
        this(uuid, new ArrayList<Achievement>(Arrays.asList(a)));
    }
    
    public UserAchievements(final UUID uuid, final List<Achievement> gotAchievements) {
        this.uuid = uuid;
        this.gotAchievements = gotAchievements;
    }
    
    @Override
    public boolean has(final Achievement achievement) {
        return this.gotAchievements.contains(achievement);
    }
    
    public boolean a(final Achievement achievement) {
        return !this.has(achievement) && this.gotAchievements.add(achievement);
    }
    
    public boolean b(final Achievement achievement) {
        return this.has(achievement) && this.gotAchievements.remove(achievement);
    }
    
    public List<Achievement> a() {
        return this.gotAchievements;
    }
    
    public static Future<UserAchievements> a(final UUID uuid) {
        final FutureResult<UserAchievements> futureResult = new FutureResult<UserAchievements>();
        if (UserAchievements.loadedAchievements.containsKey(uuid)) {
            futureResult.a(UserAchievements.loadedAchievements.get(uuid));
        }
        else {
            final Future<UserAchievements> b = b(uuid);
            s.a((Future<Object>)b, new Runnable() {
                @Override
                public void run() {
                    try {
                        UserAchievements userAchievements = b.get();
                        if (userAchievements == null) {
                            userAchievements = new UserAchievements(uuid, new ArrayList<Achievement>());
                        }
                        UserAchievements.loadedAchievements.put(uuid, userAchievements);
                        futureResult.a(userAchievements);
                    }
                    catch (InterruptedException | ExecutionException ex) {
                        final Object o2;
                        final Object o = o2;
                        futureResult.die();
                        ((Throwable)o).printStackTrace();
                    }
                }
            });
        }
        return futureResult;
    }
    
    private static Future<UserAchievements> b(final UUID uuid) {
        return s.b.f(uuid);
    }
    
    public void save() {
        s.b.b(this);
    }
    
    public static Future<Boolean> c(final UUID uuid) {
        return s.b.e(uuid);
    }
    
    public static void onEnable() {
    }
    
    public static void a(final UUID uuid) {
        UserAchievements.loadedAchievements.remove(uuid);
    }
    
    public static void e() {
        UserAchievements.loadedAchievements.clear();
    }
    
    @Override
    public UUID getUUID() {
        return this.uuid;
    }
    
    @Override
    public void set(final Achievement achievement, final boolean b) {
        if (b) {
            if (!this.has(achievement)) {
                this.a(achievement);
            }
        }
        else if (this.has(achievement)) {
            this.b(achievement);
        }
    }
}
