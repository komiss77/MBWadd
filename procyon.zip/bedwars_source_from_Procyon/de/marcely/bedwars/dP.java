// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.game.stats.c;

public class dP extends dR
{
    public dP() {
        super("kills");
    }
    
    @Override
    public String c(final c c) {
        return new StringBuilder().append(c.getKills()).toString();
    }
}
