// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.entity.EntityType;
import java.util.Iterator;
import org.bukkit.block.Block;
import java.util.List;
import org.bukkit.event.entity.EntityExplodeEvent;

public class aG
{
    private static /* synthetic */ int[] f;
    
    public static void a(final EntityExplodeEvent entityExplodeEvent) {
        av.a a = null;
        switch (f()[entityExplodeEvent.getEntityType().ordinal()]) {
            case 14: {
                a = av.a.a;
                break;
            }
            default: {
                a = av.a.b;
                break;
            }
        }
        final av.b b = new av.b(a, entityExplodeEvent.blockList(), entityExplodeEvent.getEntity().getLocation());
        av.a(b);
        if (b.a != null) {
            entityExplodeEvent.setCancelled((boolean)b.a);
        }
        final Iterator<Block> iterator = (Iterator<Block>)entityExplodeEvent.blockList().iterator();
        while (iterator.hasNext()) {
            if (!b.A.contains(iterator.next())) {
                iterator.remove();
            }
        }
    }
    
    static /* synthetic */ int[] f() {
        final int[] f = aG.f;
        if (f != null) {
            return f;
        }
        final int[] f2 = new int[EntityType.values().length];
        try {
            f2[EntityType.ARMOR_STAND.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            f2[EntityType.ARROW.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            f2[EntityType.BAT.ordinal()] = 41;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            f2[EntityType.BLAZE.ordinal()] = 37;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            f2[EntityType.BOAT.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            f2[EntityType.CAVE_SPIDER.ordinal()] = 35;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            f2[EntityType.CHICKEN.ordinal()] = 48;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            f2[EntityType.COMPLEX_PART.ordinal()] = 65;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            f2[EntityType.COW.ordinal()] = 47;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            f2[EntityType.CREEPER.ordinal()] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            f2[EntityType.DROPPED_ITEM.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            f2[EntityType.EGG.ordinal()] = 60;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            f2[EntityType.ENDERMAN.ordinal()] = 34;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            f2[EntityType.ENDERMITE.ordinal()] = 43;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        try {
            f2[EntityType.ENDER_CRYSTAL.ordinal()] = 58;
        }
        catch (NoSuchFieldError noSuchFieldError15) {}
        try {
            f2[EntityType.ENDER_DRAGON.ordinal()] = 39;
        }
        catch (NoSuchFieldError noSuchFieldError16) {}
        try {
            f2[EntityType.ENDER_PEARL.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError17) {}
        try {
            f2[EntityType.ENDER_SIGNAL.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError18) {}
        try {
            f2[EntityType.EXPERIENCE_ORB.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError19) {}
        try {
            f2[EntityType.FALLING_BLOCK.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError20) {}
        try {
            f2[EntityType.FIREBALL.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError21) {}
        try {
            f2[EntityType.FIREWORK.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError22) {}
        try {
            f2[EntityType.FISHING_HOOK.ordinal()] = 61;
        }
        catch (NoSuchFieldError noSuchFieldError23) {}
        try {
            f2[EntityType.GHAST.ordinal()] = 32;
        }
        catch (NoSuchFieldError noSuchFieldError24) {}
        try {
            f2[EntityType.GIANT.ordinal()] = 29;
        }
        catch (NoSuchFieldError noSuchFieldError25) {}
        try {
            f2[EntityType.GUARDIAN.ordinal()] = 44;
        }
        catch (NoSuchFieldError noSuchFieldError26) {}
        try {
            f2[EntityType.HORSE.ordinal()] = 55;
        }
        catch (NoSuchFieldError noSuchFieldError27) {}
        try {
            f2[EntityType.IRON_GOLEM.ordinal()] = 54;
        }
        catch (NoSuchFieldError noSuchFieldError28) {}
        try {
            f2[EntityType.ITEM_FRAME.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError29) {}
        try {
            f2[EntityType.LEASH_HITCH.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError30) {}
        try {
            f2[EntityType.LIGHTNING.ordinal()] = 62;
        }
        catch (NoSuchFieldError noSuchFieldError31) {}
        try {
            f2[EntityType.MAGMA_CUBE.ordinal()] = 38;
        }
        catch (NoSuchFieldError noSuchFieldError32) {}
        try {
            f2[EntityType.MINECART.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError33) {}
        try {
            f2[EntityType.MINECART_CHEST.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError34) {}
        try {
            f2[EntityType.MINECART_COMMAND.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError35) {}
        try {
            f2[EntityType.MINECART_FURNACE.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError36) {}
        try {
            f2[EntityType.MINECART_HOPPER.ordinal()] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError37) {}
        try {
            f2[EntityType.MINECART_MOB_SPAWNER.ordinal()] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError38) {}
        try {
            f2[EntityType.MINECART_TNT.ordinal()] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError39) {}
        try {
            f2[EntityType.MUSHROOM_COW.ordinal()] = 51;
        }
        catch (NoSuchFieldError noSuchFieldError40) {}
        try {
            f2[EntityType.OCELOT.ordinal()] = 53;
        }
        catch (NoSuchFieldError noSuchFieldError41) {}
        try {
            f2[EntityType.PAINTING.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError42) {}
        try {
            f2[EntityType.PIG.ordinal()] = 45;
        }
        catch (NoSuchFieldError noSuchFieldError43) {}
        try {
            f2[EntityType.PIG_ZOMBIE.ordinal()] = 33;
        }
        catch (NoSuchFieldError noSuchFieldError44) {}
        try {
            f2[EntityType.PLAYER.ordinal()] = 64;
        }
        catch (NoSuchFieldError noSuchFieldError45) {}
        try {
            f2[EntityType.PRIMED_TNT.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError46) {}
        try {
            f2[EntityType.RABBIT.ordinal()] = 56;
        }
        catch (NoSuchFieldError noSuchFieldError47) {}
        try {
            f2[EntityType.SHEEP.ordinal()] = 46;
        }
        catch (NoSuchFieldError noSuchFieldError48) {}
        try {
            f2[EntityType.SILVERFISH.ordinal()] = 36;
        }
        catch (NoSuchFieldError noSuchFieldError49) {}
        try {
            f2[EntityType.SKELETON.ordinal()] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError50) {}
        try {
            f2[EntityType.SLIME.ordinal()] = 31;
        }
        catch (NoSuchFieldError noSuchFieldError51) {}
        try {
            f2[EntityType.SMALL_FIREBALL.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError52) {}
        try {
            f2[EntityType.SNOWBALL.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError53) {}
        try {
            f2[EntityType.SNOWMAN.ordinal()] = 52;
        }
        catch (NoSuchFieldError noSuchFieldError54) {}
        try {
            f2[EntityType.SPIDER.ordinal()] = 28;
        }
        catch (NoSuchFieldError noSuchFieldError55) {}
        try {
            f2[EntityType.SPLASH_POTION.ordinal()] = 59;
        }
        catch (NoSuchFieldError noSuchFieldError56) {}
        try {
            f2[EntityType.SQUID.ordinal()] = 49;
        }
        catch (NoSuchFieldError noSuchFieldError57) {}
        try {
            f2[EntityType.THROWN_EXP_BOTTLE.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError58) {}
        try {
            f2[EntityType.UNKNOWN.ordinal()] = 66;
        }
        catch (NoSuchFieldError noSuchFieldError59) {}
        try {
            f2[EntityType.VILLAGER.ordinal()] = 57;
        }
        catch (NoSuchFieldError noSuchFieldError60) {}
        try {
            f2[EntityType.WEATHER.ordinal()] = 63;
        }
        catch (NoSuchFieldError noSuchFieldError61) {}
        try {
            f2[EntityType.WITCH.ordinal()] = 42;
        }
        catch (NoSuchFieldError noSuchFieldError62) {}
        try {
            f2[EntityType.WITHER.ordinal()] = 40;
        }
        catch (NoSuchFieldError noSuchFieldError63) {}
        try {
            f2[EntityType.WITHER_SKULL.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError64) {}
        try {
            f2[EntityType.WOLF.ordinal()] = 50;
        }
        catch (NoSuchFieldError noSuchFieldError65) {}
        try {
            f2[EntityType.ZOMBIE.ordinal()] = 30;
        }
        catch (NoSuchFieldError noSuchFieldError66) {}
        return aG.f = f2;
    }
}
