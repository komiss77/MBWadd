// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

public abstract class j
{
    public abstract String d();
    
    public a a() {
        final String name = this.getClass().getPackage().getName();
        return a.valueOf(String.valueOf(name.split("\\.")[name.split("\\.").length - 1].toUpperCase()) + "_" + this.getClass().getName());
    }
    
    public void a(final f f) {
        h.b(new i(this, f));
    }
    
    public void c(final i i) {
        h.b(i);
    }
    
    public enum a
    {
        a("IN_PacketChannelEnabled", 0, 0), 
        b("IN_PacketArenaExistsAnswer", 1, 1), 
        c("IN_PacketConnectPlayer", 2, 2), 
        d("IN_PacketArenasList", 3, 3), 
        e("OUT_PacketChannelExists", 4, 4), 
        f("OUT_PacketArenaCreate", 5, 5), 
        g("OUT_PacketArenaRemove", 6, 6), 
        h("OUT_PacketArenaUpdateSlots", 7, 7), 
        i("OUT_PacketArenaUpdateMaxSlots", 8, 8), 
        j("OUT_PacketArenaUpdateStatus", 9, 9), 
        k("OUT_PacketArenaUpdateName", 10, 10), 
        l("OUT_PacketArenaUpdateIcon", 11, 11), 
        m("OUT_PacketArenaExists", 12, 12), 
        n("OUT_PacketArenaUpdateMadeBy", 13, 13), 
        o("OUT_PacketArenaUpdateTeamPlayers", 14, 14);
        
        private int b;
        
        static {
            a = new a[] { de.marcely.bedwars.j.a.a, de.marcely.bedwars.j.a.b, de.marcely.bedwars.j.a.c, de.marcely.bedwars.j.a.d, de.marcely.bedwars.j.a.e, de.marcely.bedwars.j.a.f, de.marcely.bedwars.j.a.g, de.marcely.bedwars.j.a.h, de.marcely.bedwars.j.a.i, de.marcely.bedwars.j.a.j, de.marcely.bedwars.j.a.k, de.marcely.bedwars.j.a.l, de.marcely.bedwars.j.a.m, de.marcely.bedwars.j.a.n, de.marcely.bedwars.j.a.o };
        }
        
        private a(final String name, final int ordinal, final int b) {
            this.b = b;
        }
        
        public int getID() {
            return this.b;
        }
        
        public static a a(final int n) {
            a[] values;
            for (int length = (values = values()).length, i = 0; i < length; ++i) {
                final a a = values[i];
                if (a.getID() == n) {
                    return a;
                }
            }
            return null;
        }
    }
}
