// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import net.minecraft.util.io.netty.channel.ChannelPipeline;
import java.lang.reflect.InvocationTargetException;
import net.minecraft.util.io.netty.channel.ChannelHandler;
import java.util.Iterator;
import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.util.io.netty.channel.ChannelHandlerContext;
import net.minecraft.util.io.netty.handler.codec.MessageToMessageDecoder;
import net.minecraft.util.io.netty.channel.Channel;
import de.marcely.bedwars.versions.NMSClass;

@Deprecated
public class ab implements aa.b
{
    @Override
    public void a(final aa.c c) {
        try {
            final Object cast = NMSClass.m.cast(c.player);
            final Object invoke = cast.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(cast, new Object[0]);
            final Object value = invoke.getClass().getDeclaredField("playerConnection").get(invoke);
            final Object value2 = value.getClass().getDeclaredField("networkManager").get(value);
            final Field declaredField = value2.getClass().getDeclaredField("m");
            declaredField.setAccessible(true);
            final ChannelPipeline pipeline = ((Channel)declaredField.get(value2)).pipeline();
            final MessageToMessageDecoder<Object> e = new MessageToMessageDecoder<Object>() {
                protected void decode(final ChannelHandlerContext channelHandlerContext, final Object o, final List<Object> list) throws Exception {
                    try {
                        if (NMSClass.H.isInstance(o)) {
                            final Field declaredField = NMSClass.H.getDeclaredField("a");
                            declaredField.setAccessible(true);
                            final int int1 = declaredField.getInt(o);
                            for (final aa aa : c.u) {
                                if (aa.getEntityId() == int1) {
                                    final Field declaredField2 = NMSClass.H.getDeclaredField("action");
                                    declaredField2.setAccessible(true);
                                    final Object value = declaredField2.get(o);
                                    final String s = (String)value.getClass().getMethod("name", (Class<?>[])new Class[0]).invoke(value, new Object[0]);
                                    if (s.equals("INTERACT")) {
                                        final Iterator<aa.a> iterator2 = aa.i().iterator();
                                        while (iterator2.hasNext()) {
                                            iterator2.next().g(c.player);
                                        }
                                    }
                                    else {
                                        if (!s.equals("ATTACK")) {
                                            continue;
                                        }
                                        final Iterator<aa.a> iterator3 = aa.i().iterator();
                                        while (iterator3.hasNext()) {
                                            iterator3.next().h(c.player);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    list.add(o);
                }
            };
            try {
                pipeline.addAfter("decoder", "MBedwars_IM", (ChannelHandler)e);
            }
            catch (IllegalArgumentException ex) {
                pipeline.remove(pipeline.get("MBedwars_IM"));
                pipeline.addAfter("decoder", "MBedwars_IM", (ChannelHandler)e);
            }
            c.d = pipeline;
            c.e = e;
        }
        catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | SecurityException | NoSuchFieldException ex2) {
            final Throwable t;
            t.printStackTrace();
        }
    }
}
