// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import org.bukkit.Location;
import java.util.Iterator;
import de.marcely.bedwars.game.Team;
import de.marcely.bedwars.game.DropType;
import java.util.Collection;
import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import de.marcely.bedwars.api.VarParticle;
import de.marcely.bedwars.game.arena.RegenerationType;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.command.CommandSender;
import de.marcely.bedwars.achievements.Achievement;
import de.marcely.bedwars.util.b;
import org.bukkit.event.Event;
import de.marcely.bedwars.api.event.PlayerKillPlayerEvent;
import org.bukkit.Bukkit;
import java.util.concurrent.ExecutionException;
import org.bukkit.entity.Player;
import de.marcely.bedwars.game.arena.Arena;
import java.util.concurrent.Future;
import de.marcely.bedwars.game.stats.c;
import de.marcely.bedwars.game.arena.ArenaStatus;
import de.marcely.bedwars.config.ConfigValue;
import de.marcely.bedwars.util.s;
import org.bukkit.event.entity.PlayerDeathEvent;

public class aR
{
    private static /* synthetic */ int[] g;
    
    public static void a(final PlayerDeathEvent playerDeathEvent) {
        final Player entity = playerDeathEvent.getEntity();
        final Arena a = s.a(entity);
        if (ConfigValue.deathmessage_remove) {
            playerDeathEvent.setDeathMessage("");
        }
        if (a != null && a.b() == ArenaStatus.f) {
            final Player player = entity;
            final aD.a a2 = aD.f.get(player);
            final Player player2 = (a2 != null) ? a2.damager : null;
            if (ConfigValue.no_drops) {
                entity.getInventory().clear();
            }
            final Future<c> a3 = c.a(player);
            s.a((Future<Object>)a3, new Runnable() {
                @Override
                public void run() {
                    try {
                        final c c = a3.get();
                        c.setDeaths(c.getDeaths() + 1);
                        c.save();
                        a.a.s(player);
                    }
                    catch (InterruptedException | ExecutionException ex) {
                        final Throwable t;
                        t.printStackTrace();
                    }
                }
            });
            if (!ConfigValue.deathmessage_remove && ConfigValue.deathmessage_custom_enabled) {
                de.marcely.bedwars.message.b b = null;
                if (a2 != null && player2 != null) {
                    if (a != null && entity.getLastDamageCause() != null) {
                        final Team a4 = a.a(player);
                        final Team a5 = a.a(player2);
                        if (a5 == null) {
                            return;
                        }
                        if (!ConfigValue.stats_count_deaths_beforebedbroken || (a.a().d(a.a(player)) && ConfigValue.stats_count_deaths_beforebedbroken)) {
                            final Future<c> a6 = c.a(player2);
                            s.a((Future<Object>)a6, new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        final c c = a6.get();
                                        c.setKills(c.getKills() + 1);
                                        c.save();
                                        a.a.s(player2);
                                    }
                                    catch (InterruptedException | ExecutionException ex) {
                                        final Throwable t;
                                        t.printStackTrace();
                                    }
                                }
                            });
                        }
                        Bukkit.getPluginManager().callEvent((Event)new PlayerKillPlayerEvent(a, player2, player, a2.cause, a2.proj));
                        if (de.marcely.bedwars.util.b.a(player2) == 1.0) {
                            s.a(player2, Achievement.l);
                        }
                        final String s = de.marcely.bedwars.util.s.a(ConfigValue.deathmessage_custom_killed);
                        if (s != null) {
                            b = de.marcely.bedwars.message.b.a(s).c().a("player", de.marcely.bedwars.util.s.getPlayerDisplayName(player)).a("team", a4.a((CommandSender)null, true)).a("teamcolor", new StringBuilder().append(a4.getChatColor()).toString()).a("killer", de.marcely.bedwars.util.s.getPlayerDisplayName(player2)).a("killerteam", a5.a((CommandSender)null, true)).a("killerteamcolor", new StringBuilder().append(a5.getChatColor()).toString()).a("heartpercent", new StringBuilder().append((int)(de.marcely.bedwars.util.b.a(player2) / 20.0 * 100.0)).toString());
                        }
                        final Iterator<dg> iterator = de.marcely.bedwars.util.s.b.a(dg.class).iterator();
                        while (iterator.hasNext()) {
                            iterator.next().a(player2, df.d);
                        }
                    }
                }
                else if (entity.getLastDamageCause() != null) {
                    String s2 = null;
                    switch (g()[entity.getLastDamageCause().getCause().ordinal()]) {
                        case 13: {
                            s2 = s.a(ConfigValue.deathmessage_custom_void);
                            break;
                        }
                        case 11:
                        case 12: {
                            s2 = s.a(ConfigValue.deathmessage_custom_explosion);
                            break;
                        }
                        case 5: {
                            s2 = s.a(ConfigValue.deathmessage_custom_fall);
                            break;
                        }
                        case 6:
                        case 7: {
                            s2 = s.a(ConfigValue.deathmessage_custom_fire);
                            break;
                        }
                        default: {
                            s2 = s.a(ConfigValue.deathmessage_custom_default);
                            break;
                        }
                    }
                    if (s2 != null) {
                        final Team a7 = a.a(player);
                        b = de.marcely.bedwars.message.b.a(s2).c().a("player", s.getPlayerDisplayName(player)).a("team", a7.a((CommandSender)null, true)).a("teamcolor", new StringBuilder().append(a7.getChatColor()).toString());
                    }
                }
                if (b != null) {
                    playerDeathEvent.setDeathMessage("");
                    if (ConfigValue.deathmessage_private) {
                        a.a(b);
                    }
                    else {
                        final Iterator iterator2 = Bukkit.getOnlinePlayers().iterator();
                        while (iterator2.hasNext()) {
                            s.a((CommandSender)iterator2.next(), b, false);
                        }
                        b.X();
                    }
                }
            }
            aD.f.remove(entity);
        }
        final Location location = entity.getLocation().getBlock().getLocation();
        if (a != null) {
            if (ConfigValue.particles_ondeath && entity.getLastDamageCause() != null && entity.getLastDamageCause().getCause() == EntityDamageEvent.DamageCause.VOID) {
                int n = a.getWorld().getMaxHeight() / 2;
                if (a.a() == RegenerationType.c) {
                    n = (int)a.getPosMax().getX();
                }
                for (int i = location.getBlockY(); i < n; ++i) {
                    location.setY((double)i);
                    VarParticle.PARTICLE_CLOUD.play(a.getWorld(), location, 5);
                    Sound.PLAYERDEATH_EFFECT.play(location);
                }
            }
            if (ConfigValue.drop_only_itemspawner) {
                for (final ItemStack itemStack : new ArrayList<ItemStack>(playerDeathEvent.getDrops())) {
                    if (DropType.a(itemStack) == null) {
                        playerDeathEvent.getDrops().remove(itemStack);
                    }
                }
            }
            else if (ConfigValue.no_drops) {
                playerDeathEvent.getDrops().clear();
            }
        }
    }
    
    static /* synthetic */ int[] g() {
        final int[] g = aR.g;
        if (g != null) {
            return g;
        }
        final int[] g2 = new int[EntityDamageEvent.DamageCause.values().length];
        try {
            g2[EntityDamageEvent.DamageCause.BLOCK_EXPLOSION.ordinal()] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            g2[EntityDamageEvent.DamageCause.CONTACT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            g2[EntityDamageEvent.DamageCause.CUSTOM.ordinal()] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            g2[EntityDamageEvent.DamageCause.DROWNING.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            g2[EntityDamageEvent.DamageCause.ENTITY_ATTACK.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            g2[EntityDamageEvent.DamageCause.ENTITY_EXPLOSION.ordinal()] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
        try {
            g2[EntityDamageEvent.DamageCause.FALL.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError7) {}
        try {
            g2[EntityDamageEvent.DamageCause.FALLING_BLOCK.ordinal()] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError8) {}
        try {
            g2[EntityDamageEvent.DamageCause.FIRE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError9) {}
        try {
            g2[EntityDamageEvent.DamageCause.FIRE_TICK.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError10) {}
        try {
            g2[EntityDamageEvent.DamageCause.LAVA.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError11) {}
        try {
            g2[EntityDamageEvent.DamageCause.LIGHTNING.ordinal()] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError12) {}
        try {
            g2[EntityDamageEvent.DamageCause.MAGIC.ordinal()] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError13) {}
        try {
            g2[EntityDamageEvent.DamageCause.MELTING.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError14) {}
        try {
            g2[EntityDamageEvent.DamageCause.POISON.ordinal()] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError15) {}
        try {
            g2[EntityDamageEvent.DamageCause.PROJECTILE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError16) {}
        try {
            g2[EntityDamageEvent.DamageCause.STARVATION.ordinal()] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError17) {}
        try {
            g2[EntityDamageEvent.DamageCause.SUFFOCATION.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError18) {}
        try {
            g2[EntityDamageEvent.DamageCause.SUICIDE.ordinal()] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError19) {}
        try {
            g2[EntityDamageEvent.DamageCause.THORNS.ordinal()] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError20) {}
        try {
            g2[EntityDamageEvent.DamageCause.VOID.ordinal()] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError21) {}
        try {
            g2[EntityDamageEvent.DamageCause.WITHER.ordinal()] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError22) {}
        return aR.g = g2;
    }
}
