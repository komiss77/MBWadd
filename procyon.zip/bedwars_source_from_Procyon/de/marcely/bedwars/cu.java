// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.bedwars;

import de.marcely.bedwars.api.Util;
import de.marcely.bedwars.game.stats.c;

public class cu extends ct
{
    public static cu a;
    
    static {
        cu.a = new cu();
    }
    
    public String b(final c c) {
        return Util.millisToName(c.getPlayTime());
    }
}
