// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import de.marcely.configmanager2.objects.Tree;
import java.io.File;

public class ConfigFile
{
    public static final String VERSION = "2.1";
    public boolean getConfigNeverNull;
    private final File file;
    private final FileHandler fileHandler;
    private final ConfigPicker picker;
    private final Tree rootTree;
    
    public ConfigFile(final File file) {
        this(file, false);
    }
    
    public ConfigFile(final File file, final boolean getConfigNeverNull) {
        this.getConfigNeverNull = false;
        this.rootTree = new Tree(this);
        this.file = file;
        this.fileHandler = new FileHandler(this);
        this.picker = new ConfigPicker(this);
        this.getConfigNeverNull = getConfigNeverNull;
    }
    
    public void clear() {
        this.rootTree.clear();
        this.picker.getAllConfigs().clear();
    }
    
    public int load() {
        return this.fileHandler.load();
    }
    
    public int save() {
        return this.fileHandler.save();
    }
    
    public boolean exists() {
        return this.file.exists();
    }
    
    public File getFile() {
        return this.file;
    }
    
    public ConfigPicker getPicker() {
        return this.picker;
    }
    
    public Tree getRootTree() {
        return this.rootTree;
    }
}
