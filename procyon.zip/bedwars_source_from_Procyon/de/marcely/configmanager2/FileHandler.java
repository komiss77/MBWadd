// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;
import de.marcely.configmanager2.objects.Tree;
import de.marcely.configmanager2.objects.Description;
import de.marcely.configmanager2.objects.Comment;
import de.marcely.configmanager2.objects.Config;
import de.marcely.configmanager2.objects.EmptyLine;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.io.FileInputStream;

public class FileHandler
{
    private final ConfigFile file;
    
    public FileHandler(final ConfigFile file) {
        this.file = file;
    }
    
    public int load() {
        final File file = this.file.getFile();
        if (!file.exists()) {
            return 2;
        }
        if (!file.canRead()) {
            return 3;
        }
        this.file.getRootTree().clear();
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            Tree tree = this.file.getRootTree();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                final String replaceFirstSpaces = this.replaceFirstSpaces(line);
                if (replaceFirstSpaces.length() == 0) {
                    tree.addChild(new EmptyLine(tree));
                }
                else {
                    final char char1 = replaceFirstSpaces.charAt(0);
                    final char char2 = replaceFirstSpaces.charAt(replaceFirstSpaces.length() - 1);
                    boolean b = false;
                    if (char1 == '#') {
                        tree.addChild(new Comment(tree, this.replaceFirstSpaces(replaceFirstSpaces.substring(1))));
                    }
                    else if (replaceFirstSpaces.contains(":")) {
                        final String[] split = replaceFirstSpaces.split(":");
                        String s = "";
                        for (int i = 1; i < split.length; ++i) {
                            s = String.valueOf(s) + split[i];
                            if (i + 1 < split.length) {
                                s = String.valueOf(s) + ":";
                            }
                        }
                        if (!replaceFirstSpaces.startsWith("!")) {
                            tree.addChild(new Config(this.replaceLastSpaces(split[0]), tree, this.replaceFirstSpaces(s)));
                        }
                        else {
                            tree.addChild(new Description(tree, this.replaceLastSpaces(split[0]).substring(1), this.replaceFirstSpaces(s)));
                        }
                    }
                    else if (char2 == '{') {
                        tree = new Tree(this.replaceLastSpaces(replaceFirstSpaces.substring(0, replaceFirstSpaces.length() - 1)), tree);
                        tree.getParent().addChild(tree);
                        b = true;
                    }
                    else if (this.replaceLastSpaces(replaceFirstSpaces).equals("}")) {
                        tree = tree.getParent();
                        b = true;
                        if (tree == null) {
                            bufferedReader.close();
                            return 4;
                        }
                    }
                    else {
                        tree.addChild(new EmptyLine(tree));
                    }
                    if (b) {
                        continue;
                    }
                    tree.getRawChilds().add(this.replaceLastSpaces(replaceFirstSpaces));
                }
            }
            bufferedReader.close();
            if (!tree.equals(this.file.getRootTree())) {
                return 4;
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return 1;
        }
        return 0;
    }
    
    public int save() {
        final File file = this.file.getFile();
        if (file.exists() && !file.canWrite()) {
            return 2;
        }
        try {
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            if (!file.canWrite()) {
                return 2;
            }
            final BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
            final Iterator<String> iterator = this.getLines(this.file.getRootTree(), "").iterator();
            while (iterator.hasNext()) {
                bufferedWriter.write(iterator.next());
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return 1;
        }
        return 0;
    }
    
    private List<String> getLines(final Tree tree, final String s) {
        return this.getLines(tree, s, tree.equals(this.file.getRootTree()));
    }
    
    private List<String> getLines(final Tree tree, final String obj, final boolean b) {
        final ArrayList<String> list = new ArrayList<String>();
        for (final Config config : tree.getChilds()) {
            if (config.getType() == 0) {
                list.add(String.valueOf(obj) + config.getName() + " {");
                list.addAll((Collection<?>)this.getLines((Tree)config, String.valueOf(obj) + "\t", false));
                list.add(String.valueOf(obj) + "}");
            }
            else if (config.getType() == 2) {
                list.add(String.valueOf(obj) + "# " + config.getValue());
            }
            else if (config.getType() == 3) {
                list.add("");
            }
            else if (config.getType() == 4) {
                list.add(String.valueOf(obj) + "!" + config.getName() + ": " + config.getValue());
            }
            else if (config.getType() == 5) {
                list.add(String.valueOf(obj) + config.getValue());
            }
            else {
                list.add(String.valueOf(obj) + config.getName() + ": " + config.getValue());
            }
        }
        return list;
    }
    
    private String replaceFirstSpaces(String substring) {
        while (substring.startsWith(" ") || substring.startsWith("\t")) {
            substring = substring.substring(1, substring.length());
        }
        return substring;
    }
    
    private String replaceLastSpaces(String substring) {
        while (substring.endsWith(" ") || substring.endsWith("\t")) {
            substring = substring.substring(0, substring.length() - 1);
        }
        return substring;
    }
    
    public ConfigFile getFile() {
        return this.file;
    }
}
