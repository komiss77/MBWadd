// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

import javax.annotation.Nullable;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import de.marcely.configmanager2.ConfigFile;

public class Tree extends Config
{
    private final ConfigFile file;
    private final List<Config> childs;
    private final List<String> rawChilds;
    
    public Tree(final String s, final Tree tree) {
        super(s, tree);
        this.childs = new ArrayList<Config>();
        this.rawChilds = new ArrayList<String>();
        this.file = null;
    }
    
    public Tree(final ConfigFile file) {
        super("", null);
        this.childs = new ArrayList<Config>();
        this.rawChilds = new ArrayList<String>();
        this.file = file;
    }
    
    @Override
    public byte getType() {
        return 0;
    }
    
    public void addChild(final Config config) {
        this.childs.add(config);
        if (config.getType() == 1 && this.isInsideRoot()) {
            this.getConfigFile().getPicker().getAllConfigs().add(config);
        }
    }
    
    public List<Tree> getTreeChilds() {
        final ArrayList<Tree> list = new ArrayList<Tree>();
        for (final Config config : this.childs) {
            if (config.getType() == 0) {
                list.add((Tree)config);
            }
        }
        return list;
    }
    
    @Nullable
    public Tree getTreeChild(final String anObject) {
        for (final Tree tree : this.getTreeChilds()) {
            if (tree.getName().equals(anObject)) {
                return tree;
            }
        }
        return null;
    }
    
    public List<Config> getConfigChilds() {
        final ArrayList<Config> list = new ArrayList<Config>();
        for (final Config config : this.childs) {
            if (config.getType() == 1) {
                list.add(config);
            }
        }
        return list;
    }
    
    @Nullable
    public Config getConfigChild(final String anObject) {
        for (final Config config : this.getConfigChilds()) {
            if (config.getType() == 1 && config.getName() != null && config.getName().equals(anObject)) {
                return config;
            }
        }
        return null;
    }
    
    public List<Config> getConfigChilds(final String anObject) {
        final ArrayList<Config> list = new ArrayList<Config>();
        for (final Config config : this.getConfigChilds()) {
            if (config.getType() == 1 && config.getName() != null && config.getName().equals(anObject)) {
                list.add(config);
            }
        }
        return list;
    }
    
    public Config addConfigChild(final String s, final String s2) {
        final Config config = new Config(s, this, s2);
        this.addChild(config);
        return config;
    }
    
    @Deprecated
    public List<ListItem> getListItems() {
        final ArrayList<ListItem> list = new ArrayList<ListItem>();
        for (final Config config : this.getConfigChilds()) {
            if (config.getType() == 5) {
                list.add((ListItem)config);
            }
        }
        return list;
    }
    
    public void clear() {
        this.childs.clear();
    }
    
    public boolean isRoot() {
        return this.file != null;
    }
    
    public boolean isInsideRoot() {
        return this.isRoot() || this.getParent().isInsideRoot();
    }
    
    @Nullable
    public ConfigFile getConfigFile() {
        if (this.isInsideRoot()) {
            return this.isRoot() ? this.file : this.getParent().getConfigFile();
        }
        return null;
    }
    
    public List<Config> getChilds() {
        return this.childs;
    }
    
    public List<String> getRawChilds() {
        return this.rawChilds;
    }
}
