// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

public class Description extends Config
{
    private final boolean base;
    
    public Description(final Tree tree, final String s, final String s2) {
        this(tree, s, s2, false);
    }
    
    public Description(final Tree tree, final String s, final String s2, final boolean base) {
        super(s, tree, s2);
        this.base = base;
    }
    
    @Override
    public byte getType() {
        return 4;
    }
    
    public boolean isBase() {
        return this.base;
    }
}
