// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class ListItem extends Config
{
    public ListItem(final String s, final Tree tree) {
        super(null, tree, s);
    }
    
    @Override
    public byte getType() {
        return 5;
    }
    
    public static List<String> valuesToString1(final List<ListItem> list) {
        final ArrayList<String> list2 = new ArrayList<String>();
        final Iterator<ListItem> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(iterator.next().value);
        }
        return list2;
    }
}
