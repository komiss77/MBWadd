// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

public class EmptyLine extends Config
{
    public EmptyLine(final Tree tree) {
        super(null, tree, null);
    }
    
    @Override
    public byte getType() {
        return 3;
    }
}
