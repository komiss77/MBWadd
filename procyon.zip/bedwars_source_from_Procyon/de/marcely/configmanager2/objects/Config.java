// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public class Config
{
    public static final byte TYPE_TREE = 0;
    public static final byte TYPE_CONFIG = 1;
    public static final byte TYPE_COMMENT = 2;
    public static final byte TYPE_EMPTYLINE = 3;
    public static final byte TYPE_DESCRIPTION = 4;
    public static final byte TYPE_LISTITEM = 5;
    private final String name;
    private final Tree parent;
    String value;
    
    public Config(final String s, final Tree tree) {
        this(s, tree, null);
    }
    
    public Config(final String name, final Tree parent, final String value) {
        this.name = name;
        this.parent = parent;
        this.value = value;
    }
    
    public byte getType() {
        return 1;
    }
    
    public String getAbsolutePath() {
        return (this.parent != null) ? (String.valueOf(this.parent.getAbsolutePath()) + (this.parent.getAbsolutePath().isEmpty() ? "" : ".") + this.name) : "";
    }
    
    @Nullable
    private static Boolean getBoolean(final String s) {
        return Boolean.valueOf(s);
    }
    
    public static List<String> valuesToString(final List<Config> list) {
        final ArrayList<String> list2 = new ArrayList<String>();
        final Iterator<Config> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(iterator.next().value);
        }
        return list2;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Tree getParent() {
        return this.parent;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public void setValue(final String value) {
        this.value = value;
    }
}
