// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2.objects;

public class Comment extends Config
{
    public Comment(final Tree tree, final String s) {
        super(null, tree, s);
    }
    
    @Override
    public byte getType() {
        return 2;
    }
}
