// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import de.marcely.configmanager2.objects.Description;
import java.util.Iterator;
import de.marcely.configmanager2.objects.ListItem;
import de.marcely.configmanager2.objects.Tree;
import java.util.List;
import de.marcely.bedwars.util.s;
import javax.annotation.Nullable;
import de.marcely.configmanager2.objects.Config;
import org.bukkit.plugin.Plugin;
import java.io.IOException;
import java.io.File;

public class ConfigManager extends ConfigFile
{
    public ConfigManager(final File file) {
        this(file, true);
    }
    
    public ConfigManager(final File file, final boolean b) {
        super(file);
        final File parentFile = this.getFile().getParentFile();
        if (!parentFile.exists()) {
            parentFile.mkdirs();
        }
        if (b && !this.getFile().exists()) {
            try {
                this.getFile().createNewFile();
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public ConfigManager(final Plugin plugin, final String s) {
        this(plugin.getName(), s);
    }
    
    public ConfigManager(final String str, final String str2) {
        this(new File("plugins/" + str + "/" + str2));
    }
    
    public ConfigManager(final Plugin plugin, final String s, final boolean b) {
        this(plugin.getName(), s, b);
    }
    
    public ConfigManager(final String str, final String str2, final boolean b) {
        this(new File("plugins/" + str + "/" + str2));
    }
    
    public void addConfig(final String s, final Object o) {
        this.getPicker().addConfig(s, o);
    }
    
    public void addComment(final String s) {
        this.getPicker().addComment(s);
    }
    
    public void addComment(final String s, final String s2) {
        this.getPicker().addComment(s2, s);
    }
    
    @Nullable
    public String getConfigString(final String s) {
        final Config config = this.getPicker().getConfig(s);
        if (config != null) {
            return config.getValue();
        }
        return null;
    }
    
    @Nullable
    public Boolean getConfigBoolean(final String s) {
        final String configString = this.getConfigString(s);
        if (configString != null && (configString.equalsIgnoreCase("true") || configString.equalsIgnoreCase("false"))) {
            return Boolean.valueOf(configString);
        }
        return null;
    }
    
    @Nullable
    public Double getConfigDouble(final String s) {
        final String configString = this.getConfigString(s);
        if (configString != null && s.isDouble(configString)) {
            return Double.valueOf(configString);
        }
        return null;
    }
    
    @Nullable
    public Integer getConfigInt(final String s) {
        final String configString = this.getConfigString(s);
        if (configString != null && s.isInteger(configString)) {
            return Integer.valueOf(configString);
        }
        return null;
    }
    
    @Nullable
    public Long getConfigLong(final String s) {
        final String configString = this.getConfigString(s);
        if (configString != null && s.isLong(configString)) {
            return Long.valueOf(configString);
        }
        return null;
    }
    
    public void addEmptyLine() {
        this.getPicker().addEmptyLine();
    }
    
    public void addEmptyLine(final String s) {
        this.getPicker().addEmptyLine(s);
    }
    
    public List<Config> getConfigsWhichStartWith(final String s) {
        return this.getPicker().getConfigsWhichStartWith(s);
    }
    
    public List<Config> getConfigsWhichEndWith(final String s) {
        return this.getPicker().getConfigsWhichEndWith(s);
    }
    
    public List<Config> getConfigs(final String s) {
        return this.getPicker().getConfigs(s);
    }
    
    @Nullable
    public List<String> getListItems(final String s) {
        final Tree tree = this.getPicker().getTree(s, false);
        if (tree != null) {
            return tree.getRawChilds();
        }
        return null;
    }
    
    public void addListItems(final List<String> list, final String s) {
        final Tree tree = this.getPicker().getTree(s, true);
        for (final String s2 : list) {
            tree.addChild(new ListItem(s2, tree));
            tree.getRawChilds().add(s2);
        }
    }
    
    @Nullable
    public String getDescription(final String s) {
        final Description description = this.getPicker().getDescription(s);
        return (description != null) ? description.getValue() : null;
    }
    
    public void addDescription(final String s, final String s2) {
        this.getPicker().setDescription(s, s2);
    }
}
