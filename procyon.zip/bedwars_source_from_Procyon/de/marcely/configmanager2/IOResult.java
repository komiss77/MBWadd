// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

public class IOResult
{
    public static final int RESULT_SUCCESS = 0;
    public static final int RESULT_FAILED_UNKOWN = 1;
    public static final int RESULT_FAILED_LOAD_MISSINGFILE = 2;
    public static final int RESULT_FAILED_LOAD_NOPERMS = 3;
    public static final int RESULT_FAILED_LOAD_NOTVALID = 4;
    public static final int RESULT_FAILED_SAVE_NOPERMS = 2;
}
