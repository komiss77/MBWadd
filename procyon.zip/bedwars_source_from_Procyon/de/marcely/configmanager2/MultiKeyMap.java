// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import java.util.AbstractMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class MultiKeyMap<obj1, obj2>
{
    final List<obj1> l1;
    final List<obj2> l2;
    
    public MultiKeyMap() {
        this.l1 = new ArrayList<obj1>();
        this.l2 = new ArrayList<obj2>();
    }
    
    public MultiKeyMap(final MultiKeyMap<obj1, obj2> multiKeyMap) {
        this.l1 = new ArrayList<obj1>((Collection<? extends obj1>)multiKeyMap.l1);
        this.l2 = new ArrayList<obj2>((Collection<? extends obj2>)multiKeyMap.l2);
    }
    
    public int size() {
        return this.l1.size();
    }
    
    public void put(final obj1 obj1, final obj2 obj2) {
        this.l1.add(obj1);
        this.l2.add(obj2);
    }
    
    public obj2 getFirst(final obj1 obj1) {
        if (this.get(obj1).size() >= 1) {
            return this.get(obj1).get(0);
        }
        return null;
    }
    
    public List<obj2> get(final obj1 obj1) {
        final ArrayList<obj2> list = new ArrayList<obj2>();
        int n = 0;
        final Iterator<obj1> iterator = this.l1.iterator();
        while (iterator.hasNext()) {
            if (obj1.equals(iterator.next())) {
                list.add(this.l2.get(n));
            }
            ++n;
        }
        return list;
    }
    
    public List<Map.Entry<obj1, obj2>> entrySet() {
        final ArrayList<AbstractMap.SimpleEntry<Object, obj2>> list = (ArrayList<AbstractMap.SimpleEntry<Object, obj2>>)new ArrayList<Map.Entry<Object, obj2>>();
        int n = 0;
        final Iterator<obj1> iterator = new ArrayList<obj1>((Collection<? extends obj1>)this.l1).iterator();
        while (iterator.hasNext()) {
            list.add(new AbstractMap.SimpleEntry<Object, obj2>(iterator.next(), this.l2.get(n)));
            ++n;
        }
        return (List<Map.Entry<obj1, obj2>>)list;
    }
    
    public void remove(final obj1 obj) {
        int n = 0;
        final Iterator<obj1> iterator = this.l1.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().equals(obj)) {
                this.l1.remove(n);
                this.l2.remove(n);
            }
            ++n;
        }
    }
    
    public void remove(final obj1 obj, final obj2 obj2) {
        int n = 0;
        final Iterator<Object> iterator = new ArrayList<Object>(this.l1).iterator();
        while (iterator.hasNext()) {
            if (iterator.next().equals(obj) && this.l2.get(n).equals(obj2)) {
                this.l1.remove(n);
                this.l2.remove(n);
                --n;
            }
            ++n;
        }
    }
    
    public boolean containsKey(final obj1 obj1) {
        return this.l1.contains(obj1);
    }
    
    public boolean containsValue(final obj2 obj2) {
        return this.l2.contains(obj2);
    }
    
    public void replace(final obj1 obj1, final obj2 obj2) {
        this.remove(obj1);
        this.put(obj1, obj2);
    }
    
    public List<obj1> keySet() {
        return new ArrayList<obj1>((Collection<? extends obj1>)this.l1);
    }
    
    public List<obj2> values() {
        return new ArrayList<obj2>((Collection<? extends obj2>)this.l2);
    }
    
    public boolean removeFirst() {
        if (this.size() >= 1) {
            this.l1.remove(0);
            this.l2.remove(0);
            return true;
        }
        return false;
    }
    
    public boolean removeLast() {
        if (this.size() >= 1) {
            this.l1.remove(this.l1.size() - 1);
            this.l2.remove(this.l2.size() - 2);
            return true;
        }
        return false;
    }
    
    public void clear() {
        this.l1.clear();
        this.l2.clear();
    }
}
