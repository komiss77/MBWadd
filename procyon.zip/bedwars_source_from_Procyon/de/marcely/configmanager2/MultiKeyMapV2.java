// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import java.util.Collection;
import java.util.AbstractMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;

public class MultiKeyMapV2<T1, T2> implements Map<T1, T2>
{
    private final Set<Entry<T1, T2>> entries;
    
    public MultiKeyMapV2() {
        this.entries = new HashSet<Entry<T1, T2>>();
    }
    
    @Override
    public int size() {
        return this.entries.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }
    
    @Override
    public boolean containsKey(final Object o) {
        return this.get(o) != null;
    }
    
    @Override
    public boolean containsValue(final Object obj) {
        final Iterator<Entry<T1, T2>> iterator = this.entries.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getValue().equals(obj)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public T2 get(final Object obj) {
        for (final Entry<T1, T2> entry : this.entries) {
            if (entry.getKey().equals(obj)) {
                return entry.getValue();
            }
        }
        return null;
    }
    
    @Override
    public T2 put(final T1 key, final T2 value) {
        this.entries.add(new AbstractMap.SimpleEntry<T1, T2>(key, value));
        return null;
    }
    
    @Override
    public T2 remove(final Object obj) {
        final Iterator<Entry<T1, T2>> iterator = this.entries.iterator();
        Entry<T1, T2> entry;
        while ((entry = iterator.next()) != null) {
            if (entry.getKey().equals(obj)) {
                iterator.remove();
                return entry.getValue();
            }
        }
        return null;
    }
    
    @Override
    public void putAll(final Map<? extends T1, ? extends T2> map) {
        this.entries.addAll((Collection<? extends Entry<T1, T2>>)map.entrySet());
    }
    
    @Override
    public void clear() {
        this.entries.clear();
    }
    
    @Override
    public Set<T1> keySet() {
        new Exception("Unsupported as too slow").printStackTrace();
        return null;
    }
    
    @Override
    public Collection<T2> values() {
        new Exception("Unsupported as too slow").printStackTrace();
        return null;
    }
    
    @Override
    public Set<Entry<T1, T2>> entrySet() {
        return this.entries;
    }
}
