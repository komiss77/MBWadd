// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.configmanager2;

import de.marcely.configmanager2.objects.Description;
import java.util.Iterator;
import javax.annotation.Nullable;
import de.marcely.configmanager2.objects.EmptyLine;
import de.marcely.configmanager2.objects.Comment;
import de.marcely.configmanager2.objects.Tree;
import java.util.ArrayList;
import de.marcely.configmanager2.objects.Config;
import java.util.List;

public class ConfigPicker
{
    private final ConfigFile file;
    private final List<Config> allConfigs;
    
    public ConfigPicker(final ConfigFile file) {
        this.allConfigs = new ArrayList<Config>();
        this.file = file;
    }
    
    public Config addConfig(final String s, final Object o) {
        return this.addConfig(s, o.toString());
    }
    
    public Config addConfig(final String s, final String s2) {
        final String[] split = s.split("\\.");
        final Tree tree = s.contains(".") ? this.getTree(s.substring(0, s.lastIndexOf(46)), true) : this.file.getRootTree();
        final Config config = new Config(split[split.length - 1], tree, s2);
        tree.addChild(config);
        this.allConfigs.add(config);
        return config;
    }
    
    public Comment addComment(final String s) {
        return this.addComment("", s);
    }
    
    public Comment addComment(final String s, final String s2) {
        final Tree tree = this.getTree(s, true);
        final Comment comment = new Comment(tree, s2);
        tree.addChild(comment);
        return comment;
    }
    
    public EmptyLine addEmptyLine() {
        return this.addEmptyLine("");
    }
    
    public EmptyLine addEmptyLine(final String s) {
        final Tree tree = this.getTree(s, true);
        final EmptyLine emptyLine = new EmptyLine(tree);
        tree.addChild(emptyLine);
        return emptyLine;
    }
    
    @Nullable
    public Config getConfig(final String s) {
        final Tree tree = this.getTree(s.contains("\\.") ? s.substring(0, s.lastIndexOf(46)) : "", false);
        if (tree != null) {
            final String[] split = s.split("\\.");
            return tree.getConfigChild(split[split.length - 1]);
        }
        return this.file.getConfigNeverNull ? new Config(null, null, null) : null;
    }
    
    public List<Config> getConfigsWhichStartWith(final String prefix) {
        final ArrayList<Config> list = new ArrayList<Config>();
        for (final Config config : this.allConfigs) {
            if (config.getAbsolutePath().startsWith(prefix)) {
                list.add(config);
            }
        }
        return list;
    }
    
    public List<Config> getConfigsWhichEndWith(final String suffix) {
        final ArrayList<Config> list = new ArrayList<Config>();
        for (final Config config : this.allConfigs) {
            if (config.getAbsolutePath().endsWith(suffix)) {
                list.add(config);
            }
        }
        return list;
    }
    
    public List<Config> getConfigs(final String anObject) {
        final ArrayList<Config> list = new ArrayList<Config>();
        for (final Config config : this.allConfigs) {
            if (config.getAbsolutePath().equals(anObject)) {
                list.add(config);
            }
        }
        return list;
    }
    
    public Description setDescription(final String s, final String value) {
        if (!this.containsBase()) {
            this.file.getRootTree().getChilds().add(0, new EmptyLine(this.file.getRootTree()));
        }
        Description description = this.getDescription(s);
        if (description == null) {
            description = new Description(this.file.getRootTree(), s, value);
        }
        else {
            description.setValue(value);
        }
        this.file.getRootTree().getChilds().add(0, description);
        return description;
    }
    
    @Nullable
    public Description getDescription(final String anObject) {
        for (final Config config : this.file.getRootTree().getChilds()) {
            if (config.getName() != null && config.getName().equals(anObject) && config.getType() == 4) {
                return (Description)config;
            }
        }
        return null;
    }
    
    public boolean containsBase() {
        for (final Config config : this.file.getRootTree().getChilds()) {
            if (config.getType() == 4 && ((Description)config).isBase()) {
                return true;
            }
        }
        return false;
    }
    
    @Nullable
    public Tree getTree(final String s, final boolean b) {
        if (s.equals("")) {
            return this.file.getRootTree();
        }
        final String[] split = s.split("\\.");
        int i = 0;
        String s2 = "";
        Tree rootTree = this.file.getRootTree();
        while (i < split.length) {
            if (!s2.equals("")) {
                s2 = String.valueOf(s2) + ".";
            }
            s2 = String.valueOf(s2) + split[i];
            Tree treeChild = rootTree.getTreeChild(split[i]);
            if (treeChild == null) {
                if (!b) {
                    return null;
                }
                treeChild = new Tree(split[i], rootTree);
                rootTree.addChild(treeChild);
            }
            rootTree = treeChild;
            ++i;
        }
        return rootTree;
    }
    
    public ConfigFile getFile() {
        return this.file;
    }
    
    public List<Config> getAllConfigs() {
        return this.allConfigs;
    }
}
