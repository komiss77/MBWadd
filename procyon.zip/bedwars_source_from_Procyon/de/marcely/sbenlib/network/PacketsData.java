// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import java.util.HashMap;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import java.util.Map;

public class PacketsData
{
    private Map<Byte, DataPacket> packets;
    
    public PacketsData() {
        this.packets = new HashMap<Byte, DataPacket>();
    }
    
    public void addPacket(final DataPacket dataPacket) {
        this.packets.put(dataPacket.getPacketID(), dataPacket);
    }
    
    public void addPackets(final DataPacket... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.addPacket(array[i]);
        }
    }
    
    public void removePacket(final byte b) {
        this.packets.remove(b);
    }
    
    public DataPacket getPacket(final byte b) {
        return this.packets.get(b);
    }
    
    public Map<Byte, DataPacket> getPackets() {
        return this.packets;
    }
    
    public void setPackets(final Map<Byte, DataPacket> packets) {
        this.packets = packets;
    }
}
