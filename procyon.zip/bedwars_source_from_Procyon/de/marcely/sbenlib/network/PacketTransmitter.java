// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import javax.annotation.Nullable;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.network.packets.PacketNack;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.HashMap;
import javax.crypto.spec.SecretKeySpec;
import java.util.List;
import java.util.Map;
import de.marcely.sbenlib.compression.Compressor;

public abstract class PacketTransmitter
{
    private static final int PACKET_HEADER_SIZE = 2;
    private static final int WINDOW_HIGHEST = 127;
    private static final int WINDOW_LOWEST = -127;
    private static final byte SORT_TYPE_START = 0;
    private static final byte SORT_TYPE_MIDDLE = 1;
    private static final byte SORT_TYPE_END = 2;
    private static final byte SORT_TYPE_SOLO = 3;
    private final PacketsData packets;
    private final int packetSize;
    private final Compressor compressor;
    private byte currentSendWindow;
    private byte currentReceiveWindow;
    private Map<Byte, byte[]> notAckedSendPackets;
    private Map<Byte, byte[]> queueSplitReceivePackets;
    private List<Byte> missingPackets;
    private SecretKeySpec key;
    
    public PacketTransmitter(final PacketsData packets, final int n, final Compressor compressor) {
        this.currentSendWindow = 0;
        this.currentReceiveWindow = 1;
        this.notAckedSendPackets = new HashMap<Byte, byte[]>();
        this.queueSplitReceivePackets = new TreeMap<Byte, byte[]>();
        this.missingPackets = new ArrayList<Byte>();
        this.packets = packets;
        this.packetSize = n - 2;
        this.compressor = compressor;
    }
    
    public void sendNacks() {
        if (this.missingPackets.size() == 0) {
            return;
        }
        final PacketNack packetNack = new PacketNack();
        packetNack.windows = this.missingPackets.toArray(new Byte[this.missingPackets.size()]);
        try {
            this.sendPacket(packetNack, false);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void sendPacket(final Packet packet, boolean b) throws Exception {
        final byte[] encode = packet.encode();
        int n;
        byte[] array;
        if (this.compressor != null) {
            final byte[] encode2 = this.compressor.encode(encode);
            if (encode2.length < encode.length) {
                n = 1;
                array = encode2;
            }
            else {
                n = 0;
                array = encode;
            }
        }
        else {
            n = 0;
            array = encode;
        }
        byte[][] array2 = new byte[(int)Math.ceil(array.length / (double)this.packetSize)][];
        if (array2.length == 0) {
            array2 = new byte[1][2];
        }
        else {
            for (int i = 0; i < array2.length; ++i) {
                int packetSize = array.length - i * this.packetSize;
                if (packetSize > this.packetSize) {
                    packetSize = this.packetSize;
                }
                array2[i] = new byte[packetSize + 2];
                System.arraycopy(array, i * this.packetSize, array2[i], 2, packetSize);
            }
        }
        if (array2.length >= 2) {
            b = true;
            if (this.currentSendWindow + array2.length > 127) {
                this.currentSendWindow = -128;
            }
        }
        for (int j = 0; j < array2.length; ++j) {
            int n2 = 3;
            if (array2.length >= 2) {
                if (j == 0) {
                    n2 = 0;
                }
                else if (j + 1 == array2.length) {
                    n2 = 2;
                }
                else {
                    n2 = 1;
                }
            }
            array2[j][0] = (byte)(n2 | (b ? 1 : 0) << 2 | n << 3);
            array2[j][1] = (byte)(b ? ((byte)this.getNextSendWindow()) : 0);
            this.send(array2[j]);
            if (b) {
                this.notAckedSendPackets.put(array2[j][1], array2[j]);
            }
        }
    }
    
    public void receiveAck(final byte b) {
        this.notAckedSendPackets.remove(b);
    }
    
    public void receiveNack(final byte b) {
        final byte[] array = this.notAckedSendPackets.get(b);
        if (array != null) {
            this.send(array);
        }
    }
    
    public void handlePacket(final byte[] array) throws Exception {
        if (array.length < 2) {
            return;
        }
        final boolean b = (array[0] & 0x8) == 0x8;
        final boolean b2 = (array[0] & 0x4) == 0x4;
        final byte b3 = (byte)(array[0] & 0x3);
        final byte b4 = array[1];
        if (b2) {
            final PacketAck packetAck = new PacketAck();
            packetAck.windows = new Byte[] { b4 };
            this.sendPacket(packetAck, false);
        }
        final byte[] array2 = new byte[array.length - 2];
        System.arraycopy(array, 2, array2, 0, array2.length);
        if (b2) {
            if (b4 != this.currentReceiveWindow) {
                if (b4 > this.currentReceiveWindow) {
                    for (byte currentReceiveWindow = this.currentReceiveWindow; currentReceiveWindow < b4; ++currentReceiveWindow) {
                        this.missingPackets.add(currentReceiveWindow);
                    }
                    this.currentReceiveWindow = this.getNextWindow(b4);
                }
                else if (this.missingPackets.contains(b4)) {
                    this.missingPackets.remove((Object)b4);
                }
            }
            else {
                this.currentReceiveWindow = this.getNextWindow(b4);
            }
        }
        if (b3 == 3) {
            this.handleData(array2, b);
        }
        else {
            Byte b5 = null;
            Byte b6 = null;
            if (b3 == 0) {
                b5 = b4;
            }
            else if (b3 == 2) {
                b6 = b4;
            }
            if (b5 == null) {
                b5 = b4;
                Label_0346: {
                    break Label_0346;
                    Byte b7;
                    do {
                        final byte[] array3 = this.queueSplitReceivePackets.get(b5);
                        if (array3 == null) {
                            this.queueSplitReceivePackets.put(b4, array);
                            return;
                        }
                        if ((byte)(array3[0] & 0x3) == 0) {
                            break;
                        }
                        b7 = b5;
                        b5 = (byte)(b7 - 1);
                    } while (b7 >= -127);
                }
            }
            if (b6 == null) {
                b6 = b4;
                Label_0439: {
                    break Label_0439;
                    Byte b8;
                    do {
                        final byte[] array4 = this.queueSplitReceivePackets.get(b6);
                        if (array4 == null) {
                            this.queueSplitReceivePackets.put(b4, array);
                            return;
                        }
                        if ((byte)(array4[0] & 0x3) == 2) {
                            break;
                        }
                        b8 = b6;
                        b6 = (byte)(b8 + 1);
                    } while (b8 <= 127);
                }
            }
            if (b3 == 2) {
                this.queueSplitReceivePackets.put(b4, array);
            }
            final byte[] array5 = new byte[((byte)b6 - (byte)b5 + 1 - 1) * this.packetSize + this.queueSplitReceivePackets.get(b6).length - 2];
            for (byte byteValue = b5; byteValue <= b6; ++byteValue) {
                final byte[] array6 = this.queueSplitReceivePackets.remove(byteValue);
                System.arraycopy(array6, 2, array5, (byteValue - (byte)b5) * this.packetSize, array6.length - 2);
            }
            this.handleData(array5, b);
        }
    }
    
    private void handleData(byte[] decode, final boolean b) throws Exception {
        if (b && this.compressor != null) {
            decode = this.compressor.decode(decode);
        }
        final Packet decode2 = PacketDecoder.decode(this.packets, this.key, decode);
        if (decode2 != null) {
            this.receive(decode2);
        }
    }
    
    @Nullable
    private Byte getNextSendWindow() {
        this.currentSendWindow = this.getNextWindow(this.currentSendWindow);
        return this.currentSendWindow;
    }
    
    private byte getNextWindow(final byte b) {
        return (byte)(b + 1);
    }
    
    protected abstract void send(final byte[] p0);
    
    public abstract void receive(final Packet p0);
    
    public void setKey(final SecretKeySpec key) {
        this.key = key;
    }
}
