// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketPong extends Packet
{
    public long time;
    
    @Override
    public byte getType() {
        return 4;
    }
    
    @Override
    protected void _encode(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeSignedLong(this.time);
    }
    
    @Override
    protected void _decode(final BufferedReadStream bufferedReadStream) {
        this.time = bufferedReadStream.readSignedLong();
    }
}
