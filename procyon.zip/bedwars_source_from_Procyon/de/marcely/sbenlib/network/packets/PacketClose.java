// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketClose extends Packet
{
    public String reason;
    
    public PacketClose() {
        this.reason = "UNKOWN";
    }
    
    @Override
    public byte getType() {
        return 7;
    }
    
    @Override
    protected void _encode(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeString(this.reason);
    }
    
    @Override
    protected void _decode(final BufferedReadStream bufferedReadStream) {
        this.reason = bufferedReadStream.readString();
    }
}
