// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public class PacketAck extends Packet
{
    public Byte[] windows;
    
    @Override
    public byte getType() {
        return 5;
    }
    
    @Override
    protected void _encode(final BufferedWriteStream bufferedWriteStream) {
        Byte[] windows;
        for (int length = (windows = this.windows).length, i = 0; i < length; ++i) {
            bufferedWriteStream.write(windows[i]);
        }
    }
    
    @Override
    protected void _decode(final BufferedReadStream bufferedReadStream) {
        this.windows = new Byte[bufferedReadStream.available()];
        for (int i = 0; i < this.windows.length; ++i) {
            this.windows[i] = bufferedReadStream.readByte();
        }
    }
}
