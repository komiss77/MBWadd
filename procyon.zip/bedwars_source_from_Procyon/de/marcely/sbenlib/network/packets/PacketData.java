// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.crypto.spec.SecretKeySpec;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.packets.data.DataPacket;

public class PacketData extends Packet
{
    public DataPacket data;
    public PacketsData packetsData;
    public SecretKeySpec _key;
    
    @Override
    public byte getType() {
        return 2;
    }
    
    @Override
    protected void _encode(final BufferedWriteStream bufferedWriteStream) {
        bufferedWriteStream.writeByte(this.data.getPacketID());
        this.data.encode(bufferedWriteStream);
    }
    
    @Override
    protected void _decode(final BufferedReadStream bufferedReadStream) {
        this.data = this.packetsData.getPacket(bufferedReadStream.readByte());
        if (this.data != null) {
            this.data.set_key(this._key);
            this.data.decode(bufferedReadStream);
        }
    }
}
