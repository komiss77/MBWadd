// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets.data;

import java.io.IOException;
import de.marcely.sbenlib.compression.AES;
import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class SecuredPacket extends NormalPacket
{
    @Override
    public byte getTypeID() {
        return 1;
    }
    
    @Override
    public abstract byte getPacketID();
    
    @Override
    protected abstract void write(final BufferedWriteStream p0);
    
    @Override
    protected abstract void read(final BufferedReadStream p0);
    
    @Override
    public void encode(final BufferedWriteStream bufferedWriteStream) {
        if (this._key == null) {
            new NullPointerException("Missing key/session").printStackTrace();
            return;
        }
        final BufferedWriteStream bufferedWriteStream2 = new BufferedWriteStream();
        this.write(bufferedWriteStream2);
        bufferedWriteStream.write(AES.encrypt(bufferedWriteStream2.toByteArray(), this._key));
        bufferedWriteStream2.close();
    }
    
    @Override
    public void decode(final BufferedReadStream bufferedReadStream) {
        if (this._key == null) {
            new NullPointerException("Missing key/session").printStackTrace();
            return;
        }
        final BufferedReadStream bufferedReadStream2 = new BufferedReadStream(AES.decrypt(bufferedReadStream.read(bufferedReadStream.available()), this._key));
        this.read(bufferedReadStream2);
        try {
            bufferedReadStream2.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
