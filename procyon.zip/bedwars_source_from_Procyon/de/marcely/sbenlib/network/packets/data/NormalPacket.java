// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets.data;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;

public abstract class NormalPacket extends DataPacket
{
    @Override
    public byte getTypeID() {
        return 0;
    }
    
    @Override
    public abstract byte getPacketID();
    
    protected abstract void write(final BufferedWriteStream p0);
    
    protected abstract void read(final BufferedReadStream p0);
    
    @Override
    public void encode(final BufferedWriteStream bufferedWriteStream) {
        this.write(bufferedWriteStream);
    }
    
    @Override
    public void decode(final BufferedReadStream bufferedReadStream) {
        this.read(bufferedReadStream);
    }
}
