// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network.packets.data;

import de.marcely.sbenlib.util.BufferedReadStream;
import de.marcely.sbenlib.util.BufferedWriteStream;
import javax.crypto.spec.SecretKeySpec;

public abstract class DataPacket
{
    protected SecretKeySpec _key;
    public static final byte TYPE_NORMAL = 0;
    public static final byte TYPE_SECURED = 1;
    
    public abstract byte getTypeID();
    
    public abstract byte getPacketID();
    
    public abstract void encode(final BufferedWriteStream p0);
    
    public abstract void decode(final BufferedReadStream p0);
    
    public void set_key(final SecretKeySpec key) {
        this._key = key;
    }
}
