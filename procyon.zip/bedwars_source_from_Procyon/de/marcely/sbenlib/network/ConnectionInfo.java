// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import de.marcely.sbenlib.util.Util;
import de.marcely.sbenlib.compression.CompressionType;
import java.net.InetAddress;

public class ConnectionInfo
{
    public final InetAddress ip;
    public final int port;
    public final ProtocolType protocol;
    public final CompressionType compression;
    
    public ConnectionInfo(final String s, final int n) {
        this(Util.getInetAddress(s), n);
    }
    
    public ConnectionInfo(final InetAddress inetAddress, final int n) {
        this(inetAddress, n, ProtocolType.TCP, CompressionType.ZLib);
    }
    
    public ConnectionInfo(final String s, final int n, final ProtocolType protocolType, final CompressionType compressionType) {
        this(Util.getInetAddress(s), n, protocolType, compressionType);
    }
    
    public ConnectionInfo(final InetAddress ip, final int port, final ProtocolType protocol, final CompressionType compression) {
        this.ip = ip;
        this.port = port;
        this.protocol = protocol;
        this.compression = compression;
    }
}
