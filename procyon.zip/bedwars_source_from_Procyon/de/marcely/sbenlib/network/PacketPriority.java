// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

public enum PacketPriority
{
    NORMAL("NORMAL", 0, (byte)0, false), 
    DONT_LOSE("DONT_LOSE", 1, (byte)1, true), 
    DONT_LOSE_AND_SORTED("DONT_LOSE_AND_SORTED", 2, (byte)2, true);
    
    private static Map<Byte, PacketPriority> VALUES;
    private final byte id;
    private final boolean sendAck;
    
    static {
        PacketPriority.VALUES = new HashMap<Byte, PacketPriority>();
        PacketPriority[] values;
        for (int length = (values = values()).length, i = 0; i < length; ++i) {
            final PacketPriority packetPriority = values[i];
            PacketPriority.VALUES.put(packetPriority.id, packetPriority);
        }
    }
    
    private PacketPriority(final String name, final int ordinal, final byte id, final boolean sendAck) {
        this.id = id;
        this.sendAck = sendAck;
    }
    
    @Nullable
    public static PacketPriority fromId(final byte b) {
        return PacketPriority.VALUES.get(b);
    }
    
    public byte getId() {
        return this.id;
    }
    
    public boolean isSendAck() {
        return this.sendAck;
    }
}
