// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

public enum ConnectionState
{
    NotStarted("NotStarted", 0), 
    Connecting("Connecting", 1), 
    Connected("Connected", 2), 
    Disconnected("Disconnected", 3);
    
    private ConnectionState(final String name, final int ordinal) {
    }
}
