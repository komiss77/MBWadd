// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import de.marcely.sbenlib.network.packets.Packet;

public class QueuedPacket
{
    public final Packet packet;
    public final PacketPriority priority;
    public long lastTimeSend;
    
    public QueuedPacket(final Packet packet, final PacketPriority priority) {
        this.lastTimeSend = 0L;
        this.packet = packet;
        this.priority = priority;
    }
}
