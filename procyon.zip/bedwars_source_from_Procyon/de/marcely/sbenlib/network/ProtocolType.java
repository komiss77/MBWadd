// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import de.marcely.sbenlib.client.protocol.TCPProtocol;
import de.marcely.sbenlib.client.protocol.UDPProtocol;
import de.marcely.sbenlib.client.protocol.Protocol;
import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;

public enum ProtocolType
{
    UDP("UDP", 0, true, 512), 
    TCP("TCP", 1, false, 1500);
    
    private final boolean requiresAckNack;
    private final int maxPacketSize;
    
    private ProtocolType(final String name, final int ordinal, final boolean requiresAckNack, final int maxPacketSize) {
        this.requiresAckNack = requiresAckNack;
        this.maxPacketSize = maxPacketSize;
    }
    
    public Protocol getClientInstance(final ConnectionInfo connectionInfo, final SocketHandler socketHandler, final ServerEventListener serverEventListener) {
        switch (this) {
            case UDP: {
                return new UDPProtocol(connectionInfo, socketHandler, serverEventListener);
            }
            case TCP: {
                return new TCPProtocol(connectionInfo, socketHandler, serverEventListener);
            }
            default: {
                return null;
            }
        }
    }
    
    public boolean isRequiresAckNack() {
        return this.requiresAckNack;
    }
    
    public int getMaxPacketSize() {
        return this.maxPacketSize;
    }
}
