// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.network;

import javax.annotation.Nullable;
import de.marcely.sbenlib.network.packets.PacketClose;
import de.marcely.sbenlib.network.packets.PacketPong;
import de.marcely.sbenlib.network.packets.PacketPing;
import de.marcely.sbenlib.network.packets.PacketNack;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.data.SecuredPacket;
import de.marcely.sbenlib.network.packets.PacketData;
import de.marcely.sbenlib.network.packets.PacketLoginReply;
import de.marcely.sbenlib.network.packets.PacketLogin;
import de.marcely.sbenlib.network.packets.Packet;
import javax.crypto.spec.SecretKeySpec;

public class PacketDecoder
{
    @Nullable
    public static Packet decode(final PacketsData packetsData, final SecretKeySpec key, final byte[] array) throws Exception {
        if (array.length == 0) {
            return null;
        }
        try {
            switch (Packet.getTypeOfHeader(array[0])) {
                case 0: {
                    final PacketLogin packetLogin = new PacketLogin();
                    packetLogin.decode(array);
                    return packetLogin;
                }
                case 1: {
                    final PacketLoginReply packetLoginReply = new PacketLoginReply();
                    packetLoginReply.decode(array);
                    return packetLoginReply;
                }
                case 2: {
                    final PacketData packetData = new PacketData();
                    packetData.packetsData = packetsData;
                    packetData._key = key;
                    packetData.decode(array);
                    if (packetData.data != null && packetData.data instanceof SecuredPacket) {
                        ((SecuredPacket)packetData.data).set_key(key);
                    }
                    return packetData;
                }
                case 5: {
                    final PacketAck packetAck = new PacketAck();
                    packetAck.decode(array);
                    return packetAck;
                }
                case 6: {
                    final PacketNack packetNack = new PacketNack();
                    packetNack.decode(array);
                    return packetNack;
                }
                case 3: {
                    final PacketPing packetPing = new PacketPing();
                    packetPing.decode(array);
                    return packetPing;
                }
                case 4: {
                    final PacketPong packetPong = new PacketPong();
                    packetPong.decode(array);
                    return packetPong;
                }
                case 7: {
                    final PacketClose packetClose = new PacketClose();
                    packetClose.decode(array);
                    return packetClose;
                }
            }
        }
        catch (Exception ex) {
            throw ex;
        }
        return null;
    }
}
