// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client;

import de.marcely.sbenlib.network.packets.PacketNack;
import de.marcely.sbenlib.network.packets.PacketAck;
import de.marcely.sbenlib.network.packets.PacketPong;
import de.marcely.sbenlib.network.packets.PacketLoginReply;
import de.marcely.sbenlib.network.packets.PacketData;
import de.marcely.sbenlib.network.packets.data.SecuredPacket;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.network.packets.data.DataPacket;
import de.marcely.sbenlib.network.packets.PacketClose;
import javax.annotation.Nullable;
import javax.crypto.spec.SecretKeySpec;
import de.marcely.sbenlib.util.Util;
import de.marcely.sbenlib.network.ConnectionState;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.compression.Compressor;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.PacketTransmitter;
import de.marcely.sbenlib.client.protocol.Protocol;

public class SocketHandler
{
    private final SBENServerConnection server;
    private final Protocol protocol;
    public PacketTransmitter packetTransmitter;
    
    public SocketHandler(final SBENServerConnection server) {
        this.server = server;
        this.protocol = server.getConnectionInfo().protocol.getClientInstance(server.getConnectionInfo(), this, new ServerEventListener() {
            @Override
            public void onPacketReceive(final byte[] array) {
                server.networkScheduler.receivePacket(array);
            }
            
            @Override
            public void onDisconnect() {
                SocketHandler.this.close(null);
            }
        });
        this.packetTransmitter = new PacketTransmitter(server.getPacketsData(), server.getConnectionInfo().protocol.getMaxPacketSize(), server.getConnectionInfo().compression.getInstance()) {
            @Override
            protected void send(final byte[] array) {
                SocketHandler.this.protocol.sendPacket(array);
            }
            
            @Override
            public void receive(final Packet packet) {
                SocketHandler.this.handlePacket(packet);
            }
        };
    }
    
    public boolean isRunning() {
        return this.protocol.isRunning();
    }
    
    public boolean run() {
        if (this.isRunning()) {
            return false;
        }
        if (this.protocol.run()) {
            this.getServer().setConnectionState(ConnectionState.Connecting);
            this.server.key = new SecretKeySpec(Util.generateRandomSecurityID(), "AES");
            this.packetTransmitter.setKey(this.server.key);
            return true;
        }
        this.getServer().setConnectionState(ConnectionState.Disconnected);
        return false;
    }
    
    public boolean close(@Nullable String reason) {
        if (reason == null) {
            reason = "SOCKET_CLIENT_CLOSE";
        }
        if (this.isRunning()) {
            final PacketClose packetClose = new PacketClose();
            packetClose.reason = reason;
            try {
                this.server.networkScheduler.sendPacketNow(packetClose, false);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            this.getServer().setConnectionState(ConnectionState.Disconnected);
            this.getServer().onDisconnect(reason);
            return this.protocol.close();
        }
        return false;
    }
    
    public void sendPacket(final DataPacket data, boolean b) {
        if (b && this.getProtocol().getType() == ProtocolType.TCP) {
            b = false;
        }
        if (data instanceof SecuredPacket) {
            ((SecuredPacket)data).set_key(this.server.key);
        }
        final PacketData packetData = new PacketData();
        packetData.data = data;
        packetData.packetsData = this.getServer().getPacketsData();
        this.server.networkScheduler.sendPacket(packetData, b);
    }
    
    private void handlePacket(final Packet packet) {
        switch (packet.getType()) {
            case 1: {
                this.handle((PacketLoginReply)packet);
                break;
            }
            case 4: {
                this.handle((PacketPong)packet);
                break;
            }
            case 7: {
                this.handle((PacketClose)packet);
                break;
            }
            case 2: {
                this.handle((PacketData)packet);
                break;
            }
            case 5: {
                this.handle((PacketAck)packet);
                break;
            }
            case 6: {
                this.handle((PacketNack)packet);
                break;
            }
        }
    }
    
    private void handle(final PacketLoginReply packetLoginReply) {
        if (this.server.getConnectionState() != ConnectionState.Connecting) {
            return;
        }
        switch (packetLoginReply.reply) {
            case 0: {
                this.getServer().setConnectionState(ConnectionState.Connected);
                break;
            }
            case 1: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_PROTOCOL_OUTDATED_CLIENT");
                break;
            }
            case 2: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_PROTOCOL_OUTDATED_SERVER");
                break;
            }
            case 3: {
                this.getServer().setConnectionState(ConnectionState.Disconnected);
                this.close("LOGIN_UNKOWN");
                break;
            }
        }
    }
    
    private void handle(final PacketPong packetPong) {
        this.getServer().setPing(System.currentTimeMillis() - packetPong.time);
    }
    
    private void handle(final PacketClose packetClose) {
        if (this.server.getConnectionState() != ConnectionState.Connected) {
            return;
        }
        this.close(packetClose.reason);
    }
    
    private void handle(final PacketData packetData) {
        if (this.server.getConnectionState() != ConnectionState.Connected) {
            return;
        }
        this.getServer().onPacketReceive(packetData.data);
    }
    
    private void handle(final PacketAck packetAck) {
        Byte[] windows;
        for (int length = (windows = packetAck.windows).length, i = 0; i < length; ++i) {
            this.packetTransmitter.receiveAck(windows[i]);
        }
    }
    
    private void handle(final PacketNack packetNack) {
        Byte[] windows;
        for (int length = (windows = packetNack.windows).length, i = 0; i < length; ++i) {
            this.packetTransmitter.receiveNack(windows[i]);
        }
    }
    
    public SBENServerConnection getServer() {
        return this.server;
    }
    
    public Protocol getProtocol() {
        return this.protocol;
    }
}
