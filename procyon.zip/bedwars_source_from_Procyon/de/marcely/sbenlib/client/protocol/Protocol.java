// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client.protocol;

import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.network.packets.Packet;
import de.marcely.sbenlib.util.SThread;
import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionInfo;

public abstract class Protocol
{
    protected final ConnectionInfo connectionInfo;
    protected final SocketHandler socketHandler;
    protected final ServerEventListener listener;
    protected SThread thread;
    protected boolean running;
    
    public Protocol(final ConnectionInfo connectionInfo, final SocketHandler socketHandler, final ServerEventListener listener) {
        this.thread = null;
        this.running = false;
        this.connectionInfo = connectionInfo;
        this.socketHandler = socketHandler;
        this.listener = listener;
    }
    
    public boolean sendPacket(final byte[] array) {
        return this._sendPacket(array);
    }
    
    public boolean sendPacket(final Packet packet) {
        return this.sendPacket(packet.encode());
    }
    
    public abstract ProtocolType getType();
    
    public abstract boolean run();
    
    public abstract boolean close();
    
    protected abstract boolean _sendPacket(final byte[] p0);
    
    public ConnectionInfo getConnectionInfo() {
        return this.connectionInfo;
    }
    
    public SocketHandler getSocketHandler() {
        return this.socketHandler;
    }
    
    public ServerEventListener getListener() {
        return this.listener;
    }
    
    public SThread getThread() {
        return this.thread;
    }
    
    public boolean isRunning() {
        return this.running;
    }
}
