// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client.protocol;

import java.io.InputStream;
import java.io.IOException;
import de.marcely.sbenlib.util.SThread;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionInfo;
import java.net.Socket;

public class TCPProtocol extends Protocol
{
    private Socket socket;
    
    public TCPProtocol(final ConnectionInfo connectionInfo, final SocketHandler socketHandler, final ServerEventListener serverEventListener) {
        super(connectionInfo, socketHandler, serverEventListener);
    }
    
    @Override
    public ProtocolType getType() {
        return ProtocolType.TCP;
    }
    
    @Override
    public boolean run() {
        if (!this.running) {
            try {
                this.socket = new Socket(this.connectionInfo.ip, this.connectionInfo.port);
                (this.thread = new SThread(SThread.ThreadType.Protocol_TCP_Client) {
                    @Override
                    protected void _run() {
                        try {
                            final InputStream inputStream = TCPProtocol.this.socket.getInputStream();
                            while (TCPProtocol.this.running) {
                                if (inputStream.available() >= 1) {
                                    final byte[] b = new byte[inputStream.available()];
                                    inputStream.read(b);
                                    TCPProtocol.this.listener.onPacketReceive(b);
                                }
                            }
                        }
                        catch (IOException ex) {
                            final String message = ex.getMessage();
                            if (message != null && (message.equals("Stream closed.") || message.equals("Socket operation on nonsocket: socket available"))) {
                                return;
                            }
                            ex.printStackTrace();
                        }
                    }
                }).start();
            }
            catch (IOException ex) {
                final String message = ex.getMessage();
                if (message != null && message.equals("Connection refused: connect")) {
                    return false;
                }
                ex.printStackTrace();
                return false;
            }
            return this.running = true;
        }
        return false;
    }
    
    @Override
    public boolean close() {
        if (this.running) {
            try {
                this.socket.close();
                this.running = false;
            }
            catch (IOException ex) {
                ex.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    protected boolean _sendPacket(final byte[] b) {
        if (this.running) {
            try {
                this.socket.getOutputStream().write(b);
                return true;
            }
            catch (IOException ex) {
                final String message = ex.getMessage();
                if (message != null && message.equals("Connection reset by peer: socket write error")) {
                    this.close();
                }
                else {
                    ex.printStackTrace();
                }
                return false;
            }
        }
        return false;
    }
}
