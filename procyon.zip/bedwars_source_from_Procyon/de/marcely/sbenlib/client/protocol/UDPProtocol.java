// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client.protocol;

import java.net.SocketException;
import java.io.IOException;
import java.util.Arrays;
import java.net.DatagramPacket;
import de.marcely.sbenlib.util.SThread;
import de.marcely.sbenlib.network.ProtocolType;
import de.marcely.sbenlib.client.ServerEventListener;
import de.marcely.sbenlib.client.SocketHandler;
import de.marcely.sbenlib.network.ConnectionInfo;
import java.net.DatagramSocket;

public class UDPProtocol extends Protocol
{
    private DatagramSocket socket;
    
    public UDPProtocol(final ConnectionInfo connectionInfo, final SocketHandler socketHandler, final ServerEventListener serverEventListener) {
        super(connectionInfo, socketHandler, serverEventListener);
    }
    
    @Override
    public ProtocolType getType() {
        return ProtocolType.UDP;
    }
    
    @Override
    public boolean run() {
        if (!this.running) {
            this.running = true;
            try {
                this.socket = new DatagramSocket();
                (this.thread = new SThread(SThread.ThreadType.Protocol_UDP_Client) {
                    @Override
                    protected void _run() {
                        while (UDPProtocol.this.running) {
                            final DatagramPacket p = new DatagramPacket(new byte[512], 512);
                            try {
                                UDPProtocol.this.socket.receive(p);
                                if (!p.getAddress().equals(UDPProtocol.this.connectionInfo.ip) || p.getPort() != UDPProtocol.this.connectionInfo.port) {
                                    return;
                                }
                                UDPProtocol.this.listener.onPacketReceive(Arrays.copyOfRange(p.getData(), p.getOffset(), p.getLength()));
                            }
                            catch (IOException ex) {
                                final String message = ex.getMessage();
                                if (message != null && (message.equals("socket closed") || message.equals("Socket closed"))) {
                                    UDPProtocol.this.socketHandler.close(null);
                                    return;
                                }
                                ex.printStackTrace();
                            }
                        }
                    }
                }).start();
            }
            catch (SocketException ex) {
                ex.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public boolean close() {
        if (this.running) {
            this.running = false;
            this.socket.close();
            return true;
        }
        return false;
    }
    
    @Override
    protected boolean _sendPacket(final byte[] buf) {
        if (this.running) {
            try {
                this.socket.send(new DatagramPacket(buf, buf.length, this.connectionInfo.ip, this.connectionInfo.port));
            }
            catch (IOException ex) {
                ex.printStackTrace();
                return false;
            }
            return true;
        }
        return false;
    }
}
