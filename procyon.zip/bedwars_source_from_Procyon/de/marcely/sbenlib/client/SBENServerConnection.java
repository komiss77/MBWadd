// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client;

import de.marcely.sbenlib.network.packets.data.DataPacket;
import javax.annotation.Nullable;
import de.marcely.sbenlib.util.SThread;
import javax.crypto.spec.SecretKeySpec;
import de.marcely.sbenlib.network.PacketsData;
import de.marcely.sbenlib.network.ConnectionState;
import de.marcely.sbenlib.network.ConnectionInfo;

public abstract class SBENServerConnection
{
    public boolean addShutdownHook;
    private final ConnectionInfo connectionInfo;
    private final SocketHandler socketHandler;
    public final NetworkScheduler networkScheduler;
    private ConnectionState connectionState;
    private long ping;
    private PacketsData packetsData;
    public SecretKeySpec key;
    private Thread shutdownHook;
    
    public SBENServerConnection(final ConnectionInfo connectionInfo, final int n) {
        this.addShutdownHook = false;
        this.connectionState = ConnectionState.NotStarted;
        this.ping = 0L;
        this.packetsData = new PacketsData();
        this.key = null;
        this.shutdownHook = null;
        this.connectionInfo = connectionInfo;
        this.socketHandler = new SocketHandler(this);
        this.networkScheduler = new NetworkScheduler(this.socketHandler, n);
    }
    
    public boolean isRunning() {
        return this.socketHandler.isRunning();
    }
    
    public boolean run() {
        final boolean run = this.socketHandler.run();
        if (run) {
            this.networkScheduler.run();
            if (this.addShutdownHook) {
                this.shutdownHook = new SThread(SThread.ThreadType.ShutdownHook_Client) {
                    @Override
                    protected void _run() {
                        if (SBENServerConnection.this.isRunning()) {
                            SBENServerConnection.this.close("DISCONNECTED");
                            while (SBENServerConnection.this.socketHandler.isRunning()) {
                                try {
                                    Thread.sleep(5L);
                                }
                                catch (InterruptedException ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }
                    }
                };
                Runtime.getRuntime().addShutdownHook(this.shutdownHook);
            }
        }
        return run;
    }
    
    public void close() {
        this.networkScheduler.close(null);
    }
    
    public void close(@Nullable final String s) {
        this.networkScheduler.close(s);
    }
    
    public void setConnectionState(final ConnectionState connectionState) {
        if (this.connectionState == connectionState) {
            return;
        }
        this.onStateChange(connectionState);
        this.connectionState = connectionState;
    }
    
    public void sendPacket(final DataPacket dataPacket) {
        this.sendPacket(dataPacket, true);
    }
    
    public void sendPacket(final DataPacket dataPacket, final boolean b) {
        this.socketHandler.sendPacket(dataPacket, b);
    }
    
    public abstract void onStateChange(final ConnectionState p0);
    
    public abstract void onPacketReceive(final DataPacket p0);
    
    public abstract void onDisconnect(final String p0);
    
    public ConnectionInfo getConnectionInfo() {
        return this.connectionInfo;
    }
    
    public ConnectionState getConnectionState() {
        return this.connectionState;
    }
    
    public long getPing() {
        return this.ping;
    }
    
    public void setPing(final long ping) {
        this.ping = ping;
    }
    
    public PacketsData getPacketsData() {
        return this.packetsData;
    }
    
    public void setPacketsData(final PacketsData packetsData) {
        this.packetsData = packetsData;
    }
    
    public SecretKeySpec getKey() {
        return this.key;
    }
}
