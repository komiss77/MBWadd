// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client;

import de.marcely.sbenlib.network.packets.PacketPing;
import de.marcely.sbenlib.network.packets.PacketLogin;
import de.marcely.sbenlib.network.ConnectionState;
import javax.annotation.Nullable;
import de.marcely.sbenlib.util.SThread;
import java.util.concurrent.ConcurrentLinkedQueue;
import de.marcely.sbenlib.network.packets.Packet;
import java.util.Queue;

public class NetworkScheduler
{
    private final SocketHandler socket;
    private final int ups;
    private boolean isRunning;
    private Queue<byte[]> receivePackets;
    private Queue<Packet> sendPackets;
    private boolean sendClose;
    private String closeMessage;
    private long lastPing;
    private long lastReceivedPacket;
    
    public NetworkScheduler(final SocketHandler socket, final int ups) {
        this.isRunning = false;
        this.receivePackets = new ConcurrentLinkedQueue<byte[]>();
        this.sendPackets = new ConcurrentLinkedQueue<Packet>();
        this.sendClose = false;
        this.lastReceivedPacket = System.currentTimeMillis();
        this.socket = socket;
        this.ups = ups;
    }
    
    public boolean isRunning() {
        return this.isRunning;
    }
    
    public boolean run() {
        if (this.isRunning()) {
            return false;
        }
        this.isRunning = true;
        new SThread(SThread.ThreadType.NetworkScheduler) {
            @Override
            protected void _run() {
                final double n = 250 / NetworkScheduler.this.ups;
                long nanoTime = System.nanoTime();
                double n2 = 0.0;
                while (NetworkScheduler.this.isRunning()) {
                    final long nanoTime2 = System.nanoTime();
                    n2 += (nanoTime2 - nanoTime) / n;
                    nanoTime = nanoTime2;
                    while (n2 >= 1.0) {
                        NetworkScheduler.this.update();
                        --n2;
                    }
                }
            }
        }.start();
        return true;
    }
    
    public void close(@Nullable final String closeMessage) {
        this.sendClose = true;
        this.closeMessage = closeMessage;
    }
    
    public void sendPacket(final Packet packet, final boolean needACK) {
        packet._needACK = needACK;
        this.sendPackets.add(packet);
    }
    
    public void sendPacketNow(final Packet packet, final boolean needACK) throws Exception {
        packet._needACK = needACK;
        this.socket.packetTransmitter.sendPacket(packet, packet._needACK);
    }
    
    public void receivePacket(final byte[] array) {
        this.receivePackets.add(array);
    }
    
    public void update() {
        if (!this.isRunning) {
            return;
        }
        if (System.currentTimeMillis() - 6000L > this.lastReceivedPacket) {
            this.close("SERVER_TIMEOUT");
        }
        if (this.sendClose) {
            this.sendPackets.clear();
            this.sendClose = false;
            this.isRunning = false;
            this.socket.close(this.closeMessage);
            return;
        }
        if (this.receivePackets.size() >= 1) {
            this.lastReceivedPacket = System.currentTimeMillis();
            byte[] array;
            while ((array = this.receivePackets.poll()) != null) {
                try {
                    this.socket.packetTransmitter.handlePacket(array);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            this.socket.packetTransmitter.sendNacks();
        }
        if (System.currentTimeMillis() - 1500L > this.lastPing) {
            this.lastPing = System.currentTimeMillis();
            if (this.socket.getServer().getConnectionState() == ConnectionState.Connecting) {
                final PacketLogin packetLogin = new PacketLogin();
                packetLogin.security_id = this.socket.getServer().key.getEncoded();
                packetLogin.version_protocol = 3;
                this.sendPacket(packetLogin, false);
            }
            else {
                final PacketPing packetPing = new PacketPing();
                packetPing.time = System.currentTimeMillis();
                this.sendPacket(packetPing, false);
            }
        }
        if (this.sendPackets.size() >= 1) {
            Packet packet;
            while ((packet = this.sendPackets.poll()) != null) {
                try {
                    this.sendPacketNow(packet, packet._needACK);
                }
                catch (Exception ex2) {
                    ex2.printStackTrace();
                }
            }
        }
    }
}
