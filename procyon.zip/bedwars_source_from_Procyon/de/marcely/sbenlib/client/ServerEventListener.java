// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.client;

public interface ServerEventListener
{
    void onPacketReceive(final byte[] p0);
    
    void onDisconnect();
}
