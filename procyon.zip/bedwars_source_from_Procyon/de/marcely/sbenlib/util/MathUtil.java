// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

public class MathUtil
{
    public static int getSubtractable(int n, final int n2) {
        while (n % n2 != 0) {
            ++n;
        }
        return n;
    }
}
