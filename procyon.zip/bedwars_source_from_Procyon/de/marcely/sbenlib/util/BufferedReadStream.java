// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.InputStream;

public class BufferedReadStream extends InputStream
{
    private InputStream stream;
    private byte[] buffer;
    private int pos;
    private int mark;
    
    public BufferedReadStream(final InputStream stream) {
        this.pos = 0;
        this.mark = 0;
        this.stream = stream;
    }
    
    public BufferedReadStream(final byte[] buffer) {
        this.pos = 0;
        this.mark = 0;
        this.buffer = buffer;
    }
    
    @Override
    public int read() {
        if (this.stream != null) {
            try {
                return this.stream.read();
            }
            catch (IOException ex) {
                ex.printStackTrace();
                return -1;
            }
        }
        return (this.pos < this.buffer.length) ? (this.buffer[this.pos++] & 0xFF) : -1;
    }
    
    @Override
    public int available() {
        try {
            return (this.stream != null) ? this.stream.available() : (this.buffer.length - this.pos);
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return -1;
        }
    }
    
    @Override
    public int read(final byte[] array) {
        return this.read(array, 0, array.length);
    }
    
    @Override
    public int read(final byte[] array, final int n, final int n2) {
        try {
            return (this.stream != null) ? this.stream.read(array, n, n2) : super.read(array, n, n2);
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return -1;
        }
    }
    
    @Override
    public long skip(final long n) {
        try {
            if (this.stream != null) {
                return this.stream.skip(n);
            }
            this.pos += (int)n;
            return n;
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return -1L;
        }
    }
    
    @Override
    public void mark(final int n) {
        if (this.stream != null) {
            this.stream.mark(n);
        }
        else {
            this.mark = n;
        }
    }
    
    @Override
    public boolean markSupported() {
        return this.stream == null || this.stream.markSupported();
    }
    
    @Override
    public void reset() {
        try {
            if (this.stream != null) {
                this.stream.reset();
            }
            else {
                this.pos = this.mark;
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public byte[] read(final int n) {
        if (n == 0) {
            return new byte[0];
        }
        final byte[] array = new byte[n];
        this.read(array);
        return array;
    }
    
    public byte readByte() {
        return (byte)this.read();
    }
    
    public int readUnsignedByte() {
        return this.readByte() & 0xFF;
    }
    
    public byte[] readByteArray() {
        return this.read((int)this.readUnsignedInt());
    }
    
    public int readSignedInt() {
        return ByteBuffer.wrap(this.read(4)).getInt();
    }
    
    public long readUnsignedInt() {
        return (long)this.readSignedInt() & 0xFFFFFFFFL;
    }
    
    public short readSignedShort() {
        return ByteBuffer.wrap(this.read(2)).getShort();
    }
    
    public int readUnsignedShort() {
        return this.readSignedShort() & 0xFFFF;
    }
    
    public float readFloat() {
        return ByteBuffer.wrap(this.read(4)).getFloat();
    }
    
    public double readDouble() {
        return ByteBuffer.wrap(this.read(8)).getDouble();
    }
    
    public long readSignedLong() {
        return ByteBuffer.wrap(this.read(8)).getLong();
    }
    
    public String readString() {
        final byte[] byteArray = this.readByteArray();
        return (byteArray != null) ? new String(byteArray, StandardCharsets.UTF_8) : null;
    }
    
    public boolean readBoolean() {
        return this.readByte() == 1;
    }
    
    public boolean readAndCheckMagic(final byte[] array) {
        for (int i = 0; i < array.length; ++i) {
            final int read = this.read();
            if (read <= -1 || read != array[i]) {
                return false;
            }
        }
        return true;
    }
}
