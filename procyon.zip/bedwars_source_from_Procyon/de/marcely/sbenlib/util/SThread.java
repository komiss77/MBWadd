// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

import java.util.ArrayList;
import java.util.List;

public abstract class SThread extends Thread
{
    private static final List<SThread> runningThreads;
    private final ThreadType type;
    
    static {
        runningThreads = new ArrayList<SThread>();
    }
    
    public SThread() {
        this(ThreadType.Custom);
    }
    
    public SThread(final ThreadType type) {
        this.type = type;
    }
    
    @Override
    public void run() {
        SThread.runningThreads.add(this);
        this._run();
        SThread.runningThreads.remove(this);
    }
    
    protected abstract void _run();
    
    public static List<SThread> getRunningThreads() {
        return SThread.runningThreads;
    }
    
    public ThreadType getType() {
        return this.type;
    }
    
    public enum ThreadType
    {
        Protocol_TCP_Client("Protocol_TCP_Client", 0), 
        Protocol_TCP_Server("Protocol_TCP_Server", 1), 
        Protocol_UDP_Client("Protocol_UDP_Client", 2), 
        Protocol_UDP_Server("Protocol_UDP_Server", 3), 
        ShutdownHook_Client("ShutdownHook_Client", 4), 
        Init("Init", 5), 
        NetworkScheduler("NetworkScheduler", 6), 
        Custom("Custom", 7);
        
        private ThreadType(final String name, final int ordinal) {
        }
    }
}
