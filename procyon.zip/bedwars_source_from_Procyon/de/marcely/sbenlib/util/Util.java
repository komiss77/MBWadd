// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Random;

public class Util
{
    public static final Random RAND;
    
    static {
        RAND = new Random();
    }
    
    public static InetAddress getInetAddress(final String host) {
        try {
            return InetAddress.getByName(host);
        }
        catch (UnknownHostException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static void sleep(final long n) {
        try {
            Thread.sleep(n);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    
    public static byte[] generateRandomSecurityID() {
        final byte[] array = new byte[16];
        for (int i = 0; i < array.length; ++i) {
            array[i] = (byte)Util.RAND.nextInt(255);
        }
        return array;
    }
    
    public static byte[] copyOfRange(final byte[] array, final int n, final int n2) {
        final byte[] array2 = new byte[n2];
        System.arraycopy(array, n, array2, 0, n2);
        return array2;
    }
}
