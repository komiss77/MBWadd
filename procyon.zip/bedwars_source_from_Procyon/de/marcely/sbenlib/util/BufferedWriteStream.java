// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.io.IOException;
import java.io.OutputStream;

public class BufferedWriteStream extends OutputStream
{
    private OutputStream stream;
    private byte[] buffer;
    private int count;
    
    public BufferedWriteStream(final OutputStream stream) {
        this.count = 0;
        this.stream = stream;
    }
    
    public BufferedWriteStream(final int i) {
        this.count = 0;
        if (i < 0) {
            throw new IllegalArgumentException("Negative initial size: " + i);
        }
        this.buffer = new byte[i];
    }
    
    public BufferedWriteStream() {
        this(32);
    }
    
    @Override
    public void write(final int n) {
        if (this.stream != null) {
            try {
                this.stream.write(n);
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else {
            final int n2 = this.count + 1;
            if (n2 > this.buffer.length) {
                this.buffer = Arrays.copyOf(this.buffer, Math.max(this.buffer.length << 1, n2));
            }
            this.buffer[this.count] = (byte)n;
            this.count = n2;
        }
    }
    
    @Override
    public void write(final byte[] b) {
        try {
            super.write(b);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void writeByte(final byte b) {
        this.write(b);
    }
    
    public void writeUnsignedByte(final int n) {
        this.writeByte((byte)(n & 0xFF));
    }
    
    public void writeByteArray(final byte[] array) {
        this.writeUnsignedInt(array.length);
        this.write(array);
    }
    
    public void writeSignedInt(final int n) {
        this.write(ByteBuffer.allocate(4).putInt(n).array());
    }
    
    public void writeUnsignedInt(final long n) {
        this.writeSignedInt((int)(n & 0xFFFFFFFFL));
    }
    
    public void writeSignedShort(final short n) {
        this.write(ByteBuffer.allocate(2).putShort(n).array());
    }
    
    public void writeUnsignedShort(final int n) {
        this.writeSignedShort((short)(n & 0xFFFF));
    }
    
    public void writeFloat(final float n) {
        this.write(ByteBuffer.allocate(4).putFloat(n).array());
    }
    
    public void writeDouble(final double n) {
        this.write(ByteBuffer.allocate(8).putDouble(n).array());
    }
    
    public void writeSignedLong(final long n) {
        this.write(ByteBuffer.allocate(8).putLong(n).array());
    }
    
    public void writeString(final String s) {
        this.writeByteArray(s.getBytes(StandardCharsets.UTF_8));
    }
    
    public void writeBoolean(final boolean b) {
        this.writeByte((byte)(b ? 1 : 0));
    }
    
    public byte[] toByteArray() {
        if (this.stream != null) {
            throw new UnsupportedOperationException("Output is a stream");
        }
        return Arrays.copyOf(this.buffer, this.count);
    }
    
    @Override
    public void close() {
        try {
            super.close();
            if (this.stream != null) {
                this.stream.close();
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
