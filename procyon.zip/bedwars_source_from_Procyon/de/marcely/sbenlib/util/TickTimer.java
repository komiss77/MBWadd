// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.util;

import java.util.TimerTask;
import java.util.ArrayList;
import java.util.Timer;
import java.util.List;

@Deprecated
public abstract class TickTimer
{
    private static final List<TickTimer> timers;
    private final boolean repeating;
    private final long start;
    private final long delay;
    private Timer timer;
    
    static {
        timers = new ArrayList<TickTimer>();
    }
    
    public TickTimer(final boolean b, final long n) {
        this(b, n, 0L);
    }
    
    public TickTimer(final boolean repeating, final long delay, final long start) {
        this.repeating = repeating;
        this.delay = delay;
        this.start = start;
    }
    
    public boolean isRunning() {
        return this.timer != null;
    }
    
    public boolean start() {
        if (this.isRunning()) {
            return false;
        }
        this.timer = new Timer();
        TickTimer.timers.add(this);
        if (this.repeating) {
            this.timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    TickTimer.this.onRun();
                }
            }, this.start, this.delay);
        }
        else {
            this.timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    TickTimer.this.onRun();
                }
            }, this.delay);
        }
        return true;
    }
    
    public boolean stop() {
        if (!this.isRunning()) {
            return false;
        }
        TickTimer.timers.remove(this);
        this.timer.cancel();
        this.timer = null;
        return true;
    }
    
    public abstract void onRun();
    
    public static List<TickTimer> getTimers() {
        return TickTimer.timers;
    }
    
    public boolean isRepeating() {
        return this.repeating;
    }
    
    public long getStart() {
        return this.start;
    }
    
    public long getDelay() {
        return this.delay;
    }
}
