// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.compression;

import java.io.InputStream;
import java.util.zip.InflaterInputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.io.ByteArrayOutputStream;

public class ZLibCompression implements Compressor
{
    public static ZLibCompression instance;
    
    static {
        ZLibCompression.instance = new ZLibCompression();
    }
    
    @Override
    public CompressionType getType() {
        return CompressionType.ZLib;
    }
    
    @Override
    public byte[] encode(final byte[] b) throws Exception {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(out);
        deflaterOutputStream.write(b);
        deflaterOutputStream.flush();
        deflaterOutputStream.close();
        return out.toByteArray();
    }
    
    @Override
    public byte[] decode(final byte[] buf) throws Exception {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final InflaterInputStream inflaterInputStream = new InflaterInputStream(new ByteArrayInputStream(buf));
        int read;
        while ((read = inflaterInputStream.read()) != -1) {
            byteArrayOutputStream.write(read);
        }
        inflaterInputStream.close();
        return byteArrayOutputStream.toByteArray();
    }
    
    public static ZLibCompression getInstance() {
        return ZLibCompression.instance;
    }
}
