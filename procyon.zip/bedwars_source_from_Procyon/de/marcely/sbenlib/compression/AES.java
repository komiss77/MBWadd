// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.compression;

import javax.annotation.Nullable;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.security.InvalidKeyException;
import javax.crypto.NoSuchPaddingException;
import java.security.NoSuchAlgorithmException;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AES
{
    @Nullable
    public static byte[] encrypt(final byte[] input, final SecretKeySpec key) {
        try {
            final Cipher instance = Cipher.getInstance("AES");
            instance.init(1, key);
            return instance.doFinal(input);
        }
        catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
    
    @Nullable
    public static byte[] decrypt(final byte[] input, final SecretKeySpec key) {
        try {
            final Cipher instance = Cipher.getInstance("AES");
            instance.init(2, key);
            return instance.doFinal(input);
        }
        catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            final Throwable t;
            t.printStackTrace();
            return null;
        }
    }
}
