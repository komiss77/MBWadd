// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.compression;

public interface Compressor
{
    CompressionType getType();
    
    byte[] encode(final byte[] p0) throws Exception;
    
    byte[] decode(final byte[] p0) throws Exception;
}
