// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.compression;

public enum CompressionType
{
    None("None", 0, (Compressor)null), 
    ZLib("ZLib", 1, (Compressor)new ZLibCompression());
    
    private final Compressor instance;
    
    private CompressionType(final String name, final int ordinal, final Compressor instance) {
        this.instance = instance;
    }
    
    public Compressor getInstance() {
        return this.instance;
    }
}
