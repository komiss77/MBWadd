// 
// Decompiled by Procyon v0.5.36
// 

package de.marcely.sbenlib.compression;

import java.nio.charset.StandardCharsets;
import javax.xml.bind.DatatypeConverter;

public class Base64
{
    public static byte[] encode(final byte[] array) {
        return DatatypeConverter.printBase64Binary(array).getBytes(StandardCharsets.UTF_8);
    }
    
    public static byte[] decode(final byte[] bytes) {
        return DatatypeConverter.parseBase64Binary(new String(bytes, StandardCharsets.UTF_8));
    }
}
