#!/bin/sh

#while true
#do
#   java -jar spigot-1.11.jar
#done



Start()
{
clear 
 BINDIR=$(dirname "$(readlink -fn "$0")")
 cd "$BINDIR"

  cp -u /home/komiss/update/spigot_npf.jar bw05.jar
  cp -ru /home/komiss/update/plugins/* plugins/
  cp -ru /home/komiss/update/bw/* plugins/

   
Terminal=true


#java -server -Dfile.encoding=UTF-8 -Xmx2G -Xms48M -XX:+UseConcMarkSweepGC -XX:+CMSIncrementalMode -XX:-UseAdaptiveSizePolicy  -XX:SoftRefLRUPolicyMSPerMB=50 -Xmn128M -jar g3.jar nogui

java -server -Dfile.encoding=UTF-8 -Xmx2G -Xms48M -XX:+CrashOnOutOfMemoryError -jar bw05.jar nogui
IF
}


End()
{
 echo ""
 exit 
}


IF()
{
 if test -e "restart.true";
 then
	Start
 else
	End
 fi
}


Start


